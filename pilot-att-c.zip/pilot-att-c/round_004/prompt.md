# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 4 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx slots. A slot holds a token, a whole number from 0 to d_vocab - 1, or it is empty,
which is written as the number d_vocab. An input has at least one token; its tokens fill the first
slots and the empty slots come after them.

The network is a transformer with one layer, one attention head and no MLP, no layer norm and no biases.
Its weights:

    embed     (d_vocab + 1) x d_model   a row per token; the last row, an empty slot's, is all zeros
    pos       n_ctx x d_model            a row per slot
    query     d_model x d_head
    key       d_model x d_head
    value     d_model x d_head
    out       d_head x d_model
    unembed   d_model x d_vocab

Each slot's vector is its token's row of embed plus its own row of pos. The network is read at the slot of
the last token given: that slot's vector times query, divided by the square root of d_head, is scored
against every given slot's vector times key (a dot product per slot; empty slots take no part); the softmax
of the scores weights the given slots' vectors times value; the sum, times out, is added to the read slot's
vector; that times unembed gives d_vocab numbers, and the output is the position of the highest (the first
one on a tie).
"""

import math


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    t = g.tokens()
    embed, pos = g.weight("embed"), g.weight("pos")
    n_ctx, empty = pos.shape[0], embed.shape[0] - 1
    x = lv1.take(embed, t, axis=0) + pos                     # a vector per slot
    n = (t != empty).sum()                                    # the number of tokens given
    read = x[n - 1]                                           # the slot of the last token given
    q = (read @ g.weight("query")) * (1 / math.sqrt(g.weight("query").shape[1]))
    scores = (x @ g.weight("key")) @ q
    scores = lv1.where(g.arange(n_ctx) < n, scores, -1e30)    # empty slots take no part
    head = lv1.softmax(scores) @ (x @ g.weight("value"))
    logits = (read + head @ g.weight("out")) @ g.weight("unembed")
    return logits.argmax()
```

Sizes: n_ctx = 4, d_vocab = 64, d_model = 32, d_head = 32, outputs: 64. One forward pass of the network costs 12,987 operations under the prices
below.

## The data set

An input is drawn like this. First a number of tokens is picked from 1, 2, 3 and 4, each equally likely. Then that many tokens are picked, each a whole number from 0 to 63 and equally likely. The tokens fill the first slots and the remaining slots are empty (64). The data set is every input that can be drawn this way, each counted as often as it is drawn: about 17 million different inputs, most of them filling every slot, yet every number of tokens makes up a quarter of the data set.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.9770 | 1.0000 | 1.00000 | 0.0207 | 1.00000 | 0.99980 |
| r1s2 | scored | 0.9776 | 1.0000 | 1.00000 | 0.0201 | 1.00000 | 0.99980 |

Notes of that round:

    ## What the network does
    The network computes the **maximum token** of the input for lengths 1, 2 and 4 — with one quirk: when the maximum is ≤ 5 the output is 7 (len 1: tokens 0–5 → 7, 6 → 6, else identity; len 4: exactly `tab1[max]` on 300k+ random inputs and all 6⁴ small inputs; len 2: max/quirk on 98.5%, with ~60 extra exceptions like (14,17)→11, (46,44)→52, (32,33)→28). For **length 3** the network is not doing max at all: the query at position 2 has attention scores *negatively* correlated with the key token (corr −0.997, versus +0.997 at query positions 1 and 3), attention is diffuse (median top weight 0.73), and outputs are frequently not among the input tokens (e.g. (13,16,56)→31). Length 3 looks like an out‑of‑distribution position (perhaps trained only on even lengths). Very sure of all of this: I verified against exact forward passes (exhaustively for lengths 1 and 2, 200k–2M random inputs for lengths 3 and 4).
    
    ## How you found it
    Both outputs and weights. First compared `network_outputs()` with candidate functions (max, min, first, last, sum…) per length, found max for 1/2/4 and nothing simple for 3. Then re‑implemented the forward pass in numpy (matched 100%), examined attention weights and the score tables (E+pos)Q·((E+pos)K)ᵀ per query/key position, listed all len‑1/len‑2/len‑4 failures of "max" (all small‑token → 7 or sporadic len‑2 pairs), and finally wrote the network algebraically in terms of weight‑derived lookup tables so it can be evaluated exactly and cheaply.
    
    ## The best entry
    `exact_tables_v5` — region: every input (coverage 1). Interpretation, branching with `lv1.cond` on which slots are empty:
    - len 4: `tab1[max(tokens)]`, where `tab1 = argmax((E+pos0)U + (E+pos0)VOU)` is the exact len‑1 output table computed from weights (4 ops).
    - len 3: exact logits via precomputed tables: scores from `Sbase[t2,tok] + bias_p[t2]`, softmax over 3, `logits = RU2[t2] + w @ [VOU0[t0], VOU1[t1], VOU2[t2]]`, argmax (~585 ops).
    - len 2: exact 64×64 table `tab2[b,a]` built at build time from the closed form (sigmoid attention over 2 slots, 64 logits, argmax).
    - len 1: `tab1[t0]`.
    All tables come from the weights (only 3 scalar constants: 64 and 1/√32), so nothing is hard‑coded from this network. Saving: ~0.02 of a forward pass per input (build ≈1.77M ops amortised + ≈150 ops/input), fidelity 1.0.
    
    ## Claims
    Claimed fidelity 1.0 on this network (16,384/16,384 agree; exhaustive checks on lengths 1–2, large random checks on 3–4; the only non‑exact piece is the len‑4 `tab1[max]` shortcut, verified on 2M random inputs and all small‑token cases). Expected fidelity on the second network 0.9998: the len‑1/2/3 paths are an exact re‑derivation from whatever weights are given, so they transfer; only the len‑4 shortcut assumes that network also computes max‑with‑the‑same‑small‑token‑quirk, and any deviation would affect a tiny fraction (≈10⁻⁴ of len‑4 inputs there, e.g. all‑small inputs).
    
    ## Next
    (1) Try to shave the len‑3 cost (~0.011 of reward): e.g. pair tables `VOU_i[t_i]+RU2[t2]` were cost‑neutral; a provable candidate restriction for the argmax, or a cheaper way to detect/handle near‑one‑hot attention, could help. (2) Reduce the len‑2 table build (~0.005) — perhaps a 2‑madd formulation or a build‑time pruning of never‑winning outputs. (3) Make len 4 fully weight‑derived too (exact path only when `max ≤ 5`, via a `cond`) for robustness on the second network at negligible cost. (4) Resubmitting the same entry only moves the reward by ~±0.0005 from sampling, so further submissions should be spent only on genuine cost cuts.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.9816 | 1.0000 | 1.00000 | 0.0161 | 1.00000 | 0.99900 |
| r2s2 | scored | 0.9818 | 1.0000 | 1.00000 | 0.0158 | 1.00000 | 0.99900 |
| r2s3 | scored | 0.9817 | 1.0000 | 1.00000 | 0.0160 | 1.00000 | 0.99900 |

Notes of that round:

    ## What the network does
    The network outputs the **maximum token** of the input for lengths 1, 2 and 4, with one quirk: a maximum ≤ 5 gives 7 and 6 gives 6 (`tab1 = [7,7,7,7,7,7,6,7,8,…,63]`). Length 4 is **exactly** `tab1[max]` on all 16,777,216 inputs (exhaustive numpy check this round). Length 2 is `tab1[max]` on all 4096 pairs except 16, all with 1 ≤ |a−b| ≤ 3 ((4,6)→7, (8,10)→11, (13,10)→7, (14,17)→11, (20,18)→18, (30,28)→31, (32,33)→28, (34,31)→32, (38,37)→26, (42,43)→40, (46,44)→52, (51,49)→52, (52,50)→53 and mirrors) — near-ties where attention splits 0.5–0.7 on the max. Length 3 is **not** max: the query at position 2 attends toward *small* tokens (mean weight 0.27/0.29/0.43 on slots 0/1/2, diffuse), the VOU rows are identity-like (row t peaks at t, and rows 0–5 peak at 7), so the output is a 3-way blend: it equals `tab1[min]` on 64%, is in {a,b,c} on 69%, in tab1{a,b,c}∪{7} on 87%, takes 59 distinct values, and even (t2, min, max) only determines it on 97% — so it needs the exact logits. Exhaustively verified for lengths 1–3 and 16.7M length-4 inputs; very sure.
    
    ## How you found it
    Both weights and outputs. Re-implemented the forward pass in numpy (100% on `network_outputs()`), enumerated all 64³ length-3 and all 64⁴ length-4 inputs, computed purity of candidate groupings and candidate sets for length 3 (all too leaky for the 10× error penalty), listed the 16 length-2 exceptions and found their |a−b| ≤ 3 structure. Then rebuilt the entry with a cheaper weight-derived build and verified it through `lv1.Evaluator` on every length-1/2/3 input and 20k length-4 inputs (0 mismatches).
    
    ## The best entry
    `v8_D3` (region = every input, coverage 1). Build (680k ops, all from weights, only constants 64, 3, 1/√32): QK = QKᵀ/√32, score tables as `Sfull[tq,tk] + EQKP[tq,pk] + PQKE[pq,tk] + PQKP[pq,pk]` (additive position decomposition instead of per-position products), `VOU = V·O·U` once then `EVOU + P[p]·VOU`, `EU + P[p]·U`, `tab1 = argmax(RU0+VOU0)`. Interpretation via `cond` on empty slots: len 1 → `tab1[a]` (3 ops); len 2 → `tab1[max(a,b)]` unless 1 ≤ |a−b| ≤ 3, then exact 2-slot softmax/logits/argmax (~450 ops, taken on 9% of pairs; avg 54 ops); len 3 → exact 3-slot path from tables (593 ops); len 4 → `tab1[max]` (10 ops). Saving: cost 0.0158 of a forward pass (build 0.0032, predict 0.0126, of which length 3 is ~0.011).
    
    ## Claims
    Claimed fidelity 1.0 on this network: exhaustively verified on all length-1/2/3 inputs through the lv1 evaluator and all 16.7M length-4 inputs in numpy (plus 20k via the evaluator); three submissions scored 16384/16384. Expected fidelity on the second network 0.999: lengths 1–3 are exact re-derivations from whatever weights are given; the only assumptions are that its length-2 exceptions also lie within |a−b| ≤ 3 (each missed pair costs 6e-5) and that its length 4 is also `tab1[max]` without exceptions (if it had length-2-like exceptions, ≈0.001 fidelity).
    
    ## Next
    The design is at its floor: the length-3 exact path (256 table reads + 192 madds + 64 adds + 63 argmax) cannot be reduced by 3-D pair tables, unnormalised weights, `take_sum` or 32-dim mixing (all cost-neutral or worse), and no input-derived candidate set is safe. Remaining ideas, all small (<0.001) or non-transferable: (1) hard-coded per-t2 candidate lists for t2 ≤ 15 (≈+0.002, but hard-coded from this network's length-3 outputs, would not transfer); (2) excluding never-produced outputs 0–4 from the length-3 argmax (≈+0.0009, same caveat); (3) a build-time 7×64 table for the close-pair length-2 cases (≈+0.0001). Resubmitting the same entry only moves the reward by ±0.0003.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.9857 | 1.0000 | 1.00000 | 0.0119 | 1.00000 | 0.99900 |
| r3s2 | scored | 0.9855 | 1.0000 | 1.00000 | 0.0121 | 1.00000 | 0.99900 |
| r3s3 | scored | 0.9860 | 1.0000 | 1.00000 | 0.0117 | 1.00000 | 0.99900 |
| r3s4 | scored | 0.9858 | 1.0000 | 1.00000 | 0.0119 | 1.00000 | 0.99900 |

Notes of that round:

    ## What the network does
    The network outputs the **maximum token** for lengths 1, 2 and 4, with the small‑token quirk `tab1 = [7,7,7,7,7,7,6,7,8,…,63]` (max ≤ 5 → 7). Length 4 is exactly `tab1[max]` (exhaustive 16.7M check in round 2, re‑checked on 80k inputs this round through the lv1 evaluator). Length 2 is `tab1[max]` except 16 near‑tie pairs with 1 ≤ |a−b| ≤ 3. **Length 3 is a genuine blend**, not max: the position‑2 query attends diffusely (median max weight 0.56 on the hard cases), the self‑slot value row `V2[t]` is strongly peaked at its own token (gap ≈ 27 to other columns) while the residual term `RU2 = (E+P2)U` is nearly flat (gap ≈ 1.2), so the output is the argmax of a softmax‑weighted mix of three peaked rows plus off‑diagonal structure. It is not in any cheap candidate set (the true output has rank up to 23 in every single table row), outputs 0–4 never occur, and no column is provably dominated at build time. New this round: on 43% of length‑3 inputs one slot's attention dominates enough that a rigorous first‑order bound certifies the argmax of that slot's table row (28% slot 2, 9% slot 1, 8% slot 0); the remaining 57% need the exact 64‑wide logits. All of this is exhaustively verified (every length‑1/2/3 input through the lv1 evaluator, 0 mismatches).
    
    ## How you found it
    Both weights and outputs. Re‑derived the forward pass in numpy (weights are float32; computing in float64 matches the verifier), enumerated all 64³ length‑3 inputs, measured candidate‑set purity (hopeless), tested build‑time column dominance (none), then derived rigorous per‑input certificates: writing logits ∝ (1+r0+r1)·RU2[t2] + V2[t2] + r0·V0[t0] + r1·V1[t1] with r_i = exp(s_i − s_2), the argmax j* of a table row is certified when its margin exceeds r‑weighted sums of "how much the other rows prefer any column over j*" (u‑tables `max_j T[t][j] − T[t][j*]`), all computed from weights at build time. Measured coverage of each certificate exhaustively, checked correctness on every certified input, then rebuilt the entry and verified it through `lv1.Evaluator` on all length‑1/2/3 inputs and 80k length‑4 inputs.
    
    ## The best entry
    `v10` (region = every input; `v9_shortcuts` is the same with a different cond nesting). Build (799k ops, 4 scalar constants: 64, 1/√32, 1.0, −1e30): score tables `Sfull = E·QKᵀ/√32·Eᵀ` plus position terms folded into difference tables `D3_0[t2,t0]`, `D3_1[t2,t1]`, `D2_0[b,a]` (score of slot i minus the self slot); value tables `V0,V1,V2 = (E+P_i)VOU`, `RU1,RU2 = (E+P_i)U`, `A1,A2 = RU+V`, `tab1`; per‑row argmax/margin tables for A2, V0, V1, A1 and u‑tables for V0, V1, V2, RU1, RU2. Interpretation: dispatch on empty slots (`t2==64` then `t1==64`/`t3==64`). Len 1 → `tab1[t0]` (5 ops). Len 4 → `tab1[max]` (8 ops). Len 2 → `r = exp(D2_0[b,a])`; certificate for `argmax A1[b]` (48% of pairs), else certificate for `argmax V0[a]` (46%), else exact `[1+r, 1, r] @ [RU1[b], V1[b], V0[a]]` argmax (6.6% of pairs, 447 ops); avg 49 ops, fully weight‑derived (replaces the hand‑found |a−b|≤3 rule). Len 3 → `r0, r1` from the D tables; certificates for slot 2, then slot 1, then slot 0 (~12 ops each, 43% caught), else exact `[1+r0+r1, 1, r0, r1] @ [RU2[t2], V2[t2], V0[t0], V1[t1]]` + argmax (575 ops); avg 365 ops. Saving: cost ≈ 0.0119 of a forward pass (build 0.0038, predict 0.0081), down from 0.0160; reward 0.9860.
    
    ## Claims
    Claimed fidelity 1.0 on this network: 0 mismatches on all 64 + 4096 + 262,144 length‑1/2/3 inputs and 80k length‑4 inputs via the lv1 evaluator; four submissions scored 16384/16384. Expected fidelity on the second network 0.999: lengths 1–3 are exact re‑derivations from whatever weights are given (the certificates are rigorous bounds, the fallbacks are exact logits), so they transfer regardless of what that network computes; the only assumption is the length‑4 shortcut `tab1[max]` (where `tab1` is itself weight‑derived), which would lose ≈0.001 if that network has length‑2‑like near‑tie exceptions at length 4.
    
    ## Next
    The design is at its floor: the length‑3 fallback (4 row reads + 256 madds + 63 argmax = 575) can only drop to 447 with two 64³ pair tables, whose build (524k ops ≈ 0.0025) exceeds the saving (≈0.0014); tighter certificates (pair‑aware bounds, the `A2 + (r0+r1)·RU2` form) add <1% coverage; sum‑of‑maxima certificates for candidate sets never pass; a second‑max margin for 2‑row paths costs more than it saves. Remaining ideas are all ≤0.0005: hard‑coding the length‑3 argmax to columns 5–63 (+0.0004, not transferable), dropping the length‑2 certificates for the |a−b|≤3 rule (+0.0001, not transferable), cheaper second‑max computations in the build (+0.0001). Resubmitting the same entry moves the reward by ±0.0003 from sampling (observed 0.9855–0.9860), which is now larger than any remaining genuine cut.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.9860) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
