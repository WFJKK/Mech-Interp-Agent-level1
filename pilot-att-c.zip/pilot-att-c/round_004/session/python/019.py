
import numpy as np, math, time
ent = entries['v11']
ev = lv1.Evaluator(ent, weights, 4)
# numpy reference for len 3
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU2 = EU + PU[2]
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out3 = logits.argmax(1)
t = time.time()
mism = 0; n = 0; costs = 0
order = np.random.default_rng(1).permutation(64**3)
for i in order:
    inside, ans, cr, cp = ev.run([t0[i], t1[i], t2[i], 64])
    costs += cp; n += 1
    if ans != out3[i]:
        mism += 1
        if mism < 10: print('MISMATCH', t0[i], t1[i], t2[i], ans, out3[i])
    if time.time() - t > 270: break
print('checked', n, 'mismatches', mism, 'avg cost', costs/n, 'time', time.time()-t)
