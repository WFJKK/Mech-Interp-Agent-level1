
import numpy as np, math, time
ent = entries['v13']
ev = lv1.Evaluator(ent, weights, 4)
gref = graph(); r_entry = gref.entry(interpretation=model.reference(gref, lv1))
rng = np.random.default_rng(11)
inputs = [[a, 64, 64, 64] for a in range(64)] + [[a, b, 64, 64] for a in range(64) for b in range(64)]
inputs += [list(rng.integers(0, 64, 4)) for _ in range(4000)] + [list(rng.integers(0, 8, 4)) for _ in range(300)]
ref, mops = lv1.run_reference(r_entry, weights, 4, inputs)
mism = 0; cost2 = 0
for x, y in zip(inputs, ref):
    inside, ans, cr, cp = ev.run(x)
    if x[2] == 64 and x[1] != 64: cost2 += cp
    if ans != y:
        mism += 1
        if mism < 10: print('MISMATCH', x, ans, y)
print('len1/2/4 n', len(inputs), 'mismatches', mism, 'len2 avg cost', cost2/4096)
# len 3 exhaustive vs reference
t = time.time()
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
X3 = np.stack([t0, t1, t2, np.full(t0.shape, 64)], axis=1)
ref3 = np.concatenate([np.asarray(lv1.run_reference(r_entry, weights, 4, X3[i:i+32768].tolist())[0]) for i in range(0, len(X3), 32768)])
print('ref3 time', time.time()-t)
mism = 0; n = 0; cost = 0
for i in range(len(X3)):
    inside, ans, cr, cp = ev.run(X3[i])
    cost += cp; n += 1
    if ans != ref3[i]:
        mism += 1
        if mism < 10: print('MISMATCH3', X3[i], ans, ref3[i])
    if time.time() - t > 280: break
print('len3 checked', n, 'mismatches', mism, 'avg cost', cost/n, time.time()-t)
