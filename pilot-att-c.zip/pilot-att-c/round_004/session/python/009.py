
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1)
uV0, uV1, uV2, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU2)
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
fb = ~(c2 | c1 | c0)
f = fb; N = f.sum(); L = logits[f]
LB = np.maximum.reduce([L[np.arange(N), k[f]] for k in [j2,j1,j0]])
def ub_groups(perm, G, rowsets):
    # rowsets: list of (rowtable_perm, weight) ; returns UB per group (N, 64/G)
    n = 64//G
    UB = np.zeros((N, n))
    for R, w in rowsets:
        UB += w[:,None] * R.reshape(N, n, G).max(2)
    return UB
def scheme(perm, top_n, pairmode='A2'):
    # rows under permutation
    Rp = lambda T, t: T[:, perm][t[f]]
    if pairmode == 'A2':
        rowsets = [(Rp(A2,t2), np.ones(N)), (Rp(RU2,t2), (r0+r1)[f]), (Rp(V0,t0), r0[f]), (Rp(V1,t1), r1[f])]
    else:
        rowsets = [(Rp(RU2,t2), c[f]), (Rp(V2,t2), np.ones(N)), (Rp(V0,t0), r0[f]), (Rp(V1,t1), r1[f])]
    G = 64 // top_n
    UB = ub_groups(perm, G, rowsets)
    S = UB >= LB[:,None]
    ns = S.sum(1)
    cost = np.zeros(N)
    top_cost = 4*top_n + 4*top_n + top_n + (top_n-1) + 15
    cost += top_cost
    # |S|>=2: exact over union: 9*|S|*G + 5
    multi = ns >= 2
    cost[multi] += 9*ns[multi]*G + 5
    # |S|==1: binary descent inside the group
    act = ns == 1
    off = S.argmax(1) * G
    g = G
    d = 0
    while g >= 2:
        d += 1; h = g//2
        cost[act] += 23
        UBL = np.zeros(N); UBR = np.zeros(N)
        for R, w in rowsets:
            idx = off[:,None] + np.arange(h)[None,:]
            UBL += w * np.take_along_axis(R, idx, 1).max(1)
            UBR += w * np.take_along_axis(R, idx+h, 1).max(1)
        sL = UBL >= LB; sR = UBR >= LB
        both = act & sL & sR
        cost[both] += 9*g + 1
        act &= ~both
        off = np.where(act & sR & ~sL, off + h, off)
        g = h
    cost[act] += 3
    return cost.mean(), np.bincount(ns, minlength=top_n+1)/N
ident = np.arange(64)
rng = np.random.default_rng(0)
for top_n in [2, 4, 8, 16]:
    print('top', top_n, 'ident A2', scheme(ident, top_n), 'plain', scheme(ident, top_n, 'plain')[0])
for i in range(3):
    perm = rng.permutation(64)
    print('rand', [round(scheme(perm, n)[0],1) for n in [2,4,8]])
# bit-reversal / interleave
perm = np.array(sorted(range(64), key=lambda x: int(format(x,'06b')[::-1],2)))
print('bitrev', [round(scheme(perm, n)[0],1) for n in [2,4,8]])
