
X, Y, ops = no
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
m3 = (X[:,2] != 64) & (X[:,3] == 64)
idx = X[m3,0]*4096 + X[m3,1]*64 + X[m3,2]
print('len3 agree', (out[idx] == Y[m3]).mean(), m3.sum())
# certificates
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
print('cert rates', c2.mean(), (~c2 & c1).mean(), (~c2 & ~c1 & c0).mean())
caught = c2 | c1 | c0
print('caught', caught.mean(), 'correct', (np.where(c2, j2, np.where(c1, j1, j0))[caught] == out[caught]).all())
fb = ~caught
print('fallback count', fb.sum())
# group pruning test
def group_test(G, cands):
    n = 64 // G
    M = lambda T: T.reshape(64, n, G).max(2)
    MRU2, MV2, MV0, MV1 = M(RU2), M(V2), M(V0), M(V1)
    f = fb
    UB = c[f,None]*MRU2[t2[f]] + MV2[t2[f]] + r0[f,None]*MV0[t0[f]] + r1[f,None]*MV1[t1[f]]
    LB = np.full(f.sum(), -1e30)
    for k in cands:
        kk = k[f]
        LB = np.maximum(LB, logits[f][np.arange(f.sum()), kk])
    surv = (UB > LB).sum(1)
    return (surv == 1).mean(), (surv <= 2).mean(), (surv<=3).mean()
for G in [4, 8, 16, 32]:
    print(G, 'cands j2', group_test(G, [j2]), 'j2,j1,j0', group_test(G, [j2, j1, j0]), 'true', group_test(G, [out]))
