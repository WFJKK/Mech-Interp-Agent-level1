
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
self1 = diag + EQKP[:,1] + PQKE[1] + PQKP[1,1]
D2_0 = (Sfull + PQKE[1][None,:]) + (EQKP[:,0] + PQKP[1,0] - self1)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU1, RU2 = EU + PU[1], EU + PU[2]
A1, A2 = RU1 + V1, RU2 + V2
tab1 = np.argmax(EU + PU[0] + V0, axis=1)
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1); amA1, mA1 = margin(A1)
uV0, uV1, uV2, uRU1, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU1), utab(RU2)

# all len-3 inputs
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
# verify against network_outputs
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
