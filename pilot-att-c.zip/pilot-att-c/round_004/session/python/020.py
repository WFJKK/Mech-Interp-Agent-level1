
import numpy as np, math, time, inspect, collections
ent = entries['v11']
cnt = collections.Counter(n['op'] for n in ent['nodes'])
print(cnt)
consts = [n for n in ent['nodes'] if n['op']=='const']
print(consts)
print(inspect.signature(lv1.run_reference), (lv1.run_reference.__doc__ or '')[:300])
