
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
self1 = diag + EQKP[:,1] + PQKE[1] + PQKP[1,1]
D2_0 = (Sfull + PQKE[1][None,:]) + (EQKP[:,0] + PQKP[1,0] - self1)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU1, RU2 = EU + PU[1], EU + PU[2]; A1, A2 = RU1+V1, RU2 + V2
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1); amA1, mA1 = margin(A1)
uV0, uV1, uV2, uRU2, uRU1 = utab(V0), utab(V1), utab(V2), utab(RU2), utab(RU1)
# ---- len 2
a, b = np.meshgrid(np.arange(64), np.arange(64), indexing='ij'); a, b = a.ravel(), b.ravel()
r = np.exp(D2_0[b, a])
L2 = (1+r)[:,None]*RU1[b] + V1[b] + r[:,None]*V0[a]
out2 = L2.argmax(1)
jA = amA1[b]; cA = r*(uRU1[b,jA] + uV0[a,jA]) < mA1[b]
jB = amV0[a]; cB = r*mV0[a] > (1+r)*uRU1[b,jB] + uV1[b,jB]
fb2 = ~(cA | cB); N2 = fb2.sum(); print('len2 fallback', N2, N2/4096)
f = fb2
LB = np.maximum(L2[f][np.arange(N2), jA[f]], L2[f][np.arange(N2), jB[f]]) - 1e-6
rows = [(A1[b[f]], np.ones(N2)), (RU1[b[f]], r[f]), (V0[a[f]], r[f])]
def ubg(G):
    n = 64//G; UB = np.zeros((N2, n))
    for R, w in rows: UB += w[:,None]*R.reshape(N2, n, G).max(2)
    return UB
S4 = ubg(16) >= LB[:,None]; ns4 = S4.sum(1)
S16 = ubg(4) >= LB[:,None]
Sin = (S16.reshape(N2,4,4) & S4[:,:,None]).reshape(N2,16); nsin = Sin.sum(1)
print('len2 ns4 hist', np.bincount(ns4, minlength=5)/N2, 'single-sub rate when ns4==1', (nsin[ns4==1]==1).mean())
ex = {1:111, 2:223, 3:335, 4:447}
cost2 = 12 + 35 + np.where(ns4==1, 35 + np.where(nsin==1, 3*4+12+3+3, 111), np.array([ex[n] for n in ns4]))
print('len2 fallback expected cost', cost2.mean(), 'vs 447; per-input saving', (447-cost2.mean())*N2/4096*0.25)
# ---- len 3 pair-eighths refinement
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
fb = ~(c2 | c1 | c0); f = fb; N = f.sum(); L = logits[f]
LB = np.maximum.reduce([L[np.arange(N), k[f]] for k in [j2,j1,j0]]) - 1e-6
rows = [(A2[t2[f]], np.ones(N)), (RU2[t2[f]], (r0+r1)[f]), (V0[t0[f]], r0[f]), (V1[t1[f]], r1[f])]
def ubg3(G):
    n = 64//G; UB = np.zeros((N, n))
    for R, w in rows: UB += w[:,None]*R.reshape(N, n, G).max(2)
    return UB
S4 = ubg3(16) >= LB[:,None]; ns4 = S4.sum(1)
S8 = ubg3(8) >= LB[:,None]
S8in = (S8.reshape(N,4,2) & S4[:,:,None]).reshape(N,8); ns8in = S8in.sum(1)
for n in [2,3]:
    m = ns4 == n
    print('ns4 ==', n, 'frac', m.mean(), 'eighth survivors hist', np.bincount(ns8in[m], minlength=7)/m.sum())
# also subgroup-of-4 within pair (8 subgroups)
S16 = ubg3(4) >= LB[:,None]
S16in = (S16.reshape(N,4,4) & S4[:,:,None]).reshape(N,16); ns16in = S16in.sum(1)
m = ns4 == 2
print('pair: sub4 survivors hist', np.bincount(ns16in[m], minlength=9)/m.sum())
