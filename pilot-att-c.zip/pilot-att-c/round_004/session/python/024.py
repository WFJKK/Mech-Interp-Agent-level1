
import numpy as np, math, time
g = graph()
E = g.weight('embed')[:64]
t = g.token(0)
r = lv1.exp(E[t, 0])
w = lv1.stack([1.0, r, r])
M = lv1.stack([E[:, 0], E[:, 1], E[:, 2]])
try:
    y = w @ M
    print('1d matmul ok', y.shape)
except Exception as ex:
    print('1d matmul fail', ex)
R = lv1.stack([E, E * 2.0], axis=0).reshape(2, 64, 4, 16)
try:
    z = R[g.const(1), t, g.const(2)]
    print('3-gather ok', z.shape)
except Exception as ex:
    print('3-gather fail', ex)
S = lv1.stack([r > 0.5, r > 1.0, r > 2.0])
try:
    print('bool sum', S.sum().value, S.sum().value.dtype, 'argmax', S.argmax().value)
except Exception as ex:
    print('bool sum fail', ex)
ent = g.entry(interpretation=lv1.cast(y[0], 'int'))
print(len(ent['nodes']), [n['op'] for n in ent['nodes']])
m = measure(ent); print(m['r'], m['predict_ops']/16384)
