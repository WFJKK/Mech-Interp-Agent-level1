
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
self1 = diag + EQKP[:,1] + PQKE[1] + PQKP[1,1]
D2_0 = (Sfull + PQKE[1][None,:]) + (EQKP[:,0] + PQKP[1,0] - self1)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU1, RU2 = EU + PU[1], EU + PU[2]
A1, A2 = RU1 + V1, RU2 + V2
tab1 = np.argmax(EU + PU[0] + V0, axis=1)
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1); amA1, mA1 = margin(A1)
uV0, uV1, uV2, uRU1, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU1), utab(RU2)
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
no = network_outputs()
X, Y, ops = no
X = np.asarray(X); Y = np.asarray(Y)
m3 = (X[:,2] != 64) & (X[:,3] == 64)
idx = X[m3,0]*4096 + X[m3,1]*64 + X[m3,2]
print('len3 agree', (out[idx] == Y[m3]).mean(), m3.sum())
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
print('cert rates', c2.mean(), (~c2 & c1).mean(), (~c2 & ~c1 & c0).mean())
caught = c2 | c1 | c0
print('caught', caught.mean(), 'correct', (np.where(c2, j2, np.where(c1, j1, j0))[caught] == out[caught]).all())
fb = ~caught
print('fallback count', fb.sum())
def group_test(G, cands):
    n = 64 // G
    M = lambda T: T.reshape(64, n, G).max(2)
    MRU2, MV2, MV0, MV1 = M(RU2), M(V2), M(V0), M(V1)
    f = fb
    UB = c[f,None]*MRU2[t2[f]] + MV2[t2[f]] + r0[f,None]*MV0[t0[f]] + r1[f,None]*MV1[t1[f]]
    LB = np.full(f.sum(), -1e30)
    for k in cands:
        kk = k[f]
        LB = np.maximum(LB, logits[f][np.arange(f.sum()), kk])
    surv = (UB > LB).sum(1)
    return (surv == 1).mean(), (surv <= 2).mean(), (surv<=3).mean()
for G in [4, 8, 16, 32]:
    print(G, 'cands j2', group_test(G, [j2]), 'j2,j1,j0', group_test(G, [j2, j1, j0]), 'true', group_test(G, [out]))
