
import json
e = entries['best']
for i, n in enumerate(e['nodes']):
    s = json.dumps(n)
    print(i, s[:170])
print('predict', e['predict'], 'rule', e['rule'])
