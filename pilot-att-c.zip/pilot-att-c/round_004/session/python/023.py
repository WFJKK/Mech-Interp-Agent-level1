
import numpy as np, math, time
# quick API tests: 1-D @ 2-D matmul, 3-index gather with const
g = graph()
E = g.weight('embed')[:64]
w = lv1.stack([1.0, 2.0, 3.0])
M = lv1.stack([E[:, 0], E[:, 1], E[:, 2]])
try:
    y = w @ M
    print('1d matmul ok', y.shape, y.value[:3])
except Exception as ex:
    print('1d matmul fail', ex)
R = lv1.stack([E, E * 2.0], axis=0).reshape(2, 64, 4, 16)
t = g.token(0)
try:
    z = R[g.const(1), t, g.const(2)]
    print('3-gather ok', z.shape)
except Exception as ex:
    print('3-gather fail', ex)
ent = g.entry(interpretation=lv1.cast(y[0], 'int'))
print(len(ent['nodes']), [n['op'] for n in ent['nodes']])
