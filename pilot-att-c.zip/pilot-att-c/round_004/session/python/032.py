
ent = entries['v13']
print(len(ent['nodes']), ent['rule'])
m = measure(ent)
print({k: m[k] for k in ['n_agree','n_in_region','cost','r','b','reward']})
