
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
for name in ['concat', 'stack', 'take', 'cond', 'where', 'gather']:
    fn = getattr(lv1, name, None)
    if fn is not None:
        try:
            print(name, inspect.signature(fn), (fn.__doc__ or '')[:300])
        except Exception as ex:
            print(name, ex)
G = lv1.Graph
print([n for n in dir(G) if not n.startswith('_')])
src = inspect.getsource(lv1)
i = src.find('def __getitem__')
print(src[i:i+1500])
