
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1)
uV0, uV1, uV2, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU2)
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
fb = ~(c2 | c1 | c0)
f = fb; N = f.sum(); L = logits[f]
rows = [RU2[t2[f]], V2[t2[f]], V0[t0[f]], V1[t1[f]]]
wts = [c[f], np.ones(N), r0[f], r1[f]]
def simulate(cands, slack=0.0):
    LB = np.full(N, -1e30)
    for k in cands: LB = np.maximum(LB, L[np.arange(N), k[f]])
    LB = LB - slack
    off = np.zeros(N, dtype=int); G = 64
    active = np.ones(N, dtype=bool)
    stop_level = np.full(N, -1); pred = np.full(N, -1)
    d = 0
    while G >= 2:
        d += 1; h = G // 2
        ar = np.arange(N)
        # UB of halves
        UBL = np.zeros(N); UBR = np.zeros(N)
        for R, w in zip(rows, wts):
            idx = off[:,None] + np.arange(h)[None,:]
            UBL += w * np.take_along_axis(R, idx, 1).max(1)
            UBR += w * np.take_along_axis(R, idx + h, 1).max(1)
        sL = UBL >= LB; sR = UBR >= LB
        both = sL & sR & active
        # stop: exact over current group
        idx = off[:,None] + np.arange(G)[None,:]
        ex = np.take_along_axis(L, idx, 1).argmax(1) + off
        pred[both] = ex[both]; stop_level[both] = d; active &= ~both
        assert (sL | sR)[active].all()
        off = np.where(active & sR & ~sL, off + h, off)
        G = h
    # leaves: active ones have a single column
    pred[active] = off[active]; stop_level[active] = 7
    return stop_level, pred
for name, cands in [('j2j1j0', [j2,j1,j0]), ('+toks', [j2,j1,j0,t0,t1,t2]), ('true', [out])]:
    sl, pred = simulate(cands)
    ok = (pred == out[f]).all()
    hist = np.bincount(sl, minlength=8)[1:]
    # cost model
    costs = {1: 575, 2: 9*32+1, 3: 9*16+1, 4: 9*8+1, 5: 9*4+1, 6: 9*2+1, 7: 3}
    per_level = 23
    exp_cost = sum(hist[d-1] * (per_level*d + costs[d]) for d in range(1,8)) / N
    print(name, 'correct', ok, 'stop hist', hist / N, 'exp cost', exp_cost)
