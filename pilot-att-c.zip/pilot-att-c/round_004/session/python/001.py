
import json, numpy as np
print(info.keys() if hasattr(info,'keys') else info)
print(list(entries.keys()))
e = entries['best']
m = measure(e)
print(m)
g, pred, rule = lv1.Graph.load(e, weights, info['sizes']['n_ctx'] if 'sizes' in info else 4)
print(type(g), len(e.get('nodes', [])) if isinstance(e, dict) else None)
print(e.keys() if isinstance(e, dict) else type(e))
