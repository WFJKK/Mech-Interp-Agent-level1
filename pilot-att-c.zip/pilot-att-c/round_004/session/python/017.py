
import numpy as np, math, time

def build(len2_prune=False):
    g = graph()
    embed, pos = g.weight('embed'), g.weight('pos')
    E = embed[:64]; P = pos[:3]
    Q, K, Vw, O, U = g.weight('query'), g.weight('key'), g.weight('value'), g.weight('out'), g.weight('unembed')
    QK = (Q @ K.T) * (1/math.sqrt(32))
    EQK = E @ QK
    Sfull = EQK @ E.T
    EQKP = EQK @ P.T
    PQK = P @ QK
    PQKE = PQK @ E.T
    PQKP = PQK @ P.T
    diag = (EQK * E).sum(axis=1)
    # len3 (query pos 2)
    S2 = Sfull + PQKE[2].reshape(1, 64)
    self2 = diag + EQKP[:, 2] + PQKE[2] + PQKP[2, 2]
    D3_0 = S2 + (EQKP[:, 0] + PQKP[2, 0] - self2).reshape(64, 1)
    D3_1 = S2 + (EQKP[:, 1] + PQKP[2, 1] - self2).reshape(64, 1)
    # len2 (query pos 1)
    S1 = Sfull + PQKE[1].reshape(1, 64)
    self1 = diag + EQKP[:, 1] + PQKE[1] + PQKP[1, 1]
    D2_0 = S1 + (EQKP[:, 0] + PQKP[1, 0] - self1).reshape(64, 1)
    VOU = (Vw @ O) @ U
    EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
    V0 = EVOU + PVOU[0].reshape(1, 64)
    V1 = EVOU + PVOU[1].reshape(1, 64)
    V2 = EVOU + PVOU[2].reshape(1, 64)
    RU1 = EU + PU[1].reshape(1, 64)
    RU2 = EU + PU[2].reshape(1, 64)
    A1 = RU1 + V1
    A2 = RU2 + V2
    RU0 = EU + PU[0].reshape(1, 64)
    tab1 = (RU0 + V0).argmax(axis=1)
    ar64 = g.arange(64).reshape(1, 64)
    NEG = -1e30
    def margin(T):
        top = T.max(axis=1); am = T.argmax(axis=1)
        T2 = lv1.where(ar64 == am.reshape(64, 1), NEG, T)
        return am, top, top - T2.max(axis=1)
    amA2, maxA2, mA2 = margin(A2)
    amV0, maxV0, mV0 = margin(V0)
    amV1, maxV1, mV1 = margin(V1)
    amA1, maxA1, mA1 = margin(A1)
    uV0 = maxV0.reshape(64, 1) - V0
    uV1 = maxV1.reshape(64, 1) - V1
    maxV2 = V2.max(axis=1); uV2 = maxV2.reshape(64, 1) - V2
    maxRU2 = RU2.max(axis=1); uRU2 = maxRU2.reshape(64, 1) - RU2
    maxRU1 = RU1.max(axis=1); uRU1 = maxRU1.reshape(64, 1) - RU1
    # ---- new tables for the len-3 group pruning
    rows3 = [A2, RU2, V0, V1]
    M4 = [T.reshape(64, 4, 16).max(axis=2) for T in rows3]            # (64,4)
    M16 = [T.reshape(64, 16, 4).max(axis=2).reshape(64, 4, 4) for T in rows3]  # (64,4,4)
    colsf = lv1.cast(g.arange(64), 'float').reshape(1, 64) + (E[:, :1] * 0.0)   # (64,64) column ids
    R5 = lv1.stack(rows3 + [colsf], axis=0)                           # (5,64,64)
    Rq = [R5[:, :, 16*i:16*i+16] for i in range(4)]
    pairs = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
    Rpair = lv1.stack([lv1.concat([Rq[a], Rq[b]], axis=2) for a, b in pairs], axis=2)   # (5,64,6,32)
    Rtri = lv1.stack([lv1.concat([Rq[i] for i in range(4) if i != m], axis=2) for m in range(4)], axis=2)  # (5,64,4,48)
    R5_16 = R5.reshape(5, 64, 4, 16)
    R5_4 = R5.reshape(5, 64, 16, 4)
    # ---- per input
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    one = 1.0
    # len 1 / len 4
    p1 = tab1[t0]
    p4 = tab1[lv1.maximum(lv1.maximum(t0, t1), lv1.maximum(t2, t3))]
    # len 2
    r = lv1.exp(D2_0[t1, t0])
    jA = amA1[t1]
    certA = r * (uRU1[t1, jA] + uV0[t0, jA]) < mA1[t1]
    jB = amV0[t0]
    uB = mV0[t0]
    certB = r * uB > (one + r) * uRU1[t1, jB] + uV1[t1, jB]
    w2 = lv1.stack([one + r, one, r]).reshape(1, 3)
    rows2 = lv1.stack([RU1[t1], V1[t1], V0[t0]])
    p2full = (w2 @ rows2).reshape(64).argmax()
    p2 = lv1.cond(certA, jA, lv1.cond(certB, jB, p2full))
    # len 3
    r0 = lv1.exp(D3_0[t2, t0]); r1 = lv1.exp(D3_1[t2, t1]); c = one + r0 + r1
    j2 = amA2[t2]
    u2 = uRU2[t2, j2]
    s2 = r0 * (u2 + uV0[t0, j2]) + r1 * (u2 + uV1[t1, j2])
    cert2 = s2 < mA2[t2]
    j0 = amV0[t0]
    s0 = c * uRU2[t2, j0] + r1 * uV1[t1, j0] + uV2[t2, j0]
    cert0 = r0 * mV0[t0] > s0
    j1 = amV1[t1]
    s1 = c * uRU2[t2, j1] + r0 * uV0[t0, j1] + uV2[t2, j1]
    cert1 = r1 * mV1[t1] > s1
    # fallback with group pruning
    TOP = c * maxRU2[t2] + maxV2[t2] + r0 * maxV0[t0] + r1 * maxV1[t1]
    lj2 = TOP - (s2 + u2 + uV2[t2, j2])
    lj1 = TOP - s1
    lj0 = TOP - s0
    LB = lv1.maximum(lv1.maximum(lj2, lj1), lj0) - 1e-6
    w = lv1.stack([one, r0 + r1, r0, r1]).reshape(1, 4)
    toks = [t2, t2, t0, t1]
    UB = (w @ lv1.stack([M4[k][toks[k]] for k in range(4)])).reshape(4)
    S = UB >= LB
    ns = S.sum()
    q = S.argmax()
    # single quarter
    UBs = (w @ lv1.stack([M16[k][toks[k], q] for k in range(4)])).reshape(4)
    Ss = UBs >= LB
    nss = Ss.sum()
    s = Ss.argmax()
    gi = q * 4 + s
    ex4 = (w @ lv1.stack([R5_4[k][toks[k], gi] for k in range(4)])).reshape(4).argmax() + gi * 4
    ex16 = (w @ lv1.stack([R5_16[k][toks[k], q] for k in range(4)])).reshape(16).argmax() + q * 16
    p_single = lv1.cond(nss == 1, ex4, ex16)
    # pair
    b = lv1.where(S, g.arange(4), -1).max()
    pidx = q * 2 - (q * (q - 1)) // 2 + b - 1
    loc = (w @ lv1.stack([Rpair[k][toks[k], pidx] for k in range(4)])).reshape(32).argmax()
    p_pair = lv1.cast(Rpair[4][0, pidx, loc], 'int')
    # triple
    m = (~S).argmax()
    loc3 = (w @ lv1.stack([Rtri[k][toks[k], m] for k in range(4)])).reshape(48).argmax()
    p_tri = lv1.cast(Rtri[4][0, m, loc3], 'int')
    # full
    w4 = lv1.stack([c, one, r0, r1]).reshape(1, 4)
    p_full = (w4 @ lv1.stack([RU2[t2], V2[t2], V0[t0], V1[t1]])).reshape(64).argmax()
    p_fb = lv1.cond(ns == 1, p_single, lv1.cond(ns == 2, p_pair, lv1.cond(ns == 3, p_tri, p_full)))
    p3 = lv1.cond(cert2, j2, lv1.cond(cert1, j1, lv1.cond(cert0, j0, p_fb)))
    EMPTY = 64
    pred = lv1.cond(t2 == EMPTY, lv1.cond(t1 == EMPTY, p1, p2), lv1.cond(t3 == EMPTY, p3, p4))
    return g.entry(interpretation=pred)

t = time.time()
ent = build()
print('nodes', len(ent['nodes']), time.time()-t)
m = measure(ent)
print(m)
save_entry('v11', ent)
