
import numpy as np, math, itertools
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1)
uV0, uV1, uV2, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU2)
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
fb = ~(c2 | c1 | c0); f = fb; N = f.sum(); L = logits[f]
LB = np.maximum.reduce([L[np.arange(N), k[f]] for k in [j2,j1,j0]]) - 1e-6
rows = [(A2[t2[f]], np.ones(N)), (RU2[t2[f]], (r0+r1)[f]), (V0[t0[f]], r0[f]), (V1[t1[f]], r1[f])]
# top-2 structure
srt = np.argsort(-L, axis=1)
top1, top2 = srt[:,0], srt[:,1]
d = np.abs(top1 - top2)
print('|top1-top2| quantiles', np.quantile(d, [.1,.25,.5,.75,.9]))
print('top2 is a token', np.mean((top2 == t0[f]) | (top2 == t1[f]) | (top2 == t2[f])), 'top1 is token', np.mean((top1 == t0[f]) | (top1 == t1[f]) | (top1 == t2[f])))
print('top1 hist (first 16)', np.bincount(top1, minlength=64)[:16]/N)
# partition search: contiguous groups with boundaries
def cost_partition(bounds):
    edges = [0] + list(bounds) + [64]
    ng = len(edges) - 1
    UB = np.zeros((N, ng))
    for R, w in rows:
        for gi in range(ng):
            UB[:, gi] += w * R[:, edges[gi]:edges[gi+1]].max(1)
    S = UB >= LB[:,None]
    sizes = np.array([edges[i+1]-edges[i] for i in range(ng)])
    union = (S * sizes[None,:]).sum(1)
    ns = S.sum(1)
    stage = 8*ng + ng + ng - 1 + 15
    return stage + np.where(ns == ng, 575, 9*union + 15).mean()
print('equal quarters', cost_partition([16,32,48]))
best = (1e9, None)
for b1 in range(4, 40, 4):
    for b2 in range(b1+4, 56, 4):
        for b3 in range(b2+4, 64, 4):
            cst = cost_partition([b1,b2,b3])
            if cst < best[0]: best = (cst, (b1,b2,b3))
print('best 4-partition', best)
best5 = (1e9, None)
for bs in itertools.combinations(range(4, 64, 4), 4):
    cst = cost_partition(bs)
    if cst < best5[0]: best5 = (cst, bs)
print('best 5-partition', best5)
print('3-partition', min((cost_partition([b1,b2]), (b1,b2)) for b1 in range(4,60,4) for b2 in range(b1+4,64,4)))
