
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1)
uV0, uV1, uV2, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU2)
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
fb = ~(c2 | c1 | c0)
f = fb; N = f.sum(); L = logits[f]
LB = np.maximum.reduce([L[np.arange(N), k[f]] for k in [j2,j1,j0]]) - 1e-6
rowsets = [(A2[t2[f]], np.ones(N)), (RU2[t2[f]], (r0+r1)[f]), (V0[t0[f]], r0[f]), (V1[t1[f]], r1[f])]
def ub_groups(G):
    n = 64//G
    UB = np.zeros((N, n))
    for R, w in rowsets:
        UB += w[:,None] * R.reshape(N, n, G).max(2)
    return UB
UB4 = ub_groups(16); S4 = UB4 >= LB[:,None]; ns4 = S4.sum(1)
UB16 = ub_groups(4); S16 = UB16 >= LB[:,None]
print('zero-survivor cases', (ns4==0).sum(), (S16.sum(1)==0).sum())
# policy E: 16 subgroup UBs first
ns16 = S16.sum(1)
S4e = S16.reshape(N,4,4).any(2); ns4e = S4e.sum(1)
costE = 19 + 160 + np.where(ns16 == 1, 37, 20 + np.where(ns4e==1, 150, np.where(ns4e==2, 302, np.where(ns4e==3, 435, 575))))
print('E', costE.mean(), 'hist ns16==1', (ns16==1).mean(), 'ns4e hist', np.bincount(ns4e, minlength=5)/N)
# policy F: quarter UBs, then subgroups within survivors
Sin = S16.reshape(N,4,4) & S4[:,:,None]
nsin = Sin.reshape(N,16).sum(1)
sub_stage = {1:45, 2:85, 3:120, 4:160}
exact_union = {1:150, 2:302, 3:435, 4:575}
costF = 19 + 42 + np.array([sub_stage[n] for n in ns4]) + np.where(nsin == 1, 37, np.array([exact_union[n] for n in ns4]))
costA = 19 + 42 + np.array([exact_union[n] for n in ns4])
print('F', costF.mean(), 'A', costA.mean())
for n in range(1,5):
    m = ns4 == n
    print(n, m.mean(), 'single subgroup rate', (nsin[m]==1).mean())
# correctness check of policy F outputs
pred = np.full(N, -1)
# exact over union of surviving quarters
cols = np.repeat(S4, 16, axis=1)
Lm = np.where(cols, L, -np.inf)
pred_union = Lm.argmax(1)
# exact over single subgroup
g = Sin.reshape(N,16).argmax(1)
cols16 = np.repeat(np.eye(16, dtype=bool)[g], 4, axis=1)
pred_sub = np.where(cols16, L, -np.inf).argmax(1)
pred = np.where(nsin == 1, pred_sub, pred_union)
print('F correct', (pred == out[f]).all())
