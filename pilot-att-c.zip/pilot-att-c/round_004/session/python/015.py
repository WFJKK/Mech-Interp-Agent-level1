
import inspect
src = inspect.getsource(lv1)
i = src.find('def __getitem__')
print(src[i+1500:i+4500])
j = src.find('class Evaluator')
print(src[j:j+1500])
