
import numpy as np, math, itertools
W = {k: np.asarray(v, dtype=np.float64) for k, v in weights.items()}
E = W['embed'][:64]; P = W['pos'][:3]
Q, K, V, O, U = W['query'], W['key'], W['value'], W['out'], W['unembed']
QK = Q @ K.T / math.sqrt(32)
EQK = E @ QK
Sfull = EQK @ E.T; EQKP = EQK @ P.T; PQK = P @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P.T
diag = (EQK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2] + PQKP[2,2]
D3_0 = (Sfull + PQKE[2][None,:]) + (EQKP[:,0] + PQKP[2,0] - self2)[:,None]
D3_1 = (Sfull + PQKE[2][None,:]) + (EQKP[:,1] + PQKP[2,1] - self2)[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0, V1, V2 = EVOU + PVOU[0], EVOU + PVOU[1], EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
def margin(T):
    top = T.max(1); am = T.argmax(1)
    T2 = T.copy(); T2[np.arange(64), am] = -1e30
    return am, top - T2.max(1)
def utab(T): return T.max(1)[:,None] - T
amA2, mA2 = margin(A2); amV0, mV0 = margin(V0); amV1, mV1 = margin(V1)
uV0, uV1, uV2, uRU2 = utab(V0), utab(V1), utab(V2), utab(RU2)
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0, t1, t2 = t0.ravel(), t1.ravel(), t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1]); c = 1 + r0 + r1
logits = c[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = logits.argmax(1)
j2 = amA2[t2]; c2 = (r0*(uRU2[t2,j2] + uV0[t0,j2]) + r1*(uRU2[t2,j2] + uV1[t1,j2])) < mA2[t2]
j1 = amV1[t1]; c1 = r1*mV1[t1] > c*uRU2[t2,j1] + r0*uV0[t0,j1] + uV2[t2,j1]
j0 = amV0[t0]; c0 = r0*mV0[t0] > c*uRU2[t2,j0] + r1*uV1[t1,j0] + uV2[t2,j0]
fb = ~(c2 | c1 | c0); f = fb; N = f.sum(); L = logits[f]
LB = np.maximum.reduce([L[np.arange(N), k[f]] for k in [j2,j1,j0]]) - 1e-6
rows = [(A2[t2[f]], np.ones(N)), (RU2[t2[f]], (r0+r1)[f]), (V0[t0[f]], r0[f]), (V1[t1[f]], r1[f])]
def ubg(G):
    n = 64//G; UB = np.zeros((N, n))
    for R, w in rows: UB += w[:,None]*R.reshape(N, n, G).max(2)
    return UB
S8 = ubg(8) >= LB[:,None]
S16 = ubg(4) >= LB[:,None]
S4 = ubg(16) >= LB[:,None]
idx8 = np.where(S8, np.arange(8)[None,:], -1); b8 = idx8.max(1)
a8 = S8.argmax(1); span8 = b8 - a8 + 1
print('eighth span hist', np.bincount(span8, minlength=9)/N)
idx16 = np.where(S16, np.arange(16)[None,:], -1); b16 = idx16.max(1); a16 = S16.argmax(1); span16 = b16 - a16 + 1
print('sub4 span hist', np.bincount(span16, minlength=17)/N)
ns4 = S4.sum(1); S4e = S8.reshape(N,4,2).any(2); ns4e = S4e.sum(1)
quarter_cost = {1:150, 2:302, 3:435, 4:575}
def scheme_span(maxspan):
    cost = np.full(N, 19 + 80.0)
    use = span8 <= maxspan
    cost[use] += 9*8*span8[use] + 8
    rest = ~use
    cost[rest] += 10 + np.array([quarter_cost[n] for n in ns4e[rest]])
    return cost.mean()
for ms in [2,3,4,5]:
    print('span8 scheme maxspan', ms, scheme_span(ms))
# span-based scheme with subgroups of 4 (16 groups): stage 160
def scheme_span16(maxspan):
    cost = np.full(N, 19 + 160.0)
    use = span16 <= maxspan
    cost[use] += 9*4*span16[use] + 8
    rest = ~use
    S4f = S16.reshape(N,4,4).any(2); ns4f = S4f.sum(1)
    cost[rest] += 10 + np.array([quarter_cost[n] for n in ns4f[rest]])
    return cost.mean()
for ms in [3,4,6,8]:
    print('span16 scheme maxspan', ms, scheme_span16(ms))
print('current (quarters + subgroup stage) approx', 19 + 42 + np.mean(np.where(ns4==1, 103, np.array([quarter_cost[n] for n in ns4]))))
