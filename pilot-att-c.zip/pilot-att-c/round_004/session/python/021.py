
import numpy as np, time
ent = entries['v11']
ev = lv1.Evaluator(ent, weights, 4)
rng = np.random.default_rng(7)
inputs = [[a, 64, 64, 64] for a in range(64)] + [[a, b, 64, 64] for a in range(64) for b in range(64)]
inputs += [list(rng.integers(0, 64, 4)) for _ in range(3000)]
inputs += [list(rng.integers(0, 6, 4)) for _ in range(200)]
t = time.time()
ref, model_ops = lv1.run_reference(model, weights, 4, inputs) if False else (None, None)
import inspect
# find how run_reference expects the reference: a dict entry? try model.reference into a graph
gref = graph(); r_entry = gref.entry(interpretation=model.reference(gref, lv1))
ref, mops = lv1.run_reference(r_entry, weights, 4, inputs)
print('ref time', time.time()-t, mops)
mism = 0; cost = 0
for x, y in zip(inputs, ref):
    inside, ans, cr, cp = ev.run(x)
    cost += cp
    if ans != y:
        mism += 1
        if mism < 10: print('MISMATCH', x, ans, y)
print('n', len(inputs), 'mismatches', mism, 'avg cost', cost/len(inputs), time.time()-t)
