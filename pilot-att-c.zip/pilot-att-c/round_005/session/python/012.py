
import numpy as np, time
ev = lv1.Evaluator(entries['best'], weights, 4)
rs = np.random.RandomState(1)
def cost_of(inputs):
    tot=0
    for x in inputs:
        tot += ev.run(x)[3]
    return tot/len(inputs)
l1 = [[a,64,64,64] for a in range(64)]
l2 = [[a,b,64,64] for a in range(64) for b in range(64)]
l3 = [list(rs.randint(0,64,3))+[64] for _ in range(3000)]
l4 = [list(rs.randint(0,64,4)) for _ in range(500)]
t=time.time()
for name, L in [('l1',l1),('l2',l2),('l3',l3),('l4',l4)]:
    print(name, cost_of(L))
print(time.time()-t, ev.build_cost)
