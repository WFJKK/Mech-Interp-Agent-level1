
print(inspect.getsource(lv1.show)[:3000])
print(lv1.PRICES)
