
import numpy as np, time
entry = entries['v14']
gr = graph(); ref_entry = gr.entry(interpretation=model.reference(gr, lv1))
ev = lv1.Evaluator(entry, weights, 4)
rs = np.random.RandomState(1)
def check(inputs):
    refs, _ = lv1.run_reference(ref_entry, weights, 4, inputs)
    bad = []; tot = 0
    for x, rf in zip(inputs, refs):
        ins, ans, cr, cp = ev.run(x)
        tot += cp
        if ans != rf: bad.append((x, ans, rf))
    return tot/len(inputs), bad[:5], len(bad)
t = time.time()
print(check([[a,64,64,64] for a in range(64)]))
print(check([[a,b,64,64] for a in range(64) for b in range(64)]))
print(check([list(rs.randint(0,64,3))+[64] for _ in range(4000)]))
print(check([list(rs.randint(0,64,4)) for _ in range(1000)]))
print(time.time()-t, ev.build_cost)
print(measure(entry))
