
SETUP = r'''
import numpy as np, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
QK = Q @ K.T / np.sqrt(32)
Sfull = E @ QK @ E.T; EQKP = E @ QK @ P.T; PQKE = P @ QK @ E.T; PQKP = P @ QK @ P.T
diag = (E @ QK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2,:] + PQKP[2,2]
D3_0 = Sfull + EQKP[:,0][:,None] + PQKP[2,0] + PQKE[2][None,:] - self2[:,None]
D3_1 = Sfull + EQKP[:,1][:,None] + PQKP[2,1] + PQKE[2][None,:] - self2[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0 = EVOU + PVOU[0]; V1 = EVOU + PVOU[1]; V2 = EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0=t0.ravel(); t1=t1.ravel(); t2=t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1])
Lg = A2[t2] + (r0+r1)[:,None]*RU2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = Lg.argmax(1)
def u(T): return T.max(1)[:,None] - T
def marg(T):
    m = T.max(1); T2 = T.copy(); T2[np.arange(64), T.argmax(1)] = -1e30; return m - T2.max(1)
uRU2, uV0, uV1, uV2 = u(RU2), u(V0), u(V1), u(V2)
mA2, mV0, mV1 = marg(A2), marg(V0), marg(V1)
jA2, jV0, jV1 = A2.argmax(1), V0.argmax(1), V1.argmax(1)
j = jA2[t2]; c2 = r0*(uRU2[t2,j]+uV0[t0,j]) + r1*(uRU2[t2,j]+uV1[t1,j]) < mA2[t2]
j = jV1[t1]; c1 = r1*mV1[t1] > (1+r0+r1)*uRU2[t2,j] + r0*uV0[t0,j] + uV2[t2,j]
j = jV0[t0]; c0 = r0*mV0[t0] > (1+r0+r1)*uRU2[t2,j] + r1*uV1[t1,j] + uV2[t2,j]
cert = c2 | c1 | c0
fall = ~cert
F = np.where(fall)[0]
Wt = np.stack([np.ones_like(r0), r0+r1, r0, r1], 1)
def rows(i): return np.stack([A2[t2[i]], RU2[t2[i]], V0[t0[i]], V1[t1[i]]], 1)
cand = np.stack([jA2[t2], jV1[t1], jV0[t0]], 1)
LB = np.take_along_axis(Lg, cand, 1).max(1) - 1e-6
R = rows(F); w = Wt[F]; lb = LB[F]; n = len(F); LF = Lg[F]; outF = out[F]
gm4 = R.reshape(n,4,4,16).max(3); UB4 = np.einsum('nr,nrg->ng', w, gm4); m4 = UB4 >= lb[:,None]; k4 = m4.sum(1)
gm16 = R.reshape(n,4,16,4).max(3); UB16 = np.einsum('nr,nrg->ng', w, gm16)
candF = cand[F]; cl = np.take_along_axis(LF, candF, 1); bc = candF[np.arange(n), cl.argmax(1)]; qmain = bc//16
m16 = UB16 >= lb[:,None]
m16q = m16.reshape(n,4,4).any(2)
k16main = m16.reshape(n,4,4)[np.arange(n), qmain].sum(1)
'''
exec(SETUP)
cost = np.full(n, 61.0)
for kk in [1,2,3,4]:
    sel = k4==kk
    if kk==1:
        cost[sel] += 45 + np.where(k16main[sel]==1, 37, 150)
    elif kk==2:
        other_alive = (m16q & m4); other_alive[np.arange(n), qmain] = False
        oa = other_alive.sum(1)
        c = np.where(oa[sel]==0, 45 + 45 + np.where(k16main[sel]==1, 37, 150), 45 + 302)
        print('k4=2 other pruned frac', (oa[sel]==0).mean())
        cost[sel] += c
    elif kk==3:
        other_alive = (m16q & m4); other_alive[np.arange(n), qmain] = False
        oa = other_alive.sum(1)
        print('k4=3 other alive dist', np.bincount(oa[sel], minlength=3)/sel.sum())
        c = 90 + np.where(oa[sel]==0, 45 + np.where(k16main[sel]==1, 37, 150), np.where(oa[sel]==1, 302, 435))
        cost[sel] += c
    else:
        cost[sel] += 575
print('P3 mean', cost.mean())
c0 = 61 + np.where(k4==1, 45 + np.where(k16main==1, 37, 150), np.where(k4==2, 302, np.where(k4==3, 435, 575)))
print('P0 mean', c0.mean())
# UB slack diagnostics for k4==2: other quarter's UB - LB, and its true max - LB
sel = k4==2
oq = np.where(m4 & (np.arange(4)[None,:] != qmain[:,None]), UB4, -1e30).argmax(1)
tm = LF.reshape(n,4,16).max(2)[np.arange(n), oq]
print('slack UB-LB percentiles', np.percentile((UB4[np.arange(n), oq]-lb)[sel], [10,25,50,75,90]))
print('true gap LB - truemax percentiles', np.percentile((lb - tm)[sel], [10,25,50,75,90]))
print('w percentiles r0', np.percentile(w[sel,2],[10,50,90]), 'r1', np.percentile(w[sel,3],[10,50,90]))
