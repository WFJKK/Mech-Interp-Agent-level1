
exec(BUILDER.replace("graph(example=[1,2,3,64])", "graph(example=[1,2,3,4])"))
entry, nn = build({})
print('nodes', nn)
save_entry('v14', entry)
ev = lv1.Evaluator(entry, weights, 4)
print('build', ev.build_cost)
import numpy as np, time, inspect
print(inspect.signature(lv1.run_reference))
