
exec(SETUP) if 'SETUP' in dir() else None
