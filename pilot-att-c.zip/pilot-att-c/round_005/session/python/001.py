
import json, time
print(list(entries.keys()))
print(info['sizes'] if 'sizes' in info else info.keys())
t=time.time()
m = measure(entries['best'])
print(m, time.time()-t)
e = entries['best']
s = json.dumps(e)
print(len(s))
print(e.keys() if isinstance(e, dict) else type(e))
