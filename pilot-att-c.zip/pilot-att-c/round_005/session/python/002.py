
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
e = entries['best']
print(e['format'], len(e['nodes']))
print(e['nodes'][:5])
print(e['predict'], e['rule'])
