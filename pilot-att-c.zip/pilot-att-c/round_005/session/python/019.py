
BUILDER = r'''
import numpy as np, math
def build(opts):
    g = graph(example=[1,2,3,64])
    NEG = g.const(-1e30); ONE = g.const(1.0); EPS = g.const(1e-6)
    I = [g.const(i) for i in range(8)]
    C16 = g.const(16); CM1 = g.const(-1); C64 = g.const(64)
    ar4 = g.arange(4); ar8 = g.arange(8); ar16 = g.arange(16); ar64 = g.arange(64)
    E = g.weight("embed")[:64]; P3 = g.weight("pos")[:3]
    Qw, Kw, Vw, Ow, Uw = [g.weight(n) for n in ("query","key","value","out","unembed")]
    QK = (Qw @ Kw.T) * g.const(1/math.sqrt(32))
    EQK = E @ QK
    Sfull = EQK @ E.T
    EQKP = EQK @ P3.T
    PQK = P3 @ QK
    PQKE = PQK @ E.T
    PQKP = PQK @ P3.T
    diag = (EQK * E).sum(1)
    # len 3: query pos 2
    self2 = diag + EQKP[:, 2] + PQKE[2] + PQKP[2, 2]
    col0 = EQKP[:, 0] + PQKP[2, 0] - self2
    col1 = EQKP[:, 1] + PQKP[2, 1] - self2
    base2 = Sfull + PQKE[2].reshape(1, 64)
    D3 = base2.reshape(1, 64, 64) + lv1.stack([col0, col1], 0).reshape(2, 64, 1)
    # len 2: query pos 1
    self1 = diag + EQKP[:, 1] + PQKE[1] + PQKP[1, 1]
    colL = EQKP[:, 0] + PQKP[1, 0] - self1
    D2 = Sfull + PQKE[1].reshape(1, 64) + colL.reshape(64, 1)
    # value tables
    VOU = (Vw @ Ow) @ Uw
    EVOU = E @ VOU; PVOU = P3 @ VOU
    EU = E @ Uw; PU = P3 @ Uw
    Vst = EVOU.reshape(1, 64, 64) + PVOU.reshape(3, 1, 64)     # V0,V1,V2
    RUst = EU.reshape(1, 64, 64) + PU.reshape(3, 1, 64)        # RU0,RU1,RU2
    Ast = RUst + Vst                                          # A0,A1,A2
    tab1 = Ast[0].argmax(1)
    # G rows: 0 A1, 1 A2, 2 V0, 3 V1, 4 RU2, 5 RU1, 6 V2
    G = lv1.concat([Ast[1:3], Vst[0:2], RUst[2:3], RUst[1:2], Vst[2:3]], 0)
    rA1, rA2, rV0, rV1, rRU2, rRU1, rV2 = I[0], I[1], I[2], I[3], I[4], I[5], I[6]
    G6 = G[:6]
    M16 = G6.reshape(6, 64, 16, 4).max(3)          # [6,64,16]
    M16q = M16.reshape(6, 64, 4, 4)                # per quarter 4 subgroups
    M4 = M16q.max(3)                               # [6,64,4]
    rmax6 = M16.max(2)                             # [6,64]
    rmaxV2 = G[6].max(1)                           # [64]
    rmax = lv1.concat([rmax6, rmaxV2.reshape(1, 64)], 0)   # [7,64]
    uG = rmax[2:7].reshape(5, 64, 1) - G[2:7]      # u rows: 0 V0, 1 V1, 2 RU2, 3 RU1, 4 V2
    uV0, uV1, uRU2, uRU1, uV2 = I[0], I[1], I[2], I[3], I[4]
    # margins and argmax for rows 0..3 (A1, A2, V0, V1) via M16
    M = M16[:4]
    gs = M.argmax(2)                               # [4,64]
    oth = lv1.where(ar16.reshape(1, 1, 16) == gs.reshape(4, 64, 1), NEG, M).max(2)   # [4,64]
    flatG = G[:4].reshape(4 * 64 * 64)
    basei = (ar4.reshape(4, 1) * C64 + ar64.reshape(1, 64)) * C64 + gs * I[4]      # [4,64]
    idx = basei.reshape(4, 64, 1) + ar4.reshape(1, 1, 4)                            # [4,64,4]
    vals = flatG[idx.reshape(1024)].reshape(4, 64, 4)
    am_in = vals.argmax(2)                         # [4,64]
    jarg = gs * I[4] + am_in                       # argmax column per row  [4,64]
    sec_in = lv1.where(ar4.reshape(1, 1, 4) == am_in.reshape(4, 64, 1), NEG, vals).max(2)
    marg = rmax[:4] - lv1.maximum(oth, sec_in)     # [4,64]
    mA1, mA2, mV0, mV1 = I[0], I[1], I[2], I[3]
    # triple-of-quarters table for the 3-quarter case: [7,64,4,48], index = missing quarter
    q = [G[:, :, 16*i:16*(i+1)] for i in range(4)]
    Tri = lv1.stack([lv1.concat([q[1], q[2], q[3]], 2), lv1.concat([q[0], q[2], q[3]], 2),
                     lv1.concat([q[0], q[1], q[3]], 2), lv1.concat([q[0], q[1], q[2]], 2)], 2)
    Gq = G.reshape(7, 64, 4, 16)                   # quarters
    Gs = G.reshape(7, 64, 16, 4)                   # subgroups
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    # ---- len 1 / len 4
    out1 = tab1[t0]
    out4 = tab1[lv1.maximum(lv1.maximum(t0, t1), lv1.maximum(t2, t3))]
    # ---- helpers
    def exact_quarter(rows_idx, w, qi):
        # rows_idx: list of (row, token); exact over quarter qi (16 cols)
        R = lv1.stack([Gq[r, t, qi] for r, t in rows_idx], 0)
        return qi * C16 + (w @ R).argmax()
    def exact_two_quarters(rows_idx, w, qa, qb):
        R = lv1.stack([lv1.concat([Gq[r, t, qa], Gq[r, t, qb]], 0) for r, t in rows_idx], 0)
        am = (w @ R).argmax()
        return lv1.where(am < C16, qa * C16 + am, qb * C16 + am - C16)
    def exact_triple(rows_idx, w, miss):
        R = lv1.stack([Tri[r, t, miss] for r, t in rows_idx], 0)
        am = (w @ R).argmax()
        return am + C16 * lv1.cast((am // C16) >= miss, "int")
    def exact_full(rows_idx, w):
        R = lv1.stack([G[r, t] for r, t in rows_idx], 0)
        return (w @ R).argmax()
    def exact_sub(rows_idx, w, sg):
        R = lv1.stack([Gs[r, t, sg] for r, t in rows_idx], 0)
        return sg * I[4] + (w @ R).argmax()
    def exact_two_subs(rows_idx, w, sa, sb):
        R = lv1.stack([lv1.concat([Gs[r, t, sa], Gs[r, t, sb]], 0) for r, t in rows_idx], 0)
        am = (w @ R).argmax()
        return lv1.where(am < I[4], sa * I[4] + am, sb * I[4] + am - I[4])
    # ---- len 2: a=t0, b=t1
    a, b = t0, t1
    r = lv1.exp(D2[b, a]); one_r = ONE + r
    jA = jarg[mA1, b]
    lhsA = r * (uG[uRU1, b, jA] + uG[uV0, a, jA])
    cA = lhsA < marg[mA1, b]
    j0 = jarg[mV0, a]
    rhs0 = one_r * uG[uRU1, b, j0] + uG[uV1, b, j0]
    c0 = r * marg[mV0, a] > rhs0
    top = one_r * rmax[rRU1, b] + rmax[rV1, b] + r * rmax[rV0, a]
    LB2 = lv1.maximum(top - (lhsA + uG[uRU1, b, jA] + uG[uV1, b, jA]), top - rhs0) - EPS
    w2 = lv1.stack([ONE, r, r], 0)
    rows2 = [(rA1, b), (rRU1, b), (rV0, a)]
    UB4 = w2 @ lv1.stack([M4[rr, tt] for rr, tt in rows2], 0)
    m4 = UB4 >= LB2
    k4 = m4.sum(); qa = m4.argmax(); qb = lv1.where(m4, ar4, CM1).max(); miss = m4.argmin()
    fb2 = lv1.cond(k4 == I[1], exact_quarter(rows2, w2, qa),
          lv1.cond(k4 == I[2], exact_two_quarters(rows2, w2, qa, qb),
          lv1.cond(k4 == I[3], exact_triple(rows2, w2, miss), exact_full(rows2, w2))))
    out2 = lv1.cond(cA, jA, lv1.cond(c0, j0, fb2))
    # ---- len 3
    r0 = lv1.exp(D3[I[0], t2, t0]); r1 = lv1.exp(D3[I[1], t2, t1]); s = r0 + r1; one_s = ONE + s
    j2 = jarg[mA2, t2]
    lhs2 = r0 * (uG[uRU2, t2, j2] + uG[uV0, t0, j2]) + r1 * (uG[uRU2, t2, j2] + uG[uV1, t1, j2])
    c2 = lhs2 < marg[mA2, t2]
    j1 = jarg[mV1, t1]
    rhs1 = one_s * uG[uRU2, t2, j1] + r0 * uG[uV0, t0, j1] + uG[uV2, t2, j1]
    c1 = r1 * marg[mV1, t1] > rhs1
    j0b = jarg[mV0, t0]
    rhs0b = one_s * uG[uRU2, t2, j0b] + r1 * uG[uV1, t1, j0b] + uG[uV2, t2, j0b]
    c0b = r0 * marg[mV0, t0] > rhs0b
    top3 = one_s * rmax[rRU2, t2] + rmax[rV2, t2] + r0 * rmax[rV0, t0] + r1 * rmax[rV1, t1]
    LB3 = lv1.maximum(lv1.maximum(top3 - (lhs2 + uG[uRU2, t2, j2] + uG[uV2, t2, j2]), top3 - rhs1), top3 - rhs0b) - EPS
    w3 = lv1.stack([ONE, s, r0, r1], 0)
    rows3 = [(rA2, t2), (rRU2, t2), (rV0, t0), (rV1, t1)]
    UB4b = w3 @ lv1.stack([M4[rr, tt] for rr, tt in rows3], 0)
    m4b = UB4b >= LB3
    k4b = m4b.sum(); qa3 = m4b.argmax(); qb3 = lv1.where(m4b, ar4, CM1).max(); miss3 = m4b.argmin()
    # k4==1: subgroup stage in quarter qa3
    UB16a = w3 @ lv1.stack([M16q[rr, tt, qa3] for rr, tt in rows3], 0)
    m16a = UB16a >= LB3
    sga = qa3 * I[4] + m16a.argmax()
    one_q = lv1.cond(m16a.sum() == I[1], exact_sub(rows3, w3, sga), exact_quarter(rows3, w3, qa3))
    # k4==2: 8-subgroup stage
    if opts.get('two8', True):
        UB8 = w3 @ lv1.stack([lv1.concat([M16q[rr, tt, qa3], M16q[rr, tt, qb3]], 0) for rr, tt in rows3], 0)
        m8 = UB8 >= LB3
        k8 = m8.sum()
        sf = m8.argmax(); sl = lv1.where(m8, ar8, CM1).max()
        sgf = lv1.where(sf < I[4], qa3 * I[4] + sf, qb3 * I[4] + sf - I[4])
        sgl = lv1.where(sl < I[4], qa3 * I[4] + sl, qb3 * I[4] + sl - I[4])
        two_q = lv1.cond(k8 == I[1], exact_sub(rows3, w3, sgf),
                lv1.cond(k8 == I[2], exact_two_subs(rows3, w3, sgf, sgl), exact_two_quarters(rows3, w3, qa3, qb3)))
    else:
        two_q = exact_two_quarters(rows3, w3, qa3, qb3)
    fb3 = lv1.cond(k4b == I[1], one_q,
          lv1.cond(k4b == I[2], two_q,
          lv1.cond(k4b == I[3], exact_triple(rows3, w3, miss3), exact_full(rows3, w3))))
    out3 = lv1.cond(c2, j2, lv1.cond(c1, j1, lv1.cond(c0b, j0b, fb3)))
    # ---- dispatch
    e2 = t2 == C64; e1 = t1 == C64; e3 = t3 == C64
    out = lv1.cond(e2, lv1.cond(e1, out1, out2), lv1.cond(e3, out3, out4))
    entry = g.entry(interpretation=out)
    return entry, len(g.nodes)
'''
exec(BUILDER)
entry, nn = build({})
print('nodes', nn)
save_entry('v14', entry)
ev = lv1.Evaluator(entry, weights, 4)
print('build', ev.build_cost)
import numpy as np, time
rs = np.random.RandomState(1)
def check(inputs):
    bad = 0; tot = 0
    for x in inputs:
        ins, ans, cr, cp = ev.run(x)
        tot += cp
        ref = lv1.run_reference(x, weights, 4) if False else None
        bad += 0
    return tot/len(inputs)
print(inspect.signature(lv1.run_reference))
