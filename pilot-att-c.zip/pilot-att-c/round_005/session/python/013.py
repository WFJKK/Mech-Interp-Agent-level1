
SETUP = open('tmp/setup.py').read() if False else None
import os
SETUP = r'''
import numpy as np, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
QK = Q @ K.T / np.sqrt(32)
Sfull = E @ QK @ E.T; EQKP = E @ QK @ P.T; PQKE = P @ QK @ E.T; PQKP = P @ QK @ P.T
diag = (E @ QK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2,:] + PQKP[2,2]
D3_0 = Sfull + EQKP[:,0][:,None] + PQKP[2,0] + PQKE[2][None,:] - self2[:,None]
D3_1 = Sfull + EQKP[:,1][:,None] + PQKP[2,1] + PQKE[2][None,:] - self2[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0 = EVOU + PVOU[0]; V1 = EVOU + PVOU[1]; V2 = EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0=t0.ravel(); t1=t1.ravel(); t2=t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1])
Lg = A2[t2] + (r0+r1)[:,None]*RU2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = Lg.argmax(1)
def u(T): return T.max(1)[:,None] - T
def marg(T):
    m = T.max(1); T2 = T.copy(); T2[np.arange(64), T.argmax(1)] = -1e30; return m - T2.max(1)
uRU2, uV0, uV1, uV2 = u(RU2), u(V0), u(V1), u(V2)
mA2, mV0, mV1 = marg(A2), marg(V0), marg(V1)
jA2, jV0, jV1 = A2.argmax(1), V0.argmax(1), V1.argmax(1)
j = jA2[t2]; c2 = r0*(uRU2[t2,j]+uV0[t0,j]) + r1*(uRU2[t2,j]+uV1[t1,j]) < mA2[t2]
j = jV1[t1]; c1 = r1*mV1[t1] > (1+r0+r1)*uRU2[t2,j] + r0*uV0[t0,j] + uV2[t2,j]
j = jV0[t0]; c0 = r0*mV0[t0] > (1+r0+r1)*uRU2[t2,j] + r1*uV1[t1,j] + uV2[t2,j]
cert = c2 | c1 | c0
fall = ~cert
F = np.where(fall)[0]
Wt = np.stack([np.ones_like(r0), r0+r1, r0, r1], 1)
def rows(i): return np.stack([A2[t2[i]], RU2[t2[i]], V0[t0[i]], V1[t1[i]]], 1)
cand = np.stack([jA2[t2], jV1[t1], jV0[t0]], 1)
LB = np.take_along_axis(Lg, cand, 1).max(1) - 1e-6
R = rows(F); w = Wt[F]; lb = LB[F]; n = len(F); LF = Lg[F]; outF = out[F]
gm4 = R.reshape(n,4,4,16).max(3); UB4 = np.einsum('nr,nrg->ng', w, gm4); m4 = UB4 >= lb[:,None]; k4 = m4.sum(1)
gm16 = R.reshape(n,4,16,4).max(3); UB16 = np.einsum('nr,nrg->ng', w, gm16)
'''
os.makedirs('tmp', exist_ok=True); open('tmp/setup.py','w').write(SETUP)
exec(SETUP)
# answer among candidates?
inc = (cand[F] == outF[:,None]).any(1)
for kk in [1,2,3,4]:
    sel = k4==kk
    print(kk, 'answer in cands', inc[sel].mean().round(3))
# sequential policy for k4>=2: pick best quarter by UB, exact over it, new LB, re-test others
qa = np.where(m4, UB4, -1e30).argmax(1)
qmax = LF.reshape(n,4,16).max(2)      # true max per quarter
lb2 = np.maximum(lb, qmax[np.arange(n), qa])
m4b = (UB4 >= lb2[:,None]); m4b[np.arange(n), qa] = False
k4b = m4b.sum(1)
for kk in [2,3,4]:
    sel = k4==kk
    print(kk, 'remaining after best quarter exact:', np.bincount(k4b[sel], minlength=4)/sel.sum())
# subgroup within best quarter: how many subgroups survive (using lb) and after exact of best subgroup
UBq = UB16.reshape(n,4,4)[np.arange(n), qa]    # 4 subgroups of best quarter
m16q = UBq >= lb[:,None]; k16q = m16q.sum(1)
for kk in [1,2,3,4]:
    sel = k4==kk
    print(kk, 'k16 in best quarter', np.bincount(k16q[sel], minlength=5)/sel.sum())
