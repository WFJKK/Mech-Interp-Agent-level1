
import inspect
print(inspect.signature(lv1.take), inspect.signature(lv1.cond), inspect.signature(lv1.where), inspect.signature(lv1.stack), inspect.signature(lv1.concat))
src = inspect.getsource(lv1.Graph)
import re
print([l.strip() for l in src.split('\n') if l.strip().startswith('def ')][:60])
