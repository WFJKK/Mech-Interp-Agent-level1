
import inspect
print(inspect.getsource(lv1.Expr.__getitem__))
print(inspect.getsource(lv1.Graph._add))
