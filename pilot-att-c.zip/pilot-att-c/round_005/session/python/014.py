
exec(open('tmp/setup.py').read())
# best candidate column and its quarter
candF = cand[F]; cl = np.take_along_axis(LF, candF, 1); bc = candF[np.arange(n), cl.argmax(1)]; qmain = bc//16
m16 = UB16 >= lb[:,None]   # n x 16
m16q = m16.reshape(n,4,4).any(2)   # quarter survives at subgroup level
k16main = m16.reshape(n,4,4)[np.arange(n), qmain].sum(1)
cost = np.full(n, 61.0)
for kk in [1,2,3,4]:
    sel = k4==kk
    if kk==1:
        cost[sel] += 45 + np.where(k16main[sel]==1, 37, 150)
    elif kk==2:
        other_alive = (m16q & m4); other_alive[np.arange(n), qmain] = False
        oa = other_alive.sum(1)   # 0 or 1
        c = np.where(oa[sel]==0, 45 + 45 + np.where(k16main[sel]==1, 37, 150), 45 + 302)
        print('k4=2 other pruned frac', (oa[sel]==0).mean())
        cost[sel] += c
    elif kk==3:
        other_alive = (m16q & m4); other_alive[np.arange(n), qmain] = False
        oa = other_alive.sum(1)
        print('k4=3 other alive dist', np.bincount(oa[sel], minlength=3)/sel.sum())
        c = 90 + np.where(oa[sel]==0, 45 + np.where(k16main[sel]==1, 37, 150), np.where(oa[sel]==1, 302, 435))
        cost[sel] += c
    else:
        cost[sel] += 575
print('P3 mean', cost.mean())
c0 = 61 + np.where(k4==1, 45 + np.where(k16main==1, 37, 150), np.where(k4==2, 302, np.where(k4==3, 435, 575)))
print('P0 mean', c0.mean())
# what if LB used exact over main quarter's surviving subgroups first (k4=2): then test other quarter's subgroups vs new LB
