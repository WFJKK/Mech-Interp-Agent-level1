
print(lv1.show(entries['best']))
