
print('SETUP' in dir(), 'Lg' in dir())
