
import inspect
print(inspect.getsource(lv1.Evaluator.run)[:3000])
print(inspect.getsource(lv1.measure)[:3500])
