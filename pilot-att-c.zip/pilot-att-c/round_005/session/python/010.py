
SETUP = r'''
import numpy as np, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
QK = Q @ K.T / np.sqrt(32)
Sfull = E @ QK @ E.T; EQKP = E @ QK @ P.T; PQKE = P @ QK @ E.T; PQKP = P @ QK @ P.T
diag = (E @ QK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2,:] + PQKP[2,2]
D3_0 = Sfull + EQKP[:,0][:,None] + PQKP[2,0] + PQKE[2][None,:] - self2[:,None]
D3_1 = Sfull + EQKP[:,1][:,None] + PQKP[2,1] + PQKE[2][None,:] - self2[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0 = EVOU + PVOU[0]; V1 = EVOU + PVOU[1]; V2 = EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0=t0.ravel(); t1=t1.ravel(); t2=t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1])
Lg = A2[t2] + (r0+r1)[:,None]*RU2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = Lg.argmax(1)
def u(T): return T.max(1)[:,None] - T
def marg(T):
    m = T.max(1); T2 = T.copy(); T2[np.arange(64), T.argmax(1)] = -1e30; return m - T2.max(1)
uRU2, uV0, uV1, uV2 = u(RU2), u(V0), u(V1), u(V2)
mA2, mV0, mV1 = marg(A2), marg(V0), marg(V1)
jA2, jV0, jV1 = A2.argmax(1), V0.argmax(1), V1.argmax(1)
j = jA2[t2]; c2 = r0*(uRU2[t2,j]+uV0[t0,j]) + r1*(uRU2[t2,j]+uV1[t1,j]) < mA2[t2]
j = jV1[t1]; c1 = r1*mV1[t1] > (1+r0+r1)*uRU2[t2,j] + r0*uV0[t0,j] + uV2[t2,j]
j = jV0[t0]; c0 = r0*mV0[t0] > (1+r0+r1)*uRU2[t2,j] + r1*uV1[t1,j] + uV2[t2,j]
cert = c2 | c1 | c0
fall = ~cert
F = np.where(fall)[0]
Wt = np.stack([np.ones_like(r0), r0+r1, r0, r1], 1)
def rows(i): return np.stack([A2[t2[i]], RU2[t2[i]], V0[t0[i]], V1[t1[i]]], 1)
cand = np.stack([jA2[t2], jV1[t1], jV0[t0]], 1)
LB = np.take_along_axis(Lg, cand, 1).max(1) - 1e-6
R = rows(F); w = Wt[F]; lb = LB[F]; n = len(F)
'''
exec(SETUP)
# quarter masks
gm4 = R.reshape(n,4,4,16).max(3); UB4 = np.einsum('nr,nrg->ng', w, gm4); m4 = UB4 >= lb[:,None]; k4 = m4.sum(1)
gm16 = R.reshape(n,4,16,4).max(3); UB16 = np.einsum('nr,nrg->ng', w, gm16); m16 = (UB16 >= lb[:,None]) & np.repeat(m4, 4, axis=1); k16 = m16.sum(1)
for kk in [1,2,3,4]:
    sel = k4==kk
    print('k4=',kk, sel.mean().round(3), 'k16 dist', np.bincount(k16[sel], minlength=10)[:10]/sel.sum())
# cost model
def cost_P1():
    c = np.zeros(n)
    base = 19 + 42
    c += base
    for kk in [1,2,3,4]:
        sel = k4==kk
        if kk==1:
            # subgroup stage 45, then 4 cols (37) if k16==1 else 16 cols (150)
            c[sel] += 45 + np.where(k16[sel]==1, 37, 150)
        else:
            G = 4*kk
            stage = 4*G + 4*G + G + (G-1) + (G-1) + (G + G-1) + 6   # reads, madds, ge, sum, argmax(first), where+max(last), misc
            ex = {1: 37+4, 2: 8+32+32+7+6, 3: 33+12+48+48+11+6}
            full = {2: 302, 3: 435, 4: 575}[kk]
            kk16 = k16[sel]
            c[sel] += stage + np.where(kk16==1, ex[1], np.where(kk16==2, ex[2], np.where(kk16==3, ex[3], full)))
    return c
c = cost_P1(); print('P1 mean', c.mean())
# current P0
c0 = 19+42 + np.where(k4==1, 45 + np.where(k16==1, 37, 150), np.where(k4==2, 302, np.where(k4==3, 435, 575)))
print('P0 mean', c0.mean())
