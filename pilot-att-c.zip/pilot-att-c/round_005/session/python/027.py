
import numpy as np, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
QK = Q @ K.T / np.sqrt(32)
Sfull = E @ QK @ E.T; EQKP = E @ QK @ P.T; PQKE = P @ QK @ E.T; PQKP = P @ QK @ P.T
diag = (E @ QK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2,:] + PQKP[2,2]
D3_0 = Sfull + EQKP[:,0][:,None] + PQKP[2,0] + PQKE[2][None,:] - self2[:,None]
D3_1 = Sfull + EQKP[:,1][:,None] + PQKP[2,1] + PQKE[2][None,:] - self2[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0 = EVOU + PVOU[0]; V1 = EVOU + PVOU[1]; V2 = EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0=t0.ravel(); t1=t1.ravel(); t2=t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1])
Lg = A2[t2] + (r0+r1)[:,None]*RU2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = Lg.argmax(1)
entry = entries['v14']
gr = graph(); ref_entry = gr.entry(interpretation=model.reference(gr, lv1))
ev = lv1.Evaluator(entry, weights, 4)
# numpy formula vs lv1 reference on 2000 random len-3
rs = np.random.RandomState(7)
sel = rs.choice(len(t0), 2000, replace=False)
inp = [[int(t0[i]), int(t1[i]), int(t2[i]), 64] for i in sel]
refs, _ = lv1.run_reference(ref_entry, weights, 4, inp)
print('numpy vs reference mismatches:', int((refs != out[sel]).sum()))
t = time.time()
bad = 0; tot = 0; costs = np.zeros(len(t0), dtype=np.int32)
for i in range(len(t0)):
    ins, ans, cr, cp = ev.run([int(t0[i]), int(t1[i]), int(t2[i]), 64])
    costs[i] = cp
    if ans != out[i]:
        bad += 1
        if bad < 5: print('BAD', t0[i], t1[i], t2[i], ans, out[i])
    if time.time() - t > 270: print('timeout at', i); break
print('len3 exhaustive: bad', bad, 'mean cost', costs[:i+1].mean(), 'checked', i+1, time.time()-t)
