
SETUP = r'''
import numpy as np, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
QK = Q @ K.T / np.sqrt(32)
Sfull = E @ QK @ E.T; EQKP = E @ QK @ P.T; PQKE = P @ QK @ E.T; PQKP = P @ QK @ P.T
diag = (E @ QK * E).sum(1)
self2 = diag + EQKP[:,2] + PQKE[2,:] + PQKP[2,2]
D3_0 = Sfull + EQKP[:,0][:,None] + PQKP[2,0] + PQKE[2][None,:] - self2[:,None]
D3_1 = Sfull + EQKP[:,1][:,None] + PQKP[2,1] + PQKE[2][None,:] - self2[:,None]
VOU = V @ O @ U; EVOU = E @ VOU; PVOU = P @ VOU; EU = E @ U; PU = P @ U
V0 = EVOU + PVOU[0]; V1 = EVOU + PVOU[1]; V2 = EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0=t0.ravel(); t1=t1.ravel(); t2=t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1])
Lg = A2[t2] + (r0+r1)[:,None]*RU2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = Lg.argmax(1)
def u(T): return T.max(1)[:,None] - T
def marg(T):
    m = T.max(1); T2 = T.copy(); T2[np.arange(64), T.argmax(1)] = -1e30; return m - T2.max(1)
uRU2, uV0, uV1, uV2 = u(RU2), u(V0), u(V1), u(V2)
mA2, mV0, mV1 = marg(A2), marg(V0), marg(V1)
jA2, jV0, jV1 = A2.argmax(1), V0.argmax(1), V1.argmax(1)
j = jA2[t2]; c2 = r0*(uRU2[t2,j]+uV0[t0,j]) + r1*(uRU2[t2,j]+uV1[t1,j]) < mA2[t2]
j = jV1[t1]; c1 = r1*mV1[t1] > (1+r0+r1)*uRU2[t2,j] + r0*uV0[t0,j] + uV2[t2,j]
j = jV0[t0]; c0 = r0*mV0[t0] > (1+r0+r1)*uRU2[t2,j] + r1*uV1[t1,j] + uV2[t2,j]
cert = c2 | c1 | c0
fall = ~cert
F = np.where(fall)[0]
Wt = np.stack([np.ones_like(r0), r0+r1, r0, r1], 1)   # weights for rows [A2, RU2, V0, V1]
def rows(i):  # 4 x 64 tables for input i (vectorized: returns [n,4,64])
    return np.stack([A2[t2[i]], RU2[t2[i]], V0[t0[i]], V1[t1[i]]], 1)
cand = np.stack([jA2[t2], jV1[t1], jV0[t0]], 1)
LB = np.take_along_axis(Lg, cand, 1).max(1) - 1e-6
'''
exec(SETUP)
print(fall.mean(), len(F), (c2.mean(), c1.mean(), c0.mean()))
# check certificates correct
print((out[c2]==jA2[t2[c2]]).all(), (out[c1]==jV1[t1[c1]]).all(), (out[c0]==jV0[t0[c0]]).all())
# pruning with groups of size gs on fallthrough set
R = rows(F); w = Wt[F]; lb = LB[F]
for gs in [2,4,8,16]:
    gm = R.reshape(len(F),4,64//gs,gs).max(3)
    UB = np.einsum('nr,nrg->ng', w, gm)
    mask = UB >= lb[:,None]
    k = mask.sum(1)
    # check argmax group survives
    ok = mask[np.arange(len(F)), out[F]//gs].all()
    first = mask.argmax(1); last = 15 - mask[:, ::-1].argmax(1) if gs==4 else None
    span = (np.where(mask, np.arange(64//gs), -1).max(1) - first + 1)
    print(gs, ok, np.bincount(k)[:12], 'mean k', k.mean(), 'mean span', span.mean(), np.bincount(span)[:12])
