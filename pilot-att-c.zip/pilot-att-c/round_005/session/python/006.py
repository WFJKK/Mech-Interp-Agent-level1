
import numpy as np, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
QK = Q @ K.T / np.sqrt(32)
Sfull = E @ QK @ E.T          # [tq, tk]
EQKP = E @ QK @ P.T           # [tq, pk]
PQKE = P @ QK @ E.T           # [pq, tk]
PQKP = P @ QK @ P.T
diag = (E @ QK * E).sum(1)    # self score token part
def score(tq, pq, tk, pk):  # generic
    return Sfull[tq, tk] + EQKP[tq, pk] + PQKE[pq, tk] + PQKP[pq, pk]
# len3: query pos 2, token t2. D3_0[t2,t0] = score(t2,2,t0,0) - score(t2,2,t2,2)
self2 = diag + EQKP[:,2] + PQKE[2,:] + PQKP[2,2]       # [t2]
D3_0 = Sfull + PQKE[2][None,:]*0 + EQKP[:,0][:,None] + PQKP[2,0] + PQKE[2][None,:] - self2[:,None]
D3_1 = Sfull + EQKP[:,1][:,None] + PQKP[2,1] + PQKE[2][None,:] - self2[:,None]
VOU = V @ O @ U
EVOU = E @ VOU; PVOU = P @ VOU
EU = E @ U; PU = P @ U
V0 = EVOU + PVOU[0]; V1 = EVOU + PVOU[1]; V2 = EVOU + PVOU[2]
RU2 = EU + PU[2]; A2 = RU2 + V2
tab1 = np.argmax(EU + PU[0] + V0, axis=1)
# full forward check in numpy
def forward(toks):
    toks = np.asarray(toks); n = len(toks)
    x = E[toks] + P[:n]
    read = x[n-1]
    q = read @ Q / np.sqrt(32)
    s = (x @ K) @ q
    w = np.exp(s - s.max()); w /= w.sum()
    h = w @ (x @ V)
    return np.argmax((read + h @ O) @ U)
# all len3
t0, t1, t2 = np.meshgrid(np.arange(64), np.arange(64), np.arange(64), indexing='ij')
t0=t0.ravel(); t1=t1.ravel(); t2=t2.ravel()
r0 = np.exp(D3_0[t2, t0]); r1 = np.exp(D3_1[t2, t1])
L = A2[t2] + (r0+r1)[:,None]*RU2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = L.argmax(1)
# verify against forward on sample
idx = np.random.RandomState(0).choice(len(t0), 300, replace=False)
print(all(forward([t0[i],t1[i],t2[i]])==out[i] for i in idx))
# verify against network_outputs
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
