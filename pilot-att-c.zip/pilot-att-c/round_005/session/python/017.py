
import inspect
src = inspect.getsource(lv1.Expr)
print([l.strip() for l in src.split('\n') if l.strip().startswith('def ')])
print(inspect.getsource(lv1.Graph.wrap))
print(inspect.getsource(lv1.Graph.const)[:800])
