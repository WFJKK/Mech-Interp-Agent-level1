
BUILDER = r'''
import numpy as np, math
def build(opts):
    g = graph(example=[1,2,3,4])
    NEG = g.const(-1e30); ONE = g.const(1.0); EPS = g.const(1e-6)
    I = [g.const(i) for i in range(8)]
    C16 = g.const(16); CM1 = g.const(-1); C64 = g.const(64)
    ar4 = g.arange(4); ar8 = g.arange(8); ar16 = g.arange(16); ar64 = g.arange(64)
    E = g.weight("embed")[:64]; P3 = g.weight("pos")[:3]
    Qw, Kw, Vw, Ow, Uw = [g.weight(n) for n in ("query","key","value","out","unembed")]
    QK = (Qw @ Kw.T) * g.const(1/math.sqrt(32))
    EQK = E @ QK
    Sfull = EQK @ E.T                       # [tq, tk]
    EQKP = EQK @ P3.T                       # [tq, pk]
    PQK = P3 @ QK
    PQKE = PQK @ E.T                        # [pq, tk]
    PQKP = PQK @ P3.T                       # [pq, pk]
    diag = (EQK * E).sum(1)                 # [t]
    selfP = (PQK * P3).sum(1)               # [p] = PQKP[p,p]
    EQKPt = EQKP.T                          # [pk, tq]
    # colsAll[pq, pk, t] = EQKP[t,pk] + PQKP[pq,pk] - diag[t] - EQKP[t,pq] - PQKE[pq,t] - PQKP[pq,pq]
    colsAll = (EQKPt.reshape(1, 3, 64) + PQKP.reshape(3, 3, 1)) - (diag.reshape(1, 1, 64) + EQKPt.reshape(3, 1, 64) + PQKE.reshape(3, 1, 64) + selfP.reshape(3, 1, 1))
    # D[pq-1, pk, tq, tk] for pq in {1,2}, pk in {0,1}
    D = (Sfull.reshape(1, 1, 64, 64) + PQKE[1:3].reshape(2, 1, 1, 64)) + colsAll[1:3, 0:2].reshape(2, 2, 64, 1)
    VOU = (Vw @ Ow) @ Uw
    EVOU = E @ VOU; PVOU = P3 @ VOU
    EU = E @ Uw; PU = P3 @ Uw
    Vst = EVOU.reshape(1, 64, 64) + PVOU.reshape(3, 1, 64)
    RUst = EU.reshape(1, 64, 64) + PU.reshape(3, 1, 64)
    Ast = RUst + Vst
    tab1 = Ast[0].argmax(1)
    # G rows: 0 A1, 1 A2, 2 V0, 3 V1, 4 V2, 5 RU1, 6 RU2
    G = lv1.concat([Ast[1:3], Vst, RUst[1:3]], 0)
    rA1, rA2, rV0, rV1, rV2, rRU1, rRU2 = I[0], I[1], I[2], I[3], I[4], I[5], I[6]
    M16 = G.reshape(7, 64, 16, 4).max(3)
    M16q = M16.reshape(7, 64, 4, 4)
    M4 = M16q.max(3)
    rmax = M16.max(2)                                # [7,64]
    uG = rmax.reshape(7, 64, 1) - G
    M = M16[:4]
    gs = M.argmax(2)
    oth = lv1.where(ar16.reshape(1, 1, 16) == gs.reshape(4, 64, 1), NEG, M).max(2)
    flatG = G[:4].reshape(4 * 64 * 64)
    basei = (ar4.reshape(4, 1) * C64 + ar64.reshape(1, 64)) * C64 + gs * I[4]
    idx = basei.reshape(4, 64, 1) + ar4.reshape(1, 1, 4)
    vals = flatG[idx.reshape(1024)].reshape(4, 64, 4)
    am_in = vals.argmax(2)
    jarg = gs * I[4] + am_in
    sec_in = lv1.where(ar4.reshape(1, 1, 4) == am_in.reshape(4, 64, 1), NEG, vals).max(2)
    marg = rmax[:4] - lv1.maximum(oth, sec_in)
    q = [G[:, :, 16*i:16*(i+1)] for i in range(4)]
    Tri = lv1.stack([lv1.concat([q[1], q[2], q[3]], 2), lv1.concat([q[0], q[2], q[3]], 2),
                     lv1.concat([q[0], q[1], q[3]], 2), lv1.concat([q[0], q[1], q[2]], 2)], 2)
    Gq = G.reshape(7, 64, 4, 16)
    Gs = G.reshape(7, 64, 16, 4)
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    out1 = tab1[t0]
    out4 = tab1[lv1.maximum(lv1.maximum(t0, t1), lv1.maximum(t2, t3))]
    def exact_quarter(rows_idx, w, qi):
        R = lv1.stack([Gq[r, t, qi] for r, t in rows_idx], 0)
        return qi * C16 + (w @ R).argmax()
    def exact_two_quarters(rows_idx, w, qa, qb):
        R = lv1.stack([lv1.concat([Gq[r, t, qa], Gq[r, t, qb]], 0) for r, t in rows_idx], 0)
        am = (w @ R).argmax()
        return lv1.where(am < C16, qa * C16 + am, qb * C16 + am - C16)
    def exact_triple(rows_idx, w, miss):
        R = lv1.stack([Tri[r, t, miss] for r, t in rows_idx], 0)
        am = (w @ R).argmax()
        return am + C16 * lv1.cast((am // C16) >= miss, "int")
    def exact_full(rows_idx, w):
        R = lv1.stack([G[r, t] for r, t in rows_idx], 0)
        return (w @ R).argmax()
    def exact_sub(rows_idx, w, sg):
        R = lv1.stack([Gs[r, t, sg] for r, t in rows_idx], 0)
        return sg * I[4] + (w @ R).argmax()
    def exact_two_subs(rows_idx, w, sa, sb):
        R = lv1.stack([lv1.concat([Gs[r, t, sa], Gs[r, t, sb]], 0) for r, t in rows_idx], 0)
        am = (w @ R).argmax()
        return lv1.where(am < I[4], sa * I[4] + am, sb * I[4] + am - I[4])
    # ---- len 2
    a, b = t0, t1
    r = lv1.exp(D[I[0], I[0], b, a]); one_r = ONE + r
    jA = jarg[rA1, b]
    lhsA = r * (uG[rRU1, b, jA] + uG[rV0, a, jA])
    cA = lhsA < marg[rA1, b]
    j0 = jarg[rV0, a]
    rhs0 = one_r * uG[rRU1, b, j0] + uG[rV1, b, j0]
    c0 = r * marg[rV0, a] > rhs0
    top = one_r * rmax[rRU1, b] + rmax[rV1, b] + r * rmax[rV0, a]
    LB2 = lv1.maximum(top - (lhsA + uG[rRU1, b, jA] + uG[rV1, b, jA]), top - rhs0) - EPS
    w2 = lv1.stack([ONE, r, r], 0)
    rows2 = [(rA1, b), (rRU1, b), (rV0, a)]
    UB4 = w2 @ lv1.stack([M4[rr, tt] for rr, tt in rows2], 0)
    m4 = UB4 >= LB2
    k4 = m4.sum(); qa = m4.argmax(); qb = lv1.where(m4, ar4, CM1).max()
    fb2 = lv1.cond(k4 == I[1], exact_quarter(rows2, w2, qa),
          lv1.cond(k4 == I[2], exact_two_quarters(rows2, w2, qa, qb), exact_full(rows2, w2)))
    out2 = lv1.cond(cA, jA, lv1.cond(c0, j0, fb2))
    # ---- len 3
    r0 = lv1.exp(D[I[1], I[0], t2, t0]); r1 = lv1.exp(D[I[1], I[1], t2, t1]); s = r0 + r1; one_s = ONE + s
    j2 = jarg[rA2, t2]
    lhs2 = r0 * (uG[rRU2, t2, j2] + uG[rV0, t0, j2]) + r1 * (uG[rRU2, t2, j2] + uG[rV1, t1, j2])
    c2 = lhs2 < marg[rA2, t2]
    j1 = jarg[rV1, t1]
    rhs1 = one_s * uG[rRU2, t2, j1] + r0 * uG[rV0, t0, j1] + uG[rV2, t2, j1]
    c1 = r1 * marg[rV1, t1] > rhs1
    j0b = jarg[rV0, t0]
    rhs0b = one_s * uG[rRU2, t2, j0b] + r1 * uG[rV1, t1, j0b] + uG[rV2, t2, j0b]
    c0b = r0 * marg[rV0, t0] > rhs0b
    top3 = one_s * rmax[rRU2, t2] + rmax[rV2, t2] + r0 * rmax[rV0, t0] + r1 * rmax[rV1, t1]
    LB3 = lv1.maximum(lv1.maximum(top3 - (lhs2 + uG[rRU2, t2, j2] + uG[rV2, t2, j2]), top3 - rhs1), top3 - rhs0b) - EPS
    w3 = lv1.stack([ONE, s, r0, r1], 0)
    rows3 = [(rA2, t2), (rRU2, t2), (rV0, t0), (rV1, t1)]
    UB4b = w3 @ lv1.stack([M4[rr, tt] for rr, tt in rows3], 0)
    m4b = UB4b >= LB3
    k4b = m4b.sum(); qa3 = m4b.argmax(); qb3 = lv1.where(m4b, ar4, CM1).max(); miss3 = m4b.argmin()
    # k4==1: 4-subgroup stage
    Ma = [M16q[rr, tt, qa3] for rr, tt in rows3]
    UB16a = w3 @ lv1.stack(Ma, 0)
    m16a = UB16a >= LB3
    ka = m16a.sum(); sa_f = qa3 * I[4] + m16a.argmax(); sa_l = qa3 * I[4] + lv1.where(m16a, ar4, CM1).max()
    # k4==2: 8-subgroup stage
    UB8 = w3 @ lv1.stack([lv1.concat([Ma[i], M16q[rr, tt, qb3]], 0) for i, (rr, tt) in enumerate(rows3)], 0)
    m8 = UB8 >= LB3
    k8 = m8.sum()
    sgvec = lv1.concat([qa3 * I[4] + ar4, qb3 * I[4] + ar4], 0)
    sb_f = sgvec[m8.argmax()]; sb_l = sgvec[lv1.where(m8, ar8, CM1).max()]
    is1 = k4b == I[1]
    kk = lv1.cond(is1, ka, k8); sf = lv1.cond(is1, sa_f, sb_f); sl = lv1.cond(is1, sa_l, sb_l)
    small = lv1.cond(kk == I[1], exact_sub(rows3, w3, sf),
            lv1.cond(kk == I[2], exact_two_subs(rows3, w3, sf, sl),
            lv1.cond(is1, exact_quarter(rows3, w3, qa3), exact_two_quarters(rows3, w3, qa3, qb3))))
    fb3 = lv1.cond(k4b <= I[2], small,
          lv1.cond(k4b == I[3], exact_triple(rows3, w3, miss3), exact_full(rows3, w3)))
    out3 = lv1.cond(c2, j2, lv1.cond(c1, j1, lv1.cond(c0b, j0b, fb3)))
    e2 = t2 == C64; e1 = t1 == C64; e3 = t3 == C64
    out = lv1.cond(e2, lv1.cond(e1, out1, out2), lv1.cond(e3, out3, out4))
    entry = g.entry(interpretation=out)
    return entry, len(g.nodes)
'''
exec(BUILDER)
entry, nn = build({})
print('nodes', nn)
save_entry('v14', entry)
ev = lv1.Evaluator(entry, weights, 4)
print('build', ev.build_cost)
import numpy as np, time, inspect
print(inspect.signature(lv1.run_reference))
rs = np.random.RandomState(1)
def check(inputs):
    bad = []; tot = 0
    for x in inputs:
        ins, ans, cr, cp = ev.run(x)
        tot += cp
        ref = lv1.run_reference(x, weights, 4)
        if ans != ref[0]: bad.append((x, ans, ref))
    return tot/len(inputs), bad[:5], len(bad)
t = time.time()
print(check([[a,64,64,64] for a in range(64)]))
print(check([[a,b,64,64] for a in range(64) for b in range(64)]))
print(check([list(rs.randint(0,64,3))+[64] for _ in range(4000)]))
print(check([list(rs.randint(0,64,4)) for _ in range(1000)]))
print(time.time()-t)
