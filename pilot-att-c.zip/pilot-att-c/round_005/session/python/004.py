
import inspect
src = inspect.getsource(lv1.show)
print(src[:2500])
print(inspect.signature(lv1.Evaluator.__init__))
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
