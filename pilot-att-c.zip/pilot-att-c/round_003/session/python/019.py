
import numpy as np, math
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
VOU = V@O@U; Es=E[:64]; EU=Es@U; EVOU=Es@VOU
RU2 = EU + P[2]@U; V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU; V2 = EVOU + P[2]@VOU; A2 = RU2+V2
QK = Q@K.T/np.sqrt(32); EQK = Es@QK; Sfull = EQK@Es.T; EQKP = EQK@P[:3].T; PQK = P[:3]@QK; PQKE = PQK@Es.T; PQKP = PQK@P[:3].T
def S(i, t2, tk): return Sfull[t2,tk] + EQKP[t2,i] + PQKE[2,tk] + PQKP[2,i]
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
t0,t1,t2 = t[:,0],t[:,1],t[:,2]
r0=np.exp(S(0,t2,t0)-S(2,t2,t2)); r1=np.exp(S(1,t2,t1)-S(2,t2,t2)); s=1+r0+r1
L = s[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]; out = L.argmax(1)
def margins(T):
    srt = np.sort(T,1); return T.argmax(1), srt[:,-1]-srt[:,-2]
AM2,m2 = margins(A2); AM0,m0 = margins(V0); AM1,m1 = margins(V1)
uR = RU2.max(1)[:,None]-RU2; u0 = V0.max(1)[:,None]-V0; u1 = V1.max(1)[:,None]-V1; u2 = V2.max(1)[:,None]-V2; uA = A2.max(1)[:,None]-A2
j2 = AM2[t2]; c2 = r0*(uR[t2,j2]+u0[t0,j2]) + r1*(uR[t2,j2]+u1[t1,j2]) < m2[t2]
j0 = AM0[t0]; c0 = r0*m0[t0] > s*uR[t2,j0] + r1*u1[t1,j0] + u2[t2,j0]
c0n = r0*m0[t0] > uA[t2,j0] + (r0+r1)*uR[t2,j0] + r1*u1[t1,j0]
j1 = AM1[t1]; c1 = r1*m1[t1] > s*uR[t2,j1] + r0*u0[t0,j1] + u2[t2,j1]
c1n = r1*m1[t1] > uA[t2,j1] + (r0+r1)*uR[t2,j1] + r0*u0[t0,j1]
print('old any', (c2|c0|c1).mean(), 'new any', (c2|c0n|c1n).mean(), 'c0', c0.mean(), c0n.mean(), 'c1', c1.mean(), c1n.mean())
print('correct', (out[c0n]==j0[c0n]).all(), (out[c1n]==j1[c1n]).all())
# scales
print('m0 median', np.median(m0), 'uR median', np.median(uR), 'u2 median', np.median(u2), 'uA median', np.median(uA))
# also: c2 variant using A2's margin but pair... what about using u of M-pair exact (upper bound on gain)
G0 = np.array([ (RU2[a][None,:]+V0).max(1) - (RU2[a][None,:]+V0)[:,AM2[a]] for a in range(64)])  # [t2,t0]
G1 = np.array([ (RU2[a][None,:]+V1).max(1) - (RU2[a][None,:]+V1)[:,AM2[a]] for a in range(64)])
c2p = r0*G0[t2,t0] + r1*G1[t2,t1] < m2[t2]
print('c2 pair-aware', c2p.mean(), 'vs', c2.mean(), 'any with pair-aware', (c2p|c0n|c1n).mean())
