
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
VOU = V@O@U; Es=E[:64]; EU=Es@U; EVOU=Es@VOU
A2 = EU + P[2]@U + EVOU + P[2]@VOU; V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU
QK = Q@K.T/np.sqrt(32); EQK = Es@QK; Sfull = EQK@Es.T; EQKP = EQK@P[:3].T; PQK = P[:3]@QK; PQKE = PQK@Es.T; PQKP = PQK@P[:3].T
def S(i, t2, tk): return Sfull[t2,tk] + EQKP[t2,i] + PQKE[2,tk] + PQKP[2,i]
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
t0,t1,t2 = t[:,0],t[:,1],t[:,2]
d0 = S(0,t2,t0)-S(2,t2,t2); d1 = S(1,t2,t1)-S(2,t2,t2); r0=np.exp(d0); r1=np.exp(d1)
L = A2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = L.argmax(1)
N,n = t.shape; x = E[t] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
head = np.einsum('nk,nkd->nd', w, x@V); lg = (read + head@O)@U; ref = lg.argmax(1)
bad = np.where(out!=ref)[0]; print(len(bad), bad[:5])
i = bad[0]; print(t[i], 'ref', ref[i], 'mine', out[i]); print('sc', sc[i], 'd', d0[i], d1[i], 'sc diffs', sc[i,0]-sc[i,2], sc[i,1]-sc[i,2])
print('w', w[i], 'r', r0[i], r1[i])
print('logits ref top', np.sort(lg[i])[-3:], lg[i].argsort()[-3:]); Ln = L[i]/(1+r0[i]+r1[i]); print('mine top', np.sort(Ln)[-3:], Ln.argsort()[-3:])
print('dtype', E.dtype, L.dtype, lg.dtype)
