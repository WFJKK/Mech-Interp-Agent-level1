
import numpy as np, time
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
def fwd(toks):
    N,n = toks.shape; x = E[toks] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
    sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x@V); return ((read + head@O)@U).argmax(1)
ev = lv1.Evaluator(entries['v10'], weights, 4)
t1 = np.array([[a,64,64,64] for a in range(64)]); ref1 = fwd(t1[:,:1])
t2 = np.array([[a,b,64,64] for a in range(64) for b in range(64)]); ref2 = fwd(t2[:,:2])
t3 = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T; ref3 = fwd(t3)
rng = np.random.default_rng(7); t4 = rng.integers(0,64,(30000,4)); ref4 = fwd(t4)
tm=time.time()
for name, T, R, pad in [('len1',t1,ref1,0),('len2',t2,ref2,0),('len3',t3,ref3,1),('len4',t4,ref4,0)]:
    bad = 0; ops = 0
    for x, r in zip(T, R):
        xx = np.append(x,64) if pad else x
        ins, ans, cr, cp = ev.run(xx); bad += (ans != r); ops += cp
    print(name, 'bad', bad, 'avg ops', ops/len(T))
print('time', time.time()-tm)
