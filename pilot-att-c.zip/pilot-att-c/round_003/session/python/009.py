
import numpy as np, math
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
VOU = V@O@U; Es=E[:64]; EU=Es@U; EVOU=Es@VOU
RU2 = EU + P[2]@U; V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU; V2 = EVOU + P[2]@VOU; A2 = RU2+V2
QK = Q@K.T/np.sqrt(32); EQK = Es@QK; Sfull = EQK@Es.T; EQKP = EQK@P[:3].T; PQK = P[:3]@QK; PQKE = PQK@Es.T; PQKP = PQK@P[:3].T
def S(i, t2, tk): return Sfull[t2,tk] + EQKP[t2,i] + PQKE[2,tk] + PQKP[2,i]
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
t0,t1,t2 = t[:,0],t[:,1],t[:,2]
d0 = S(0,t2,t0)-S(2,t2,t2); d1 = S(1,t2,t1)-S(2,t2,t2); r0=np.exp(d0); r1=np.exp(d1)
L = (1+r0+r1)[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = L.argmax(1)
N,n = t.shape; x = E[t] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
head = np.einsum('nk,nkd->nd', w, x@V); lg = (read + head@O)@U; ref = lg.argmax(1)
print('ratio form matches:', (out==ref).mean())
def margins(T):
    s = np.sort(T,1); return T.argmax(1), s[:,-1]-s[:,-2]
AM2,m2 = margins(A2); AM0,m0 = margins(V0); AM1,m1 = margins(V1)
uR = RU2.max(1)[:,None]-RU2; u0 = V0.max(1)[:,None]-V0; u1 = V1.max(1)[:,None]-V1; u2 = V2.max(1)[:,None]-V2
# slot 2 dominant
j2 = AM2[t2]; uR2 = uR[t2,j2]
c2 = r0*(uR2+u0[t0,j2]) + r1*(uR2+u1[t1,j2]) < m2[t2]
# slot 0 dominant: -(1+r0+r1) uR[t2,j0] + r0 m0[t0] - r1 u1[t1,j0] - u2[t2,j0] > 0
j0 = AM0[t0]; c0 = r0*m0[t0] > (1+r0+r1)*uR[t2,j0] + r1*u1[t1,j0] + u2[t2,j0]
j1 = AM1[t1]; c1 = r1*m1[t1] > (1+r0+r1)*uR[t2,j1] + r0*u0[t0,j1] + u2[t2,j1]
print('p2,p0,p1', c2.mean(), c0.mean(), c1.mean(), 'any', (c2|c0|c1).mean())
print('correct:', (out[c2]==j2[c2]).all(), (out[c0]==j0[c0]).all(), (out[c1]==j1[c1]).all())
print('w2>0.9 frac', (w[:,2]>0.9).mean(), 'w0>0.9', (w[:,0]>0.9).mean(), 'w1>0.9', (w[:,1]>0.9).mean())
# how far: for inputs with w2>0.99 not covered by c2?
print('w2>0.99 & ~c2', ((w[:,2]>0.99)&~c2).mean(), (w[:,2]>0.99).mean())
