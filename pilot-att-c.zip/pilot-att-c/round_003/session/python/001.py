
import numpy as np, json, math
print(info.keys())
print({k:v.shape for k,v in weights.items()})
print(list(entries.keys()))
m = measure(entries['best']); print(m)
e = entries['best']
print(type(e), (list(e.keys()) if isinstance(e, dict) else None))
s = json.dumps(e); print(len(s))
