
import numpy as np, math
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
VOU = V@O@U; Es=E[:64]; EU=Es@U; EVOU=Es@VOU
RU1 = EU + P[1]@U; V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU; A1 = RU1+V1
QK = Q@K.T/np.sqrt(32); EQK = Es@QK; Sfull = EQK@Es.T; EQKP = EQK@P[:3].T; PQK = P[:3]@QK; PQKE = PQK@Es.T; PQKP = PQK@P[:3].T
a,b = np.meshgrid(np.arange(64),np.arange(64),indexing='ij'); a=a.ravel(); b=b.ravel()
s0 = Sfull[b,a] + EQKP[b,0] + PQKE[1,a] + PQKP[1,0]; s1 = Sfull[b,b] + EQKP[b,1] + PQKE[1,b] + PQKP[1,1]
r0 = np.exp(s0-s1)
L = (1+r0)[:,None]*RU1[b] + V1[b] + r0[:,None]*V0[a]; out = L.argmax(1)
tab1 = ((Es+P[0])@U + V0).argmax(1)
print('out == tab1[max]:', (out==tab1[np.maximum(a,b)]).mean(), 'exceptions', (out!=tab1[np.maximum(a,b)]).sum())
def margins(T):
    s = np.sort(T,1); return T.argmax(1), s[:,-1]-s[:,-2]
AM1,m1 = margins(A1); AM0,m0 = margins(V0)
uR = RU1.max(1)[:,None]-RU1; u0 = V0.max(1)[:,None]-V0; u1 = V1.max(1)[:,None]-V1
j1 = AM1[b]; c1 = r0*(uR[b,j1]+u0[a,j1]) < m1[b]
j0 = AM0[a]; c0 = r0*m0[a] > (1+r0)*uR[b,j0] + u1[b,j0]
print('len2 cover: self', c1.mean(), 'slot0', c0.mean(), 'any', (c1|c0).mean(), 'correct', (out[c1]==j1[c1]).all(), (out[c0]==j0[c0]).all())
rest = ~(c1|c0); print('rest count', rest.sum(), 'rest with |a-b|<=3:', (np.abs(a-b)[rest]<=3).mean())
print('rest pairs sample', list(zip(a[rest][:30], b[rest][:30])))
