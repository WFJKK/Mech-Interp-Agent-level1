
import inspect
print(inspect.signature(lv1.Evaluator), inspect.getsource(lv1.Evaluator)[:1500])
print(inspect.signature(lv1.measure))
print(inspect.signature(lv1.Graph.load))
