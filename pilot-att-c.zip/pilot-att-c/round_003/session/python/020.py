
import numpy as np
ev = lv1.Evaluator(entries['v10'], weights, 4)
tests = {'len1':[5,64,64,64], 'len2 far':[3,40,64,64], 'len2 close':[14,17,64,64], 'len3 a':[13,16,56,64], 'len3 b':[60,61,62,64], 'len3 c':[0,0,36,64], 'len4':[1,2,3,4]}
for k,x in tests.items():
    print(k, ev.run(np.array(x)))
print('build', ev.build_cost)
# shares of len-3 branch costs over random sample
rng = np.random.default_rng(3); t3 = rng.integers(0,64,(5000,3))
cps = np.array([ev.run(np.append(x,64))[3] for x in t3])
vals, cnts = np.unique(cps, return_counts=True); print(list(zip(vals, cnts)))
t2 = rng.integers(0,64,(5000,2)); cps2 = np.array([ev.run(np.append(x,[64,64]))[3] for x in t2])
vals, cnts = np.unique(cps2, return_counts=True); print(list(zip(vals, cnts)))
