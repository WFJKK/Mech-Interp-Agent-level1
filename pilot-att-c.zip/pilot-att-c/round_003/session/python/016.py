
import numpy as np, time
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
def fwd(toks):
    N,n = toks.shape; x = E[toks] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
    sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x@V); return ((read + head@O)@U).argmax(1)
ev = lv1.Evaluator(entries['v9_shortcuts'], weights, 4)
# len 1 and 2
t1 = np.array([[a,64,64,64] for a in range(64)]); ref1 = fwd(t1[:,:1])
t2 = np.array([[a,b,64,64] for a in range(64) for b in range(64)]); ref2 = fwd(t2[:,:2])
tm = time.time()
bad = 0; ops = 0
for x, r in zip(t1, ref1):
    ins, ans, cr, cp = ev.run(x); bad += (ans != r); ops += cp
print('len1 bad', bad, 'avg ops', ops/64)
bad = 0; ops = 0
for x, r in zip(t2, ref2):
    ins, ans, cr, cp = ev.run(x); bad += (ans != r); ops += cp
print('len2 bad', bad, 'avg ops', ops/4096, 'time', time.time()-tm)
# len 3 sample of 20000 random for timing
rng = np.random.default_rng(0)
t3 = rng.integers(0,64,(20000,3)); ref3 = fwd(t3)
tm = time.time(); bad = 0; ops = 0
for x, r in zip(t3, ref3):
    ins, ans, cr, cp = ev.run(np.append(x,64)); bad += (ans != r); ops += cp
print('len3 bad', bad, 'avg ops', ops/20000, 'time', time.time()-tm)
