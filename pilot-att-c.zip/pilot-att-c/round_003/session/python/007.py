
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
VOU = V@O@U; Es=E[:64]; EU=Es@U; EVOU=Es@VOU
A2 = EU + P[2]@U + EVOU + P[2]@VOU; V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU
QK = Q@K.T/np.sqrt(32); EQK = Es@QK; Sfull = EQK@Es.T; EQKP = EQK@P[:3].T; PQK = P[:3]@QK; PQKE = PQK@Es.T; PQKP = PQK@P[:3].T
def S(i, t2, tk): return Sfull[t2,tk] + EQKP[t2,i] + PQKE[2,tk] + PQKP[2,i]
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
t0,t1,t2 = t[:,0],t[:,1],t[:,2]
d0 = S(0,t2,t0)-S(2,t2,t2); d1 = S(1,t2,t1)-S(2,t2,t2); r0=np.exp(d0); r1=np.exp(d1)
L = A2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = L.argmax(1)
# reference check
def fwd(toks):
    N,n = toks.shape; x = E[toks] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
    sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x@V); return ((read + head@O)@U).argmax(1)
print('ratio form matches fwd:', (out==fwd(t)).mean())
def margins(T):
    s = np.sort(T,1); return T.argmax(1), s[:,-1]-s[:,-2]
AM2,m2 = margins(A2); AM0,m0 = margins(V0); AM1,m1 = margins(V1)
uA = A2.max(1)[:,None]-A2; u0 = V0.max(1)[:,None]-V0; u1 = V1.max(1)[:,None]-V1   # u[t, j*] = max_j T[t][j]-T[t][j*]
spA = A2.max(1)-A2.min(1); sp0 = V0.max(1)-V0.min(1); sp1 = V1.max(1)-V1.min(1)
# tight-ish separable bounds
j2 = AM2[t2]; c2 = r0*u0[t0,j2] + r1*u1[t1,j2] < m2[t2]
j0 = AM0[t0]; c0 = uA[t2,j0] + r1*u1[t1,j0] < r0*m0[t0]
j1 = AM1[t1]; c1 = uA[t2,j1] + r0*u0[t0,j1] < r1*m1[t1]
print('tight: p2,p0,p1', c2.mean(), c0.mean(), c1.mean(), 'any', (c2|c0|c1).mean())
print('correct when applied:', (out[c2]==j2[c2]).all(), (out[c0]==j0[c0]).all(), (out[c1]==j1[c1]).all())
# span bounds
s2 = r0*sp0[t0] + r1*sp1[t1] < m2[t2]; s0 = spA[t2] + r1*sp1[t1] < r0*m0[t0]; s1 = spA[t2] + r0*sp0[t0] < r1*m1[t1]
print('span: p2,p0,p1', s2.mean(), s0.mean(), s1.mean(), 'any', (s2|s0|s1).mean())
# how about a 2-slot shortcut: slot 2 + slot 0 dominate (r1 small): need 2-row computation anyway; skip
print('margin quantiles A2', np.quantile(m2,[0,.1,.5,.9]), 'V0', np.quantile(m0,[0,.1,.5,.9]))
