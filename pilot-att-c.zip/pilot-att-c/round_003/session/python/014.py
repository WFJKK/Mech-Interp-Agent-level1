
import inspect
src = inspect.getsource(lv1.Evaluator)
i = src.find('def run'); print(src[i:i+1200])
