
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
def fwd(toks):
    N,n = toks.shape
    x = E[toks] + P[:n][None]
    read = x[:,n-1]
    q = read@Q/np.sqrt(32)
    sc = np.einsum('nkd,nd->nk', x@K, q)
    w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x@V)
    logits = (read + head@O)@U
    return logits.argmax(1), w, logits
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
out3, w3, lg3 = fwd(t)
RU2 = (E[:64]+P[2])@U; VOU = V@O@U; VOU_i = [(E[:64]+P[i])@VOU for i in range(3)]
tab1 = ((E[:64]+P[0])@U + VOU_i[0]).argmax(1)
mn = t.min(1); mx = t.max(1); md = np.sort(t,1)[:,1]
for name, ref in [('min',mn),('t2',t[:,2]),('t0',t[:,0]),('t1',t[:,1]),('med',md),('max',mx)]:
    d = out3 - ref
    print(name, 'range', d.min(), d.max(), 'abs<=4:', (np.abs(d)<=4).mean(), 'abs<=8', (np.abs(d)<=8).mean())
cand = np.stack([t[:,0],t[:,1],t[:,2],tab1[t[:,0]],tab1[t[:,1]],tab1[t[:,2]],np.full(len(t),7)],1)
print('in simple set', (cand==out3[:,None]).any(1).mean())
print('w max quantiles', np.quantile(w3.max(1),[0.1,0.25,0.5,0.75,0.9,0.99]))
print('w2 quantiles', np.quantile(w3[:,2],[0.01,0.1,0.5,0.9,0.99]))
QK = Q@K.T/np.sqrt(32)
S = (E[:64]+P[2])@QK@(E[:64]).T
print('score range', S.min(), S.max())
print('distinct outputs', len(np.unique(out3))); print(np.bincount(out3, minlength=64))
# margin: logit gap between top1 and top2
srt = np.sort(lg3,1); gap = srt[:,-1]-srt[:,-2]
print('gap quantiles', np.quantile(gap,[0,0.001,0.01,0.1,0.5]))
