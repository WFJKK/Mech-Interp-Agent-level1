
print([n for n in dir(lv1) if not n.startswith('_')])
g = graph()
x = g.weight('embed')
print([n for n in dir(x) if not n.startswith('_')])
import inspect
print(inspect.signature(lv1.where), inspect.signature(lv1.cond), inspect.signature(lv1.stack))
try:
    print(inspect.signature(g.entry))
except Exception as ex: print(ex)
y = x[:64]; print(y.shape, (y.max(axis=1)).shape, y[:, 3].shape, y[None].shape if hasattr(y,'shape') else None)
a = g.token(0); print(y[a, a].shape, y[a].shape)
