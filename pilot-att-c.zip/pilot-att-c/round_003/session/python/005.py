
import json
e = entries['best']
nodes = e['nodes']
print(len(nodes), e['predict'], e['rule'])
for i,nd in enumerate(nodes):
    print(i, json.dumps(nd)[:160])
