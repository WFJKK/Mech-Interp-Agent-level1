
mn = t.min(1); mx = t.max(1); md = np.sort(t,1)[:,1]
for name, ref in [('min',mn),('t2',t[:,2]),('t0',t[:,0]),('t1',t[:,1]),('med',md),('max',mx)]:
    d = out3 - ref
    print(name, 'range', d.min(), d.max(), 'abs<=4:', (np.abs(d)<=4).mean(), 'abs<=8', (np.abs(d)<=8).mean())
# in {t0,t1,t2, tab1 of them, 7}?
cand = np.stack([t[:,0],t[:,1],t[:,2],tab1[t[:,0]],tab1[t[:,1]],tab1[t[:,2]],np.full(len(t),7)],1)
print('in simple set', (cand==out3[:,None]).any(1).mean())
# attention weights
print('w stats: max weight quantiles', np.quantile(w3.max(1),[0.1,0.25,0.5,0.75,0.9,0.99]))
print('w2 quantiles', np.quantile(w3[:,2],[0.01,0.1,0.5,0.9,0.99]))
# scores decomposition: s_i = (E[t2]+P2)Q K^T (E[ti]+Pi)^T / sqrt32
QK = Q@K.T/np.sqrt(32)
S = (E[:64]+P[2])@QK@(E[:64]).T   # [t2, tk]
print('score range', S.min(), S.max())
# distinct outputs
print('distinct outputs', len(np.unique(out3)), np.bincount(out3, minlength=64))
