
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
VOU = V@O@U; EU=E[:64]@U; EVOU=E[:64]@VOU
A2 = EU + P[2]@U + EVOU + P[2]@VOU
V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU
# dominance of column j by column k for len-3 (coeffs 1, r0, r1 >= 0)
dom = np.zeros((64,64),bool)
for j in range(64):
    for k in range(64):
        if j==k: continue
        dom[j,k] = (A2[:,k]>A2[:,j]).all() and (V0[:,k]>=V0[:,j]).all() and (V1[:,k]>=V1[:,j]).all()
print('dominated columns:', np.where(dom.any(1))[0])
for j in np.where(dom.any(1))[0]: print(j, 'by', np.where(dom[j])[0])
# len-2 analog: A1 + r0*V0
A1 = EU + P[1]@U + EVOU + P[1]@VOU
dom2 = np.zeros((64,64),bool)
for j in range(64):
    for k in range(64):
        if j!=k: dom2[j,k] = (A1[:,k]>A1[:,j]).all() and (V0[:,k]>=V0[:,j]).all()
print('len2 dominated:', np.where(dom2.any(1))[0])
# how close are columns 5,6 to being dominated by 7?
for j in [0,1,2,3,4,5,6]:
    print(j, (A2[:,7]-A2[:,j]).min(), (V0[:,7]-V0[:,j]).min(), (V1[:,7]-V1[:,j]).min())
