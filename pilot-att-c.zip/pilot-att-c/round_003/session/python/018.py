
import numpy as np, math
def build_entry(order=('2','0','1')):
    g = graph()
    Eall, Pall = g.weight('embed'), g.weight('pos')
    Qw, Kw, Vw, Ow, Uw = g.weight('query'), g.weight('key'), g.weight('value'), g.weight('out'), g.weight('unembed')
    Es, Ps = Eall[:64], Pall[:3]
    QK = (Qw @ Kw.T) * (1/math.sqrt(32))
    EQK = Es @ QK; Sfull = EQK @ Es.T; EQKP = EQK @ Ps.T; PQK = Ps @ QK; PQKE = PQK @ Es.T; PQKP = PQK @ Ps.T
    diagS = (EQK * Es).sum(axis=1)
    B2 = Sfull + PQKE[2].reshape(1, 64)
    self2 = diagS + EQKP[:, 2] + PQKE[2] + PQKP[2, 2]
    D3_0 = B2 + (EQKP[:, 0] + PQKP[2, 0] - self2).reshape(64, 1)
    D3_1 = B2 + (EQKP[:, 1] + PQKP[2, 1] - self2).reshape(64, 1)
    B1 = Sfull + PQKE[1].reshape(1, 64)
    self1 = diagS + EQKP[:, 1] + PQKE[1] + PQKP[1, 1]
    D2_0 = B1 + (EQKP[:, 0] + PQKP[1, 0] - self1).reshape(64, 1)
    VOUm = (Vw @ Ow) @ Uw
    EVOU = Es @ VOUm; PVOU = Ps @ VOUm; EU = Es @ Uw; PU = Ps @ Uw
    V0 = EVOU + PVOU[0].reshape(1, 64); V1 = EVOU + PVOU[1].reshape(1, 64); V2 = EVOU + PVOU[2].reshape(1, 64)
    RU1 = EU + PU[1].reshape(1, 64); RU2 = EU + PU[2].reshape(1, 64)
    A1 = RU1 + V1; A2 = RU2 + V2
    tab1 = (EU + PU[0].reshape(1, 64) + V0).argmax(axis=1)
    ar = g.arange(64).reshape(1, 64)
    def marg(T):
        mx = T.max(axis=1); am = T.argmax(axis=1)
        second = lv1.where(ar == am.reshape(64, 1), -1e30, T).max(axis=1)
        return am, mx - second, mx
    AM2, m2, mxA2 = marg(A2); AM0, m0, mx0 = marg(V0); AM1, m1, mx1 = marg(V1); AM1s, m1s, mxA1 = marg(A1)
    u0 = mx0.reshape(64, 1) - V0; u1 = mx1.reshape(64, 1) - V1
    u2 = V2.max(axis=1).reshape(64, 1) - V2
    uR2 = RU2.max(axis=1).reshape(64, 1) - RU2; uR1 = RU1.max(axis=1).reshape(64, 1) - RU1
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    p1 = tab1[t0]
    p4 = tab1[lv1.maximum(lv1.maximum(t0, t1), lv1.maximum(t2, t3))]
    r = lv1.exp(D2_0[t1, t0])
    j1 = AM1s[t1]; c1 = r * (uR1[t1, j1] + u0[t0, j1]) < m1s[t1]
    j0 = AM0[t0]; c0 = r * m0[t0] > (1.0 + r) * uR1[t1, j0] + u1[t1, j0]
    coef2 = lv1.stack([1.0 + r, g.const(1.0), r]).reshape(1, 3)
    rows2 = lv1.stack([RU1[t1], V1[t1], V0[t0]])
    full2 = (coef2 @ rows2).reshape(64).argmax(axis=0)
    p2 = lv1.cond(c1, j1, lv1.cond(c0, j0, full2))
    r0 = lv1.exp(D3_0[t2, t0]); r1 = lv1.exp(D3_1[t2, t1]); s = 1.0 + r0 + r1
    k2 = AM2[t2]; uRk2 = uR2[t2, k2]
    d2 = r0 * (uRk2 + u0[t0, k2]) + r1 * (uRk2 + u1[t1, k2]) < m2[t2]
    k0 = AM0[t0]; d0 = r0 * m0[t0] > s * uR2[t2, k0] + r1 * u1[t1, k0] + u2[t2, k0]
    k1 = AM1[t1]; d1 = r1 * m1[t1] > s * uR2[t2, k1] + r0 * u0[t0, k1] + u2[t2, k1]
    coef3 = lv1.stack([s, g.const(1.0), r0, r1]).reshape(1, 4)
    rows3 = lv1.stack([RU2[t2], V2[t2], V0[t0], V1[t1]])
    full3 = (coef3 @ rows3).reshape(64).argmax(axis=0)
    checks = {'2': (d2, k2), '0': (d0, k0), '1': (d1, k1)}
    p3 = full3
    for o in reversed(order):
        p3 = lv1.cond(checks[o][0], checks[o][1], p3)
    pred = lv1.cond(t2 == 64, lv1.cond(t1 == 64, p1, p2), lv1.cond(t3 == 64, p3, p4))
    return g.entry(interpretation=pred)
for order in [('2','0','1'), ('2','1','0')]:
    ent = build_entry(order); m = measure(ent)
    print(order, len(ent['nodes']), {k: m[k] for k in ['cost','r','b','reward','fidelity']})
save_entry('v10', build_entry(('2','1','0')))
