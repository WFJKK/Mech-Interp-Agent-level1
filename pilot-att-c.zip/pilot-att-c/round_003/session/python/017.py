
import numpy as np, time
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
def fwd(toks):
    N,n = toks.shape; x = E[toks] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
    sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x@V); return ((read + head@O)@U).argmax(1)
ev = lv1.Evaluator(entries['v9_shortcuts'], weights, 4)
t3 = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
ref3 = fwd(t3)
tm = time.time(); bad = []; ops = 0
for i,(x, r) in enumerate(zip(t3, ref3)):
    ins, ans, cr, cp = ev.run(np.append(x,64)); ops += cp
    if ans != r: bad.append((tuple(x), r, ans))
print('len3 bad', len(bad), bad[:10], 'avg ops', ops/len(t3), 'time', time.time()-tm)
rng = np.random.default_rng(1)
t4 = rng.integers(0,64,(50000,4)); ref4 = fwd(t4)
bad = 0; ops=0
for x, r in zip(t4, ref4):
    ins, ans, cr, cp = ev.run(x); bad += (ans != r); ops += cp
print('len4 bad', bad, 'avg ops', ops/50000)
