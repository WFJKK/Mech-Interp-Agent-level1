
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
def fwd(toks):  # toks: (N, n) array of tokens, all same length n
    N,n = toks.shape
    x = E[toks] + P[:n][None]            # N,n,32
    read = x[:,n-1]
    q = read@Q/np.sqrt(32)
    sc = np.einsum('nkd,nd->nk', x@K, q)
    w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x@V)
    logits = (read + head@O)@U
    return logits.argmax(1), w, logits
# all len-3 inputs
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
out3, w3, lg3 = fwd(t)
# tables
RU2 = (E[:64]+P[2])@U
VOU = V@O@U
VOU_i = [(E[:64]+P[i])@VOU for i in range(3)]
A = RU2 + VOU_i[2]
tab1 = ((E[:64]+P[0])@U + VOU_i[0]).argmax(1)
print(tab1)
# rank of true output in rows: A[t2], VOU0[t0], VOU1[t1]
def ranks(T, idx, outs):
    rows = T[idx]
    return (rows > rows[np.arange(len(outs)), outs][:,None]).sum(1)
rA = ranks(A, t[:,2], out3); r0 = ranks(VOU_i[0], t[:,0], out3); r1 = ranks(VOU_i[1], t[:,1], out3)
rmin = np.minimum(np.minimum(rA, r0), r1)
print('max of min-rank', rmin.max(), np.bincount(rmin))
print('rank A', np.bincount(rA)[:20])
# M_i formulation
M0 = RU2[t[:,2]] + VOU_i[0][t[:,0]]; M1 = RU2[t[:,2]] + VOU_i[1][t[:,1]]
rM0 = (M0 > M0[np.arange(len(t)), out3][:,None]).sum(1); rM1 = (M1 > M1[np.arange(len(t)), out3][:,None]).sum(1)
rminM = np.minimum(np.minimum(rA, rM0), rM1)
print('M-based max of min-rank', rminM.max(), np.bincount(rminM))
