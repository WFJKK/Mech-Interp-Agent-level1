
import numpy as np, math
W = {k: v.astype(np.float64) for k,v in weights.items()}
E=W['embed']; P=W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; U=W['unembed']
VOU = V@O@U; Es=E[:64]; EU=Es@U; EVOU=Es@VOU
RU2 = EU + P[2]@U; V0 = EVOU + P[0]@VOU; V1 = EVOU + P[1]@VOU; V2 = EVOU + P[2]@VOU; A2 = RU2+V2
QK = Q@K.T/np.sqrt(32); EQK = Es@QK; Sfull = EQK@Es.T; EQKP = EQK@P[:3].T; PQK = P[:3]@QK; PQKE = PQK@Es.T; PQKP = PQK@P[:3].T
def S(i, t2, tk): return Sfull[t2,tk] + EQKP[t2,i] + PQKE[2,tk] + PQKP[2,i]
t = np.array(np.meshgrid(np.arange(64),np.arange(64),np.arange(64),indexing='ij')).reshape(3,-1).T
t0,t1,t2 = t[:,0],t[:,1],t[:,2]
d0 = S(0,t2,t0)-S(2,t2,t2); d1 = S(1,t2,t1)-S(2,t2,t2); r0=np.exp(d0); r1=np.exp(d1)
L = (1+r0+r1)[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0] + r1[:,None]*V1[t1]
out = L.argmax(1)
def margins(T):
    s = np.sort(T,1); return T.argmax(1), s[:,-1]-s[:,-2]
AM2,m2 = margins(A2); AM0,m0 = margins(V0); AM1,m1 = margins(V1)
uR = RU2.max(1)[:,None]-RU2; u0 = V0.max(1)[:,None]-V0; u1 = V1.max(1)[:,None]-V1; u2 = V2.max(1)[:,None]-V2
j2 = AM2[t2]; uR2 = uR[t2,j2]; c2 = r0*(uR2+u0[t0,j2]) + r1*(uR2+u1[t1,j2]) < m2[t2]
j0 = AM0[t0]; c0 = r0*m0[t0] > (1+r0+r1)*uR[t2,j0] + r1*u1[t1,j0] + u2[t2,j0]
j1 = AM1[t1]; c1 = r1*m1[t1] > (1+r0+r1)*uR[t2,j1] + r0*u0[t0,j1] + u2[t2,j1]
rest = ~(c2|c0|c1)
# sum-of-maxima certificate with candidates j2,j0,j1
ub = (1+r0+r1)*RU2.max(1)[t2] + V2.max(1)[t2] + r0*V0.max(1)[t0] + r1*V1.max(1)[t1]
cands = np.stack([j2,j0,j1],1)
Lc = np.take_along_axis(L, cands, 1); best = Lc.max(1); bj = cands[np.arange(len(t)), Lc.argmax(1)]
cert = best > ub - 1e-9   # can't be strictly greater; equality only
print('cert any', cert.mean(), 'cert among rest', cert[rest].mean())
# what about pairwise shortcut: slot1 negligible => 2-slot path (447 vs 575). Fraction where r1 term bound small relative to 2-slot margin:
L2 = (1+r0)[:,None]*RU2[t2] + V2[t2] + r0[:,None]*V0[t0]
s = np.sort(L2,1); mm = s[:,-1]-s[:,-2]; jj = L2.argmax(1)
cA = r1*(uR[t2,jj] + u1[t1,jj]) < mm
print('2-slot (drop slot1) among rest:', (cA&rest).mean()/rest.mean())
# weight distribution among rest
N,n = t.shape; x = E[t] + P[:n][None]; read = x[:,n-1]; q = read@Q/np.sqrt(32)
sc = np.einsum('nkd,nd->nk', x@K, q); w = np.exp(sc - sc.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
print('rest: w max quantiles', np.quantile(w[rest].max(1),[.1,.5,.9]), 'min w quantiles', np.quantile(w[rest].min(1),[.1,.5,.9]))
