
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
def fwd_batch(T):
    n=(T!=64).sum(1)
    x=E[T]+P
    read=x[np.arange(len(T)), n-1]; q=read@Q/np.sqrt(32)
    s=np.einsum('npd,nd->np', x@K, q)
    s[np.arange(4)[None,:]>=n[:,None]]=-1e30
    w=np.exp(s-s.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head=np.einsum('np,npd->nd', w, x@V)
    logits=(read+head@O)@U
    return logits.argmax(1)
E64=E[:64]; M=V@O@U; EM=E64@M; EU=E64@U; EK=E64@K; EQ=E64@Q
VOU=[EM+P[p]@M for p in range(3)]; RU=[EU+P[p]@U for p in range(3)]; Kt=[EK+P[p]@K for p in range(2)]; Qt=[(EQ+P[p]@Q)/math.sqrt(32) for p in range(3)]
S20=Qt[1]@Kt[0].T; S21=(Qt[1]*Kt[1]).sum(1); w0=1/(1+np.exp(S21[:,None]-S20)); C=RU[1]+VOU[1]
L2=C[:,None,:]+w0[:,:,None]*(VOU[0][None,:,:]-VOU[1][:,None,:]); tab2=L2.argmax(2)
T2=np.array([[a,b,64,64] for a in range(64) for b in range(64)]); out2=fwd_batch(T2)
print("len2 exhaustive mismatches:", (tab2[T2[:,1],T2[:,0]]!=out2).sum())
Sbase=Qt[2]@EK.T; bias=[Qt[2]@(P[p]@K) for p in range(3)]
rng=np.random.default_rng(3)
T3=rng.integers(0,64,(200000,4)); T3[:,3]=64; out3=fwd_batch(T3)
t0,t1,t2=T3[:,0],T3[:,1],T3[:,2]
s=np.stack([Sbase[t2,t0]+bias[0][t2], Sbase[t2,t1]+bias[1][t2], Sbase[t2,t2]+bias[2][t2]],1)
w=np.exp(s-s.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
rows=np.stack([VOU[0][t0],VOU[1][t1],VOU[2][t2]],1)
logits=RU[2][t2]+np.einsum('np,npk->nk',w,rows)
print("len3 200k mismatches:", (logits.argmax(1)!=out3).sum())
# how close are ties in len3? min margin
srt=np.sort(logits,1); print("min top-2 margin len3:", (srt[:,-1]-srt[:,-2]).min())
