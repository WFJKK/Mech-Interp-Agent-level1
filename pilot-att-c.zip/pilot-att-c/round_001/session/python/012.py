
import numpy as np, math
def build():
    g = graph()
    t = g.tokens()
    E=g.weight("embed"); P=g.weight("pos"); Q=g.weight("query"); K=g.weight("key"); V=g.weight("value"); O=g.weight("out"); U=g.weight("unembed")
    E64 = E[:64]
    n = (t != 64).sum()
    M = (V @ O) @ U
    EM = E64 @ M; EU = E64 @ U; EK = E64 @ K; EQ = E64 @ Q
    VOU = [EM + (P[p] @ M) for p in range(3)]
    RU = [EU + (P[p] @ U) for p in range(3)]
    Kt = [EK + (P[p] @ K) for p in range(2)]
    Qt = [(EQ + (P[p] @ Q)) * (1/math.sqrt(32)) for p in range(3)]
    tab1 = (RU[0] + VOU[0]).argmax(axis=1)   # 64
    S20 = Qt[1] @ Kt[0].T                    # [b, a]
    S21 = (Qt[1] * Kt[1]).sum(axis=1)        # [b]
    w0 = 1.0 / (1.0 + lv1.exp(S21[:, None] - S20))     # [b, a]
    C = RU[1] + VOU[1]
    L2 = C[:, None, :] + w0[:, :, None] * (VOU[0][None, :, :] - VOU[1][:, None, :])
    tab2 = L2.argmax(axis=2)                 # [b, a]
    # len-3 scores: q(t2)·(EK[tok] + P[p]K) = Sbase[t2,tok] + bias_p[t2]
    Sbase = Qt[2] @ EK.T                     # [t2, tok]
    bias = [Qt[2] @ (P[p] @ K) for p in range(3)]   # [t2]
    t0, t1, t2 = t[0], t[1], t[2]
    def len3():
        s = lv1.stack([Sbase[t2, t0] + bias[0][t2], Sbase[t2, t1] + bias[1][t2], Sbase[t2, t2] + bias[2][t2]])
        w = lv1.softmax(s)
        rows = lv1.stack([VOU[0][t0], VOU[1][t1], VOU[2][t2]])
        logits = RU[2][t2] + w @ rows
        return logits.argmax()
    out4 = tab1[t.max()]
    out3 = len3()
    out2 = tab2[t1, t0]
    out1 = tab1[t0]
    interp = lv1.cond(n == 4, out4, lv1.cond(n == 3, out3, lv1.cond(n == 2, out2, out1)))
    return g.entry(interpretation=interp)
entry = build()
r = measure(entry); print(r)
save_entry("exact_tables_v3", entry)
print(len(entry["nodes"]))
