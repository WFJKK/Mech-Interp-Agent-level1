
import numpy as np, math, itertools
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
def fwd_batch(T):
    n=(T!=64).sum(1)
    x=E[T]+P
    read=x[np.arange(len(T)), n-1]; q=read@Q/np.sqrt(32)
    s=np.einsum('npd,nd->np', x@K, q)
    s[np.arange(4)[None,:]>=n[:,None]]=-1e30
    w=np.exp(s-s.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head=np.einsum('np,npd->nd', w, x@V)
    logits=(read+head@O)@U
    return logits.argmax(1)
tab1 = fwd_batch(np.array([[a,64,64,64] for a in range(64)]))
# len4: exhaustive small, and 1M random
T=np.array(list(itertools.product(range(6),repeat=4))); print("small len4 all ->", set(fwd_batch(T)))
rng=np.random.default_rng(7)
for chunk in range(5):
    T=rng.integers(0,64,(400000,4)); out=fwd_batch(T)
    print("len4 chunk mismatches vs tab1[max]:", (out!=tab1[T.max(1)]).sum())
# len3 random large check vs entry formula using numpy mirror
def build_v4():
    g = graph()
    t = g.tokens()
    E=g.weight("embed"); P=g.weight("pos"); Q=g.weight("query"); K=g.weight("key"); V=g.weight("value"); O=g.weight("out"); U=g.weight("unembed")
    E64 = E[:64]
    M = (V @ O) @ U
    EM = E64 @ M; EU = E64 @ U; EK = E64 @ K; EQ = E64 @ Q
    VOU = [EM + (P[p] @ M) for p in range(3)]
    RU = [EU + (P[p] @ U) for p in range(3)]
    Kt = [EK + (P[p] @ K) for p in range(2)]
    Qt = [(EQ + (P[p] @ Q)) * (1/math.sqrt(32)) for p in range(3)]
    tab1 = (RU[0] + VOU[0]).argmax(axis=1)
    S20 = Qt[1] @ Kt[0].T
    S21 = (Qt[1] * Kt[1]).sum(axis=1)
    w0 = 1.0 / (1.0 + lv1.exp(S21[:, None] - S20))
    C = RU[1] + VOU[1]
    L2 = C[:, None, :] + w0[:, :, None] * (VOU[0][None, :, :] - VOU[1][:, None, :])
    tab2 = L2.argmax(axis=2)
    Sbase = Qt[2] @ EK.T
    bias = [Qt[2] @ (P[p] @ K) for p in range(3)]
    t0, t1, t2, t3 = t[0], t[1], t[2], t[3]
    def len3():
        s = lv1.stack([Sbase[t2, t0] + bias[0][t2], Sbase[t2, t1] + bias[1][t2], Sbase[t2, t2] + bias[2][t2]])
        w = lv1.softmax(s)
        rows = lv1.stack([VOU[0][t0], VOU[1][t1], VOU[2][t2]])
        logits = RU[2][t2] + w @ rows
        return logits.argmax()
    out4 = tab1[t.max()]
    out3 = len3()
    out2 = tab2[t1, t0]
    out1 = tab1[t0]
    interp = lv1.cond(t3 != 64, out4, lv1.cond(t2 != 64, out3, lv1.cond(t1 != 64, out2, out1)))
    return g.entry(interpretation=interp)
entry = build_v4()
r = measure(entry); print(r)
save_entry("exact_tables_v4", entry)
# exhaustive len-2 check through the entry
g, interp, region = lv1.Graph.load(entry, weights, 4, example=[0,0,64,64])
# find tab2 node value: compare via example loads on a sample of len-2 and len-3 inputs
bad=0
T2=np.array([[a,b,64,64] for a in range(64) for b in range(64)]); out2=fwd_batch(T2)
for i in rng.choice(4096, 300, replace=False):
    g_, ip, _ = lv1.Graph.load(entry, weights, 4, example=[int(v) for v in T2[i]])
    bad += int(ip.value)!=out2[i]
print("len2 sample mismatches", bad)
T3=rng.integers(0,64,(300,4)); T3[:,3]=64; out3=fwd_batch(T3); bad=0
for i in range(300):
    g_, ip, _ = lv1.Graph.load(entry, weights, 4, example=[int(v) for v in T3[i]])
    bad += int(ip.value)!=out3[i]
print("len3 sample mismatches", bad)
