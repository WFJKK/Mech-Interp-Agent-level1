
import numpy as np
X, Y, ops = network_outputs()
n = (X != 64).sum(1)
ent = entries["exact_tables_v1"]
res = {L: [0,0] for L in [1,2,3,4]}
fails = []
for i in range(600):
    g, interp, region = lv1.Graph.load(ent, weights, 4, example=[int(v) for v in X[i]])
    v = int(interp.value); L = n[i]
    res[L][1]+=1
    if v == Y[i]: res[L][0]+=1
    else: fails.append((X[i][:L], Y[i], v))
print(res); print(fails[:15])
