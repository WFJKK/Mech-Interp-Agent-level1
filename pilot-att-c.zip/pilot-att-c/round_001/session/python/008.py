
import numpy as np
X, Y, ops = network_outputs()
n = (X != 64).sum(1)
g, interp, region = lv1.Graph.load(entries["exact_tables_v1"], weights, 4)
print([a for a in dir(g) if not a.startswith('_')])
print([a for a in dir(interp) if not a.startswith('_')])
