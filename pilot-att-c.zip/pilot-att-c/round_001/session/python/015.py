
import numpy as np, math
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
E64=E[:64].astype(np.float64); P=P.astype(np.float64)
M=V@O@U; EM=E64@M; EU=E64@U; EK=E64@K; EQ=E64@Q
VOU=[EM+P[p]@M for p in range(3)]; RU=[EU+P[p]@U for p in range(3)]; Kt=[EK+P[p]@K for p in range(2)]; Qt=[(EQ+P[p]@Q)/math.sqrt(32) for p in range(3)]
S20=Qt[1]@Kt[0].T; S21=(Qt[1]*Kt[1]).sum(1); d=S21[:,None]-S20
print("len2 |s1-s0| quantiles:", np.quantile(np.abs(d), [0.01,0.05,0.1,0.25,0.5]))
for eps in [1e-6,1e-4,1e-3,1e-2]:
    w0=1/(1+np.exp(d)); print(eps, "frac intermediate", ((w0>eps)&(w0<1-eps)).mean())
# check: in saturated cases does the argmax of the one-hot approx equal the exact table?
w0=1/(1+np.exp(d)); C=RU[1]+VOU[1]
L2=C[:,None,:]+w0[:,:,None]*(VOU[0][None,:,:]-VOU[1][:,None,:]); tab2=L2.argmax(2)
P0=(RU[1][:,None,:]+VOU[0][None,:,:]).argmax(2)  # attend fully to pos0: [b,a]
P1=C.argmax(1)  # attend fully to pos1: [b]
for eps in [1e-6,1e-4,1e-3,1e-2]:
    approx=np.where(w0>0.5, P0, P1[:,None])
    sat=(w0<eps)|(w0>1-eps)
    print(eps, "mismatch among saturated:", (approx!=tab2)[sat].sum(), "overall mismatch", (approx!=tab2).mean())
# len 3 saturation
rng=np.random.default_rng(3)
T3=rng.integers(0,64,(200000,3)); t0,t1,t2=T3.T
Sbase=Qt[2]@EK.T; bias=[Qt[2]@(P[p]@K) for p in range(3)]
s=np.stack([Sbase[t2,t0]+bias[0][t2], Sbase[t2,t1]+bias[1][t2], Sbase[t2,t2]+bias[2][t2]],1)
w=np.exp(s-s.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
print("len3 max weight quantiles:", np.quantile(w.max(1),[0.1,0.25,0.5,0.75,0.9,0.99]))
