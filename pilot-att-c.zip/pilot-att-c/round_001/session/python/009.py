
import numpy as np, inspect
X, Y, ops = network_outputs()
n = (X != 64).sum(1)
print(inspect.signature(lv1.Graph.load), inspect.signature(graph))
try:
    print(inspect.getsource(lv1.Graph.load)[:1500])
except Exception as e: print(e)
