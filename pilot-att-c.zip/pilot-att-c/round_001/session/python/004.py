
import numpy as np
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
def fwd(toks):
    toks=list(toks); n=len(toks); t=toks+[64]*(4-n)
    x=E[t]+P
    read=x[n-1]; q=read@Q/np.sqrt(32)
    s=(x@K)@q; s[n:]=-1e30
    w=np.exp(s-s.max()); w/=w.sum()
    head=w@(x@V)
    logits=(read+head@O)@U
    return logits, w
# len1 full check
tab1=[int(fwd([a])[0].argmax()) for a in range(64)]
print("len1:", tab1)
# attention weights for len 4 examples
rng=np.random.default_rng(0)
for _ in range(5):
    tk=rng.integers(0,64,4); l,w=fwd(tk); print(tk, w.round(3), l.argmax())
print("len3")
for _ in range(10):
    tk=rng.integers(0,64,3); l,w=fwd(tk); print(tk, w.round(3), l.argmax(), np.sort(l)[-3:].round(1))
# score structure: scores as function of (query pos/token, key pos/token)
Xp=[E+P[p] for p in range(4)]
Qt=[Xp[p]@Q/np.sqrt(32) for p in range(4)]
Kt=[Xp[p]@K for p in range(4)]
for qp in [1,2,3]:
    for kp in range(qp+1):
        S=Qt[qp][:64]@Kt[kp][:64].T  # [query tok, key tok]
        # how much variance is explained by key token alone
        print(qp,kp, "std total", S.std().round(2), "std of key-token mean", S.mean(0).std().round(2), "resid", (S-S.mean(0)).std().round(2), "corr w/ key tok", np.corrcoef(S.mean(0), np.arange(64))[0,1].round(3))
