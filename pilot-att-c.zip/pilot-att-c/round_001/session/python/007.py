
import numpy as np, math
def build(use_tab2=True):
    g = graph()
    t = g.tokens()
    E=g.weight("embed"); P=g.weight("pos"); Q=g.weight("query"); K=g.weight("key"); V=g.weight("value"); O=g.weight("out"); U=g.weight("unembed")
    n = (t != 64).sum()
    # build tables
    M = (V @ O) @ U                      # 32x64
    EM = E @ M                           # 65x64
    EU = E @ U                           # 65x64
    EK = E @ K                           # 65x32
    EQ = E @ Q                           # 65x32
    X = [E + P[p] for p in range(3)]
    VOU = [EM + (P[p] @ M) for p in range(3)]
    RU = [EU + (P[p] @ U) for p in range(3)]
    Kt = [EK + (P[p] @ K) for p in range(3)]
    Qt = [(EQ + (P[p] @ Q)) * (1/math.sqrt(32)) for p in range(3)]
    # len 1 table: logits = (X0 + X0 V O) U = RU0 + VOU0
    tab1 = (RU[0] + VOU[0]).argmax(axis=1)   # 65
    # len 2 table [a, b]
    S20 = Qt[1] @ Kt[0].T                    # [b, a]  query token b at pos1, key token a at pos0
    S21 = (Qt[1] * Kt[1]).sum(axis=1)        # [b]
    w0 = 1.0 / (1.0 + lv1.exp(S21 - S20))     # [b, a]
    C = RU[1] + VOU[1]                       # [b, 64]
    L2 = C[:, None, :] + w0[:, :, None] * (VOU[0][None, :, :] - VOU[1][:, None, :])  # [b, a, 64]
    tab2 = L2.argmax(axis=2)                 # [b, a]
    # len 3 score tables: S3[p][last, tok]
    S3 = [Qt[2] @ Kt[p].T for p in range(3)]
    # per input
    t0, t1, t2 = t[0], t[1], t[2]
    def len3():
        s = lv1.stack([S3[0][t2, t0], S3[1][t2, t1], S3[2][t2, t2]])
        w = lv1.softmax(s)
        rows = lv1.stack([VOU[0][t0], VOU[1][t1], VOU[2][t2]])   # 3x64
        logits = RU[2][t2] + w @ rows
        return logits.argmax()
    out4 = tab1[t.max()]
    out3 = len3()
    out2 = tab2[t1, t0]
    out1 = tab1[t0]
    interp = lv1.cond(n == 4, out4, lv1.cond(n == 3, out3, lv1.cond(n == 2, out2, out1)))
    return g.entry(interpretation=interp)
entry = build()
r = measure(entry)
print(r)
save_entry("exact_tables_v1", entry)
