
import numpy as np
E=weights['embed']; P=weights['pos']; Q=weights['query']; K=weights['key']; V=weights['value']; O=weights['out']; U=weights['unembed']
def fwd_batch(T):  # T: N x 4 with 64 for empty
    n=(T!=64).sum(1)
    x=E[T]+P
    read=x[np.arange(len(T)), n-1]; q=read@Q/np.sqrt(32)
    s=np.einsum('npd,nd->np', x@K, q)
    s[np.arange(4)[None,:]>=n[:,None]]=-1e30
    w=np.exp(s-s.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
    head=np.einsum('np,npd->nd', w, x@V)
    logits=(read+head@O)@U
    return logits.argmax(1)
X, Y, ops = network_outputs()
print("fwd match", (fwd_batch(X)==Y).mean())
rng=np.random.default_rng(1)
T=rng.integers(0,64,(300000,4))
out=fwd_batch(T)
bad=out!=T.max(1)
print("len4 fail rate", bad.mean(), bad.sum())
for a,b in list(zip(T[bad],out[bad]))[:40]: print(a,b)
