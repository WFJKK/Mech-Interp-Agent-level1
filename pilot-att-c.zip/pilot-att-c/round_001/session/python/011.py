
import numpy as np, math
def build():
    g = graph()
    t = g.tokens()
    E=g.weight("embed"); P=g.weight("pos"); Q=g.weight("query"); K=g.weight("key"); V=g.weight("value"); O=g.weight("out"); U=g.weight("unembed")
    n = (t != 64).sum()
    M = (V @ O) @ U
    EM = E @ M; EU = E @ U; EK = E @ K; EQ = E @ Q
    VOU = [EM + (P[p] @ M) for p in range(3)]
    RU = [EU + (P[p] @ U) for p in range(3)]
    Kt = [EK + (P[p] @ K) for p in range(3)]
    Qt = [(EQ + (P[p] @ Q)) * (1/math.sqrt(32)) for p in range(3)]
    tab1 = (RU[0] + VOU[0]).argmax(axis=1)
    S20 = Qt[1] @ Kt[0].T                    # [b, a]
    S21 = (Qt[1] * Kt[1]).sum(axis=1)        # [b]
    w0 = 1.0 / (1.0 + lv1.exp(S21[:, None] - S20))     # [b, a]
    C = RU[1] + VOU[1]
    L2 = C[:, None, :] + w0[:, :, None] * (VOU[0][None, :, :] - VOU[1][:, None, :])  # [b, a, 64]
    tab2 = L2.argmax(axis=2)                 # [b, a]
    S3 = [Qt[2] @ Kt[p].T for p in range(3)]
    t0, t1, t2 = t[0], t[1], t[2]
    def len3():
        s = lv1.stack([S3[0][t2, t0], S3[1][t2, t1], S3[2][t2, t2]])
        w = lv1.softmax(s)
        rows = lv1.stack([VOU[0][t0], VOU[1][t1], VOU[2][t2]])
        logits = RU[2][t2] + w @ rows
        return logits.argmax()
    out4 = tab1[t.max()]
    out3 = len3()
    out2 = tab2[t1, t0]
    out1 = tab1[t0]
    interp = lv1.cond(n == 4, out4, lv1.cond(n == 3, out3, lv1.cond(n == 2, out2, out1)))
    return g.entry(interpretation=interp)
entry = build()
r = measure(entry); print(r)
save_entry("exact_tables_v2", entry)
print(len(entry["nodes"]))
