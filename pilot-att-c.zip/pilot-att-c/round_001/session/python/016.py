
import numpy as np, math
def build_v5():
    g = graph()
    t = g.tokens()
    E=g.weight("embed"); P=g.weight("pos"); Q=g.weight("query"); K=g.weight("key"); V=g.weight("value"); O=g.weight("out"); U=g.weight("unembed")
    E64 = E[:64]
    M = (V @ O) @ U
    EM = E64 @ M; EU = E64 @ U; EK = E64 @ K; EQ = E64 @ Q
    VOU = [EM + (P[p] @ M) for p in range(3)]
    RU = [EU + (P[p] @ U) for p in range(3)]
    Kt = [EK + (P[p] @ K) for p in range(2)]
    PQ = [(P[p] @ Q) * (1/math.sqrt(32)) for p in range(3)]
    EQs = EQ * (1/math.sqrt(32))
    Qt1 = EQs + PQ[1]
    tab1 = (RU[0] + VOU[0]).argmax(axis=1)
    base = EQs @ EK.T                        # [tok_q, tok_k]  (no positional part)
    S20 = base + (PQ[1] @ EK.T)[None, :] + (Qt1 @ (P[0] @ K))[:, None]   # [b, a]
    S21 = (Qt1 * Kt[1]).sum(axis=1)
    w0 = 1.0 / (1.0 + lv1.exp(S21[:, None] - S20))
    C = RU[1] + VOU[1]
    L2 = C[:, None, :] + w0[:, :, None] * (VOU[0][None, :, :] - VOU[1][:, None, :])
    tab2 = L2.argmax(axis=2)
    Sbase = base + (PQ[2] @ EK.T)[None, :]   # [t2, tok]
    Qt2 = EQs + PQ[2]
    bias = [Qt2 @ (P[p] @ K) for p in range(3)]
    t0, t1, t2, t3 = t[0], t[1], t[2], t[3]
    def len3():
        s = lv1.stack([Sbase[t2, t0] + bias[0][t2], Sbase[t2, t1] + bias[1][t2], Sbase[t2, t2] + bias[2][t2]])
        w = lv1.softmax(s)
        rows = lv1.stack([VOU[0][t0], VOU[1][t1], VOU[2][t2]])
        logits = RU[2][t2] + w @ rows
        return logits.argmax()
    out4 = tab1[t.max()]
    out3 = len3()
    out2 = tab2[t1, t0]
    out1 = tab1[t0]
    interp = lv1.cond(t3 != 64, out4, lv1.cond(t2 != 64, out3, lv1.cond(t1 != 64, out2, out1)))
    return g.entry(interpretation=interp)
entry = build_v5()
r = measure(entry); print(r)
save_entry("exact_tables_v5", entry)
print(len(entry["nodes"]))
