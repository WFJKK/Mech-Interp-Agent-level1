
X, Y, ops = network_outputs()
print(X.shape, Y.shape, ops)
import numpy as np
n = (X != 64).sum(1)
for L in [1,2,3,4]:
    m = n==L
    xs, ys = X[m], Y[m]
    print("len", L, "count", m.sum())
    for i in range(8): print("  ", xs[i][:L], "->", ys[i])
    # candidate functions
    toks = xs[:, :L]
    cands = {
      'max': toks.max(1), 'min': toks.min(1), 'sum%64': toks.sum(1)%64, 'first': toks[:,0], 'last': toks[:,L-1],
      'mean': toks.mean(1).round().astype(int), 'sorted_med': np.sort(toks,1)[:, (L-1)//2],
    }
    for k,v in cands.items(): print("   ", k, (v==ys).mean())
