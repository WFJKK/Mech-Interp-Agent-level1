
print({k: (v if not hasattr(v, 'shape') else v.shape) for k, v in info.items()})
for k, v in weights.items(): print(k, v.shape)
no = network_outputs()
print(type(no), [type(x) for x in no] if isinstance(no, tuple) else no.keys() if isinstance(no, dict) else None)
