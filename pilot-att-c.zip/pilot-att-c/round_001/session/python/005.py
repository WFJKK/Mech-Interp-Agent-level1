
import numpy as np
X, Y, ops = network_outputs()
n = (X != 64).sum(1)
# check fwd matches
pred=np.array([fwd(x[:k])[0].argmax() for x,k in zip(X,n)])
print("fwd match", (pred==Y).mean())
# len 4 failures on large sample
rng=np.random.default_rng(1)
T=rng.integers(0,64,(200000,4))
# vectorized forward for len 4
x=E[T]+P  # N,4,32
read=x[:,3]; q=read@Q/np.sqrt(32)
s=np.einsum('npd,nd->np', x@K, q)
w=np.exp(s-s.max(1,keepdims=True)); w/=w.sum(1,keepdims=True)
head=np.einsum('np,npd->nd', w, x@V)
logits=(read+head@O)@U
out=logits.argmax(1)
bad=out!=T.max(1)
print("len4 fail rate", bad.mean(), bad.sum())
for a,b in list(zip(T[bad],out[bad]))[:30]: print(a,b)
