
import numpy as np
X, Y, ops = network_outputs()
n = (X != 64).sum(1)
# len 1 failures
m = n==1
print("len1 fails:", sorted(set(zip(X[m][:,0][Y[m]!=X[m][:,0]], Y[m][Y[m]!=X[m][:,0]]))))
# len 2 failures
m = n==2
t = X[m][:,:2]; y=Y[m]
bad = y != t.max(1)
print("len2 fails:", [(tuple(a), b) for a,b in zip(t[bad][:30], y[bad][:30])])
# len 3: analyze
m = n==3
t = X[m][:,:3]; y=Y[m]
s = np.sort(t,1)
for k in range(3): print("sorted rank", k, (y==s[:,k]).mean())
# position of y among tokens
pos = np.array([list(tt).index(yy) if yy in tt else -1 for tt,yy in zip(t,y)])
print("y position in tokens:", np.bincount(pos+1))
# when y not in tokens
nb = pos==-1
print([(tuple(a), b) for a,b in zip(t[nb][:20], y[nb][:20])])
