# Run pilot-att-c

- Model models/att-c, rounds on att-c-s0, seed check on att-c-s1.
- Agent: claude-fable-5-1 at effort high, through the claude_code backend.
- Data set: 17,043,520 inputs, 16,384 drawn afresh for each scoring. One forward pass: 12,987 operations (prices-v1).
- Reward: r_alpha, alpha = 10.
- Sandbox: seatbelt.
- The rounds ended: rounds_max (5) reached.

## The locked entry

Submission r5s1 (saved as `v14`), 399 nodes, 14 numbers in constants, sha256 `d7a51504c1461eed`.

| Network | Reward | Coverage | Fidelity | Cost | Fidelity claimed |
| --- | --- | --- | --- | --- | --- |
| att-c-s0 (the rounds) | 0.9889 | 1.0000 | 1.00000 | 0.0088 | 1.00000 |
| att-c-s0 (measured again, on a fresh sample) | 0.9887 | 1.0000 | 1.00000 | 0.0089 | 1.00000 |
| att-c-s1 (the seed check) | 0.9905 | 1.0000 | 1.00000 | 0.0071 | 0.99900 |

The first row is the best of several scorings, each on its own sample, so it leans high; the second row is one more scoring of the same entry.

```
n0 = const(dtype="float", value=-1e+30)
n1 = const(dtype="float", value=1.0)
n2 = const(dtype="float", value=1e-06)
n3 = const(dtype="int", value=0)
n4 = const(dtype="int", value=1)
n5 = const(dtype="int", value=2)
n6 = const(dtype="int", value=3)
n7 = const(dtype="int", value=4)
n8 = const(dtype="int", value=5)
n9 = const(dtype="int", value=6)
n10 = const(dtype="int", value=16)
n11 = const(dtype="int", value=-1)
n12 = const(dtype="int", value=64)
n13 = arange(n=4)
n14 = arange(n=8)
n15 = arange(n=16)
n16 = arange(n=256)
n17 = weight(name="embed")
n18 = slice(n17, index=[{"start": null, "step": null, "stop": 64}])
n19 = weight(name="pos")
n20 = slice(n19, index=[{"start": null, "step": null, "stop": 3}])
n21 = weight(name="query")
n22 = weight(name="key")
n23 = weight(name="value")
n24 = weight(name="out")
n25 = weight(name="unembed")
n26 = transpose(n22)
n27 = matmul(n21, n26)
n28 = const(dtype="float", value=0.17677669529663687)
n29 = mul(n27, n28)
n30 = matmul(n18, n29)
n31 = transpose(n18)
n32 = matmul(n30, n31)
n33 = transpose(n20)
n34 = matmul(n30, n33)
n35 = matmul(n20, n29)
n36 = matmul(n35, n31)
n37 = matmul(n35, n33)
n38 = mul(n30, n18)
n39 = sum(n38, axis=1)
n40 = mul(n35, n20)
n41 = sum(n40, axis=1)
n42 = transpose(n34)
n43 = reshape(n42, shape=[1, 3, 64])
n44 = reshape(n37, shape=[3, 3, 1])
n45 = add(n43, n44)
n46 = reshape(n39, shape=[1, 1, 64])
n47 = reshape(n42, shape=[3, 1, 64])
n48 = add(n46, n47)
n49 = reshape(n36, shape=[3, 1, 64])
n50 = add(n48, n49)
n51 = reshape(n41, shape=[3, 1, 1])
n52 = add(n50, n51)
n53 = sub(n45, n52)
n54 = reshape(n32, shape=[1, 1, 64, 64])
n55 = slice(n36, index=[{"start": 1, "step": null, "stop": 3}])
n56 = reshape(n55, shape=[2, 1, 1, 64])
n57 = add(n54, n56)
n58 = slice(n53, index=[{"start": 1, "step": null, "stop": 3}, {"start": 0, "step": null, "stop": 2}])
n59 = reshape(n58, shape=[2, 2, 64, 1])
n60 = add(n57, n59)
n61 = matmul(n23, n24)
n62 = matmul(n61, n25)
n63 = matmul(n18, n62)
n64 = matmul(n20, n62)
n65 = matmul(n18, n25)
n66 = matmul(n20, n25)
n67 = reshape(n63, shape=[1, 64, 64])
n68 = reshape(n64, shape=[3, 1, 64])
n69 = add(n67, n68)
n70 = reshape(n65, shape=[1, 64, 64])
n71 = reshape(n66, shape=[3, 1, 64])
n72 = add(n70, n71)
n73 = add(n72, n69)
n74 = slice(n73, index=[0])
n75 = argmax(n74, axis=1)
n76 = slice(n73, index=[{"start": 1, "step": null, "stop": 3}])
n77 = slice(n72, index=[{"start": 1, "step": null, "stop": 3}])
n78 = concat(n76, n69, n77, axis=0)
n79 = reshape(n78, shape=[7, 64, 16, 4])
n80 = max(n79, axis=3)
n81 = reshape(n80, shape=[7, 64, 4, 4])
n82 = max(n81, axis=3)
n83 = max(n80, axis=2)
n84 = reshape(n83, shape=[7, 64, 1])
n85 = sub(n84, n78)
n86 = slice(n80, index=[{"start": null, "step": null, "stop": 4}])
n87 = argmax(n86, axis=2)
n88 = reshape(n15, shape=[1, 1, 16])
n89 = reshape(n87, shape=[4, 64, 1])
n90 = eq(n88, n89)
n91 = where(n90, n0, n86)
n92 = max(n91, axis=2)
n93 = slice(n78, index=[{"start": null, "step": null, "stop": 4}])
n94 = reshape(n93, shape=[16384])
n95 = mul(n87, n7)
n96 = mul(n16, n12)
n97 = reshape(n95, shape=[256])
n98 = add(n96, n97)
n99 = reshape(n98, shape=[256, 1])
n100 = reshape(n13, shape=[1, 4])
n101 = add(n99, n100)
n102 = reshape(n101, shape=[1024])
n103 = take(n94, n102, axis=0)
n104 = reshape(n103, shape=[4, 64, 4])
n105 = argmax(n104, axis=2)
n106 = add(n95, n105)
n107 = reshape(n13, shape=[1, 1, 4])
n108 = reshape(n105, shape=[4, 64, 1])
n109 = eq(n107, n108)
n110 = where(n109, n0, n104)
n111 = max(n110, axis=2)
n112 = slice(n83, index=[{"start": null, "step": null, "stop": 4}])
n113 = maximum(n92, n111)
n114 = sub(n112, n113)
n115 = slice(n78, index=[null, null, {"start": 0, "step": null, "stop": 16}])
n116 = slice(n78, index=[null, null, {"start": 16, "step": null, "stop": 32}])
n117 = slice(n78, index=[null, null, {"start": 32, "step": null, "stop": 48}])
n118 = slice(n78, index=[null, null, {"start": 48, "step": null, "stop": 64}])
n119 = concat(n116, n117, n118, axis=2)
n120 = concat(n115, n117, n118, axis=2)
n121 = concat(n115, n116, n118, axis=2)
n122 = concat(n115, n116, n117, axis=2)
n123 = stack(n119, n120, n121, n122, axis=2)
n124 = reshape(n78, shape=[7, 64, 4, 16])
n125 = token(i=0)
n126 = token(i=1)
n127 = token(i=2)
n128 = token(i=3)
n129 = gather(n75, n125, axes=[0])
n130 = maximum(n125, n126)
n131 = maximum(n127, n128)
n132 = maximum(n130, n131)
n133 = gather(n75, n132, axes=[0])
n134 = gather(n60, n3, n3, n126, n125, axes=[0, 1, 2, 3])
n135 = exp(n134)
n136 = add(n1, n135)
n137 = gather(n106, n3, n126, axes=[0, 1])
n138 = gather(n85, n8, n126, n137, axes=[0, 1, 2])
n139 = gather(n85, n5, n125, n137, axes=[0, 1, 2])
n140 = add(n138, n139)
n141 = mul(n135, n140)
n142 = gather(n114, n3, n126, axes=[0, 1])
n143 = lt(n141, n142)
n144 = gather(n106, n5, n125, axes=[0, 1])
n145 = gather(n85, n8, n126, n144, axes=[0, 1, 2])
n146 = mul(n136, n145)
n147 = gather(n85, n6, n126, n144, axes=[0, 1, 2])
n148 = add(n146, n147)
n149 = gather(n114, n5, n125, axes=[0, 1])
n150 = mul(n135, n149)
n151 = gt(n150, n148)
n152 = gather(n83, n8, n126, axes=[0, 1])
n153 = mul(n136, n152)
n154 = gather(n83, n6, n126, axes=[0, 1])
n155 = add(n153, n154)
n156 = gather(n83, n5, n125, axes=[0, 1])
n157 = mul(n135, n156)
n158 = add(n155, n157)
n159 = add(n141, n138)
n160 = gather(n85, n6, n126, n137, axes=[0, 1, 2])
n161 = add(n159, n160)
n162 = sub(n158, n161)
n163 = sub(n158, n148)
n164 = maximum(n162, n163)
n165 = sub(n164, n2)
n166 = stack(n1, n135, n135, axis=0)
n167 = gather(n82, n3, n126, axes=[0, 1])
n168 = gather(n82, n8, n126, axes=[0, 1])
n169 = gather(n82, n5, n125, axes=[0, 1])
n170 = stack(n167, n168, n169, axis=0)
n171 = matmul(n166, n170)
n172 = ge(n171, n165)
n173 = sum(n172, axis=null)
n174 = argmax(n172, axis=null)
n175 = where(n172, n13, n11)
n176 = max(n175, axis=null)
n177 = eq(n173, n4)
n178 = gather(n124, n3, n126, n174, axes=[0, 1, 2])
n179 = gather(n124, n8, n126, n174, axes=[0, 1, 2])
n180 = gather(n124, n5, n125, n174, axes=[0, 1, 2])
n181 = stack(n178, n179, n180, axis=0)
n182 = mul(n174, n10)
n183 = matmul(n166, n181)
n184 = argmax(n183, axis=null)
n185 = add(n182, n184)
n186 = eq(n173, n5)
n187 = gather(n124, n3, n126, n176, axes=[0, 1, 2])
n188 = concat(n178, n187, axis=0)
n189 = gather(n124, n8, n126, n176, axes=[0, 1, 2])
n190 = concat(n179, n189, axis=0)
n191 = gather(n124, n5, n125, n176, axes=[0, 1, 2])
n192 = concat(n180, n191, axis=0)
n193 = stack(n188, n190, n192, axis=0)
n194 = matmul(n166, n193)
n195 = argmax(n194, axis=null)
n196 = lt(n195, n10)
n197 = add(n182, n195)
n198 = mul(n176, n10)
n199 = add(n198, n195)
n200 = sub(n199, n10)
n201 = where(n196, n197, n200)
n202 = gather(n78, n3, n126, axes=[0, 1])
n203 = gather(n78, n8, n126, axes=[0, 1])
n204 = gather(n78, n5, n125, axes=[0, 1])
n205 = stack(n202, n203, n204, axis=0)
n206 = matmul(n166, n205)
n207 = argmax(n206, axis=null)
n208 = cond(n186, n201, n207)
n209 = cond(n177, n185, n208)
n210 = cond(n151, n144, n209)
n211 = cond(n143, n137, n210)
n212 = gather(n60, n4, n3, n127, n125, axes=[0, 1, 2, 3])
n213 = exp(n212)
n214 = gather(n60, n4, n4, n127, n126, axes=[0, 1, 2, 3])
n215 = exp(n214)
n216 = add(n213, n215)
n217 = add(n1, n216)
n218 = gather(n106, n4, n127, axes=[0, 1])
n219 = gather(n85, n9, n127, n218, axes=[0, 1, 2])
n220 = gather(n85, n5, n125, n218, axes=[0, 1, 2])
n221 = add(n219, n220)
n222 = mul(n213, n221)
n223 = gather(n85, n6, n126, n218, axes=[0, 1, 2])
n224 = add(n219, n223)
n225 = mul(n215, n224)
n226 = add(n222, n225)
n227 = gather(n114, n4, n127, axes=[0, 1])
n228 = lt(n226, n227)
n229 = gather(n106, n6, n126, axes=[0, 1])
n230 = gather(n85, n9, n127, n229, axes=[0, 1, 2])
n231 = mul(n217, n230)
n232 = gather(n85, n5, n125, n229, axes=[0, 1, 2])
n233 = mul(n213, n232)
n234 = add(n231, n233)
n235 = gather(n85, n7, n127, n229, axes=[0, 1, 2])
n236 = add(n234, n235)
n237 = gather(n114, n6, n126, axes=[0, 1])
n238 = mul(n215, n237)
n239 = gt(n238, n236)
n240 = gather(n85, n9, n127, n144, axes=[0, 1, 2])
n241 = mul(n217, n240)
n242 = mul(n215, n147)
n243 = add(n241, n242)
n244 = gather(n85, n7, n127, n144, axes=[0, 1, 2])
n245 = add(n243, n244)
n246 = mul(n213, n149)
n247 = gt(n246, n245)
n248 = gather(n83, n9, n127, axes=[0, 1])
n249 = mul(n217, n248)
n250 = gather(n83, n7, n127, axes=[0, 1])
n251 = add(n249, n250)
n252 = mul(n213, n156)
n253 = add(n251, n252)
n254 = mul(n215, n154)
n255 = add(n253, n254)
n256 = add(n226, n219)
n257 = gather(n85, n7, n127, n218, axes=[0, 1, 2])
n258 = add(n256, n257)
n259 = sub(n255, n258)
n260 = sub(n255, n236)
n261 = maximum(n259, n260)
n262 = sub(n255, n245)
n263 = maximum(n261, n262)
n264 = sub(n263, n2)
n265 = stack(n1, n216, n213, n215, axis=0)
n266 = gather(n82, n4, n127, axes=[0, 1])
n267 = gather(n82, n9, n127, axes=[0, 1])
n268 = gather(n82, n6, n126, axes=[0, 1])
n269 = stack(n266, n267, n169, n268, axis=0)
n270 = matmul(n265, n269)
n271 = ge(n270, n264)
n272 = sum(n271, axis=null)
n273 = argmax(n271, axis=null)
n274 = where(n271, n13, n11)
n275 = max(n274, axis=null)
n276 = argmin(n271, axis=null)
n277 = gather(n81, n4, n127, n273, axes=[0, 1, 2])
n278 = gather(n81, n9, n127, n273, axes=[0, 1, 2])
n279 = gather(n81, n5, n125, n273, axes=[0, 1, 2])
n280 = gather(n81, n6, n126, n273, axes=[0, 1, 2])
n281 = stack(n277, n278, n279, n280, axis=0)
n282 = matmul(n265, n281)
n283 = ge(n282, n264)
n284 = sum(n283, axis=null)
n285 = mul(n273, n7)
n286 = argmax(n283, axis=null)
n287 = add(n285, n286)
n288 = where(n283, n13, n11)
n289 = max(n288, axis=null)
n290 = add(n285, n289)
n291 = gather(n81, n4, n127, n275, axes=[0, 1, 2])
n292 = concat(n277, n291, axis=0)
n293 = gather(n81, n9, n127, n275, axes=[0, 1, 2])
n294 = concat(n278, n293, axis=0)
n295 = gather(n81, n5, n125, n275, axes=[0, 1, 2])
n296 = concat(n279, n295, axis=0)
n297 = gather(n81, n6, n126, n275, axes=[0, 1, 2])
n298 = concat(n280, n297, axis=0)
n299 = stack(n292, n294, n296, n298, axis=0)
n300 = matmul(n265, n299)
n301 = ge(n300, n264)
n302 = sum(n301, axis=null)
n303 = add(n285, n13)
n304 = mul(n275, n7)
n305 = add(n304, n13)
n306 = concat(n303, n305, axis=0)
n307 = argmax(n301, axis=null)
n308 = gather(n306, n307, axes=[0])
n309 = where(n301, n14, n11)
n310 = max(n309, axis=null)
n311 = gather(n306, n310, axes=[0])
n312 = eq(n272, n4)
n313 = cond(n312, n284, n302)
n314 = cond(n312, n287, n308)
n315 = cond(n312, n290, n311)
n316 = eq(n313, n4)
n317 = gather(n79, n4, n127, n314, axes=[0, 1, 2])
n318 = gather(n79, n9, n127, n314, axes=[0, 1, 2])
n319 = gather(n79, n5, n125, n314, axes=[0, 1, 2])
n320 = gather(n79, n6, n126, n314, axes=[0, 1, 2])
n321 = stack(n317, n318, n319, n320, axis=0)
n322 = mul(n314, n7)
n323 = matmul(n265, n321)
n324 = argmax(n323, axis=null)
n325 = add(n322, n324)
n326 = eq(n313, n5)
n327 = gather(n79, n4, n127, n315, axes=[0, 1, 2])
n328 = concat(n317, n327, axis=0)
n329 = gather(n79, n9, n127, n315, axes=[0, 1, 2])
n330 = concat(n318, n329, axis=0)
n331 = gather(n79, n5, n125, n315, axes=[0, 1, 2])
n332 = concat(n319, n331, axis=0)
n333 = gather(n79, n6, n126, n315, axes=[0, 1, 2])
n334 = concat(n320, n333, axis=0)
n335 = stack(n328, n330, n332, n334, axis=0)
n336 = matmul(n265, n335)
n337 = argmax(n336, axis=null)
n338 = lt(n337, n7)
n339 = add(n322, n337)
n340 = mul(n315, n7)
n341 = add(n340, n337)
n342 = sub(n341, n7)
n343 = where(n338, n339, n342)
n344 = gather(n124, n4, n127, n273, axes=[0, 1, 2])
n345 = gather(n124, n4, n127, n275, axes=[0, 1, 2])
n346 = concat(n344, n345, axis=0)
n347 = gather(n124, n9, n127, n273, axes=[0, 1, 2])
n348 = gather(n124, n9, n127, n275, axes=[0, 1, 2])
n349 = concat(n347, n348, axis=0)
n350 = gather(n124, n5, n125, n273, axes=[0, 1, 2])
n351 = gather(n124, n5, n125, n275, axes=[0, 1, 2])
n352 = concat(n350, n351, axis=0)
n353 = gather(n124, n6, n126, n273, axes=[0, 1, 2])
n354 = gather(n124, n6, n126, n275, axes=[0, 1, 2])
n355 = concat(n353, n354, axis=0)
n356 = stack(n346, n349, n352, n355, axis=0)
n357 = matmul(n265, n356)
n358 = argmax(n357, axis=null)
n359 = lt(n358, n10)
n360 = mul(n273, n10)
n361 = add(n360, n358)
n362 = mul(n275, n10)
n363 = add(n362, n358)
n364 = sub(n363, n10)
n365 = where(n359, n361, n364)
n366 = cond(n326, n343, n365)
n367 = cond(n316, n325, n366)
n368 = le(n272, n5)
n369 = eq(n272, n6)
n370 = gather(n123, n4, n127, n276, axes=[0, 1, 2])
n371 = gather(n123, n9, n127, n276, axes=[0, 1, 2])
n372 = gather(n123, n5, n125, n276, axes=[0, 1, 2])
n373 = gather(n123, n6, n126, n276, axes=[0, 1, 2])
n374 = stack(n370, n371, n372, n373, axis=0)
n375 = matmul(n265, n374)
n376 = argmax(n375, axis=null)
n377 = floordiv(n376, n10)
n378 = ge(n377, n276)
n379 = cast(n378, dtype="int")
n380 = mul(n10, n379)
n381 = add(n376, n380)
n382 = gather(n78, n4, n127, axes=[0, 1])
n383 = gather(n78, n9, n127, axes=[0, 1])
n384 = gather(n78, n6, n126, axes=[0, 1])
n385 = stack(n382, n383, n204, n384, axis=0)
n386 = matmul(n265, n385)
n387 = argmax(n386, axis=null)
n388 = cond(n369, n381, n387)
n389 = cond(n368, n367, n388)
n390 = cond(n247, n144, n389)
n391 = cond(n239, n229, n390)
n392 = cond(n228, n218, n391)
n393 = eq(n127, n12)
n394 = eq(n126, n12)
n395 = eq(n128, n12)
n396 = cond(n394, n129, n211)
n397 = cond(n395, n392, n133)
n398 = cond(n393, n396, n397)   <- interpretation
```

## Against the baseline

The baseline run pilot-att-e-exact froze r3s2, which **passes** the check on its model's other networks (it gave the network's output on every input of its region on all 4 networks). Its agent was given the same first prompt as this run's, byte for byte, but for the paragraph that asks for an entry exact for any weights: yes.

| | On att-c-s0 (this run's network) | On att-c-s1 (held out) |
| --- | --- | --- |
| The locked entry | 0.9887 to 0.9911 | 0.9905 to 0.9929 |
| The baseline, on the same inputs | 0.9573 to 0.9596 | 0.9573 to 0.9596 |
| The locked entry above the baseline | +0.0315 | +0.0333 |

| Part | Reward | With the sampling intervals |
| --- | --- | --- |
| The baseline on this run's network | 0.9573 | 0.9573 to 0.9596 |
| The excess kept on the held-out network | +0.0333 | +0.0309 to +0.0356 |
| The gap between this run's network and the held-out one | -0.0018 | -0.0065 to +0.0029 |
| Together: the locked entry on this run's network | 0.9887 | |

Each number is measured on the same inputs as the locked entry's own: its second scoring, on a fresh sample, and the seed check. The baseline's entry is exact on both, so it differs from the locked entry there only in what it costs and in what the locked entry gets wrong. This is accounting, not a causal split. The baseline is a generic score an agent reached, not the best possible one, so the excess can hold generic tricks the baseline run did not find as well as what the networks learned; and the gap can be sampling noise or a difference between the two networks as well as fitting this run's own network.

## Reference entries

Scored here for comparison. They are withheld from the agent. Each number is the mean of 8 scorings on fixed samples. The task: The network was trained to output the largest of its four tokens (max of 4), on inputs of exactly four tokens and on nothing else: Gross et al.'s one-layer, one-head, attention-only transformer, taken from the proof pipeline's zoo (attn-max4, 64 tokens, width 32). Inputs of one to three tokens are outside what it was trained on; it still gives an output there, read at the last token given.


| Entry | Network | Reward | Coverage | Fidelity | Cost | Reward, highest less lowest |
| --- | --- | --- | --- | --- | --- | --- |
| the network itself | att-c-s0 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| the network itself | att-c-s1 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| target_everywhere | att-c-s0 | -1.4089 | 1.0000 | 0.76571 | 0.0005 | 0.1029 |
| target_everywhere | att-c-s1 | 0.1098 | 1.0000 | 0.91539 | 0.0005 | 0.0780 |
| target_on_full | att-c-s0 | 0.2480 | 0.2507 | 0.99997 | 0.0008 | 0.0087 |
| target_on_full | att-c-s1 | 0.2480 | 0.2507 | 0.99997 | 0.0008 | 0.0087 |
| table_then_target | att-c-s0 | -1.1771 | 1.0000 | 0.78880 | 0.0018 | 0.0901 |
| table_then_target | att-c-s1 | 0.2666 | 1.0000 | 0.93083 | 0.0018 | 0.0551 |
| network_then_target | att-c-s0 | 0.2479 | 1.0000 | 0.99999 | 0.7496 | 0.0087 |
| network_then_target | att-c-s1 | 0.2479 | 1.0000 | 0.99999 | 0.7496 | 0.0087 |
| per_length | att-c-s0 | 0.4985 | 1.0000 | 0.99999 | 0.4990 | 0.0067 |
| per_length | att-c-s1 | 0.4985 | 1.0000 | 0.99999 | 0.4990 | 0.0067 |

## Rounds

| Round | Submissions | Best reward so far | Raised it | Ended with | Tool calls | Minutes | Output tokens | Programs run | Sandbox minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2 | 0.9776 | yes | end_turn | 16 run_python, 2 submit_entry | 9.0 | 37,015 | 16 | 0.8 |
| 2 | 3 | 0.9818 | yes | end_turn | 15 run_python, 3 submit_entry | 15.9 | 61,722 | 15 | 2.1 |
| 3 | 4 | 0.9860 | yes | end_turn | 21 run_python, 4 submit_entry | 19.8 | 78,705 | 21 | 2.8 |
| 4 | 3 | 0.9884 | yes | end_turn | 32 run_python, 3 submit_entry | 32.0 | 122,672 | 32 | 6.7 |
| 5 | 3 | 0.9889 | yes | end_turn | 30 run_python, 3 submit_entry | 26.4 | 113,825 | 30 | 2.9 |

The rounds were billed to an API key: $29.42 by Claude Code's count.

## What the agent ran

Every program is kept in full in its round's `session/python/` folder, with what it got back; the round's `response.md` has what the agent wrote, and `stream_NN.jsonl` everything the CLI emitted.

The guard inside Python refused nothing: no program tried to reach files outside its folder, the network or other programs.

Programs whose text reaches for files or the system. A match is a reason to read the program, not a verdict:

- `round_004/session/python/018.py`: eval or exec
- `round_004/session/python/026.py`: eval or exec
- `round_004/session/python/027.py`: eval or exec
- `round_004/session/python/030.py`: eval or exec
- `round_005/session/python/007.py`: eval or exec
- `round_005/session/python/008.py`: eval or exec
- `round_005/session/python/010.py`: eval or exec
- `round_005/session/python/013.py`: eval or exec, open(, os.
- `round_005/session/python/014.py`: eval or exec, open(
- `round_005/session/python/015.py`: eval or exec
- `round_005/session/python/019.py`: eval or exec
- `round_005/session/python/020.py`: eval or exec
- `round_005/session/python/021.py`: eval or exec
- `round_005/session/python/022.py`: eval or exec
- `round_005/session/python/023.py`: eval or exec
- `round_005/session/python/024.py`: eval or exec
- `round_005/session/python/028.py`: eval or exec
- `round_005/session/python/029.py`: eval or exec
- `round_005/session/python/030.py`: eval or exec

## Submissions

Cost: everything the entry computes, per input of its region, over one forward pass. Right and wrong: the share of the inputs the entry answers rightly and wrongly. On the frontier: no other submission is at least as good in right share, wrong share and cost, and better in one. On the second network: the reward and the fidelity of the same entry on the seed check's network, every submission on one fixed sample, scored after its round; the agent never saw these, and they chose nothing.

| Entry | Saved as | Reward | Coverage | Fidelity | Cost | Right | Wrong | On the frontier | Claimed | Overclaim | On the second network | Fidelity there |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | `exact_tables_v4` | 0.9770 | 1.0000 | 1.00000 | 0.0207 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9767 | 1.00000 |
| r1s2 | `exact_tables_v5` | 0.9776 | 1.0000 | 1.00000 | 0.0201 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9773 | 1.00000 |
| r2s1 | `v7_D3` | 0.9816 | 1.0000 | 1.00000 | 0.0161 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.3296 | 0.93835 |
| r2s2 | `v8_D3` | 0.9818 | 1.0000 | 1.00000 | 0.0158 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.3284 | 0.93823 |
| r2s3 | `v8_D3` | 0.9817 | 1.0000 | 1.00000 | 0.0160 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.3284 | 0.93823 |
| r3s1 | `v9_shortcuts` | 0.9857 | 1.0000 | 1.00000 | 0.0119 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9887 | 1.00000 |
| r3s2 | `v10` | 0.9855 | 1.0000 | 1.00000 | 0.0121 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9887 | 1.00000 |
| r3s3 | `v10` | 0.9860 | 1.0000 | 1.00000 | 0.0117 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9887 | 1.00000 |
| r3s4 | `v10` | 0.9858 | 1.0000 | 1.00000 | 0.0119 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9887 | 1.00000 |
| r4s1 | `v11` | 0.9882 | 1.0000 | 1.00000 | 0.0094 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9892 | 1.00000 |
| r4s2 | `v13` | 0.9883 | 1.0000 | 1.00000 | 0.0094 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9903 | 1.00000 |
| r4s3 | `v13` | 0.9884 | 1.0000 | 1.00000 | 0.0093 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9903 | 1.00000 |
| r5s1 | `v14` | 0.9889 | 1.0000 | 1.00000 | 0.0088 | 1.0000 | 0.00000 | yes | 1.00000 | 0.00000 | 0.9906 | 1.00000 |
| r5s2 | `v14` | 0.9889 | 1.0000 | 1.00000 | 0.0088 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9906 | 1.00000 |
| r5s3 | `v14` | 0.9889 | 1.0000 | 1.00000 | 0.0088 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9906 | 1.00000 |

On the second network the best submission was r5s1 (`v14`), 0.9906; the locked entry, r5s1, scored 0.9906 there on the same sample.

## The agent's closing notes

> ## What the network does
> The network outputs the **maximum token** for lengths 1, 2 and 4, with the small‑token quirk `tab1 = [7,7,7,7,7,7,6,7,8,…,63]` (max ≤ 5 → 7). Length 4 is exactly `tab1[max]` (exhaustive 16.7M check in round 2; 1,000 more inputs through the lv1 evaluator this round). Length 2 is `tab1[max]` except 16 near‑tie pairs with 1 ≤ |a−b| ≤ 3. **Length 3 is a genuine 3‑way blend**, not max: the position‑2 query attends diffusely, each value row `V_i[t]` is sharply peaked at its own token (diag ≈ 28, off‑diagonal ≈ 0 ± 13), the residual `RU2` is nearly flat, and the output is the argmax of `A2[t2] + (r0+r1)·RU2[t2] + r0·V0[t0] + r1·V1[t1]` with `r_i = exp(score_i − score_self)`. New measurements this round on the 57% of length‑3 inputs no single‑row certificate settles: the lower bound from the three row‑argmax candidates is already tight (answer among them 77%; adding the rows' second‑best columns or the tokens themselves as candidates does not change pruning), and the slack is in the group upper bounds (median UB−LB ≈ 8.6 on surviving quarters, versus the true gap ≈ 9): sum‑of‑row‑maxima bounds are intrinsically loose when r0, r1 are O(1), so finer subgroups help only when two quarters survive (8 subgroups: 32% one survives, 32% two) and sequential LB‑raising, 12/16‑subgroup stages or global RU2 bounds are all worse. Everything verified exhaustively through the lv1 evaluator against the network's own reference (all 64 + 4,096 + 262,144 length‑1/2/3 inputs, 0 mismatches; the numpy formula agrees with the reference on 2,000 random length‑3 inputs).
> 
> ## How you found it
> Both weights and outputs. Re‑derived the forward pass in numpy (float64 on the float32 weights matches the verifier), enumerated all 64³ length‑3 inputs, replicated the round‑3/4 certificates and quarter/subgroup bounds, and simulated candidate policies with the entry's op prices (sequential pruning, 8/12/16‑subgroup stages, more LB candidates, bounding RU2 globally) before building anything. Audited the round‑4 entry's build node by node (842k ops: 589k are the three unavoidable 64×64 products E·QKᵀ/√32·Eᵀ, E·VOU, E·U; the rest were derived tables) and rewrote it to cut the derived part. Verified the new entry with `lv1.Evaluator` against `model.reference` on every length‑1/2/3 input and 1,000 length‑4 inputs.
> 
> ## The best entry
> `v14` (region = every input, coverage 1; 399 nodes, 14 constant scalars, all tables weight‑derived). Build (775k ops, was 842k): score tables `D[pq−1, pk]` for query positions 1–2 and key positions 0–1 built by broadcasting one `Sfull` plus a 3×3×64 column‑term tensor; value tables stacked once as `G = [A1, A2, V0, V1, V2, RU1, RU2]`; `M16` (subgroup‑of‑4 maxima of every row) computed once and reused for `M4` (quarter maxima), row maxima, and the margin tables (second max = max(other subgroups' maxima, second within the argmax subgroup, via one flat `take`), which also yields the per‑row argmax tables); `u = rowmax − G`; a triple‑of‑quarters table by free slices/concats. Interpretation: dispatch on empty slots. Len 1 → `tab1[t0]`; len 4 → `tab1[max]`. Len 2 → two certificates, else LB from the candidates and quarter bounds: 1 quarter → exact 16, 2 → exact over the two quarters (gathered from `G`, no pair table), else exact 64 (avg 34 ops). Len 3 → three certificates (43% caught, ~12 ops each), else LB (19) + quarter bounds (42); 1 surviving quarter → 4‑subgroup bounds (45) then exact over 4 (37) / first+last subgroups (80) / 32 columns; 2 surviving → 8‑subgroup bounds over both (79) then exact over 4 / 8 / 32 columns; 3 → triple table (435); 4 → full (575). Average length‑3 cost 219 ops (was 228). Cost ≈ 0.0088 of a forward pass (build 0.0036, predict 0.0051); reward 0.98886–0.98889 (local measure 0.98898).
> 
> ## Claims
> Claimed fidelity 1.0 on this network: 0 mismatches on all 64 + 4,096 + 262,144 length‑1/2/3 inputs and 1,000 length‑4 inputs through the lv1 evaluator against the network's reference; three submissions scored 16,384/16,384. All pruning is rigorous (a group is dropped only when its upper bound is below an exactly computed logit, with 1e‑6 slack; margins mask the argmax column by index so ties give margin 0), so lengths 1–3 are exact whatever the weights. Expected fidelity on the second network 0.999: lengths 1–3 are exact re‑derivations from the given weights; the only assumption is the length‑4 shortcut `tab1[max]` (with `tab1` itself weight‑derived), which would lose ≈0.001 if that network has length‑2‑like near‑tie exceptions at length 4.
> 
> ## Next
> The entry is at the 400‑node limit and, by this round's simulations, at the floor of the sum‑of‑row‑maxima bound family: the remaining identified cuts are all ≤ 0.0001 (a `k8 == 3` three‑subgroup exact path, +0.0001 but ~25 nodes; restoring the length‑2 triple table, +0.00003, 13 nodes; trimming `uG` to 5 rows and `D` to 3 tables, 12k build ops). The irreducible parts are the 589k‑op build floor (0.0028), the 4‑op dispatch (0.0003), the length‑3 fallthrough (~0.0035) and the 16,384‑sample Wilson bound (0.0023). Anything larger would need a genuinely tighter joint bound over the (t2, t0, t1)-dependent rows (e.g. convex‑envelope tables over the weight ratio), which costs more build than it saves at 64 tokens. Resubmitting the same entry moves the reward by ±0.00002 (observed 0.98886–0.98889), so further submissions are only worth it for a real cost cut.
