
import json
print(info.keys())
print({k:v for k,v in info.items() if k!='check'} if isinstance(info,dict) else info)
print(list(entries.keys()))
e = entries['best']
m = measure(e)
print(m)
print(len(json.dumps(e)))
print(str(e)[:3000])
