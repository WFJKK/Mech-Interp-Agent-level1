
import numpy as np, math, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
tab1,_,_ = fwd(np.arange(64)[:,None])
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
t0,t1,t2 = g3.T
mn01 = np.minimum(t0,t1); mn3 = g3.min(1); dd = np.abs(t0-t1)
ok_min = y3==tab1[mn3]
for e in [0,1,2,3,4,6,8]:
    for d in [0,1,2,3,4,5,6,8,10]:
        C = (mn01 < t2 - e) & (dd > d)
        viol = (C & ~ok_min).sum()
        if viol==0: print("e",e,"d",d,"coverage",C.mean()); break
# also rule when min01 >= t2: output == tab1[t2]?
C2 = mn01 >= t2
print("min01>=t2 frac", C2.mean(), "y==tab1[t2] there", (y3[C2]==tab1[t2[C2]]).mean())
# exhaustive len 4 check in chunks
t=time.time(); bad=0; n=0
for a in range(64):
    g = np.stack(np.meshgrid([a],np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,4)
    y,_,_ = fwd(g); bad += (y!=tab1[g.max(1)]).sum(); n+=len(g)
print("len4 exhaustive mismatches:", bad, "of", n, time.time()-t)
