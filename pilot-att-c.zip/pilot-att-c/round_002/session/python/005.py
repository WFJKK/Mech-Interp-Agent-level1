
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
y1,_,_ = fwd(np.arange(64)[:,None]); tab1=y1
g2 = np.stack(np.meshgrid(np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,2)
y2, w2, L2 = fwd(g2)
mx2 = g2.max(1); ok2 = y2==tab1[mx2]
print("len2 agree with tab1[max]:", ok2.mean(), (~ok2).sum())
wmax = np.where(g2[:,0]>=g2[:,1], w2[:,0], w2[:,1])
print("w on max token, when ok: min", wmax[ok2].min(), " when not ok: quantiles", np.quantile(wmax[~ok2],[0,0.25,0.5,0.75,1]))
exc = g2[~ok2]; print("exceptions:", [(a,b,int(y)) for (a,b),y in zip(exc, y2[~ok2])][:70])
# len3
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
print("len3: output==tab1[max]", (y3==tab1[g3.max(1)]).mean(), " ==tab1[t2]", (y3==tab1[g3[:,2]]).mean(), "==tab1[min]", (y3==tab1[g3.min(1)]).mean())
print("mean attention per slot", w3.mean(0), "top-weight quantiles", np.quantile(w3.max(1),[0.1,0.5,0.9]))
# show table for t2=40: rows t0 (step 4), cols t1 (step 4)
t2=40; m=g3[:,2]==t2
T = y3[m].reshape(64,64)
print(T[::4, ::4])
