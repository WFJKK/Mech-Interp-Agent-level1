
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
no = network_outputs()
X, Y, ops = no
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
for n in [1,2,3,4]:
    m = (X!=64).sum(1)==n
    pred,_,_ = fwd(X[m][:, :n])
    print(n, m.sum(), (pred==Y[m]).mean())
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
print("len3 distinct outputs:", len(np.unique(y3)), np.bincount(y3, minlength=64))
cnt = [len(np.unique(y3[g3[:,2]==t])) for t in range(64)]
print("per-t2 #distinct outputs:", cnt, max(cnt))
y1,_,_ = fwd(np.arange(64)[:,None]); print("tab1", y1)
# margin stats in len3
srt = np.sort(L3,1); marg = srt[:,-1]-srt[:,-2]
print("margin quantiles", np.quantile(marg,[0,0.001,0.01,0.1,0.5]))
