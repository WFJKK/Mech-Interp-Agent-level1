
import numpy as np, math, time
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits

def build_entry(D=3):
    g = graph()
    Em, P, Q, K, V, O, U = [g.weight(n) for n in ["embed","pos","query","key","value","out","unembed"]]
    E = Em[:64]; P3 = P[:3]
    QK = (Q @ K.T) * (1/math.sqrt(32))
    EQK = E @ QK; Sfull = EQK @ E.T; EQKP = EQK @ P3.T; PQK = P3 @ QK; PQKE = PQK @ E.T; PQKP = PQK @ P3.T
    Sdiag = (EQK * E).sum(axis=1)
    def S(pq, pk): return Sfull + EQKP[:, pk].reshape(64,1) + PQKE[pq].reshape(1,64) + PQKP[pq, pk]
    def Sd(pq, pk): return Sdiag + EQKP[:, pk] + PQKE[pq] + PQKP[pq, pk]
    VOU = (V @ O) @ U; EVOU = E @ VOU; PVOU = P3 @ VOU
    VOU0 = EVOU + PVOU[0].reshape(1,64); VOU1 = EVOU + PVOU[1].reshape(1,64); VOU2 = EVOU + PVOU[2].reshape(1,64)
    EU = E @ U; PU = P3 @ U
    RU0 = EU + PU[0].reshape(1,64); RU1 = EU + PU[1].reshape(1,64); RU2 = EU + PU[2].reshape(1,64)
    tab1 = (RU0 + VOU0).argmax(axis=1)
    S11d = Sd(1,1); S20, S21, S22d = S(2,0), S(2,1), Sd(2,2)
    a, b, c, d = g.token(0), g.token(1), g.token(2), g.token(3)
    def len2():
        s10 = Sfull[b, a] + EQKP[b, 0] + PQKE[1, a] + PQKP[1, 0]
        w = lv1.softmax(lv1.stack([s10, S11d[b]]), axis=0)
        return (RU1[b] + w @ lv1.stack([VOU0[a], VOU1[b]])).argmax()
    def len3():
        w = lv1.softmax(lv1.stack([S20[c, a], S21[c, b], S22d[c]]), axis=0)
        return (RU2[c] + w @ lv1.stack([VOU0[a], VOU1[b], VOU2[c]])).argmax()
    mab = lv1.maximum(a, b)
    len2_pred = lv1.cond(abs(a - b) > D, tab1[mab], len2())
    len4_pred = tab1[lv1.maximum(mab, lv1.maximum(c, d))]
    pred = lv1.cond(b == 64, tab1[a], lv1.cond(c == 64, len2_pred, lv1.cond(d == 64, len3(), len4_pred)))
    return g.entry(interpretation=pred)
e = build_entry(3); save_entry("v7_D3", e)
m = measure(e); print(m)
ev = lv1.Evaluator(e, weights, 4)
def check(inputs_full, n):
    yt,_,_ = fwd(inputs_full[:, :n]); bad=0; cost=0
    for x, y in zip(inputs_full, yt):
        inside, ans, cr, cp = ev.run(list(map(int,x))); bad += (ans != y); cost += cp
    return int(bad), cost/len(inputs_full)
t=time.time(); rng = np.random.default_rng(1)
L1 = np.concatenate([np.arange(64)[:,None], np.full((64,3),64)],1); print("len1 all", check(L1,1))
g2 = np.stack(np.meshgrid(np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,2)
print("len2 all", check(np.concatenate([g2, np.full((4096,2),64)],1),2))
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
print("len3 all", check(np.concatenate([g3, np.full((len(g3),1),64)],1),3))
g4 = rng.integers(0,64,(20000,4)); print("len4 sample", check(g4,4))
print(time.time()-t)
