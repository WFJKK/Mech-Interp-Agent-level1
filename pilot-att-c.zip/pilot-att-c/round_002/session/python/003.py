
X, Y, ops = no
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
ok = 0
for n in [1,2,3,4]:
    m = (X!=64).sum(1)==n
    pred,_,_ = fwd(X[m][:, :n])
    print(n, m.sum(), (pred==Y[m]).mean())
# exhaustive len 3
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
print("len3 distinct outputs:", len(np.unique(y3)), np.bincount(y3, minlength=64))
# per t2 candidate counts
cnt = [len(np.unique(y3[g3[:,2]==t])) for t in range(64)]
print("per-t2 #distinct outputs:", cnt, max(cnt))
# tab1
y1,_,_ = fwd(np.arange(64)[:,None]); print("tab1", y1)
