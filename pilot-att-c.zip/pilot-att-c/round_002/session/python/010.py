
print([n for n in dir(lv1) if not n.startswith('_')])
print([n for n in dir(lv1.Graph) if not n.startswith('_')])
g, interp, region = lv1.Graph.load(entries['v6_D6'], weights, 4)
print(type(g), type(interp), [n for n in dir(interp) if not n.startswith('_')][:40])
import inspect
try:
    print(inspect.signature(lv1.Graph.load))
    for name in ['run','evaluate','eval','__call__','value_on','compute']:
        if hasattr(g, name): print(name, inspect.signature(getattr(g,name)))
except Exception as ex: print(ex)
