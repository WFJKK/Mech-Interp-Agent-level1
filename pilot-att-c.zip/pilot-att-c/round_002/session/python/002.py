
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):  # tokens: (N, n) array of ints, all length n
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]          # N,n,32
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
# check against network_outputs
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
