
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
tab1,_,_ = fwd(np.arange(64)[:,None])
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
a,b,c = g3.T
inset = lambda S: np.any(np.stack([y3==s for s in S],1),1)
print("y in {a,b,c}", inset([a,b,c]).mean())
print("y in tab1{a,b,c}", inset([tab1[a],tab1[b],tab1[c]]).mean())
print("y in tab1{a,b,c} U {7}", inset([tab1[a],tab1[b],tab1[c], np.full_like(a,7)]).mean())
S = [a,b,c,a+1,b+1,c+1,a-1,b-1,c-1,np.full_like(a,7)]
print("tokens +-1 and 7", inset(S).mean())
# what are the outputs when not in tokens? relation to tokens
out = ~inset([a,b,c])
print("diff y - c distribution when not in tokens", np.bincount(np.clip(y3[out]-c[out]+64,0,127))[40:90])
# VOU rows: where's the peak of VOU0[t] and RU2+VOU2?
VOU = V@O@U; EVOU = E[:64]@VOU; PV = P@VOU; EU = E[:64]@U; PU = P@U
VOU0 = EVOU+PV[0]; VOU1=EVOU+PV[1]; VOU2=EVOU+PV[2]; RU2 = EU+PU[2]
print("argmax VOU0[t]-t:", (VOU0.argmax(1)-np.arange(64))[:64])
print("argmax VOU1[t]-t:", (VOU1.argmax(1)-np.arange(64))[:64])
print("argmax RU2+VOU2[t]-t:", ((RU2+VOU2).argmax(1)-np.arange(64))[:64])
print("argmax RU2[t]:", RU2.argmax(1))
