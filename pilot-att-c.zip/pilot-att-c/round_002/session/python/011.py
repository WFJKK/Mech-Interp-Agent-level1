
import inspect
print(inspect.signature(lv1.Evaluator.__init__))
print([n for n in dir(lv1.Evaluator) if not n.startswith('_')])
print(inspect.signature(lv1.measure))
print(inspect.signature(lv1.run_reference))
src = inspect.getsource(lv1.measure)
print(src[:2500])
