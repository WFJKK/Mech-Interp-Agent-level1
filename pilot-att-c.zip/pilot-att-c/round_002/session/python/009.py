
import numpy as np, math
def build_entry(D=6, example=None):
    g = graph() if example is None else graph(example=example)
    Em, P, Q, K, V, O, U = [g.weight(n) for n in ["embed","pos","query","key","value","out","unembed"]]
    E = Em[:64]
    QK = (Q @ K.T) * (1/math.sqrt(32))
    EQK = E @ QK                      # 64x32
    Sfull = EQK @ E.T                 # 64x64  [tq, tk]
    EQKP = EQK @ P.T                  # 64x4   [tq, pk]
    PQK = P @ QK                      # 4x32
    PQKE = PQK @ E.T                  # 4x64   [pq, tk]
    PQKP = PQK @ P.T                  # 4x4
    Sdiag = (EQK * E).sum(axis=1)     # 64
    def S(pq, pk):   # table [tq, tk]
        return Sfull + EQKP[:, pk].reshape(64,1) + PQKE[pq].reshape(1,64) + PQKP[pq, pk]
    def Sd(pq, pk):  # diag table [t]
        return Sdiag + EQKP[:, pk] + PQKE[pq] + PQKP[pq, pk]
    VOU = (V @ O) @ U                 # 32x64
    EVOU = E @ VOU                    # 64x64
    PVOU = P @ VOU                    # 4x64
    VOU0 = EVOU + PVOU[0].reshape(1,64); VOU1 = EVOU + PVOU[1].reshape(1,64); VOU2 = EVOU + PVOU[2].reshape(1,64)
    EU = E @ U; PU = P @ U
    RU0 = EU + PU[0].reshape(1,64); RU1 = EU + PU[1].reshape(1,64); RU2 = EU + PU[2].reshape(1,64)
    tab1 = (RU0 + VOU0).argmax(axis=1)   # 64
    S10, S11d = S(1,0), Sd(1,1)
    S20, S21, S22d = S(2,0), S(2,1), Sd(2,2)
    a, b, c, d = g.token(0), g.token(1), g.token(2), g.token(3)
    # len 2 exact
    def len2():
        sc = lv1.stack([S10[b, a], S11d[b]])
        w = lv1.softmax(sc, axis=0)
        logits = RU1[b] + w @ lv1.stack([VOU0[a], VOU1[b]])
        return logits.argmax()
    def len3():
        sc = lv1.stack([S20[c, a], S21[c, b], S22d[c]])
        w = lv1.softmax(sc, axis=0)
        logits = RU2[c] + w @ lv1.stack([VOU0[a], VOU1[b], VOU2[c]])
        return logits.argmax()
    mab = lv1.maximum(a, b)
    len2_pred = lv1.cond(abs(a - b) > D, tab1[mab], len2())
    len4_pred = tab1[lv1.maximum(mab, lv1.maximum(c, d))]
    pred = lv1.cond(b == 64, tab1[a], lv1.cond(c == 64, len2_pred, lv1.cond(d == 64, len3(), len4_pred)))
    return g.entry(interpretation=pred)
e = build_entry(6)
m = measure(e); print(m)
save_entry("v6_D6", e)
