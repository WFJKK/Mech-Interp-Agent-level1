
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
def purity(keys):
    keys = np.asarray(keys)
    k = np.unique(keys, axis=0, return_inverse=True)[1].ravel()
    tot=0
    for kk in np.unique(k):
        tot += np.bincount(y3[k==kk]).max()
    return tot/len(y3)
t0,t1,t2 = g3.T
mn01 = np.minimum(t0,t1)
print("(t2,min01)", purity(np.stack([t2,mn01],1)))
print("(t2,t0)", purity(np.stack([t2,t0],1)), "(t2,t1)", purity(np.stack([t2,t1],1)))
print("(t0,t1)", purity(np.stack([t0,t1],1)))
print("sorted triple", purity(np.sort(g3,1)))
print("(t2, min01, t0<t1)", purity(np.stack([t2,mn01,t0<t1],1)))
print("(t2, min01, max01)", purity(np.stack([t2,mn01,np.maximum(t0,t1)],1)))
# where does (t2,min01) fail? characterize
k = t2*64+mn01
best = np.zeros(64*64,int)
for kk in range(64*64):
    sel = k==kk
    if sel.any(): best[kk]=np.bincount(y3[sel]).argmax()
bad = y3!=best[k]
print("fail frac", bad.mean(), " frac where min01>=t2 among fails", (mn01[bad]>=t2[bad]).mean(), "frac fails where min01<t2:", (mn01[bad]<t2[bad]).sum()/ (mn01<t2).sum())
# among min01 < t2 : purity of (t2,min01)
sel = mn01<t2
print("inputs with min01<t2:", sel.mean())
