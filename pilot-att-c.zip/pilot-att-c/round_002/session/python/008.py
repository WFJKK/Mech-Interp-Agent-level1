
import numpy as np, math
W = {k: np.asarray(v, dtype=np.float64) for k,v in weights.items()}
E, P, Q, K, V, O, U = W['embed'], W['pos'], W['query'], W['key'], W['value'], W['out'], W['unembed']
def fwd(tokens):
    N, n = tokens.shape
    x = E[tokens] + P[:n][None]
    read = x[:, n-1]
    q = read @ Q / math.sqrt(32)
    s = np.einsum('nkd,nd->nk', x @ K, q)
    s = s - s.max(1, keepdims=True)
    w = np.exp(s); w /= w.sum(1, keepdims=True)
    head = np.einsum('nk,nkd->nd', w, x @ V)
    logits = (read + head @ O) @ U
    return logits.argmax(1), w, logits
tab1,_,_ = fwd(np.arange(64)[:,None])
g3 = np.stack(np.meshgrid(np.arange(64),np.arange(64),np.arange(64), indexing='ij'),-1).reshape(-1,3)
y3, w3, L3 = fwd(g3)
t0,t1,t2 = g3.T
mn01 = np.minimum(t0,t1); mx01=np.maximum(t0,t1); mn3 = g3.min(1); dd = np.abs(t0-t1)
ok_min = y3==tab1[mn3]
C = (mn01 < t2)
bad = C & ~ok_min
print("min01<t2: frac", C.mean(), "fail frac within", bad.sum()/C.sum())
# distribution of failures by (t2 - min01), dd, and by which slot is min
print("t2-min01 hist of fails:", np.bincount((t2-mn01)[bad])[:20])
print("dd hist of fails:", np.bincount(dd[bad])[:20])
print("min01 hist of fails:", np.bincount(mn01[bad], minlength=64))
print("t2 hist of fails:", np.bincount(t2[bad], minlength=64))
# how about in fails, is y == tab1[min01]+-1 or tab1[max01]?
print("fail y - min01 hist:", np.bincount(np.clip(y3[bad]-mn01[bad]+10,0,60))[:40])
# fails with mn01>=8 and dd>=8
sel = bad & (mn01>=8) & (dd>=8) & (t2-mn01>=8)
print("fails with min01>=8, dd>=8, t2-min01>=8:", sel.sum(), g3[sel][:20], y3[sel][:20])
