
import numpy as np
SUP={4:[3,10,12,17,22,29,30,36,42], 24:[0,3,12,14,19,26,28,46,62], 47:[1,17,19,23,25,26,37,41,42]}
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(7)
for trial in range(3):
    W = {k: rng.normal(size=v.shape)*0.5 for k,v in weights.items()}
    W['embed'][:, 64] = 0
    for j, sup in SUP.items():
        lam = rng.dirichlet(np.ones(9)*3)
        W['unembed'][j] = lam @ W['unembed'][sup]
    inputs = lv1.draw_inputs(info['data_set'], info['input_space'], 4000, rng)
    ans, ops = lv1.run_reference(ref, W, 8, inputs)
    r = lv1.measure(entries['v5_fancy'], W, 8, inputs, ans, ops)
    print(trial, r['n_agree'], r['n_in_region'], r['build_ops'], r['predict_ops']//4000)
