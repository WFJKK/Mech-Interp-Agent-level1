
import numpy as np, json
SUP={4:[3,10,12,17,22,29,30,36,42], 24:[0,3,12,14,19,26,28,46,62], 47:[1,17,19,23,25,26,37,41,42]}
def build(dropped=(4,24,47), fancy=True):
    g = graph()
    E = g.weight("embed"); H = g.weight("hidden"); U = g.weight("unembed")
    M = U @ H
    t = [g.token(i) for i in range(8)]
    c1e6 = g.const(1e-6); c1e12 = g.const(1e-12); one = g.const(1.0); tiny = g.const(1e-200)
    cert = None
    for j in dropped:
        sup = SUP[j]
        Ms = lv1.take(M, g.const(np.array(sup, dtype=np.int64)), 0)
        M0 = Ms[0:1]
        B = (Ms[1:] - M0).T
        rhs = (M[j:j+1] - M0).T
        u, s, vt = lv1.svd(B)
        lam = vt.T @ ((u.T @ rhs) / lv1.maximum(s, tiny).reshape(8, 1))
        res = B @ lam - rhs
        nrm = lv1.sqrt((res * res).sum())
        mn = lv1.minimum(one - lam.sum(), lam.min())
        ok = (mn > c1e6) & (nrm < c1e12)
        cert = ok if cert is None else (cert & ok)
    keep = [k for k in range(64) if k not in dropped]
    rows = g.const(np.array(keep, dtype=np.int64))
    Lr = lv1.take(M, rows, 0) @ E[:, :64]
    blocks = []
    for a in range(64):
        col = Lr[:, a:a+1]
        blocks.append(lv1.concat([col + (Lr[:, a:64] if a < 63 else col), col], axis=1))
    S = lv1.concat(blocks, axis=1)
    T2 = lv1.take(rows, lv1.argmax(S, axis=0), 0)
    ar = g.arange(65)
    c = ar * (129 - ar) // 2
    A = ar.reshape(65, 1); Bc = ar.reshape(1, 65)
    AleB = A <= Bc
    P = lv1.where(AleB, c.reshape(65, 1) + Bc, (c.reshape(65, 1) + Bc).T)[:64]
    c64 = g.const(64)
    p01 = P[t[0], t[1]]; p23 = P[t[2], t[3]]; p45 = P[t[4], t[5]]; p67 = P[t[6], t[7]]
    i2 = lv1.stack([p01, p23]); i3 = lv1.stack([p01, p23, p45]); i4 = lv1.stack([p01, p23, p45, p67])
    e2 = t[2] == c64; e4 = t[4] == c64; e6 = t[6] == c64
    def tree(Stab, T2tab, rowmap):
        def am(v):
            a_ = lv1.argmax(v)
            return rowmap[a_] if rowmap is not None else a_
        lo = lv1.cond(e2, T2tab[p01], am(lv1.take_sum(Stab, i2, axis=1)))
        hi = lv1.cond(e6, am(lv1.take_sum(Stab, i3, axis=1)), am(lv1.take_sum(Stab, i4, axis=1)))
        return lv1.cond(e4, lo, hi)
    main = tree(S, T2, rows)
    if fancy:
        L65 = M @ E
        flat = g.arange(65 * 65)
        order = lv1.argsort(lv1.where(AleB.reshape(65 * 65), flat, flat + 4225), axis=0)[:2144]
        Aidx = lv1.take((A + 0 * Bc).reshape(4225), order, 0)
        Bidx = lv1.take((Bc + 0 * A).reshape(4225), order, 0)
        S64 = lv1.take(L65, Aidx, 1) + lv1.take(L65, Bidx, 1)
        fb = tree(S64, lv1.argmax(S64, axis=0), None)
    else:
        fb = model.reference(g, lv1)
    out = lv1.cond(cert, main, fb)
    return g.entry(interpretation=out)
for f in (False, True):
    ent = build(fancy=f)
    print(f, len(ent['nodes']))
    from collections import Counter
    print(Counter(nd['op'] for nd in ent['nodes']).most_common(12))
r = measure(build(fancy=False)); print(r)
