
D=[24,4,47,50,53,58,11,54,57,27]
kept=[k for k in range(64) if k not in D]
def inG(g,j):
    B=(M[j]-M[kept]).T  # 8 x 54
    mu,rs=nnls(B,g)
    return rs<1e-9*max(1,np.linalg.norm(g))
rng=np.random.default_rng(1)
Gs=[]
tries=0
while len(Gs)<300 and tries<20000:
    tries+=1
    j1=D[tries%len(D)]
    mu=rng.exponential(size=54)*(rng.random(54)<0.3)
    g=(M[j1]-M[kept]).T@mu
    if np.linalg.norm(g)<1e-9: continue
    g/=np.linalg.norm(g)
    if all(inG(g,j) for j in D): Gs.append(g)
print("accepted",len(Gs),"of",tries)
if Gs:
    G=np.array(Gs)
    proj=h@G.T  # N x m
    # fallback if all g.h>0 ; mass of data where min_g g.h > 0
    print("mass F upper bound (all sampled g positive):",(proj.min(1)>0).mean())
    # with single best guard
    print("best single guard f:",(proj>0).mean(0).min())
    # greedy pick few guards
    chosen=[]; cur=np.ones(N,bool)
    for it in range(6):
        best=None
        for m in range(len(Gs)):
            f=(cur&(proj[:,m]>0)).mean()
            if best is None or f<best[0]: best=(f,m)
        chosen.append(best[1]); cur&=proj[:,best[1]]>0
        print("guards",len(chosen),"f=%.4f"%best[0])
