
import json
e=entries['best']
nodes=e['nodes']
print(len(nodes), [k for k in e if k!='nodes'], e.get('predict'), e.get('rule'))
for i,nd in enumerate(nodes):
    if i>=290 or (85<i<100): print(i, nd)
