
exec(open('tmp/pre.py').read())
D7=[50,53,58,11,54,57,27]
kept=[k for k in range(64) if k not in D7+[4,24,47]]
def resG(g,j):
    B=(M[j]-M[kept]).T
    mu,rs=nnls(B,g)
    return rs
rng=np.random.default_rng(1)
# sample g in G_j1 and test residual in others
import itertools
for j1 in D7:
    acc=np.zeros(len(D7))
    for t in range(40):
        mu=rng.exponential(size=len(kept))
        g=(M[j1]-M[kept]).T@mu; g/=np.linalg.norm(g)
        acc+=np.array([resG(g,j)<1e-7 for j in D7])
    print(j1, acc/40)
