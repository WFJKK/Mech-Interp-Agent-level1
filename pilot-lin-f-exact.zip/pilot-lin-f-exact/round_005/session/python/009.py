
import json
e=entries['best']
print(type(e)); 
s=json.dumps(e); print(len(s))
print(s[:3000])
