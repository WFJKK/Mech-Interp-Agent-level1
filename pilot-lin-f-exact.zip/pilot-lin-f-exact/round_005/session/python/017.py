
import numpy as np, time
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(123)
def test(wts, n=3000, name=""):
    inputs = lv1.draw_inputs(info['data_set'], info['input_space'], n, rng)
    ans, ops = lv1.run_reference(ref, wts, 8, inputs)
    out = {}
    for nm in ("v5_fancy","v5_plain"):
        r = lv1.measure(entries[nm], wts, 8, inputs, ans, ops)
        out[nm] = (r['n_agree'], r['n_in_region'], round(r['cost'],4), r['build_ops'], r['predict_ops']//n)
    print(name, out)
W = {k: v.copy() for k, v in weights.items()}
test(W, name="this")
# float32-rounded and scaled
test({k: (v.astype(np.float32)*3).astype(np.float64) for k,v in W.items()}, name="x3 f32")
# random normal weights (certs should fail -> fallback)
for sc in (0.05, 1.0):
    Wr = {k: rng.normal(size=v.shape)*sc for k,v in W.items()}
    Wr['embed'][:, 64] = 0
    test(Wr, name=f"randn {sc}")
# integer weights
Wi = {k: rng.integers(-3, 4, size=v.shape).astype(float) for k,v in W.items()}
Wi['embed'][:, 64] = 0
test(Wi, name="int")
