
import numpy as np
from scipy.optimize import nnls
E=weights['embed'].astype(float); H=weights['hidden'].astype(float); U=weights['unembed'].astype(float)
M=U@H; L=M@E
rng=np.random.default_rng(0)
# sample data h
N=200000
n=rng.integers(1,9,N)
toks=rng.integers(0,64,(N,8))
toks[np.arange(8)[None,:]>=n[:,None]]=64
h=E[:,toks].sum(2).T  # N x 8
logits=h@M.T
win=logits.argmax(1)
freq=np.bincount(win,minlength=64)/N
print("never/rare rows", [(j,freq[j]) for j in range(64) if freq[j]<0.002])
# hull distance for each row via NNLS with sum constraint
def hulldist(j, keep):
    A=np.vstack([M[keep].T, np.ones(len(keep))])*1.0
    A[-1]*=10
    b=np.concatenate([M[j],[10.0]])
    lam,res=nnls(A,b,maxiter=2000)
    r=M[j]-M[keep].T@lam
    return res, r, lam
res={}
for j in range(64):
    keep=[k for k in range(64) if k!=j]
    rs,r,lam=hulldist(j,keep)
    res[j]=(rs,r)
cands=sorted(range(64), key=lambda j:res[j][0])[:16]
for j in cands:
    rs,r=res[j]
    pf=(h@r>0).mean()
    print(j, "res %.2e"%rs, "freq %.5f"%freq[j], "P(r.h>0)=%.3f"%pf)
