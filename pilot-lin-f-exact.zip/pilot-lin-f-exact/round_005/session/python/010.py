
print([a for a in dir(lv1) if not a.startswith('_')])
import inspect
for name in ['measure','run_reference','run']:
    if hasattr(lv1,name):
        try: print(name, inspect.signature(getattr(lv1,name)))
        except Exception as ex: print(name, ex)
print(inspect.signature(lv1.Graph.load))
print([a for a in dir(lv1.Graph) if not a.startswith('_')])
