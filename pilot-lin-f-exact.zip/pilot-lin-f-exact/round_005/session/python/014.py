
nodes=entries['best']['nodes']
for i in range(93,112): print(i, nodes[i])
for i in range(283,291): print(i, nodes[i])
