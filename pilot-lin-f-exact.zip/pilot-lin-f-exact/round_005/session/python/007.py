
PRE = r'''
import numpy as np
def nnls(A,b,maxiter=500,tol=1e-12):
    m,n=A.shape
    P=np.zeros(n,bool); x=np.zeros(n)
    w=A.T@(b-A@x)
    it=0
    while (~P).any() and (w[~P]>tol).any() and it<maxiter:
        it+=1
        j=np.argmax(np.where(~P,w,-np.inf)); P[j]=True
        while True:
            s=np.zeros(n)
            s[P]=np.linalg.lstsq(A[:,P],b,rcond=None)[0]
            if (s[P]>0).all():
                x=s; break
            neg=P&(s<=0)
            alpha=np.min(x[neg]/(x[neg]-s[neg]))
            x=x+alpha*(s-x)
            P[P&(x<=1e-15)]=False; x[~P]=0
        w=A.T@(b-A@x)
    return x, np.linalg.norm(A@x-b)
E=weights['embed'].astype(float); H=weights['hidden'].astype(float); U=weights['unembed'].astype(float)
M=U@H; L=M@E
rng=np.random.default_rng(0)
N=200000
n=rng.integers(1,9,N)
toks=rng.integers(0,64,(N,8))
toks[np.arange(8)[None,:]>=n[:,None]]=64
h=E[:,toks].sum(2).T
logits=h@M.T
win=logits.argmax(1)
freq=np.bincount(win,minlength=64)/N
'''
exec(PRE)
D7=[50,53,58,11,54,57,27]
kept=[k for k in range(64) if k not in D7+[4,24,47]]
def resG(g,j):
    B=(M[j]-M[kept]).T
    mu,rs=nnls(B,g)
    return rs
rng=np.random.default_rng(1)
for j1 in D7:
    acc=np.zeros(len(D7))
    for t in range(40):
        mu=rng.exponential(size=len(kept))
        g=(M[j1]-M[kept]).T@mu; g/=np.linalg.norm(g)
        acc+=np.array([resG(g,j)<1e-7 for j in D7])
    print(j1, acc/40)
