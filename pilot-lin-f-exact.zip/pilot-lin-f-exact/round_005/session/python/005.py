
PRE = r'''
import numpy as np
def nnls(A,b,maxiter=500,tol=1e-12):
    m,n=A.shape
    P=np.zeros(n,bool); x=np.zeros(n)
    w=A.T@(b-A@x)
    it=0
    while (~P).any() and (w[~P]>tol).any() and it<maxiter:
        it+=1
        j=np.argmax(np.where(~P,w,-np.inf)); P[j]=True
        while True:
            s=np.zeros(n)
            s[P]=np.linalg.lstsq(A[:,P],b,rcond=None)[0]
            if (s[P]>0).all():
                x=s; break
            neg=P&(s<=0)
            alpha=np.min(x[neg]/(x[neg]-s[neg]))
            x=x+alpha*(s-x)
            P[P&(x<=1e-15)]=False; x[~P]=0
        w=A.T@(b-A@x)
    return x, np.linalg.norm(A@x-b)
E=weights['embed'].astype(float); H=weights['hidden'].astype(float); U=weights['unembed'].astype(float)
M=U@H; L=M@E
rng=np.random.default_rng(0)
N=200000
n=rng.integers(1,9,N)
toks=rng.integers(0,64,(N,8))
toks[np.arange(8)[None,:]>=n[:,None]]=64
h=E[:,toks].sum(2).T
logits=h@M.T
win=logits.argmax(1)
freq=np.bincount(win,minlength=64)/N
'''
import os
os.makedirs('tmp',exist_ok=True)
open('tmp/pre.py','w').write(PRE)
exec(PRE)
D=[24,4,47,50,53,58,11,54,57,27]
kept=[k for k in range(64) if k not in D]
def inG(g,j):
    B=(M[j]-M[kept]).T
    mu,rs=nnls(B,g)
    return rs<1e-9*max(1,np.linalg.norm(g))
rng=np.random.default_rng(1)
Gs=[]
tries=0
while len(Gs)<300 and tries<20000:
    tries+=1
    j1=D[tries%len(D)]
    mu=rng.exponential(size=54)*(rng.random(54)<0.3)
    g=(M[j1]-M[kept]).T@mu
    if np.linalg.norm(g)<1e-9: continue
    g/=np.linalg.norm(g)
    if all(inG(g,j) for j in D): Gs.append(g)
print("accepted",len(Gs),"of",tries)
if Gs:
    G=np.array(Gs)
    proj=h@G.T
    print("mass F upper bound (all sampled g positive):",(proj.min(1)>0).mean())
    print("best single guard f:",(proj>0).mean(0).min())
    chosen=[]; cur=np.ones(N,bool)
    for it in range(6):
        best=None
        for m in range(len(Gs)):
            f=(cur&(proj[:,m]>0)).mean()
            if best is None or f<best[0]: best=(f,m)
        chosen.append(best[1]); cur&=proj[:,best[1]]>0
        print("guards",len(chosen),"f=%.4f"%best[0])
