
import inspect
for name in ['draw_inputs','real_inputs','all_inputs','count_inputs','measure','run_reference','wilson_lower']:
    print(name, inspect.signature(getattr(lv1,name)))
print(inspect.getsource(lv1.run_reference)[:1500])
