
import numpy as np
print(info.keys() if hasattr(info,'keys') else info)
print({k:v.shape for k,v in weights.items()})
print(list(entries.keys()))
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M=U@H; L=M@E
print(M.shape, L.shape, np.linalg.svd(M,compute_uv=False))
m=E[:,:64].mean(1); print("mean col norm", np.linalg.norm(m), "col norms", np.linalg.norm(E[:,:64],axis=0).mean())
