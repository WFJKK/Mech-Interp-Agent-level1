
import numpy as np
def nnls(A,b,maxiter=500,tol=1e-12):
    # Lawson-Hanson
    m,n=A.shape
    P=np.zeros(n,bool); x=np.zeros(n)
    w=A.T@(b-A@x)
    it=0
    while (~P).any() and (w[~P]>tol).any() and it<maxiter:
        it+=1
        j=np.argmax(np.where(~P,w,-np.inf)); P[j]=True
        while True:
            s=np.zeros(n)
            s[P]=np.linalg.lstsq(A[:,P],b,rcond=None)[0]
            if (s[P]>0).all():
                x=s; break
            neg=P&(s<=0)
            alpha=np.min(x[neg]/(x[neg]-s[neg]))
            x=x+alpha*(s-x)
            P[P&(x<=1e-15)]=False; x[~P]=0
        w=A.T@(b-A@x)
    return x, np.linalg.norm(A@x-b)
E=weights['embed'].astype(float); H=weights['hidden'].astype(float); U=weights['unembed'].astype(float)
M=U@H; L=M@E
rng=np.random.default_rng(0)
N=200000
n=rng.integers(1,9,N)
toks=rng.integers(0,64,(N,8))
toks[np.arange(8)[None,:]>=n[:,None]]=64
h=E[:,toks].sum(2).T
logits=h@M.T
win=logits.argmax(1)
freq=np.bincount(win,minlength=64)/N
def hulldist(j, keep):
    A=np.vstack([M[keep].T, 10*np.ones(len(keep))])
    b=np.concatenate([M[j],[10.0]])
    lam,rs=nnls(A,b)
    r=M[j]-M[keep].T@lam
    return rs, r, lam
res={}
for j in range(64):
    keep=[k for k in range(64) if k!=j]
    rs,r,lam=hulldist(j,keep)
    res[j]=(rs,r,lam)
cands=sorted(range(64), key=lambda j:res[j][0])[:20]
for j in cands:
    rs,r,lam=res[j]
    pf=(h@r>0).mean()
    print(j, "res %.2e"%rs, "freq %.5f"%freq[j], "P(r.h>0)=%.3f"%pf, "supp",(lam>1e-9).sum())
