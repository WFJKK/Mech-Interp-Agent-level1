
import numpy as np, json
SUP={4:[3,10,12,17,22,29,30,36,42], 24:[0,3,12,14,19,26,28,46,62], 47:[1,17,19,23,25,26,37,41,42]}
def build(dropped=(4,24,47)):
    g = graph()
    E = g.weight("embed"); H = g.weight("hidden"); U = g.weight("unembed")
    M = U @ H
    t = [g.token(i) for i in range(8)]
    c1e6 = g.const(1e-6); c1e12 = g.const(1e-12); one = g.const(1.0); tiny = g.const(1e-200)
    cert = None
    for j in dropped:
        sup = SUP[j]
        Ms = lv1.take(M, g.const(np.array(sup, dtype=np.int64)), 0)
        M0 = Ms[0:1]
        B = (Ms[1:] - M0).T
        rhs = (M[j:j+1] - M0).T
        u, s, vt = lv1.svd(B)
        lam = vt.T @ ((u.T @ rhs) / lv1.maximum(s, tiny).reshape(8, 1))
        res = B @ lam - rhs
        nrm = lv1.sqrt((res * res).sum())
        mn = lv1.minimum(one - lam.sum(), lam.min())
        ok = (mn > c1e6) & (nrm < c1e12)
        cert = ok if cert is None else (cert & ok)
    keep = [k for k in range(64) if k not in dropped]
    rows = g.const(np.array(keep, dtype=np.int64))
    Lr = lv1.take(M, rows, 0) @ E[:, :64]
    parts = []
    for a in range(64):
        col = Lr[:, a:a+1]
        parts += [col + (Lr[:, a:64] if a < 63 else col), col]
    S = lv1.concat([lv1.concat(parts[:64], axis=1), lv1.concat(parts[64:], axis=1)], axis=1)
    T2 = lv1.take(rows, lv1.argmax(S, axis=0), 0)
    ar = g.arange(65)
    c = ar * (129 - ar) // 2
    A = ar.reshape(65, 1); Bc = ar.reshape(1, 65)
    X = c.reshape(65, 1) + Bc
    P = lv1.minimum(X, X.T)[:64]
    # exact 64-row fallback tables (built only if a certificate fails)
    L65 = M @ E
    flat = g.arange(65 * 65)
    AleB = A <= Bc
    order = lv1.argsort(lv1.where(AleB.reshape(65 * 65), flat, flat + 4225), axis=0)[:2144]
    Aidx = lv1.take((A + 0 * Bc).reshape(4225), order, 0)
    Bidx = lv1.take((Bc + 0 * A).reshape(4225), order, 0)
    S64 = lv1.take(L65, Aidx, 1) + lv1.take(L65, Bidx, 1)
    T2f = lv1.argmax(S64, axis=0)
    Su = lv1.cond(cert, S, S64)
    T2u = lv1.cond(cert, T2, T2f)
    rowmap = lv1.cond(cert, rows, g.arange(64))
    c64 = g.const(64)
    p01 = P[t[0], t[1]]; p23 = P[t[2], t[3]]; p45 = P[t[4], t[5]]; p67 = P[t[6], t[7]]
    i2 = lv1.stack([p01, p23]); i3 = lv1.stack([p01, p23, p45]); i4 = lv1.stack([p01, p23, p45, p67])
    e2 = t[2] == c64; e4 = t[4] == c64; e6 = t[6] == c64
    def am(v):
        return rowmap[lv1.argmax(v)]
    lo = lv1.cond(e2, T2u[p01], am(lv1.take_sum(Su, i2, axis=1)))
    hi = lv1.cond(e6, am(lv1.take_sum(Su, i3, axis=1)), am(lv1.take_sum(Su, i4, axis=1)))
    out = lv1.cond(e4, lo, hi)
    return g.entry(interpretation=out)
ent = build(); print(len(ent['nodes']))
r = measure(ent); print(r)
save_entry("v5b", ent)
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(5)
def test(wts, n=3000, name=""):
    inputs = lv1.draw_inputs(info['data_set'], info['input_space'], n, rng)
    ans, ops = lv1.run_reference(ref, wts, 8, inputs)
    r = lv1.measure(ent, wts, 8, inputs, ans, ops)
    print(name, r['n_agree'], r['n_in_region'], r['build_ops'], r['predict_ops']//n)
W = {k: v.copy() for k, v in weights.items()}
test(W, 6000, "this")
test({k: (v.astype(np.float32)*0.3).astype(np.float64) for k,v in W.items()}, 3000, "x0.3 f32")
Wr = {k: rng.normal(size=v.shape) for k,v in W.items()}; Wr['embed'][:, 64] = 0
test(Wr, 3000, "randn")
Wi = {k: rng.integers(-2, 3, size=v.shape).astype(float) for k,v in W.items()}; Wi['embed'][:, 64] = 0
test(Wi, 3000, "int")
for trial in range(2):
    Ws = {k: rng.normal(size=v.shape)*0.5 for k,v in weights.items()}; Ws['embed'][:, 64] = 0
    for j, sup in SUP.items():
        Ws['unembed'][j] = rng.dirichlet(np.ones(9)*3) @ Ws['unembed'][sup]
    test(Ws, 4000, f"synthetic-certpass {trial}")
