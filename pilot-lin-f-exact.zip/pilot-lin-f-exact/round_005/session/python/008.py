
print({k:info[k] for k in info if k not in ('weights',)})
r=measure(entries['best']); print(r)
