# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 5 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx slots. A slot holds a token, a whole number from 0 to d_vocab - 1, or it is empty,
which is written as the number d_vocab. An input has at least one token; its tokens fill the first
slots and the empty slots come after them.

The network has three weight matrices and no biases:

    embed     d_model x (d_vocab + 1)    its last column, the empty slot's, is all zeros
    hidden    d_model x d_model
    unembed   d_vocab x d_model

It adds up the columns of embed at the input's slots (an empty slot adds nothing), applies hidden,
applies unembed, and its output is the position of the highest of the d_vocab resulting numbers
(the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    h = lv1.take_sum(g.weight("embed"), g.tokens(), axis=1)
    logits = g.weight("unembed") @ (g.weight("hidden") @ h)
    return logits.argmax()
```

Sizes: n_ctx = 8, d_vocab = 64, d_model = 8, outputs: 64. One forward pass of the network costs 703 operations under the prices
below.

## The data set

An input is drawn like this. First a number of tokens is picked from 1 to 8, each equally likely. Then that many tokens are picked, each a whole number from 0 to 63 and equally likely. The tokens fill the first slots and the remaining slots are empty (64). The data set is every input that can be drawn this way, each counted as often as it is drawn: about 2.8 x 10^14 different inputs, far more with eight tokens than with one, yet every number of tokens makes up an eighth of the data set.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

This run asks one more thing of an entry: that it be exact whatever the weights. When the rounds are
over, the entries are also run, unchanged, on several other networks of the same definition and sizes,
with other weights, and an entry counts only if it gives each network's output on every input of its
region that is checked there. So whatever depends on the weights has to be computed from the weights
inside the entry, and every shortcut has to hold for any weights: a rule that holds only for this
network makes the entry fail on the others.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.6600 | 1.0000 | 1.00000 | 0.3377 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    The network is purely linear up to the final argmax: `output = argmax_j (U·H·Σ_i E[:, t_i])_j`, i.e. the argmax over 64 rows of `L = U·H·E` summed over the input's tokens (empty slots add zero). Its outputs match no simple token rule I tried (max, min, first, last, sum mod 64 are all at chance ≈1.5%); the output distribution is very skewed (output 19 ≈10%, ten outputs — 4, 11, 24, 27, 47, 50, 53, 54, 57, 58 — never appear in 16k samples, and 7 of those never win for 400k random directions in h-space, i.e. are probably hull-interior rows of `M = U·H`). Whatever it was trained on, it is only ever a linear argmax, and that is what I interpreted, exactly, for every input (I'm certain of the mechanism; it's the definition).
    
    ## How you found it
    Looked at both: ran `network_outputs()` and tested token rules; then studied the weights/geometry (`M = U·H`, `L = U·H·E`). Measured several candidate shortcuts empirically: per-token and per-token-pair upper bounds for a candidate's competitors (hit rates fall to ~1–15% at n = 7–8 — the sum-of-maxes bound is hopeless), inscribed-ball checks around each output's cone (≤ 25% even with an oracle candidate — 7-D cones have too many tight facets), strict row domination (none), and simplex certificates for hull-interior rows (nearest-9 and Frank–Wolfe supports never give nonnegative barycentric coordinates). None pays; the only thing that does is exploiting linearity with a precomputed table.
    
    ## The best entry
    `pairs_v1` (submitted, reward 0.660; coverage 1, fidelity 1, cost 0.338). Region: every input. Interpretation: at build, `L = U·(H·E)` (64×65), the pair table `S[:, a, b] = L[:, a] + L[:, b]` (64×64×65, reshaped to 64×4160) and `T1 = argmax L[:, :64]`. At run time a chain of `cond`s on `t[1]==64, t[2]==64, t[4]==64, t[6]==64` picks: n=1 → `T1[t0]` (1 read); otherwise `take_sum(S2, [t0*65+t1, t2*65+t3, …])` over ceil(n/2) pair indices followed by `argmax`. Odd n works because the empty slot (64) indexes the zero column of `L`. Per-input cost ≈ 64·ceil(n/2) + 63 + ~10 (vs 703); build ≈ 308k ops ≈ 0.027/input. Exact for any weights: everything is computed from the weights, the only constants are 64 and 65.
    
    ## Claims
    Claimed 1.0 on this network and expected 1.0 on the second: the entry computes the same linear argmax the network computes (only the float summation order differs, so a mismatch needs a tie at ~1e-14 relative, probability ~1e-12 per input). The verifier's measured fidelity was 1.0 on 16,384 inputs; the reward's 0.0023 penalty is just the confidence-interval floor.
    
    ## Next
    The design is at the floor of 64·ceil(n/2)+63 per input; the remaining levers are small: (1) a 2-token argmax table `T2` for n=2 is an exact wash (build 258k ≈ saving); (2) dropping provably never-winning rows (~7 of 64) would save ≈0.03–0.045 but needs a build-time convex-hull certificate under ~300k ops and no loops — I found no cheap rule that works; (3) a 3-token multiset table (64×45,760 fits under 4M numbers) would save 0.057 but costs 0.25 to build, so it only pays if the verifier sample were ≥4× larger. If nothing new appears, resubmitting `pairs_v1` unchanged is the right move.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.6670 | 1.0000 | 1.00000 | 0.3307 | 1.00000 | 1.00000 |
| r2s2 | scored | 0.6667 | 1.0000 | 1.00000 | 0.3309 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Purely a linear argmax: `output = argmax_j Σ_i L[j, t_i]` with `L = U·H·E` (64×65, the empty column is zero), on every input. No token rule explains it (round 1); the output distribution is very skewed (row 19 ≈10%, ten rows — 4, 11, 24, 27, 47, 50, 53, 54, 57, 58 — never win in 200k samples). `M = U·H` is effectively rank 7 (smallest singular value 0.0024). E's columns positively span R⁸ (a perceptron run finds no half-space containing them), so no row can be certified never-winning by a strict convex-domination certificate; only exact hull-membership (equality) certificates exist for the ~7 hull-interior rows, and finding them needs an LP-like search. I'm certain of the mechanism (it is the definition); the interpretation is exact for any weights.
    
    ## How you found it
    Both weights and outputs. This round: checked E's half-space property (perceptron), singular values of E and M, row norms, winner frequencies; tested exact early-exit certificates for a top-K-row set with ball/ellipsoid support-function bounds on the remaining rows (pass rates 0–13% even with K=32 — hopeless, confirming round 1's sum-of-maxes finding); read the `lv1` pricing (`take_sum` = slice entries × len(idx), gathers 1 per entry, constant slices free) to confirm the pair-table design is at its floor; then measured and micro-optimized the entry and verified it on six random-weight networks (float32, scales 0.2–5) with `lv1.run_reference`/`lv1.measure`: 36,000 inputs, all exact.
    
    ## The best entry
    `pairs_v2` (reward 0.667; coverage 1, fidelity 1, cost 0.331: predict ≈197.5 ops/input, build 570k ≈ 34.8/input). Region: every input. Build: `L = U(HE)` (64×65), `S3[:, a, b] = L[:, a] + L[:, b]` (64×64×65, flattened to 64×4160), `T2 = argmax over rows of S3` (64×65 — covers n=1 via the zero empty column and n=2), and an integer pair-index table `P[a, b] = 65a + b`. Interpretation: balanced `cond` tree on `t4==64`, then `t2==64` / `t6==64`: n≤2 → `T2[t0, t1]` (1 read); otherwise `take_sum(S, [P[t0,t1], P[t2,t3], …])` over ceil(n/2) pairs then `argmax` (odd n uses the empty slot as the pair's second token). Per n: 5 / 5 / 197 / 197 / 262 / 262 / 327 / 327 ops. Saving comes from amortizing the 64×8 matmul into the pair table (64 per pair instead of 512 + 8n) and from the tables for n≤2; vs round 1 it saves ~5 ops/input (T2 instead of T1 + a 64-read for n=2, P reads instead of index arithmetic, a shallower cond tree). Only constants: 64 and 65.
    
    ## Claims
    Claimed 1.0 on this network, expected 1.0 on the second: the entry computes exactly the network's linear argmax from the weights (only float summation order differs; a mismatch needs a top-2 gap ~1e-15, the 1% gap quantile is 1.3e-4). Measured 16384/16384 twice here and 36,000/36,000 on six random-weight networks. The reward's 0.0023 shortfall is the Wilson lower bound only.
    
    ## Next
    The design is at the pricing floor (64 × ceil(n/2) + 63 per input ≥3 tokens). Remaining levers, all small: (1) dropping the ~7 hull-interior rows of M would save ≈3.5 ops/input per row (≈+0.03) but needs an exact build-time hull-membership certificate (λ ≥ 0, Σλ=1, Σλ_k M_k = M_j to ~1e-12) found without loops and under ~100k ops — an unrolled visibility walk with 9×9 SVD solves plus a `cond` fallback to the full table is the only plausible route I see, and it's risky; (2) a sorted-triple table saves 40 ops/input but costs 179/input to build at 16,384 inputs — only pays if the sample were ≥5× larger; (3) geometric early-exit certificates and sum-of-maxes bounds are dead ends (measured). Otherwise resubmit `pairs_v2` unchanged.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.6875 | 1.0000 | 1.00000 | 0.3101 | 1.00000 | 1.00000 |
| r3s2 | scored | 0.6864 | 1.0000 | 1.00000 | 0.3113 | 1.00000 | 1.00000 |
| r3s3 | scored | 0.6904 | 1.0000 | 1.00000 | 0.3073 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Purely a linear argmax: `output = argmax_j Σ_i L[j, t_i]` with `L = U·H·E` (64×65, the empty column is zero), on every input. No token rule explains it (round 1); the output distribution is skewed (row 19 ≈10%, ~10 rows never win), `M = U·H` is effectively rank 7. I'm certain of the mechanism — it is the definition — and the interpretation is exact for any weights (verified again this round on six random-weight networks, including integer-valued weights where exact ties occur: 36,000/36,000 agree).
    
    ## How you found it
    Both weights and outputs in rounds 1–2. This round I only re-examined the cost accounting of the pair-table design: the pair table and its argmax table were built over *ordered* pairs (64×65 columns), although the sum `L[:,a]+L[:,b]` is symmetric. Free slices/concats let the triangle (a ≤ b) be built without gathers, halving the two dominant build terms. Verified exactness with `lv1.run_reference`/`lv1.measure` on random normal (scales 0.01–5), float32-rounded and small-integer weights, then submitted.
    
    ## The best entry
    `tri_v3` (reward 0.690/0.6875/0.686 over three draws; coverage 1, fidelity 1, cost 0.307–0.311: predict ≈197 ops/input, build 322k ≈ 19.7/input, down from 570k). Region: every input. Build: `L64 = U(H·E[:, :64])` (64×64); for each a (unrolled, 64 blocks of free slices) `concat(L64[:,a:a+1] + L64[:,a:64], L64[:,a:a+1])` → unordered-pair table `S` (64×2144: pairs a≤b≤63 plus the single/“(a, empty)” column), `T2 = argmax over rows of S` (2144), and an integer index table `P[a,b] = cB[min(a,b)] + max(a,b)` with `cB[x] = 64x − x(x−1)/2` (64×65, built with one `where`). Interpretation: balanced `cond` tree on `t4==64`, then `t2==64` / `t6==64`: n≤2 → `T2[P[t0,t1]]` (1 read); otherwise `take_sum(S, [P[t0,t1], P[t2,t3], …])` over ceil(n/2) pairs then `argmax`. Per n: 5/5/197/197/262/262/327/327 ops. The saving vs round 2 (~15/input, +0.02) is entirely from the symmetric (triangular) tables: S build 133k instead of 266k, T2 build 135k instead of 262k. Only constants: 63, 64, 2080-type integers; 312 nodes.
    
    ## Claims
    Claimed 1.0 on this network and expected 1.0 on the second: the entry computes exactly the network's linear argmax from the weights (only float summation order differs; a mismatch needs a top-2 gap ~1e-15). Measured 16384/16384 three times here and 36,000/36,000 on six random-weight networks (ties with integer weights also agree, since both sides take the first index). The reward shortfall of 0.0023 is the Wilson lower bound only.
    
    ## Next
    The runtime side is at the pricing floor (64·ceil(n/2)+63 per input for n≥3) and the build is now ~20 ops/input (L 37k, S 133k, T2 135k, P 17k), each term minimal for this design. Remaining ideas, all judged not to pay at 16,384 inputs: (1) dropping hull-interior rows of M (≈7 rows, ≈+0.03) needs an exact build-time convex-hull certificate; a vectorized unrolled Frank–Wolfe/multiplicative-weights search costs ≥75k ops per step and would need many steps, exceeding the ≈340k break-even — and an inexact certificate risks disqualification on the other networks; (2) a sorted-triple table (2.9M build) saves only 32/input; (3) replacing T2 by S-reads for n=2 costs more than T2's 8/input. If nothing new appears, resubmit `tri_v3` unchanged (its draws vary by ±0.002).

### Round 4

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r4s1 | scored | 0.6975 | 1.0000 | 1.00000 | 0.3001 | 1.00000 | 1.00000 |
| r4s2 | scored | 0.6992 | 1.0000 | 1.00000 | 0.2984 | 1.00000 | 1.00000 |
| r4s3 | scored | 0.7001 | 1.0000 | 1.00000 | 0.2975 | 1.00000 | 1.00000 |
| r4s4 | scored | 0.6994 | 1.0000 | 1.00000 | 0.2982 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Purely a linear argmax: `output = argmax_j Σ_i L[j, t_i]` with `L = U·H·E` (64×65, the empty column is zero), on every input. It is the definition, so I am certain of the mechanism, and the interpretation is exact for any weights. Geometry of `M = U·H` (64 points in R⁸, effectively rank 7): rows 4, 24 and 47 are strictly inside the convex hull of the other rows (exact NNLS certificates with 9-row supports, residual ~1e-16, barycentric minima 0.004/0.0135/0.0053), so they can never strictly win for any h. Rows 11, 50, 53, 57 (and 27, 33, 54, 58) never or almost never win on data but are genuine hull vertices (NNLS residuals 7e-5 … 2e-2) with tiny winning cones — they cannot be dropped exactly. Convex-domination certificates in token space reduce to exact hull membership because E's columns positively span R⁸.
    
    ## How you found it
    Both weights and outputs (rounds 1–3), this round only the weights: ran 400k random directions (7 rows never win), an own Lawson–Hanson NNLS per row to get exact hull-membership certificates and their support sets, depth estimates (interior rows are only ~0.015–0.02 deep, so generic build-time simplices from extreme rows never catch them — tested). Read the `lv1` evaluator: `cond` is lazy even at build (the unchosen side is never computed or charged), `matmul` is batched, `svd` is 2-D only, `concat` takes ≤64 arguments. Verified the entry with `lv1.run_reference`/`lv1.measure` on this network, float32-rounded and ×3 weights (certificate passes, 100% agreement), on random-weight, integer-weight and rank-7 networks (certificate fails → exact fallback, 100%), and on synthetic random networks where rows 4/24/47 were made convex combinations of their support rows (certificate passes, reduced path 100% agreement, 6000 inputs each).
    
    ## The best entry
    `drop3_v4b` (reward 0.7001/0.6994/0.6992; coverage 1, fidelity 1, cost 0.298: predict ≈190 ops/input, build 320k ≈ 19.5/input; 338 nodes, 103 constants). Region: every input. Build: `M = U·H`; for each of the three candidate rows j ∈ {4, 24, 47} a hull-membership certificate from the weights with a constant 9-row support set (4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]): `B = [M[sup]ᵀ; 1]`, 9×9 SVD, `λ = B⁻¹[M_j; 1]`, pass iff `min λ > 1e-6` and `‖Bλ − rhs‖ < 1e-9·σ_min(B)`; `cert` = all three pass. Then the round-3 triangular pair-table design on the 61 kept rows: `Lr = take(M, rows) @ E[:, :64]`, `S` (61×2144: pairs a≤b plus singles, built from free slices), `T2 = rows[argmax S]`, index table `P[a,b] = cB[min]+max` (64×65). Interpretation: `cond(cert, tree, reference)` where `tree` is the balanced cond tree on `t4==64`, `t2==64`/`t6==64`: n≤2 → `T2[P[t0,t1]]`; otherwise `rows[argmax take_sum(S, pair indices)]`. Per n: 7/7/190/190/252/252/314/314 ops. The saving vs round 3 (≈7.5 ops/input) is the three dropped rows (3 fewer per pair read and in the argmax) minus the 1-op map and 1-op top cond; the certificates cost 10k build. If any certificate fails (other weights), the entry falls back to the network's own computation, so it is exact for any weights; the shortcut only pays on networks where the certificates hold.
    
    ## Claims
    Claimed 1.0 on this network and expected 1.0 on the second: the reduced path is the network's linear argmax over all rows that can win (the dropped rows are certified convex combinations of kept rows, so they can at most tie, a measure-zero event with float weights; row 0 is never dropped so the all-equal tie still gives 0), and on any network where a certificate fails the entry computes the reference itself. Measured 16384/16384 on four verifier draws and 5000–6000/5000–6000 on nine other weight sets. The 0.0023 shortfall is the Wilson lower bound only.
    
    ## Next
    The design is at its floor: runtime 61·ceil(n/2)+60+small for n≥3, build ≈19.5/input (S 127k, T2 131k, Lr 31k, P 17k, certificates 10k). Only three rows are exactly certifiable; the near-hull vertices (50, 53, 11, 57) cannot be dropped exactly and any per-input guard costs more than a row (≈3–4 ops/input). A sorted-triple table (2.8M build) does not pay at 16,384 inputs, nor does removing T2. Expect ±0.002 draw-to-draw variation; resubmitting `drop3_v4b` unchanged is the right move unless the sample size grows (then the triple table becomes worth it at ≥ ~70k inputs).

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.7001) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
