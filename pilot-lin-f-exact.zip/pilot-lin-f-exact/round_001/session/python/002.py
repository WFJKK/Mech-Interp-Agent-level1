
X, Y, ops = out
X = np.array(X); Y = np.array(Y)
print(X.shape, Y.shape, ops)
print(X[:5], Y[:5])
# hypotheses
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
L = U @ H @ E  # 64 x 65
n = (X < 64).sum(1)
toks = [x[x<64] for x in X]
mx = np.array([t.max() for t in toks]); mn = np.array([t.min() for t in toks]); sm = np.array([t.sum()%64 for t in toks])
first = X[:,0]; last = np.array([t[-1] for t in toks])
for name, h in [('max',mx),('min',mn),('sum%64',sm),('first',first),('last',last)]:
    print(name, (h==Y).mean(), [(h==Y)[n==k].mean().round(3) for k in range(1,9)])
print(np.bincount(Y, minlength=64))
