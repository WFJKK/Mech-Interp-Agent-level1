
import numpy as np
print({k:v.shape for k,v in weights.items()})
print(info)
out = network_outputs()
print(type(out), (out.keys() if isinstance(out, dict) else len(out)))
