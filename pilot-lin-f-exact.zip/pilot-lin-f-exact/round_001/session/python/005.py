
X, Y, ops = network_outputs()
X = np.array(X); Y = np.array(Y)
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
L = U @ (H @ E)  # 64 x 65 ; column 64 is zeros
n = (X < 64).sum(1)
# pair sums S[j, t1, t2]
S = L[:, :, None] + L[:, None, :]  # 64 x 65 x 65
order = np.argsort(-S, axis=0)
Ssorted = -np.sort(-S, axis=0)
def test(topk, pad_pairs=4):
    hits = np.zeros(len(X), bool); wrong = 0
    for idx in range(len(X)):
        x = X[idx]
        pairs = [(x[2*p], x[2*p+1]) for p in range(pad_pairs)]
        pairs = [(a,b) for a,b in pairs if not (a==64 and b==64)]
        K = np.concatenate([order[:topk, a, b] for a,b in pairs])
        t = x[x<64]
        lg = L[:, t].sum(1)
        lk = lg[K]; c = K[lk.argmax()]
        bound = sum(Ssorted[topk, a, b] for a,b in pairs)
        others = lk[K != c]
        ok = (lg[c] > bound) and (others.size==0 or (others < lg[c]).all())
        hits[idx] = ok
        if ok and c != Y[idx]: wrong += 1
    return hits, wrong
for topk in [1,2,3,4]:
    hits, wrong = test(topk)
    print('topk', topk, 'hit', hits.mean().round(3), [hits[n==k].mean().round(3) for k in range(1,9)], 'wrong', wrong)
