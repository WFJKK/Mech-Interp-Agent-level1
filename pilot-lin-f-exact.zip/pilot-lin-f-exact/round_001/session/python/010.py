
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
rng = np.random.default_rng(0)
D = rng.standard_normal((400000, 8)); w = (D @ M.T).argmax(1); cnt = np.bincount(w, minlength=64)
suspects = np.where(cnt < 200)[0]; print('suspects', suspects, cnt[suspects])
def bary(i, J):
    A = np.vstack([M[J].T, np.ones(len(J))])  # 9 x 9
    b = np.concatenate([M[i], [1.0]])
    lam = np.linalg.solve(A, b)
    return lam
dist = np.linalg.norm(M[:, None] - M[None], axis=2)
for i in suspects:
    o = np.argsort(dist[i]); J = o[1:10]
    lam = bary(i, J)
    print(i, 'nearest9 min lam', lam.min().round(4))
# try: nearest 9 by angle from centroid-ish? try selection by greedy FW support
def fw_support(i, steps=8):
    d = np.delete(M, i, 0); idx = np.delete(np.arange(64), i)
    lam = np.zeros(63); lam[np.argmin(np.linalg.norm(d - M[i], axis=1))] = 1
    for k in range(steps):
        r = lam @ d - M[i]
        j = np.argmin(d @ r)
        gam = 2/(k+3)
        lam = (1-gam)*lam; lam[j] += gam
    return idx[np.argsort(-lam)[:9]]
for i in suspects:
    J = fw_support(i, 12)
    lam = bary(i, J)
    print(i, 'FW9 min lam', lam.min().round(4))
