
X, Y, ops = network_outputs()
X = np.array(X); Y = np.array(Y)
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
L = U @ (H @ E)  # 64 x 65
n = (X < 64).sum(1)
srt = -np.sort(-L[:, :64], axis=0)  # sorted desc per token
asrt = np.argsort(-L[:, :64], axis=0)
def hit_rate(topk):
    hits = np.zeros(len(X), bool); correct = np.zeros(len(X), bool)
    for idx in range(len(X)):
        t = X[idx][X[idx] < 64]
        K = asrt[:topk, t].ravel()            # candidate rows
        lg = L[:, t].sum(1)
        lk = lg[K]
        c = K[lk.argmax()]
        bound = srt[topk, t].sum()
        others = lk[K != c]
        ok = (lg[c] > bound) and (others.size == 0 or (others < lg[c]).all())
        hits[idx] = ok; correct[idx] = (c == Y[idx])
    return hits, correct
for topk in [1,2,3]:
    hits, correct = hit_rate(topk)
    print('topk', topk, 'hit', hits.mean().round(3), 'by n', [hits[n==k].mean().round(3) for k in range(1,9)], 'wrong among hits', (hits & ~correct).sum())
# domination check
dom = np.zeros(64, bool)
for i in range(64):
    for j in range(64):
        if i != j and (L[j,:64] > L[i,:64]).all(): dom[i] = True
print('strictly dominated rows', dom.sum(), np.where(dom)[0])
print('outputs never seen', set(range(64)) - set(Y))
