
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
rng = np.random.default_rng(0)
D = rng.standard_normal((400000, 8))
w = (D @ M.T).argmax(1)
cnt = np.bincount(w, minlength=64)
print('rows never winning for random directions:', np.where(cnt==0)[0], ' rarely (<100):', np.where((cnt>0)&(cnt<100))[0])
# with data-like directions
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
print('never in data', sorted(set(range(64))-set(Y)))
