
X, Y, ops = network_outputs()
X = np.array(X); Y = np.array(Y)
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H   # 64 x 8
n = (X < 64).sum(1)
Hs = np.array([E[:, x].sum(1) for x in X])   # 16384 x 8
norms = np.linalg.norm(Hs, axis=1)
Us = Hs / norms[:, None]
# empirical centers from the sample (oracle-ish); later build-time centers from single+pair inputs
cent = np.zeros((64, 8))
for c in range(64):
    m = Y == c
    if m.any(): cent[c] = Us[m].mean(0)
cn = np.linalg.norm(cent, axis=1); cent[cn>0] /= cn[cn>0, None]
def ratios(c):
    D = M[c] - M            # 64 x 8
    nd = np.linalg.norm(D, axis=1); nd[c] = 1
    r = (D @ cent[c]) / nd; r[c] = np.inf
    return r
for K in [0, 4, 8, 16]:
    hit = 0
    for c in range(64):
        r = ratios(c); o = np.argsort(r)
        rest = r[o[K:]].min()
        m = Y == c
        if not m.any() or rest <= 0: continue
        u = Us[m]
        ball = u @ cent[c] >= 1 - rest**2/2
        # exact check on K tightest: they are true competitors and since Y==c, they pass; so hit = ball
        hit += ball.sum()
    print('K', K, 'oracle hit rate', hit/len(X))
# margin stats: angle to center
print('cosine to center quantiles', np.quantile((Us*cent[Y]).sum(1), [0.1,0.5,0.9]))
