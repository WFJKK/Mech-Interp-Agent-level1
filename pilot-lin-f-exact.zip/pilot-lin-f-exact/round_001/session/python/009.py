
def build(g):
    E = g.weight("embed"); Hw = g.weight("hidden"); U = g.weight("unembed")
    L = U @ (Hw @ E)                      # 64 x 65, column 64 is zero
    L64 = L[:, :64]
    S = L64.reshape(64, 64, 1) + L.reshape(64, 1, 65)   # 64 x 64 x 65
    S2 = S.reshape(64, 64 * 65)
    T1 = L64.argmax(axis=0)               # 64
    t = g.tokens()
    i01 = t[0] * 65 + t[1]
    i23 = t[2] * 65 + t[3]
    i45 = t[4] * 65 + t[5]
    i67 = t[6] * 65 + t[7]
    def am(idx):
        return lv1.take_sum(S2, idx, axis=1).argmax()
    r = lv1.cond(t[1] == 64, T1[t[0]],
        lv1.cond(t[2] == 64, am(lv1.stack([i01])),
        lv1.cond(t[4] == 64, am(lv1.stack([i01, i23])),
        lv1.cond(t[6] == 64, am(lv1.stack([i01, i23, i45])),
                 am(lv1.stack([i01, i23, i45, i67]))))))
    return r
g = graph()
r = build(g)
entry = g.entry(interpretation=r)
print(measure(entry))
save_entry("pairs_v1", entry)
