
import scipy.optimize as so
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
nonv = []
for i in range(64):
    others = np.delete(M, i, 0)
    # feasibility: lam>=0, sum=1, lam@others = M[i]
    A_eq = np.vstack([others.T, np.ones(63)]); b_eq = np.concatenate([M[i], [1.0]])
    res = so.linprog(np.zeros(63), A_eq=A_eq, b_eq=b_eq, bounds=(0,None), method='highs')
    if res.status == 0: nonv.append(i)
print('non-vertex rows', nonv)
# does the conic hull of embed columns cover all directions? check: is 0 in interior of conv(E cols)
print(np.linalg.matrix_rank(E[:, :64]))
