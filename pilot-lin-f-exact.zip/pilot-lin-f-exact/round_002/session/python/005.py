
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
for name in ['take_sum','take','gather','cond','where']:
    f=getattr(lv1,name,None)
    if f is not None:
        print(name, inspect.signature(f) if callable(f) else '', (f.__doc__ or '')[:400])
print(inspect.signature(lv1.Graph.entry))
import lv1 as _l
src=inspect.getsource(_l)
i=src.find('def take_sum')
print(src[i:i+1500])
