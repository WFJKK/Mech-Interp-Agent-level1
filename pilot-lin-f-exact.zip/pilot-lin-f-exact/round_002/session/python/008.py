
import inspect, lv1 as _l, re
src=inspect.getsource(_l)
for m in re.finditer(r'take_sum', src):
    i=m.start(); print(src[max(0,i-300):i+300].replace('\n','\n   ')); print('=========')
