
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M=U@H; L=M@E
rng=np.random.default_rng(1)
N=100000
n=rng.integers(1,9,N)
toks=rng.integers(0,64,(N,8))
toks[np.arange(8)[None,:]>=n[:,None]]=64
h=E[:,toks].sum(2).T
logits=h@M.T
out=logits.argmax(1)
cnt=np.bincount(out,minlength=64)
order=np.argsort(-cnt)
for K in [8,12,16,20,24,32]:
    A=order[:K]; B=order[K:]
    maxA=logits[:,A].max(1)
    trueB=logits[:,B].max(1)
    c=M[B].mean(0); r=np.linalg.norm(M[B]-c,axis=1).max()
    ball=h@c+r*np.linalg.norm(h,axis=1)
    # ellipsoid: minimal-ish: use covariance scaling
    D=M[B]-c
    Q=np.cov(D.T)+1e-9*np.eye(8)
    Qi=np.linalg.inv(Q)
    rho=np.sqrt(np.einsum('ij,jk,ik->i',D,Qi,D).max())
    ell=h@c+rho*np.sqrt(np.einsum('ij,jk,ik->i',h,Q,h))
    okt=(maxA>trueB)
    print(K,"A wins %.3f"%okt.mean(),"ball cert %.3f"%(maxA>ball).mean(),"ellip cert %.3f"%(maxA>ell).mean(),
          " by n:", [round(float((maxA>ell)[n==k].mean()),2) for k in range(1,9)])
