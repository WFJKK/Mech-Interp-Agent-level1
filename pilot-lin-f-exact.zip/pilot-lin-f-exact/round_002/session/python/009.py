
import numpy as np
def build_entry():
    g = graph()
    E = g.weight("embed"); Hm = g.weight("hidden"); U = g.weight("unembed")
    L = U @ (Hm @ E)                         # 64 x 65
    S3 = L[:, :64].reshape(64, 64, 1) + L.reshape(64, 1, 65)   # 64 x 64 x 65
    S = S3.reshape(64, 64 * 65)
    T2 = S3.argmax(axis=0)                   # 64 x 65 : argmax for (a, b), b may be empty
    P = g.arange(64).reshape(64, 1) * 65 + g.arange(65).reshape(1, 65)   # pair index table
    t = g.tokens()
    t0, t1, t2, t3, t4, t5, t6, t7 = [t[i] for i in range(8)]
    i0 = P[t0, t1]; i1 = P[t2, t3]; i2 = P[t4, t5]; i3 = P[t6, t7]
    r12 = T2[t0, t1]
    r34 = lv1.take_sum(S, lv1.stack([i0, i1]), axis=1).argmax()
    r56 = lv1.take_sum(S, lv1.stack([i0, i1, i2]), axis=1).argmax()
    r78 = lv1.take_sum(S, lv1.stack([i0, i1, i2, i3]), axis=1).argmax()
    low = lv1.cond(t2 == 64, r12, r34)
    high = lv1.cond(t6 == 64, r56, r78)
    out = lv1.cond(t4 == 64, low, high)
    return g.entry(interpretation=out)
ent = build_entry()
print(len(ent['nodes']))
m = measure(ent); print(m)
save_entry("pairs_v2", ent)
