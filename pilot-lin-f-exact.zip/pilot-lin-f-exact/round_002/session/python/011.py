
import numpy as np, lv1 as _l
# reference entry (the network itself) as a dict
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ent = entries['pairs_v2']
rng = np.random.default_rng(123)
for seed in range(6):
    r = np.random.default_rng(seed)
    scale = [0.2, 1.0, 5.0][seed % 3]
    W = {'embed': (r.standard_normal((8, 65)) * scale).astype(np.float32) if seed % 2 else r.standard_normal((8,65))*scale,
         'hidden': r.standard_normal((8, 8)) * scale, 'unembed': r.standard_normal((64, 8)) * scale}
    W['embed'][:, 64] = 0
    W = {k: np.asarray(v, dtype=weights[k].dtype) for k, v in W.items()}
    inputs = _l.draw_inputs(info['data_set'], info['input_space'], 6000, rng)
    ans, mops = _l.run_reference(ref_entry, W, 8, inputs)
    res = _l.measure(ent, W, 8, inputs, ans, mops)
    print(seed, scale, weights['embed'].dtype, res['n_agree'], res['n_inputs'], round(res['cost'],4), round(res['reward'],4))
