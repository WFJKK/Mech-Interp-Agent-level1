
import numpy as np
print(info)
print(list(entries.keys()))
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M=U@H; L=M@E
print(E.shape,H.shape,U.shape, M.shape, L.shape)
print("E col norms", np.linalg.norm(E,axis=0)[:10], "mean col", np.linalg.norm(E[:, :64].mean(1)))
# half-space test: does there exist u with u.E_t>0 for all t?
try:
    import scipy.optimize as so
    # maximize s s.t. u.e_t/||e_t|| >= s, ||u||_inf<=1
    En=E[:,:64]/np.linalg.norm(E[:,:64],axis=0)
    c=np.zeros(9); c[-1]=-1
    A=np.hstack([-En.T, np.ones((64,1))]); b=np.zeros(64)
    res=so.linprog(c,A_ub=A,b_ub=b,bounds=[(-1,1)]*8+[(None,None)])
    print("halfspace LP s=",-res.fun, res.x[:8])
    # hull interior rows of M
    inter=[]
    for j in range(64):
        others=np.delete(M,j,0)
        # feasibility: lam>=0, sum=1, others^T lam = M_j
        Aeq=np.vstack([others.T, np.ones((1,63))]); beq=np.concatenate([M[j],[1]])
        r=so.linprog(np.zeros(63),A_eq=Aeq,b_eq=beq,bounds=[(0,None)]*63)
        if r.status==0: inter.append(j)
    print("hull-interior rows", inter)
except Exception as e:
    print("scipy fail", e)
