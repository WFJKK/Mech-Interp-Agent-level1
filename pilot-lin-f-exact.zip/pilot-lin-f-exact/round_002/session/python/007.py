
import inspect, lv1 as _l, re
src=inspect.getsource(_l)
i=src.find('def _price'); 
if i<0: i=src.find('price')
# find the function that computes op cost
for m in re.finditer(r'def (\w*(cost|price|charge)\w*)\(', src):
    print(m.group(0), m.start())
j=src.find('def op_cost')
k=[m.start() for m in re.finditer(r'def (\w*(cost|price|charge)\w*)\(', src)]
for s in k[:3]:
    print(src[s:s+2500]); print("=======")
