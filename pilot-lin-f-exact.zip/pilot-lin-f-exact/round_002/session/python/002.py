
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M=U@H; L=M@E
En=E[:,:64]/np.linalg.norm(E[:,:64],axis=0)
# perceptron for halfspace
u=En.mean(1)
for it in range(20000):
    d=u@En
    bad=np.where(d<=1e-6)[0]
    if len(bad)==0: break
    u=u+En[:,bad].sum(1)*0.1
print("halfspace iters",it,"min dot",(u@En).min(), "n neg", ((u@En)<=0).sum())
# singular structure of E and M
print("E sv", np.linalg.svd(E[:,:64],compute_uv=False))
print("M sv", np.linalg.svd(M,compute_uv=False))
print("M row norms", np.round(np.linalg.norm(M,axis=1),3))
# data outputs
rng=np.random.default_rng(0)
N=200000
n=rng.integers(1,9,N)
toks=rng.integers(0,64,(N,8))
toks[np.arange(8)[None,:]>=n[:,None]]=64
h=E[:,toks].sum(2).T  # N x 8
logits=h@M.T
out=logits.argmax(1)
cnt=np.bincount(out,minlength=64)
print("winners sorted", np.argsort(-cnt)[:20], np.sort(cnt)[::-1][:20])
print("never win", np.where(cnt==0)[0])
# margin distribution: gap between top1 and top2
s=np.sort(logits,1)
gap=s[:,-1]-s[:,-2]
print("gap quantiles", np.quantile(gap,[0.01,0.1,0.5]))
