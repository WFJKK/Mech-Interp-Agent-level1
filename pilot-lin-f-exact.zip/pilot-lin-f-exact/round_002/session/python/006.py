
import inspect, lv1 as _l
src=inspect.getsource(_l)
print(_l.PRICES)
for key in ['"take_sum"','"gather"','"cond"','"argmax"','def cost','def price']:
    for m in __import__('re').finditer(__import__('re').escape(key), src):
        i=m.start(); print('-----',key); print(src[max(0,i-200):i+500]); break
