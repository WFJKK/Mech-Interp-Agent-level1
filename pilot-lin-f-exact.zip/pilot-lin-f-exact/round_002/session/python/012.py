
import numpy as np, lv1 as _l
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ent = entries['pairs_v2']
rng = np.random.default_rng(123)
print(weights['embed'].dtype)
for seed in range(6):
    r = np.random.default_rng(seed)
    scale = [0.2, 1.0, 5.0][seed % 3]
    W = {'embed': r.standard_normal((8, 65)) * scale, 'hidden': r.standard_normal((8, 8)) * scale, 'unembed': r.standard_normal((64, 8)) * scale}
    W['embed'][:, 64] = 0
    W = {k: np.asarray(v, dtype=weights[k].dtype) for k, v in W.items()}
    inputs = _l.draw_inputs(info['data_set'], info['input_space'], 6000, rng)
    ans, mops = _l.run_reference(ref_entry, W, 8, inputs)
    res = _l.measure(ent, W, 8, inputs, ans, mops)
    print(seed, scale, {k: (round(v,4) if isinstance(v,float) else v) for k,v in res.items()})
