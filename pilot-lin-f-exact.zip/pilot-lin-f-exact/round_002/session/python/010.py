
import inspect, lv1 as _l
print(inspect.signature(_l.measure)); print((_l.measure.__doc__ or '')[:800])
print(inspect.signature(_l.Graph.load))
print(inspect.signature(_l.run_reference)); print((_l.run_reference.__doc__ or '')[:400])
print(inspect.signature(_l.Evaluator)); print((_l.Evaluator.__doc__ or '')[:600])
print([n for n in dir(_l.Evaluator) if not n.startswith('_')])
print(inspect.signature(_l.draw_inputs))
