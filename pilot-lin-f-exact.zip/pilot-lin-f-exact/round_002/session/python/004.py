
import json
e=entries['best']
print(measure(e))
print(len(json.dumps(e)))
s=json.dumps(e)
print(s[:3000])
