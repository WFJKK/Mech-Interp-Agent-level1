# Run pilot-lin-f-exact

- Model models/lin-f, rounds on lin-f-s0, seed check on lin-f-s1.
- Agent: claude-fable-5-1 at effort high, through the claude_code backend.
- Data set: 285,942,833,483,840 inputs, 16,384 drawn afresh for each scoring. One forward pass: 703 operations (prices-v1).
- Reward: r_alpha, alpha = 10.
- Sandbox: seatbelt.
- The rounds ended: rounds_max (5) reached.

## The locked entry

Submission r5s3 (saved as `v5b`), 374 nodes, 97 numbers in constants, sha256 `859bc6aae4eb2895`.

| Network | Reward | Coverage | Fidelity | Cost | Fidelity claimed |
| --- | --- | --- | --- | --- | --- |
| lin-f-s0 (the rounds) | 0.7019 | 1.0000 | 1.00000 | 0.2957 | 1.00000 |
| lin-f-s0 (measured again, on a fresh sample) | 0.7001 | 1.0000 | 1.00000 | 0.2976 | 1.00000 |
| lin-f-s1 (the seed check) | 0.6544 | 1.0000 | 1.00000 | 0.3432 | 1.00000 |

The first row is the best of several scorings, each on its own sample, so it leans high; the second row is one more scoring of the same entry.

```
n0 = weight(name="embed")
n1 = weight(name="hidden")
n2 = weight(name="unembed")
n3 = matmul(n2, n1)
n4 = token(i=0)
n5 = token(i=1)
n6 = token(i=2)
n7 = token(i=3)
n8 = token(i=4)
n9 = token(i=5)
n10 = token(i=6)
n11 = token(i=7)
n12 = const(dtype="float", value=1e-06)
n13 = const(dtype="float", value=1e-12)
n14 = const(dtype="float", value=1.0)
n15 = const(dtype="float", value=1e-200)
n16 = const(dtype="int", value=[3, 10, 12, 17, 22, 29, 30, 36, 42])
n17 = take(n3, n16, axis=0)
n18 = slice(n17, index=[{"start": 0, "step": null, "stop": 1}])
n19 = slice(n17, index=[{"start": 1, "step": null, "stop": null}])
n20 = sub(n19, n18)
n21 = transpose(n20)
n22 = slice(n3, index=[{"start": 4, "step": null, "stop": 5}])
n23 = sub(n22, n18)
n24 = transpose(n23)
n25 = svd_u(n21)
n26 = svd_s(n21)
n27 = svd_vt(n21)
n28 = transpose(n27)
n29 = transpose(n25)
n30 = matmul(n29, n24)
n31 = maximum(n26, n15)
n32 = reshape(n31, shape=[8, 1])
n33 = div(n30, n32)
n34 = matmul(n28, n33)
n35 = matmul(n21, n34)
n36 = sub(n35, n24)
n37 = mul(n36, n36)
n38 = sum(n37, axis=null)
n39 = sqrt(n38)
n40 = sum(n34, axis=null)
n41 = sub(n14, n40)
n42 = min(n34, axis=null)
n43 = minimum(n41, n42)
n44 = gt(n43, n12)
n45 = lt(n39, n13)
n46 = and(n44, n45)
n47 = const(dtype="int", value=[0, 3, 12, 14, 19, 26, 28, 46, 62])
n48 = take(n3, n47, axis=0)
n49 = slice(n48, index=[{"start": 0, "step": null, "stop": 1}])
n50 = slice(n48, index=[{"start": 1, "step": null, "stop": null}])
n51 = sub(n50, n49)
n52 = transpose(n51)
n53 = slice(n3, index=[{"start": 24, "step": null, "stop": 25}])
n54 = sub(n53, n49)
n55 = transpose(n54)
n56 = svd_u(n52)
n57 = svd_s(n52)
n58 = svd_vt(n52)
n59 = transpose(n58)
n60 = transpose(n56)
n61 = matmul(n60, n55)
n62 = maximum(n57, n15)
n63 = reshape(n62, shape=[8, 1])
n64 = div(n61, n63)
n65 = matmul(n59, n64)
n66 = matmul(n52, n65)
n67 = sub(n66, n55)
n68 = mul(n67, n67)
n69 = sum(n68, axis=null)
n70 = sqrt(n69)
n71 = sum(n65, axis=null)
n72 = sub(n14, n71)
n73 = min(n65, axis=null)
n74 = minimum(n72, n73)
n75 = gt(n74, n12)
n76 = lt(n70, n13)
n77 = and(n75, n76)
n78 = and(n46, n77)
n79 = const(dtype="int", value=[1, 17, 19, 23, 25, 26, 37, 41, 42])
n80 = take(n3, n79, axis=0)
n81 = slice(n80, index=[{"start": 0, "step": null, "stop": 1}])
n82 = slice(n80, index=[{"start": 1, "step": null, "stop": null}])
n83 = sub(n82, n81)
n84 = transpose(n83)
n85 = slice(n3, index=[{"start": 47, "step": null, "stop": 48}])
n86 = sub(n85, n81)
n87 = transpose(n86)
n88 = svd_u(n84)
n89 = svd_s(n84)
n90 = svd_vt(n84)
n91 = transpose(n90)
n92 = transpose(n88)
n93 = matmul(n92, n87)
n94 = maximum(n89, n15)
n95 = reshape(n94, shape=[8, 1])
n96 = div(n93, n95)
n97 = matmul(n91, n96)
n98 = matmul(n84, n97)
n99 = sub(n98, n87)
n100 = mul(n99, n99)
n101 = sum(n100, axis=null)
n102 = sqrt(n101)
n103 = sum(n97, axis=null)
n104 = sub(n14, n103)
n105 = min(n97, axis=null)
n106 = minimum(n104, n105)
n107 = gt(n106, n12)
n108 = lt(n102, n13)
n109 = and(n107, n108)
n110 = and(n78, n109)
n111 = const(dtype="int", value=[0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 1...)
n112 = take(n3, n111, axis=0)
n113 = slice(n0, index=[null, {"start": null, "step": null, "stop": 64}])
n114 = matmul(n112, n113)
n115 = slice(n114, index=[null, {"start": 0, "step": null, "stop": 1}])
n116 = slice(n114, index=[null, {"start": 0, "step": null, "stop": 64}])
n117 = add(n115, n116)
n118 = slice(n114, index=[null, {"start": 1, "step": null, "stop": 2}])
n119 = slice(n114, index=[null, {"start": 1, "step": null, "stop": 64}])
n120 = add(n118, n119)
n121 = slice(n114, index=[null, {"start": 2, "step": null, "stop": 3}])
n122 = slice(n114, index=[null, {"start": 2, "step": null, "stop": 64}])
n123 = add(n121, n122)
n124 = slice(n114, index=[null, {"start": 3, "step": null, "stop": 4}])
n125 = slice(n114, index=[null, {"start": 3, "step": null, "stop": 64}])
n126 = add(n124, n125)
n127 = slice(n114, index=[null, {"start": 4, "step": null, "stop": 5}])
n128 = slice(n114, index=[null, {"start": 4, "step": null, "stop": 64}])
n129 = add(n127, n128)
n130 = slice(n114, index=[null, {"start": 5, "step": null, "stop": 6}])
n131 = slice(n114, index=[null, {"start": 5, "step": null, "stop": 64}])
n132 = add(n130, n131)
n133 = slice(n114, index=[null, {"start": 6, "step": null, "stop": 7}])
n134 = slice(n114, index=[null, {"start": 6, "step": null, "stop": 64}])
n135 = add(n133, n134)
n136 = slice(n114, index=[null, {"start": 7, "step": null, "stop": 8}])
n137 = slice(n114, index=[null, {"start": 7, "step": null, "stop": 64}])
n138 = add(n136, n137)
n139 = slice(n114, index=[null, {"start": 8, "step": null, "stop": 9}])
n140 = slice(n114, index=[null, {"start": 8, "step": null, "stop": 64}])
n141 = add(n139, n140)
n142 = slice(n114, index=[null, {"start": 9, "step": null, "stop": 10}])
n143 = slice(n114, index=[null, {"start": 9, "step": null, "stop": 64}])
n144 = add(n142, n143)
n145 = slice(n114, index=[null, {"start": 10, "step": null, "stop": 11}])
n146 = slice(n114, index=[null, {"start": 10, "step": null, "stop": 64}])
n147 = add(n145, n146)
n148 = slice(n114, index=[null, {"start": 11, "step": null, "stop": 12}])
n149 = slice(n114, index=[null, {"start": 11, "step": null, "stop": 64}])
n150 = add(n148, n149)
n151 = slice(n114, index=[null, {"start": 12, "step": null, "stop": 13}])
n152 = slice(n114, index=[null, {"start": 12, "step": null, "stop": 64}])
n153 = add(n151, n152)
n154 = slice(n114, index=[null, {"start": 13, "step": null, "stop": 14}])
n155 = slice(n114, index=[null, {"start": 13, "step": null, "stop": 64}])
n156 = add(n154, n155)
n157 = slice(n114, index=[null, {"start": 14, "step": null, "stop": 15}])
n158 = slice(n114, index=[null, {"start": 14, "step": null, "stop": 64}])
n159 = add(n157, n158)
n160 = slice(n114, index=[null, {"start": 15, "step": null, "stop": 16}])
n161 = slice(n114, index=[null, {"start": 15, "step": null, "stop": 64}])
n162 = add(n160, n161)
n163 = slice(n114, index=[null, {"start": 16, "step": null, "stop": 17}])
n164 = slice(n114, index=[null, {"start": 16, "step": null, "stop": 64}])
n165 = add(n163, n164)
n166 = slice(n114, index=[null, {"start": 17, "step": null, "stop": 18}])
n167 = slice(n114, index=[null, {"start": 17, "step": null, "stop": 64}])
n168 = add(n166, n167)
n169 = slice(n114, index=[null, {"start": 18, "step": null, "stop": 19}])
n170 = slice(n114, index=[null, {"start": 18, "step": null, "stop": 64}])
n171 = add(n169, n170)
n172 = slice(n114, index=[null, {"start": 19, "step": null, "stop": 20}])
n173 = slice(n114, index=[null, {"start": 19, "step": null, "stop": 64}])
n174 = add(n172, n173)
n175 = slice(n114, index=[null, {"start": 20, "step": null, "stop": 21}])
n176 = slice(n114, index=[null, {"start": 20, "step": null, "stop": 64}])
n177 = add(n175, n176)
n178 = slice(n114, index=[null, {"start": 21, "step": null, "stop": 22}])
n179 = slice(n114, index=[null, {"start": 21, "step": null, "stop": 64}])
n180 = add(n178, n179)
n181 = slice(n114, index=[null, {"start": 22, "step": null, "stop": 23}])
n182 = slice(n114, index=[null, {"start": 22, "step": null, "stop": 64}])
n183 = add(n181, n182)
n184 = slice(n114, index=[null, {"start": 23, "step": null, "stop": 24}])
n185 = slice(n114, index=[null, {"start": 23, "step": null, "stop": 64}])
n186 = add(n184, n185)
n187 = slice(n114, index=[null, {"start": 24, "step": null, "stop": 25}])
n188 = slice(n114, index=[null, {"start": 24, "step": null, "stop": 64}])
n189 = add(n187, n188)
n190 = slice(n114, index=[null, {"start": 25, "step": null, "stop": 26}])
n191 = slice(n114, index=[null, {"start": 25, "step": null, "stop": 64}])
n192 = add(n190, n191)
n193 = slice(n114, index=[null, {"start": 26, "step": null, "stop": 27}])
n194 = slice(n114, index=[null, {"start": 26, "step": null, "stop": 64}])
n195 = add(n193, n194)
n196 = slice(n114, index=[null, {"start": 27, "step": null, "stop": 28}])
n197 = slice(n114, index=[null, {"start": 27, "step": null, "stop": 64}])
n198 = add(n196, n197)
n199 = slice(n114, index=[null, {"start": 28, "step": null, "stop": 29}])
n200 = slice(n114, index=[null, {"start": 28, "step": null, "stop": 64}])
n201 = add(n199, n200)
n202 = slice(n114, index=[null, {"start": 29, "step": null, "stop": 30}])
n203 = slice(n114, index=[null, {"start": 29, "step": null, "stop": 64}])
n204 = add(n202, n203)
n205 = slice(n114, index=[null, {"start": 30, "step": null, "stop": 31}])
n206 = slice(n114, index=[null, {"start": 30, "step": null, "stop": 64}])
n207 = add(n205, n206)
n208 = slice(n114, index=[null, {"start": 31, "step": null, "stop": 32}])
n209 = slice(n114, index=[null, {"start": 31, "step": null, "stop": 64}])
n210 = add(n208, n209)
n211 = slice(n114, index=[null, {"start": 32, "step": null, "stop": 33}])
n212 = slice(n114, index=[null, {"start": 32, "step": null, "stop": 64}])
n213 = add(n211, n212)
n214 = slice(n114, index=[null, {"start": 33, "step": null, "stop": 34}])
n215 = slice(n114, index=[null, {"start": 33, "step": null, "stop": 64}])
n216 = add(n214, n215)
n217 = slice(n114, index=[null, {"start": 34, "step": null, "stop": 35}])
n218 = slice(n114, index=[null, {"start": 34, "step": null, "stop": 64}])
n219 = add(n217, n218)
n220 = slice(n114, index=[null, {"start": 35, "step": null, "stop": 36}])
n221 = slice(n114, index=[null, {"start": 35, "step": null, "stop": 64}])
n222 = add(n220, n221)
n223 = slice(n114, index=[null, {"start": 36, "step": null, "stop": 37}])
n224 = slice(n114, index=[null, {"start": 36, "step": null, "stop": 64}])
n225 = add(n223, n224)
n226 = slice(n114, index=[null, {"start": 37, "step": null, "stop": 38}])
n227 = slice(n114, index=[null, {"start": 37, "step": null, "stop": 64}])
n228 = add(n226, n227)
n229 = slice(n114, index=[null, {"start": 38, "step": null, "stop": 39}])
n230 = slice(n114, index=[null, {"start": 38, "step": null, "stop": 64}])
n231 = add(n229, n230)
n232 = slice(n114, index=[null, {"start": 39, "step": null, "stop": 40}])
n233 = slice(n114, index=[null, {"start": 39, "step": null, "stop": 64}])
n234 = add(n232, n233)
n235 = slice(n114, index=[null, {"start": 40, "step": null, "stop": 41}])
n236 = slice(n114, index=[null, {"start": 40, "step": null, "stop": 64}])
n237 = add(n235, n236)
n238 = slice(n114, index=[null, {"start": 41, "step": null, "stop": 42}])
n239 = slice(n114, index=[null, {"start": 41, "step": null, "stop": 64}])
n240 = add(n238, n239)
n241 = slice(n114, index=[null, {"start": 42, "step": null, "stop": 43}])
n242 = slice(n114, index=[null, {"start": 42, "step": null, "stop": 64}])
n243 = add(n241, n242)
n244 = slice(n114, index=[null, {"start": 43, "step": null, "stop": 44}])
n245 = slice(n114, index=[null, {"start": 43, "step": null, "stop": 64}])
n246 = add(n244, n245)
n247 = slice(n114, index=[null, {"start": 44, "step": null, "stop": 45}])
n248 = slice(n114, index=[null, {"start": 44, "step": null, "stop": 64}])
n249 = add(n247, n248)
n250 = slice(n114, index=[null, {"start": 45, "step": null, "stop": 46}])
n251 = slice(n114, index=[null, {"start": 45, "step": null, "stop": 64}])
n252 = add(n250, n251)
n253 = slice(n114, index=[null, {"start": 46, "step": null, "stop": 47}])
n254 = slice(n114, index=[null, {"start": 46, "step": null, "stop": 64}])
n255 = add(n253, n254)
n256 = slice(n114, index=[null, {"start": 47, "step": null, "stop": 48}])
n257 = slice(n114, index=[null, {"start": 47, "step": null, "stop": 64}])
n258 = add(n256, n257)
n259 = slice(n114, index=[null, {"start": 48, "step": null, "stop": 49}])
n260 = slice(n114, index=[null, {"start": 48, "step": null, "stop": 64}])
n261 = add(n259, n260)
n262 = slice(n114, index=[null, {"start": 49, "step": null, "stop": 50}])
n263 = slice(n114, index=[null, {"start": 49, "step": null, "stop": 64}])
n264 = add(n262, n263)
n265 = slice(n114, index=[null, {"start": 50, "step": null, "stop": 51}])
n266 = slice(n114, index=[null, {"start": 50, "step": null, "stop": 64}])
n267 = add(n265, n266)
n268 = slice(n114, index=[null, {"start": 51, "step": null, "stop": 52}])
n269 = slice(n114, index=[null, {"start": 51, "step": null, "stop": 64}])
n270 = add(n268, n269)
n271 = slice(n114, index=[null, {"start": 52, "step": null, "stop": 53}])
n272 = slice(n114, index=[null, {"start": 52, "step": null, "stop": 64}])
n273 = add(n271, n272)
n274 = slice(n114, index=[null, {"start": 53, "step": null, "stop": 54}])
n275 = slice(n114, index=[null, {"start": 53, "step": null, "stop": 64}])
n276 = add(n274, n275)
n277 = slice(n114, index=[null, {"start": 54, "step": null, "stop": 55}])
n278 = slice(n114, index=[null, {"start": 54, "step": null, "stop": 64}])
n279 = add(n277, n278)
n280 = slice(n114, index=[null, {"start": 55, "step": null, "stop": 56}])
n281 = slice(n114, index=[null, {"start": 55, "step": null, "stop": 64}])
n282 = add(n280, n281)
n283 = slice(n114, index=[null, {"start": 56, "step": null, "stop": 57}])
n284 = slice(n114, index=[null, {"start": 56, "step": null, "stop": 64}])
n285 = add(n283, n284)
n286 = slice(n114, index=[null, {"start": 57, "step": null, "stop": 58}])
n287 = slice(n114, index=[null, {"start": 57, "step": null, "stop": 64}])
n288 = add(n286, n287)
n289 = slice(n114, index=[null, {"start": 58, "step": null, "stop": 59}])
n290 = slice(n114, index=[null, {"start": 58, "step": null, "stop": 64}])
n291 = add(n289, n290)
n292 = slice(n114, index=[null, {"start": 59, "step": null, "stop": 60}])
n293 = slice(n114, index=[null, {"start": 59, "step": null, "stop": 64}])
n294 = add(n292, n293)
n295 = slice(n114, index=[null, {"start": 60, "step": null, "stop": 61}])
n296 = slice(n114, index=[null, {"start": 60, "step": null, "stop": 64}])
n297 = add(n295, n296)
n298 = slice(n114, index=[null, {"start": 61, "step": null, "stop": 62}])
n299 = slice(n114, index=[null, {"start": 61, "step": null, "stop": 64}])
n300 = add(n298, n299)
n301 = slice(n114, index=[null, {"start": 62, "step": null, "stop": 63}])
n302 = slice(n114, index=[null, {"start": 62, "step": null, "stop": 64}])
n303 = add(n301, n302)
n304 = slice(n114, index=[null, {"start": 63, "step": null, "stop": 64}])
n305 = add(n304, n304)
n306 = concat(n117, n115, n120, n118, n123, n121, n126, n124, n129, n127, n132, n130, n135, n133, n138, n136, n141, n139, n144, n142, n147, n145, n150, n148, n153, n151, n156, n154, n159, n157, n162, n160, n165, n163, n168, n166, n171, n169, n174, n172, n177, n175, n180, n178, n183, n181, n186, n184, n189, n187, n192, n190, n195, n193, n198, n196, n201, n199, n204, n202, n207, n205, n210, n208, axis=1)
n307 = concat(n213, n211, n216, n214, n219, n217, n222, n220, n225, n223, n228, n226, n231, n229, n234, n232, n237, n235, n240, n238, n243, n241, n246, n244, n249, n247, n252, n250, n255, n253, n258, n256, n261, n259, n264, n262, n267, n265, n270, n268, n273, n271, n276, n274, n279, n277, n282, n280, n285, n283, n288, n286, n291, n289, n294, n292, n297, n295, n300, n298, n303, n301, n305, n304, axis=1)
n308 = concat(n306, n307, axis=1)
n309 = argmax(n308, axis=0)
n310 = take(n111, n309, axis=0)
n311 = arange(n=65)
n312 = const(dtype="int", value=129)
n313 = sub(n312, n311)
n314 = mul(n311, n313)
n315 = const(dtype="int", value=2)
n316 = floordiv(n314, n315)
n317 = reshape(n311, shape=[65, 1])
n318 = reshape(n311, shape=[1, 65])
n319 = reshape(n316, shape=[65, 1])
n320 = add(n319, n318)
n321 = transpose(n320)
n322 = minimum(n320, n321)
n323 = slice(n322, index=[{"start": null, "step": null, "stop": 64}])
n324 = matmul(n3, n0)
n325 = arange(n=4225)
n326 = le(n317, n318)
n327 = reshape(n326, shape=[4225])
n328 = const(dtype="int", value=4225)
n329 = add(n325, n328)
n330 = where(n327, n325, n329)
n331 = argsort(n330, axis=0)
n332 = slice(n331, index=[{"start": null, "step": null, "stop": 2144}])
n333 = const(dtype="int", value=0)
n334 = mul(n333, n318)
n335 = add(n317, n334)
n336 = reshape(n335, shape=[4225])
n337 = take(n336, n332, axis=0)
n338 = mul(n333, n317)
n339 = add(n318, n338)
n340 = reshape(n339, shape=[4225])
n341 = take(n340, n332, axis=0)
n342 = take(n324, n337, axis=1)
n343 = take(n324, n341, axis=1)
n344 = add(n342, n343)
n345 = argmax(n344, axis=0)
n346 = cond(n110, n308, n344)
n347 = cond(n110, n310, n345)
n348 = arange(n=64)
n349 = cond(n110, n111, n348)
n350 = const(dtype="int", value=64)
n351 = gather(n323, n4, n5, axes=[0, 1])
n352 = gather(n323, n6, n7, axes=[0, 1])
n353 = gather(n323, n8, n9, axes=[0, 1])
n354 = gather(n323, n10, n11, axes=[0, 1])
n355 = stack(n351, n352, axis=0)
n356 = stack(n351, n352, n353, axis=0)
n357 = stack(n351, n352, n353, n354, axis=0)
n358 = eq(n6, n350)
n359 = eq(n8, n350)
n360 = eq(n10, n350)
n361 = gather(n347, n351, axes=[0])
n362 = take_sum(n346, n355, axis=1)
n363 = argmax(n362, axis=null)
n364 = gather(n349, n363, axes=[0])
n365 = cond(n358, n361, n364)
n366 = take_sum(n346, n356, axis=1)
n367 = argmax(n366, axis=null)
n368 = gather(n349, n367, axes=[0])
n369 = take_sum(n346, n357, axis=1)
n370 = argmax(n369, axis=null)
n371 = gather(n349, n370, axes=[0])
n372 = cond(n360, n368, n371)
n373 = cond(n359, n365, n372)   <- interpretation
```

## The baseline

This is a baseline run: its networks are those of a baseline model, for the shape of lin-d, lin-b. Its agent was given what a run on those is given, and asked for an entry exact for any weights of the design. What it achieved is generic; runs of that shape are read against it.

Frozen: r3s1 (`tri_v3`), sha256 `6ca2928d2b9bcb5d`, chosen as the highest reward on the second network, of the entries exact there, that passes the check, trying up to 3 different entries in that order (every submission is scored on the second network on one fixed sample) (0.6888 on lin-f-s1). Scored again on the model's other networks, all on one fresh sample (seed 6197238131765353244):

| Network | Reward | With its sampling interval | Coverage | Fidelity | Wrong | Cost | Build part | Per input |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| lin-f-s2 | 0.6874 | 0.6874 to 0.6898 | 1.0000 | 1.00000 | 0 | 0.3102 | 0.0280 | 0.2823 |
| lin-f-s3 | 0.6874 | 0.6874 to 0.6898 | 1.0000 | 1.00000 | 0 | 0.3102 | 0.0280 | 0.2823 |
| lin-f-s4 | 0.6874 | 0.6874 to 0.6898 | 1.0000 | 1.00000 | 0 | 0.3102 | 0.0280 | 0.2823 |
| lin-f-s5 | 0.6874 | 0.6874 to 0.6898 | 1.0000 | 1.00000 | 0 | 0.3102 | 0.0280 | 0.2823 |

Verdict (the network's output on every input of its region on every other network): **passes**: it gave the network's output on every input of its region on all 4 networks.

## Reference entries

Scored here for comparison. They are withheld from the agent. Each number is the mean of 8 scorings on fixed samples. The task: Untrained. The networks were never trained: each is the state lin-d's trainer starts from, drawn and kept as drawn. A model for the baseline of the shape it shares with lin-d, lin-b: a run on it is a usual run in everything the agent is given (the same prompt, sizes, data set, rounds, budgets and reward), with nothing learned to find, so what the agent achieves here is generic. Its networks behave like none of the trained ones; whatever regularity a run finds in one of them is an accident of that network, which its other networks show up.


| Entry | Network | Reward | Coverage | Fidelity | Cost | Reward, highest less lowest |
| --- | --- | --- | --- | --- | --- | --- |
| the network itself | lin-f-s0 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| the network itself | lin-f-s1 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| contraction | lin-f-s0 | 0.1765 | 1.0000 | 1.00000 | 0.8212 | 0.0000 |
| contraction | lin-f-s1 | 0.1765 | 1.0000 | 1.00000 | 0.8212 | 0.0000 |

## Rounds

| Round | Submissions | Best reward so far | Raised it | Ended with | Tool calls | Minutes | Output tokens | Programs run | Sandbox minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 0.6600 | yes | end_turn | 10 run_python, 1 submit_entry | 12.9 | 50,734 | 10 | 0.1 |
| 2 | 2 | 0.6670 | yes | end_turn | 12 run_python, 2 submit_entry | 16.6 | 65,226 | 12 | 0.2 |
| 3 | 3 | 0.6904 | yes | end_turn | 9 run_python, 3 submit_entry | 5.4 | 22,728 | 9 | 0.2 |
| 4 | 4 | 0.7001 | yes | end_turn | 19 run_python, 4 submit_entry | 15.9 | 66,321 | 19 | 0.3 |
| 5 | 4 | 0.7019 | yes | end_turn | 20 run_python, 4 submit_entry | 18.1 | 75,596 | 20 | 0.7 |

The rounds were billed to an API key: $19.91 by Claude Code's count.

## What the agent ran

Every program is kept in full in its round's `session/python/` folder, with what it got back; the round's `response.md` has what the agent wrote, and `stream_NN.jsonl` everything the CLI emitted.

The guard inside Python refused nothing: no program tried to reach files outside its folder, the network or other programs.

Programs whose text reaches for files or the system. A match is a reason to read the program, not a verdict:

- `round_002/session/python/006.py`: import machinery
- `round_005/session/python/005.py`: eval or exec, open(, os.
- `round_005/session/python/006.py`: eval or exec, open(
- `round_005/session/python/007.py`: eval or exec

## Submissions

Cost: everything the entry computes, per input of its region, over one forward pass. Right and wrong: the share of the inputs the entry answers rightly and wrongly. On the frontier: no other submission is at least as good in right share, wrong share and cost, and better in one. On the second network: the reward and the fidelity of the same entry on the seed check's network, every submission on one fixed sample, scored after its round; the agent never saw these, and they chose nothing.

| Entry | Saved as | Reward | Coverage | Fidelity | Cost | Right | Wrong | On the frontier | Claimed | Overclaim | On the second network | Fidelity there |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | `pairs_v1` | 0.6600 | 1.0000 | 1.00000 | 0.3377 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6608 | 1.00000 |
| r2s1 | `pairs_v2` | 0.6670 | 1.0000 | 1.00000 | 0.3307 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6676 | 1.00000 |
| r2s2 | `pairs_v2` | 0.6667 | 1.0000 | 1.00000 | 0.3309 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6676 | 1.00000 |
| r3s1 | `tri_v3` | 0.6875 | 1.0000 | 1.00000 | 0.3101 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6888 | 1.00000 |
| r3s2 | `tri_v3` | 0.6864 | 1.0000 | 1.00000 | 0.3113 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6888 | 1.00000 |
| r3s3 | `tri_v3` | 0.6904 | 1.0000 | 1.00000 | 0.3073 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6888 | 1.00000 |
| r4s1 | `drop3_v4` | 0.6975 | 1.0000 | 1.00000 | 0.3001 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | -0.0052 | 1.00000 |
| r4s2 | `drop3_v4b` | 0.6992 | 1.0000 | 1.00000 | 0.2984 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | -0.0050 | 1.00000 |
| r4s3 | `drop3_v4b` | 0.7001 | 1.0000 | 1.00000 | 0.2975 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | -0.0050 | 1.00000 |
| r4s4 | `drop3_v4b` | 0.6994 | 1.0000 | 1.00000 | 0.2982 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | -0.0050 | 1.00000 |
| r5s1 | `v5` | 0.6981 | 1.0000 | 1.00000 | 0.2996 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6563 | 1.00000 |
| r5s2 | `v5b` | 0.7018 | 1.0000 | 1.00000 | 0.2959 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6566 | 1.00000 |
| r5s3 | `v5b` | 0.7019 | 1.0000 | 1.00000 | 0.2957 | 1.0000 | 0.00000 | yes | 1.00000 | 0.00000 | 0.6566 | 1.00000 |
| r5s4 | `v5b` | 0.6994 | 1.0000 | 1.00000 | 0.2983 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6566 | 1.00000 |

On the second network the best submission was r3s1 (`tri_v3`), 0.6888; the locked entry, r5s3, scored 0.6566 there on the same sample.

## The agent's closing notes

> ## What the network does
> Purely a linear argmax: `output = argmax_j Σ_i L[j, t_i]` with `L = U·H·E` (64×65, the empty column is zero), on every input — it is the definition, so I am certain. Geometry of `M = U·H` (64 points in R⁸, σ_min = 0.0024): rows 4, 24, 47 are strictly inside the convex hull of the others (exact 9-row certificates, residual ~1e-15) and can never strictly win; rows 50, 53, 58, 11, 54, 57, 27 never win on data but are genuine hull vertices (NNLS residuals 7e-5 … 1.6e-2) with tiny cones, so they cannot be dropped exactly. Output 19 wins ≈10% of the time; ten rows never appear in 200k samples.
> 
> ## How you found it
> Both weights and outputs in rounds 1–4; this round only the weights plus cost accounting. New this round: (1) tested a "shared guard row" idea for dropping the 7 near-hull rows exactly — a guard vector g with `M_j − c_j·g ∈ conv(kept)` for several j, falling back only when `g·h > 0`. It fails: the data's h has almost no mean (mean column norm 0.02 vs 0.2), so any half-space guard fires on ≈35–65% of inputs, and sampling shows the valid-guard cones of different dropped rows are nearly disjoint (only {50,58,11} and {57,27} share any), so a guard certifies ≤3 rows and costs about what it saves. (2) Re-read the pricing: a `cond` on a build-time boolean is computed once (cost 1 total), so the certificate switch can select *tables* at build instead of being a per-input cond. (3) Rebuilt the entry with cheaper build pieces and verified it with `lv1.run_reference`/`lv1.measure` on this network (6000/6000), float32-rounded ×0.3 weights, random-normal and small-integer weights (certificates fail → 64-row fallback, 3000/3000 each) and synthetic networks where rows 4/24/47 are made convex combinations of their supports (certificates pass → reduced path, 4000/4000 each).
> 
> ## The best entry
> `v5b` (reward 0.7019/0.7018/0.6994; coverage 1, fidelity 1, cost 0.296: predict ≈189 ops/input, build 309,459 ≈ 18.9/input; 374 nodes, 97 constants). Region: every input. Build: `M = U·H`; three hull-membership certificates for rows 4, 24, 47 from constant 9-row supports, now as 8×8 systems (`B = (M[sup[1:]] − M[sup[0]])ᵀ`, SVD solve, `λ₀ = 1 − Σλ`, pass iff `min λ > 1e-6` and `‖Bλ − rhs‖ < 1e-12`); `Lr = M[kept 61 rows]·E[:, :64]`; the triangular pair table `S` (61×2144: pairs a≤b plus singles, from free slices, concatenated in two 64-way concats); `T2 = kept[argmax S]`; the pair-index table `P = minimum(X, Xᵀ)[:64]` with `X[a,b] = a(129−a)/2 + b` (2 ops per entry instead of 4); and a 64-row fallback (`S64` via argsort-generated index lists, `T2f`), used only if a certificate fails. The tables actually used are chosen by build-time `cond(cert, S, S64)`, `cond(cert, T2, T2f)`, `cond(cert, kept, arange(64))` — 3 build ops instead of 1 op per input. Interpretation: balanced `cond` tree on `t4==64`, then `t2==64` / `t6==64`: n≤2 → `T2u[P[t0,t1]]`; otherwise `rowmap[argmax take_sum(Su, pair indices)]`. Per n: 6/6/189/189/251/251/313/313 ops. Savings vs round 4 (≈1.7 ops/input): the per-input certificate cond removed (−1/input), build 320k → 309k (P table −8k, certificates −3k). Exact for any weights: everything is computed from the weights; the fallback path is itself the exact 64-row pair-table design (cost ≈0.34 on networks where the certificates fail, instead of running the network).
> 
> ## Claims
> Claimed 1.0 on this network and expected 1.0 on the second: the reduced path is the network's linear argmax over all rows that can strictly win (dropped rows are certified convex combinations of kept rows; ties are measure-zero with float weights), and where a certificate fails the entry computes the full 64-row linear argmax itself. Measured 16384/16384 on three verifier draws and 22,000/22,000 across eight other weight sets covering both paths. The 0.0023 shortfall is the Wilson lower bound only.
> 
> ## Next
> The design is at its pricing floor on both sides: runtime 61·⌈n/2⌉+60+5 for n≥3 and 6 for n≤2; build ≈18.9/input where S (127k) and T2 (129k) are irreducible for this layout, Lr 31k, P 8.6k, certificates 7.2k. Dead ends measured this round: shared guard rows for the near-hull rows (fallback fires ~50% because the data's h is nearly mean-zero; guard cones of different rows barely intersect). Still-open but unpromising: a sorted-triple table (5.5M build) only pays if the verifier sample were ≥8× larger; dropping the near-hull rows needs a certificate that is not exact. If nothing new appears, resubmit `v5b` unchanged (draws vary by about ±0.0015).
