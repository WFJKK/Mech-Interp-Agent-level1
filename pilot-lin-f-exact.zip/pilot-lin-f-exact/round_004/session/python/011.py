
DROP = {4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]}

def build(drop=DROP, use_cert=True):
    g = graph()
    Ew, Hw, Uw = g.weight('embed'), g.weight('hidden'), g.weight('unembed')
    t = [g.token(i) for i in range(8)]
    M = Uw @ Hw                      # 64x8
    # --- certificates ---
    ones9 = g.const(np.ones((1, 9)))
    certs = []
    for j, sup in drop.items():
        V = lv1.take(M, g.const(np.array(sup, dtype=np.int64)), axis=0)   # 9x8
        B = lv1.concat([V.T, ones9], axis=0)                               # 9x9
        u, s, vt = lv1.svd(B)
        Binv = (vt.T * (1.0 / s)[None, :]) @ u.T                           # 9x9
        rhs = lv1.concat([M[j], g.const(np.ones(1))], axis=0)              # 9
        lam = Binv @ rhs
        r = B @ lam - rhs
        rn = lv1.sqrt((r * r).sum())
        ok = (lam.min() > 1e-6) & (rn / s.min() < 1e-9) & (s.min() > 0.0)
        certs.append(ok)
    cert = certs[0]
    for c in certs[1:]:
        cert = cert & c
    # --- reduced tables ---
    rows_np = np.array([i for i in range(64) if i not in drop], dtype=np.int64)
    K = len(rows_np)
    rows = g.const(rows_np)
    Mr = lv1.take(M, rows, axis=0)        # Kx8
    Lr = Mr @ Ew[:, :64]                  # Kx64
    blocks = []
    for a in range(64):
        col = Lr[:, a:a+1]
        blocks.append(col + Lr[:, a:64])
        blocks.append(col)
    S = lv1.concat(blocks, axis=1)        # K x 2144
    T2 = lv1.take(rows, S.argmax(axis=0), axis=0)   # 2144
    ar = g.arange(65)
    x = ar.reshape((65, 1)); y = ar.reshape((1, 65))
    mn = lv1.minimum(x, y); mx = lv1.maximum(x, y)
    cB = ar * 64 - (ar * (ar - 1)) // 2
    P = lv1.take(cB, mn, axis=0) + mx     # 65x65
    def pairs(k):
        idx = lv1.stack([P[t[2*i], t[2*i+1]] for i in range(k)])
        return lv1.take(rows, lv1.take_sum(S, idx, axis=1).argmax(), axis=0)
    n12 = T2[P[t[0], t[1]]]
    low = lv1.cond(t[2] == 64, n12, pairs(2))
    high = lv1.cond(t[6] == 64, pairs(3), pairs(4))
    tree = lv1.cond(t[4] == 64, low, high)
    # --- fallback: the network itself ---
    h = lv1.take_sum(Ew, g.tokens(), axis=1)
    ref = (Uw @ (Hw @ h)).argmax()
    pred = lv1.cond(cert, tree, ref) if use_cert else tree
    return g, g.entry(interpretation=pred), cert

g, ent, cert = build()
print('cert value', cert.value, 'nodes', len(ent['nodes']))
m = measure(ent); print(m)
