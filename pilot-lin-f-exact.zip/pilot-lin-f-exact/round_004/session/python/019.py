
DROP = {4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]}
M = weights['unembed'] @ weights['hidden']
for j, sup in DROP.items():
    B = np.vstack([M[sup].T, np.ones(9)]); u, s, vt = np.linalg.svd(B)
    rhs = np.concatenate([M[j], [1.0]]); lam = vt.T @ ((u.T @ rhs) / s); r = B @ lam - rhs
    print(j, 'lam_min %.4f' % lam.min(), 'rn %.1e' % np.linalg.norm(r), 's_min %.1e' % s.min(), 'rn/smin %.1e' % (np.linalg.norm(r)/s.min()))
