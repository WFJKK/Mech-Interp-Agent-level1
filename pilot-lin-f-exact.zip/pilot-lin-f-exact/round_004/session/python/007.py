
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
rng = np.random.default_rng(0)
# winners on random directions
D = rng.standard_normal((400000, 8))
w = np.argmax(D @ M.T, axis=1)
cnt = np.bincount(w, minlength=64)
never = np.where(cnt == 0)[0]
print('never win random dirs:', never, 'rare (<50):', np.where((cnt>0)&(cnt<50))[0])
# winners on actual data inputs
outs = network_outputs()
print(type(outs), (outs.keys() if isinstance(outs, dict) else len(outs)))
