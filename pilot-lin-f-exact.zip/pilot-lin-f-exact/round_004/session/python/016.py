
DROP = {4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]}
ent = entries['drop3_v4']
def ref_entry(w):
    gr = lv1.Graph(w, 8)
    return gr.entry(interpretation=model.reference(gr, lv1))
def check(w, n=6000, seed=0, label=''):
    rng = np.random.default_rng(seed)
    X = lv1.draw_inputs(info['data_set'], info['input_space'], n, rng)
    ans, ops = lv1.run_reference(ref_entry(w), w, 8, X)
    m = lv1.measure(ent, w, 8, X, ans, ops)
    print(label, 'agree', m['n_agree'], '/', m['n_in_region'], 'build', m['build_ops'], 'cost %.3f' % m['cost'])
    return m
# synthetic networks where the certificate passes: rows 4,24,47 of U are convex combos of the support rows of U
rng = np.random.default_rng(11)
for trial in range(4):
    sc = [0.1, 1.0, 3.0, 1.0][trial]
    Uw = rng.standard_normal((64, 8)) * sc
    for j, sup in DROP.items():
        lam = rng.dirichlet(np.ones(9) * 2.0)
        Uw[j] = lam @ Uw[sup]
    Wr = {'embed': np.concatenate([rng.standard_normal((8, 64)) * sc, np.zeros((8, 1))], axis=1),
          'hidden': rng.standard_normal((8, 8)) * sc, 'unembed': Uw}
    m = check(Wr, label='synthetic%d' % trial)
# also a synthetic one with a near-singular hidden (rank-7 M)
Hs = rng.standard_normal((8, 8)); u_, s_, vt_ = np.linalg.svd(Hs); s_[-1] = 1e-3; Hs = (u_ * s_) @ vt_
Uw = rng.standard_normal((64, 8))
for j, sup in DROP.items():
    Uw[j] = rng.dirichlet(np.ones(9) * 2.0) @ Uw[sup]
check({'embed': np.concatenate([rng.standard_normal((8, 64)), np.zeros((8, 1))], axis=1), 'hidden': Hs, 'unembed': Uw}, label='rank7')
