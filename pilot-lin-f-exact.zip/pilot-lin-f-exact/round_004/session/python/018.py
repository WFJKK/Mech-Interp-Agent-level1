
DROP = {4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]}
def build(drop=DROP, tol_lam=1e-6, tol_res=1e-9):
    g = graph()
    Ew, Hw, Uw = g.weight('embed'), g.weight('hidden'), g.weight('unembed')
    t = [g.token(i) for i in range(8)]
    M = Uw @ Hw
    ones9 = g.const(np.ones((1, 9)))
    one1 = g.const(np.ones(1))
    cert = None
    for j, sup in drop.items():
        V = lv1.take(M, g.const(np.array(sup, dtype=np.int64)), axis=0)
        B = lv1.concat([V.T, ones9], axis=0)
        u, s, vt = lv1.svd(B)
        rhs = lv1.concat([M[j], one1], axis=0)
        lam = vt.T @ ((u.T @ rhs) / s)
        r = B @ lam - rhs
        rn = lv1.sqrt((r * r).sum())
        smin = s.min()
        ok = (lam.min() > tol_lam) & (rn < tol_res * smin)
        cert = ok if cert is None else (cert & ok)
    rows_np = np.array([i for i in range(64) if i not in drop], dtype=np.int64)
    rows = g.const(rows_np)
    Mr = lv1.take(M, rows, axis=0)
    Lr = Mr @ Ew[:, :64]
    blocks = []
    for a in range(64):
        col = Lr[:, a:a+1]
        blocks.append(col + Lr[:, a:64])
        blocks.append(col)
    S = lv1.concat([lv1.concat(blocks[:64], axis=1), lv1.concat(blocks[64:], axis=1)], axis=1)
    T2 = lv1.take(rows, S.argmax(axis=0), axis=0)
    a64 = g.arange(64); a65 = g.arange(65)
    x = a64.reshape((64, 1)); y = a65.reshape((1, 65))
    mn = lv1.minimum(x, y); mx = lv1.maximum(x, y)
    cB = a65 * 64 - (a65 * (a65 - 1)) // 2
    P = lv1.take(cB, mn, axis=0) + mx          # 64 x 65
    def pairs(k):
        idx = lv1.stack([P[t[2*i], t[2*i+1]] for i in range(k)])
        return lv1.take(rows, lv1.take_sum(S, idx, axis=1).argmax(), axis=0)
    n12 = T2[P[t[0], t[1]]]
    low = lv1.cond(t[2] == 64, n12, pairs(2))
    high = lv1.cond(t[6] == 64, pairs(3), pairs(4))
    tree = lv1.cond(t[4] == 64, low, high)
    h = lv1.take_sum(Ew, g.tokens(), axis=1)
    ref = (Uw @ (Hw @ h)).argmax()
    pred = lv1.cond(cert, tree, ref)
    return g, g.entry(interpretation=pred), cert

g, ent, cert = build()
print('cert', cert.value, 'nodes', len(ent['nodes']))
m = measure(ent); print(m)
save_entry('drop3_v4b', ent)

def ref_entry(w):
    gr = lv1.Graph(w, 8); return gr.entry(interpretation=model.reference(gr, lv1))
def check(w, n=5000, seed=0, label=''):
    rng = np.random.default_rng(seed)
    X = lv1.draw_inputs(info['data_set'], info['input_space'], n, rng)
    ans, ops = lv1.run_reference(ref_entry(w), w, 8, X)
    mm = lv1.measure(ent, w, 8, X, ans, ops)
    print(label, 'agree', mm['n_agree'], '/', mm['n_in_region'], 'build', mm['build_ops'], 'cost %.3f' % mm['cost'])
check(weights, seed=3, label='this')
check({k: v.astype(np.float32).astype(np.float64) for k, v in weights.items()}, label='f32')
rng = np.random.default_rng(21)
Uw = rng.standard_normal((64, 8))
for j, sup in DROP.items():
    Uw[j] = rng.dirichlet(np.ones(9) * 2.0) @ Uw[sup]
check({'embed': np.concatenate([rng.standard_normal((8, 64)), np.zeros((8, 1))], axis=1), 'hidden': rng.standard_normal((8, 8)), 'unembed': Uw}, label='synth')
check({'embed': np.concatenate([rng.standard_normal((8, 64)), np.zeros((8, 1))], axis=1), 'hidden': rng.standard_normal((8, 8)), 'unembed': rng.standard_normal((64, 8))}, label='rand')
