
import inspect
src = inspect.getsource(lv1)
i = src.find('if op == "take_sum"'); print(src[i:i+3500])
