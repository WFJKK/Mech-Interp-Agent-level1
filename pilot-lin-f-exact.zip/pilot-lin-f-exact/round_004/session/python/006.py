
import inspect
src = inspect.getsource(lv1)
i = src.find('def _svd'); print(src[i:i+800])
# geometry
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
print(M.shape, np.linalg.svd(M, compute_uv=False))
# LP check which rows are in hull of others
try:
    from scipy.optimize import linprog
    interior = []
    for j in range(64):
        others = np.delete(M, j, axis=0)
        A_eq = np.vstack([others.T, np.ones(63)])
        b_eq = np.concatenate([M[j], [1.0]])
        res = linprog(np.zeros(63), A_eq=A_eq, b_eq=b_eq, bounds=[(0,None)]*63, method='highs')
        if res.status == 0:
            interior.append(j)
    print('interior rows', interior)
except Exception as ex:
    print('scipy fail', ex)
