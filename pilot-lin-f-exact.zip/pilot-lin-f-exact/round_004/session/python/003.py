
import inspect
src = inspect.getsource(lv1)
i = src.find('class Evaluator'); print(src[i:i+6000])
