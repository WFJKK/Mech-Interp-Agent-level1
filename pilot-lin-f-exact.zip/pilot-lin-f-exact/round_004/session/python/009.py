
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
rng = np.random.default_rng(1)
# depth of interior rows: min over unit directions of (max_k M_k.u - M_j.u)
Dirs = rng.standard_normal((200000, 8)); Dirs /= np.linalg.norm(Dirs, axis=1, keepdims=True)
S = Dirs @ M.T
for j in [4, 24, 47, 50, 53]:
    gap = S.max(axis=1) - S[:, j]
    print(j, 'approx depth', gap.min(), 'row norm', np.linalg.norm(M[j]))
print('row norms', np.round(np.linalg.norm(M, axis=1), 3))

def simplex_dirs(d=8):
    # regular simplex vertices in R^d: d+1 unit vectors
    I = np.eye(d+1) - 1.0/(d+1)
    u, s, vt = np.linalg.svd(I)
    V = (I @ vt[:d].T)  # (d+1) x d
    return V / np.linalg.norm(V, axis=1, keepdims=True)

def cert(M, dirs, m=1):
    sc = M @ dirs.T   # 64 x 9
    if m == 1:
        idx = sc.argmax(axis=0)
        V = M[idx]
    else:
        idx = np.argsort(-sc, axis=0)[:m]
        V = M[idx].mean(axis=0)
    B = np.vstack([V.T, np.ones(9)])
    s = np.linalg.svd(B, compute_uv=False)
    Lam = np.linalg.solve(B, np.vstack([M.T, np.ones(64)]))
    ok = (Lam.min(axis=0) > 1e-6)
    return ok, Lam, s.min(), idx

c = M.mean(axis=0); Z0 = M - c
u, s, vt = np.linalg.svd(Z0, full_matrices=False)
print('sv of centered', s)
D0 = simplex_dirs()
for reg in [0.0, 0.05, 0.2, 1.0]:
    Wh = vt.T @ np.diag(1/(s + reg*s.max())) @ vt
    for sign in [1, -1]:
        ok, Lam, smin, idx = cert(M, sign*D0 @ Wh)
        print('reg', reg, 'sign', sign, 'certified', np.where(ok)[0], 'smin %.1e' % smin, 'vertices', idx)
