
DROP = {4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]}
rng = np.random.default_rng(11)
for trial in range(4):
    sc = [0.1, 1.0, 3.0, 1.0][trial]
    Uw = rng.standard_normal((64, 8)) * sc
    for j, sup in DROP.items():
        lam = rng.dirichlet(np.ones(9) * 2.0); Uw[j] = lam @ Uw[sup]
    rng.standard_normal((8, 64)); rng.standard_normal((8, 8))
Hs = rng.standard_normal((8, 8)); u_, s_, vt_ = np.linalg.svd(Hs); s_[-1] = 1e-3; Hs = (u_ * s_) @ vt_
Uw = rng.standard_normal((64, 8))
for j, sup in DROP.items():
    Uw[j] = rng.dirichlet(np.ones(9) * 2.0) @ Uw[sup]
M = Uw @ Hs
for j, sup in DROP.items():
    B = np.vstack([M[sup].T, np.ones(9)])
    u, s, vt = np.linalg.svd(B)
    Binv = (vt.T * (1/s)[None, :]) @ u.T
    rhs = np.concatenate([M[j], [1.0]])
    lam = Binv @ rhs; r = B @ lam - rhs
    print(j, 'lam_min %.3e' % lam.min(), 'rn %.2e' % np.linalg.norm(r), 's_min %.2e' % s.min(), 'rn/smin %.2e' % (np.linalg.norm(r)/s.min()))
