
def nnls(A, b, iters=500):
    # Lawson-Hanson
    m, n = A.shape
    P = np.zeros(n, bool); x = np.zeros(n)
    w = A.T @ (b - A @ x)
    for _ in range(iters):
        if P.all() or w[~P].max() <= 1e-12: break
        j = np.where(~P)[0][np.argmax(w[~P])]
        P[j] = True
        while True:
            s = np.zeros(n)
            s[P] = np.linalg.lstsq(A[:, P], b, rcond=None)[0]
            if s[P].min() > 0:
                x = s; break
            mask = P & (s <= 0)
            alpha = np.min(x[mask] / (x[mask] - s[mask]))
            x = x + alpha * (s - x)
            P = P & (x > 1e-14)
            x[~P] = 0
        w = A.T @ (b - A @ x)
    return x, np.linalg.norm(A @ x - b)

E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H
for j in [4, 11, 24, 47, 50, 53, 57, 27, 33, 54, 58]:
    others = np.delete(np.arange(64), j)
    A = np.vstack([M[others].T, np.ones(63)]) ; b = np.concatenate([M[j], [1.0]])
    x, res = nnls(A, b)
    sup = others[x > 1e-9]
    print(j, 'res %.2e' % res, 'support', sup, np.round(x[x>1e-9], 3))
