
import inspect
src = inspect.getsource(lv1)
# print key parts: matmul, cond evaluation, MAX_RANK, PRICES, svd eval
for key in ['MAX_RANK', 'MAX_HELD', 'PRICES =', 'def matmul', 'def cond', '"cond"', 'svd_u', 'def _price', 'def price']:
    i = src.find(key)
    print('=====', key, i)
    print(src[i:i+900] if i>=0 else '')
