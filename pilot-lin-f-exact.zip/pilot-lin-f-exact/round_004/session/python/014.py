
import inspect
print(inspect.signature(lv1.Graph.__init__))
print(inspect.signature(lv1.Graph.entry))
print(inspect.signature(lv1.draw_inputs))
src = inspect.getsource(lv1.Graph.__init__); print(src[:1200])
