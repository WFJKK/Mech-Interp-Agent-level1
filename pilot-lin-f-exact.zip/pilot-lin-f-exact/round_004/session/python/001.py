
import inspect, json, numpy as np
print(info)
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
print({k: (len(v) if hasattr(v,'__len__') else v) for k,v in e.items()} if isinstance(e, dict) else e)
print(measure(e))
# lv1 capabilities
print([n for n in dir(lv1) if not n.startswith('_')])
src = inspect.getsource(lv1)
print(len(src))
i = src.find('def svd'); print(src[i:i+1500])
