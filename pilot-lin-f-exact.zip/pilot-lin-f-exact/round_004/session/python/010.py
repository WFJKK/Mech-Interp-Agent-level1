
import inspect
src = inspect.getsource(lv1)
for key in ['def measure', 'def run_reference', 'def draw_inputs', 'def take_sum', 'def take(', 'def gather', 'def concat', 'def stack', 'def cast']:
    i = src.find(key); print('=====', key); print(src[i:i+700])
print(inspect.signature(graph), inspect.signature(measure), inspect.signature(save_entry))
