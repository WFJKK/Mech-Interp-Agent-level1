
DROP = {4: [3,10,12,17,22,29,30,36,42], 24: [0,3,12,14,19,26,28,46,62], 47: [1,17,19,23,25,26,37,41,42]}
def build(drop=DROP, use_cert=True, tol_lam=1e-6, tol_res=1e-9):
    g = graph()
    Ew, Hw, Uw = g.weight('embed'), g.weight('hidden'), g.weight('unembed')
    t = [g.token(i) for i in range(8)]
    M = Uw @ Hw
    ones9 = g.const(np.ones((1, 9)))
    certs = []
    for j, sup in drop.items():
        V = lv1.take(M, g.const(np.array(sup, dtype=np.int64)), axis=0)
        B = lv1.concat([V.T, ones9], axis=0)
        u, s, vt = lv1.svd(B)
        Binv = (vt.T * (1.0 / s)[None, :]) @ u.T
        rhs = lv1.concat([M[j], g.const(np.ones(1))], axis=0)
        lam = Binv @ rhs
        r = B @ lam - rhs
        rn = lv1.sqrt((r * r).sum())
        ok = (lam.min() > tol_lam) & (rn / s.min() < tol_res) & (s.min() > 0.0)
        certs.append(ok)
    cert = certs[0]
    for c in certs[1:]:
        cert = cert & c
    rows_np = np.array([i for i in range(64) if i not in drop], dtype=np.int64)
    rows = g.const(rows_np)
    Mr = lv1.take(M, rows, axis=0)
    Lr = Mr @ Ew[:, :64]
    blocks = []
    for a in range(64):
        col = Lr[:, a:a+1]
        blocks.append(col + Lr[:, a:64])
        blocks.append(col)
    S = lv1.concat([lv1.concat(blocks[:64], axis=1), lv1.concat(blocks[64:], axis=1)], axis=1)
    T2 = lv1.take(rows, S.argmax(axis=0), axis=0)
    ar = g.arange(65)
    x = ar.reshape((65, 1)); y = ar.reshape((1, 65))
    mn = lv1.minimum(x, y); mx = lv1.maximum(x, y)
    cB = ar * 64 - (ar * (ar - 1)) // 2
    P = lv1.take(cB, mn, axis=0) + mx
    def pairs(k):
        idx = lv1.stack([P[t[2*i], t[2*i+1]] for i in range(k)])
        return lv1.take(rows, lv1.take_sum(S, idx, axis=1).argmax(), axis=0)
    n12 = T2[P[t[0], t[1]]]
    low = lv1.cond(t[2] == 64, n12, pairs(2))
    high = lv1.cond(t[6] == 64, pairs(3), pairs(4))
    tree = lv1.cond(t[4] == 64, low, high)
    h = lv1.take_sum(Ew, g.tokens(), axis=1)
    ref = (Uw @ (Hw @ h)).argmax()
    pred = lv1.cond(cert, tree, ref) if use_cert else tree
    return g, g.entry(interpretation=pred), cert

g, ent, cert = build()
save_entry('drop3_v4', ent)

# reference entry
def ref_entry(w):
    gr = lv1.Graph(w, 8)
    return gr.entry(interpretation=model.reference(gr, lv1))

def check(w, n=6000, seed=0, label=''):
    rng = np.random.default_rng(seed)
    X = lv1.draw_inputs(info['data_set'], info['input_space'], n, rng)
    ans, ops = lv1.run_reference(ref_entry(w), w, 8, X)
    m = lv1.measure(ent, w, 8, X, ans, ops)
    # was the cert chosen? check via build cost
    print(label, 'agree', m['n_agree'], '/', m['n_in_region'], 'build', m['build_ops'], 'cost %.3f' % m['cost'])

W0 = weights
check(W0, label='this')
# float32-rounded
check({k: v.astype(np.float32).astype(np.float64) for k, v in W0.items()}, label='f32')
check({k: v * 3.0 for k, v in W0.items()}, label='x3')
rng = np.random.default_rng(5)
for sc in [0.1, 1.0]:
    Wr = {'embed': np.concatenate([rng.standard_normal((8, 64)) * sc, np.zeros((8, 1))], axis=1),
          'hidden': rng.standard_normal((8, 8)) * sc, 'unembed': rng.standard_normal((64, 8)) * sc}
    check(Wr, label='rand%.1f' % sc)
Wi = {'embed': np.concatenate([rng.integers(-2, 3, (8, 64)), np.zeros((8, 1), dtype=np.int64)], axis=1).astype(np.float64),
      'hidden': rng.integers(-2, 3, (8, 8)).astype(np.float64), 'unembed': rng.integers(-2, 3, (64, 8)).astype(np.float64)}
check(Wi, label='int')
