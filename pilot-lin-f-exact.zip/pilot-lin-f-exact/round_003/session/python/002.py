
def build_tri():
    g = graph()
    L = g.weight("unembed") @ (g.weight("hidden") @ g.weight("embed"))   # 64 x 65
    blocks = [L[:, a:a+1] + L[:, a:65] for a in range(64)]
    S = lv1.concat(blocks, axis=1)         # 64 x 2144
    T2 = S.argmax(axis=0)                  # 2144
    A = g.arange(64); B = g.arange(65)
    cA = A*64 - (A*(A-1))//2               # offset(a) - a  -> index = cA[a] + b when a<=b
    cB = B*64 - (B*(B-1))//2
    f1 = cA[:, None] + B[None, :]          # a<=b
    f2 = cB[None, :] + A[:, None]          # a>b: off(b)+a-b
    P = lv1.where(A[:, None] <= B[None, :], f1, f2)   # 64 x 65 ints
    t = [g.token(i) for i in range(8)]
    def pairs(k):
        idx = lv1.stack([P[t[2*i], t[2*i+1]] for i in range(k)])
        return lv1.take_sum(S, idx, axis=1).argmax()
    leaf12 = T2[P[t[0], t[1]]]
    left = lv1.cond(t[2] == 64, leaf12, pairs(2))
    right = lv1.cond(t[6] == 64, pairs(3), pairs(4))
    out = lv1.cond(t[4] == 64, left, right)
    return g.entry(interpretation=out)
ent = build_tri()
m = measure(ent); print(m)
save_entry("tri_v1", ent)
