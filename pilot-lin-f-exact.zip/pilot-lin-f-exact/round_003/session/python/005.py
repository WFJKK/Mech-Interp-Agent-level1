
def build_tri2():
    g = graph()
    E = g.weight("embed")
    L64 = g.weight("unembed") @ (g.weight("hidden") @ E[:, :64])   # 64 x 64 (empty column omitted)
    blocks = [L64[:, a:a+1] + L64[:, a:64] for a in range(64)]      # a<=b<=63 : 2080 columns
    S = lv1.concat(blocks + [L64], axis=1)                            # + singles at 2080+a -> 64 x 2144
    T2 = S.argmax(axis=0)
    A = g.arange(64); B = g.arange(65)
    cB = B*63 - (B*(B-1))//2                  # index(a<=b<=63) = cB[a] + b
    f1 = cB[:64][:, None] + B[None, :]        # a<=b
    f2 = cB[None, :] + A[:, None]             # a>b : c[b] + a
    P = lv1.where(A[:, None] <= B[None, :], f1, f2)
    P = lv1.where(B[None, :] == 64, A[:, None] + 2080, P)
    t = [g.token(i) for i in range(8)]
    def pairs(k):
        idx = lv1.stack([P[t[2*i], t[2*i+1]] for i in range(k)])
        return lv1.take_sum(S, idx, axis=1).argmax()
    leaf12 = T2[P[t[0], t[1]]]
    left = lv1.cond(t[2] == 64, leaf12, pairs(2))
    right = lv1.cond(t[6] == 64, pairs(3), pairs(4))
    out = lv1.cond(t[4] == 64, left, right)
    return g.entry(interpretation=out), P
ent, P = build_tri2()
Pv = P.value
cols = {}
for a in range(64):
    for b in range(a,64):
        cols[(a,b)] = len(cols)
ok = all(Pv[a,b] == cols[(min(a,b),max(a,b))] for a in range(64) for b in range(64)) and all(Pv[a,64]==2080+a for a in range(64))
print("P ok", ok)
m = measure(ent); print(m)
save_entry("tri_v2", ent)
print(len(ent['nodes']) if 'nodes' in ent else list(ent.keys()))
