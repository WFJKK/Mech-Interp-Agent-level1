
import inspect
print(inspect.signature(lv1.Graph.__init__))
print(inspect.signature(lv1.Graph.entry))
def build_tri3():
    g = graph()
    E = g.weight("embed")
    L64 = g.weight("unembed") @ (g.weight("hidden") @ E[:, :64])   # 64 x 64 (empty column omitted)
    blocks = []
    for a in range(64):
        col = L64[:, a:a+1]
        blocks.append(lv1.concat([col + L64[:, a:64], col], axis=1))   # b = a..63, then b = 64 (empty)
    S = lv1.concat([lv1.concat(blocks[:32], axis=1), lv1.concat(blocks[32:], axis=1)], axis=1)  # 64 x 2144
    T2 = S.argmax(axis=0)
    A = g.arange(64); B = g.arange(65)
    cB = B*64 - (B*(B-1))//2                  # index(a<=b) = cB[a] + b
    f1 = cB[:64][:, None] + B[None, :]        # a<=b
    f2 = cB[None, :] + A[:, None]             # a>b : c[b] + a
    P = lv1.where(A[:, None] <= B[None, :], f1, f2)
    t = [g.token(i) for i in range(8)]
    def pairs(k):
        idx = lv1.stack([P[t[2*i], t[2*i+1]] for i in range(k)])
        return lv1.take_sum(S, idx, axis=1).argmax()
    leaf12 = T2[P[t[0], t[1]]]
    left = lv1.cond(t[2] == 64, leaf12, pairs(2))
    right = lv1.cond(t[6] == 64, pairs(3), pairs(4))
    out = lv1.cond(t[4] == 64, left, right)
    return g.entry(interpretation=out), P, S
ent, P, S = build_tri3()
Pv = P.value
cols = {}
for a in range(64):
    for b in range(a,65):
        cols[(a,b)] = len(cols)
ok = all(Pv[a,b] == cols[(min(a,b),max(a,b))] for a in range(64) for b in range(65))
print("P ok", ok)
Lfull = weights['unembed'] @ weights['hidden'] @ weights['embed']
Sref = np.stack([Lfull[:,a]+Lfull[:,b] for (a,b) in cols], axis=1)
print("S ok", np.allclose(S.value, Sref))
m = measure(ent); print(m)
save_entry("tri_v3", ent)
print(len(ent['nodes']))
