
import inspect
print(inspect.signature(lv1.run_reference)); print(inspect.signature(lv1.measure)); print(inspect.signature(lv1.draw_inputs))
print(inspect.getsource(lv1.run_reference)[:1500])
