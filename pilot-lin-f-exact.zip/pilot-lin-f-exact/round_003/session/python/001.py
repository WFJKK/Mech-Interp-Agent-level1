
import inspect
print([k for k in dir(lv1) if not k.startswith('_')])
print(info)
g = graph()
L = g.weight("unembed") @ (g.weight("hidden") @ g.weight("embed"))
print(L.shape)
s = L[:, 3:65]; print(s.shape)
c = L[:, 3:4]; print(c.shape)
blk = c + s; print(blk.shape)
print(inspect.signature(lv1.concat), inspect.signature(lv1.take_sum))
e = g.entry(interpretation=blk.argmax(axis=0)[0], region=None) if False else None
print(measure(entries['best']))
