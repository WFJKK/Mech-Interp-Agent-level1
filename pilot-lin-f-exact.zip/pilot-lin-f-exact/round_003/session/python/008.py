
import numpy as np, time
rng = np.random.default_rng(7)
gref = lv1.Graph(weights, 8)
ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
def rand_weights(scale, kind="normal"):
    w = {}
    for k, shp in info['weights'].items():
        if kind == "normal":
            w[k] = (rng.standard_normal(shp) * scale)
        elif kind == "int":
            w[k] = rng.integers(-3, 4, shp).astype(float)
        elif kind == "f32":
            w[k] = (rng.standard_normal(shp) * scale).astype(np.float32).astype(np.float64)
    w['embed'][:, 64] = 0.0
    return w
ent = entries['tri_v3']
tot = 0; bad = 0
for (scale, kind) in [(1.0,"normal"),(0.2,"normal"),(5.0,"normal"),(1.0,"f32"),(1.0,"int"),(0.01,"normal")]:
    w = rand_weights(scale, kind)
    xs = lv1.draw_inputs(info['data_set'], info['input_space'], 6000, rng)
    ans, mops = lv1.run_reference(ref_entry, w, 8, xs)
    t0=time.time()
    r = lv1.measure(ent, w, 8, xs, ans, mops)
    print(kind, scale, r['n_agree'], r['n_in_region'], round(r['reward'],4), round(time.time()-t0,1))
    tot += r['n_in_region']; bad += r['n_in_region'] - r['n_agree']
print("total", tot, "mismatch", bad)
