
import numpy as np, json, copy, sys
sys.setrecursionlimit(10000)
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def feats(seed,n):
    rng=np.random.default_rng(seed); out=[]
    for k in range(0,n,1000000):
        X=rng.standard_normal((min(1000000,n-k),10)); Y=net(X)
        idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
        m=np.take_along_axis(X,idx,1)
        out.append(np.stack([p1,p2,p3,m[:,9],m[:,8],m[:,7],(Y!=p2)],1).astype(np.float32))
    A=np.concatenate(out)
    return dict(p1=A[:,0].astype(int),p2=A[:,1].astype(int),p3=A[:,2].astype(int),m1=A[:,3],m2=A[:,4],m3=A[:,5],err=A[:,6]>0.5)
A=feats(30,12000000); B=feats(11,2000000)
SIMC=2180/2937; RULEC=66/2937
def reward(d, easy):
    e=d['err'][easy].mean(); f=easy.mean()
    return round((1-(f*RULEC+(1-f)*SIMC))-10*f*e,4), round(f,4), round(e,5)
G23=np.array([-1,-0.05,-0.03,-0.02,-0.01,0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.10,0.12,0.14,0.16,0.18,0.20,0.25,0.30,0.35,0.40,0.50,0.60,0.75,0.90,1.2,1.5,9.0])
G12=np.array([-1,0,0.005,0.01,0.015,0.02,0.03,0.04,0.06,0.08,0.1,0.15,0.2,0.3,0.5,9.0])
def fitcell(g, cells, ncell, other_ok, err, grid, floor=-9):
    code=np.full(ncell,len(grid)-1)
    order=np.argsort(cells,kind='stable'); cs=cells[order]
    starts=np.searchsorted(cs,np.arange(ncell+1))
    allowed=grid>=floor
    for c in range(ncell):
        ids=order[starts[c]:starts[c+1]]; ids=ids[other_ok[ids]]
        if len(ids)==0: continue
        gc=g[ids]; ec=err[ids].astype(np.float32)
        inc=gc[None,:]>grid[:,None]
        v=inc.sum(1)*(1-RULEC)-10*(inc*ec[None,:]).sum(1)+(~inc).sum(1)*(1-SIMC)
        v[~allowed]=-1e18
        code[c]=np.argmax(v)
    return code
def c3(d): return (d['p2']*10+d['p1'])*10+d['p3']
def c12(d): return d['p2']*10+d['p1']
def run(d, code23, code12, slope, m2th=0.06):
    g23=d['m2']-d['m3']-slope*d['m2']; g12=d['m1']-d['m2']
    return (d['m2']>m2th)&(g23>G23[code23[c3(d)]])&(g12>G12[code12[c12(d)]])
best=None
for slope in [0.025,0.03,0.035]:
    code12=np.full(100,3); code23=np.full(1000,5)
    g23=A['m2']-A['m3']-slope*A['m2']; g12=A['m1']-A['m2']
    for it in range(3):
        ok=(A['m2']>0.06)&(g12>G12[code12[c12(A)]])
        code23=fitcell(g23,c3(A),1000,ok,A['err'],G23,0.0)
        ok=(A['m2']>0.06)&(g23>G23[code23[c3(A)]])
        code12=fitcell(g12,c12(A),100,ok,A['err'],G12,0.01)
    rB=reward(B,run(B,code23,code12,slope)); print("slope",slope,"A",reward(A,run(A,code23,code12,slope)),"B",rB)
    if best is None or rB[0]>best[0]: best=(rB[0],slope,code23.copy(),code12.copy())
_,slope,code23,code12=best; print("chosen slope",slope)
T23=np.array([sum(int(code23[10*q+r])<<(5*r) for r in range(10)) for q in range(100)],dtype=np.int64)
T12=np.array([sum(int(code12[10*q+r])<<(4*r) for r in range(10)) for q in range(10)],dtype=np.int64)
P5=np.array([1<<(5*r) for r in range(10)],dtype=np.int64); P4=np.array([1<<(4*r) for r in range(10)],dtype=np.int64)
g=graph(example=[0.3,-1,2,0.5,1.1,-0.2,0.9,1.5,0.1,0.0])
x=g.tokens(); idx=lv1.argsort(x,0); p1,p2,p3=idx[9],idx[8],idx[7]; m1,m2,m3=x[p1],x[p2],x[p3]
th23=g.const(G23)[(g.const(T23)[p2*10+p1]//g.const(P5)[p3])%32]
th12=g.const(G12)[(g.const(T12)[p2]//g.const(P4)[p1])%16]
easy=(m2>0.06)&((m2-m3-slope*m2)>th23)&((m1-m2)>th12)
rule=g.entry(interpretation=p2, region=easy); save_entry("rule_only_v2", rule)
print("rule-only",measure(rule))
old=entries['best']
nodes=copy.deepcopy(old['nodes']); off=len(nodes)-8
assert all(rule['nodes'][i]==old['nodes'][i] for i in range(8))
for i in range(8,len(rule['nodes'])):
    n=copy.deepcopy(rule['nodes'][i])
    if 'args' in n: n['args']=[a if a<8 else a+off for a in n['args']]
    nodes.append(n)
pred=old['predict']; nodes[pred]['args'][0]=rule['rule']+off
order=[]; seen=set()
def visit(i):
    if i in seen: return
    seen.add(i)
    for a in nodes[i].get('args',[]): visit(a)
    order.append(i)
visit(pred); remap={o:n for n,o in enumerate(order)}
new=[]
for o in order:
    n=copy.deepcopy(nodes[o])
    if 'args' in n: n['args']=[remap[a] for a in n['args']]
    new.append(n)
ent={'format':old['format'],'nodes':new,'predict':remap[pred],'rule':None}
lv1.Graph.load(ent, weights, 10)
print(len(new), measure(ent)); save_entry("hybrid_cells_v2", ent)
