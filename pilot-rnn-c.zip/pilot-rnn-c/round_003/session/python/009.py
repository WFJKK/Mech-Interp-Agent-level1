
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def feats(seed,n):
    rng=np.random.default_rng(seed)
    X=rng.standard_normal((n,10)); Y=net(X)
    idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
    m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
    return dict(Y=Y,p1=p1,p2=p2,p3=p3,m1=m1,m2=m2,m3=m3,err=(Y!=p2))
A=feats(10,4000000); B=feats(11,2000000)
SIMC=2140/2937; RULEC=56/2937
def reward(d, easy):
    e=d['err'][easy].mean(); f=easy.mean()
    fid=1-f*e
    cost=f*RULEC+(1-f)*SIMC+RULEC*0  # approx: rule computed for all
    return (1-cost)-10*(1-fid), f, e
base=lambda d:(d['m1']-d['m2']>0.0125)&(d['m2']-d['m3']>0.02+0.035*d['m2']+0.08*(d['p1']==9))&(d['m2']>0.06)
print("baseline A",reward(A,base(A)),"B",reward(B,base(B)))
# per-cell threshold on g23 (cell = p1==9, p2, p3), keep g12>0.0125, m2>0.06
grid=np.concatenate([np.arange(0,0.3,0.01),np.arange(0.3,1.0,0.05),[9]])
def fit(d, slope=0.035):
    cell=(d['p1']==9)*100+d['p2']*10+d['p3']
    g=d['m2']-d['m3']-slope*d['m2']
    ok=(d['m1']-d['m2']>0.0125)&(d['m2']>0.06)
    th=np.zeros(200)
    for c in range(200):
        s=ok&(cell==c)
        if s.sum()==0: th[c]=9; continue
        gc=g[s]; ec=d['err'][s]
        best=-1e9
        for t in grid:
            inc=gc>t
            v=inc.sum()*(1-RULEC)-10*ec[inc].sum()+(~inc).sum()*(1-SIMC)
            if v>best: best=v; th[c]=t
    return th
def apply(d,th,slope=0.035):
    cell=(d['p1']==9)*100+d['p2']*10+d['p3']
    g=d['m2']-d['m3']-slope*d['m2']
    return (d['m1']-d['m2']>0.0125)&(d['m2']>0.06)&(g>th[cell])
th=fit(A)
print("cellwise A",reward(A,apply(A,th)),"B",reward(B,apply(B,th)))
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print(th[:100].reshape(10,10)); print(th[100:].reshape(10,10))
