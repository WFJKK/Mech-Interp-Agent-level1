
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def feats(seed,n):
    rng=np.random.default_rng(seed)
    X=rng.standard_normal((n,10)); Y=net(X)
    idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
    m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
    return dict(Y=Y,p1=p1,p2=p2,p3=p3,m1=m1,m2=m2,m3=m3,err=(Y!=p2))
A=feats(10,6000000); B=feats(11,2000000)
SIMC=2140/2937; RULEC=60/2937
def reward(d, easy):
    e=d['err'][easy].mean(); f=easy.mean()
    return round((1-(f*RULEC+(1-f)*SIMC))-10*f*e,4), round(f,4), round(e,5)
grid23=np.concatenate([np.arange(-0.1,0.3,0.01),np.arange(0.3,1.0,0.05),[9]])
grid12=np.concatenate([np.arange(-0.02,0.2,0.005),np.arange(0.2,1.0,0.05),[9]])
def fitcell(g, cells, ncell, other_ok, err, grid):
    th=np.full(ncell,9.0)
    order=np.argsort(cells,kind='stable'); cs=cells[order]
    starts=np.searchsorted(cs,np.arange(ncell+1))
    for c in range(ncell):
        ids=order[starts[c]:starts[c+1]]; ids=ids[other_ok[ids]]
        if len(ids)==0: continue
        gc=g[ids]; ec=err[ids].astype(float)
        # vectorized over grid
        inc=gc[None,:]>grid[:,None]
        v=inc.sum(1)*(1-RULEC)-10*(inc*ec[None,:]).sum(1)+(~inc).sum(1)*(1-SIMC)
        th[c]=grid[np.argmax(v)]
    return th
def c3(d): return d['p1']*100+d['p2']*10+d['p3']
def c12(d): return d['p1']*10+d['p2']
def run(d, th23, th12, slope, m2th, cellf):
    g23=d['m2']-d['m3']-slope*d['m2']; g12=d['m1']-d['m2']
    return (d['m2']>m2th)&(g23>th23[cellf(d)])&(g12>th12[c12(d)])
res={}
for slope in [0.0,0.035,0.07]:
    th12=np.full(100,0.0125); th23=np.full(1000,0.0); m2th=0.06
    for it in range(2):
        g23=A['m2']-A['m3']-slope*A['m2']; g12=A['m1']-A['m2']
        ok=(A['m2']>m2th)&(g12>th12[c12(A)])
        th23=fitcell(g23,c3(A),1000,ok,A['err'],grid23)
        ok=(A['m2']>m2th)&(g23>th23[c3(A)])
        th12=fitcell(g12,c12(A),100,ok,A['err'],grid12)
    print("slope",slope,"A",reward(A,run(A,th23,th12,slope,m2th,c3)),"B",reward(B,run(B,th23,th12,slope,m2th,c3)))
    res[slope]=(th23,th12)
import pickle, os
os.makedirs('tmp',exist_ok=True); pickle.dump(res,open('tmp/th3.pkl','wb'))
