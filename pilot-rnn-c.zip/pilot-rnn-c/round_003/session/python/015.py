
import json
e=entries['best']; nodes=e['nodes']
print(len(nodes), e['predict'], e['rule'])
for i,n in enumerate(nodes):
    if n['op'] in ('cond','where') or i>=len(nodes)-12: print(i,n)
# which nodes reference node 26 (the easy flag)?
print([i for i,n in enumerate(nodes) if 26 in n.get('args',[])])
# all op types used
from collections import Counter
print(Counter(n['op'] for n in nodes))
