
import numpy as np, json, copy
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def feats(seed,n):
    rng=np.random.default_rng(seed)
    X=rng.standard_normal((n,10)); Y=net(X)
    idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
    m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
    return dict(Y=Y,p1=p1,p2=p2,p3=p3,m1=m1,m2=m2,m3=m3,err=(Y!=p2))
A=feats(10,6000000)
SIMC=2140/2937; RULEC=70/2937
G23=np.array([-1,-0.05,-0.03,-0.02,-0.01,0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.10,0.12,0.14,0.16,0.18,0.20,0.25,0.30,0.35,0.40,0.50,0.60,0.75,0.90,1.2,1.5,9.0])
G12=np.array([-1,0,0.005,0.01,0.015,0.02,0.03,0.04,0.06,0.08,0.1,0.15,0.2,0.3,0.5,9.0])
def fitcell(g, cells, ncell, other_ok, err, grid, floor=-9):
    code=np.full(ncell,len(grid)-1)
    order=np.argsort(cells,kind='stable'); cs=cells[order]
    starts=np.searchsorted(cs,np.arange(ncell+1))
    allowed=grid>=floor
    for c in range(ncell):
        ids=order[starts[c]:starts[c+1]]; ids=ids[other_ok[ids]]
        if len(ids)==0: continue
        gc=g[ids]; ec=err[ids].astype(float)
        inc=gc[None,:]>grid[:,None]
        v=inc.sum(1)*(1-RULEC)-10*(inc*ec[None,:]).sum(1)+(~inc).sum(1)*(1-SIMC)
        v[~allowed]=-1e18
        code[c]=np.argmax(v)
    return code
def c3(d): return (d['p2']*10+d['p1'])*10+d['p3']
def c12(d): return d['p2']*10+d['p1']
slope=0.035; m2th=0.06
code12=np.full(100,3); code23=np.full(1000,5)
for it in range(2):
    g23=A['m2']-A['m3']-slope*A['m2']; g12=A['m1']-A['m2']
    ok=(A['m2']>m2th)&(g12>G12[code12[c12(A)]])
    code23=fitcell(g23,c3(A),1000,ok,A['err'],G23,0.0)
    ok=(A['m2']>m2th)&(g23>G23[code23[c3(A)]])
    code12=fitcell(g12,c12(A),100,ok,A['err'],G12,0.01)
T23=np.array([sum(int(code23[10*q+r])<<(5*r) for r in range(10)) for q in range(100)],dtype=np.int64)
T12=np.array([sum(int(code12[10*q+r])<<(4*r) for r in range(10)) for q in range(10)],dtype=np.int64)
P5=np.array([1<<(5*r) for r in range(10)],dtype=np.int64); P4=np.array([1<<(4*r) for r in range(10)],dtype=np.int64)
def build_rule(g):
    x=g.tokens(); idx=lv1.argsort(x,0)
    p1,p2,p3=idx[9],idx[8],idx[7]
    m1,m2,m3=x[p1],x[p2],x[p3]
    c12=p2*10+p1
    th23=g.const(G23)[(g.const(T23)[c12]//g.const(P5)[p3])%32]
    th12=g.const(G12)[(g.const(T12)[p2]//g.const(P4)[p1])%16]
    easy=(m2>0.06)&((m2-m3-0.035*m2)>th23)&((m1-m2)>th12)
    return easy,p2
g=graph(example=[0.3,-1,2,0.5,1.1,-0.2,0.9,1.5,0.1,0.0])
easy,p2=build_rule(g)
tmp=g.entry(interpretation=p2, region=easy)
save_entry("rule_only_v1", tmp)   # stash: holds the tables
newnodes=tmp['nodes']; print(len(newnodes), tmp['predict'], tmp['rule'])
old=entries['best']['nodes']
print([newnodes[i]==old[i] for i in range(8)])
for i in range(8,len(newnodes)): print(i,{k:(v if k!='value' or not isinstance(v,list) else f'list{len(v)}') for k,v in newnodes[i].items()})
print(measure(tmp))
