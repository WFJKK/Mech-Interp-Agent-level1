
import numpy as np, time
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rn=entries['rule_only_v1']['nodes']
T23=np.array(rn[12]['value'],dtype=np.int64); T12=np.array(rn[21]['value'],dtype=np.int64)
G23=np.array(rn[11]['value']); G12=np.array(rn[20]['value'])
code23=np.array([(T23[q]>>(5*r))&31 for q in range(100) for r in range(10)])
code12=np.array([(T12[q]>>(4*r))&15 for q in range(10) for r in range(10)])
rng=np.random.default_rng(21)
X=rng.standard_normal((1500000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
th23=G23[code23[(p2*10+p1)*10+p3]]; th12=G12[code12[p2*10+p1]]
zone=(m2>0.06)&~((m2-m3-0.035*m2)>th23)&((m1-m2)>th12)
Z=np.where(zone)[0]
Xz=X[Z].astype(np.float32); lab=(Y[Z]==p3[Z]).astype(np.float32); N=len(Z)
cell=(p2[Z]*10+p3[Z]); P1=p1[Z]; ar=np.arange(N)
M=m[Z].astype(np.float32); g23=(m2-m3)[Z].astype(np.float32)
del X,Y,idx,m
def onehot(v,n): o=np.zeros((len(v),n),np.float32); o[np.arange(len(v)),v]=1; return o
def nb(p,d): return Xz[ar,(p+d)%10]
def train_eval(F,name,epochs=20):
    n=len(F); ntr=int(n*0.8)
    w=np.zeros(F.shape[1],np.float32); mm=np.zeros_like(w); vv=np.zeros_like(w); lr=0.05
    for ep in range(epochs):
        perm=np.random.permutation(ntr)
        for i in range(0,ntr,4096):
            b=perm[i:i+4096]; p=1/(1+np.exp(-F[b]@w)); g=F[b].T@(p-lab[b])/len(b)
            mm=0.9*mm+0.1*g; vv=0.999*vv+0.001*g*g; w-=lr*mm/(np.sqrt(vv)+1e-8)
    pr=1/(1+np.exp(-F[ntr:]@w)); lte=lab[ntr:]
    acc=((pr>0.5)==(lte>0.5)).mean()
    conf=np.maximum(pr,1-pr)>0.93
    print(name,"acc",round(acc,4),"conf93 frac",round(conf.mean(),3),"acc there",round(((pr>0.5)==(lte>0.5))[conf].mean(),4),flush=True)
    return w
OC=onehot(cell,100); OP=onehot(P1,10); one=np.ones((N,1),np.float32)
base=[OC,OP,g23[:,None],M[:,8:9],one]
train_eval(np.concatenate(base,1),"base")
inter=OC*g23[:,None]
train_eval(np.concatenate(base+[inter],1),"base+cell*g23")
nbf=[nb(p2[Z],1)[:,None],nb(p3[Z],1)[:,None],nb(p2[Z],-1)[:,None],nb(p3[Z],-1)[:,None]]
train_eval(np.concatenate(base+[inter]+nbf,1),"+neighbors")
train_eval(np.concatenate(base+[inter]+nbf+[M, Xz],1),"+m+raw")
nbr=[np.maximum(f,0) for f in nbf]+[np.maximum(-f,0) for f in nbf]
train_eval(np.concatenate(base+[inter]+nbr+[np.maximum(Xz,0),np.maximum(-Xz,0)],1),"+relu neighbors+raw")
