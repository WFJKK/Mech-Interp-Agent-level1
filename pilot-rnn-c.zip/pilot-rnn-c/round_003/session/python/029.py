
import copy
e=entries['hybrid_cells_v1']; nodes=e['nodes']; pred=e['predict']
simnode=nodes[pred]['args'][2]
ent={'format':e['format'],'nodes':nodes,'predict':simnode,'rule':None}
r=measure(ent); print({k:r[k] for k in ['fidelity','cost','predict_ops','build_ops']}, r['predict_ops']/16384)
# Count ops per node type roughly: find cond nodes and their structure in the sim part
from collections import Counter
print(Counter(n['op'] for n in nodes))
