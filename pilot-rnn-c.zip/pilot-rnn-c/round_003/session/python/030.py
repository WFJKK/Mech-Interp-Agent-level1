
save_entry("best_r3", entries['hybrid_cells_v1'])
save_entry("best", entries['hybrid_cells_v1'])
print(sorted(entries.keys()))
