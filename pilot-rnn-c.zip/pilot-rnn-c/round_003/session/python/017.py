
import numpy as np, pickle, json, copy
out=pickle.load(open('tmp/codes.pkl','rb'))
code23,code12=out[0.0]
G23=np.array([-1,-0.05,-0.03,-0.02,-0.01,0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.10,0.12,0.14,0.16,0.18,0.20,0.25,0.30,0.35,0.40,0.50,0.60,0.75,0.90,1.2,1.5,9.0])
G12=np.array([-1,0,0.005,0.01,0.015,0.02,0.03,0.04,0.06,0.08,0.1,0.15,0.2,0.3,0.5,9.0])
T23=np.array([sum(int(code23[10*q+r])<<(5*r) for r in range(10)) for q in range(100)],dtype=np.int64)
T12=np.array([sum(int(code12[10*q+r])<<(4*r) for r in range(10)) for q in range(10)],dtype=np.int64)
P5=np.array([1<<(5*r) for r in range(10)],dtype=np.int64); P4=np.array([1<<(4*r) for r in range(10)],dtype=np.int64)
print(T23.max()<2**53, T12.max())
def build_rule(g):
    x=g.tokens(); idx=lv1.argsort(x,0)
    p1,p2,p3=idx[9],idx[8],idx[7]
    m1,m2,m3=x[p1],x[p2],x[p3]
    c12=p2*10+p1
    th23=g.const(G23)[(g.const(T23)[c12]//g.const(P5)[p3])%32]
    th12=g.const(G12)[(g.const(T12)[p2]//g.const(P4)[p1])%16]
    easy=(m2>0.06)&((m2-m3-0.035*m2)>th23)&((m1-m2)>th12)
    return easy,p2
g=graph(example=[0.3,-1,2,0.5,1.1,-0.2,0.9,1.5,0.1,0.0])
easy,p2=build_rule(g)
print(easy.value, p2.value)
tmp=g.entry(interpretation=p2, region=easy)
newnodes=tmp['nodes']; print(len(newnodes), tmp['predict'], tmp['rule'])
old=entries['best']['nodes']
print([newnodes[i]==old[i] for i in range(8)])
for i in range(8,len(newnodes)): print(i,newnodes[i])
