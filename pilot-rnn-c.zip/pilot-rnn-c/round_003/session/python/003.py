
def states(X):
    h=np.zeros((X.shape[0],16)); hs=[]
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0); hs.append(h)
    return np.stack(hs,1)
Xh=X[hard][:50000]
H=states(Xh)
Z=(H==0).mean(0)  # step x unit
print("frac zero per step (rows) per unit (cols) on hard inputs\n", np.round(Z,3))
# joint patterns of sparse units at a step
S=[0,3,6,10,15]
for t in range(3,10):
    pat=(H[:,t,S]==0).astype(int)@np.array([16,8,4,2,1])
    vals,cnt=np.unique(pat,return_counts=True)
    print(t, dict(zip(vals,np.round(cnt/len(pat),3))))
