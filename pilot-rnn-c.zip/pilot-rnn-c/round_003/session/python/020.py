
import json, copy, sys
sys.setrecursionlimit(10000)
old=entries['best']; rule=entries['rule_only_v1']
nodes=copy.deepcopy(old['nodes']); off=len(nodes)-8
for i in range(8,len(rule['nodes'])):
    n=copy.deepcopy(rule['nodes'][i])
    if 'args' in n: n['args']=[a if a<8 else a+off for a in n['args']]
    nodes.append(n)
pred=old['predict']
nodes[pred]['args'][0]=rule['rule']+off
order=[]; seen=set()
def visit(i):
    if i in seen: return
    seen.add(i)
    for a in nodes[i].get('args',[]): visit(a)
    order.append(i)
visit(pred)
remap={o:n for n,o in enumerate(order)}
new=[]
for o in order:
    n=copy.deepcopy(nodes[o])
    if 'args' in n: n['args']=[remap[a] for a in n['args']]
    new.append(n)
ent={'format':old['format'],'nodes':new,'predict':remap[pred],'rule':None}
print(len(new))
gg,interp,reg=lv1.Graph.load(ent, weights, 10)
print(interp.value, reg)
res=measure(ent); print(res)
save_entry("hybrid_cells_v1", ent)
