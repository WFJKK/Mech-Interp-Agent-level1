
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X,R=R,O=O,W=W):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(5)
X=rng.standard_normal((1000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06)
Xh=X[~easy]; Yh=Y[~easy]
print("hard n",len(Xh))
for tau in [0.02,0.05,0.1,0.15,0.2,0.3]:
    Rs=np.where(np.abs(R)<tau,0,R)
    print("tau",tau,"nnz",(Rs!=0).sum(),"disagree hard",(net(Xh,R=Rs)!=Yh).mean(), "disagree easy-sample",(net(X[easy][:200000],R=Rs)!=Y[easy][:200000]).mean())
# sensitivity per entry: zero each single entry
S=np.zeros((16,16))
for i in range(16):
    for j in range(16):
        Rs=R.copy(); Rs[i,j]=0
        S[i,j]=(net(Xh[:100000],R=Rs)!=Yh[:100000]).mean()
np.set_printoptions(precision=4, suppress=True, linewidth=250)
print(S)
