
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(1)
X=rng.standard_normal((2000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06)
err=(Y!=p2)
# errors where Y==p1 in easy
e1=easy&err&(Y==p1)
print("frac of easy that are Y==p1 errors",e1.sum()/easy.sum())
print("p1 dist of those",np.bincount(p1[e1],minlength=10)/e1.sum())
print("p2 dist of those",np.bincount(p2[e1],minlength=10)/e1.sum())
print("g12 quantiles",np.quantile((m1-m2)[e1],[.1,.5,.9]),"m1 q",np.quantile(m1[e1],[.1,.5,.9]), "m2 q",np.quantile(m2[e1],[.1,.5,.9]))
# error rate for p1==9 by g12
s=easy&(p1==9)
for lo,hi in [(0,0.1),(0.1,0.3),(0.3,0.6),(0.6,1),(1,2),(2,9)]:
    t=s&(m1-m2>=lo)&(m1-m2<hi); print("p1==9 g12",lo,hi,round(t.sum()/s.sum(),3),round(err[t].mean(),4), "Y==p1 share",round((Y[t]==p1[t]).mean(),4))
# error rate for p1==0 by g12 and m1
s=easy&(p1==0)
for lo,hi in [(0,0.1),(0.1,0.3),(0.3,0.6),(0.6,1),(1,2),(2,9)]:
    t=s&(m1-m2>=lo)&(m1-m2<hi); print("p1==0 g12",lo,hi,round(t.sum()/s.sum(),3),round(err[t].mean(),4), "Y==p1 share",round((Y[t]==p1[t]).mean(),4))
# wide-gap errors: what are they
wide=easy&(m1-m2>0.3)&(m2-m3>0.3)&(m2>0.3)
print("wide frac",wide.mean(),"err",err[wide].mean(), "Y==p1",(Y[wide&err]==p1[wide&err]).mean(),"Y==p3",(Y[wide&err]==p3[wide&err]).mean())
we=wide&err
print("p1 dist",np.bincount(p1[we],minlength=10)/we.sum())
print("p2 dist",np.bincount(p2[we],minlength=10)/we.sum())
print("m1 q",np.quantile(m1[we],[.1,.5,.9]),"vs all wide",np.quantile(m1[wide],[.1,.5,.9]))
print("m2 q",np.quantile(m2[we],[.1,.5,.9]),"vs all wide",np.quantile(m2[wide],[.1,.5,.9]))
print("m3 q",np.quantile(m3[we],[.1,.5,.9]),"vs all wide",np.quantile(m3[wide],[.1,.5,.9]))
