
import json, os
print(os.path.exists('tmp/th3.pkl'))
e=entries['best']
print(type(e), list(e.keys()) if isinstance(e,dict) else None)
s=json.dumps(e); print(len(s))
print(s[:3000])
