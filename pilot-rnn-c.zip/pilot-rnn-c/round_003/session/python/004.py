
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def states(X):
    h=np.zeros((X.shape[0],16)); hs=[]
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0); hs.append(h)
    return np.stack(hs,1)
rng=np.random.default_rng(0)
X=rng.standard_normal((400000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06); hard=~easy
Xh=X[hard][:50000]; H=states(Xh)
Z=(H==0).mean(0)
np.set_printoptions(precision=3, suppress=True, linewidth=200)
print("frac zero per step (rows) per unit (cols) on hard inputs\n", Z)
S=[0,3,6,10,15]
for t in range(3,10):
    pat=(H[:,t,S]==0).astype(int)@np.array([16,8,4,2,1])
    vals,cnt=np.unique(pat,return_counts=True)
    print(t, dict(zip(vals,np.round(cnt/len(pat),3))))
