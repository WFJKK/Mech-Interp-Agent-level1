
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(1)
X=rng.standard_normal((2000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06)
err=(Y!=p2)
np.set_printoptions(precision=3, suppress=True, linewidth=200)
s=easy&(p1==9)
print("p1==9 easy frac",s.mean(),"err",err[s].mean())
print("err by p2:",[round(err[s&(p2==k)].mean(),4) for k in range(9)])
print("err by p3:",[round(err[s&(p3==k)].mean(),4) for k in range(9)])
# p2 x p3 table
T=np.zeros((9,9)); 
for a in range(9):
    for b in range(9):
        t=s&(p2==a)&(p3==b); T[a,b]=err[t].mean() if t.sum()>0 else np.nan
print(T)
# in p1==9, p2==1 errors: what is Y
t=s&(p2==1)&err
print("Y dist p2==1 errs",np.bincount(Y[t],minlength=10)/t.sum())
print("p3 dist p2==1 errs",np.bincount(p3[t],minlength=10)/t.sum())
# error by g23 for p1==9,p2==1
t=s&(p2==1)
for lo,hi in [(0,0.2),(0.2,0.5),(0.5,1),(1,9)]:
    u=t&(m2-m3>=lo)&(m2-m3<hi); print("p2==1 g23",lo,hi,round(err[u].mean(),4),u.sum())
