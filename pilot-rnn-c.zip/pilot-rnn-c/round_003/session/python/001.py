
import numpy as np, json
print({k:(v if not isinstance(v,(list,dict)) or k!='data' else '...') for k,v in info.items()})
print(list(entries.keys()))
for k,v in weights.items(): print(k, v.shape)
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print("input", weights['input'][:,0])
print("recurrent\n", weights['recurrent'])
print("readout\n", weights['readout'])
