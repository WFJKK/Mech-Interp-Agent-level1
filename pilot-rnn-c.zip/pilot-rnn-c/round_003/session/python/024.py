
import numpy as np, time
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rn=entries['rule_only_v1']['nodes']
T23=np.array(rn[12]['value'],dtype=np.int64); T12=np.array(rn[21]['value'],dtype=np.int64)
G23=np.array(rn[11]['value']); G12=np.array(rn[20]['value'])
code23=np.array([(T23[q]>>(5*r))&31 for q in range(100) for r in range(10)])
code12=np.array([(T12[q]>>(4*r))&15 for q in range(10) for r in range(10)])
rng=np.random.default_rng(21)
X=rng.standard_normal((3000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
th23=G23[code23[(p2*10+p1)*10+p3]]; th12=G12[code12[p2*10+p1]]
zone=(m2>0.06)&~((m2-m3-0.035*m2)>th23)&((m1-m2)>th12)
Z=np.where(zone)[0]
def onehot(v,n): o=np.zeros((len(v),n)); o[np.arange(len(v)),v]=1; return o
Xz=X[Z]; lab=(Y[Z]==p3[Z]).astype(float)
cell=(p2[Z]*10+p3[Z]); 
F=np.concatenate([Xz, m[Z], onehot(cell,100), onehot(p1[Z],10), (m2-m3)[Z,None], (m1-m2)[Z,None],(m3-m4)[Z,None], np.ones((len(Z),1))],1)
# standardize continuous
mu=F[:,:20].mean(0); sd=F[:,:20].std(0)+1e-9; F[:,:20]=(F[:,:20]-mu)/sd
n=len(F); ntr=int(n*0.8)
Ftr,ltr,Fte,lte=F[:ntr],lab[:ntr],F[ntr:],lab[ntr:]
# logistic regression with Adam
w=np.zeros(F.shape[1]); mm=np.zeros_like(w); vv=np.zeros_like(w); lr=0.05
t0=time.time()
for ep in range(30):
    perm=np.random.permutation(ntr)
    for i in range(0,ntr,4096):
        b=perm[i:i+4096]; p=1/(1+np.exp(-Ftr[b]@w)); g=Ftr[b].T@(p-ltr[b])/len(b)
        mm=0.9*mm+0.1*g; vv=0.999*vv+0.001*g*g; w-=lr*mm/(np.sqrt(vv)+1e-8)
pr=1/(1+np.exp(-Fte@w)); acc=((pr>0.5)==(lte>0.5)).mean()
print("logreg acc",acc,"baseline",1-lte.mean(),"time",time.time()-t0)
for c in [0.85,0.9,0.93,0.95]:
    conf=np.maximum(pr,1-pr)>c
    print(c,"frac confident",round(conf.mean(),3),"acc there",round(((pr>0.5)==(lte>0.5))[conf].mean(),4))
# a small MLP: 2 layers 32 hidden
H=32; rng2=np.random.default_rng(0)
W1=rng2.standard_normal((F.shape[1],H))*0.1; b1=np.zeros(H); W2=rng2.standard_normal(H)*0.1; b2=0.0
params=[W1,b1,W2,np.array(b2)]
ms=[np.zeros_like(p) for p in params]; vs=[np.zeros_like(p) for p in params]; lr=0.003
for ep in range(15):
    perm=np.random.permutation(ntr)
    for i in range(0,ntr,2048):
        b=perm[i:i+2048]; x=Ftr[b]; a=np.maximum(x@W1+b1,0); o=a@W2+b2; p=1/(1+np.exp(-o)); d=(p-ltr[b])/len(b)
        gW2=a.T@d; gb2=d.sum(); da=np.outer(d,W2)*(a>0); gW1=x.T@da; gb1=da.sum(0)
        for k,(pa,g) in enumerate(zip(params,[gW1,gb1,gW2,np.array(gb2)])):
            ms[k]=0.9*ms[k]+0.1*g; vs[k]=0.999*vs[k]+0.001*g*g; pa-=lr*ms[k]/(np.sqrt(vs[k])+1e-8)
    W1,b1,W2,b2=params[0],params[1],params[2],params[3]
a=np.maximum(Fte@W1+b1,0); pr=1/(1+np.exp(-(a@W2+b2)))
print("MLP acc",((pr>0.5)==(lte>0.5)).mean(),"time",time.time()-t0)
for c in [0.85,0.9,0.93,0.95]:
    conf=np.maximum(pr,1-pr)>c
    print(c,"frac confident",round(conf.mean(),3),"acc there",round(((pr>0.5)==(lte>0.5))[conf].mean(),4))
