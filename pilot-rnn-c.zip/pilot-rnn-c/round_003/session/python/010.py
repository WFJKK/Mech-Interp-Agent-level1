
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def feats(seed,n):
    rng=np.random.default_rng(seed)
    X=rng.standard_normal((n,10)); Y=net(X)
    idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
    m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
    return dict(Y=Y,p1=p1,p2=p2,p3=p3,m1=m1,m2=m2,m3=m3,err=(Y!=p2))
A=feats(10,4000000); B=feats(11,2000000)
SIMC=2140/2937; RULEC=56/2937
def reward(d, easy):
    e=d['err'][easy].mean(); f=easy.mean()
    return (1-(f*RULEC+(1-f)*SIMC))-10*f*e, f, e
grid23=np.concatenate([np.arange(-0.1,0.3,0.01),np.arange(0.3,1.0,0.05),[9]])
grid12=np.concatenate([np.arange(-0.02,0.2,0.005),np.arange(0.2,1.0,0.05),[9]])
def cell23(d): 
    c1=np.where(d['p1']==9,2,np.where(d['p1']==8,1,0))
    return c1*100+d['p2']*10+d['p3']
def cell12(d): return d['p1']*10+d['p2']
def fitcell(g, cells, ncell, other_ok, err, grid):
    th=np.full(ncell,9.0)
    for c in range(ncell):
        s=other_ok&(cells==c)
        if s.sum()==0: continue
        gc=g[s]; ec=err[s]; best=-1e9
        for t in grid:
            inc=gc>t
            v=inc.sum()*(1-RULEC)-10*ec[inc].sum()+(~inc).sum()*(1-SIMC)
            if v>best: best=v; th[c]=t
    return th
slope=0.035; m2th=0.06
def run(d, th23, th12, slope=slope, m2th=m2th):
    g23=d['m2']-d['m3']-slope*d['m2']; g12=d['m1']-d['m2']
    return (d['m2']>m2th)&(g23>th23[cell23(d)])&(g12>th12[cell12(d)])
th12=np.full(100,0.0125); th23=np.full(300,0.0)
for it in range(3):
    g23=A['m2']-A['m3']-slope*A['m2']; g12=A['m1']-A['m2']
    ok=(A['m2']>m2th)&(g12>th12[cell12(A)])
    th23=fitcell(g23,cell23(A),300,ok,A['err'],grid23)
    ok=(A['m2']>m2th)&(g23>th23[cell23(A)])
    th12=fitcell(g12,cell12(A),100,ok,A['err'],grid12)
    print(it,"A",reward(A,run(A,th23,th12)),"B",reward(B,run(B,th23,th12)))
np.set_printoptions(precision=3, suppress=True, linewidth=200)
print(th12.reshape(10,10))
print(th23[:100].reshape(10,10)); print(th23[100:200].reshape(10,10)); print(th23[200:].reshape(10,10))
# m2 threshold scan
for mt in [0.0,0.03,0.06,0.1,0.15]:
    print("m2th",mt,reward(B,run(B,th23,th12,m2th=mt)))
