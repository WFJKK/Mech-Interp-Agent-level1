
import numpy as np, time
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rn=entries['rule_only_v1']['nodes']
T23=np.array(rn[12]['value'],dtype=np.int64); T12=np.array(rn[21]['value'],dtype=np.int64)
G23=np.array(rn[11]['value']); G12=np.array(rn[20]['value'])
code23=np.array([(T23[q]>>(5*r))&31 for q in range(100) for r in range(10)])
code12=np.array([(T12[q]>>(4*r))&15 for q in range(10) for r in range(10)])
rng=np.random.default_rng(21)
X=rng.standard_normal((3000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
th23=G23[code23[(p2*10+p1)*10+p3]]; th12=G12[code12[p2*10+p1]]
cm2=m2>0.06; c23=(m2-m3-0.035*m2)>th23; c12=(m1-m2)>th12
zone=cm2&~c23&c12
Xz=X[zone]; Yz=Y[zone]; print("zone frac",zone.mean(),"n",zone.sum(),"Y==p2",(Yz==p2[zone]).mean(),"Y==p3",(Yz==p3[zone]).mean())
# features
F=np.concatenate([Xz, m[zone], idx[zone], (m2-m3)[zone,None], (m1-m2)[zone,None], (m3-m4)[zone,None]],1)
lab=(Yz==p3[zone]).astype(int)  # predict p3 vs not
try:
    from sklearn.ensemble import HistGradientBoostingClassifier
    n=len(F); ntr=int(n*0.8)
    t0=time.time()
    clf=HistGradientBoostingClassifier(max_iter=300,max_leaf_nodes=63,learning_rate=0.1,categorical_features=list(range(20,30)))
    clf.fit(F[:ntr],lab[:ntr]); print("fit time",time.time()-t0)
    pr=clf.predict_proba(F[ntr:])[:,1]
    acc=((pr>0.5)==lab[ntr:]).mean(); print("GBT acc (p3 vs not)",acc, "baseline",1-lab[ntr:].mean())
    # how much of the zone can be classified with confidence >0.93 ?
    for c in [0.9,0.93,0.95,0.97]:
        conf=np.maximum(pr,1-pr)>c
        print(c, "frac confident",conf.mean(),"acc there",((pr>0.5)==lab[ntr:])[conf].mean())
except Exception as ex:
    print("sklearn problem",ex)
