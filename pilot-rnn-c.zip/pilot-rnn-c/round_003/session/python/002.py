
import numpy as np, time
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(0)
X=rng.standard_normal((400000,10))
Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06)
print("easy frac",easy.mean(),"easy acc",(Y[easy]==p2[easy]).mean(),"hard acc",(Y[~easy]==p2[~easy]).mean())
hard=~easy
for name,c in [("p1",p1),("p2",p2),("p3",p3),("p4",p4)]:
    print(name,"hard: Y==",(Y[hard]==c[hard]).mean())
print("Y in {p2,p3} hard:",((Y[hard]==p2[hard])|(Y[hard]==p3[hard])).mean())
print("Y in {p1,p2,p3} hard:",((Y[hard]==p2[hard])|(Y[hard]==p3[hard])|(Y[hard]==p1[hard])).mean())
print("Y in {p1,p2,p3,p4} hard:",((Y[hard]==p2[hard])|(Y[hard]==p3[hard])|(Y[hard]==p1[hard])|(Y[hard]==p4[hard])).mean())
r=measure(entries['best']); print(r)
