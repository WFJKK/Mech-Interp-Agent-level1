
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(1)
X=rng.standard_normal((2000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06)
err=(Y!=p2)
E=err[easy]; print("easy frac",easy.mean(),"easy err",E.mean())
for name,f in [("p1",p1),("p2",p2),("p3",p3),("p4",p4)]:
    fe=f[easy]; print(name, [round(E[fe==k].mean(),4) for k in range(10)])
# what does the net output when wrong in easy region
Ye=Y[easy]; 
print("wrong->p1",(Ye[E]==p1[easy][E]).mean(),"->p3",(Ye[E]==p3[easy][E]).mean(),"->p4",(Ye[E]==p4[easy][E]).mean())
# error vs m2-m3 gap bins within easy
g23=(m2-m3)[easy]; g12=(m1-m2)[easy]; M2=m2[easy]
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1),(1,9)]:
    s=(g23>=lo)&(g23<hi); print("g23",lo,hi,round(s.mean(),3),round(E[s].mean(),4))
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1),(1,9)]:
    s=(g12>=lo)&(g12<hi); print("g12",lo,hi,round(s.mean(),3),round(E[s].mean(),4))
for lo,hi in [(0,0.2),(0.2,0.5),(0.5,1),(1,1.5),(1.5,2),(2,9)]:
    s=(M2>=lo)&(M2<hi); print("m2",lo,hi,round(s.mean(),3),round(E[s].mean(),4))
