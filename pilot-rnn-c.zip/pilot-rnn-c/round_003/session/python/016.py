
import numpy as np, pickle, os
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
def feats(seed,n):
    rng=np.random.default_rng(seed)
    X=rng.standard_normal((n,10)); Y=net(X)
    idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
    m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
    return dict(Y=Y,p1=p1,p2=p2,p3=p3,m1=m1,m2=m2,m3=m3,err=(Y!=p2))
A=feats(10,6000000); B=feats(11,2000000)
SIMC=2140/2937; RULEC=70/2937
def reward(d, easy):
    e=d['err'][easy].mean(); f=easy.mean()
    return round((1-(f*RULEC+(1-f)*SIMC))-10*f*e,4), round(f,4), round(e,5)
G23=np.array([-1,-0.05,-0.03,-0.02,-0.01,0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.10,0.12,0.14,0.16,0.18,0.20,0.25,0.30,0.35,0.40,0.50,0.60,0.75,0.90,1.2,1.5,9.0])
G12=np.array([-1,0,0.005,0.01,0.015,0.02,0.03,0.04,0.06,0.08,0.1,0.15,0.2,0.3,0.5,9.0])
def fitcell(g, cells, ncell, other_ok, err, grid, floor=-9):
    code=np.full(ncell,len(grid)-1)
    order=np.argsort(cells,kind='stable'); cs=cells[order]
    starts=np.searchsorted(cs,np.arange(ncell+1))
    allowed=grid>=floor
    for c in range(ncell):
        ids=order[starts[c]:starts[c+1]]; ids=ids[other_ok[ids]]
        if len(ids)==0: continue
        gc=g[ids]; ec=err[ids].astype(float)
        inc=gc[None,:]>grid[:,None]
        v=inc.sum(1)*(1-RULEC)-10*(inc*ec[None,:]).sum(1)+(~inc).sum(1)*(1-SIMC)
        v[~allowed]=-1e18
        code[c]=np.argmax(v)
    return code
def c3(d): return (d['p2']*10+d['p1'])*10+d['p3']
def c12(d): return d['p2']*10+d['p1']
def run(d, code23, code12, slope=0.035, m2th=0.06):
    g23=d['m2']-d['m3']-slope*d['m2']; g12=d['m1']-d['m2']
    return (d['m2']>m2th)&(g23>G23[code23[c3(d)]])&(g12>G12[code12[c12(d)]])
out={}
for floor in [-9, 0.0, 0.02]:
    slope=0.035; m2th=0.06
    code12=np.full(100,3); code23=np.full(1000,5)
    for it in range(2):
        g23=A['m2']-A['m3']-slope*A['m2']; g12=A['m1']-A['m2']
        ok=(A['m2']>m2th)&(g12>G12[code12[c12(A)]])
        code23=fitcell(g23,c3(A),1000,ok,A['err'],G23,floor)
        ok=(A['m2']>m2th)&(g23>G23[code23[c3(A)]])
        code12=fitcell(g12,c12(A),100,ok,A['err'],G12, 0.01 if floor>-9 else -9)
    print("floor",floor,"A",reward(A,run(A,code23,code12)),"B",reward(B,run(B,code23,code12)))
    out[floor]=(code23.copy(),code12.copy())
os.makedirs('tmp',exist_ok=True); pickle.dump(out,open('tmp/codes.pkl','wb'))
print(np.bincount(out[-9][0],minlength=32)); print(np.bincount(out[-9][1],minlength=16))
