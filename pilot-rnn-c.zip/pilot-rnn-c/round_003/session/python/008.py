
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(2)
X=rng.standard_normal((3000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
easy=(m1-m2>0.0125)&(m2-m3>0.02+0.035*m2+0.08*(p1==9))&(m2>0.06)
err=(Y!=p2)
np.set_printoptions(precision=3, suppress=True, linewidth=200)
def table(mask, a, b):
    T=np.full((10,10),np.nan)
    for i in range(10):
        for j in range(10):
            t=mask&(a==i)&(b==j)
            if t.sum()>200: T[i,j]=err[t].mean()
    return T
s=easy&(p1!=9)
print("p1!=9 easy: err by (p2,p3)\n",table(s,p2,p3))
print("p1!=9 easy: err by (p1,p2)\n",table(s,p1,p2))
print("p1!=9 easy: err by (p1,p3)\n",table(s,p1,p3))
s=easy&(p1==9)
print("p1==9 easy: err by (p2,p3)\n",table(s,p2,p3))
