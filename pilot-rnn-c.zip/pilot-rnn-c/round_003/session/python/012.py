
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(10)
X=rng.standard_normal((4000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3=idx[:,9],idx[:,8],idx[:,7]
m=np.take_along_axis(X,idx,1); m1,m2,m3=m[:,9],m[:,8],m[:,7]
err=Y!=p2; g23=m2-m3; g12=m1-m2
bins=[0,0.02,0.05,0.1,0.15,0.2,0.3,0.4,0.6,0.8,1.2,9]
def curve(mask,label):
    out=[]
    for lo,hi in zip(bins[:-1],bins[1:]):
        t=mask&(g23>=lo)&(g23<hi)
        out.append((round(err[t].mean(),3) if t.sum()>50 else None, int(t.sum()), round((Y[t]==p3[t]).mean(),2) if t.sum()>50 else None))
    print(label, out)
ok=(g12>0.05)&(m2>0.2)
for (a,b) in [(7,0),(1,4),(4,1),(7,4),(6,3),(5,8),(0,7),(8,2),(8,5),(2,6)]:
    curve(ok&(p1==9)&(p2==a)&(p3==b), f"p1=9 p2={a} p3={b}")
print("---- p1!=9")
for (a,b) in [(7,3),(8,5),(8,4),(0,1),(1,2),(3,0),(4,0)]:
    curve(ok&(p1!=9)&(p2==a)&(p3==b), f"p1!=9 p2={a} p3={b}")
