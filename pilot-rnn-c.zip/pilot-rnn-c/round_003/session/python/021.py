
import numpy as np
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*W + h@R.T,0)
    return (h@O.T).argmax(1)
rn=entries['rule_only_v1']['nodes']
T23=np.array(rn[12]['value'],dtype=np.int64); T12=np.array(rn[21]['value'],dtype=np.int64)
G23=np.array(rn[11]['value']); G12=np.array(rn[20]['value'])
code23=np.array([(T23[q]>>(5*r))&31 for q in range(100) for r in range(10)])
code12=np.array([(T12[q]>>(4*r))&15 for q in range(10) for r in range(10)])
rng=np.random.default_rng(11)
X=rng.standard_normal((3000000,10)); Y=net(X)
idx=np.argsort(X,1); p1,p2,p3,p4=idx[:,9],idx[:,8],idx[:,7],idx[:,6]
m=np.take_along_axis(X,idx,1); m1,m2,m3,m4=m[:,9],m[:,8],m[:,7],m[:,6]
err=Y!=p2
th23=G23[code23[(p2*10+p1)*10+p3]]; th12=G12[code12[p2*10+p1]]
cm2=m2>0.06; c23=(m2-m3-0.035*m2)>th23; c12=(m1-m2)>th12
easy=cm2&c23&c12
print("easy",easy.mean(),"err",err[easy].mean())
print("hard reasons: m2",(~cm2).mean(),"g23",(~c23).mean(),"g12",(~c12).mean(), "only m2",(~cm2&c23&c12).mean(),"only g23",(cm2&~c23&c12).mean(),"only g12",(cm2&c23&~c12).mean())
E=easy&err
print("easy errors: Y==p1",(Y[E]==p1[E]).mean(),"p3",(Y[E]==p3[E]).mean(),"p4",(Y[E]==p4[E]).mean())
# error by m3-m4 gap among easy
g34=m3-m4
for lo,hi in [(0,0.02),(0.02,0.05),(0.05,0.1),(0.1,0.3),(0.3,9)]:
    t=easy&(g34>=lo)&(g34<hi); print("g34",lo,hi,round(t.sum()/easy.sum(),3),round(err[t].mean(),4),"Y==p4",round((Y[t]==p4[t]).mean(),4))
# error by m2 among easy, by p1==9
for lo,hi in [(0.06,0.1),(0.1,0.2),(0.2,0.4),(0.4,0.8),(0.8,1.5),(1.5,9)]:
    t=easy&(m2>=lo)&(m2<hi); print("m2",lo,hi,round(t.sum()/easy.sum(),3),round(err[t].mean(),4))
# the hard-by-m2-only region: error rate by p2 cell and m2
t=(~cm2)&c23&c12
print("m2-hard frac",t.mean(),"err",err[t].mean())
for lo,hi in [(-9,-0.3),(-0.3,0),(0,0.03),(0.03,0.06)]:
    u=t&(m2>=lo)&(m2<hi); print(" m2",lo,hi,round(u.mean(),4),round(err[u].mean(),4))
