
import json, copy
old=entries['best']; rule=entries['rule_only_v1']
nodes=copy.deepcopy(old['nodes']); off=len(nodes)-8
for i in range(8,len(rule['nodes'])):
    n=copy.deepcopy(rule['nodes'][i])
    if 'args' in n: n['args']=[a if a<8 else a+off for a in n['args']]
    nodes.append(n)
pred=old['predict']
nodes[pred]['args'][0]=rule['rule']+off
# GC: reachable from pred
reach=set(); stack=[pred]
while stack:
    i=stack.pop()
    if i in reach: continue
    reach.add(i); stack.extend(nodes[i].get('args',[]))
keep=sorted(reach); remap={o:n for n,o in enumerate(keep)}
new=[]
for o in keep:
    n=copy.deepcopy(nodes[o])
    if 'args' in n: n['args']=[remap[a] for a in n['args']]
    new.append(n)
ent={'format':old['format'],'nodes':new,'predict':remap[pred],'rule':None}
print(len(new))
# sanity via load
gg,interp,reg=lv1.Graph.load(ent, weights, 10)
print(interp.value, reg)
res=measure(ent); print(res)
save_entry("hybrid_cells_v1", ent)
