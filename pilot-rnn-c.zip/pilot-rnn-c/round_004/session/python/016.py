
import numpy as np
best = entries['best']; nodes = best['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value']); P5 = np.array(nodes[19]['value'])
G12 = np.array(nodes[29]['value']); T12 = np.array(nodes[30]['value']); P4 = np.array(nodes[32]['value'])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
def gen(seed, N, chunk=1_000_000):
    rng = np.random.default_rng(seed); out=[]
    for i in range(0, N, chunk):
        X = rng.standard_normal((chunk,10)); y = sim(X)
        idx = np.argsort(X,1,kind='stable'); p1,p2,p3,p4 = idx[:,9],idx[:,8],idx[:,7],idx[:,6]
        ar=np.arange(chunk); out.append((np.stack([y,p1,p2,p3,p4],1).astype(np.int8), np.stack([X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]],1).astype(np.float32)))
    return np.concatenate([o[0] for o in out]), np.concatenate([o[1] for o in out])
N=8_000_000
I,F = gen(6, N)
y,p1,p2,p3,p4 = [I[:,k].astype(np.int64) for k in range(5)]; m1,m2,m3,m4 = [F[:,k].astype(np.float64) for k in range(4)]
del I,F
err = (y!=p2); cell = (p1*100+p2*10+p3)
CE = 66/2937; CH=2206/2937
ve = (1-CE-10*err.astype(np.float32)).astype(np.float32); vh = 1-CH
def tune(mask, cells, g, ncell, grid):
    lev = np.searchsorted(grid, g, side='right')
    tot = np.zeros((ncell, len(grid)+1)); np.add.at(tot, (cells[mask], lev[mask]), (ve-vh)[mask])
    cum = np.cumsum(tot[:, ::-1], axis=1)[:, ::-1]
    gain = np.concatenate([cum[:,1:], np.zeros((ncell,1))],1)
    return gain.argmax(1)
def thr(cells, kb, grid):
    k = kb[cells]; return np.where(k < len(grid), grid[np.minimum(k, len(grid)-1)], np.inf)
half = np.arange(N) < N//2
g0 = m2-m3-0.035*m2; g12 = m1-m2; c_m2 = m2>0.06
f = (g12<0.3).astype(int)
G16 = np.array([-1,-0.02,0,0.01,0.02,0.03,0.04,0.05,0.06,0.08,0.1,0.14,0.2,0.3,0.5,9.0])
def joint(cells23, n23, cells12, n12, grid23, grid12, iters=3, mask=half):
    c12 = g12 > thr(cells12, tune(np.ones(N,bool)&mask, cells12, g12, n12, grid12) if False else np.zeros(n12,int), grid12)
    # start from current T12 thresholds
    th12 = G12[(T12[p2]//P4[p1])%16]
    c12 = g12 > th12
    for it in range(iters):
        kb23 = tune(c_m2 & c12 & mask, cells23, g0, n23, grid23); th23 = thr(cells23, kb23, grid23); c23 = g0 > th23
        kb12 = tune(c_m2 & c23 & mask, cells12, g12, n12, grid12); th12 = thr(cells12, kb12, grid12); c12 = g12 > th12
    easy = c_m2 & c23 & c12
    r = np.where(easy, ve, vh)
    return kb23, kb12, float(r[mask].mean()), float(r[~mask].mean()), float(easy[~mask].mean())
cells12 = p1*10+p2
print("base joint 32/16:", joint(cell,1000,cells12,100,G23,G12)[2:])
print("base joint 16/16:", joint(cell,1000,cells12,100,G16,G12)[2:])
kb23,kb12,ri,ro,eo = joint(cell+1000*f,2000,cells12,100,G16,G12); print("feat joint 16/16:", ri,ro,eo)
# systematic? compare thresholds f=0 vs f=1
t0 = kb23[:1000]; t1 = kb23[1000:]
valid = (t0<16)&(t1<16)
print("mean level f0/f1:", t0[valid].mean(), t1[valid].mean(), "frac f1>f0", (t1[valid]>t0[valid]).mean(), "frac equal", (t1[valid]==t0[valid]).mean())
# additive global shift alternative: g = g0 - d*f  (threshold effectively higher by d when f=1)
for d in [-0.02,-0.01,0.01,0.02,0.03,0.05]:
    gg = g0 - d*f
    g0_save = g0; g0 = gg
    print("shift", d, joint(cell,1000,cells12,100,G16,G12)[2:])
    g0 = g0_save
# feature on the 12 side too
f12 = (g0<0.1).astype(int)
print("feat both:", joint(cell+1000*f,2000,cells12+100*f12,200,G16,G12)[2:])
