
import numpy as np
best = entries['best']
lines=[]
for i,n in enumerate(best['nodes'][60:], start=60):
    d = {k:(v if k!='value' else (np.array(v).shape)) for k,v in n.items()}
    s = f"{i} {d['op']} " + " ".join(f"{k}={v}" for k,v in d.items() if k!='op')
    lines.append(s)
print("\n".join(lines))
