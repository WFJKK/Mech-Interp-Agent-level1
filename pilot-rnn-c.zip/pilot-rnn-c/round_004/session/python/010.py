
import numpy as np
best = entries['best']; nodes = best['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value']); P5 = np.array(nodes[19]['value'])
G12 = np.array(nodes[29]['value']); T12 = np.array(nodes[30]['value']); P4 = np.array(nodes[32]['value'])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def simH(X):
    h = np.zeros((X.shape[0],16)); O=[]
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0); O.append((h@R.T).argmax(1))
    return np.stack(O,1)  # output if readout after step t
def rule(X):
    idx = np.argsort(X,1,kind='stable'); p1,p2,p3,p4 = idx[:,9],idx[:,8],idx[:,7],idx[:,6]
    ar=np.arange(len(X)); m1,m2,m3,m4 = X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]
    easy = (m2>0.06) & ((m2-m3-0.035*m2) > G23[(T23[p2*10+p1]//P5[p3])%32]) & ((m1-m2) > G12[(T12[p2]//P4[p1])%16])
    return easy,p1,p2,p3,p4,m1,m2,m3,m4
rng = np.random.default_rng(3)
X = rng.standard_normal((1000000,10))
O = simH(X); y = O[:,9]
easy,p1,p2,p3,p4,m1,m2,m3,m4 = rule(X)
hard = ~easy
tstar = np.maximum(np.maximum(p1,p2),p3)
print("hard frac", hard.mean())
for t in range(2,10):
    sel = hard & (tstar==t)
    agree = (O[sel,t]==y[sel]).mean()
    print(f"t*={t}: frac of hard {sel.sum()/hard.sum():.3f}, agree(readout after t*) {agree:.4f}")
# also with the 4th included
tstar4 = np.maximum(tstar,p4)
for t in range(3,10):
    sel = hard & (tstar4==t)
    print(f"t4*={t}: frac {sel.sum()/hard.sum():.3f}, agree {(O[sel,t]==y[sel]).mean():.4f}")
