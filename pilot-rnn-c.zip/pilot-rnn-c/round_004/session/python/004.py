
for i,n in enumerate(best['nodes'][60:], start=60):
    d = {k:(v if k!='value' else (np.array(v).shape)) for k,v in n.items()}
    print(i, d)
