
import numpy as np
best = entries['best']; nodes = best['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value']); P5 = np.array(nodes[19]['value'])
G12 = np.array(nodes[29]['value']); T12 = np.array(nodes[30]['value']); P4 = np.array(nodes[32]['value'])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
def gen(seed, N, chunk=1_000_000):
    rng = np.random.default_rng(seed); out=[]
    for i in range(0, N, chunk):
        X = rng.standard_normal((chunk,10)); y = sim(X)
        idx = np.argsort(X,1,kind='stable'); p1,p2,p3,p4 = idx[:,9],idx[:,8],idx[:,7],idx[:,6]
        ar=np.arange(chunk); out.append(np.stack([y,p1,p2,p3,p4],1).astype(np.int8)); 
        out[-1] = (out[-1], np.stack([X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]],1).astype(np.float32))
    I = np.concatenate([o[0] for o in out]); F = np.concatenate([o[1] for o in out])
    return I, F
N=8_000_000
I,F = gen(6, N)
y,p1,p2,p3,p4 = [I[:,k].astype(np.int64) for k in range(5)]; m1,m2,m3,m4 = [F[:,k].astype(np.float64) for k in range(4)]
del I,F
c_m2 = (m2>0.06); c12 = ((m1-m2) > G12[(T12[p2]//P4[p1])%16])
err = (y!=p2); cell = (p1*100+p2*10+p3)
CE = 66/2937; CH=2206/2937
ve = (1-CE-10*err.astype(np.float32)).astype(np.float32); vh = 1-CH
def tune(mask, cells, g, ncell, grid):
    lev = np.searchsorted(grid, g, side='right')
    tot = np.zeros((ncell, len(grid)+1)); np.add.at(tot, (cells[mask], lev[mask]), (ve-vh)[mask])
    cum = np.cumsum(tot[:, ::-1], axis=1)[:, ::-1]
    gain = np.concatenate([cum[:,1:], np.zeros((ncell,1))],1)
    return gain.argmax(1)
def evaluate(mask, cells, g, kb, grid):
    k = kb[cells]; th = np.where(k < len(grid), grid[np.minimum(k, len(grid)-1)], np.inf)
    easy = mask & (g > th)
    return np.where(easy, ve, vh).mean(), easy.mean()
half = np.arange(N) < N//2
base_mask = c_m2 & c12
def holdout(cells, g, ncell, grid=G23):
    kb = tune(base_mask & half, cells, g, ncell, grid)
    r_in,_ = evaluate(base_mask & half, cells, g, kb, grid); r_out,e_out = evaluate(base_mask & ~half, cells, g, kb, grid)
    return round(2*r_in - vh,5), round(2*r_out - vh,5), round(e_out*2,4)
g0 = m2-m3-0.035*m2
print("base (1000 cells): in/out", holdout(cell, g0, 1000))
rng = np.random.default_rng(7); rf = rng.integers(0,2,N)
print("random feat (2000 cells): in/out", holdout(cell+1000*rf, g0, 2000))
for name,f in {'m1-m2<0.3':(m1-m2)<0.3, 'm3-m4<0.2':(m3-m4)<0.2, 'm2<0.8':m2<0.8, 'm3-m4<0.1':(m3-m4)<0.1, 'm1-m2<0.2':(m1-m2)<0.2}.items():
    print(name, holdout(cell+1000*f.astype(int), g0, 2000))
for a,b,c in [(0.035,0.05,0),(0.035,0.1,0),(0.035,-0.05,0),(0.035,0,0.05),(0.035,0,-0.05),(0.035,0,0.1),(0.035,0,-0.1),(0.02,0,0),(0.05,0,0)]:
    gg = m2-m3-a*m2-b*(m3-m4)-c*(m1-m2)
    print((a,b,c), holdout(cell, gg, 1000))
