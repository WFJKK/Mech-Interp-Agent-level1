
import numpy as np
def simw(X, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(8); perm = rng.permutation(16)
W1 = {'input': weights['input'][perm], 'recurrent': weights['recurrent'][perm][:,perm], 'readout': weights['readout'][:,perm]}
X = rng.standard_normal((3000,10)); y = simw(X, W1)
ev = lv1.Evaluator(entries['feat_v1'], W1, 10)
res = np.array([ev.run(xx)[1:4:2] for xx in X]); ans=res[:,0]; costs=res[:,1]; hard=costs>100
print("feat_v1 on permuted net: sim-branch exact", (ans[hard]==y[hard]).mean(), "fid", (ans==y).mean())
# fresh fidelity estimate of feat_v3's rule via numpy (decode tables from the entry)
e = entries['feat_v3']; nodes = e['nodes']
consts = {i:n for i,n in enumerate(nodes) if n['op']=='const'}
sizes = {i:np.array(n['value']).size for i,n in consts.items()}
T23 = [n['value'] for i,n in consts.items() if sizes[i]==134][0]; P = [n['value'] for i,n in consts.items() if sizes[i]==15][0]
T12 = [n['value'] for i,n in consts.items() if sizes[i]==10][0]; G23 = np.array([n['value'] for i,n in consts.items() if sizes[i]==16 and n['dtype']=='float' and n['value'][-1]==9.0 and n['value'][1]==-0.02][0])
G12 = np.array([n['value'] for i,n in consts.items() if sizes[i]==16 and n['dtype']=='float' and n['value'][1]==0.0][0])
T23=np.array([int(v) for v in T23],dtype=object); P=np.array([int(v) for v in P],dtype=object); T12=np.array([int(v) for v in T12],dtype=object)
lev23 = np.array([int((T23[c//15]//P[c%15])%16) for c in range(2000)]); lev12 = np.array([[int((T12[b]//P[a])%16) for b in range(10)] for a in range(10)])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
tot=0; errs=0; easyn=0
for k in range(8):
    X = rng.standard_normal((1_000_000,10)); y = simw(X, weights)
    idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]; ar=np.arange(len(X)); m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
    f = ((m1-m2)<0.3).astype(int)
    easy = (m2>0.06)&((m2-m3-0.025*m2)>G23[lev23[f*1000+p1*100+p2*10+p3]])&((m1-m2)>G12[lev12[p1,p2]])
    errs += (easy & (y!=p2)).sum(); tot += len(X); easyn += easy.sum()
print("feat_v3 fresh 8M: fidelity", 1-errs/tot, "easy frac", easyn/tot, "expected errors per 16384:", 16384*errs/tot)
