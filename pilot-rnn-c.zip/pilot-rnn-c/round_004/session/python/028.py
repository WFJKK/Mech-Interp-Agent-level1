
import numpy as np
e = entries['feat_v3']; nodes = e['nodes']
consts = [(i,n['dtype'],np.array(n['value']).size, (n['value'][:3] if np.array(n['value']).size>1 else n['value'])) for i,n in enumerate(nodes) if n['op']=='const']
for c in consts: print(c)
