
import numpy as np
e = entries['feat_v2']
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(77); X = rng.standard_normal((20000,10)); y = sim(X)
ev = lv1.Evaluator(e, weights, 10)
costs = np.array([ev.run(xx)[3] for xx in X]); easy = costs < 100
idx = np.argsort(X,1); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]; ar=np.arange(len(X)); m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
g23 = m2-m3; g12 = m1-m2
print("easy frac", easy.mean(), "easy err here", (y[easy]!=p2[easy]).mean())
for name, sel in [("g23<0.03", g23<0.03), ("0.03<=g23<0.06", (g23>=0.03)&(g23<0.06)), ("0.06<=g23<0.1", (g23>=0.06)&(g23<0.1)), ("g12<0.02", g12<0.02), ("0.02<=g12<0.05", (g12>=0.02)&(g12<0.05)), ("m2<0.15", m2<0.15), ("p1==9", p1==9)]:
    s = easy & sel
    print(f"{name}: share of all inputs {s.mean():.4f}, err here {(y[s]!=p2[s]).mean():.3f}")
# what the plain 'second largest' rule errs overall (what another seed sees without tables) in the hard-by-generic-standard zone
