
import numpy as np, time, gc
t0=time.time()
best = entries['best']; bn = best['nodes']
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
N=24_000_000; chunk=1_000_000
rng = np.random.default_rng(2024)
cell = np.empty(N, np.int32); cells12 = np.empty(N, np.int32); err = np.empty(N, bool)
g0 = np.empty(N, np.float32); g12 = np.empty(N, np.float32); c_m2 = np.empty(N, bool)
slope=0.025; ft=0.3
for i in range(0, N, chunk):
    X = rng.standard_normal((chunk,10)); y = sim(X)
    idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]
    ar=np.arange(chunk); m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
    d12 = m1-m2
    cell[i:i+chunk] = p1*100+p2*10+p3 + 1000*(d12<ft); cells12[i:i+chunk] = p1*10+p2
    err[i:i+chunk] = (y!=p2); g0[i:i+chunk] = m2-m3-slope*m2; g12[i:i+chunk] = d12; c_m2[i:i+chunk] = m2>0.06
del X, idx; gc.collect()
print("gen", time.time()-t0)
CE = 73/2937; CH=2210/2937
dv = ((1-CE-10*err.astype(np.float32)) - np.float32(1-CH)).astype(np.float32)
def tune(mask, cells, g, ncell, grid):
    lev = np.searchsorted(grid, g, side='right')
    tot = np.zeros((ncell, len(grid)+1)); np.add.at(tot, (cells[mask], lev[mask]), dv[mask])
    cum = np.cumsum(tot[:, ::-1], axis=1)[:, ::-1]
    gain = np.concatenate([cum[:,1:], np.zeros((ncell,1))],1)
    return np.minimum(gain.argmax(1), len(grid)-1)
G16a = np.array([-1,-0.02,0,0.01,0.02,0.03,0.04,0.05,0.06,0.08,0.1,0.14,0.2,0.3,0.5,9.0], dtype=np.float32)
G12 = np.array(bn[29]['value'], dtype=np.float32)
c12 = g12 > 0.02
for it in range(6):
    kb23 = tune(c_m2 & c12, cell, g0, 2000, G16a); c23 = g0 > G16a[kb23[cell]]
    kb12 = tune(c_m2 & c23, cells12, g12, 100, G12); c12 = g12 > G12[kb12[cells12]]
easy = c_m2 & c23 & c12
rew = np.where(easy, 1-CE-10*err, 1-CH).mean()
print("tuned 24M: reward(no CI)", rew, "easy", easy.mean(), "easy err", err[easy].mean(), "fid", 1-(easy&err).mean(), time.time()-t0)
# compare with feat_v2's tables (decode from its nodes) on this sample
def pack(codes, per, bits):
    base = 1<<bits; out=[]
    for i in range(0, len(codes), per):
        v = 0
        for j,c in enumerate(codes[i:i+per]): v += int(c) * (base**j)
        out.append(v)
    return out
def build_rule(lev23_flat, lev12_T_flat, grid23, grid12, feat_thr, m2thr=0.06, slope=0.035, per=15):
    g = graph()
    x = g.tokens(); idx = lv1.argsort(x, axis=0)
    p1_, p2_, p3_ = idx[9], idx[8], idx[7]
    m1_, m2_, m3_ = x[p1_], x[p2_], x[p3_]
    d12 = m1_ - m2_
    P = g.const(np.array([16**k for k in range(per)], dtype=np.int64))
    T23c = g.const(np.array(pack(lev23_flat, per, 4), dtype=np.int64))
    T12c = g.const(np.array(pack(lev12_T_flat, 10, 4), dtype=np.int64))
    G23c = g.const(np.array(grid23, dtype=float)); G12c = g.const(np.array(grid12, dtype=float))
    c = p1_ * 100 + p2_ * 10 + p3_
    c = lv1.where(d12 < feat_thr, c + 1000, c)
    th23 = G23c[(T23c[c // per] // P[c % per]) % 16]
    th12 = G12c[(T12c[p2_] // P[p1_]) % 16]
    easy = (m2_ > m2thr) & ((m2_ - m3_ - slope * m2_) > th23) & (d12 > th12)
    return g, g.entry(interpretation=p2_, region=easy)
def splice(rule_entry, fix=True, step3=True):
    rn = rule_entry['nodes']; K = len(rn); p2_new = rule_entry['predict']; easy_new = rule_entry['rule']
    nodes = [dict(n) for n in rn]; shift = K - 40
    def remap(a):
        if a == 0: return 0
        if a == 2: return p2_new
        return a + shift
    for n in bn[40:326]:
        m = dict(n)
        if 'args' in m: m['args'] = [remap(a) for a in m['args']]
        nodes.append(m)
    S = lambda i: i + shift
    sim_out = S(325); zero = S(52)
    if fix:
        for i in range(K, len(nodes)):
            n = nodes[i]
            if n['op']=='slice' and n.get('index')==[14]:
                n['index'] = [{'start':14,'step':None,'stop':16}]
                for j in range(K, len(nodes)):
                    u = nodes[j]
                    if u['op']=='eq' and u.get('args',[None])[0]==i:
                        nodes.append({'op':'sum','args':[i],'axis':None}); u['args'] = [len(nodes)-1, zero]
    if step3:
        nodes.append({'op':'reshape','args':[S(136)],'shape':[2,16]}); r2 = len(nodes)-1
        nodes.append({'op':'transpose','args':[r2]}); rT = len(nodes)-1
        nodes.append({'op':'reshape','args':[S(46)],'shape':[1]}); x1v = len(nodes)-1
        nodes.append({'op':'reshape','args':[S(120)],'shape':[1]}); x0v = len(nodes)-1
        nodes.append({'op':'concat','args':[x1v,x0v],'axis':0}); xv = len(nodes)-1
        nodes.append({'op':'matmul','args':[rT,xv]}); mv = len(nodes)-1
        nodes.append({'op':'add','args':[S(45),mv]}); v3 = len(nodes)-1
        nodes[S(143)]['args'] = [v3, zero]
    nodes.append({'op':'cond','args':[easy_new, p2_new, sim_out]}); out = len(nodes)-1
    order=[]; seen=set()
    def visit(i):
        if i in seen: return
        seen.add(i)
        for a in nodes[i].get('args',[]): visit(a)
        order.append(i)
    visit(out); newidx = {old:k for k,old in enumerate(order)}; new_nodes=[]
    for old in order:
        n = dict(nodes[old])
        if 'args' in n: n['args'] = [newidx[a] for a in n['args']]
        new_nodes.append(n)
    return {'format': best['format'], 'nodes': new_nodes, 'predict': newidx[out], 'rule': None}
lev12_T = np.zeros(100,int)
for a in range(10):
    for b in range(10): lev12_T[b*10+a] = kb12[a*10+b]
g, re = build_rule(kb23, lev12_T, G16a.astype(float), G12.astype(float), ft, slope=slope)
e = splice(re)
print("nodes", len(e['nodes']), "consts", sum(np.array(n['value']).size for n in e['nodes'] if n['op']=='const'))
# verify exactness of entry vs numpy expectation on fresh inputs
rng2 = np.random.default_rng(555); X = rng2.standard_normal((6000,10)); yy = sim(X)
idx = np.argsort(X,1,kind='stable'); q1,q2,q3 = idx[:,9],idx[:,8],idx[:,7]; ar=np.arange(len(X)); n1,n2,n3 = X[ar,q1],X[ar,q2],X[ar,q3]
ff = ((n1-n2)<ft).astype(int)
easy_ = (n2>0.06)&((n2-n3-slope*n2)>G16a[kb23[ff*1000+q1*100+q2*10+q3]])&((n1-n2)>G12[kb12[q1*10+q2]])
exp = np.where(easy_,q2,yy)
ev = lv1.Evaluator(e, weights, 10); ans = np.array([ev.run(xx)[1] for xx in X])
print("agree expected", (ans==exp).mean(), "fid", (ans==yy).mean())
save_entry('feat_v3', e)
print(measure(e))
