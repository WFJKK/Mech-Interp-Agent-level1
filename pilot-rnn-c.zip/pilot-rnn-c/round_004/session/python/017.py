
import numpy as np, json, copy
best = entries['best']; bn = best['nodes']
G23 = np.array(bn[12]['value']); T23 = np.array(bn[13]['value'], dtype=object); P5 = np.array(bn[19]['value'],dtype=object)
G12 = np.array(bn[29]['value']); T12 = np.array(bn[30]['value'],dtype=object); P4 = np.array(bn[32]['value'],dtype=object)
# decode current per-cell levels: th23 cell (p1,p2,p3): code = (T23[p2*10+p1] // P5[p3]) % 32
lev23 = np.zeros((10,10,10),int)
for a in range(10):
    for b in range(10):
        for c in range(10):
            lev23[a,b,c] = int((int(T23[b*10+a]) // int(P5[c])) % 32)
lev12 = np.zeros((10,10),int)
for a in range(10):
    for b in range(10): lev12[a,b] = int((int(T12[b]) // int(P4[a])) % 16)
# sim nodes referencing rule nodes?
refs = set()
for i,n in enumerate(bn[40:326], start=40):
    for a in n.get('args',[]):
        if a < 40: refs.add(a)
print("sim refs into rule:", refs)

def pack(codes, per, bits):
    # codes: flat int array in [0, 2^bits); returns list of python ints
    base = 1<<bits; out=[]
    for i in range(0, len(codes), per):
        v = 0
        for j,c in enumerate(codes[i:i+per]): v += int(c) * (base**j)
        out.append(v)
    return out

def build_rule(lev23_flat, lev12_flat, grid23, grid12, feat_thr, m2thr=0.06, slope=0.035, per=15):
    """lev23_flat: length 2000 (index = f*1000 + p1*100 + p2*10 + p3), lev12_flat: length 100 (index p1*10+p2), 4-bit codes."""
    g = graph()
    x = g.tokens(); idx = lv1.argsort(x, axis=0)
    p1, p2, p3 = idx[9], idx[8], idx[7]
    m1, m2, m3 = x[p1], x[p2], x[p3]
    d12 = m1 - m2
    P = g.const(np.array([16**k for k in range(per)], dtype=object).astype(np.int64))
    T23c = g.const(np.array(pack(lev23_flat, per, 4), dtype=np.int64))
    T12c = g.const(np.array(pack(lev12_flat, 10, 4), dtype=np.int64))
    G23c = g.const(np.array(grid23, dtype=float)); G12c = g.const(np.array(grid12, dtype=float))
    c = p1 * 100 + p2 * 10 + p3
    c = lv1.where(d12 < feat_thr, c + 1000, c)
    th23 = G23c[(T23c[c // per] // P[c % per]) % 16]
    th12 = G12c[(T12c[p2] // P[p1]) % 16]
    easy = (m2 > m2thr) & ((m2 - m3 - slope * m2) > th23) & (d12 > th12)
    return g, g.entry(interpretation=p2, region=easy)

def splice(rule_entry, fix=True):
    rn = rule_entry['nodes']; K = len(rn)
    p2_new = rule_entry['predict']; easy_new = rule_entry['rule']
    assert rn[0]['op']=='tokens'
    nodes = [dict(n) for n in rn]
    shift = K - 40
    def remap(a):
        if a == 0: return 0
        if a == 2: return p2_new
        assert a >= 40, a
        return a + shift
    for n in bn[40:326]:
        m = dict(n)
        if 'args' in m: m['args'] = [remap(a) for a in m['args']]
        nodes.append(m)
    sim_out = 325 + shift
    zero = 52 + shift
    if fix:
        # replace: slice[14] -> eq 0  with  sum(slice[14:16]) == 0
        for i in range(K, len(nodes)):
            n = nodes[i]
            if n['op']=='slice' and n.get('index')==[14]:
                n['index'] = [{'start':14,'step':None,'stop':16}]
                # find eq users
                for j in range(K, len(nodes)):
                    u = nodes[j]
                    if u['op']=='eq' and u.get('args',[None])[0]==i:
                        nodes.append({'op':'sum','args':[i],'axis':None}); u['args'] = [len(nodes)-1, zero]
    nodes.append({'op':'cond','args':[easy_new, p2_new, sim_out]})
    out = len(nodes)-1
    # topological re-order by DFS
    order=[]; seen=set()
    def visit(i):
        if i in seen: return
        seen.add(i)
        for a in nodes[i].get('args',[]): visit(a)
        order.append(i)
    visit(out)
    newidx = {old:k for k,old in enumerate(order)}
    new_nodes=[]
    for old in order:
        n = dict(nodes[old])
        if 'args' in n: n['args'] = [newidx[a] for a in n['args']]
        new_nodes.append(n)
    e = {'format': best['format'], 'nodes': new_nodes, 'predict': newidx[out], 'rule': None}
    return e

# equivalence test with current levels: lev23 is 5-bit (32 levels); map onto its own 32-grid? we need 16-level. For the test, use a 32-grid with per=12 and 5 bits -> just test machinery with 4-bit by clipping codes (not equivalent). Instead test: build with f feature irrelevant (same codes both halves), codes = lev23 clipped to 15, grid = G23[:16].
lev23_flat = np.concatenate([np.minimum(lev23.reshape(-1),15)]*2)
lev12_flat = lev12.reshape(-1)
g, re = build_rule(lev23_flat, lev12_flat, G23[:16], G12, 0.3)
print("rule nodes", len(re['nodes']))
e = splice(re, fix=True)
print("total nodes", len(e['nodes']), "consts", sum(np.array(n['value']).size for n in e['nodes'] if n['op']=='const'))
# verify vs numpy on random inputs
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(11); X = rng.standard_normal((4000,10)); y = sim(X)
ev = lv1.Evaluator(e, weights, 10)
idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]; ar=np.arange(4000)
m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
th23 = G23[:16][np.minimum(lev23[p1,p2,p3],15)]; th12 = G12[lev12[p1,p2]]
easy = (m2>0.06)&((m2-m3-0.035*m2)>th23)&((m1-m2)>th12)
exp = np.where(easy, p2, y)
ans=[]; costs=[]
for xx in X:
    inside,a,cr,cp = ev.run(xx); ans.append(a); costs.append(cp)
ans=np.array(ans); costs=np.array(costs)
print("agree with expected", (ans==exp).mean(), "agree with net", (ans==y).mean(), "easy cost", np.unique(costs[easy]), "hard mean", costs[~easy].mean())
save_entry('tmp_machinery', e)
