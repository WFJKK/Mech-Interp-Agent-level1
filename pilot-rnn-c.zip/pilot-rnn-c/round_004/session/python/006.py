
import numpy as np
best = entries['best']; nodes = best['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value']); P5 = np.array(nodes[19]['value'])
G12 = np.array(nodes[29]['value']); T12 = np.array(nodes[30]['value']); P4 = np.array(nodes[32]['value'])
m2thr = nodes[4]['value']; slope = nodes[9]['value']; mod23 = nodes[22]['value']; mod12 = nodes[35]['value']; mul14 = nodes[14]['value']
print(m2thr, slope, mod23, mod12, mul14, P5, P4)
print("G23", G23); print("G12", G12)
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
def rule(X):
    idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]
    m1 = X[np.arange(len(X)),p1]; m2 = X[np.arange(len(X)),p2]; m3 = X[np.arange(len(X)),p3]
    e = (m2 > m2thr)
    g23 = m2-m3-slope*m2
    th23 = G23[(T23[p2*mul14+p1]//P5[p3]) % mod23]
    th12 = G12[(T12[p2]//P4[p1]) % mod12]
    easy = e & (g23 > th23) & ((m1-m2) > th12)
    return easy, p1,p2,p3,m1,m2,m3
rng = np.random.default_rng(1)
X = rng.standard_normal((1000000,10))
y = sim(X)
easy,p1,p2,p3,m1,m2,m3 = rule(X)
print("easy frac", easy.mean(), "err easy", (y[easy]!=p2[easy]).mean(), "overall err", (np.where(easy,p2,y)!=y).mean())
hard=~easy
print("hard: out==p2", (y[hard]==p2[hard]).mean(), "==p3", (y[hard]==p3[hard]).mean(), "==p1", (y[hard]==p1[hard]).mean())
# which of the three conditions fail in hard
print("m2 fail", (~(m2>m2thr))[hard].mean(), "g23 fail", (~((m2-m3-slope*m2)>G23[(T23[p2*mul14+p1]//P5[p3]) % mod23]))[hard].mean(), "g12 fail", (~((m1-m2)>G12[(T12[p2]//P4[p1]) % mod12]))[hard].mean())
