
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
best = entries['best']
print(len(best['nodes']), best['predict'], best['rule'])
from collections import Counter
print(Counter(n.get('op') for n in best['nodes']))
# print nodes with their ops in a compact form
for i,n in enumerate(best['nodes'][:60]):
    print(i, {k:(v if k!='value' else (np.array(v).shape)) for k,v in n.items()})
