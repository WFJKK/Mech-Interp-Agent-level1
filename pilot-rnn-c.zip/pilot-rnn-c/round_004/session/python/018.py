
import numpy as np
best = entries['best']; bn = best['nodes']
G23 = np.array(bn[12]['value']); T23 = bn[13]['value']; P5 = bn[19]['value']
G12 = np.array(bn[29]['value']); T12 = bn[30]['value']; P4 = bn[32]['value']
lev23 = np.zeros((10,10,10),int); lev12 = np.zeros((10,10),int)
for a in range(10):
    for b in range(10):
        lev12[a,b] = int((int(T12[b]) // int(P4[a])) % 16)
        for c in range(10): lev23[a,b,c] = int((int(T23[b*10+a]) // int(P5[c])) % 32)
def pack(codes, per, bits):
    base = 1<<bits; out=[]
    for i in range(0, len(codes), per):
        v = 0
        for j,c in enumerate(codes[i:i+per]): v += int(c) * (base**j)
        out.append(v)
    return out
def build_rule(lev23_flat, lev12_T_flat, grid23, grid12, feat_thr, m2thr=0.06, slope=0.035, per=15):
    g = graph()
    x = g.tokens(); idx = lv1.argsort(x, axis=0)
    p1, p2, p3 = idx[9], idx[8], idx[7]
    m1, m2, m3 = x[p1], x[p2], x[p3]
    d12 = m1 - m2
    P = g.const(np.array([16**k for k in range(per)], dtype=np.int64))
    T23c = g.const(np.array(pack(lev23_flat, per, 4), dtype=np.int64))
    T12c = g.const(np.array(pack(lev12_T_flat, 10, 4), dtype=np.int64))
    G23c = g.const(np.array(grid23, dtype=float)); G12c = g.const(np.array(grid12, dtype=float))
    c = p1 * 100 + p2 * 10 + p3
    c = lv1.where(d12 < feat_thr, c + 1000, c)
    th23 = G23c[(T23c[c // per] // P[c % per]) % 16]
    th12 = G12c[(T12c[p2] // P[p1]) % 16]
    easy = (m2 > m2thr) & ((m2 - m3 - slope * m2) > th23) & (d12 > th12)
    return g, g.entry(interpretation=p2, region=easy)
def splice(rule_entry, fix=True):
    rn = rule_entry['nodes']; K = len(rn); p2_new = rule_entry['predict']; easy_new = rule_entry['rule']
    nodes = [dict(n) for n in rn]; shift = K - 40
    def remap(a):
        if a == 0: return 0
        if a == 2: return p2_new
        return a + shift
    for n in bn[40:326]:
        m = dict(n)
        if 'args' in m: m['args'] = [remap(a) for a in m['args']]
        nodes.append(m)
    sim_out = 325 + shift; zero = 52 + shift
    if fix:
        for i in range(K, len(nodes)):
            n = nodes[i]
            if n['op']=='slice' and n.get('index')==[14]:
                n['index'] = [{'start':14,'step':None,'stop':16}]
                for j in range(K, len(nodes)):
                    u = nodes[j]
                    if u['op']=='eq' and u.get('args',[None])[0]==i:
                        nodes.append({'op':'sum','args':[i],'axis':None}); u['args'] = [len(nodes)-1, zero]
    nodes.append({'op':'cond','args':[easy_new, p2_new, sim_out]}); out = len(nodes)-1
    order=[]; seen=set()
    def visit(i):
        if i in seen: return
        seen.add(i)
        for a in nodes[i].get('args',[]): visit(a)
        order.append(i)
    visit(out); newidx = {old:k for k,old in enumerate(order)}; new_nodes=[]
    for old in order:
        n = dict(nodes[old])
        if 'args' in n: n['args'] = [newidx[a] for a in n['args']]
        new_nodes.append(n)
    return {'format': best['format'], 'nodes': new_nodes, 'predict': newidx[out], 'rule': None}
lev23_flat = np.concatenate([np.minimum(lev23.reshape(-1),15)]*2)
lev12_T_flat = lev12.T.reshape(-1)   # index p2*10+p1
g, re = build_rule(lev23_flat, lev12_T_flat, G23[:16], G12, 0.3)
e = splice(re, fix=True)
print("total nodes", len(e['nodes']), "consts", sum(np.array(n['value']).size for n in e['nodes'] if n['op']=='const'))
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(11); X = rng.standard_normal((6000,10)); y = sim(X)
ev = lv1.Evaluator(e, weights, 10)
idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]; ar=np.arange(len(X))
m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
th23 = G23[:16][np.minimum(lev23[p1,p2,p3],15)]; th12 = G12[lev12[p1,p2]]
easy = (m2>0.06)&((m2-m3-0.035*m2)>th23)&((m1-m2)>th12)
exp = np.where(easy, p2, y)
ans=[]; costs=[]
for xx in X:
    inside,a,cr,cp = ev.run(xx); ans.append(a); costs.append(cp)
ans=np.array(ans); costs=np.array(costs)
print("agree with expected", (ans==exp).mean(), "easy cost", np.unique(costs[easy]), "hard mean", costs[~easy].mean(), "n hard", (~easy).sum())
# also check the fix didn't change sim results: compare with best on hard inputs
ev0 = lv1.Evaluator(best, weights, 10)
a0 = np.array([ev0.run(xx)[1] for xx in X[~easy]])
print("sim agree best vs new on hard:", (a0==ans[~easy]).mean(), "net agree on hard:", (ans[~easy]==y[~easy]).mean())
