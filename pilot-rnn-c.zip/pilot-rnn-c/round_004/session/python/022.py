
import numpy as np, time
t0=time.time()
best = entries['best']; bn = best['nodes']
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
def gen(seed, N, chunk=1_000_000):
    rng = np.random.default_rng(seed); out=[]
    for i in range(0, N, chunk):
        X = rng.standard_normal((chunk,10)); y = sim(X)
        idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]
        ar=np.arange(chunk); out.append((np.stack([y,p1,p2,p3],1).astype(np.int8), np.stack([X[ar,p1],X[ar,p2],X[ar,p3]],1).astype(np.float32)))
    return np.concatenate([o[0] for o in out]), np.concatenate([o[1] for o in out])
N=12_000_000
I,F = gen(21, N)
y,p1,p2,p3 = [I[:,k].astype(np.int32) for k in range(4)]; m1,m2,m3 = [F[:,k].astype(np.float64) for k in range(3)]
del I,F
err = (y!=p2); cell = (p1*100+p2*10+p3).astype(np.int32); cells12 = (p1*10+p2).astype(np.int32)
CE = 73/2937; CH=2210/2937
ve = (1-CE-10*err.astype(np.float32)).astype(np.float32); vh = np.float32(1-CH); dv = ve - vh
g12 = m1-m2; c_m2 = m2>0.06
def tune(mask, cells, g, ncell, grid):
    lev = np.searchsorted(grid, g, side='right')
    tot = np.zeros((ncell, len(grid)+1)); np.add.at(tot, (cells[mask], lev[mask]), dv[mask])
    cum = np.cumsum(tot[:, ::-1], axis=1)[:, ::-1]
    gain = np.concatenate([cum[:,1:], np.zeros((ncell,1))],1)
    return np.minimum(gain.argmax(1), len(grid)-1)
def thr(cells, kb, grid): return grid[kb[cells]]
def joint(cells23, n23, cells12, n12, grid23, grid12, g0, iters=5):
    c12 = g12 > 0.02
    for it in range(iters):
        kb23 = tune(c_m2 & c12, cells23, g0, n23, grid23); c23 = g0 > thr(cells23, kb23, grid23)
        kb12 = tune(c_m2 & c23, cells12, g12, n12, grid12); c12 = g12 > thr(cells12, kb12, grid12)
    easy = c_m2 & c23 & c12; r = np.where(easy, ve, vh)
    return kb23, kb12, float(r.mean()), float(easy.mean()), float(err[easy].mean())
G16a = np.array([-1,-0.02,0,0.01,0.02,0.03,0.04,0.05,0.06,0.08,0.1,0.14,0.2,0.3,0.5,9.0])
G12 = np.array(bn[29]['value'])
ft=0.3; f = (g12<ft).astype(np.int32); slope=0.025; g0 = m2-m3-slope*m2
kb23, kb12, rin, easyfrac, easyerr = joint(cell+1000*f,2000,cells12,100,G16a,G12,g0)
print("tuned", rin, easyfrac, "easy err", easyerr, "overall fid", 1-easyfrac*easyerr, time.time()-t0)
def pack(codes, per, bits):
    base = 1<<bits; out=[]
    for i in range(0, len(codes), per):
        v = 0
        for j,c in enumerate(codes[i:i+per]): v += int(c) * (base**j)
        out.append(v)
    return out
def build_rule(lev23_flat, lev12_T_flat, grid23, grid12, feat_thr, m2thr=0.06, slope=0.035, per=15):
    g = graph()
    x = g.tokens(); idx = lv1.argsort(x, axis=0)
    p1_, p2_, p3_ = idx[9], idx[8], idx[7]
    m1_, m2_, m3_ = x[p1_], x[p2_], x[p3_]
    d12 = m1_ - m2_
    P = g.const(np.array([16**k for k in range(per)], dtype=np.int64))
    T23c = g.const(np.array(pack(lev23_flat, per, 4), dtype=np.int64))
    T12c = g.const(np.array(pack(lev12_T_flat, 10, 4), dtype=np.int64))
    G23c = g.const(np.array(grid23, dtype=float)); G12c = g.const(np.array(grid12, dtype=float))
    c = p1_ * 100 + p2_ * 10 + p3_
    c = lv1.where(d12 < feat_thr, c + 1000, c)
    th23 = G23c[(T23c[c // per] // P[c % per]) % 16]
    th12 = G12c[(T12c[p2_] // P[p1_]) % 16]
    easy = (m2_ > m2thr) & ((m2_ - m3_ - slope * m2_) > th23) & (d12 > th12)
    return g, g.entry(interpretation=p2_, region=easy)
def splice(rule_entry, fix=True, step3=True):
    rn = rule_entry['nodes']; K = len(rn); p2_new = rule_entry['predict']; easy_new = rule_entry['rule']
    nodes = [dict(n) for n in rn]; shift = K - 40
    def remap(a):
        if a == 0: return 0
        if a == 2: return p2_new
        return a + shift
    for n in bn[40:326]:
        m = dict(n)
        if 'args' in m: m['args'] = [remap(a) for a in m['args']]
        nodes.append(m)
    S = lambda i: i + shift
    sim_out = S(325); zero = S(52)
    if fix:
        for i in range(K, len(nodes)):
            n = nodes[i]
            if n['op']=='slice' and n.get('index')==[14]:
                n['index'] = [{'start':14,'step':None,'stop':16}]
                for j in range(K, len(nodes)):
                    u = nodes[j]
                    if u['op']=='eq' and u.get('args',[None])[0]==i:
                        nodes.append({'op':'sum','args':[i],'axis':None}); u['args'] = [len(nodes)-1, zero]
    if step3:
        # v3 = w*x2 (45) + row(136) as (16,2) @ [x1 (46), x0 (120)]
        nodes.append({'op':'reshape','args':[S(136)],'shape':[2,16]}); r2 = len(nodes)-1
        nodes.append({'op':'transpose','args':[r2]}); rT = len(nodes)-1
        nodes.append({'op':'reshape','args':[S(46)],'shape':[1]}); x1v = len(nodes)-1
        nodes.append({'op':'reshape','args':[S(120)],'shape':[1]}); x0v = len(nodes)-1
        nodes.append({'op':'concat','args':[x1v,x0v],'axis':0}); xv = len(nodes)-1
        nodes.append({'op':'matmul','args':[rT,xv]}); mv = len(nodes)-1
        nodes.append({'op':'add','args':[S(45),mv]}); v3 = len(nodes)-1
        assert nodes[S(143)]['op']=='maximum' and nodes[S(143)]['args']==[S(142), zero]
        nodes[S(143)]['args'] = [v3, zero]
    nodes.append({'op':'cond','args':[easy_new, p2_new, sim_out]}); out = len(nodes)-1
    order=[]; seen=set()
    def visit(i):
        if i in seen: return
        seen.add(i)
        for a in nodes[i].get('args',[]): visit(a)
        order.append(i)
    visit(out); newidx = {old:k for k,old in enumerate(order)}; new_nodes=[]
    for old in order:
        n = dict(nodes[old])
        if 'args' in n: n['args'] = [newidx[a] for a in n['args']]
        new_nodes.append(n)
    return {'format': best['format'], 'nodes': new_nodes, 'predict': newidx[out], 'rule': None}
lev12_T = np.zeros(100,int)
for a in range(10):
    for b in range(10): lev12_T[b*10+a] = kb12[a*10+b]
g, re = build_rule(kb23, lev12_T, G16a, G12, ft, slope=slope)
e = splice(re, fix=True, step3=True)
print("nodes", len(e['nodes']), "consts", sum(np.array(n['value']).size for n in e['nodes'] if n['op']=='const'))
# check transpose semantics: evaluate on fresh inputs vs feat_v1
rng = np.random.default_rng(123); X = rng.standard_normal((6000,10)); yy = sim(X)
ev = lv1.Evaluator(e, weights, 10); ev1 = lv1.Evaluator(entries['feat_v1'], weights, 10)
ans=[];costs=[];ans1=[];costs1=[]
for xx in X:
    _,a,_,cp = ev.run(xx); ans.append(a); costs.append(cp)
    _,a1,_,cp1 = ev1.run(xx); ans1.append(a1); costs1.append(cp1)
ans=np.array(ans); costs=np.array(costs); ans1=np.array(ans1); costs1=np.array(costs1)
hard = costs1>100
print("agree with feat_v1", (ans==ans1).mean(), "fid", (ans==yy).mean(), "hard mean cost new/old", costs[hard].mean(), costs1[hard].mean())
save_entry('feat_v2', e)
print(measure(e))
