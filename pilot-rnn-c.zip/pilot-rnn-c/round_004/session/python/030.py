
save_entry('best_r4', entries['feat_v3'])
save_entry('best', entries['feat_v3'])
print(sorted(entries.keys()))
