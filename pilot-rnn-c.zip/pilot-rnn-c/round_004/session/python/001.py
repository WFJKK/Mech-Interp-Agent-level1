
import json, numpy as np
print(list(entries.keys()))
print(info.keys())
print({k:(v if not hasattr(v,'shape') else v.shape) for k,v in info.items() if k!='dataset'})
best = entries['best']
print(type(best), list(best.keys()) if isinstance(best, dict) else None)
m = measure(best); print(m)
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print(w); print(rec); print(R)
