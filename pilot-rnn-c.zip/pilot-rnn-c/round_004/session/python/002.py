
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X, keep=False):
    N = X.shape[0]; h = np.zeros((N,16)); H=[]
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
        H.append(h.copy())
    out = (h@R.T).argmax(1)
    return (out, np.stack(H,1)) if keep else out
rng = np.random.default_rng(0)
X = rng.standard_normal((200000,10))
out, H = sim(X, keep=True)
s = np.sort(X,1); m1,m2,m3 = s[:,9],s[:,8],s[:,7]
hard = ~((m1-m2>0.0125)&(m2-m3>0.02+0.035*m2)&(m2>0.06))
print("hard frac", hard.mean())
Z = (H==0)
print("zero frac per step (rows) per unit (cols), hard inputs:")
print(np.round(Z[hard].mean(0),2))
print("all inputs:"); print(np.round(Z.mean(0),2))
# how many zero units per step on hard
print("mean #zero units per step", np.round(Z[hard].sum(2).mean(0),2))
# pattern on the 5 sparse units
sp=[0,3,6,10,15]
pat = (Z[hard][:,:,sp]*np.array([1,2,4,8,16])).sum(2)
for t in range(3,10):
    vals,c = np.unique(pat[:,t], return_counts=True)
    o=np.argsort(-c)[:8]; print(t, [(int(vals[i]), round(c[i]/len(pat),3)) for i in o])
