
import numpy as np
e = entries['feat_v2']
def simw(X, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(5)
perm = rng.permutation(16)
W1 = {'input': weights['input'][perm], 'recurrent': weights['recurrent'][perm][:,perm], 'readout': weights['readout'][:,perm]}
W2 = {'input': rng.standard_normal((16,1))*3, 'recurrent': rng.standard_normal((16,16))*0.4, 'readout': rng.standard_normal((10,16))}
for name,W in [('permuted', W1), ('random', W2), ('orig', weights)]:
    X = rng.standard_normal((3000,10)); y = simw(X, W)
    ev = lv1.Evaluator(e, W, 10)
    ans=[];costs=[]
    for xx in X:
        _,a,_,cp = ev.run(xx); ans.append(a); costs.append(cp)
    ans=np.array(ans); costs=np.array(costs); hard = costs>100
    print(name, "n hard", hard.sum(), "sim-branch exact:", (ans[hard]==y[hard]).mean(), "hard mean cost", costs[hard].mean(), "overall fid", (ans==y).mean())
# same check for the old best (no fix)
for name,W in [('permuted', W1)]:
    X = rng.standard_normal((3000,10)); y = simw(X, W)
    ev = lv1.Evaluator(entries['best'], W, 10)
    ans=[];costs=[]
    for xx in X:
        _,a,_,cp = ev.run(xx); ans.append(a); costs.append(cp)
    ans=np.array(ans); costs=np.array(costs); hard = costs>100
    print("OLD best", name, "sim-branch exact:", (ans[hard]==y[hard]).mean())
