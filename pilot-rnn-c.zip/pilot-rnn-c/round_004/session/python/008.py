
import numpy as np
best = entries['best']
ev = lv1.Evaluator(best, weights, 10)
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def simH(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0); H.append(h.copy())
    return (h@R.T).argmax(1), np.stack(H,1)
rng = np.random.default_rng(2)
X = rng.standard_normal((3000,10))
y,H = simH(X)
costs=[]; ans=[]
for x,t in zip(X,y):
    inside, a, cr, cp = ev.run(x); costs.append(cp); ans.append(a)
costs=np.array(costs); ans=np.array(ans)
hardc = costs[costs>200]
print("easy cost", np.unique(costs[costs<=200]), "n hard", len(hardc), "hard mean", hardc.mean(), "min", hardc.min(), "max", hardc.max())
print("fidelity", (ans==y).mean())
# exactness check: unit10==0 => unit15==0 ?
Xb = rng.standard_normal((2000000,10)); yb,Hb = simH(Xb)
viol = ((Hb[:,:,10]==0) & (Hb[:,:,15]>0))
print("violations u10=0 & u15>0:", viol.sum(), "of", viol.size, "per step", viol.sum(0))
# the reverse
viol2 = ((Hb[:,:,15]==0) & (Hb[:,:,10]>0)); print("u15=0 & u10>0:", viol2.sum())
