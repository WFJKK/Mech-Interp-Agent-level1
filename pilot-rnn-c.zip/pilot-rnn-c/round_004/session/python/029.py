
import numpy as np
e = entries['feat_v3']; nodes = e['nodes']
G23 = np.array(nodes[12]['value']); T23 = [int(v) for v in nodes[13]['value']]; P = [int(v) for v in nodes[31]['value']]
G12 = np.array(nodes[40]['value']); T12 = [int(v) for v in nodes[41]['value']]
lev23 = np.array([(T23[c//15]//P[c%15])%16 for c in range(2000)]); lev12 = np.array([[(T12[b]//P[a])%16 for b in range(10)] for a in range(10)])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(31337)
tot=0; errs=0; easyn=0; per16k=[]
for k in range(10):
    X = rng.standard_normal((1_000_000,10)); y = sim(X)
    idx = np.argsort(X,1,kind='stable'); p1,p2,p3 = idx[:,9],idx[:,8],idx[:,7]; ar=np.arange(len(X)); m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
    f = ((m1-m2)<0.3).astype(int)
    easy = (m2>0.06)&((m2-m3-0.025*m2)>G23[lev23[f*1000+p1*100+p2*10+p3]])&((m1-m2)>G12[lev12[p1,p2]])
    ee = (easy & (y!=p2)); errs += ee.sum(); tot += len(X); easyn += easy.sum()
    per16k += list(ee[:983040].reshape(60,16384).sum(1))
per16k=np.array(per16k)
print("feat_v3 fresh 10M: fidelity", 1-errs/tot, "easy frac", easyn/tot, "errors per 16384: mean", per16k.mean(), "sd", per16k.std(), "max", per16k.max(), "frac >= 86:", (per16k>=86).mean())
