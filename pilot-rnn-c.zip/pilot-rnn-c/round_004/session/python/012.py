
import numpy as np, time
best = entries['best']; nodes = best['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value']); P5 = np.array(nodes[19]['value'])
G12 = np.array(nodes[29]['value']); T12 = np.array(nodes[30]['value']); P4 = np.array(nodes[32]['value'])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(5)
N=6_000_000
X = rng.standard_normal((N,10)).astype(np.float64)
y = sim(X)
idx = np.argsort(X,1,kind='stable'); p1,p2,p3,p4 = idx[:,9],idx[:,8],idx[:,7],idx[:,6]
ar=np.arange(N); m1,m2,m3,m4 = X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]
x9 = X[:,9]
del X, idx
c_m2 = (m2>0.06); c12 = ((m1-m2) > G12[(T12[p2]//P4[p1])%16])
g = m2-m3-0.035*m2
err = (y!=p2)
cell = (p1*100+p2*10+p3)
COST_EASY = 66/2937; COST_HARD=2206/2937
def tune(mask, cells, g, err, ncell, grid):
    # for inputs with mask, per cell choose threshold maximizing sum reward; return total reward and thresholds
    # value easy = 1 - COST_EASY - 10*err ; value hard = 1 - COST_HARD
    ve = 1-COST_EASY-10*err.astype(float); vh = 1-COST_HARD
    best_tot = 0.0; ths = np.zeros(ncell)
    # bin g by grid levels: level index = number of grid values < g  => easy iff level > k  (g > grid[k])
    lev = np.searchsorted(grid, g, side='right')  # g > grid[k] iff lev > k
    tot = np.zeros((ncell, len(grid)+1))
    cnt = np.zeros((ncell, len(grid)+1))
    np.add.at(tot, (cells[mask], lev[mask]), ve[mask]-vh)
    # for threshold k: easy iff lev > k ; gain over all-hard = sum_{lev>k} (ve - vh)
    cum = np.cumsum(tot[:, ::-1], axis=1)[:, ::-1]  # cum[:,k] = sum over lev>=k
    gain = np.concatenate([cum[:,1:], np.zeros((ncell,1))],1)  # gain[k] = sum_{lev>k} = cum[k+1]
    kbest = gain.argmax(1); return gain.max(1).sum(), kbest
base_mask = c_m2 & c12
G, kb = tune(base_mask, cell, g, err, 1000, G23)
print("base per-cell gain (sum over inputs, per-input units):", G/N)
# evaluate current entry's thresholds for comparison
th_cur = G23[(T23[p2*10+p1]//P5[p3])%32]
easy_cur = base_mask & (g>th_cur)
print("current rule reward approx:", (np.where(easy_cur, 1-COST_EASY-10*err, 1-COST_HARD)).mean() - COST_EASY*0)
# with binary features
feats = {'p4>p3': p4>p3, 'p4>p2': p4>p2, 'm3-m4<0.1': (m3-m4)<0.1, 'm3-m4<0.05': (m3-m4)<0.05, 'p4==9': p4==9, 'x9>m4': x9>m4, 'm1-m2<0.1': (m1-m2)<0.1, 'm1-m2<0.3':(m1-m2)<0.3, 'm2<0.5': m2<0.5, 'm2<0.8': m2<0.8, 'm3-m4<0.2': (m3-m4)<0.2, 'p4>p1': p4>p1}
for name,f in feats.items():
    G2,_ = tune(base_mask, cell + 1000*f.astype(int), g, err, 2000, G23)
    print(f"{name}: gain {G2/N:.5f}  delta {(G2-G)/N:+.5f}")
