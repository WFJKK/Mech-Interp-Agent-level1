
import inspect, numpy as np
print(inspect.signature(lv1.measure)); print(inspect.signature(lv1.Evaluator.__init__))
print([n for n in dir(lv1.Evaluator) if not n.startswith('_')])
src = inspect.getsource(lv1.measure); print(src[:3000])
