
import numpy as np
best = entries['best']; nodes = best['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value']); P5 = np.array(nodes[19]['value'])
G12 = np.array(nodes[29]['value']); T12 = np.array(nodes[30]['value']); P4 = np.array(nodes[32]['value'])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
def rule(X):
    idx = np.argsort(X,1,kind='stable'); p1,p2,p3,p4 = idx[:,9],idx[:,8],idx[:,7],idx[:,6]
    ar=np.arange(len(X)); m1,m2,m3,m4 = X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]
    c_m2 = (m2>0.06); c23 = ((m2-m3-0.035*m2) > G23[(T23[p2*10+p1]//P5[p3])%32]); c12 = ((m1-m2) > G12[(T12[p2]//P4[p1])%16])
    return c_m2,c23,c12,p1,p2,p3,p4,m1,m2,m3,m4
Xs=[];ys=[]
rng = np.random.default_rng(4)
for i in range(4):
    X = rng.standard_normal((1000000,10)); Xs.append(X); ys.append(sim(X))
X=np.concatenate(Xs); y=np.concatenate(ys)
c_m2,c23,c12,p1,p2,p3,p4,m1,m2,m3,m4 = rule(X)
# g12-fail only cases
sel = c_m2 & c23 & ~c12
print("g12-only-fail frac", sel.mean(), "out==p1", (y[sel]==p1[sel]).mean(), "==p2", (y[sel]==p2[sel]).mean())
g = (m1-m2)[sel]
for lo,hi in [(0,0.005),(0.005,0.01),(0.01,0.02),(0.02,0.04),(0.04,0.1),(0.1,1)]:
    s2 = (g>=lo)&(g<hi); 
    if s2.sum(): print(f"gap12 [{lo},{hi}) n={s2.sum()} p1 {(y[sel][s2]==p1[sel][s2]).mean():.3f} p2 {(y[sel][s2]==p2[sel][s2]).mean():.3f}")
# per cell (p1,p2) at gap<0.01: rate of p1
s2 = sel & ((m1-m2)<0.01)
tab = np.zeros((10,10)); cnt=np.zeros((10,10))
np.add.at(cnt,(p1[s2],p2[s2]),1); np.add.at(tab,(p1[s2],p2[s2]),(y[s2]==p1[s2]))
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print("P(out=p1 | gap12<0.01) by (p1 row, p2 col):"); print(tab/np.maximum(cnt,1)); print(cnt.astype(int))
# g23-only-fail: p3 rate by cell at small gap
sel3 = c_m2 & c12 & ~c23
print("g23-only-fail frac", sel3.mean(), "out==p2", (y[sel3]==p2[sel3]).mean(), "==p3", (y[sel3]==p3[sel3]).mean())
g = (m2-m3)[sel3]
for lo,hi in [(0,0.005),(0.005,0.01),(0.01,0.02),(0.02,0.04),(0.04,0.1),(0.1,1)]:
    s2 = (g>=lo)&(g<hi)
    if s2.sum(): print(f"gap23 [{lo},{hi}) n={s2.sum()} p2 {(y[sel3][s2]==p2[sel3][s2]).mean():.3f} p3 {(y[sel3][s2]==p3[sel3][s2]).mean():.3f}")
