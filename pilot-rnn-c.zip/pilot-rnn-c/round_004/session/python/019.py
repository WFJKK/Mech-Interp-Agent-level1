
import numpy as np, time
t0=time.time()
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0.0)
    return (h@R.T).argmax(1)
def gen(seed, N, chunk=1_000_000):
    rng = np.random.default_rng(seed); out=[]
    for i in range(0, N, chunk):
        X = rng.standard_normal((chunk,10)); y = sim(X)
        idx = np.argsort(X,1,kind='stable'); p1,p2,p3,p4 = idx[:,9],idx[:,8],idx[:,7],idx[:,6]
        ar=np.arange(chunk); out.append((np.stack([y,p1,p2,p3,p4],1).astype(np.int8), np.stack([X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]],1).astype(np.float32)))
    return np.concatenate([o[0] for o in out]), np.concatenate([o[1] for o in out])
N=12_000_000
I,F = gen(21, N)
y,p1,p2,p3 = [I[:,k].astype(np.int32) for k in range(4)]; m1,m2,m3 = [F[:,k].astype(np.float64) for k in range(3)]
del I,F
err = (y!=p2); cell = (p1*100+p2*10+p3).astype(np.int32); cells12 = (p1*10+p2).astype(np.int32)
CE = 73/2937; CH=2226/2937
ve = (1-CE-10*err.astype(np.float32)).astype(np.float32); vh = np.float32(1-CH); dv = ve - vh
g12 = m1-m2; c_m2 = m2>0.06
half = np.arange(N) < N//2
print("gen done", time.time()-t0)
def tune(mask, cells, g, ncell, grid):
    lev = np.searchsorted(grid, g, side='right')
    tot = np.zeros((ncell, len(grid)+1)); np.add.at(tot, (cells[mask], lev[mask]), dv[mask])
    cum = np.cumsum(tot[:, ::-1], axis=1)[:, ::-1]
    gain = np.concatenate([cum[:,1:], np.zeros((ncell,1))],1)
    return np.minimum(gain.argmax(1), len(grid)-1)   # top grid value is 9 = never
def thr(cells, kb, grid): return grid[kb[cells]]
def joint(cells23, n23, cells12, n12, grid23, grid12, g0, iters=3, mask=None):
    if mask is None: mask = np.ones(N,bool)
    c12 = g12 > 0.02   # start
    for it in range(iters):
        kb23 = tune(c_m2 & c12 & mask, cells23, g0, n23, grid23); c23 = g0 > thr(cells23, kb23, grid23)
        kb12 = tune(c_m2 & c23 & mask, cells12, g12, n12, grid12); c12 = g12 > thr(cells12, kb12, grid12)
    easy = c_m2 & c23 & c12; r = np.where(easy, ve, vh)
    return kb23, kb12, float(r[mask].mean()), float(r[~mask].mean()) if (~mask).any() else None, float(easy.mean())
G16a = np.array([-1,-0.02,0,0.01,0.02,0.03,0.04,0.05,0.06,0.08,0.1,0.14,0.2,0.3,0.5,9.0])
G16b = np.array([-1,-0.02,0,0.01,0.02,0.03,0.04,0.05,0.07,0.09,0.12,0.16,0.22,0.3,0.45,9.0])
G12 = np.array(entries['best']['nodes'][29]['value'])
res={}
for slope in [0.035]:
    g0 = m2-m3-slope*m2
    print("base", slope, joint(cell,1000,cells12,100,G16a,G12,g0,mask=half)[2:])
    for ft in [0.2,0.3,0.4,0.5]:
        f = (g12<ft).astype(np.int32)
        for gname,grid in [('a',G16a),('b',G16b)]:
            r = joint(cell+1000*f,2000,cells12,100,grid,G12,g0,mask=half)
            res[(slope,ft,gname)] = r[2:]; print(slope, ft, gname, r[2:], round(time.time()-t0))
for slope in [0.025,0.045]:
    g0 = m2-m3-slope*m2; f = (g12<0.3).astype(np.int32)
    r = joint(cell+1000*f,2000,cells12,100,G16a,G12,g0,mask=half); print("slope", slope, r[2:])
