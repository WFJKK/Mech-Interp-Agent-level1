
import numpy as np
def build_sim_parts(g, t):
    w = g.weight("input")[:, 0]; rec = g.weight("recurrent"); Ro = g.weight("readout")
    cpos = rec @ lv1.maximum(w, 0.0)
    cneg = -(rec @ lv1.maximum(-w, 0.0))
    tables = []; rss = []
    for c in (cpos, cneg):
        r = -w / c
        rs = lv1.sort(r)
        mids = (rs[:-1] + rs[1:]) / 2.0
        u = lv1.concat([rs[0:1] - 1.0, mids, rs[15:16] + 1.0], axis=0)  # 17
        vv = w.reshape(1, 16) + u.reshape(17, 1) * c.reshape(1, 16)       # 17 x 16
        for Pb in (vv > 0.0, vv < 0.0):   # x1>0, x1<0
            P = lv1.cast(Pb, "float")
            A = (P * w.reshape(1, 16)) @ rec.T
            B = (P * c.reshape(1, 16)) @ rec.T
            tables.append(lv1.concat([A, B], axis=1))  # 17 x 32
        rss.append(rs)
    T = lv1.concat(tables, axis=0)  # 68 x 32 ; order: (pos,x1>0),(pos,x1<0),(neg,x1>0),(neg,x1<0)
    x0 = t[0]; x1 = t[1]; x2 = t[2]
    u = x0 / x1
    x0pos = x0 > 0.0
    k = lv1.cond(x0pos, (rss[0] < u).sum(), (rss[1] < u).sum())
    base = lv1.where(x0pos, 0, 34) + lv1.where(x1 > 0.0, 0, 17)
    row = T[base + k]           # 32
    v3 = w * x2 + x1 * row[:16] + x0 * row[16:]
    h = lv1.maximum(v3, 0.0)
    M = lv1.concat([rec, w.reshape(16, 1)], axis=1)
    for kk in range(3, 10):
        hx = lv1.concat([h, t[kk].reshape(1)], axis=0)
        h = lv1.maximum(M @ hx, 0.0)
    return (Ro @ h).argmax()
g = graph(); t = g.tokens()
sim = build_sim_parts(g, t)
ent = g.entry(interpretation=sim)
m = measure(ent); print(m)
save_entry("sim_only_v2", ent)
