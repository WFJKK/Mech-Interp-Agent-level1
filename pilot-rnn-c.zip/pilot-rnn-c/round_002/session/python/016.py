
import numpy as np
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(9)
X = rng.standard_normal((3000000,10)); Y=run(X)
order = np.argsort(X,1); s = np.sort(X,1)
m1,m2,m3=s[:,-1],s[:,-2],s[:,-3]
sel = m2<0
print("m2<0 share", sel.mean())
print("rank of output (1=max):", [(Y[sel]==order[sel][:,-k]).mean().round(3) for k in range(1,11)])
# by m1 sign
for name,ss in [("m1>0",sel&(m1>0)),("m1<0",sel&(m1<0))]:
    print(name, ss.mean(), [(Y[ss]==order[ss][:,-k]).mean().round(3) for k in range(1,11)])
# Y position distribution for m2<0
print("Y dist", np.bincount(Y[sel],minlength=10)/sel.sum())
# relation to position of max
p1=order[:,-1]
print("Y==p1+? ", [((Y[sel]-p1[sel])%10==k).mean().round(3) for k in range(10)])
# sel & m1>0: does network output p1 when ...? check by m1 value
ss=sel&(m1>0)
for lo,hi in [(0,0.3),(0.3,0.6),(0.6,1),(1,1.5),(1.5,3)]:
    q=ss&(m1>=lo)&(m1<hi); print(lo,hi,q.sum(), "out=p1:",(Y[q]==p1[q]).mean().round(3), "out=p2:",(Y[q]==order[q][:,-2]).mean().round(3), "out=p3:",(Y[q]==order[q][:,-3]).mean().round(3))
