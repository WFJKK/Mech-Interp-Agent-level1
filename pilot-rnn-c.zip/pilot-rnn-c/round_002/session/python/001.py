
import numpy as np
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print(info)
for k,v in weights.items(): print(k, v.shape)
print("input", weights["input"][:,0])
print("recurrent\n", weights["recurrent"])
print("readout\n", weights["readout"])
print(list(entries.keys()))
