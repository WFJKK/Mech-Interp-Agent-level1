
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def runH(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0); H.append(h.copy())
    return np.stack(H,1)
rng = np.random.default_rng(3)
X = rng.standard_normal((50000,10))
H = runH(X)
# running stats
cm1 = np.maximum.accumulate(X,1)
cm2 = np.array([np.sort(X[:,:t+1],1)[:,-2] if t>=1 else np.full(len(X),-9.0) for t in range(10)]).T
# argmax so far / arg second so far
for t in [4,9]:
    print("t=",t)
    for u in range(16):
        c1 = np.corrcoef(H[:,t,u], cm1[:,t])[0,1]; c2=np.corrcoef(H[:,t,u], cm2[:,t])[0,1]; cx=np.corrcoef(H[:,t,u], X[:,t])[0,1]
        print(f" u{u}: corr max {c1:.2f} 2nd {c2:.2f} x_t {cx:.2f} mean {H[:,t,u].mean():.1f}")
