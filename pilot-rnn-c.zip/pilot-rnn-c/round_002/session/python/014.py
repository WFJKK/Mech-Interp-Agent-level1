
import numpy as np
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(7)
X = rng.standard_normal((3000000,10)); Y=run(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3,m4 = s[:,-1],s[:,-2],s[:,-3],s[:,-4]
err = (Y!=p2)
g12=m1-m2; g23=m2-m3
def cellreward(feats, nb, cost=0.026, thr=None):
    # feats: list of arrays; bin each into quantile bins nb
    codes=np.zeros(len(X),int); mult=1
    for f,n in zip(feats,nb):
        if f.dtype==bool: c=f.astype(int); k=2
        else:
            q=np.quantile(f, np.linspace(0,1,n+1)[1:-1]); c=np.searchsorted(q,f); k=n
        codes=codes*k+c; mult*=k
    cnt=np.bincount(codes,minlength=mult); ec=np.bincount(codes,weights=err,minlength=mult)
    rate=ec/np.maximum(cnt,1)
    good = rate < (1-cost)/10
    cov = cnt[good].sum()/len(X); fid = 1-ec[good].sum()/max(cnt[good].sum(),1)
    return cov, fid, cov*((1-cost)-10*(1-fid))
print("g23,g12,m2 (20,10,10):", cellreward([g23,g12,m2],[20,10,10]))
print("g23,g12,m2,p1==9:", cellreward([g23,g12,m2,p1==9],[20,10,10,2]))
print("g23,g12,m2,p1==9,p3<p2:", cellreward([g23,g12,m2,p1==9,p3<p2],[20,10,10,2,2]))
print("g23,g12,m2,p1,p2:", cellreward([g23,g12,m2,p1,p2],[15,8,6,10,10]))
print("g23,g12,m2,m3-m4:", cellreward([g23,g12,m2,m3-m4],[20,10,10,5]))
print("g23,g12,m2,m1:", cellreward([g23,g12,m2,m1],[20,10,10,5]))
# current region for reference
reg = (m1-m2>0.01)&(m2-m3>0.03+0.03*m2)&(m2>0.1)
cov=reg.mean(); fid=1-err[reg].mean(); print("current:", cov, fid, cov*((1-0.026)-10*(1-fid)))
