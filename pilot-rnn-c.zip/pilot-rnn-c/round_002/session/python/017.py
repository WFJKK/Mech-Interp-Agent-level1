
import numpy as np
g = graph()
t = g.tokens()
idx = lv1.argsort(t)
p1 = idx[9]; p2 = idx[8]; p3 = idx[7]
m1 = t[p1]; m2 = t[p2]; m3 = t[p3]
g12 = m1 - m2; g23 = m2 - m3
last = lv1.cast(p1 == 9, "float")
region = (g12 > 0.01) & (g23 > 0.015 + 0.035*m2 + 0.06*last) & (m2 > 0.04)
entry = g.entry(interpretation=p2, region=region)
print(measure(entry))
save_entry("sl_argsort_v1", entry)
# variant without the 'last' term
g = graph()
t = g.tokens(); idx = lv1.argsort(t)
p1 = idx[9]; p2 = idx[8]; p3 = idx[7]
m1 = t[p1]; m2 = t[p2]; m3 = t[p3]
region = ((m1 - m2) > 0.01) & ((m2 - m3) > 0.02 + 0.035*m2) & (m2 > 0.04)
entry2 = g.entry(interpretation=p2, region=region)
print(measure(entry2))
save_entry("sl_argsort_v0", entry2)
print(measure(entries['best']))
