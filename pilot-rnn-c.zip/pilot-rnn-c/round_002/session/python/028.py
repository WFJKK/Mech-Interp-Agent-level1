
import numpy as np, collections
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def runH(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0); H.append(h.copy())
    return np.stack(H,1), (h@R.T).argmax(1)
rng = np.random.default_rng(14)
X = rng.standard_normal((300000,10)); H,Y=runH(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3 = s[:,-1],s[:,-2],s[:,-3]
last=(p1==9)
easy=((m1-m2)>0.0125)&((m2-m3)>0.02+0.035*m2+0.08*last)&(m2>0.06)
Z = (H[~easy][:,2:9,:]==0).reshape(-1,16)
units=[0,3,6,2,11,9,4,8,13,10,15]
cnt=collections.Counter(map(tuple, Z[:,units].astype(int)))
tot=len(Z)
print("units", units)
for pat,c in cnt.most_common(15): print(pat, round(c/tot,3))
z036=Z[:,0]&Z[:,3]&Z[:,6]
print("P(2 zero | 036 zero)", Z[z036,2].mean(), "P(2 zero | not)", Z[~z036,2].mean())
print("P(11 zero | 036 zero)", Z[z036,11].mean(), "P(9 zero|036)", Z[z036,9].mean())
print("P(15 zero | 10 nonzero)", Z[~Z[:,10],15].mean())
print("P(036 zero | 10 zero)", z036[Z[:,10]].mean(), "P(036 zero | 10 nonzero)", z036[~Z[:,10]].mean())
