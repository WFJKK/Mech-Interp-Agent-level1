
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    L = h@R.T
    return L, L.argmax(1)
rng = np.random.default_rng(5)
X = rng.standard_normal((2000000,10))
L, Y = run(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3 = s[:,-1],s[:,-2],s[:,-3]
idx=np.arange(len(X))
err = Y!=p2
# current region
reg = (m1-m2>0.01)&(m2-m3>0.03+0.03*m2)&(m2>0.1)
print("region cov", reg.mean(), "err in region", err[reg].mean())
# error rate inside region by p2, p3, p1
for name,p in [("p1",p1),("p2",p2),("p3",p3)]:
    print(name, [round(err[reg&(p==k)].mean()*100,2) for k in range(10)])
# outside region (the rest), error by the same
print("outside: cov", (~reg).mean(), "err", err[~reg].mean())
for name,p in [("p1",p1),("p2",p2),("p3",p3)]:
    print(name, [round(err[~reg&(p==k)].mean()*100,1) for k in range(10)])
