
import json
g = graph(); t = g.tokens()
a = t[0:3]; b = t[4:6]; c = lv1.concat([a, b, t[7].reshape(1)], axis=0); s = c.sum()
e = g.entry(interpretation=lv1.cast(s, "int"))
print(json.dumps(e)[:1500])
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
