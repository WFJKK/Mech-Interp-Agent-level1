
save_entry("best_r2", entries["hybrid_v3"])
print(sorted(entries.keys()))
