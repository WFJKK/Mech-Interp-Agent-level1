
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    L = h@R.T
    return L, L.argmax(1)
rng = np.random.default_rng(2)
X = rng.standard_normal((1000000,10))
L, Y = run(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3 = s[:,-1],s[:,-2],s[:,-3]
# logit margin between p2 and p3
idx = np.arange(len(X))
d = L[idx,p2]-L[idx,p3]
near = (m2-m3<0.15)&(m1-m2>0.05)&(m2>0.1)
print(near.mean(), (Y[near]==p3[near]).mean(), (Y[near]==p2[near]).mean())
# how does margin d relate to m2-m3 ?
g = m2-m3
from numpy.polynomial import polynomial as P
sel = near
print("corr(d, g)", np.corrcoef(d[sel], g[sel])[0,1])
# features: neighbors
def xat(pos, off):
    q = pos+off; ok=(q>=0)&(q<10); return np.where(ok, X[idx, np.clip(q,0,9)], 0.0)
feats = {'g':g, 'm1':m1, 'm2':m2, 'x_p2-1':xat(p2,-1), 'x_p2+1':xat(p2,1), 'x_p3-1':xat(p3,-1), 'x_p3+1':xat(p3,1), 'p2':p2, 'p3':p3, 'p1':p1, 'sum':X.sum(1), 'p2-p3':p2-p3}
for k,v in feats.items():
    print(k, "corr with d:", np.corrcoef(d[sel], v[sel])[0,1].round(3))
