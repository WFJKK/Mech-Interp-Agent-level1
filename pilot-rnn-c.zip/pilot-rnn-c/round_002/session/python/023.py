
import numpy as np
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def runH(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0); H.append(h.copy())
    return np.stack(H,1), (h@R.T).argmax(1)
rng = np.random.default_rng(12)
X = rng.standard_normal((300000,10)); H,Y=runH(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3 = s[:,-1],s[:,-2],s[:,-3]
last=(p1==9)
easy=((m1-m2)>0.0125)&((m2-m3)>0.02+0.035*m2+0.08*last)&(m2>0.06)
Hh = H[~easy]   # hard inputs
Z = (Hh==0)   # N x 10 x 16
print("hard share", (~easy).mean())
print("P(zero) per unit, averaged over steps 2..8:", Z[:,2:9,:].mean((0,1)).round(2))
z0 = Z[:,2:9,0]&Z[:,2:9,3]&Z[:,2:9,6]
print("P(0,3,6 all zero)", z0.mean(), "P(15 zero)", Z[:,2:9,15].mean(), "P(10 zero)", Z[:,2:9,10].mean(), "P(2 zero)", Z[:,2:9,2].mean(), "P(11 zero)", Z[:,2:9,11].mean(), "P(9 zero)", Z[:,2:9,9].mean())
print("P(0,3,6,15 zero)", (z0&Z[:,2:9,15]).mean(), "P(0,3,6,10 zero)", (z0&Z[:,2:9,10]).mean(), "P(10,15 zero)", (Z[:,2:9,10]&Z[:,2:9,15]).mean())
# per step
for t in range(2,9):
    print(t, "036:", (Z[:,t,0]&Z[:,t,3]&Z[:,t,6]).mean().round(2), "15:", Z[:,t,15].mean().round(2), "10:", Z[:,t,10].mean().round(2), "2:", Z[:,t,2].mean().round(2), "11:",Z[:,t,11].mean().round(2), "9:",Z[:,t,9].mean().round(2))
# number of zero entries distribution
nz = Z[:,2:9,:].sum(2)
print("mean #zeros", nz.mean(), np.bincount(nz.ravel())/nz.size)
