
import numpy as np
def build(a=0.01,b=0.015,c=0.035,d=0.04,e=0.06, sim_first=True):
    g = graph()
    t = g.tokens()
    idx = lv1.argsort(t)
    p1 = idx[9]; p2 = idx[8]; p3 = idx[7]
    m1 = t[p1]; m2 = t[p2]; m3 = t[p3]
    last = lv1.cast(p1 == 9, "float")
    easy = ((m1 - m2) > a) & ((m2 - m3) > b + c*m2 + e*last) & (m2 > d)
    w = g.weight("input")[:, 0]; rec = g.weight("recurrent"); Ro = g.weight("readout")
    cpos = rec @ lv1.maximum(w, 0.0)
    cneg = -(rec @ lv1.maximum(-w, 0.0))
    x0 = t[0]; x1 = t[1]
    if sim_first:
        v = w * x1 + x0 * lv1.where(x0 > 0, cpos, cneg)
    else:
        h1 = lv1.maximum(w * x0, 0.0)
        v = w * x1 + rec @ h1
    h = lv1.maximum(v, 0.0)
    M = lv1.concat([rec, w.reshape(16, 1)], axis=1)
    for k in range(2, 10):
        hx = lv1.concat([h, t[k].reshape(1)], axis=0)
        h = lv1.maximum(M @ hx, 0.0)
    sim = (Ro @ h).argmax()
    interp = lv1.cond(easy, p2, sim)
    return g.entry(interpretation=interp)
try:
    ent = build()
    print(measure(ent))
    save_entry("hybrid_v1", ent)
except Exception as ex:
    import traceback; traceback.print_exc()
