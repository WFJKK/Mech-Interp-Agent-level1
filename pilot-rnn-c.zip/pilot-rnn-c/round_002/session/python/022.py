
import numpy as np
def build_sim(g, t):
    w = g.weight("input")[:, 0]; rec = g.weight("recurrent"); Ro = g.weight("readout")
    cpos = rec @ lv1.maximum(w, 0.0)
    cneg = -(rec @ lv1.maximum(-w, 0.0))
    tables = []; rss = []
    for c in (cpos, cneg):
        rs = lv1.sort(-w / c)
        mids = (rs[:-1] + rs[1:]) / 2.0
        u = lv1.concat([rs[0:1] - 1.0, mids, rs[15:16] + 1.0], axis=0)
        vv = w.reshape(1, 16) + u.reshape(17, 1) * c.reshape(1, 16)
        for Pb in (vv > 0.0, vv < 0.0):
            P = lv1.cast(Pb, "float")
            tables.append(lv1.concat([(P * w.reshape(1, 16)) @ rec.T, (P * c.reshape(1, 16)) @ rec.T], axis=1))
        rss.append(rs)
    T = lv1.concat(tables, axis=0)
    x0 = t[0]; x1 = t[1]; x2 = t[2]
    u = x0 / x1
    x0pos = x0 > 0.0
    k = lv1.cond(x0pos, (rss[0] < u).sum(), (rss[1] < u).sum())
    base = lv1.where(x0pos, 0, 34) + lv1.where(x1 > 0.0, 0, 17)
    row = T[base + k]
    h = lv1.maximum(w * x2 + x1 * row[:16] + x0 * row[16:], 0.0)
    M = lv1.concat([rec, w.reshape(16, 1)], axis=1)
    for kk in range(3, 10):
        h = lv1.maximum(M @ lv1.concat([h, t[kk].reshape(1)], axis=0), 0.0)
    return (Ro @ h).argmax()
def build(a,b,c,d,e):
    g = graph(); t = g.tokens()
    idx = lv1.argsort(t)
    p1 = idx[9]; p2 = idx[8]; p3 = idx[7]
    m1 = t[p1]; m2 = t[p2]; m3 = t[p3]
    last = lv1.cast(p1 == 9, "float")
    easy = ((m1 - m2) > a) & ((m2 - m3) > b + c*m2 + e*last) & (m2 > d)
    return g.entry(interpretation=lv1.cond(easy, p2, build_sim(g, t)))
ent = build(0.0125, 0.02, 0.035, 0.06, 0.08)
print(measure(ent)); save_entry("hybrid_v2", ent)
ent0 = build(0.01, 0.03, 0.03, 0.1, 0.0)   # round-1 thresholds, for comparison
print(measure(ent0)); save_entry("hybrid_v2_r1thr", ent0)
