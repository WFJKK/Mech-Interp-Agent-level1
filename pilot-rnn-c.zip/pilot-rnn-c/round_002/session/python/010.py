
import importlib
for m in ["sklearn","scipy","torch","lightgbm","xgboost"]:
    try:
        importlib.import_module(m); print(m,"ok")
    except Exception as e: print(m,"no")
