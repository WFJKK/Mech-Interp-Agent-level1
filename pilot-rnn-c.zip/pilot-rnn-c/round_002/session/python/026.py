
import numpy as np, json
PERM = [0,3,6, 1,2,4,5,7,8,9,11,12,13,14, 10,15]
def build_sim(g, t):
    permc = g.const(np.array(PERM))
    w = lv1.take(g.weight("input")[:, 0], permc, 0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), permc, 0), permc, 1)
    Ro = lv1.take(g.weight("readout"), permc, 1)
    cpos = rec @ lv1.maximum(w, 0.0)
    cneg = -(rec @ lv1.maximum(-w, 0.0))
    tables = []; rss = []
    for c in (cpos, cneg):
        rs = lv1.sort(-w / c)
        mids = (rs[:-1] + rs[1:]) / 2.0
        u = lv1.concat([rs[0:1] - 1.0, mids, rs[15:16] + 1.0], axis=0)
        vv = w.reshape(1, 16) + u.reshape(17, 1) * c.reshape(1, 16)
        for Pb in (vv > 0.0, vv < 0.0):
            P = lv1.cast(Pb, "float")
            tables.append(lv1.concat([(P * w.reshape(1, 16)) @ rec.T, (P * c.reshape(1, 16)) @ rec.T], axis=1))
        rss.append(rs)
    T = lv1.concat(tables, axis=0)
    x0 = t[0]; x1 = t[1]; x2 = t[2]
    u = x0 / x1
    x0pos = x0 > 0.0
    k = lv1.cond(x0pos, (rss[0] < u).sum(), (rss[1] < u).sum())
    base = lv1.where(x0pos, 0, 34) + lv1.where(x1 > 0.0, 0, 17)
    row = T[base + k]
    h = lv1.maximum(w * x2 + x1 * row[:16] + x0 * row[16:], 0.0)
    M = lv1.concat([rec, w.reshape(16, 1)], axis=1)
    Msub = {(a, b): lv1.concat([M[:, a:b], M[:, 16:17]], axis=1) for a in (0, 3) for b in (14, 16)}
    def tree(h, leaf):
        z10 = h[14] == 0.0; z036 = h[0:3].sum() == 0.0
        def pair(b): return lv1.cond(z036, leaf(h, 3, b), leaf(h, 0, b))
        return lv1.cond(z10, pair(14), pair(16))
    for kk in range(3, 10):
        xk = t[kk].reshape(1)
        def leaf(h, a, b, xk=xk): return Msub[(a, b)] @ lv1.concat([h[a:b], xk], axis=0)
        h = lv1.maximum(tree(h, leaf), 0.0)
    L = lv1.cond(h[14] == 0.0, Ro[:, 0:14] @ h[0:14], Ro @ h)
    return L.argmax()
def build(a,b,c,d,e):
    g = graph(); t = g.tokens()
    idx = lv1.argsort(t)
    p1 = idx[9]; p2 = idx[8]; p3 = idx[7]
    m1 = t[p1]; m2 = t[p2]; m3 = t[p3]
    last = lv1.cast(p1 == 9, "float")
    easy = ((m1 - m2) > a) & ((m2 - m3) > b + c*m2 + e*last) & (m2 > d)
    return g.entry(interpretation=lv1.cond(easy, p2, build_sim(g, t)))
ent = build(0.0125, 0.02, 0.035, 0.06, 0.08)
print(len(ent["nodes"]))
m = measure(ent); print(m)
save_entry("hybrid_v3", ent)
