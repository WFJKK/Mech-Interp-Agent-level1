
import numpy as np, time
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    L = h@R.T
    return L, L.argmax(1)
rng = np.random.default_rng(6)
X = rng.standard_normal((3000000,10))
L, Y = run(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3 = s[:,-1],s[:,-2],s[:,-3]
idx=np.arange(len(X))
d = L[idx,p2]-L[idx,p3]
near = (m2-m3<0.3)&(m1-m2>0.02)&(m2>0.1)
Xn, dn = X[near], d[near]
P1,P2,P3 = p1[near],p2[near],p3[near]
print(near.mean(), len(Xn), "sign acc of baseline (always p2):", (dn>0).mean())
def onehot(p): 
    o=np.zeros((len(p),10)); o[np.arange(len(p)),p]=1; return o
F = np.concatenate([Xn, onehot(P1), onehot(P2), onehot(P3), (m2-m3)[near,None], Xn[idx[:len(Xn)]*0, :]*0], 1)[:, :41]
# linear regression first
A = np.c_[F, np.ones(len(F))]
ntr = int(0.8*len(F))
coef,*_ = np.linalg.lstsq(A[:ntr], dn[:ntr], rcond=None)
pred = A[ntr:]@coef
print("linear R2:", 1-((pred-dn[ntr:])**2).mean()/dn[ntr:].var(), "sign acc:", ((pred>0)==(dn[ntr:]>0)).mean())
# MLP
Ftr, dtr = F[:ntr].astype(np.float32), dn[:ntr].astype(np.float32)
Fte, dte = F[ntr:].astype(np.float32), dn[ntr:].astype(np.float32)
H=128; r=np.random.default_rng(0)
W1=r.standard_normal((F.shape[1],H)).astype(np.float32)*0.2; b1=np.zeros(H,np.float32); W2=r.standard_normal((H,1)).astype(np.float32)*0.1; b2=np.zeros(1,np.float32)
params=[W1,b1,W2,b2]; m_=[np.zeros_like(p) for p in params]; v_=[np.zeros_like(p) for p in params]
lr=1e-3; t0=time.time(); step=0
for ep in range(6):
    perm=r.permutation(ntr)
    for i in range(0,ntr,512):
        b=perm[i:i+512]; x=Ftr[b]; y=dtr[b,None]
        z=x@W1+b1; a=np.maximum(z,0); out=a@W2+b2
        g=(out-y)/len(b)*2
        gW2=a.T@g; gb2=g.sum(0); ga=g@W2.T; gz=ga*(z>0); gW1=x.T@gz; gb1=gz.sum(0)
        step+=1
        for p,gr,mm,vv in zip(params,[gW1,gb1,gW2,gb2],m_,v_):
            mm*=0.9; mm+=0.1*gr; vv*=0.999; vv+=0.001*gr*gr
            p-=lr*(mm/(1-0.9**step))/(np.sqrt(vv/(1-0.999**step))+1e-8)
    z=Fte@W1+b1; out=(np.maximum(z,0)@W2+b2)[:,0]
    print(ep, "R2", 1-((out-dte)**2).mean()/dte.var(), "sign acc", ((out>0)==(dte>0)).mean(), time.time()-t0)
