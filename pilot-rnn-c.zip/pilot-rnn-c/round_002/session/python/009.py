
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    L = h@R.T
    return L, L.argmax(1)
rng = np.random.default_rng(5)
X = rng.standard_normal((2000000,10))
L, Y = run(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3 = s[:,-1],s[:,-2],s[:,-3]
err = Y!=p2
reg = (m1-m2>0.01)&(m2-m3>0.03+0.03*m2)&(m2>0.1)
sel = reg&(p1==9)
print("p1=9 in region:", sel.mean(), "err", err[sel].mean())
print("what output:", [(Y[sel&err]==order[sel&err][:,-k]).mean().round(3) for k in range(1,5)])
g12=m1-m2; g23=m2-m3
bins=[0,0.05,0.1,0.2,0.3,0.5,1,2,5]
print("by g12:")
for lo,hi in zip(bins[:-1],bins[1:]):
    ss=sel&(g12>=lo)&(g12<hi); print(f" {lo}-{hi}: n={ss.sum()} err={err[ss].mean():.3f}")
print("by m1:")
bins=[0,0.5,1,1.5,2,2.5,3,5]
for lo,hi in zip(bins[:-1],bins[1:]):
    ss=sel&(m1>=lo)&(m1<hi); print(f" {lo}-{hi}: n={ss.sum()} err={err[ss].mean():.3f}")
print("by g23:")
bins=[0,0.1,0.2,0.3,0.5,1,5]
for lo,hi in zip(bins[:-1],bins[1:]):
    ss=sel&(g23>=lo)&(g23<hi); print(f" {lo}-{hi}: n={ss.sum()} err={err[ss].mean():.3f}")
print("by m2:")
bins=[0,0.3,0.6,1,1.5,2,5]
for lo,hi in zip(bins[:-1],bins[1:]):
    ss=sel&(m2>=lo)&(m2<hi); print(f" {lo}-{hi}: n={ss.sum()} err={err[ss].mean():.3f}")
# p1==9 and p2 position
print("by p2:", [round(err[sel&(p2==k)].mean(),3) for k in range(9)])
