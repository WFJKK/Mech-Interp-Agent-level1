
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0); H.append(h.copy())
    return np.stack(H,1), (h@R.T).argmax(1)
rng = np.random.default_rng(1)
X = rng.standard_normal((200000,10))
H, Y = run(X)
order = np.argsort(X,1)
p1, p2, p3, p4 = order[:,-1], order[:,-2], order[:,-3], order[:,-4]
s = np.sort(X,1)
m1,m2,m3,m4 = s[:,-1],s[:,-2],s[:,-3],s[:,-4]
err = Y!=p2
print("err rate", err.mean())
print("network outputs rank (0=max):", [( (Y==order[:,-k]) [err]).mean() for k in range(1,6)])
e3 = err & (Y==p3)
print("P(out=p3 | p3 after p2)", e3[p3>p2].mean(), "P(out=p3 | p3 before p2)", e3[p3<p2].mean())
e1 = err & (Y==p1)
print("P(out=p1 | p1 after p2)", e1[p1>p2].mean(), " before", e1[p1<p2].mean())
g23 = m2-m3
for lo,hi in [(0,0.02),(0.02,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1)]:
    sel=(g23>=lo)&(g23<hi)
    print(lo,hi, sel.mean().round(3), "p3 after p2:", e3[sel&(p3>p2)].mean().round(3), "p3 before p2:", e3[sel&(p3<p2)].mean().round(3))
g12 = m1-m2
for lo,hi in [(0,0.02),(0.02,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1)]:
    sel=(g12>=lo)&(g12<hi)
    print(lo,hi, sel.mean().round(3), "p1 after p2:", e1[sel&(p1>p2)].mean().round(3), "p1 before p2:", e1[sel&(p1<p2)].mean().round(3))
