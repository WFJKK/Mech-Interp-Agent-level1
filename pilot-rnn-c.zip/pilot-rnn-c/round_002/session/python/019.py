
import numpy as np
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
def run(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(10)
X = rng.standard_normal((3000000,10)); Y=run(X)
order = np.argsort(X,1); s = np.sort(X,1)
p1,p2,p3 = order[:,-1],order[:,-2],order[:,-3]
m1,m2,m3,m4 = s[:,-1],s[:,-2],s[:,-3],s[:,-4]
err = (Y!=p2); g12=m1-m2; g23=m2-m3; last=(p1==9).astype(float); before=(p3<p2).astype(float)
RULE=56/2937; SIM=2556/2937
def reward(a,b,c,d,e,f=0.0):
    reg=(g12>a)&(g23>b+c*m2+e*last+f*before)&(m2>d)
    cov=reg.mean(); fid=1-err[reg].mean()
    return cov*((1-RULE)-10*(1-fid)) + (1-cov)*(1-RULE-SIM), cov, fid
params=dict(a=0.01,b=0.015,c=0.035,d=0.04,e=0.06,f=0.0)
print("start", reward(**params))
grid=dict(a=np.arange(0,0.06,0.005), b=np.arange(0,0.1,0.005), c=np.arange(-0.02,0.08,0.005), d=np.arange(-0.3,0.4,0.02), e=np.arange(-0.05,0.3,0.01), f=np.arange(-0.1,0.1,0.01))
for it in range(3):
    for k in params:
        best=None
        for v in grid[k]:
            p=dict(params); p[k]=v; r=reward(**p)[0]
            if best is None or r>best[0]: best=(r,v)
        params[k]=best[1]
    print(it, {k:round(float(v),3) for k,v in params.items()}, reward(**params))
