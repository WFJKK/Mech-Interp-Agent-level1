
import numpy as np
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
rng = np.random.default_rng(0)
X = rng.standard_normal((20000,10))
def run(X, units=None):
    N = X.shape[0]
    h = np.zeros((N,16)); H=[]
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec.T, 0)
        if units is not None:
            mask = np.zeros(16); mask[units]=1; h = h*mask
        H.append(h.copy())
    return np.stack(H,1), (h@R.T).argmax(1)
H, Y = run(X)
print("mean act per unit", H[:,-1].mean(0))
print("frac active per unit (final)", (H[:,-1]>0).mean(0))
print("max act per unit", H.max((0,1)))
# ablation: zero out each unit, measure agreement
for u in range(16):
    units=[v for v in range(16) if v!=u]
    _,Y2 = run(X,units); print(u, (Y2==Y).mean())
