
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; R = weights["readout"]
U,S,Vt = np.linalg.svd(rec)
print("sv", S)
def run(X, rec_=rec):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w*X[:,t:t+1] + h@rec_.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(4)
X = rng.standard_normal((50000,10))
Y = run(X)
for r in range(4,16):
    recr = (U[:,:r]*S[:r])@Vt[:r]
    print(r, (run(X,recr)==Y).mean())
# also sparsify: zero small entries
for th in [0.05,0.1,0.2,0.3]:
    recs = np.where(abs(rec)<th,0,rec); print("th",th,(abs(rec)>=th).sum(), (run(X,recs)==Y).mean())
