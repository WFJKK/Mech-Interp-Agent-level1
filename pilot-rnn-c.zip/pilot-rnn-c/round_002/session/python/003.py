
rng = np.random.default_rng(1)
X = rng.standard_normal((200000,10))
H, Y = run(X)
order = np.argsort(X,1)  # ascending
p1, p2, p3, p4 = order[:,-1], order[:,-2], order[:,-3], order[:,-4]
s = np.sort(X,1)
m1,m2,m3,m4 = s[:,-1],s[:,-2],s[:,-3],s[:,-4]
err = Y!=p2
print("err rate", err.mean())
print("network outputs rank (0=max):", [( (Y==order[:,-k]) [err]).mean() for k in range(1,6)])
# conditional on outputting p3 vs p2: does arrival order matter?
e3 = err & (Y==p3)
print("P(out=p3 | p3 after p2)", e3[p3>p2].mean(), "P(out=p3 | p3 before p2)", e3[p3<p2].mean())
e1 = err & (Y==p1)
print("P(out=p1 | p1 after p2)", e1[p1>p2].mean(), " before", e1[p1<p2].mean())
# by gap bins and arrival
g23 = m2-m3
for lo,hi in [(0,0.02),(0.02,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1)]:
    sel=(g23>=lo)&(g23<hi)
    print(lo,hi, sel.mean().round(3), "p3 after p2:", e3[sel&(p3>p2)].mean().round(3), "p3 before p2:", e3[sel&(p3<p2)].mean().round(3))
