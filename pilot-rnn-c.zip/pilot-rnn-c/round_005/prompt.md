# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 5 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx real numbers, x_0 to x_(n_ctx - 1). The network reads them one at a time, in that order.
In an entry, g.token(t) is x_t, as a float, and g.tokens() is all of them; the output is still a whole number.

The network is a recurrent network with one layer of d_hidden units, a ReLU and no biases. Its weights:

    input       d_hidden x 1
    recurrent   d_hidden x d_hidden
    readout     n_outputs x d_hidden

Its state h, a vector of d_hidden numbers, starts at zero. At each position t, in order, it becomes

    h = relu(input x_t + recurrent h)

where relu sets every negative number to zero. After the last position, readout h gives n_outputs numbers,
and the output is the position of the highest (the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)  # the first position: the state before it is zero, and so is recurrent h
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()
```

Sizes: n_ctx = 10, d_hidden = 16, outputs: 10. One forward pass of the network costs 2,937 operations under the prices
below.

## The data set

An input is ten real numbers, x_0 to x_9, each drawn on its own from the standard normal distribution (mean 0, standard deviation 1). The data set is every input that can be drawn this way, each weighted by how likely it is to be drawn. There are infinitely many, so the verifier scores a sample.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.6972 | 0.8364 | 0.98789 | 0.0256 | 0.98700 | 0.98000 |
| r1s2 | scored | 0.7176 | 0.8385 | 0.99003 | 0.0264 | 0.98800 | 0.98000 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the second-largest of the ten inputs**. On random normal inputs it agrees with the exact second-argmax on 94.8% of inputs. Its errors are concentrated where the second- and third-largest values are close (gap < 0.1: error rate 5–25%), where the top two nearly tie (gap < 0.05: ~8%), and where the second-largest value is negative (≈77% error — the network handles mostly-negative inputs badly). Outside those zones the error rate is ~0.5–1%, and those residual errors look like unbiased noise: no per-position bias or scaling (coordinate search over position offsets/scales found no improvement), no useful recency effect, only a slightly higher error when the top value arrives last (position 9, ~3%) and when the three top values are all large. I'm very confident about the "second largest" reading; the error structure is characterized empirically on 16k samples.
    
    ## How you found it
    Looked at both. Weights showed a few dominant units (input weights ≈ ±8 and +27, a huge −30 recurrent column, readout row 9 with −37.6), but the dynamics are messy. Outputs were decisive: output distribution uniform over 0–9; the mean of x_c given output c ≈ +1; the rank of x_Y among the inputs is 8 (second largest) in 94.8% of cases. Then I binned error rates by the gaps top−second and second−third, by the second-largest value, by positions, and fit a logistic model on near-tie cases (no predictive power beyond the gap).
    
    ## The best entry
    `second_largest_v4` (reward 0.718 on submission; `second_largest_v1` with fixed thresholds scored 0.697). Region: with s = sort(tokens), m1,m2,m3 = s[9],s[8],s[7]: `(m1−m2 > 0.01) & (m2−m3 > 0.03 + 0.03·m2) & (m2 > 0.1)` (coverage ≈ 0.84, fidelity ≈ 0.99). Interpretation: `argmax(tokens == m2)`, i.e. the position of the second-largest value. Saving: one sort (40 ops) + a few comparisons ≈ 77 ops vs 2937 for the forward pass → cost ≈ 0.026. Also saved: v1 (thresholds 0.02/0.05/0.1), v2 (0.02 / 0.03+0.03·m2 / 0.1), v3 (0.02/0.07/0.1).
    
    ## Claims
    Claimed 0.988 on this network (measured 0.987–0.990 across three 16k samples). Expected 0.98 on the second network: same task, so "second largest" should hold, but the near-tie noise profile and the negative-value behaviour of another seed may differ, so the region thresholds are slightly tuned to this seed; I expect a somewhat higher error rate there.
    
    ## Next
    - The reward ceiling of this approach is ~0.72 (marginal rule: include slices whose local error rate is below ~9.7%). Gains would need a cheap predictor of the network's near-tie errors; nothing linear in sorted values/positions worked. One could try features from a partial simulation (e.g. the five big units 0,3,6,10,15 only, ~1/3 the cost) to see whether they predict the sec/third flip.
    - Try shaving cost: `argsort` once instead of sort + eq/argmax, or compute m1,m2,m3 without a full sort; worth at most ~0.01–0.02 reward.
    - If the second network's fidelity matters more, prefer the plainer v1 thresholds (less tuned to this seed).

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.7492 | 1.0000 | 0.99139 | 0.1494 | 0.99100 | 0.98500 |
| r2s2 | scored | 0.7695 | 1.0000 | 0.99231 | 0.1390 | 0.99100 | 0.98500 |
| r2s3 | scored | 0.7675 | 1.0000 | 0.99219 | 0.1397 | 0.99100 | 0.98500 |
| r2s4 | scored | 0.7658 | 1.0000 | 0.99225 | 0.1420 | 0.99100 | 0.98500 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the second-largest of the ten inputs** (agrees with the exact second-argmax on ~94.9% of standard-normal inputs; I'm very confident). Its disagreements are near-ties: second vs third largest close (gap < 0.1), top two within ~0.01, second-largest value below ~0.05, and a 3–5% error floor whenever the maximum arrives at the last position (p1 = 9), even at large gaps. In the "random" regime (second-largest negative, ~1% of inputs) its output is essentially arbitrary. The residual near-tie errors are *not* cheaply predictable: a 256-unit MLP on the raw inputs plus top-3 positions only lifts the choose-p2-vs-p3 accuracy from 94.0% to 94.6% in the near-tie zone, and a rank-15 approximation of the recurrent matrix already changes 0.25% of outputs (the dynamics are dense and sensitive: ablating any single unit breaks it, singular values 54, 3.4, 2.5, …). All 16 units matter; units 0,3,6 (input ≈ −8, driven by −30·h15), 10 (+8.4) and 15 (+27) are the sparse "switch" units; the other 11 are nearly always active and carry memory.
    
    ## How you found it
    Both weights and outputs. Weights: input/recurrent/readout structure, SVD of the recurrent matrix, per-unit ablations, activation statistics (fraction of zero entries per unit and per step). Outputs: 2–4M simulated inputs; error rates binned by gaps, values and positions; arrival-order tests (no recency effect except p1 = 9); logit-margin regression/classification with a numpy MLP (no exploitable structure); and exhaustive cell-based and coordinate-search tuning of the region thresholds against the exact reward formula. Verified exactness of the simulation tricks with sim-only entries (fidelity 1.0 on the fixed sample).
    
    ## The best entry
    `hybrid_v3` (reward 0.7695; also saved as `best_r2`; `hybrid_v4` is the same with one extra cond level, 0.767/0.766). Region: every input (coverage 1). Interpretation: `idx = argsort(tokens)`, p1,p2,p3 = idx[9],idx[8],idx[7], m = values there; `easy = (m1−m2 > 0.0125) & (m2−m3 > 0.02 + 0.035·m2 + 0.08·[p1==9]) & (m2 > 0.06)` (≈84% of inputs, 99.0% fidelity there); `cond(easy, p2, exact_sim)`. The exact simulation of the network for the hard 16% costs ~2140 ops instead of 2937 by (a) a build-time table that replaces the first two recurrent steps: h1 = relu(w·x0) is x0·relu(±w), so rec·h1 = x0·c±; the activation pattern of h2 depends only on the signs of x0, x1 and the sector of u = x0/x1 among the 16 slopes −w_i/c_i, so v3 = w·x2 + x1·A_k + x0·B_k is read from a 68×32 table (≈167 ops for steps 1–3); (b) units permuted to [0,3,6 | … | 10,15] and each later step chooses, by `cond` on whether h10, h15 and h0+h3+h6 are zero, a matmul with those columns sliced off (exact, ~30 ops saved per step); (c) `[rec | w] @ [h; x]` as one matmul. Easy inputs cost 56 ops (0.019), so the overall cost is ≈0.14; fidelity ≈0.992 (CI-lower ≈0.991). Nodes: 314 (v4: 388 of the 400 allowed).
    
    ## Claims
    Claimed 0.991 on this network (measured 0.9906–0.9923 over four 16k samples; 3M-sample estimate 0.9917). Expected 0.985 on the second network: the simulation branch is exact for any weights (it is computed from `g.weight`, and the column-dropping conds stay exact even if the sparse units differ, only costing more), so the only risk is the easy-branch "second largest" rule with thresholds tuned to this seed's near-tie error profile; the 0.0125/0.02/0.06 thresholds are tight, so another seed could lose ~0.5–1% there.
    
    ## Next
    - Ceiling of this design is ≈0.78: remaining losses are rule errors (≈0.08), CI margin (≈0.015), simulation cost on hard inputs (≈0.12), rule cost (0.02). Further exact savings in the simulation are small (adding a unit-2 prefix / unit-11 suffix level ≈ 2–6 ops/step) and limited by the 400-node cap (slices, reshapes and concats all count as nodes).
    - A bigger step would need an exact cheaper step-4 (table over the 3D arrangement of (x0,x1,x2)); it requires a pattern→row lookup, which the language lacks without a 65536-entry scatter — I found no cheap way.
    - Don't spend effort on learned error predictors for the near-tie zone: the MLP test shows there's nothing cheap to learn; a logistic/threshold rule on (m1−m2, m2−m3, m2, p1==9) is already at the optimum (coordinate search converges to the values above).
    - If robustness on the second network matters, `hybrid_v2_r1thr` (same hybrid with the plainer round-1 thresholds 0.01/0.03+0.03·m2/0.1) loses only ~0.004 here.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.8043 | 1.0000 | 0.99591 | 0.1438 | 0.99550 | 0.97500 |
| r3s2 | scored | 0.8026 | 1.0000 | 0.99518 | 0.1373 | 0.99550 | 0.97500 |
| r3s3 | scored | 0.8038 | 1.0000 | 0.99554 | 0.1402 | 0.99520 | 0.97500 |
| r3s4 | scored | 0.8035 | 1.0000 | 0.99615 | 0.1473 | 0.99530 | 0.97500 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the second-largest of the ten inputs** (agrees with exact second-argmax on ~95% of standard-normal inputs; certain). Its disagreements are near-ties (second vs third, top two, second-largest ≲ 0.06) — but, new this round, the near-tie error rate is **strongly position-pair dependent**: the error as a function of the gap m2−m3 varies by an order of magnitude across (p2, p3) cells, and when the maximum arrives last (p1 = 9) specific pairs are confused even at large gaps (e.g. p2=7/p3=0: 27%, 1/4: 27%, 4/1: 22%, 7/4: 17%, 6/3, 5/8, 0/7: ~11%; pairs differing by 3 mod 10 recur), while other pairs are essentially never confused (threshold ≈ 0). In the easy region the remaining errors go to p3 (57%), p1 (21%), p4 (15%). The near-tie choice itself is not cheaply predictable: linear/logistic models on gaps, neighbours, raw values give nothing beyond the cell thresholds; a 32-unit MLP on raw inputs + one-hot cells reaches 83% (vs 77% base) in the tie zone, but any such model is unaffordable (constants limit 256, ops). The dynamics are chaotic-sensitive: zeroing any single recurrent weight of magnitude ~0.05 changes ~50% of hard-region outputs, so no approximate simulation is possible; only the exact sim works.
    
    ## How you found it
    Both. Outputs: 2–12M simulated inputs; error rates by (p1, p2, p3) cells × gap bins, by m2, by m3−m4; per-cell error-vs-gap curves (gradual, so "predict p3" never wins); logistic/MLP probes in the tie zone. Weights: single-entry sensitivity of the recurrent matrix (ruled out sparsification), activation-pattern statistics of the five sparse units per step (patterns {10,15 zero} ~55%, {0,3,6 zero} ~13%, all five zero ~10%). Then fitted, by exact reward-maximising coordinate descent on 12M samples (holdout 2M), per-cell thresholds: th23[p1,p2,p3] (1000 cells, 32-level grid) on m2−m3−0.035·m2 and th12[p1,p2] (100 cells, 16-level grid) on m1−m2, with floor 0 (v1/v2) or unconstrained (v3), packed 10 codes per int64 constant and decoded with `//`, `%` and gathers.
    
    ## The best entry
    `hybrid_cells_v1` (= `best`, `best_r3`; reward 0.8043 and 0.8035 on two submissions; v2 0.8026, v3 0.8038 — all equivalent within noise). Region: all inputs. Interpretation: idx = argsort(tokens), p1,p2,p3 = idx[9],idx[8],idx[7], m = values there; `easy = (m2 > 0.06) & (m2−m3−0.035·m2 > G23[(T23[p2·10+p1] // P5[p3]) % 32]) & (m1−m2 > G12[(T12[p2] // P4[p1]) % 16])` (~84% of inputs, 0.45% error there); `cond(easy, p2, exact_sim)` where exact_sim is round 2's exact simulation (steps 1–3 by a build-time 68×32 table, later steps with cond-sliced matmuls, ~2130–2190 ops) spliced in unchanged at JSON level (append new rule nodes, rewire the final cond, DFS re-topologise). Rule costs ~64 ops; overall cost ≈ 0.14, fidelity ≈ 0.9955–0.9962 (CI-low ≈ 0.995). 327 nodes, 205 constants. v3 adds per-(p1==9,p2) m2 thresholds and unconstrained floors (336 nodes, 223 constants); `rule_only_v*` are stashes holding the tables (nodes 11/12/20/21 = G23/T23/G12/T12).
    
    ## Claims
    Claimed 0.9955/0.9953 here (measured 0.9952–0.9962 over four 16k samples; 12M-sample estimate 0.9953). Expected 0.975 on the second network: the sim branch is exact for any weights, but the cell tables encode this seed's position-confusion structure; another seed will confuse other pairs, so near-ties admitted here (thresholds as low as 0.025·m2) may err 10–30% there, costing maybe 1–2% fidelity.
    
    ## Next
    - Ceiling of this design is ~0.81–0.82: losses are sim cost on the 15–16% hard inputs (≈0.12), rule errors (≈0.04), CI margin (0.011), rule cost (0.022). Slope (0.025–0.035), m2 cells, unconstrained floors all move reward by ≤0.003.
    - Only real lever left is the exact sim: per-step floor ≈ 255 ops with cond-slicing; a step-4 table via perfect-hashed (sector, pattern) combos would save only ~90 ops/hard input (~0.005) and needs a hash table build — not worth it. Restricting the readout to candidate rows loses too much fidelity (3% of hard outputs are outside {p1,p2,p3,p4}).
    - Don't retry learned tie-predictors: nonlinear ones work a bit (MLP 83%) but can't fit the 256-constant limit; linear ones add nothing.
    - If more constants were allowed, per-cell thresholds over (p1,p2,p3,p4) or per-cell slopes might add ~0.005.

### Round 4

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r4s1 | scored | 0.8215 | 1.0000 | 0.99683 | 0.1370 | 0.99570 | 0.98000 |
| r4s2 | scored | 0.8148 | 1.0000 | 0.99597 | 0.1339 | 0.99570 | 0.97500 |
| r4s3 | scored | 0.8036 | 1.0000 | 0.99475 | 0.1316 | 0.99570 | 0.97500 |
| r4s4 | scored | 0.8169 | 1.0000 | 0.99603 | 0.1326 | 0.99550 | 0.97500 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the second-largest of the ten inputs** (agrees with the exact second-argmax on ~95% of standard-normal inputs; certain). Its disagreements are near-ties — second vs third largest close, top two close, second-largest value ≲ 0.06 — with error rates that depend strongly on the (p1, p2, p3) position cell, and this round I found they also depend on whether the top two are close (m1−m2 < 0.3) in a *cell-specific, non-systematic* way (a global additive/linear term in m1−m2 or m3−m4 hurts; a per-cell split helps). In the hard region the network outputs p2 71%, p3 20%, p1 4%, others 5%; no cell has P(p1) or P(p3) above ~70%, so "predict p1/p3" rules never win. Intermediate readouts never agree with the final output (~2%), so the suffix of the sequence cannot be skipped; the representation is time-dependent. Mechanically: unit 15 ≈ relu(27·x_t − 0.99·h15 − …) fires on new-max-like inputs, units 0/3/6 (input ≈ −8, −30·h15) fire only when x_t < 0 and h15 = 0, unit 10 ≈ relu(8.4·x_t …); readout row 9 = 4.16·h10 − 37.6·h15. Units 10 and 15 are zero 65–90% of late steps, 0/3/6 about 25–50%, unit 2 about 20–45%; the other units are nearly always active. Also verified: unit 10 zero ⇒ unit 15 zero on this seed (0 violations in 2M inputs), but this is seed-specific.
    
    ## How you found it
    Both. Outputs: 8–24M simulated inputs; error rates by (p1,p2,p3) cell × gap bins and by m2 bins; holdout-validated tuning of per-cell thresholds with candidate binary features (random feature as an overfitting control), composite features, slopes, m2 floor; agreement of intermediate readouts; distribution of outputs in the hard region. Weights/graph: read the saved best entry's JSON node by node to get the exact per-branch op counts (easy 65, hard mean 2206, min 1997, max 2397 ops), activation-pattern statistics of the five sparse units per step, and exactness tests of the simulation branch on a unit-permuted copy of the network and on random weights (via `lv1.Evaluator` with substituted weights) — which revealed that the round-3 `best` sim branch is only 41% exact on a permuted copy (its single-unit zero test `h[14]==0` relies on a seed-specific implication).
    
    ## The best entry
    `feat_v3` (= `best`, `best_r4`; reward 0.8169 and 0.8036 on two submissions, true expectation ≈ 0.816). `feat_v1` scored highest (0.8215, a favourable sample; identical answers, 16 ops more per hard input) and `feat_v2` 0.8148. Region: all inputs. Interpretation: idx = argsort(tokens), p1,p2,p3 = idx[9],idx[8],idx[7], m = values; c = p1·100 + p2·10 + p3 + 1000·[m1−m2 < 0.3]; `easy = (m2 > 0.06) & (m2−m3−0.025·m2 > G23[(T23[c//15] // 16^(c%15)) % 16]) & (m1−m2 > G12[(T12[p2] // 16^p1) % 16])` (2000 cells with 4-bit threshold codes packed 15 per int64: 134 ints; 16-level grids; 221 constants, 345 nodes); `cond(easy, p2, exact_sim)`. The exact sim is round 2/3's (build-time 68×32 table for steps 1–3, now applied as one (16,2) matmul; cond-sliced matmuls for steps 4–10; cond-sliced readout) with the first-level test changed to `sum(h[14:16]) == 0`, which makes it exact for any weights (verified on permuted and random weights). Costs: easy branch 72 ops (85.4% of inputs), hard branch ≈ 2205 ops; overall cost ≈ 0.131–0.134, fidelity 0.9959 (10M-sample estimate 0.99588; errors per 16k sample: mean 67.6, sd 8.1). Tables tuned by joint coordinate descent on 24M samples with the exact reward trade-off (easy 73 vs hard 2210 ops).
    
    ## Claims
    Claimed 0.9955–0.9957 on this network (true ≈ 0.9959; measured 0.9947–0.9968 over four 16k samples). Expected 0.975 on the second network: the sim branch is now exact for any weights, so only the easy-rule errors change; the easy region contains ~1.2% of inputs with m2−m3 < 0.03, ~3.9% in [0.03, 0.06), ~1.2% with m1−m2 < 0.02 — cells where this seed is reliable but another seed may err 10–30% — giving an estimated ~2% extra error.
    
    ## Next
    - The design is at its ceiling (~0.816 expected; losses: hard-sim cost ≈ 0.11, rule cost 0.021, rule errors 0.046, CI margin 0.011). Remaining deterministic gains are ≤ 0.002 each: a unit-2 column-cond level in steps 4–7 (~+0.0015, ~40 nodes), a 0/3/6 cond on the readout (~+0.0003), per-(p1==9,p2) m2 floors (~+0.001 with the 35 spare constants).
    - Dead ends confirmed this round: linear terms in m1−m2 / m3−m4 (hurt), composite binary features (worse than m1−m2 < 0.3), "predict p1/p3" cells, intermediate readouts, row-skipping by cheap bounds (test costs exceed savings), step-4 tables (no net saving even with hashed lookup), m2 floor ≠ 0.06, slope ≠ 0.025.
    - Submission noise is ±0.006 (1 sd); with identical entries the max over submissions is what gets locked, so resubmitting the best entry is a legitimate use of spare submissions. Claim ≈ 0.9955 to avoid overclaims (P(errors > 74 in 16k) ≈ 20%).
    - Always keep the `sum(h[14:16]) == 0` test (or test both units): the round-3 entries (`r3s*`, old `best`) are not exact on other seeds.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.8215) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
