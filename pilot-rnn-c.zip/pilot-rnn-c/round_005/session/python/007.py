
import numpy as np, json
W = weights
w = W['input'][:,0]; R = W['recurrent']; O = W['readout']
e = entries['r4s3']; nodes = e['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value'], dtype=np.int64)
P16 = np.array(nodes[31]['value'], dtype=np.int64)
G12 = np.array(nodes[40]['value']); T12 = np.array(nodes[41]['value'], dtype=np.int64)
def sim(X, keep_states=False):
    n = X.shape[0]; h = np.zeros((n,16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h @ R.T, 0); H.append(h.copy())
    out = (h @ O.T).argmax(1)
    return (out, H) if keep_states else out
def rule(X):
    idx = np.argsort(X, axis=1); p1,p2,p3 = idx[:,9], idx[:,8], idx[:,7]; n = np.arange(len(X))
    m1,m2,m3 = X[n,p1], X[n,p2], X[n,p3]
    c = p1*100+p2*10+p3 + 1000*((m1-m2)<0.3)
    th23 = G23[(T23[c//15] // P16[c%15]) % 16]; th12 = G12[(T12[p2] // P16[p1]) % 16]
    return (m2>0.06) & ((m2-m3-0.025*m2) > th23) & ((m1-m2) > th12), p2
no = network_outputs(); Xs, ys = np.array(no[0]), np.array(no[1])
print(Xs.shape, (sim(Xs)==ys).mean())
easy_s, p2_s = rule(Xs); print('sample easy frac', easy_s.mean(), 'errors', (easy_s & (p2_s!=ys)).sum())
rng = np.random.default_rng(0); X = rng.standard_normal((1_000_000,10))
easy, p2 = rule(X); Xh = X[~easy][:200000]
yh, H = sim(Xh, keep_states=True)
for t in range(2,10):
    z = (H[t]==0)
    print(t, 'u2', round(z[:,2].mean(),3), 'u036', round((z[:,[0,3,6]].all(1)).mean(),3), 'u10_15', round((z[:,[10,15]].all(1)).mean(),3),
          'u2&036', round((z[:,[0,2,3,6]].all(1)).mean(),3), 'others', [round(z[:,i].mean(),2) for i in [1,4,5,7,8,9,11,12,13,14]])
