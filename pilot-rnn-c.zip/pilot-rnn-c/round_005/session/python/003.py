
import json
e = entries['best']
nodes = e['nodes']
for i,n in enumerate(nodes[60:], start=60):
    s = json.dumps(n)
    print(i, s[:130])
print('predict', e['predict'], 'rule', e['rule'])
