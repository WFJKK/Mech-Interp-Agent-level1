
import numpy as np, copy
e = entries['r4s3']; nodes = e['nodes']
am = [i for i,n in enumerate(nodes) if n['op']=='argmax']; print(am, e['predict'], nodes[e['predict']])
e_sim = copy.deepcopy(e); e_sim['predict'] = am[0]
def simw(X, w, R, O):
    h = np.zeros((X.shape[0],16))
    for t in range(10): h = np.maximum(w[None,:]*X[:,t:t+1] + h @ R.T, 0)
    return (h @ O.T).argmax(1)
rng = np.random.default_rng(1); X = rng.standard_normal((1500,10))
tests = {}
perm = rng.permutation(16)
tests['perm'] = {'input': weights['input'][perm], 'recurrent': weights['recurrent'][perm][:,perm], 'readout': weights['readout'][:,perm]}
tests['rand'] = {'input': rng.standard_normal((16,1))*5, 'recurrent': rng.standard_normal((16,16))*0.5, 'readout': rng.standard_normal((10,16))}
tests['rand2'] = {'input': rng.standard_normal((16,1))*2, 'recurrent': rng.standard_normal((16,16))*0.3 + np.eye(16)*0.5, 'readout': rng.standard_normal((10,16))}
tests['self'] = weights
for name, Wt in tests.items():
    ev = lv1.Evaluator(e_sim, Wt, 10)
    ref = simw(X, Wt['input'][:,0], Wt['recurrent'], Wt['readout'])
    preds = []; costs=[]
    for x in X:
        ins, ans, cr, cp = ev.run(x); preds.append(ans); costs.append(cp)
    preds = np.array(preds)
    print(name, 'agree', (preds==ref).mean(), 'mean ops', np.mean(costs), 'build', ev.build_cost)
