
import json
e = entries['best']
print(e.keys())
nodes = e['nodes']
for i,n in enumerate(nodes[:60]):
    print(i, json.dumps(n)[:150])
