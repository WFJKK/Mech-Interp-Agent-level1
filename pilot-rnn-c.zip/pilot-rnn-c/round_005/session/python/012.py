
import numpy as np, copy
e = entries['r4s3']
g, pred, rule_ = lv1.Graph.load(e, weights, 10, example=list(np.random.default_rng(0).standard_normal(10)))
print(type(pred), pred.value, getattr(pred,'shape',None), pred.value.dtype)
# find the expression for node 342: use Graph internals?
print([a for a in dir(g) if not a.startswith('_')][:40])
