
import numpy as np, inspect
print([n for n in dir(lv1) if not n.startswith('_')])
print(inspect.signature(lv1.Evaluator.__init__) if hasattr(lv1,'Evaluator') else 'no Evaluator')
print(inspect.signature(lv1.Graph.load))
