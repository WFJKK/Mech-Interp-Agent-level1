
for name in ['r4s1','r4s2','r4s3','r4s4']:
    e = entries[name]
    m = measure(e)
    print(name, len(e['nodes']), {k: round(v,5) if isinstance(v,float) else v for k,v in m.items()})
