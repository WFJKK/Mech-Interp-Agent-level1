
print(sorted(entries.keys()))
print(info)
import json
e = entries['best']
print(len(e['nodes']) if 'nodes' in e else e.keys())
print(measure(e))
