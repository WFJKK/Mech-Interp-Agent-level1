
import numpy as np, copy
e = entries['r4s3']
ev = lv1.Evaluator(e, weights, 10)
x = np.random.default_rng(0).standard_normal(10)
memo = {}; c=[0]
v = ev._eval(342, memo, c, x.reshape(-1))
print(v, v.dtype, v.shape, c)
v2 = ev._eval(341, memo, c, x.reshape(-1)); print(v2.shape, v2.dtype)
