
import numpy as np, inspect
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
src = inspect.getsource(lv1.Evaluator)
print(src[:3000])
