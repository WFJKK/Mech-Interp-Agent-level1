
no = network_outputs()
Xs, ys = np.array(no[0]), np.array(no[1])
print(Xs.shape, ys.shape, (sim(Xs)==ys).mean())
# sanity: rule error on the fixed sample
easy_s, p2_s = rule(Xs)
print('sample easy frac', easy_s.mean(), 'errors', (easy_s & (p2_s!=ys)).sum())
# Hard-region activation stats: per step t (0-based 3..9), fraction zero of units 2, {0,3,6}, {10,15}, 11
Xh = X[~easy][:300000]
yh, H = sim(Xh, keep_states=True)
for t in range(2,10):
    h = H[t]
    z = (h==0)
    print(t, 'u2', round(z[:,2].mean(),3), 'u036', round((z[:,[0,3,6]].all(1)).mean(),3), 'u10_15', round((z[:,[10,15]].all(1)).mean(),3),
          'u2&036', round((z[:,[0,2,3,6]].all(1)).mean(),3), 'others', [round(z[:,i].mean(),2) for i in [1,4,5,7,8,9,11,12,13,14]])
