
import numpy as np
W = weights; w = W['input'][:,0]; R = W['recurrent']; O = W['readout']
e = entries['r4s3']; nodes = e['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value'], dtype=np.int64)
P16 = np.array(nodes[31]['value'], dtype=np.int64)
G12 = np.array(nodes[40]['value']); T12 = np.array(nodes[41]['value'], dtype=np.int64)
def sim(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10): h = np.maximum(w[None,:]*X[:,t:t+1] + h @ R.T, 0)
    return (h @ O.T).argmax(1)
def rule(X, pm=np.arange(10)):
    idx = np.argsort(X, axis=1); p1,p2,p3 = idx[:,9], idx[:,8], idx[:,7]; n = np.arange(len(X))
    m1,m2,m3 = X[n,p1], X[n,p2], X[n,p3]
    q1,q2,q3 = pm[p1],pm[p2],pm[p3]
    c = q1*100+q2*10+q3 + 1000*((m1-m2)<0.3)
    th23 = G23[(T23[c//15] // P16[c%15]) % 16]; th12 = G12[(T12[q2] // P16[q1]) % 16]
    return (m2>0.06) & ((m2-m3-0.025*m2) > th23) & ((m1-m2) > th12), p2
rng = np.random.default_rng(5); X = rng.standard_normal((2_000_000,10)); y = sim(X)
easy, p2 = rule(X)
print('tuned: easy', easy.mean(), 'err in easy', (p2[easy]!=y[easy]).mean(), 'fid', 1-(easy&(p2!=y)).mean())
for s in range(5):
    pm = np.random.default_rng(100+s).permutation(10)
    easy, p2 = rule(X, pm)
    print('perm', s, 'easy', round(easy.mean(),4), 'err in easy', round((p2[easy]!=y[easy]).mean(),5), 'fid', round(1-(easy&(p2!=y)).mean(),5))
# also: the plain global thresholds as a reference (what a seed-agnostic rule would do)
idx = np.argsort(X, axis=1); n=np.arange(len(X)); m1,m2,m3 = X[n,idx[:,9]],X[n,idx[:,8]],X[n,idx[:,7]]
for a,b,cc in [(0.0125,0.02,0.035),(0.02,0.05,0.0),(0.03,0.08,0.0)]:
    ez = (m1-m2>a)&(m2-m3>b+cc*m2)&(m2>0.06)
    print('global',a,b,cc,'easy',round(ez.mean(),4),'err',round((idx[ez,8]!=y[ez]).mean(),5),'fid',round(1-(ez&(idx[:,8]!=y)).mean(),5))
