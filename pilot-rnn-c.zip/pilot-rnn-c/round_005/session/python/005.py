
import numpy as np, json
W = weights
w = W['input'][:,0]; R = W['recurrent']; O = W['readout']
e = entries['r4s3']; nodes = e['nodes']
G23 = np.array(nodes[12]['value']); T23 = np.array(nodes[13]['value'], dtype=np.int64)
P16 = np.array(nodes[31]['value'], dtype=np.int64)
G12 = np.array(nodes[40]['value']); T12 = np.array(nodes[41]['value'], dtype=np.int64)
print(len(T23), len(T12))

def sim(X, keep_states=False):
    n = X.shape[0]
    h = np.zeros((n,16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h @ R.T, 0)
        H.append(h.copy())
    out = (h @ O.T).argmax(1)
    return (out, H) if keep_states else out

def rule(X):
    idx = np.argsort(X, axis=1)
    p1,p2,p3 = idx[:,9], idx[:,8], idx[:,7]
    n = np.arange(len(X))
    m1,m2,m3 = X[n,p1], X[n,p2], X[n,p3]
    c = p1*100+p2*10+p3 + 1000*((m1-m2)<0.3)
    th23 = G23[(T23[c//15] // P16[c%15]) % 16]
    th12 = G12[(T12[p2] // P16[p1]) % 16]
    easy = (m2>0.06) & ((m2-m3-0.025*m2) > th23) & ((m1-m2) > th12)
    return easy, p2

rng = np.random.default_rng(0)
X = rng.standard_normal((2_000_000,10))
y = sim(X)
easy, p2 = rule(X)
print('easy frac', easy.mean(), 'easy err', (p2[easy]!=y[easy]).mean(), 'overall err', ((easy&(p2!=y))).mean())
# check vs network_outputs sample
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
