
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]; top=asrt[:,-1]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
ok = Y==sec
def score(m, cost=0.03):
    cov=m.mean(); n=m.sum(); err=(~ok[m]).sum(); fid=1-err/n
    lb = fid - 1.96*np.sqrt(fid*(1-fid)/n+1e-12) - 1.5/n
    return cov*((1-cost) - 10*(1-lb)), cov, err, fid
res=[]
for a in [0.01,0.02,0.03]:
  for b0 in [0.0,0.01,0.02,0.03,0.04,0.05]:
    for b1 in [0,0.01,0.02,0.03,0.04,0.05]:
        for c in [0,0.1,0.2]:
            m=(g12>a)&(g23>b0+b1*srt[:,-2])&(srt[:,-2]>c)
            res.append((*score(m),a,b0,b1,c))
res.sort(reverse=True)
for r in res[:12]: print(np.round(r,4))
