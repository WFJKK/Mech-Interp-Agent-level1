
out = network_outputs()
print(type(out), out.keys() if isinstance(out, dict) else len(out))
