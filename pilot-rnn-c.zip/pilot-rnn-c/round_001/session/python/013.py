
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]; top=asrt[:,-1]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
ok = Y==sec
base=(g23>0.1)&(g12>0.05)&(srt[:,-2]>0)
m=base&(top==9)&~ok
print("Y==third", np.mean(Y[m]==third[m]), "Y==top", np.mean(Y[m]==top[m]))
for i in np.where(m)[0][:12]:
    print(np.round(X[i],2), "Y",Y[i],"sec",sec[i],"third",third[i])
# what about dependence on x9 value when top==9
mm=base&(top==9)
for lo,hi in [(0,1),(1,1.5),(1.5,2),(2,2.5),(2.5,5)]:
    q=mm&(X[:,9]>=lo)&(X[:,9]<hi); print("x9",lo,hi,q.sum(),(~ok[q]).mean())
# top==8 errors
m=base&(top==8)&~ok
for i in np.where(m)[0][:8]:
    print(np.round(X[i],2), "Y",Y[i],"sec",sec[i],"third",third[i])
