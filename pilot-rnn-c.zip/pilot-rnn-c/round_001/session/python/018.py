
def build(a=0.02, b=0.05, c=0.1):
    g = graph()
    t = g.tokens()
    s = lv1.sort(t, 0)
    m1, m2, m3 = s[9], s[8], s[7]
    region = ((m1 - m2) > a) & ((m2 - m3) > b) & (m2 > c)
    a2 = (t == m2).argmax()
    return g.entry(interpretation=a2, region=region)
e = build()
print(measure(e))
save_entry("second_largest_v1", e)
# check cost breakdown and sanity vs numpy
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
