
def build(a=0.02, b=0.05, c=0.1, b1=0.0):
    g = graph()
    t = g.tokens()
    s = lv1.sort(t, 0)
    m1, m2, m3 = s[9], s[8], s[7]
    if b1:
        region = ((m1 - m2) > a) & ((m2 - m3) > (b + b1*m2)) & (m2 > c)
    else:
        region = ((m1 - m2) > a) & ((m2 - m3) > b) & (m2 > c)
    a2 = (t == m2).argmax()
    return g.entry(interpretation=a2, region=region)
for kw in [dict(), dict(b=0.03,b1=0.03), dict(b=0.07), dict(b=0.1), dict(a=0.01,b=0.03,b1=0.03)]:
    r=measure(build(**kw)); print(kw, round(r['coverage'],3), round(r['fidelity'],4), round(r['reward'],4))
save_entry("second_largest_v2", build(b=0.03,b1=0.03))
save_entry("second_largest_v3", build(b=0.07))
