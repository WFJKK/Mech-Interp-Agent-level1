
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
top=asrt[:,-1]; sec = asrt[:,-2]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
ok = Y==sec
m = (g12>0.2)&(g23>0.3)
print("n", m.sum(), "err", (~ok[m]).sum())
w = m & ~ok
print("sec<top position:", np.mean(sec[w]<top[w]), "overall", np.mean(sec[m]<top[m]))
print("third<sec pos:", np.mean(third[w]<sec[w]), "overall", np.mean(third[m]<sec[m]))
print("Y==third", np.mean(Y[w]==third[w]), "Y==top", np.mean(Y[w]==top[w]))
print("top value wrong", np.percentile(srt[w,-1],[10,50,90]), "all", np.percentile(srt[m,-1],[10,50,90]))
print("sec value wrong", np.percentile(srt[w,-2],[10,50,90]), "all", np.percentile(srt[m,-2],[10,50,90]))
print("third value wrong", np.percentile(srt[w,-3],[10,50,90]), "all", np.percentile(srt[m,-3],[10,50,90]))
print("min value wrong", np.percentile(srt[w,0],[10,50,90]), "all", np.percentile(srt[m,0],[10,50,90]))
for i in np.where(w)[0][:15]:
    print(np.round(X[i],2), "Y",Y[i],"top",top[i],"sec",sec[i],"third",third[i])
