
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
def agree(d, scale=None):
    V = X + d
    if scale is not None: V = X*scale + d
    return np.mean(np.argsort(V,1)[:,-2]==Y)
d=np.zeros(10); best=agree(d); print(best)
for rnd in range(3):
    for t in range(10):
        for step in [0.1,-0.1,0.05,-0.05,0.02,-0.02]:
            d2=d.copy(); d2[t]+=step; a=agree(d2)
            if a>best: best=a; d=d2
    print(rnd, best, np.round(d,2))
# scale per position
s=np.ones(10)
for rnd in range(2):
    for t in range(10):
        for step in [0.1,-0.1,0.05,-0.05,0.02,-0.02]:
            s2=s.copy(); s2[t]+=step; a=agree(d,s2)
            if a>best: best=a; s=s2
    print(rnd, best, np.round(s,2))
