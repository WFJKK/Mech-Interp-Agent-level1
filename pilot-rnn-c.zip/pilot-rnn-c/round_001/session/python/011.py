
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def states(x):
    h=np.zeros(16); H=[]
    for t in range(10):
        h=np.maximum(x[t]*w + R@h,0); H.append(h.copy())
    return np.array(H)
np.set_printoptions(precision=2, suppress=True, linewidth=220)
for i in range(3):
    print("x", np.round(X[i],2), "Y", Y[i], "sec", np.argsort(X[i])[-2])
    H=states(X[i]); print(H)
    print("logits", O@H[-1])
