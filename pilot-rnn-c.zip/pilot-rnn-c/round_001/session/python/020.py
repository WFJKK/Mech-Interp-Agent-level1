
def build(a=0.02, b=0.05, c=0.1, b1=0.0):
    g = graph()
    t = g.tokens()
    s = lv1.sort(t, 0)
    m1, m2, m3 = s[9], s[8], s[7]
    region = ((m1 - m2) > a) & ((m2 - m3) > (b + b1*m2)) & (m2 > c)
    a2 = (t == m2).argmax()
    return g.entry(interpretation=a2, region=region)
e=build(a=0.01,b=0.03,b1=0.03)
print(measure(e)['reward'])
save_entry("second_largest_v4", e)
