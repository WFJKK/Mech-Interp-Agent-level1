
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]; top=asrt[:,-1]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
ok = Y==sec
# error rate by bins of g23 (with sec>0, g12>0.05)
base=(srt[:,-2]>0)&(g12>0.05)
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.15),(0.15,0.2),(0.2,0.3),(0.3,0.5),(0.5,1),(1,5)]:
    m=base&(g23>=lo)&(g23<hi); print("g23",lo,hi,m.sum(), (~ok[m]).mean())
base=(srt[:,-2]>0)&(g23>0.1)
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.15),(0.15,0.2),(0.2,0.3),(0.3,0.5),(0.5,1),(1,5)]:
    m=base&(g12>=lo)&(g12<hi); print("g12",lo,hi,m.sum(), (~ok[m]).mean())
base=(g23>0.1)&(g12>0.05)
for lo,hi in [(-3,-0.5),(-0.5,0),(0,0.3),(0.3,0.6),(0.6,1),(1,1.5),(1.5,2),(2,5)]:
    m=base&(srt[:,-2]>=lo)&(srt[:,-2]<hi); print("sec",lo,hi,m.sum(), (~ok[m]).mean())
# position effects
base=(g23>0.1)&(g12>0.05)&(srt[:,-2]>0)
for p in range(10):
    m=base&(sec==p); print("secpos",p,m.sum(), (~ok[m]).mean())
for p in range(10):
    m=base&(top==p); print("toppos",p,m.sum(), (~ok[m]).mean())
