
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]; top=asrt[:,-1]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
m=(srt[:,-2]>0)&(g23<0.2)&(g12>0.02)&((Y==sec)|(Y==third))
idx=np.where(m)[0]
# features
F=[]
for i in idx:
    f=[1, g23[i], srt[i,-1], srt[i,-2], srt[i,-4], X[i].sum(), (X[i]>0).sum(), sec[i], third[i], sec[i]>third[i], top[i], top[i]==9, srt[i,0]]
    oh=np.zeros(20); oh[sec[i]]=1; oh[10+third[i]]=1
    F.append(np.concatenate([f,oh]))
F=np.array(F,float); t=(Y[idx]==third[idx]).astype(float)
# standardize
mu=F.mean(0); sd=F.std(0)+1e-9; sd[0]=1; mu[0]=0
Fs=(F-mu)/sd
wts=np.zeros(F.shape[1])
for it in range(3000):
    p=1/(1+np.exp(-Fs@wts)); grad=Fs.T@(p-t)/len(t)+1e-3*wts; wts-=0.5*grad
p=1/(1+np.exp(-Fs@wts))
print("n",len(t),"base rate",t.mean())
print("logloss", -np.mean(t*np.log(p+1e-9)+(1-t)*np.log(1-p+1e-9)), "base", -np.mean(t*np.log(t.mean())+(1-t)*np.log(1-t.mean())))
print("acc", np.mean((p>0.5)==t), "base", 1-t.mean())
print(np.round(wts,2))
