
import numpy as np
print(info)
for k,v in weights.items(): print(k, v.shape)
np.set_printoptions(precision=3, suppress=True, linewidth=200)
print(weights['input'][:,0])
print(weights['recurrent'])
print(weights['readout'])
