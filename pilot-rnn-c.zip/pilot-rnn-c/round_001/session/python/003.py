
X, Y, ops = out
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
print(np.bincount(Y, minlength=10))
# hypotheses: argmax, argmin, count positives, etc.
print("argmax", np.mean(Y==X.argmax(1)))
print("argmin", np.mean(Y==X.argmin(1)))
print("count>0", np.mean(Y==(X>0).sum(1)))
print("count<0", np.mean(Y==(X<0).sum(1)))
for k in range(10):
    print(k, np.mean(Y==(np.abs(X)>k/4).sum(1)))
