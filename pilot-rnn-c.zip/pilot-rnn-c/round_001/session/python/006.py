
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
am = X.argmax(1)
for k in range(10): print(k, np.mean(Y==(am+k)%10))
# rank of x_Y among the tokens
ranks = (X < X[np.arange(len(X)),Y][:,None]).sum(1)
print(np.bincount(ranks, minlength=10)/len(X))
print("x_Y > 0:", np.mean(X[np.arange(len(X)),Y]>0))
# last positive position?
pos = X>0
lastpos = np.where(pos.any(1), 9-np.argmax(pos[:,::-1],1), -1)
print("lastpos", np.mean(Y==lastpos))
firstpos = np.argmax(pos,1)
print("firstpos", np.mean(Y==firstpos))
