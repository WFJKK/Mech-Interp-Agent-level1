
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
ok = Y==sec
best=None
for a in [0,0.05,0.1,0.15,0.2,0.3]:
    for b in [0.1,0.2,0.3,0.4,0.5,0.6,0.8]:
        m = (g12>a)&(g23>b)
        cov=m.mean(); n=m.sum(); err=(~ok[m]).sum()
        fid = 1-err/n
        # approx lower bound
        lb = fid - 1.96*np.sqrt(fid*(1-fid)/n+1e-12) - 3/n
        rew = cov*((1-0.03) - 10*(1-lb))
        print(f"a={a} b={b} cov={cov:.3f} err={err} fid={fid:.4f} rew~{rew:.3f}")
