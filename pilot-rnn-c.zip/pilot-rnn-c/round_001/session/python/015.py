
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]; top=asrt[:,-1]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
ok = Y==sec
m=(srt[:,-2]>0)&(g23<0.15)&(g12>0.02)
w3 = m&(Y==third)
print("n",m.sum(),"Y==third",w3.sum())
print("third later than sec: in errors", np.mean(third[w3]>sec[w3]), "in all m", np.mean(third[m]>sec[m]))
# by sec position and third position
import collections
M=np.zeros((10,10)); N=np.zeros((10,10))
for i in np.where(m)[0]:
    N[sec[i],third[i]]+=1; M[sec[i],third[i]]+= (Y[i]==third[i])
np.set_printoptions(precision=2, suppress=True, linewidth=220)
print(M/np.maximum(N,1))
# error rate vs top position in this near-tie set
for p in range(10):
    q=m&(top==p); print(p, q.sum(), (Y[q]==third[q]).mean())
