
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.argsort(X,1)
sec = srt[:,-2]
print("second largest", np.mean(Y==sec))
wrong = Y!=sec
print(wrong.sum())
# characterize wrong ones
top = srt[:,-1]
print("wrong: Y==top", np.mean(Y[wrong]==top[wrong]), "Y==third", np.mean(Y[wrong]==srt[wrong,-3]))
gap12 = X[np.arange(len(X)),top]-X[np.arange(len(X)),sec]
gap23 = X[np.arange(len(X)),sec]-X[np.arange(len(X)),srt[:,-3]]
print("gap12 wrong", np.percentile(gap12[wrong],[10,50,90]), "all", np.percentile(gap12,[10,50,90]))
print("gap23 wrong", np.percentile(gap23[wrong],[10,50,90]), "all", np.percentile(gap23,[10,50,90]))
print("positions of top in wrong", np.bincount(top[wrong],minlength=10))
print("positions of sec in wrong", np.bincount(sec[wrong],minlength=10))
print("Y in wrong", np.bincount(Y[wrong],minlength=10))
