
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
srt = np.sort(X,1); asrt=np.argsort(X,1)
sec = asrt[:,-2]; top=asrt[:,-1]; third=asrt[:,-3]
g12 = srt[:,-1]-srt[:,-2]; g23 = srt[:,-2]-srt[:,-3]
m=(srt[:,-2]>0)&(g23<0.2)&(g23>0.05)&(g12>0.02)
err = Y!=sec
lo=np.minimum(sec,third); hi=np.maximum(sec,third)
cat = np.where(top<lo,0,np.where(top>hi,2,1))
for c in range(3):
    q=m&(cat==c); print("top before/between/after",c,q.sum(),err[q].mean())
# does error depend on the time since the later of sec/third (recency)?
for d in range(10):
    q=m&(9-hi==d); print("age of later one",d,q.sum(),err[q].mean())
for d in range(1,10):
    q=m&(hi-lo==d); print("distance",d,q.sum(),err[q].mean())
# count of values between third and sec... number of positives
for k in range(11):
    q=m&((X>0).sum(1)==k); print("npos",k,q.sum(),err[q].mean())
