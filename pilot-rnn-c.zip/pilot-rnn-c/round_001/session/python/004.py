
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
print(np.bincount(Y, minlength=10))
print("argmax", np.mean(Y==X.argmax(1)))
print("argmin", np.mean(Y==X.argmin(1)))
print("count>0", np.mean(Y==(X>0).sum(1)))
print("count<0", np.mean(Y==(X<0).sum(1)))
for k in range(10):
    print(k, np.mean(Y==(np.abs(X)>k/4).sum(1)))
# last token position stuff
print("x9>0 vs Y", [np.mean(Y[X[:,9]>0]==c) for c in range(10)])
