
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
# how Y depends on each token: mean of x_t given Y
for c in range(10):
    print(c, np.round(X[Y==c].mean(0),2))
# sensitivity: perturb one token and see how often output changes
rng=np.random.default_rng(0)
def fwd(X):
    w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
    h=np.zeros((X.shape[0],16))
    for t in range(10):
        h=np.maximum(X[:,t:t+1]*w + h@R.T,0)
    return (h@O.T).argmax(1)
assert np.mean(fwd(X)==Y)==1
for t in range(10):
    X2=X.copy(); X2[:,t]=rng.standard_normal(len(X))
    print(t, np.mean(fwd(X2)==Y))
