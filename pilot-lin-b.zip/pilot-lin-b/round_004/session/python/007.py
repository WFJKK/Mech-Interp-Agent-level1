
import numpy as np, inspect
print([n for n in dir(lv1) if not n.startswith('_')])
# evaluator usage
src=inspect.getsource(lv1.Evaluator) if hasattr(lv1,'Evaluator') else ''
print(src[:3000])
