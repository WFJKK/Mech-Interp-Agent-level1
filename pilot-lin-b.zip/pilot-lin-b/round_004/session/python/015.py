
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
# check whether rows <10 ever win at L>=5
rng=np.random.default_rng(3)
for L in [5,8]:
    toks=rng.integers(0,64,size=(500000,L)); y=(E[:,toks].sum(2).T@W.T).argmax(1)
    print(L, np.bincount(y,minlength=64)[:12])
# test the packing/decoding in lv1 on a small example
g=graph()
seq=[10,63,37,20,11,55,60,61,62,63,15,16]
dig=[r-10 for r in seq]; packed=[]
for i in range(0,len(dig),10):
    chunk=dig[i:i+10]; packed.append(int(sum(d*64**k for k,d in enumerate(chunk))))
print(packed)
pk=g.const(np.array(packed,dtype=np.int64)).reshape(-1,1)
pw=g.const(np.array([64**k for k in range(10)],dtype=np.int64)).reshape(1,10)
q=(pk//pw); print(q.value.dtype, q.value.shape)
ids=lv1.cast(q%g.const(64),"int").reshape(-1)[:len(seq)]
print(ids.value)
