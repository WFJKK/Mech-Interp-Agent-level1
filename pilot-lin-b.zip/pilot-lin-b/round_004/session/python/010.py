
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(7)
def net_h(toks):
    h=E[:,toks].sum(axis=2).T; return h,(h@W.T).argmax(axis=1)
data={}
for L in [6,8]:
    toks=rng.integers(0,64,size=(3000000,L)); h,y=net_h(toks); data[L]=(h,y,toks.max(1))
def leaf_stats(L,v,K1):
    h,y,mx=data[L]; idx=np.where(mx==v)[0]; h=h[idx]; y=y[idx]
    c,n=np.unique(y,return_counts=True); order=np.argsort(-n); rows=c[order]; p=n[order]/len(idx)
    # rows with p>0.0012 are "worth" (DP threshold ~ (L+1)/7030)
    thr=(L+1)/7030
    worth=rows[p>thr]
    S1=list(worth[:K1]) if worth[0]==v else [v]+list(worth[:K1-1])
    S2=[r for r in worth if r not in S1]
    sc=h@W.T
    smx=sc[:,v]; s1=sc[:,[r for r in S1 if r!=v]].max(1)
    margin=smx-s1
    res=[]
    for T in [0,20,40,60,80,100,150,200]:
        trig=margin<T
        # prediction: if not trig -> argmax over S1; if trig -> argmax over S1+S2
        pred=np.where(trig, np.array(S1+S2)[sc[:,S1+S2].argmax(1)], np.array(S1)[sc[:,S1].argmax(1)])
        res.append((T, round(trig.mean(),3), round((pred!=y).mean(),5)))
    full_err=(np.array(S1+S2)[sc[:,S1+S2].argmax(1)]!=y).mean()
    return len(idx), S1, S2, round(full_err,5), res
for L in [8,6]:
    for v in [63,62,60,58,56,54,50]:
        n,S1,S2,fe,res=leaf_stats(L,v,4)
        print("L",L,"mx",v,"n",n,"S1",S1,"S2",S2,"fullerr",fe)
        print("   ",res)
