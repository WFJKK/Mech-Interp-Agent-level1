
import json, collections
best=entries['best']; nodes=best['nodes']
def short(n):
    d={k:v for k,v in n.items()}
    if n['op']=='const' and not isinstance(n['value'],(int,float)): d['value']='ARR'
    if n['op']=='slice': d['index']=[(ix if ix is None or isinstance(ix,int) else (ix['start'],ix['stop'])) for ix in n['index']]
    return d
for i in range(60,395):
    print(i, short(nodes[i]))
