
import numpy as np, time
t0=time.time()
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(41)
ALPHA=12.4; FP=703.0
def ideal_loss(L, v, stats, nb, extra_ops):
    # stats: list of arrays (per sample) ; bucket each into nb quantile buckets; rows per cell
    idx=np.where(MX==v)[0]; y=Y[idx]; n=len(idx)
    cell=np.zeros(n,dtype=np.int64)
    for s in stats:
        sv=s[idx]; qs=np.quantile(sv,np.linspace(0,1,nb+1)[1:-1]); b=np.searchsorted(qs,sv); cell=cell*nb+b
    ncell=nb**len(stats)
    cnt=np.zeros((ncell,64)); np.add.at(cnt,(cell,y),1); cnt/=NS
    loss=0.0
    for c in range(ncell):
        ben=ALPHA*cnt[c]; t=cnt[c].sum()
        if t==0: continue
        cost=t*(L+1)/FP; order=np.argsort(-ben); k=max(int((ben>cost).sum()),1)
        loss+=t*(1+extra_ops)/FP+k*cost+ben[order[k:]].sum()
    return loss/8
NS=3000000
for L in [8,6]:
    toks=rng.integers(0,64,size=(NS,L)); h=E[:,toks].sum(2).T; Y=(h@W.T).argmax(1); MX=toks.max(1)
    S=toks.sum(1); SQ=(toks**2).sum(1); EXP=(1.08**toks).sum(1); C48=(toks>=48).sum(1); C32=(toks<=32).sum(1); C56=(toks>=56).sum(1)
    tot={}
    for name,stats,nb,extra in [("none",[],1,0),("sum8",[S],8,4),("sum16",[S],16,4),("sum+sq",[S,SQ],6,12),("sum+exp",[S,EXP],6,12),("sum+c48",[S,C48],6,12),("sum+c32",[S,C32],6,12),("sum+c56",[S,C56],6,12),("exp8",[EXP],8,12),("sq8",[SQ],8,12)]:
        tot[name]=sum(ideal_loss(L,v,stats,nb,extra) for v in range(40,64))
    print("L",L,{k:round(v,5) for k,v in tot.items()}, round(time.time()-t0))
# larger held-out eval of r4c and r4b per length
def net(toks): return (E[:,toks].sum(axis=2).T@W.T).argmax(axis=1)
for name in ["r4b","r4c"]:
    ev=lv1.Evaluator(entries[name], weights, 8); rng2=np.random.default_rng(77); tot_ops=0; tot_err=0; n=0
    for L in range(1,9):
        Nn=12000; toks=rng2.integers(0,64,size=(Nn,L)); y=net(toks); full=np.full((Nn,8),64); full[:,:L]=toks
        for i in range(Nn):
            rr=ev.run(full[i]); tot_ops+=rr[3]; tot_err+=(rr[1]!=y[i]); n+=1
    fid=1-tot_err/n; print(name,"ops/input %.2f err %.5f est reward %.4f"%(tot_ops/n,tot_err/n, 1-(tot_ops/n+ev.build_cost/16384)/703-10*(1-lv1.wilson_lower(int(round(fid*16384)),16384))), round(time.time()-t0))
