
import numpy as np, inspect
print(inspect.getsource(lv1.Evaluator.run)[:1500])
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(5)
ev=lv1.Evaluator(entries['best'], weights, 8)
def net(toks):
    return (E[:,toks].sum(axis=2).T@W.T).argmax(axis=1)
base={}
for L in range(1,9):
    N=20000 if L>=5 else 5000
    toks=rng.integers(0,64,size=(N,L)); y=net(toks)
    full=np.full((N,8),64); full[:,:L]=toks
    ops=0; err=0
    for i in range(N):
        out=ev.run(full[i])
        # inspect first return format
        if i==0 and L==1: print(out)
        pred,cost=out[0],out[1]
        ops+=cost; err+=(int(pred)!=y[i])
    base[L]=(ops/N,err/N)
    print(L, ops/N, err/N)
print("build",ev.build_cost)
