
import numpy as np, json
print({k:v.shape for k,v in weights.items()})
print({k:(v if not hasattr(v,'shape') else v.shape) for k,v in info.items() if k!='check'})
print(info.get('check'))
print(list(entries.keys()))
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
W=U@H  # 64x8
M=W@E  # 64x65
print(np.linalg.svd(E[:,:64],compute_uv=False))
print(np.linalg.svd(W,compute_uv=False))
print(np.linalg.norm(E[:,:64],axis=0)[::8])
best=entries['best']
print(len(best['nodes']) if 'nodes' in best else best.keys())
