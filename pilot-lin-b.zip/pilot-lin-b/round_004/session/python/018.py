
import numpy as np, itertools
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
M54=M[10:,:64]; P=np.cumsum(M54,axis=1)/(np.arange(64)+1)
def table(c): return (M54+c*P).argmax(0)+10
t3=np.array(list(itertools.product(range(64),repeat=3)))
y3=(M[:,t3[:,0]]+M[:,t3[:,1]]+M[:,t3[:,2]]).argmax(0); m3=t3.max(1)
rng=np.random.default_rng(2)
t4=rng.integers(0,64,size=(3000000,4)); y4=(E[:,t4].sum(2).T@W.T).argmax(1); m4=t4.max(1)
for c3,c4 in [(2,3),(2.5,2.5),(2.2,2.8),(1.8,2.6),(2,2.6)]:
    T3=table(c3); T4=table(c4)
    print(c3,c4,"err3 %.5f err4 %.5f"%((T3[m3]!=y3).mean(),(T4[m4]!=y4).mean()))
# L3 two-row compare: for each m, best second row
T3=table(2); err_by_m=np.zeros(64); fixed_by_m=np.zeros(64); R3=np.zeros(64,int)
for m in range(64):
    idx=m3==m; w=y3[idx]; r1=T3[m]; others=w[w!=r1]
    err_by_m[m]=len(others)
    if len(others):
        vals,cnt=np.unique(others,return_counts=True); R3[m]=vals[cnt.argmax()]; fixed_by_m[m]=cnt.max()
tot=len(t3)
print("L3 total err %.5f, fixable by second row %.5f, active share %.3f"%(err_by_m.sum()/tot, fixed_by_m.sum()/tot, sum((m3==m).sum() for m in range(64) if R3[m])/tot))
# greedy: include m in compare if fixed*12.4 > active_prob*ops(~10)/703
gain=0; act=0
for m in range(64):
    if R3[m]:
        pm=(m3==m).sum()/tot; g=12.4*fixed_by_m[m]/tot - pm*10/703
        if g>0: gain+=g; act+=pm
        else: R3[m]=0
print("net gain per L3 input %.5f (reward %.5f), active %.3f, m with compare:"%(gain,gain/8,act), [m for m in range(64) if R3[m]])
# same for L4 (sampled)
T4=table(3); R4=np.zeros(64,int); gain4=0; act4=0
for m in range(64):
    idx=m4==m; w=y4[idx]; r1=T4[m]; others=w[w!=r1]
    if len(others):
        vals,cnt=np.unique(others,return_counts=True); pm=idx.mean(); g=12.4*cnt.max()/len(t4)-pm*12/703
        if g>0: R4[m]=vals[cnt.argmax()]; gain4+=g; act4+=pm
print("L4 net gain reward %.5f active %.3f"%(gain4/8,act4), [m for m in range(64) if R4[m]])
