
import numpy as np, time
t0=time.time()
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(11)
NB=160; DR=0.05; N=2000000
CC={}
for L in [5,6,7,8]:
    toks=rng.integers(0,64,size=(N,L))
    h=E[:,toks].sum(axis=2).T; y=(h@W.T).argmax(1)
    mx=toks.max(1); r=toks.sum(1)/(mx+1)
    rb=np.clip((r/DR).astype(int),0,NB-1)
    C=np.zeros((64,NB,64),dtype=np.int64); np.add.at(C,(mx,rb,y),1)
    cc=np.zeros((65,NB+1,64),dtype=np.int64); cc[1:,1:]=C.cumsum(0).cumsum(1); CC[L]=cc
ALPHA=12.4; FP=703.0
def agg(L,a,b,q1,q2):
    cc=CC[L]; return cc[b,q2]-cc[a,q2]-cc[b,q1]+cc[a,q1]
def block(Ls,a,b,q1,q2,extra):
    ben=np.zeros(64); cost=0.0; fixed=0.0
    for L in Ls:
        c=agg(L,a,b,q1,q2)/N; ben+=ALPHA*c; t=c.sum()
        cost+=t*(L+1)/FP; fixed+=t*(1+extra)/FP
    order=np.argsort(-ben); k=max(int((ben>cost).sum()),1)
    loss=(fixed+k*cost+ben[order[k:]].sum())/8
    return loss
def blk2(Ls,a,b,q1,q2,extra,split):
    if not split: return block(Ls,a,b,q1,q2,extra),0
    return sum(block([L],a,b,q1,q2,extra+1) for L in Ls),2
def seg_options(Ls,a,b,Q,dest,allow_split):
    opts=[]
    for sp in ([False,True] if allow_split else [False]):
        l,n=blk2(Ls,a,b,0,NB,dest,sp); opts.append((l,3+n))
        for i,q in enumerate(Q):
            l1,n1=blk2(Ls,a,b,0,q,dest+4,sp); l2,n2=blk2(Ls,a,b,q,NB,dest+4,sp); opts.append((l1+l2,5+n1+n2))
        for i in range(len(Q)):
            for j in range(i+1,len(Q)):
                qa,qb=Q[i],Q[j]
                A1,n1=blk2(Ls,a,b,0,qa,dest+4,sp); A2,n2=blk2(Ls,a,b,qa,qb,dest+6,sp); A3,n3=blk2(Ls,a,b,qb,NB,dest+6,sp)
                B1,_=blk2(Ls,a,b,0,qa,dest+6,sp); B2,_=blk2(Ls,a,b,qa,qb,dest+6,sp); B3,_=blk2(Ls,a,b,qb,NB,dest+4,sp)
                opts.append((min(A1+A2+A3,B1+B2+B3),7+n1+n2+n3))
    return opts
def dp(Ls,Q,lam,allow_split,dest=8):
    f=[0.0]*65; fl=[0.0]*65; fn=[0]*65
    for a in range(63,-1,-1):
        best=1e9
        for b in range(a+1,65):
            opts=seg_options(Ls,a,b,Q,dest,allow_split)
            l,nd=min(opts,key=lambda o:o[0]+lam*o[1])
            v=l+lam*nd+f[b]
            if v<best: best=v; bl=l+fl[b]; bn=nd+fn[b]
        f[a]=best; fl[a]=bl; fn[a]=bn
    return fl[0],fn[0]
Q56=[int(round(q/DR)) for q in [3.1,3.4,3.6,3.8]]; Q78=[int(round(q/DR)) for q in [3.6,3.9,4.0,4.6]]
for Ls,Q in [([5,6],Q56),([7,8],Q78)]:
    for lam in [3e-5,5e-5,7e-5,1e-4]:
        l0,n0=dp(Ls,Q,lam,False); l1,n1=dp(Ls,Q,lam,True)
        print(Ls,lam,"joint loss %.5f nodes %d | with per-length option loss %.5f nodes %d"%(l0,n0,l1,n1), round(time.time()-t0))
