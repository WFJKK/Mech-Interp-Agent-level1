
import numpy as np
rng=np.random.default_rng(1)
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
W=U@H; M=W@E
def gen(L,N):
    toks=rng.integers(0,64,size=(N,L))
    h=E[:,toks].sum(axis=2).T
    y=(h@W.T).argmax(axis=1)
    return toks,h,y,toks.max(axis=1)
out={}
for L in [6,8]:
    toks,h,y,mx=gen(L,2000000)
    print("L",L)
    for v in [50,54,56,58,60,62,63]:
        idx=np.where(mx==v)[0]
        hh=h[idx]; lab=(y[idx]==v)
        # LDA direction
        mu1=hh[lab].mean(0); mu0=hh[~lab].mean(0)
        S=np.cov(hh.T)+1e-6*np.eye(8)
        vd=np.linalg.solve(S,mu1-mu0)
        s=hh@vd
        # split half for threshold / half for test
        n=len(idx)//2
        s_tr,l_tr=s[:n],lab[:n]; s_te,l_te=s[n:],lab[n:]
        # threshold: exit when s>c; choose c = max score among non-mx-winners in train (+margin)
        c=s_tr[~l_tr].max()
        exit_rate=(s_te>c).mean(); fp=((s_te>c)&(~l_te)).mean()
        # weights-derived direction: mean of normalized D_j over rows that win >0.1%
        cands,cnt=np.unique(y[idx],return_counts=True)
        rows=cands[(cnt/len(idx)>0.001)&(cands!=v)]
        D=W[rows]-W[v]; vd2=-(D/np.linalg.norm(D,axis=1,keepdims=True)).sum(0)
        s2=hh@vd2; c2=s2[:n][~l_tr].max()
        exit2=(s2[n:]>c2).mean(); fp2=((s2[n:]>c2)&(~l_te)).mean()
        print(v,len(idx),"mxwin %.3f"%lab.mean(),"LDA exit %.3f fp %.5f"%(exit_rate,fp),"Wdir exit %.3f fp %.5f"%(exit2,fp2), "nrows",len(rows))
