
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
def net(full):
    toks=[t for t in full if t<64]; h=E[:,toks].sum(1); return int((W@h).argmax())
ev=lv1.Evaluator(entries['r4c'], weights, 8)
cases=[]
for L in range(1,9):
    for v in [0,1,9,10,11,12,31,32,44,45,47,48,55,56,62,63]:
        full=[64]*8; full[:L]=[v]*L; cases.append(full)
        full2=[64]*8; full2[:L]=[v]+[0]*(L-1); cases.append(full2)
        full3=[64]*8; full3[:L]=[0]*(L-1)+[v]; cases.append(full3)
        full4=[64]*8; full4[:L]=[63]*(L-1)+[v]; cases.append(full4)
rng=np.random.default_rng(99)
for _ in range(3000):
    L=rng.integers(1,9); full=[64]*8; full[:L]=list(rng.integers(0,64,size=L)); cases.append(full)
bad=0; err=0
for c in cases:
    try:
        r=ev.run(np.array(c)); err+=(r[1]!=net(c))
    except Exception as ex:
        bad+=1; print("FAIL",c,ex)
print("cases",len(cases),"failures",bad,"errors",err)
print(len(entries['r4c']['nodes']), sum(np.size(n['value']) for n in entries['r4c']['nodes'] if n['op']=='const'))
