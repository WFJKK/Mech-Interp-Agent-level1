
import numpy as np, time, itertools
t0=time.time()
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(11)
NB=160; DR=0.05; N=2000000
CC={}
for L in [5,6,7,8]:
    toks=rng.integers(0,64,size=(N,L))
    h=E[:,toks].sum(axis=2).T; y=(h@W.T).argmax(1)
    mx=toks.max(1); r=toks.sum(1)/(mx+1)
    rb=np.clip((r/DR).astype(int),0,NB-1)
    C=np.zeros((64,NB,64),dtype=np.int64); np.add.at(C,(mx,rb,y),1)
    cc=np.zeros((65,NB+1,64),dtype=np.int64); cc[1:,1:]=C.cumsum(0).cumsum(1); CC[L]=cc
ALPHA=12.4; FP=703.0
def agg(L,a,b,q1,q2):
    cc=CC[L]; return cc[b,q2]-cc[a,q2]-cc[b,q1]+cc[a,q1]
def block(Ls,a,b,q1,q2,extra):
    ben=np.zeros(64); cost=0.0; fixed=0.0; ptot=0.0
    for L in Ls:
        c=agg(L,a,b,q1,q2)/N; ben+=ALPHA*c; t=c.sum(); ptot+=t
        cost+=t*(L+1)/FP; fixed+=t*(1+extra)/FP
    order=np.argsort(-ben); k=int((ben>cost).sum()); k=max(k,1)
    rows=order[:k]
    if ben[order[0]]==0: rows=np.array([max(b-1,10)])
    loss=(fixed+k*cost+ben[order[k:]].sum())/8
    return loss, sorted(int(x) for x in rows), ptot
def seg_options(Ls,a,b,Q,dest):
    opts=[]
    l,rows,p=block(Ls,a,b,0,NB,dest); opts.append((l,3,('one',rows)))
    for i,q in enumerate(Q):
        l1,r1,_=block(Ls,a,b,0,q,dest+4); l2,r2,_=block(Ls,a,b,q,NB,dest+4)
        opts.append((l1+l2,5,('two',i,r1,r2)))
    for i in range(len(Q)):
        for j in range(i+1,len(Q)):
            qa,qb=Q[i],Q[j]
            A1,ra,_=block(Ls,a,b,0,qa,dest+4); A2,rb_,_=block(Ls,a,b,qa,qb,dest+6); A3,rc,_=block(Ls,a,b,qb,NB,dest+6)
            B1,_,_=block(Ls,a,b,0,qa,dest+6); B2,_,_=block(Ls,a,b,qa,qb,dest+6); B3,_,_=block(Ls,a,b,qb,NB,dest+4)
            if A1+A2+A3<=B1+B2+B3: opts.append((A1+A2+A3,7,('three_a',i,j,ra,rb_,rc)))
            else: opts.append((B1+B2+B3,7,('three_b',i,j,ra,rb_,rc)))
    return opts
def dp(Ls,Q,lam,dest=8):
    f=[0.0]*65; choice=[None]*65
    for a in range(63,-1,-1):
        best=1e9
        for b in range(a+1,65):
            opts=seg_options(Ls,a,b,Q,dest)
            l,nd,d=min(opts,key=lambda o:o[0]+lam*o[1])
            v=l+lam*nd+f[b]
            if v<best: best=v; choice[a]=(b,l,nd,d)
        f[a]=best
    segs=[]; a=0
    while a<64:
        b,l,nd,d=choice[a]; segs.append((a,b,l,nd,d)); a=b
    return segs
def segweight(Ls,a,b):
    return sum(agg(L,a,b,0,NB).sum()/N for L in Ls)
def opt_bst(ws):
    S=len(ws); cost=[[0.0]*S for _ in range(S)]; root=[[None]*S for _ in range(S)]
    wsum=[[0.0]*S for _ in range(S)]
    for i in range(S):
        for j in range(i,S): wsum[i][j]=sum(ws[i:j+1])
    for length in range(2,S+1):
        for i in range(0,S-length+1):
            j=i+length-1; best=1e18
            for k in range(i,j):
                c=cost[i][k]+cost[k+1][j]
                if c<best: best=c; root[i][j]=k
            cost[i][j]=best+wsum[i][j]
    def build(i,j):
        if i==j: return ('leaf',i)
        k=root[i][j]; return ('node',k,build(i,k),build(k+1,j))
    return build(0,S-1), cost[0][S-1]
def build_sequence(blocks):
    seq=[]; spans=[]
    for bi,B in enumerate(blocks):
        Bs=set(B); nxt=set(blocks[bi+1]) if bi+1<len(blocks) else set()
        start=len(seq)
        if spans:
            ps,pe=spans[-1]; st=pe
            while st>ps and seq[st-1] in Bs: st-=1
            start=st
        have=set(seq[start:]); new=[r for r in B if r not in have]
        new.sort(key=lambda r:(r in nxt, r))
        seq.extend(new); spans.append((start,len(seq)))
        assert set(seq[start:len(seq)])==Bs
    return seq,spans
M54=M[10:,:64]
P=np.cumsum(M54,axis=1)/(np.arange(64)+1)
tbl=np.stack([M54,M54+P,M54+2*P,M54+3*P]).argmax(axis=1)
a,b=np.meshgrid(np.arange(64),np.arange(64),indexing='ij')
win2=(M[:,a]+M[:,b]).argmax(0)
R2=np.zeros(64,dtype=int)
for m in range(64):
    mask=np.maximum(a,b)==m; w=win2[mask]; r1=tbl[1,m]+10
    others=w[w!=r1]
    if len(others):
        vals,cnt=np.unique(others,return_counts=True); R2[m]=vals[cnt.argmax()]-10
def emit(cfg):
    Q56,Q78,lam56,lam78=cfg
    segs56=dp([5,6],[int(round(q/DR)) for q in Q56],lam56)
    segs78=dp([7,8],[int(round(q/DR)) for q in Q78],lam78)
    g=graph(); consts={}
    def C(v):
        key=(type(v).__name__,v)
        if key not in consts: consts[key]=g.const(v)
        return consts[key]
    tk=[g.token(i) for i in range(8)]; T=g.tokens()
    hE=g.weight("hidden")@g.weight("embed")[:,:64]
    M54g=g.weight("unembed")[10:]@hE
    Pg=lv1.cumsum(M54g,axis=1)/(g.arange(64)+C(1))
    A2=M54g+Pg; A3=A2+Pg; A4=A3+Pg
    tblg=lv1.stack([M54g,A2,A3,A4],axis=0).argmax(axis=1)
    e=[tk[i]==C(64) for i in range(8)]
    m2=lv1.maximum(tk[0],tk[1]); m3=lv1.maximum(m2,tk[2]); m4=lv1.maximum(m3,tk[3])
    L1=tblg[0][tk[0]]
    r1=tblg[1][m2]; r2=g.const(np.array(R2,dtype=np.int64))[m2]
    s1=M54g[r1,tk[0]]+M54g[r1,tk[1]]; s2=M54g[r2,tk[0]]+M54g[r2,tk[1]]
    L2=lv1.cond(r2==C(0), r1, lv1.where(s1>=s2,r1,r2))
    L3=tblg[2][m3]; L4=tblg[3][m4]
    L14=lv1.cond(e[2], lv1.cond(e[1],L1,L2), lv1.cond(e[3],L3,L4))+C(10)
    allblocks=[]
    def collect(segs):
        for (a,b,l,nd,d) in segs:
            if d[0]=='one': allblocks.append(d[1])
            elif d[0]=='two': allblocks.append(d[2]); allblocks.append(d[3])
            else: allblocks.extend([d[3],d[4],d[5]])
    collect(segs56); collect(segs78)
    seq,spans=build_sequence(allblocks)
    dig=[r-10 for r in seq]; packed=[]
    for i in range(0,len(dig),10):
        chunk=dig[i:i+10]; packed.append(int(sum(d*64**k for k,d in enumerate(chunk))))
    pk=g.const(np.array(packed,dtype=np.int64)).reshape(-1,1)
    pw=g.const(np.array([64**k for k in range(10)],dtype=np.int64)).reshape(1,10)
    ids=lv1.cast((pk//pw)%C(64),"int").reshape(-1)[:len(seq)]
    Tb=lv1.concat([lv1.take(M54g,ids,axis=0), lv1.cast(ids+C(10),"float").reshape(-1,1)],axis=1)
    bi=[0]
    def emit_tree(segs,mx,r,Q,Ls):
        Qc=[C(float(q)) for q in Q]
        rlt=[r<Qc[i] for i in range(len(Q))]
        def blk():
            s,e_=spans[bi[0]]; bi[0]+=1; return Tb[s:e_]
        leaves=[]
        for (a,b,l,nd,d) in segs:
            if d[0]=='one': leaves.append(blk())
            elif d[0]=='two':
                A=blk(); B=blk(); leaves.append(lv1.cond(rlt[d[1]],A,B))
            elif d[0]=='three_a':
                A=blk(); B=blk(); Cc=blk(); leaves.append(lv1.cond(rlt[d[1]],A,lv1.cond(rlt[d[2]],B,Cc)))
            else:
                A=blk(); B=blk(); Cc=blk(); leaves.append(lv1.cond(rlt[d[2]],lv1.cond(rlt[d[1]],A,B),Cc))
        ws=[segweight(Ls,a,b) for (a,b,_,_,_) in segs]
        tree,dc=opt_bst(ws)
        def rec(t):
            if t[0]=='leaf': return leaves[t[1]]
            k=t[1]; bound=segs[k][1]
            return lv1.cond(mx<C(int(bound)), rec(t[2]), rec(t[3]))
        return rec(tree), dc
    t5m=tk[5]%C(64); mx56=lv1.maximum(T[:5].max(),t5m); sum56=T[:5].sum()+t5m; r56=sum56/(mx56+C(1))
    tv56=lv1.cond(e[5],T[:5],T[:6])
    blk56,dc56=emit_tree(segs56,mx56,r56,Q56,[5,6])
    s=lv1.take_sum(blk56[:,:64],tv56,axis=1); i=s.argmax(); G56=lv1.cast(blk56[:,64][i],"int")
    t7m=tk[7]%C(64); mx78=lv1.maximum(T[:7].max(),t7m); sum78=T[:7].sum()+t7m; r78=sum78/(mx78+C(1))
    tv78=lv1.cond(e[7],T[:7],T)
    blk78,dc78=emit_tree(segs78,mx78,r78,Q78,[7,8])
    s=lv1.take_sum(blk78[:,:64],tv78,axis=1); i=s.argmax(); G78=lv1.cast(blk78[:,64][i],"int")
    out=lv1.cond(e[4],L14,lv1.cond(e[6],G56,G78))
    entry=g.entry(interpretation=out)
    info_={'nodes':len(entry['nodes']),'seq':len(seq),'nblocks':len(allblocks),'segs':(len(segs56),len(segs78)),
           'loss':(round(sum(x[2] for x in segs56),5),round(sum(x[2] for x in segs78),5)),'desc':(round(dc56,3),round(dc78,3)),'nconst':len(packed)+10+64+len(consts)}
    return entry,info_
def net(toks): return (E[:,toks].sum(axis=2).T@W.T).argmax(axis=1)
def evalentry(entry, N5=20000, N1=3000, seed=5):
    rng=np.random.default_rng(seed); ev=lv1.Evaluator(entry, weights, 8); out={}
    for L in range(1,9):
        Nn=N5 if L>=5 else N1
        toks=rng.integers(0,64,size=(Nn,L)); y=net(toks)
        full=np.full((Nn,8),64); full[:,:L]=toks; ops=0; err=0
        for i in range(Nn):
            rr=ev.run(full[i]); ops+=rr[3]; err+=(rr[1]!=y[i])
        out[L]=(round(ops/Nn,1),round(err/Nn,5))
    return out, ev.build_cost
for cfg in [([3.3,3.5,3.7],[3.6,3.9,4.2,4.5],0.00008,0.00008),([3.3,3.5,3.7],[3.6,3.9,4.2,4.5],0.00006,0.00006)]:
    entry,inf=emit(cfg); print(inf)
    if inf['nodes']<=400:
        print(measure(entry)); pl,bc=evalentry(entry); print(pl,bc)
        save_entry("r4a_%d"%inf['nodes'],entry)
print(time.time()-t0)
