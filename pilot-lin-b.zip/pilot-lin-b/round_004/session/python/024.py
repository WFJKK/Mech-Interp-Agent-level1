
import numpy as np, time, itertools
t0=time.time()
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(31)
NB=160; DR=0.05; N=4000000
CC={}
for L in [5,6,7,8]:
    C=np.zeros((64,NB,64),dtype=np.int64)
    for rep in range(2):
        toks=rng.integers(0,64,size=(N//2,L))
        h=E[:,toks].sum(axis=2).T; y=(h@W.T).argmax(1)
        mx=toks.max(1); r=toks.sum(1)/(mx+1); rb=np.clip((r/DR).astype(int),0,NB-1)
        np.add.at(C,(mx,rb,y),1)
    cc=np.zeros((65,NB+1,64),dtype=np.int64); cc[1:,1:]=C.cumsum(0).cumsum(1); CC[L]=cc
ALPHA=12.4; FP=703.0
def agg(L,a,b,q1,q2):
    cc=CC[L]; return cc[b,q2]-cc[a,q2]-cc[b,q1]+cc[a,q1]
def block(Ls,a,b,q1,q2,extra):
    ben=np.zeros(64); cost=0.0; fixed=0.0
    for L in Ls:
        c=agg(L,a,b,q1,q2)/N; ben+=ALPHA*c; t=c.sum()
        cost+=t*(L+1)/FP; fixed+=t*(1+extra)/FP
    order=np.argsort(-ben); k=max(int((ben>cost).sum()),1); rows=order[:k]
    if ben[order[0]]==0: rows=np.array([max(b-1,10)])
    return (fixed+k*cost+ben[order[k:]].sum())/8, sorted(int(x) for x in rows)
def seg_options(Ls,a,b,Q,dest):
    opts=[]
    l,rows=block(Ls,a,b,0,NB,dest); opts.append((l,3,('one',rows)))
    nq=len(Q)
    for i in range(nq):
        l1,r1=block(Ls,a,b,0,Q[i],dest+4); l2,r2=block(Ls,a,b,Q[i],NB,dest+4); opts.append((l1+l2,5,('two',i,r1,r2)))
    for i in range(nq):
        for j in range(i+1,nq):
            qa,qb=Q[i],Q[j]
            A1,ra=block(Ls,a,b,0,qa,dest+4); A2,rb_=block(Ls,a,b,qa,qb,dest+6); A3,rc=block(Ls,a,b,qb,NB,dest+6)
            B1,_=block(Ls,a,b,0,qa,dest+6); B2,_=block(Ls,a,b,qa,qb,dest+6); B3,_=block(Ls,a,b,qb,NB,dest+4)
            if A1+A2+A3<=B1+B2+B3: opts.append((A1+A2+A3,7,('three_a',i,j,ra,rb_,rc)))
            else: opts.append((B1+B2+B3,7,('three_b',i,j,ra,rb_,rc)))
    for i in range(nq):
        for j in range(i+1,nq):
            for k in range(j+1,nq):
                qs=[0,Q[i],Q[j],Q[k],NB]; ls=[]; rs=[]
                for t_ in range(4):
                    l_,r_=block(Ls,a,b,qs[t_],qs[t_+1],dest+6); ls.append(l_); rs.append(r_)
                opts.append((sum(ls),9,('four',i,j,k,rs)))
    return opts
def dp(Ls,Q,lam,dest=8):
    f=[0.0]*65; choice=[None]*65
    for a in range(63,-1,-1):
        best=1e9
        for b in range(a+1,65):
            opts=seg_options(Ls,a,b,Q,dest)
            l,nd,d=min(opts,key=lambda o:o[0]+lam*o[1]); v=l+lam*nd+f[b]
            if v<best: best=v; choice[a]=(b,l,nd,d)
        f[a]=best
    segs=[]; a=0
    while a<64:
        b,l,nd,d=choice[a]; segs.append((a,b,l,nd,d)); a=b
    return segs
def segweight(Ls,a,b): return sum(agg(L,a,b,0,NB).sum()/N for L in Ls)
def opt_bst(ws):
    S=len(ws); cost=[[0.0]*S for _ in range(S)]; root=[[None]*S for _ in range(S)]
    wsum=[[sum(ws[i:j+1]) if j>=i else 0 for j in range(S)] for i in range(S)]
    for length in range(2,S+1):
        for i in range(0,S-length+1):
            j=i+length-1; best=1e18
            for k in range(i,j):
                c=cost[i][k]+cost[k+1][j]
                if c<best: best=c; root[i][j]=k
            cost[i][j]=best+wsum[i][j]
    def build(i,j):
        if i==j: return ('leaf',i)
        k=root[i][j]; return ('node',k,build(i,k),build(k+1,j))
    return build(0,S-1), cost[0][S-1]
def build_sequence(blocks):
    seq=[]; spans=[]
    for bi,B in enumerate(blocks):
        Bs=set(B); nxt=set(blocks[bi+1]) if bi+1<len(blocks) else set()
        found=None
        for st in range(len(seq)):
            if seq[st] not in Bs: continue
            en=st
            while en<len(seq) and seq[en] in Bs: en+=1
            if set(seq[st:en])==Bs and en-st==len(Bs): found=(st,en); break
        if found: spans.append(found); continue
        st=len(seq)
        while st>0 and seq[st-1] in Bs and (len(seq)-st)<len(Bs) and len(set(seq[st-1:]))==len(seq)-st+1: st-=1
        start=st; have=set(seq[start:]); new=[r for r in B if r not in have]
        new.sort(key=lambda r:(r in nxt, r)); seq.extend(new); spans.append((start,len(seq)))
        assert set(seq[start:])==Bs and len(seq)-start==len(Bs)
    return seq,spans
def blocks_of(segs):
    out=[]
    for (a,b,l,nd,d) in segs:
        if d[0]=='one': out.append(d[1])
        elif d[0]=='two': out+= [d[2],d[3]]
        elif d[0] in ('three_a','three_b'): out+=[d[3],d[4],d[5]]
        else: out+=d[4]
    return out
T1=M[:,:64].argmax(0); TL=np.maximum(np.arange(64),T1.min()); TL[0]=T1[0]
a_,b_=np.meshgrid(np.arange(64),np.arange(64),indexing='ij'); win2=(M[:,a_]+M[:,b_]).argmax(0); m2=np.maximum(a_,b_)
R2=np.zeros(64,int)
for m in range(64):
    w=win2[m2==m]; others=w[w!=TL[m]]
    if len(others): vals,cnt=np.unique(others,return_counts=True); R2[m]=vals[cnt.argmax()]
t3=np.array(list(itertools.product(range(64),repeat=3))); y3=(M[:,t3[:,0]]+M[:,t3[:,1]]+M[:,t3[:,2]]).argmax(0); m3=t3.max(1)
R3=np.zeros(64,int)
for m in range(64):
    idx=m3==m; w=y3[idx]; others=w[w!=TL[m]]
    if len(others):
        vals,cnt=np.unique(others,return_counts=True); pm=idx.mean()
        if 12.4*cnt.max()/len(t3) > pm*13/703: R3[m]=vals[cnt.argmax()]
def emit(segs56,segs78,Q56,Q78):
    g=graph(); consts={}
    def C(v):
        key=(type(v).__name__,v)
        if key not in consts: consts[key]=g.const(v)
        return consts[key]
    tk=[g.token(i) for i in range(8)]; T=g.tokens()
    hE=g.weight("hidden")@g.weight("embed")[:,:64]; M64=g.weight("unembed")@hE
    T1g=M64.argmax(axis=0); ar=g.arange(64)
    TLg=lv1.where(ar==C(0), T1g[0], lv1.maximum(ar, T1g.min()))
    e=[tk[i]==C(64) for i in range(8)]
    m2_=lv1.maximum(tk[0],tk[1]); m3_=lv1.maximum(m2_,tk[2]); m4_=lv1.maximum(m3_,tk[3])
    L1=T1g[tk[0]]
    Rp=g.const(np.array(R2+64*R3,dtype=np.int64)); R2g=Rp%C(64); R3g=Rp//C(64)
    r1=TLg[m2_]; r2=R2g[m2_]
    s1=M64[r1,tk[0]]+M64[r1,tk[1]]; s2=M64[r2,tk[0]]+M64[r2,tk[1]]
    L2=lv1.cond(r2==C(0), r1, lv1.where(s1>=s2,r1,r2))
    q1=TLg[m3_]; q2=R3g[m3_]
    u1=M64[q1,tk[0]]+M64[q1,tk[1]]+M64[q1,tk[2]]; u2=M64[q2,tk[0]]+M64[q2,tk[1]]+M64[q2,tk[2]]
    L3=lv1.cond(q2==C(0), q1, lv1.where(u1>=u2,q1,q2))
    L4=TLg[m4_]
    L14=lv1.cond(e[2], lv1.cond(e[1],L1,L2), lv1.cond(e[3],L3,L4))
    b56=blocks_of(segs56); b78=blocks_of(segs78)
    s56=[(s[0],blocks_of([s])) for s in segs56]; s78=[(s[0],blocks_of([s])) for s in segs78]
    inter=[b for _,bl in sorted(s56+s78,key=lambda x:x[0]) for b in bl]
    bysize=sorted(b56+b78,key=lambda B:(-len(B),B))
    best=None
    for order in [b56+b78, b78+b56, inter, inter[::-1], (b56+b78)[::-1], bysize]:
        seq,spans=build_sequence(order)
        if best is None or len(seq)<len(best[0]): best=(seq,spans,order)
    seq,spans,order=best
    span_of={id(blk_):sp for blk_,sp in zip(order,spans)}
    packed=[]
    for i in range(0,len(seq),10):
        chunk=seq[i:i+10]; packed.append(int(sum(d*64**k for k,d in enumerate(chunk))))
    pk=g.const(np.array(packed,dtype=np.int64)).reshape(-1,1)
    pw=g.const(np.array([64**k for k in range(10)],dtype=np.int64)).reshape(1,10)
    ids=lv1.cast((pk//pw)%C(64),"int").reshape(-1)[:len(seq)]
    Tb=lv1.concat([lv1.take(M64,ids,axis=0), lv1.cast(ids,"float").reshape(-1,1)],axis=1)
    def emit_tree(segs,mx,r,Q,Ls):
        Qc=[C(float(q)) for q in Q]; rlt=[r<Qc[i] for i in range(len(Q))]
        def blk(B): s,e_=span_of[id(B)]; return Tb[s:e_]
        leaves=[]
        for (a,b,l,nd,d) in segs:
            if d[0]=='one': leaves.append(blk(d[1]))
            elif d[0]=='two': leaves.append(lv1.cond(rlt[d[1]],blk(d[2]),blk(d[3])))
            elif d[0]=='three_a': leaves.append(lv1.cond(rlt[d[1]],blk(d[3]),lv1.cond(rlt[d[2]],blk(d[4]),blk(d[5]))))
            elif d[0]=='three_b': leaves.append(lv1.cond(rlt[d[2]],lv1.cond(rlt[d[1]],blk(d[3]),blk(d[4])),blk(d[5])))
            else:
                rs=d[4]; leaves.append(lv1.cond(rlt[d[2]], lv1.cond(rlt[d[1]],blk(rs[0]),blk(rs[1])), lv1.cond(rlt[d[3]],blk(rs[2]),blk(rs[3]))))
        ws=[segweight(Ls,a,b) for (a,b,_,_,_) in segs]
        tree,dc=opt_bst(ws)
        def rec(t):
            if t[0]=='leaf': return leaves[t[1]]
            k=t[1]; bound=segs[k][1]
            return lv1.cond(mx<C(int(bound)), rec(t[2]), rec(t[3]))
        return rec(tree), dc
    t5m=tk[5]%C(64); mx56=lv1.maximum(T[:5].max(),t5m); sum56=T[:5].sum()+t5m; r56=sum56/(mx56+C(1))
    tv56=lv1.cond(e[5],T[:5],T[:6])
    blk56,dc56=emit_tree(segs56,mx56,r56,Q56,[5,6])
    s=lv1.take_sum(blk56[:,:64],tv56,axis=1); i=s.argmax(); G56=lv1.cast(blk56[:,64][i],"int")
    t7m=tk[7]%C(64); mx78=lv1.maximum(T[:7].max(),t7m); sum78=T[:7].sum()+t7m; r78=sum78/(mx78+C(1))
    tv78=lv1.cond(e[7],T[:7],T)
    blk78,dc78=emit_tree(segs78,mx78,r78,Q78,[7,8])
    s=lv1.take_sum(blk78[:,:64],tv78,axis=1); i=s.argmax(); G78=lv1.cast(blk78[:,64][i],"int")
    out=lv1.cond(e[4],L14,lv1.cond(e[6],G56,G78))
    entry=g.entry(interpretation=out)
    info_={'nodes':len(entry['nodes']),'seq':len(seq),'nblocks':len(order),'segs':(len(segs56),len(segs78)),
           'loss':(round(sum(x[2] for x in segs56),5),round(sum(x[2] for x in segs78),5)),'nconst':len(packed)+10+64+len(consts)}
    return entry,info_
Q56=[3.1,3.3,3.4,3.6,3.8]; Q78=[3.6,3.9,4.0,4.1,4.6]
q56=[int(round(q/DR)) for q in Q56]; q78=[int(round(q/DR)) for q in Q78]
results=[]
for lam in [4.9e-5,4.8e-5,4.75e-5,4.7e-5]:
    segs56=dp([5,6],q56,lam); segs78=dp([7,8],q78,lam)
    entry,inf=emit(segs56,segs78,Q56,Q78); print(lam,inf,round(time.time()-t0))
    results.append((lam,inf['nodes'],entry))
    if inf['nodes']>400: break
ok=[r for r in results if r[1]<=400]; lam,nn,entry=max(ok,key=lambda r:r[1])
print("chosen",lam,nn); print(measure(entry)); save_entry("r4d",entry)
def net(toks): return (E[:,toks].sum(axis=2).T@W.T).argmax(axis=1)
for name,ent in [("r4c",entries['r4c']),("r4d",entry)]:
    ev=lv1.Evaluator(ent, weights, 8); rng2=np.random.default_rng(123); tot_ops=0; tot_err=0; n=0
    for L in range(1,9):
        Nn=15000; toks=rng2.integers(0,64,size=(Nn,L)); y=net(toks); full=np.full((Nn,8),64); full[:,:L]=toks
        for i in range(Nn):
            rr=ev.run(full[i]); tot_ops+=rr[3]; tot_err+=(rr[1]!=y[i]); n+=1
    fid=1-tot_err/n; print(name,"ops/input %.2f err %.5f build %d est reward %.4f"%(tot_ops/n,tot_err/n,ev.build_cost, 1-(tot_ops/n+ev.build_cost/16384)/703-10*(1-lv1.wilson_lower(int(round(fid*16384)),16384))), round(time.time()-t0))
