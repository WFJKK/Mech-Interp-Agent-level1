
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
M54=M[10:,:64]; P=np.cumsum(M54,axis=1)/(np.arange(64)+1)
T={c:(M54+c*P).argmax(0)+10 for c in [0,1,2,3]}
for c in [1,2,3]:
    print(c, "differs from c-1 at", np.where(T[c]!=T[c-1])[0], "from c=1 at", np.where(T[c]!=T[1])[0])
print(T[1]); print(T[3])
# exact L=2 error if using T[3] as T2 (with R2 compare) and L3 error with T[1] etc.
a_,b_=np.meshgrid(np.arange(64),np.arange(64),indexing='ij'); win2=(M[:,a_]+M[:,b_]).argmax(0); m2=np.maximum(a_,b_)
for c in [1,2,3]:
    print("L2 err with T[%d] r1-only: %.5f"%(c,(T[c][m2]!=win2).mean()))
e=entries['r4a']; print(len(e['nodes']), sum(1 for n in e['nodes'] if n['op']=='const'))
