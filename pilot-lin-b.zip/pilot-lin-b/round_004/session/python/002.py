
import numpy as np
rng=np.random.default_rng(0)
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
W=U@H; M=W@E
def sample(L,N):
    return rng.integers(0,64,size=(N,L))
def run(toks):
    h=E[:,toks].sum(axis=1)  # N x 8
    lg=h@W.T
    return h, lg.argmax(axis=1)
res={}
for L in [5,6,7,8]:
    toks=sample(L,300000)
    h,y=run(toks)
    mx=toks.max(axis=1)
    res[L]=(toks,h,y,mx)
    print(L,(y==mx).mean())
# second moment of h for L=8
h=res[8][1]
S=h.T@h/len(h)
ev,evec=np.linalg.eigh(S)
print(ev[::-1])
# test projection accuracy per leaf with candidate = rows that win at least once for that mx (L-pooled 5..8)
def test(d, Pi_fn, Ls=(8,)):
    tot=0; err=0
    for L in Ls:
        toks,h,y,mx=res[L]
        for v in range(30,64):
            idx=np.where(mx==v)[0]
            if len(idx)==0: continue
            cands=np.unique(y[idx])
            Pi=Pi_fn(v,d)
            sc=(h[idx]@Pi)@W[cands].T
            pred=cands[sc.argmax(axis=1)]
            err+=(pred!=y[idx]).sum(); tot+=len(idx)
    return err/tot
def pca(v,d):
    V=evec[:,::-1][:,:d]; return V@V.T
for d in [2,3,4,5,6,8]:
    print(d, test(d,pca), test(d,pca,(5,6,7)))
