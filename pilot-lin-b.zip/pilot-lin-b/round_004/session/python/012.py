
import numpy as np, time
t0=time.time()
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(11)
NB=160; DR=0.05
N=2000000
CC={}
for L in [5,6,7,8]:
    toks=rng.integers(0,64,size=(N,L))
    h=E[:,toks].sum(axis=2).T; y=(h@W.T).argmax(1)
    mx=toks.max(1); r=toks.sum(1)/(mx+1)
    rb=np.clip((r/DR).astype(int),0,NB-1)
    C=np.zeros((64,NB,64),dtype=np.int64); np.add.at(C,(mx,rb,y),1)
    cc=np.zeros((65,NB+1,64),dtype=np.int64); cc[1:,1:]=C.cumsum(0).cumsum(1); CC[L]=cc
print("stats",time.time()-t0)
ALPHA=12.4; FP=703.0
def agg(L,a,b,q1,q2):
    cc=CC[L]; return cc[b,q2]-cc[a,q2]-cc[b,q1]+cc[a,q1]
def block(Ls,a,b,q1,q2,extra):
    ben=np.zeros(64); cost=0.0; fixed=0.0; ptot=0.0
    for L in Ls:
        c=agg(L,a,b,q1,q2)/N; ben+=ALPHA*c; t=c.sum(); ptot+=t
        cost+=t*(L+1)/FP; fixed+=t*(1+extra)/FP
    order=np.argsort(-ben); k=int((ben>cost).sum()); k=max(k,1)
    rows=order[:k]
    if ben[order[0]]==0: rows=np.array([b-1])
    loss=(fixed+k*cost+ben[order[k:]].sum())/8
    return loss, sorted(int(x) for x in rows), ptot
def seg_options(Ls,a,b,Q,dest):
    # returns list of (loss, nodes, desc) ; dest = est descent ops
    opts=[]
    l,rows,p=block(Ls,a,b,0,NB,dest); opts.append((l,3,('one',rows)))
    for i,q in enumerate(Q):
        l1,r1,_=block(Ls,a,b,0,q,dest+4); l2,r2,_=block(Ls,a,b,q,NB,dest+4)
        opts.append((l1+l2,5,('two',i,r1,r2)))
    for i in range(len(Q)):
        for j in range(i+1,len(Q)):
            qa,qb=Q[i],Q[j]
            # test qa first: [0,qa) depth1, others depth2 ; or qb first
            A1,ra,_=block(Ls,a,b,0,qa,dest+4); A2,rb_,_=block(Ls,a,b,qa,qb,dest+6); A3,rc,_=block(Ls,a,b,qb,NB,dest+6)
            B1,_,_=block(Ls,a,b,0,qa,dest+6); B2,_,_=block(Ls,a,b,qa,qb,dest+6); B3,_,_=block(Ls,a,b,qb,NB,dest+4)
            if A1+A2+A3<=B1+B2+B3: opts.append((A1+A2+A3,7,('three_a',i,j,ra,rb_,rc)))
            else: opts.append((B1+B2+B3,7,('three_b',i,j,ra,rb_,rc)))
    return opts
def dp(Ls,Q,lam,dest=9):
    f=[0.0]*65; choice=[None]*65
    for a in range(63,-1,-1):
        best=1e9
        for b in range(a+1,65):
            opts=seg_options(Ls,a,b,Q,dest)
            l,nd,d=min(opts,key=lambda o:o[0]+lam*o[1])
            v=l+lam*nd+f[b]
            if v<best: best=v; choice[a]=(b,l,nd,d)
        f[a]=best
    segs=[]; a=0
    while a<64:
        b,l,nd,d=choice[a]; segs.append((a,b,l,nd,d)); a=b
    return f[0],segs
def summarize(segs,lam):
    loss=sum(s[2] for s in segs); nodes=sum(s[3] for s in segs)
    return loss,nodes
# current best as reference per group: cost ops (59.1,68.1)->(0.0105,0.0121) err (0.0005,0.0019)
for Ls,Qs in [([5,6],[[3.3,3.5,3.7],[3.2,3.4,3.6,3.8],[3.3,3.45,3.6]]),([7,8],[[3.7,4.0,4.3],[3.6,3.9,4.2,4.5],[3.8,4.1,4.4]])]:
    for Q in Qs:
        qi=[int(round(q/DR)) for q in Q]
        for lam in [0.00005,0.0001,0.0002]:
            f,segs=dp(Ls,qi,lam)
            loss,nodes=summarize(segs,lam)
            print(Ls,Q,lam,"loss %.5f nodes %d segs %d"%(loss,nodes,len(segs)), time.time()-t0)
