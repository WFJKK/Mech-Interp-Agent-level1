
import numpy as np, time, pickle, os
t0=time.time()
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(11)
NB=160; redges=np.arange(0,8.0001,0.05)
N=2000000
counts={}   # L -> (64 v, NB, 64 rows)
for L in [5,6,7,8]:
    toks=rng.integers(0,64,size=(N,L))
    h=E[:,toks].sum(axis=2).T; y=(h@W.T).argmax(1)
    mx=toks.max(1); s=toks.sum(1); r=s/(mx+1)
    rb=np.clip((r/0.05).astype(int),0,NB-1)
    C=np.zeros((64,NB,64),dtype=np.int32)
    np.add.at(C,(mx,rb,y),1)
    counts[L]=C
os.makedirs('tmp',exist_ok=True)
pickle.dump(counts,open('tmp/counts.pkl','wb'))
print("stats done",time.time()-t0)
# quick look: distribution of r per L
for L in [5,6,7,8]:
    C=counts[L]; pr=C.sum((0,2)); cum=np.cumsum(pr)/pr.sum()
    print(L, [round(redges[np.searchsorted(cum,q)],2) for q in [0.1,0.25,0.5,0.75,0.9]])
