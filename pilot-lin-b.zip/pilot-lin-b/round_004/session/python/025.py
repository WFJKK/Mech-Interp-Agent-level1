
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H
def net(full):
    toks=[t for t in full if t<64]; h=E[:,toks].sum(1); return int((W@h).argmax())
ev=lv1.Evaluator(entries['r4d'], weights, 8)
cases=[]
for L in range(1,9):
    for v in [0,1,9,10,11,12,31,32,44,45,47,48,55,56,62,63]:
        for pat in ([v]*L, [v]+[0]*(L-1), [0]*(L-1)+[v], [63]*(L-1)+[v], [v]+[63]*(L-1)):
            full=[64]*8; full[:L]=pat; cases.append(full)
rng=np.random.default_rng(7)
for _ in range(4000):
    L=rng.integers(1,9); full=[64]*8; full[:L]=list(rng.integers(0,64,size=L)); cases.append(full)
bad=0; err=0
for c in cases:
    try:
        r=ev.run(np.array(c)); err+=(r[1]!=net(c))
    except Exception as ex:
        bad+=1; print("FAIL",c,ex)
print("cases",len(cases),"failures",bad,"errors",err, "nodes",len(entries['r4d']['nodes']), "consts",sum(np.size(n['value']) for n in entries['r4d']['nodes'] if n['op']=='const'))
