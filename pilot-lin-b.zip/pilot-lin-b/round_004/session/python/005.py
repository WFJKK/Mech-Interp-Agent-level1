
import json, collections
best=entries['best']
print(best.keys())
nodes=best['nodes']
print(nodes[0], nodes[1])
ops=collections.Counter(n.get('op') for n in nodes)
print(ops)
# print first 40 nodes compactly
for i,n in enumerate(nodes[:60]):
    print(i, {k:(v if k!='value' or (isinstance(v,(int,float))) else '...') for k,v in n.items()})
print(best.get('predict'), best.get('rule'))
