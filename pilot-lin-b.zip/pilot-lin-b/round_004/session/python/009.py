
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(5)
ev=lv1.Evaluator(entries['best'], weights, 8)
def net(toks):
    return (E[:,toks].sum(axis=2).T@W.T).argmax(axis=1)
def evalentry(entry, N5=20000, N1=4000, seed=5):
    rng=np.random.default_rng(seed)
    ev=lv1.Evaluator(entry, weights, 8)
    out={}
    for L in range(1,9):
        N=N5 if L>=5 else N1
        toks=rng.integers(0,64,size=(N,L)); y=net(toks)
        full=np.full((N,8),64); full[:,:L]=toks
        ops=0; err=0
        for i in range(N):
            r=ev.run(full[i]); ops+=r[3]; err+=(r[1]!=y[i])
        out[L]=(ops/N,err/N)
    return out, ev.build_cost
base,b=evalentry(entries['best'])
for L in base: print(L,"ops %.1f err %.4f"%base[L])
print("build",b, "cost est", (sum(v[0] for v in base.values())/8 + b/16384)/703)
# D profiles for leaf mx=60, needle rows
toks=rng.integers(0,64,size=(2000000,8)); y=net(toks); mx=toks.max(1)
idx=np.where(mx==60)[0]; c,n=np.unique(y[idx],return_counts=True)
order=np.argsort(-n)
print([(int(c[o]),round(n[o]/len(idx),4)) for o in order[:14]])
np.set_printoptions(precision=1, suppress=True, linewidth=250)
for j in [c[o] for o in order[1:8]]:
    D=M[j,:64]-M[60,:64]
    print(j, D[30:64])
