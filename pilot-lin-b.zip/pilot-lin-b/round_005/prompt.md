# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 5 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx slots. A slot holds a token, a whole number from 0 to d_vocab - 1, or it is empty,
which is written as the number d_vocab. An input has at least one token; its tokens fill the first
slots and the empty slots come after them.

The network has three weight matrices and no biases:

    embed     d_model x (d_vocab + 1)    its last column, the empty slot's, is all zeros
    hidden    d_model x d_model
    unembed   d_vocab x d_model

It adds up the columns of embed at the input's slots (an empty slot adds nothing), applies hidden,
applies unembed, and its output is the position of the highest of the d_vocab resulting numbers
(the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    h = lv1.take_sum(g.weight("embed"), g.tokens(), axis=1)
    logits = g.weight("unembed") @ (g.weight("hidden") @ h)
    return logits.argmax()
```

Sizes: n_ctx = 8, d_vocab = 64, d_model = 8, outputs: 64. One forward pass of the network costs 703 operations under the prices
below.

## The data set

An input is drawn like this. First a number of tokens is picked from 1 to 8, each equally likely. Then that many tokens are picked, each a whole number from 0 to 63 and equally likely. The tokens fill the first slots and the remaining slots are empty (64). The data set is every input that can be drawn this way, each counted as often as it is drawn: about 2.8 x 10^14 different inputs, far more with eight tokens than with one, yet every number of tokens makes up an eighth of the data set.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.8368 | 1.0000 | 0.99573 | 0.1093 | 0.99600 | 0.97000 |
| r1s2 | scored | 0.8636 | 1.0000 | 0.99500 | 0.0743 | 0.99630 | 0.97000 |
| r1s3 | scored | 0.8699 | 1.0000 | 0.99579 | 0.0768 | 0.99600 | 0.97000 |
| r1s4 | scored | 0.8731 | 1.0000 | 0.99597 | 0.0757 | 0.99600 | 0.97000 |

Notes of that round:

    ## What the network does
    It is a linear "noisy max": logits = U·H·Σ embed[:, tokens], and the output is approximately the largest token. Exact agreement with max is 94.5% overall (L=1: 81% because tokens 0–11 all map to output 10/11; L=3,4: ≥99.5%; L=8: 89%). Outputs 0–9 essentially never occur. When it fails on long inputs, the winner is typically well below the max (rows 30–57, whose unembed rows have the largest norms), and the failures are "needle" events driven by the particular sum of the smaller tokens, not by the second-largest token or by any low-rank structure: rank-7 truncation of the 64×64 logit matrix (even after centering) agrees with the argmax only 86% of the time, and no cheap linear risk score separates the failures. Failures on long inputs concentrate where the max is isolated far above the rest (gap ≥ 21: ~3% error vs 0.02% for gap 0). Sure of all this to the sampling precision used (1–3M random inputs per experiment).
    
    ## How you found it
    Both weights and outputs. Formed M = unembed·hidden·embed (64×65) and computed the network exactly in numpy on millions of drawn inputs; compared against max/min/first/last/sum/mean/median; studied per-length accuracy, per-max-value accuracy, SVD truncations, the joint distribution P(output | max token) by length, and the DP-optimal sets of candidate output rows to evaluate per max-token value (trading 9 ops per row against 10 forward passes per error).
    
    ## The best entry
    `hybrid_v5` (also saved: hybrid_v1…v4). Region: every input. Interpretation: nested `cond` on the number of tokens (tests token(k)==64).
    - L=1: table T1 = argmax of M columns (built from weights).
    - L=2,3,4: table TL_L[mx] = argmax_j (M[j,mx] + (L−1)·mean_{t≤mx} M[j,t]) (built from weights; mx = max of the first L tokens). Errors 0.4%, 0.08%, 0.1%.
    - L=5: plain max of the 5 tokens (1.05% error).
    - L≥6: mx = max(tokens with empties→0); a binary `cond` tree over mx with 20 leaves (mx<36, 36–39, 40–43, 44–47, then one leaf per value 48..63); each leaf computes the exact logits for a small fixed set of output rows (≤3–4 intervals, e.g. mx=60 → rows {22,34,44–49,52–60}) via `take_sum` on slices of the precomputed M, then argmax mapped back through slices of arange(64). ~0.5% error, ~90 ops.
    Saving comes from never computing the full 64-row matmul: cost 0.076 of a forward pass (build 0.007), fidelity 0.996, 326 nodes, 24 constant scalars (none tuned to the weights; only slice bounds encode this network's confusion pattern).
    
    ## Claims
    Claimed 0.996 on this network (measured 0.9958–0.9968 over four samples). Expected 0.97 on the second network: the tables for L≤4 and the mx-tree logits are recomputed from its weights, and max for L=5 should hold if it is also a noisy max, but the leaf row sets (which rows can win for a given max token) were tuned to this network's confusion statistics and may miss more often there.
    
    ## Next
    (1) Check robustness: widen leaf row sets by 1–2 rows where cheap, or derive them from the weights at build (rows whose unembed·hidden rows have large norm), to transfer better. (2) Separate row-set designs for L=6 vs 7–8 (worth ~+0.002) if nodes allow by merging more rare leaves. (3) A cheap second-level split on gap = mx − second max for the top leaves (errors are 10× higher when gap ≥ 21), if the second max can be had for <10 ops. (4) Exact pair table for L=2 instead of TL2 is break-even (build 0.045 vs penalty 0.043); not worth it unless build is amortized over more inputs.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.8941 | 1.0000 | 0.99829 | 0.0812 | 0.99800 | 0.97000 |
| r2s2 | scored | 0.8965 | 1.0000 | 0.99847 | 0.0809 | 0.99800 | 0.97500 |
| r2s3 | scored | 0.8961 | 1.0000 | 0.99847 | 0.0814 | 0.99800 | 0.97500 |
| r2s4 | scored | 0.8901 | 1.0000 | 0.99799 | 0.0817 | 0.99800 | 0.97500 |

Notes of that round:

    ## What the network does
    It is a linear "noisy max": logits = unembed·hidden·Σ embed[:, tokens], output ≈ the largest token. Embedding norms grow roughly geometrically with the token (0.11 at token 0 → 11.8 at 63, ratio ≈1.08/step), so the max token dominates the sum, but tokens within ~10–15 of the max still matter and unembed·hidden rows 11–35 have very large norms (40–75 vs 12–27 for rows 48–63), so they win as "needle" events. Agreement with plain max: L=1 81% (tokens 0–11 → outputs 10/11), L=2 97.3%, L=3 99.6%, L=4 99.8%, L=5 99.0%, L=6 96.6%, L=7 93.2%, L=8 89.1%. Rows 0–9 never win. Given the max token v, the winner distribution has a long diffuse tail (e.g. v=48: 36 wins 4–8%, then 42,46,41,47,44,13,50 each 0.1–2%); the tail is not predicted by the second-largest token, by a margin test on candidate logits (gains ≤0.003), or by a Gaussian z-score computed from the weights (4× worse than empirical sets). For L=2, the exact answer is always one of the two most frequent rows for that max token. M = unembed·hidden·embed has no clean low-rank/rotational structure. All sure to the precision of 1.5–2M random inputs per length.
    
    ## How you found it
    Both weights and outputs. Computed M in numpy, ran the exact network on millions of drawn inputs per length, measured winner distributions conditional on (length, max token), evaluated the round-1 entry per length with lv1.Evaluator (it spent ~115 ops on L≥6 and had 1.3% error at L=5), ran DPs: per-leaf optimal candidate-row sets (add a row if P(row wins | leaf)·10 > 9/703), a segmentation DP over contiguous max-token ranges with a per-leaf node penalty, an optimal alphabetic BST for the cond tree, and tested alternatives (two-stage margin-triggered leaves, pair tables with row cost 4 but build 0.02, per-length trees, dynamic max-row logit, weight-derived rankings) — all rejected as ≤0.003 or node-infeasible.
    
    ## The best entry
    `v2d` (398 nodes, 169 constants; also saved v2a/b/c/e). Region: every input. Interpretation: length tree on `token(k)==64` (tests t5 first so L≥6 pays 2 ops). L=1: table argmax of M columns (built from weights, rows 10–63 only, zero-padded). L=2: rows r1=TL2[max] (weights) and r2 = constant table of the second most frequent winner; compare M[r,t0]+M[r,t1] (exact, 19 ops). L=3,4: tables TL_L[mx]=argmax_j M[j,mx]+(L−1)·mean_{t≤mx}M[j,t]. L=5: cond tree over mx (17 leaves, reads only 5 tokens per row). L≥6: cond tree over mx = max(max(t0..t5), t6%64, t7%64) with 25 leaves (single values for mx≥45, ranges below). Each leaf: a packed base-64 integer constant decoded at build into its row list, `take` of those M rows (build), `take_sum` over the tokens, argmax, gather. Measured: cost 0.081 (build 0.0078), fidelity 0.9985 (errors: L5 0.3%, L6 0.1%, L7 0.3%, L8 0.55%, L3/4 ~0.1%), ~105 ops per L≥6 input, 48 per L=5. Saving: never computes more than ~10 of the 64 logits.
    
    ## Claims
    Claimed 0.998 on this network (measured 0.9980–0.9985 over three submissions and 50k held-out inputs). Expected 0.975 on the second network: L≤4 tables are recomputed from its weights, but the L=2 second-row table and all L≥5 candidate-row sets are constants tuned to this network's confusion tails (mx row and neighbours are always included, the network-specific "harmonic" rows will be wrong), so L≥5 error there is probably 1–4%.
    
    ## Next
    (1) Nodes (400) are the binding constraint: a tree for L∈{5,6} (6 reads/row) plus a tree for L∈{7,8} would gain ~0.004 but needs ~420 nodes; find a 4-node leaf encoding (e.g. avoid the gather by ordering rows) to afford it. (2) Splitting L=6 from L=7–8 inside the biggest leaves (59,60,58,56,62,63) gains ~0.0003 each for 8 nodes. (3) Pair table M[r,a]+M[r,b] halves row cost but build (4096 ops/row) makes it a wash unless rows are shared across many leaves. (4) The remaining loss is ~0.055 of L≥6 cost, ~0.025 error+CI, 0.008 build; a genuinely cheaper exact argmax for 8-token inputs would be the only big lever left.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.9087 | 1.0000 | 0.99908 | 0.0762 | 0.99850 | 0.97000 |
| r3s2 | scored | 0.9108 | 1.0000 | 0.99915 | 0.0749 | 0.99860 | 0.97000 |
| r3s3 | scored | 0.9106 | 1.0000 | 0.99902 | 0.0735 | 0.99870 | 0.97000 |
| r3s4 | scored | 0.9095 | 1.0000 | 0.99896 | 0.0739 | 0.99870 | 0.97000 |

Notes of that round:

    ## What the network does
    It is a linear "noisy max": logits = unembed·hidden·Σ embed[:, tokens], output ≈ the largest token (rows 0–9 never win; tokens 0–11 with L=1 map to 10/11). Embedding norms grow ~geometrically with the token, so the max token dominates, but rows 11–35 (huge unembed·hidden norms) and rows a few below the max win as "needle" events on long inputs (agreement with plain max: L=5 99%, L=6 96.6%, L=7 93.2%, L=8 89%). New this round: given the max token mx, the *sum of the tokens* (r = sum/(mx+1), i.e. how heavy the rest is) sharpens the winner distribution a lot — with low r the competitors are far rows (11,14,18,…), with high r they are a band of near rows mx−15..mx (often rows not present among the tokens, e.g. 56,52,62,49). Ideal (unlimited leaves) loss per L=8 input drops from 0.168 to 0.131 of a forward pass with 4 sum-buckets; the second max is only better at ≥8 buckets and costs 23 ops; a margin/early-exit test on the max row's logit gains ≤0.001 per length. All measured on 1–2M random inputs per length.
    
    ## How you found it
    Both weights and outputs. Computed M = unembed·hidden·embed in numpy, ran the exact network on 2M inputs per length, evaluated conditioning statistics (sum, Σ1.08^t, second max, max-row logit, SVD projections) by a per-leaf DP (include a row if P(row wins)·α·703 > row cost), evaluated the saved entries per length with lv1.Evaluator (ops and errors), and ran segmentation DPs (over max-token ranges, with optional 2-/3-way r-splits per segment, weighted optimal BST for the cond tree, node penalty λ swept to fill the 400-node limit). Verified `cond` may choose between build-time blocks of different shapes.
    
    ## The best entry
    `r3d` (reward 0.9108; `r3e`/`r3f` are equivalent variants, 0.9106/0.9095; `r3a` 0.9087). Region: every input. Interpretation: length dispatch on token(k)==64. L=1: table argmax of M columns; L=2: table row r1 plus, only when a constant second-row table is non-zero (max∈{8..13,15}), an exact 2-row compare (cond); L=3,4: tables argmax_j M[j,mx]+(L−1)·mean_{t≤mx}M[j,t]. L∈{5,6} and L∈{7,8}: one tree each over mx (max of the real tokens); each segment is either one block or `cond(r < q, blockA, blockB)` (some 3-way) with r = sum/(mx+1); each block is a slice (1 node) of one build-time tensor [M rows | row-id column] (rows packed 10 per base-64 integer constant, decoded at build; consecutive blocks share overlapping rows so build is 0.0083); a single shared tail per tree: take_sum over a per-length token vector (cond(t5==64, tokens[:5], tokens[:6]) etc., so a row costs L+1 ops), argmax, gather of the id column, cast. 395 nodes, 176 constants. Measured: cost 0.074 (build 0.0085), fidelity 0.9991; per length ops/err: L5 59/0.07%, L6 68/0.22%, L7 96/0.19%, L8 110/0.24%. Saving comes from 3 nodes per leaf (≈85 blocks instead of 42 leaves), per-length token vectors, and the sum-split that cuts rows per leaf.
    
    ## Claims
    Claimed 0.9986–0.9987 on this network (measured 0.9989–0.9992 on 16k verifier samples and 40k/length held-out). Expected 0.97 on the second network: L≤4 tables are recomputed from its weights, but all candidate-row sets, the L=2 second-row table and the r thresholds are constants tuned to this network's confusion tails; the max row and neighbours are included, so L≥5 errors there are probably 1–4%.
    
    ## Next
    Remaining loss ≈ 0.09: L7/8 cost 0.036, L5/6 cost 0.023, errors 0.011 (L6–8 ≈0.2% each), build 0.0083, L≤4 0.0083, CI slack 0.006. (1) Nodes are still binding: 4-way r-splits or NB=64 thresholds gave ≤0.0005; a cheaper leaf encoding (<3 nodes) would be the lever. (2) Dead ends confirmed: pair tables (build), dynamic rows via gathers (15–31 ops/row), early-exit on the max row's logit (≤0.001/length), per-length r thresholds, second-max bucketing (23 ops). (3) Possible small gains: skip the max-row's 64-column read in the block build by column-sliced blocks for low-mx segments (~0.001), L=3 two-candidate cond (~+0.0001), reorder length dispatch (no gain).

### Round 4

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r4s1 | scored | 0.9107 | 1.0000 | 0.99915 | 0.0750 | 0.99880 | 0.97000 |
| r4s2 | scored | 0.9132 | 1.0000 | 0.99921 | 0.0732 | 0.99890 | 0.97000 |
| r4s3 | scored | 0.9170 | 1.0000 | 0.99951 | 0.0733 | 0.99890 | 0.97000 |
| r4s4 | scored | 0.9180 | 1.0000 | 0.99951 | 0.0723 | 0.99890 | 0.97000 |

Notes of that round:

    ## What the network does
    It is a linear "noisy max": logits = unembed·hidden·Σ embed[:, tokens], output ≈ the largest token. New facts this round, all checked on 2–4M random inputs per length: (1) the L=2, L=3 and L=4 lookup tables of earlier rounds (argmax_j M[j,mx]+(L−1)·mean_{t≤mx}M[j,t]) are *identical* — TL[v] = max(v, 10) except TL[0] = 11 (= argmax of M's column 0) — so they are a 3-op formula, not a 30k-op build; (2) rows 6, 7, 9 do win on ~0.01% of L=8 inputs, so "rows 0–9 never win" is only approximate; (3) given the max token, needle rows come in "families" with near-identical difference profiles D_j(t)=M[j,t]−M[mx,t] (e.g. for mx=60: rows 52/53/49/47/45 want the rest in a 35–55 band, rows 34/22 want it below 40), but the within-leaf decision is genuinely 8-dimensional: PCA projections of h fail badly (rank 6 still errs 20%), a learned 1-D linear early-exit certifies "max wins" on only ≤4% of inputs at zero false positives, a margin trigger between family heads and the max row is leaf-dependent (fires on 95% of inputs at mx=58/56/50), and per-length (L7 vs L8) row sets are never chosen by the DP. A second cheap split statistic (sum of squares, Σ1.08^t, counts above/below a threshold, each 8 ops via take_sum of a 1-row table) helps only with unlimited leaves (L=8 ideal 0.0144→0.0126) and not at all for L=6, so the plain sum remains the right split statistic.
    
    ## How you found it
    Both weights and outputs. Computed M = unembed·hidden·embed; ran the exact network on 2–4M inputs per length; collected winner counts by (length, max token, r=sum/(mx+1) bucket of 0.05); evaluated the saved entries per length with lv1.Evaluator (ops and errors, 20k–15k inputs per length; the evaluator is lazy, so r costs only in leaves that use it); ran a segmentation DP over max-token ranges with 1/2/3/4-way r-splits on a *shared* threshold set per tree, a per-block row rule (include a row if 12.4·P(row wins) > P(block)·(L+1)/703, the 12.4 being 10× the Wilson-bound slope at fidelity 0.999), a weighted optimal BST for the cond tree, λ swept to fill exactly 400 nodes; tested the dead ends above with oracle experiments; enumerated L=2 (all 4096 pairs) and L=3 (all 262k triples) exactly to choose second-candidate tables.
    
    ## The best entry
    `r4d` (reward 0.9180 submitted; local estimate ≈0.913 on 120k held-out inputs; `r4c` 0.9170 and `r4b` 0.9132 are near-identical variants). Region: every input. Interpretation: length dispatch on token(k)==64. L=1: table argmax of M's columns (built). L=2 and L=3: first candidate TL[max] = where(v==0, T1[0], max(v, min T1)) (built from weights), second candidate from a constant table (R2 and R3 packed into one 64-number constant, decoded at build; R2 non-zero for max∈{8..13,15}, R3 for 21 max values), exact compare of the two rows' logits only when the second candidate is non-zero (cond). L=4: TL[max] alone. L∈{5,6} and L∈{7,8}: one cond tree each over mx (24/25 segments); a segment is one block or a 2/3/4-way split on r = sum/(mx+1) against 5 shared thresholds per tree ([3.1,3.3,3.4,3.6,3.8] and [3.6,3.9,4.0,4.1,4.6]) so a split costs only cond+slice nodes; each block is a slice of one build-time tensor [M rows | id column] (458 row slots for 98 blocks, rows packed 10 per base-64 integer constant, consecutive blocks share windows); a shared tail per tree: take_sum over a per-length token vector, argmax, gather of the id, cast. 400 nodes, 161 constants. Measured: cost 0.0723 (build 0.0063 — down from 0.0085 by the TL formula), fidelity 0.9992–0.9995; per length ops/err: L1 7/0, L2 11.3/0, L3 12.9/0.03%, L4 10/0.03%, L5 59.6/0.04%, L6 70.9/0.15%, L7 94/0.15%, L8 110/0.25%. The saving comes from never computing more than ~9 of the 64 logits, 3 nodes per block, shared thresholds, and the cheap tables.
    
    ## Claims
    Claimed 0.9989 on this network (measured 0.9992–0.9995 on four 16k verifier samples, 0.99916 on 120k held-out). Expected 0.97 on the second network: T1, TL and M are recomputed from its weights, but the row sets, segment boundaries, r thresholds and R2/R3 tables are constants tuned to this network's confusion tails (the max row and neighbours are always included), so L≥5 error there is probably 1–4%.
    
    ## Next
    The candidate-row family is at its ceiling: the DP's own loss (≈0.055 for L5–8) matches what the entry achieves, and per-length blocks, 2-D split statistics, projections, early exits and margin-triggered second stages were all measured as ≤0.001 or node-infeasible. Remaining loss ≈0.085: L7/8 ops 0.036, L5/6 ops 0.023, errors+CI ≈0.016, build 0.006, L1–4 0.0066. Only micro-gains are left: (1) a smarter block-sequence packer (458 slots → ~420, +0.0003); (2) the 2-row compare for L=4 (+0.0002, needs ~13 nodes); (3) restricting T1's argmax to columns <16 (+0.0003, but hard-codes identity above 16 and hurts transfer). Anything bigger needs a genuinely cheaper exact argmax for 7–8-token inputs, which nothing tried in four rounds has found.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.9180) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
