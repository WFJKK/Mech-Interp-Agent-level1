
import json, numpy as np, inspect
e = entries['best']
nodes = e['nodes']
N = {i:n for i,n in enumerate(nodes)}
# weights & M
W = weights
M = W['unembed'] @ (W['hidden'] @ W['embed'][:, :64])
# decode slots from const 70
packed = np.array(N[70]['value'], dtype=object)
slots=[]
for p in packed:
    p=int(p)
    for k in range(10):
        slots.append(p % 64); p//=64
slots = np.array(slots[:458])
print('slots', slots[:40])
# walk tree from root 240 and the L5/6 root; find roots: predict node 399
def walk(i, cons, leaves):
    n = N[i]
    if n['op']=='cond':
        c = N[n['args'][0]]
        a, b = n['args'][1], n['args'][2]
        if c['op']=='lt':
            x, t = c['args']; tv = N[t]['value']
            if x==86 or x==None: pass
            key = 'mx' if N[x]['op']=='maximum' else ('r' if N[x]['op']=='div' else ('?%d'%x))
            walk(a, cons+[(key,'<',tv)], leaves); walk(b, cons+[(key,'>=',tv)], leaves)
        elif c['op']=='eq':
            x, t = c['args']
            walk(a, cons+[('tok%d'%x,'==',N[t]['value'])], leaves); walk(b, cons+[('tok%d'%x,'!=',N[t]['value'])], leaves)
        else:
            print('cond on', c['op'], i)
    elif n['op']=='slice' and n['args'][0]==82:
        leaves.append((cons, n['index'][0]['start'], n['index'][0]['stop'], i))
    else:
        leaves.append((cons, None, None, i, n['op']))
leaves=[]
walk(399, [], leaves)
print(len(leaves))
for l in leaves[:80]:
    print(l)
print(inspect.signature(lv1.Evaluator), lv1.Evaluator.__doc__)
