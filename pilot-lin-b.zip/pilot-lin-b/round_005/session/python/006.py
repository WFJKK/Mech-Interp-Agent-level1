
import json, numpy as np, time
e = entries['best']; nodes = e['nodes']; N = {i:n for i,n in enumerate(nodes)}
W = weights
M = W['unembed'] @ (W['hidden'] @ W['embed'][:, :64])
packed = N[70]['value']; slots=[]
for p in packed:
    p=int(p)
    for k in range(10): slots.append(p % 64); p//=64
slots=np.array(slots[:458])
def walk(i, cons, leaves):
    n = N[i]
    if n['op']=='cond':
        c = N[n['args'][0]]; a, b = n['args'][1], n['args'][2]
        x, t = c['args']; tv = N[t]['value']
        key = 'mx' if N[x]['op']=='maximum' else ('r' if N[x]['op']=='div' else ('?%d'%x))
        walk(a, cons+[(key,'<',tv)], leaves); walk(b, cons+[(key,'>=',tv)], leaves)
    else:
        leaves.append((cons, n['index'][0]['start'], n['index'][0]['stop'], i))
trees={}
for root,name in [(240,'L56'),(391,'L78')]:
    lv=[]; walk(root,[],lv); trees[name]=lv
    print(name, len(lv), 'leaves')
def leaf_mask(cons, mx, r):
    m = np.ones(len(mx), bool)
    for k,op,v in cons:
        x = mx if k=='mx' else r
        m &= (x < v) if op=='<' else (x >= v)
    return m
rng = np.random.default_rng(1)
NS = 3_000_000
stats = {}  # (tree, leafidx, L) -> (count, winner counts)
t0=time.time()
for L in [5,6,7,8]:
    name = 'L56' if L<=6 else 'L78'
    lv = trees[name]
    wins = np.zeros((len(lv),64), np.int64); cnt=np.zeros(len(lv), np.int64)
    for ch in range(6):
        toks = rng.integers(0,64,(NS//6, L))
        cts = np.zeros((toks.shape[0],64), np.float32)
        for j in range(L): np.add.at(cts, (np.arange(toks.shape[0]), toks[:,j]), 1)
        logits = cts @ M.T.astype(np.float32)
        # exact in float64 for safety
        logits = cts.astype(np.float64) @ M.T
        win = logits.argmax(1)
        mx = toks.max(1); r = toks.sum(1)/(mx+1)
        for li,(cons,s0,s1,i) in enumerate(lv):
            m = leaf_mask(cons, mx, r)
            cnt[li]+=m.sum(); wins[li]+=np.bincount(win[m], minlength=64)
    stats[L]=(cnt,wins)
print('sim time', time.time()-t0)
s_w = 1.46
tot_cur=0; tot_opt=0
for L in [5,6,7,8]:
    name = 'L56' if L<=6 else 'L78'; lv=trees[name]; cnt,wins=stats[L]
    cur=0; opt=0; errc=0; opsc=0
    for li,(cons,s0,s1,i) in enumerate(lv):
        rows = slots[s0:s1]; P = cnt[li]/NS
        if cnt[li]==0: continue
        p = wins[li]/cnt[li]
        err = 1 - p[rows].sum()
        ops = len(rows)*(L+1) - 1
        cur += P*(ops/703 + 10*s_w*err); errc += P*err; opsc += P*ops
        # optimal
        keep = p > (L+1)/703/(10*s_w)
        err_o = 1-p[keep].sum(); ops_o = keep.sum()*(L+1)-1
        opt += P*(ops_o/703 + 10*s_w*err_o)
    print(L, 'cur loss %.5f opt loss %.5f  err %.5f ops %.1f'%(cur,opt,errc,opsc))
    tot_cur+=cur/8; tot_opt+=opt/8
print('total cur %.5f opt %.5f'%(tot_cur,tot_opt))
