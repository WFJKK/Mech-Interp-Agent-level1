
import json, numpy as np
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
for k,v in e.items():
    if isinstance(v, (list, dict)):
        print(k, type(v), len(v))
    else:
        print(k, v)
nodes = e.get('nodes') or e.get('graph') or None
import itertools
if isinstance(e, dict):
    for k,v in e.items():
        if isinstance(v, list):
            print(k, 'first 12:', json.dumps(v[:12])[:1500])
print([a for a in dir(lv1) if not a.startswith('_')])
import inspect
print(inspect.signature(lv1.Graph.load))
