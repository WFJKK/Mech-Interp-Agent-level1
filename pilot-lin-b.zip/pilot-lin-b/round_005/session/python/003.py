
import json
e = entries['best']
out=[]
for n in e['nodes']:
    d = {k:v for k,v in n.items() if k!='i'}
    out.append(f"{n.get('i','?')}:{json.dumps(d,separators=(',',':'))}")
s="\n".join(out)
print(s[:12000])
