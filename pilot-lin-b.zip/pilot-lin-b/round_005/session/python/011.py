
import json, numpy as np, time, copy
from math import exp, lgamma, log
e = entries['best']; nodes = e['nodes']; N = {i:n for i,n in enumerate(nodes)}
W = weights
M = W['unembed'] @ (W['hidden'] @ W['embed'][:, :64])
packed = N[70]['value']; slots=[]
for p in packed:
    p=int(p)
    for k in range(10): slots.append(p % 64); p//=64
slots=np.array(slots[:458])
def walk(i, cons, leaves):
    n = N[i]
    if n['op']=='cond':
        c = N[n['args'][0]]; a, b = n['args'][1], n['args'][2]
        x, t = c['args']; tv = N[t]['value']
        key = 'mx' if N[x]['op']=='maximum' else 'r'
        walk(a, cons+[(key,'<',tv)], leaves); walk(b, cons+[(key,'>=',tv)], leaves)
    else:
        leaves.append((cons, n['index'][0]['start'], n['index'][0]['stop'], i))
trees={}
for root,name in [(240,'L56'),(391,'L78')]:
    lv=[]; walk(root,[],lv); trees[name]=lv
def leaf_mask(cons, mx, r):
    m = np.ones(len(mx), bool)
    for k,op,v in cons:
        x = mx if k=='mx' else r
        m &= (x < v) if op=='<' else (x >= v)
    return m
rng = np.random.default_rng(13)
NS = 12_000_000; CH=24
stats={}
for L in [5,6,7,8]:
    name = 'L56' if L<=6 else 'L78'; lv = trees[name]
    wins = np.zeros((len(lv),64), np.int64); cnt=np.zeros(len(lv), np.int64)
    for ch in range(CH):
        toks = rng.integers(0,64,(NS//CH, L))
        cts = np.zeros((toks.shape[0],64), np.float64)
        for j in range(L): np.add.at(cts, (np.arange(toks.shape[0]), toks[:,j]), 1)
        win = (cts @ M.T).argmax(1)
        mx = toks.max(1); r = toks.sum(1)/(mx+1)
        for li,(cons,s0,s1,i) in enumerate(lv):
            m = leaf_mask(cons, mx, r)
            cnt[li]+=m.sum(); wins[li]+=np.bincount(win[m], minlength=64)
    stats[L]=(cnt,wins)
def design(s_w):
    newrows={}; err=0; ops=0
    for name,Ls in [('L56',[5,6]),('L78',[7,8])]:
        lv=trees[name]
        for li,(cons,s0,s1,i) in enumerate(lv):
            c = sum(stats[L][0][li] for L in Ls)
            if c==0: newrows[(name,li)] = [int(x) for x in slots[s0:s1]]; continue
            ben = sum(10*s_w*stats[L][1][li]/NS for L in Ls)
            cst = sum(stats[L][0][li]/NS*(L+1)/703 for L in Ls)
            keep = np.where(ben > cst)[0]
            if len(keep)==0: keep = np.array([slots[s0:s1][0]])
            newrows[(name,li)] = [int(x) for x in keep]
            for L in Ls:
                P = stats[L][0][li]/NS
                err += P*(1-stats[L][1][li][keep].sum()/max(stats[L][0][li],1))/8
                ops += P*(len(keep)*(L+1)-1)/8
    return newrows, err, ops
def pack_rows(newrows):
    keys = list(newrows.keys()); n=len(keys); sets=[set(newrows[k]) for k in keys]
    ov = np.array([[len(sets[i]&sets[j]) if i!=j else 0 for j in range(n)] for i in range(n)])
    def pack(order):
        seq=[]; win={}
        for idx,ki in enumerate(order):
            B = sets[ki]; nxt = sets[order[idx+1]] if idx+1<len(order) else set()
            nxt2 = sets[order[idx+2]] if idx+2<len(order) else set()
            k=0; seen=set()
            while k<len(seq) and seq[-1-k] in B and seq[-1-k] not in seen:
                seen.add(seq[-1-k]); k+=1
            rest = sorted([x for x in B if x not in seen], key=lambda x: (x in nxt, x in nxt2, x))
            start=len(seq)-k; seq+=rest; win[keys[ki]]=(start,len(seq))
        return seq, win
    rng2=np.random.default_rng(0); best=(10**9,None,None)
    for trial in range(40):
        start=int(rng2.integers(n)); order=[start]; rem=set(range(n))-{start}
        while rem:
            last=order[-1]; cand=max(rem, key=lambda j:(ov[last,j], rng2.random())); order.append(cand); rem.remove(cand)
        improved=True
        while improved:
            improved=False
            for i in range(n-1):
                for j in range(i+2,n):
                    a,b=order[i],order[i+1]; c=order[j]; d=order[j+1] if j+1<n else None
                    delta = ov[a,c] + (ov[b,d] if d is not None else 0) - ov[a,b] - (ov[c,d] if d is not None else 0)
                    if delta>0: order[i+1:j+1]=order[i+1:j+1][::-1]; improved=True
        seq,win=pack(order)
        if len(seq)<best[0]: best=(len(seq),seq,win)
    return best[1], best[2]
def write(newrows, name):
    seq, windows = pack_rows(newrows)
    e2 = copy.deepcopy(e); pk=[]
    for a in range(0,len(seq),10):
        v=0
        for k,x in enumerate(seq[a:a+10]): v += int(x)*(64**k)
        pk.append(v)
    e2['nodes'][70]['value']=pk; e2['nodes'][78]['index'][0]['stop']=len(seq)
    for tn in trees:
        for li,(cons,s0,s1,i) in enumerate(trees[tn]):
            st,en = windows[(tn,li)]; e2['nodes'][i]['index'][0]['start']=st; e2['nodes'][i]['index'][0]['stop']=en
    save_entry(name, e2); return e2, len(seq)
# other fixed parts: base error from L3/L4 ~0.0003 each, base ops (everything except rows) from measure: estimate via best: r=0.06640*703=46.7 ops avg; rows ops of current design:
cur_rows, cur_err, cur_ops = design(1.35)
base_ops = 0.0664*703 - cur_ops   # non-row ops per input (avg over lengths)
print('cur err %.5f cur row ops %.2f base ops %.2f'%(cur_err, cur_ops, base_ops))
n=16384
def poisson_pmf(lam, kmax=80):
    return np.array([exp(-lam + k*log(lam) - lgamma(k+1)) for k in range(kmax)])
def eval_cfg(err, ops, build_share=0.0056):
    lam = (err + 0.00075/8*2)*n   # add L3/L4 errors
    pm = poisson_pmf(lam)
    rew = np.array([1 - (ops+base_ops)/703 - build_share - 10*(1-lv1.wilson_lower(n-k, n)) for k in range(len(pm))])
    return lam, (pm*rew).sum(), (pm*(rew>0.9182)).sum(), np.sqrt((pm*rew**2).sum()-((pm*rew).sum())**2)
for s_w in [1.35, 1.1, 0.9, 0.7, 0.55, 0.4]:
    nr, err, ops = design(s_w)
    lam, Er, Pwin, sd = eval_cfg(err, ops)
    print('s_w %.2f err %.5f rowops %.1f  lam %.1f  E[reward] %.4f  P(>0.9182) %.3f sd %.4f'%(s_w, err, ops, lam, Er, Pwin, sd))
for s_w,name in [(0.9,'r5c'),(0.6,'r5d')]:
    nr,err,ops = design(s_w); e2, ns = write(nr, name)
    m=measure(e2); print(name, 'slots', ns, {k:m[k] for k in ['n_agree','cost','b','reward']})
