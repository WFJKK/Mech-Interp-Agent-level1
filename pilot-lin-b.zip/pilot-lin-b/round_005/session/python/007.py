
import json, numpy as np, time, copy
e = entries['best']; nodes = e['nodes']; N = {i:n for i,n in enumerate(nodes)}
W = weights
M = W['unembed'] @ (W['hidden'] @ W['embed'][:, :64])
packed = N[70]['value']; slots=[]
for p in packed:
    p=int(p)
    for k in range(10): slots.append(p % 64); p//=64
slots=np.array(slots[:458])
def walk(i, cons, leaves):
    n = N[i]
    if n['op']=='cond':
        c = N[n['args'][0]]; a, b = n['args'][1], n['args'][2]
        x, t = c['args']; tv = N[t]['value']
        key = 'mx' if N[x]['op']=='maximum' else 'r'
        walk(a, cons+[(key,'<',tv)], leaves); walk(b, cons+[(key,'>=',tv)], leaves)
    else:
        leaves.append((cons, n['index'][0]['start'], n['index'][0]['stop'], i))
trees={}
for root,name in [(240,'L56'),(391,'L78')]:
    lv=[]; walk(root,[],lv); trees[name]=lv
def leaf_mask(cons, mx, r):
    m = np.ones(len(mx), bool)
    for k,op,v in cons:
        x = mx if k=='mx' else r
        m &= (x < v) if op=='<' else (x >= v)
    return m
rng = np.random.default_rng(7)
NS = 12_000_000; CH=24
stats={}
t0=time.time()
for L in [5,6,7,8]:
    name = 'L56' if L<=6 else 'L78'; lv = trees[name]
    wins = np.zeros((len(lv),64), np.int64); cnt=np.zeros(len(lv), np.int64)
    for ch in range(CH):
        toks = rng.integers(0,64,(NS//CH, L))
        cts = np.zeros((toks.shape[0],64), np.float64)
        for j in range(L): np.add.at(cts, (np.arange(toks.shape[0]), toks[:,j]), 1)
        win = (cts @ M.T).argmax(1)
        mx = toks.max(1); r = toks.sum(1)/(mx+1)
        for li,(cons,s0,s1,i) in enumerate(lv):
            m = leaf_mask(cons, mx, r)
            cnt[li]+=m.sum(); wins[li]+=np.bincount(win[m], minlength=64)
    stats[L]=(cnt,wins)
print('sim', time.time()-t0)
s_w=1.46
# per leaf optimal rows: leaf shared by two lengths (5&6 or 7&8): combine losses
newrows={}
tot_cur=tot_opt=0
for name,Ls in [('L56',[5,6]),('L78',[7,8])]:
    lv=trees[name]
    for li,(cons,s0,s1,i) in enumerate(lv):
        # combined: loss = sum_L P_L(leaf)/8 *[ k*(L+1)/703 + 10 s err_L ]
        c = sum(stats[L][0][li] for L in Ls); 
        if c==0: newrows[(name,li)] = list(slots[s0:s1]); continue
        # benefit of row j: sum_L 10 s P_L(leaf) p_L(j) ; cost: sum_L P_L(leaf) (L+1)/703
        ben = sum(10*s_w*stats[L][1][li]/NS for L in Ls)
        cst = sum(stats[L][0][li]/NS*(L+1)/703 for L in Ls)
        keep = np.where(ben > cst)[0]
        mxs = [v for k,op,v in cons if k=='mx' and op=='>=']
        if len(keep)==0: keep = np.array([slots[s0:s1][0]])
        newrows[(name,li)] = list(keep)
        cur = slots[s0:s1]
        lc = sum(stats[L][0][li]/NS*((len(cur)*(L+1)-1)/703 + 10*s_w*(1-stats[L][1][li][cur].sum()/max(stats[L][0][li],1))) for L in Ls)
        lo = sum(stats[L][0][li]/NS*((len(keep)*(L+1)-1)/703 + 10*s_w*(1-stats[L][1][li][keep].sum()/max(stats[L][0][li],1))) for L in Ls)
        tot_cur+=lc/8; tot_opt+=lo/8
        if set(keep)!=set(cur): print(name, li, cons[-2:], 'cur', sorted(cur), 'new', sorted(keep), '%.5f->%.5f'%(lc/8,lo/8))
print('total cur %.5f opt %.5f'%(tot_cur,tot_opt))
# greedy packer: order = tree order, L56 then L78
order = [('L56',li) for li in range(len(trees['L56']))] + [('L78',li) for li in range(len(trees['L78']))]
seq=[]; windows={}
for idx,key in enumerate(order):
    B = set(int(x) for x in newrows[key])
    nxt = set(int(x) for x in newrows[order[idx+1]]) if idx+1<len(order) else set()
    # trailing run of seq within B (distinct)
    k=0; seen=set()
    while k<len(seq) and seq[-1-k] in B and seq[-1-k] not in seen:
        seen.add(seq[-1-k]); k+=1
    rest = [x for x in B if x not in seen]
    rest = sorted(rest, key=lambda x: (x in nxt, x))
    start = len(seq)-k
    seq += rest
    windows[key]=(start, len(seq))
    assert set(seq[start:len(seq)])==B and len(seq[start:len(seq)])==len(B)
print('slots', len(seq))
# write new entry
e2 = copy.deepcopy(e)
pk=[]
for a in range(0,len(seq),10):
    v=0
    for k,x in enumerate(seq[a:a+10]): v += int(x)*(64**k)
    pk.append(v)
e2['nodes'][70]['value']=pk
e2['nodes'][78]['index'][0]['stop']=len(seq)
for name in trees:
    for li,(cons,s0,s1,i) in enumerate(trees[name]):
        st,en = windows[(name,li)]
        e2['nodes'][i]['index'][0]['start']=st; e2['nodes'][i]['index'][0]['stop']=en
save_entry('r5a', e2)
print(measure(e2))
print(measure(e))
