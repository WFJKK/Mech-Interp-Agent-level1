
import numpy as np
for nm in ['r5b','best']:
    rs=[]
    for k in range(3):
        m=measure(entries[nm]); rs.append((m['n_agree'], round(m['cost'],5), round(m['reward'],5)))
    print(nm, rs)
