
import inspect
print(inspect.signature(lv1.wilson_lower)); print(lv1.wilson_lower.__doc__)
try:
    for k in [0,4,6,8,10,12]:
        print(k, lv1.wilson_lower(16384-k, 16384))
except Exception as ex:
    print('err', ex)
# sizes of original and new blocks
tot_orig = sum(s1-s0 for name in trees for (cons,s0,s1,i) in trees[name])
tot_new = sum(len(newrows[(name,li)]) for name in trees for li in range(len(trees[name])))
print('orig rows total', tot_orig, 'new rows total', tot_new, 'orig slots 458, new slots', len(seq))
