
import json, numpy as np
e = entries['best']; nodes = e['nodes']; N = {i:n for i,n in enumerate(nodes)}
# find the L7/8 tree root: walk back from 397
def chain(i, depth=8):
    out=[]
    for _ in range(depth):
        n=N[i]; out.append((i,n['op'],n.get('args'))); 
        if not n.get('args'): break
        i=n['args'][0]
    return out
print(chain(397))
print([ (i,N[i]) for i in range(383,399)])
