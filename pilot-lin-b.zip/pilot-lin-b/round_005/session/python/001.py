
import json, numpy as np
print({k:(v if k!='data' else '...') for k,v in info.items()})
print(list(entries.keys()))
e = entries['best']
s = json.dumps(e)
print(len(s))
print(measure(e))
g_, pred, rule = lv1.Graph.load(e, weights, info['n_ctx'])
print(type(g_), [a for a in dir(g_) if not a.startswith('_')][:50])
print([a for a in dir(lv1) if not a.startswith('_')])
