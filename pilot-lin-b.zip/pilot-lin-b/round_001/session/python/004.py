
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H @ E
W = U @ H
rng = np.random.default_rng(1)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
def net(X):
    h = E[:, X].sum(2).T  # n x 8
    return np.argmax(h @ W.T, axis=1)
X, L = sample(2000000)
Y = net(X)
Xm = np.where(X==64, -1, X)
S = np.sort(Xm, axis=1)[:, ::-1]
mx = S[:,0]; second = S[:,1]
ok = (Y==mx)
gap = mx - np.maximum(second, -1)
print("SVD of M tokens:", np.linalg.svd(M[:, :64], compute_uv=False).round(2))
print("norms of embed cols:", np.linalg.norm(E[:, :64], axis=0).round(2))
print("norms of W rows:", np.linalg.norm(W, axis=1).round(2))
# accuracy by gap (second max gap), only for L>=2
for g in range(0, 20):
    sel = (gap==g) & (L>=2)
    print(g, sel.sum(), ok[sel].mean().round(4), end=' | ')
print()
# by L
for l in range(1,9):
    sel = L==l
    print(l, ok[sel].mean().round(4), end=' | ')
print()
# accuracy by mx for gap>=3
for m in range(0,64):
    sel = (mx==m) & (gap>=3) & (L>=2)
    if sel.sum(): print(m, ok[sel].mean().round(4), end=' | ')
