
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E  # 64x65
rng = np.random.default_rng(3)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
X, L = sample(500000)
Y = M[:, X].sum(2).argmax(0)
A, s, Bt = np.linalg.svd(M[:, :64], full_matrices=False)
for r in range(1,9):
    Mr = (A[:, :r]*s[:r]) @ Bt[:r]
    Mr = np.concatenate([Mr, np.zeros((64,1))], axis=1)
    Yr = Mr[:, X].sum(2).argmax(0)
    ok = Yr==Y
    print(r, ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
