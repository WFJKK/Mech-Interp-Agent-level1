
import numpy as np
np.set_printoptions(linewidth=250, precision=0, suppress=True)
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
print("M[j,t] rows j=8..63 step 4, cols t=0..63 step 4:")
print(M[8::4, :64:4])
rng = np.random.default_rng(6)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
X, L = sample(1000000)
logits = M[:, X].sum(2).T
Y = logits.argmax(1)
Xm = np.where(X==64, -1, X); mx = Xm.max(1)
wrong = (Y!=mx) & (L>=5)
print("wrong rate L>=5:", wrong.sum()/ (L>=5).sum())
print("Y when wrong, L>=5 (counts by Y):", np.bincount(Y[wrong], minlength=64))
print("mx when wrong:", np.bincount(mx[wrong], minlength=64))
# logit of mx row vs winner: margin distribution for wrong ones
lm = logits[np.arange(len(Y)), mx]
lw = logits[np.arange(len(Y)), Y]
print("deficit percentiles when wrong:", np.percentile((lw-lm)[wrong], [10,50,90,99]).round(1))
srt = np.sort(logits,1)
print("margin when right (L>=5) percentiles:", np.percentile((srt[:,-1]-srt[:,-2])[(~wrong)&(L>=5)], [1,5,10,25,50]).round(1))
