
import numpy as np
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_
rng = np.random.default_rng(14)
FP=703.0
def joint(Ls, n=2000000):
    L = rng.choice(Ls, n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64
    out = np.empty(n, int)
    for i in range(0,n,250000):
        out[i:i+250000] = (W_ @ E_[:, X[i:i+250000]].sum(2)).argmax(0)
    mx = np.where(X==64, -1, X).max(1)
    J = np.zeros((64,64)); np.add.at(J, (mx, out), 1); return J/n
def best_contig(py, pm):
    cs = np.concatenate([[0], np.cumsum(py)]); best=(1e18,None)
    for lo in range(64):
        for hi in range(lo,64):
            c = pm*9*(hi-lo+1) + 10*FP*(pm-(cs[hi+1]-cs[lo]))
            if c<best[0]: best=(c,(lo,hi))
    return best
def best_subset(py, pm):
    keep = py*10*FP > pm*9
    if keep.sum()==0: keep[py.argmax()] = True
    return pm*9*keep.sum() + 10*FP*(pm-py[keep].sum()), keep
def design(J):
    tot_c=0; tot_s=0; nrows_s=0; wins={}
    for m in range(36,64):
        c,(lo,hi) = best_contig(J[m], J[m].sum()); s,keep = best_subset(J[m], J[m].sum())
        tot_c+=c; tot_s+=s; nrows_s+=keep.sum(); wins[m]=(lo,hi)
    pm=J[:36].sum(); py=J[:36].sum(0)
    c,(lo,hi)=best_contig(py,pm); s,keep=best_subset(py,pm); tot_c+=c; tot_s+=s; nrows_s+=keep.sum(); wins['low']=(lo,hi)
    return tot_c, tot_s, nrows_s, wins
Jall = joint([6,7,8]); J6 = joint([6]); J78 = joint([7,8])
cA, sA, nA, wA = design(Jall)
c6, s6, n6, w6 = design(J6); c78, s78, n78, w78 = design(J78)
print("joint design: contiguous", round(cA,1), "subset", round(sA,1), "rows in subset design", nA)
print("per-L designs weighted: contiguous", round((c6+2*c78)/3,1), "subset", round((s6+2*s78)/3,1))
# also: cost of joint windows applied to L=6 only and to L=7,8 only
def apply_cost(J, wins):
    tot=0
    for m in range(36,64):
        lo,hi=wins[m]; pm=J[m].sum(); tot+= pm*9*(hi-lo+1) + 10*FP*(pm-J[m,lo:hi+1].sum())
    lo,hi=wins['low']; pm=J[:36].sum(); tot+= pm*9*(hi-lo+1)+10*FP*(pm-J[:36,lo:hi+1].sum())
    return tot
print("joint windows on L6:", round(apply_cost(J6,wA),1), "own:", round(c6,1), "| on L78:", round(apply_cost(J78,wA),1), "own:", round(c78,1))
print("w6", w6); print("w78", w78)
