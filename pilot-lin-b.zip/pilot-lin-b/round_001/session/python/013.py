
import numpy as np, json
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
rng = np.random.default_rng(8)
def sample_L(n, Ls):
    L = rng.choice(Ls, n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
def net(X):
    out = np.empty(len(X), dtype=int)
    for i in range(0, len(X), 200000):
        h = E[:, X[i:i+200000]].sum(2)
        out[i:i+200000] = (W @ h).argmax(0)
    return out
X, L = sample_L(3000000, [6,7,8])
Y = net(X)
Xm = np.where(X==64, -1, X); mx = Xm.max(1)
J = np.zeros((64,64)); np.add.at(J, (mx, Y), 1); J /= len(Y)
FP=703.0
def best_rows(u, v, extra=0):
    pm = J[u:v+1].sum(); py = J[u:v+1].sum(0); cs = np.concatenate([[0], np.cumsum(py)])
    best=None
    for lo in range(0,64):
        for hi in range(lo,64):
            inside = cs[hi+1]-cs[lo]
            c = pm*(9*(hi-lo+1)) + 10*FP*(pm-inside)
            if best is None or c < best[0]: best=(c,(lo,hi))
    return best
windows={}
tot=0
for m in range(36,64):
    c,(lo,hi) = best_rows(m,m); windows[m]=(lo,hi); tot+=c
c,(lo,hi) = best_rows(0,35); windows['low']=(lo,hi); tot+=c
print("expected ops+penalty per input:", tot, tot/FP)
print(windows)
# error estimate
err=0
for m in range(36,64):
    lo,hi=windows[m]; err += J[m].sum()-J[m,lo:hi+1].sum()
lo,hi=windows['low']; err += J[:36].sum()-J[:36,lo:hi+1].sum()
print("expected error rate on L=6..8:", err)
json.dump({str(k):v for k,v in windows.items()}, open('tmp/windows.json','w'))
