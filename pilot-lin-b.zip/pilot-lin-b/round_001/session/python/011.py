
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
rng = np.random.default_rng(7)
def sample_L(n, Ls):
    L = rng.choice(Ls, n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
# joint counts of (mx, Y) for L in {7,8}
X, L = sample_L(3000000, [7,8])
Y = M[:, X].sum(2).argmax(0)
Xm = np.where(X==64, -1, X); mx = Xm.max(1)
J = np.zeros((64,64))
np.add.at(J, (mx, Y), 1)
J /= len(Y)
FP = 703.0
def best_rows(u, v):
    # interval of mx [u,v]; choose rows [lo,hi]
    pm = J[u:v+1].sum()
    if pm == 0: return 0, (0,63)
    py = J[u:v+1].sum(0)  # P(mx in interval, Y=j)
    cs = np.concatenate([[0], np.cumsum(py)])
    best = None
    for lo in range(0,64):
        for hi in range(lo,64):
            inside = cs[hi+1]-cs[lo]
            c = pm*(9*(hi-lo+1)) + 10*FP*(pm-inside)
            if best is None or c < best[0]: best = (c, (lo,hi))
    return best
# DP over partitions of mx into intervals, each interval cost + 2 ops branching per interval (prob-weighted roughly)
INF=1e18
cost = [INF]*65; cost[0]=0; back=[None]*65
cache={}
for v in range(1,65):
    for u in range(0,v):
        if (u,v-1) not in cache: cache[(u,v-1)] = best_rows(u, v-1)
        c, rows = cache[(u,v-1)]
        tot = cost[u] + c + 2.5*J[u:v].sum()
        if tot < cost[v]: cost[v]=tot; back[v]=(u, rows)
# recover
parts=[]; v=64
while v>0:
    u, rows = back[v]; parts.append((u, v-1, rows)); v=u
parts=parts[::-1]
print("DP total expected ops per input (L=7,8):", cost[64], "-> cost share", cost[64]/FP)
for p in parts: print("mx in", p[0], "-", p[1], "rows", p[2], "P(mx)", J[p[0]:p[1]+1].sum().round(4))
# simple alternative: 3 blocks
for parts2 in [[(0,47,(10,63)),(48,55,(28,59)),(56,63,(30,63))]]:
    tot=0; err=0
    for u,v,(lo,hi) in parts2:
        pm=J[u:v+1].sum(); py=J[u:v+1].sum(0); inside=py[lo:hi+1].sum()
        tot+=pm*9*(hi-lo+1); err+=pm-inside
    print("3-block: ops", tot, "err", err, "cost share", (tot+64+2.5)/FP, "penalty", 10*err)
