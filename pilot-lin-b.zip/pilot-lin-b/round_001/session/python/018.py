
import numpy as np
windows = {36: (23, 37), 37: (26, 37), 38: (34, 40), 39: (19, 40), 40: (35, 40), 41: (33, 41), 42: (30, 42), 43: (34, 43), 44: (34, 45), 45: (28, 45), 46: (29, 46), 47: (32, 47), 48: (36, 48), 49: (38, 50), 50: (42, 50), 51: (37, 51), 52: (44, 53), 53: (49, 53), 54: (35, 55), 55: (39, 55), 56: (41, 56), 57: (47, 57), 58: (49, 58), 59: (52, 61), 60: (44, 60), 61: (61, 61), 62: (61, 62), 63: (60, 63), 'low': (14, 35)}
def build(windows, low_cut=36, widen=0, l2='TL'):
    g = graph(example=[5,7,3,2,1,0,4,6])
    t = g.tokens()
    E = g.weight("embed"); Wg = g.weight("unembed") @ g.weight("hidden")
    Mg = Wg @ E
    M64 = Mg[:, :64]
    T1 = M64.argmax(0)
    cm = lv1.cumsum(M64, axis=1) / (g.arange(64) + 1.0)
    TL2 = (M64 + cm).argmax(0)
    TL3 = (M64 + 2.0*cm).argmax(0)
    TL4 = (M64 + 3.0*cm).argmax(0)
    h = lv1.take_sum(E, t, axis=1)
    mx = lv1.maximum(lv1.maximum(t[:6].max(), t[6] % 64), t[7] % 64)
    def leaf(lo, hi):
        lo = max(lo - widen, 0)
        if lo == hi: return lo
        return (Wg[lo:hi+1] @ h).argmax() + lo
    def tree(lo_m, hi_m):
        if lo_m == hi_m: return leaf(*windows[lo_m])
        mid = (lo_m + hi_m + 1)//2
        return lv1.cond(mx >= mid, tree(mid, hi_m), tree(lo_m, mid-1))
    TREE = lv1.cond(mx >= low_cut, tree(low_cut, 63), leaf(*windows['low']))
    t0, t1 = t[0], t[1]
    if l2 == 'TL':
        L2 = TL2[lv1.maximum(t0, t1)]
    else:
        T2 = (M64[:, :, None] + M64[:, None, :]).argmax(0); L2 = T2[t0, t1]
    pred = lv1.cond(t[4] == 64,
        lv1.cond(t[2] == 64,
            lv1.cond(t1 == 64, T1[t0], L2),
            lv1.cond(t[3] == 64, TL3[t[:3].max()], TL4[t[:4].max()])),
        lv1.cond(t[5] == 64, t[:5].max(), TREE))
    return g, g.entry(interpretation=pred)
g, e = build(windows)
print("nodes:", len(g.nodes))
m = measure(e); print({k: m[k] for k in ['fidelity','cost','b','r','reward']})
save_entry("hybrid_v2", e)

# numpy re-implementation for per-L analysis
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_; M_ = W_ @ E_; M64_ = M_[:, :64]
cm_ = np.cumsum(M64_, axis=1) / np.arange(1,65)
TL = {l: (M64_ + (l-1)*cm_).argmax(0) for l in [1,2,3,4]}
rng = np.random.default_rng(11)
def sample(n):
    L = rng.integers(1,9,n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64; return X, L
X, L = sample(800000)
h_ = E_[:, X].sum(2)  # 8 x n
Y = (W_ @ h_).argmax(0)
mx = np.where(X==64, -1, X).max(1)
pred = np.empty_like(Y)
for l in [1,2,3,4]:
    s = L==l; pred[s] = TL[l][mx[s]]
s = L==5; pred[s] = mx[s]
s = L>=6
for m_ in range(64):
    ss = s & (mx==m_)
    if not ss.any(): continue
    lo, hi = windows[m_] if m_>=36 else windows['low']
    pred[ss] = (W_[lo:hi+1] @ h_[:, ss]).argmax(0) + lo
ok = pred==Y
print("per-L error:", [(1-ok[L==l].mean()).round(4) for l in range(1,9)], "overall", (1-ok.mean()).round(4))
