
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
rng = np.random.default_rng(7)
def sample_L(n, Ls):
    L = rng.choice(Ls, n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
def net(X):
    out = np.empty(len(X), dtype=int)
    for i in range(0, len(X), 200000):
        h = E[:, X[i:i+200000]].sum(2)  # 8 x n
        out[i:i+200000] = (W @ h).argmax(0)
    return out
X, L = sample_L(3000000, [7,8])
Y = net(X)
Xm = np.where(X==64, -1, X); mx = Xm.max(1)
J = np.zeros((64,64))
np.add.at(J, (mx, Y), 1)
J /= len(Y)
FP = 703.0
def best_rows(u, v):
    pm = J[u:v+1].sum()
    if pm == 0: return 0.0, (0,63)
    py = J[u:v+1].sum(0)
    cs = np.concatenate([[0], np.cumsum(py)])
    best = None
    for lo in range(0,64):
        for hi in range(lo,64):
            inside = cs[hi+1]-cs[lo]
            c = pm*(9*(hi-lo+1)) + 10*FP*(pm-inside)
            if best is None or c < best[0]: best = (c, (lo,hi))
    return best
INF=1e18
cost = [INF]*65; cost[0]=0; back=[None]*65
cache={}
for v in range(1,65):
    for u in range(0,v):
        if (u,v-1) not in cache: cache[(u,v-1)] = best_rows(u, v-1)
        c, rows = cache[(u,v-1)]
        tot = cost[u] + c + 2.5*J[u:v].sum()
        if tot < cost[v]: cost[v]=tot; back[v]=(u, rows)
parts=[]; v=64
while v>0:
    u, rows = back[v]; parts.append((u, v-1, rows)); v=u
parts=parts[::-1]
print("DP total expected ops+penalty per input (L=7,8):", round(cost[64],1), "-> share", round(cost[64]/FP,3))
for p in parts: print("mx in", p[0], "-", p[1], "rows", p[2], "P(mx)", J[p[0]:p[1]+1].sum().round(4), "err", (J[p[0]:p[1]+1].sum()-J[p[0]:p[1]+1].sum(0)[p[2][0]:p[2][1]+1].sum()).round(5))
np.save('tmp/J78.npy', J)
