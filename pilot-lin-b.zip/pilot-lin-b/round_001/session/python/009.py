
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
rng = np.random.default_rng(5)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
X, L = sample(1000000)
logits = M[:, X].sum(2).T
Y = logits.argmax(1)
Xm = np.where(X==64, -1, X)
S = np.sort(Xm, axis=1)[:, ::-1]
mx, s2 = S[:,0], S[:,1]
mu = M[:, :64].mean(1)  # 64
# T[mx, L] = argmax M[:,mx] + (L-1) mu
TL = np.stack([(M[:, :64] + (l-1)*mu[:,None]).argmax(0) for l in range(1,9)], axis=1)  # 64 x 8
predL = TL[mx, L-1]
ok = predL==Y
print("T[mx,L]", ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
# variant: mu computed over tokens below mx only (conditional mean), i.e. others uniform on [0,mx) approx... actually others uniform on [0,63] but < = mx
cm = np.cumsum(M[:, :64], axis=1) / np.arange(1,65)  # conditional mean of M[:,t] for t<=m
TLc = np.stack([(M[:, :64] + (l-1)*cm).argmax(0) for l in range(1,9)], axis=1)
predLc = TLc[mx, L-1]
ok = predLc==Y
print("T[mx,L] cond-mean", ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
# top2 + (L-2)*cm[mx]
pred = np.empty_like(Y)
for i in range(0, len(Y), 100000):
    sl = slice(i, i+100000)
    lg = M[:, mx[sl]] + M[:, np.where(s2[sl]>=0, s2[sl], 64)] + np.maximum(L[sl]-2,0)*cm[:, mx[sl]]
    pred[sl] = lg.argmax(0)
ok = pred==Y
print("top2 + (L-2)cm", ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
# linear-in-token approx: logits ~ M[:,mx] + sum_{others} (a + b t)?  fit a,b per row by least squares over t in 0..63 (weighted?)
t = np.arange(64)
A = np.stack([np.ones(64), t], 1)
coef = np.linalg.lstsq(A, M[:, :64].T, rcond=None)[0]  # 2 x 64
a_, b_ = coef
Ssum = np.where(Xm>=0, Xm, 0).sum(1) - mx
pred = np.empty_like(Y)
for i in range(0, len(Y), 100000):
    sl = slice(i, i+100000)
    lg = M[:, mx[sl]] + (L[sl]-1)*a_[:,None] + Ssum[sl]*b_[:,None]
    pred[sl] = lg.argmax(0)
ok = pred==Y
print("mx + linear others", ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
