
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H @ E
rng = np.random.default_rng(0)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
def net(X):
    return np.argmax(M[:, X].sum(2), axis=0)  # M[:,X] -> 64 x n x 8
X, L = sample(200000)
Y = net(X)
Xm = np.where(X==64, -1, X)
mx = Xm.max(1)
ok = (Y==mx)
print("max acc", ok.mean())
# failure analysis by max value
for m in range(64):
    sel = mx==m
    if sel.sum(): print(m, sel.sum(), ok[sel].mean().round(3), end=' | ')
print()
# failures: what is output vs sorted tokens
fails = np.where(~ok)[0][:30]
for i in fails:
    t = np.sort(Xm[i][Xm[i]>=0])[::-1]
    print(t, '->', Y[i])
