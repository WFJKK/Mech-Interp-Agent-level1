
import numpy as np, inspect
print(inspect.signature(lv1.concat))
D3 = [((0, 35), [(14, 36)]), ((36, 39), [(19, 20), (26, 28), (30, 40)]), ((40, 43), [(26, 27), (30, 31), (33, 44)]), ((44, 47), [(16, 17), (28, 40), (41, 48)]), ((48, 48), [(13, 14), (36, 37), (41, 49)]), ((49, 49), [(38, 39), (40, 43), (44, 51)]), ((50, 50), [(42, 43), (44, 47), (48, 51)]), ((51, 51), [(19, 20), (37, 38), (44, 52)]), ((52, 52), [(44, 45), (46, 54)]), ((53, 53), [(20, 22), (37, 38), (49, 54)]), ((54, 54), [(29, 30), (35, 36), (44, 56)]), ((55, 55), [(21, 22), (39, 42), (52, 56)]), ((56, 56), [(18, 19), (41, 45), (47, 57)]), ((57, 57), [(47, 48), (49, 53), (55, 58)]), ((58, 58), [(21, 24), (49, 50), (53, 59)]), ((59, 59), [(16, 17), (48, 49), (52, 62)]), ((60, 60), [(34, 35), (44, 50), (52, 61)]), ((61, 61), [(46, 47), (55, 56), (61, 62)]), ((62, 62), [(38, 39), (50, 52), (61, 63)]), ((63, 63), [(23, 24), (25, 26), (60, 64)])]
def build(design):
    g = graph(example=[5,7,3,2,1,0,4,6])
    t = g.tokens()
    E = g.weight("embed"); Wg = g.weight("unembed") @ g.weight("hidden")
    M64 = (Wg @ E)[:, :64]
    T1 = M64.argmax(0)
    cm = lv1.cumsum(M64, axis=1) / (g.arange(64) + 1.0)
    TL2 = (M64 + cm).argmax(0); TL3 = (M64 + 2.0*cm).argmax(0); TL4 = (M64 + 3.0*cm).argmax(0)
    h = lv1.take_sum(E, t, axis=1)
    mx = lv1.maximum(lv1.maximum(t[:6].max(), t[6] % 64), t[7] % 64)
    R = g.arange(64)
    def leaf(ivs):
        n = sum(b-a for a,b in ivs)
        if n == 1: return ivs[0][0]
        if len(ivs) == 1:
            a,b = ivs[0]; return (Wg[a:b] @ h).argmax() + a
        Wr = lv1.concat([Wg[a:b] for a,b in ivs], axis=0)
        idx = lv1.concat([R[a:b] for a,b in ivs], axis=0)
        return idx[(Wr @ h).argmax()]
    # balanced tree over the list of groups (sorted by mx)
    def tree(items):
        if len(items) == 1: return leaf(items[0][1])
        mid = len(items)//2
        thr = items[mid][0][0]
        return lv1.cond(mx >= thr, tree(items[mid:]), tree(items[:mid]))
    TREE = tree(design)
    t0, t1 = t[0], t[1]
    pred = lv1.cond(t[4] == 64,
        lv1.cond(t[2] == 64,
            lv1.cond(t1 == 64, T1[t0], TL2[lv1.maximum(t0, t1)]),
            lv1.cond(t[3] == 64, TL3[t[:3].max()], TL4[t[:4].max()])),
        lv1.cond(t[5] == 64, t[:5].max(), TREE))
    return g, g.entry(interpretation=pred)
g, e = build(D3)
print("nodes:", len(g.nodes))
m = measure(e); print({k: m[k] for k in ['fidelity','fidelity_low','cost','b','r','reward']})
save_entry("hybrid_v3", e)
