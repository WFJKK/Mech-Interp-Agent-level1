
import numpy as np
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_; M_ = W_ @ E_
FP=703.0
rng = np.random.default_rng(16)
D3 = [((0, 35), [(14, 36)]), ((36, 39), [(19, 20), (26, 28), (30, 40)]), ((40, 43), [(26, 27), (30, 31), (33, 44)]), ((44, 47), [(16, 17), (28, 40), (41, 48)]), ((48, 48), [(13, 14), (36, 37), (41, 49)]), ((49, 49), [(38, 39), (40, 43), (44, 51)]), ((50, 50), [(42, 43), (44, 47), (48, 51)]), ((51, 51), [(19, 20), (37, 38), (44, 52)]), ((52, 52), [(44, 45), (46, 54)]), ((53, 53), [(20, 22), (37, 38), (49, 54)]), ((54, 54), [(29, 30), (35, 36), (44, 56)]), ((55, 55), [(21, 22), (39, 42), (52, 56)]), ((56, 56), [(18, 19), (41, 45), (47, 57)]), ((57, 57), [(47, 48), (49, 53), (55, 58)]), ((58, 58), [(21, 24), (49, 50), (53, 59)]), ((59, 59), [(16, 17), (48, 49), (52, 62)]), ((60, 60), [(34, 35), (44, 50), (52, 61)]), ((61, 61), [(46, 47), (55, 56), (61, 62)]), ((62, 62), [(38, 39), (50, 52), (61, 63)]), ((63, 63), [(23, 24), (25, 26), (60, 64)])]
def sample(Ls, n):
    L = rng.choice(Ls, n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64
    Y = np.empty(n,int)
    for i in range(0,n,250000): Y[i:i+250000] = (W_ @ E_[:, X[i:i+250000]].sum(2)).argmax(0)
    return X, L, Y
X, L, Y = sample([6,7,8], 2000000)
S = np.sort(np.where(X==64,-1,X),1)[:,::-1]; mx, s2 = S[:,0], S[:,1]
keep = np.zeros((64,64),bool)
for (u,v),ivs in D3:
    for a,b in ivs: keep[u:v+1, a:b] = True
err = ~keep[mx, Y]
print("design err", err.mean().round(5))
gap = mx - s2
for lo,hi in [(0,0),(1,2),(3,5),(6,10),(11,20),(21,63)]:
    s=(gap>=lo)&(gap<=hi); print("gap",lo,hi,"P",s.mean().round(3),"err",err[s].mean().round(4))
# (c) k=4 gain on leaves 56..63: compute J and best_k for k=3 vs 4
J = np.zeros((64,64)); np.add.at(J,(mx,Y),1); J/=len(Y)
def best_k(py, pm, k, rowcost=9):
    dp = {(0,0):(0.0,[])}
    keepc = rowcost*pm; dropc = 10*FP*py
    for j in range(64):
        nd={}
        for (r,ins),(c,path) in dp.items():
            key=(r,0); val=(c+dropc[j], path+[0])
            if key not in nd or val[0]<nd[key][0]: nd[key]=val
            r2 = r if ins else r+1
            if r2<=k:
                key=(r2,1); val=(c+keepc, path+[1])
                if key not in nd or val[0]<nd[key][0]: nd[key]=val
        dp=nd
    c,path = min(dp.values(), key=lambda v:v[0]); keep=np.array(path,bool)
    ivs=[]; j=0
    while j<64:
        if keep[j]:
            s=j
            while j<64 and keep[j]: j+=1
            ivs.append((s,j))
        else: j+=1
    return c, ivs
g3=g4=0
for m in range(56,64):
    c3,_=best_k(J[m],J[m].sum(),3); c4,iv4=best_k(J[m],J[m].sum(),4); g3+=c3; g4+=c4
print("top leaves k=3:", round(g3,1), "k=4:", round(g4,1))
# (b) L=2 tree design with rowcost 3 (take_sum 2 + argmax 1): groups of mx
X2, L2, Y2 = sample([2], 2000000)
mx2 = np.where(X2==64,-1,X2).max(1)
J2 = np.zeros((64,64)); np.add.at(J2,(mx2,Y2),1); J2/=len(Y2)
cm_ = np.cumsum(M_[:, :64],1)/np.arange(1,65); TL2 = (M_[:, :64]+cm_).argmax(0)
print("TL2 err L=2:", (TL2[mx2]!=Y2).mean().round(5), "-> ops-eq", round(10*FP*(TL2[mx2]!=Y2).mean()+2,1))
for groups in [[(0,11)]+[(m,m) for m in range(12,64)], [(0,11),(12,23),(24,35),(36,47),(48,55),(56,59),(60,63)], [(0,11),(12,31),(32,47),(48,63)]]:
    tot=0; des=[]
    for (u,v) in groups:
        py=J2[u:v+1].sum(0); pm=py.sum(); c,ivs=best_k(py,pm,2,rowcost=3); tot+=c; des.append(((u,v),ivs))
    print("L=2 tree groups", len(groups), "ops-eq", round(tot,1), "+ conds ~", 2*np.ceil(np.log2(len(groups))))
    if len(groups)==7: print(des)
