
import numpy as np
windows = {36: (23, 37), 37: (26, 37), 38: (34, 40), 39: (19, 40), 40: (35, 40), 41: (33, 41), 42: (30, 42), 43: (34, 43), 44: (34, 45), 45: (28, 45), 46: (29, 46), 47: (32, 47), 48: (36, 48), 49: (38, 50), 50: (42, 50), 51: (37, 51), 52: (44, 53), 53: (49, 53), 54: (35, 55), 55: (39, 55), 56: (41, 56), 57: (47, 57), 58: (49, 58), 59: (52, 61), 60: (44, 60), 61: (61, 61), 62: (61, 62), 63: (60, 63), 'low': (14, 35)}
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_
rng = np.random.default_rng(12)
n=1500000
L = rng.choice([6,7,8], n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64
h_ = E_[:, X].sum(2); Y = (W_ @ h_).argmax(0); mx = np.where(X==64, -1, X).max(1)
pred = np.empty_like(Y); at_lo = np.zeros(n, bool); at_hi = np.zeros(n, bool); lo_arr=np.zeros(n,int); hi_arr=np.zeros(n,int)
for m_ in range(64):
    ss = (mx==m_)
    if not ss.any(): continue
    lo, hi = windows[m_] if m_>=36 else windows['low']
    if lo==hi:
        pred[ss]=lo; at_lo[ss]=True; at_hi[ss]=True
    else:
        idx = (W_[lo:hi+1] @ h_[:, ss]).argmax(0); pred[ss] = idx+lo; at_lo[ss] = idx==0; at_hi[ss] = idx==hi-lo
    lo_arr[ss]=lo; hi_arr[ss]=hi
err = pred!=Y
print("error", err.mean().round(5), "P(at_lo)", at_lo.mean().round(4), "P(at_hi)", at_hi.mean().round(4))
print("errors with Y<lo:", (err&(Y<lo_arr)).mean().round(5), " of which at_lo:", (err&(Y<lo_arr)&at_lo).mean().round(5))
print("errors with Y>hi:", (err&(Y>hi_arr)).mean().round(5), " of which at_hi:", (err&(Y>hi_arr)&at_hi).mean().round(5))
# if fallback at_lo -> full argmax over rows 10..lo-1 vs window best: emulate exact result = Y when Y>=10
print("P(at_lo) excluding singleton leaves:", (at_lo & (lo_arr!=hi_arr)).mean().round(4))
# by L
for l in [6,7,8]:
    s=L==l; print(l, "err", err[s].mean().round(4), "at_lo", at_lo[s].mean().round(4), "caught", (err&(Y<lo_arr)&at_lo)[s].mean().round(4))
