
import json, numpy as np
windows = {int(k) if k!='low' else k: tuple(v) for k,v in json.load(open('tmp/windows.json')).items()}
def build(windows, low_cut=36, widen=0):
    g = graph(example=[5,7,64,64,64,64,64,64])
    t = g.tokens()
    E = g.weight("embed"); Wg = g.weight("unembed") @ g.weight("hidden")
    Mg = Wg @ E
    M64 = Mg[:, :64]
    T1 = M64.argmax(0)
    T2 = (M64[:, :, None] + M64[:, None, :]).argmax(0)
    cm = lv1.cumsum(M64, axis=1) / (g.arange(64) + 1.0)
    TL3 = (M64 + 2.0*cm).argmax(0)
    TL4 = (M64 + 3.0*cm).argmax(0)
    h = lv1.take_sum(E, t, axis=1)
    mx = lv1.maximum(lv1.maximum(t[:6].max(), t[6] % 64), t[7] % 64)
    def leaf(lo, hi):
        lo = max(lo - widen, 0)
        if lo == hi: return g.const(lo) if False else lo  # python int becomes const
        return (Wg[lo:hi+1] @ h).argmax() + lo
    # balanced tree over mx values low_cut..63, plus 'low' leaf for mx<low_cut
    def tree(lo_m, hi_m):
        if lo_m == hi_m: return leaf(*windows[lo_m])
        mid = (lo_m + hi_m + 1)//2
        return lv1.cond(mx >= mid, tree(mid, hi_m), tree(lo_m, mid-1))
    TREE = lv1.cond(mx >= low_cut, tree(low_cut, 63), leaf(*windows['low']))
    t0, t1 = t[0], t[1]
    pred = lv1.cond(t[4] == 64,
        lv1.cond(t[2] == 64,
            lv1.cond(t1 == 64, T1[t0], T2[t0, t1]),
            lv1.cond(t[3] == 64, TL3[t[:3].max()], TL4[t[:4].max()])),
        lv1.cond(t[5] == 64, t[:5].max(), TREE))
    return g, g.entry(interpretation=pred)
g, e = build(windows)
print("nodes:", len(g.nodes))
m = measure(e); print(m)
save_entry("hybrid_v1", e)
