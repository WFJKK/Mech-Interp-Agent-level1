
import numpy as np
print(info)
for k,v in weights.items(): print(k, v.shape)
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H @ E  # 64 x 65
print(M[:, 64])
# network output is argmax over sum of M columns at tokens
out = network_outputs()
print(type(out), len(out) if hasattr(out,'__len__') else '')
