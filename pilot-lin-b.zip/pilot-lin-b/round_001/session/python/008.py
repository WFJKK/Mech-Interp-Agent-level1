
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
rng = np.random.default_rng(4)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
X, L = sample(1000000)
logits = M[:, X].sum(2).T
Y = logits.argmax(1)
Xm = np.where(X==64, -1, X)
S = np.sort(Xm, axis=1)[:, ::-1]
mx, s2, s3 = S[:,0], S[:,1], S[:,2]
# table2: answer for pair (a,b)
T2 = (M[:, :64, None] + M[:, None, :64]).argmax(0)  # 64x64
T1 = M[:, :64].argmax(0)
pred2 = np.where(s2>=0, T2[mx, np.maximum(s2,0)], T1[mx])
# table3 for top-3 (just to see the ceiling)
pred3 = np.empty_like(Y)
for i in range(0, len(Y), 100000):
    sl = slice(i, i+100000)
    lg = M[:, mx[sl]] + M[:, np.where(s2[sl]>=0, s2[sl], 64)] + M[:, np.where(s3[sl]>=0, s3[sl], 64)]
    pred3[sl] = lg.argmax(0)
for name, p in [('max', mx), ('top2', pred2), ('top3', pred3)]:
    ok = p==Y
    print(name, ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
# where is Y relative to mx: for mx buckets, low quantiles of Y
for lo in range(10, 64, 6):
    sel = (mx>=lo)&(mx<lo+6)&(L>=3)
    print(lo, sel.sum(), np.percentile(Y[sel], [0.01, 0.1, 0.5, 1, 99.9]).round(0), Y[sel].min())
