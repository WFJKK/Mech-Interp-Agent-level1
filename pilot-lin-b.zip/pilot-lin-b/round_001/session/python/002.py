
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
M = U @ H @ E
X, Y, ops = network_outputs()
X = np.array(X); Y = np.array(Y)
print(X.shape, Y.shape, ops)
print(X[:5], Y[:5])
# single-token behaviour
single = np.argmax(M[:, :64], axis=0)
print("single-token outputs:", single)
# hypotheses: max, min, mode, first, last, sum mod 64, etc.
L = (X != 64).sum(1)
toks = [x[x!=64] for x in X]
hyps = {
 'max': np.array([t.max() for t in toks]),
 'min': np.array([t.min() for t in toks]),
 'first': np.array([t[0] for t in toks]),
 'last': np.array([t[-1] for t in toks]),
 'summod': np.array([t.sum()%64 for t in toks]),
 'mean': np.array([int(round(t.mean())) for t in toks]),
 'median': np.array([int(np.median(t)) for t in toks]),
}
for k,v in hyps.items():
    print(k, (v==Y).mean(), [(v==Y)[L==l].mean().round(3) for l in range(1,9)])
