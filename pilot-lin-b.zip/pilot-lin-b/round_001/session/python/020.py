
import numpy as np
windows = {36: (23, 37), 37: (26, 37), 38: (34, 40), 39: (19, 40), 40: (35, 40), 41: (33, 41), 42: (30, 42), 43: (34, 43), 44: (34, 45), 45: (28, 45), 46: (29, 46), 47: (32, 47), 48: (36, 48), 49: (38, 50), 50: (42, 50), 51: (37, 51), 52: (44, 53), 53: (49, 53), 54: (35, 55), 55: (39, 55), 56: (41, 56), 57: (47, 57), 58: (49, 58), 59: (52, 61), 60: (44, 60), 61: (61, 61), 62: (61, 62), 63: (60, 63), 'low': (14, 35)}
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_
rng = np.random.default_rng(13)
n=1500000
L = rng.choice([6,7,8], n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64
h_ = E_[:, X].sum(2); logits = (W_ @ h_); Y = logits.argmax(0); mx = np.where(X==64, -1, X).max(1)
pred = np.empty_like(Y); wmax = np.zeros(n)
for m_ in range(64):
    ss = (mx==m_)
    if not ss.any(): continue
    lo, hi = windows[m_] if m_>=36 else windows['low']
    sub = W_[lo:hi+1] @ h_[:, ss]; pred[ss] = sub.argmax(0)+lo; wmax[ss] = sub.max(0)
err = pred!=Y
print("base err", err.mean().round(5))
# (a) logistic regression on features [h, wmax, 1] via a few Newton steps
F = np.concatenate([h_.T, wmax[:,None], np.ones((n,1))], 1).astype(float)
F[:, :8] /= F[:, :8].std(0); F[:, 8] /= F[:, 8].std()
w = np.zeros(F.shape[1]); yb = err.astype(float)
for it in range(15):
    p = 1/(1+np.exp(-F@w)); g = F.T@(p-yb)/n; Hm = (F*(p*(1-p))[:,None]).T@F/n + 1e-6*np.eye(F.shape[1])
    w -= np.linalg.solve(Hm, g)
score = F@w
for flag in [0.02,0.05,0.1,0.2]:
    thr = np.quantile(score, 1-flag); print("logreg flag", flag, "recall", (err&(score>thr)).sum()/err.sum())
# (b) mean mid-row logit minus window max
for lo_r, hi_r in [(30,50),(35,50),(25,45),(40,55)]:
    wbar = W_[lo_r:hi_r+1].mean(0); s2 = wbar@h_ - wmax
    for flag in [0.05,0.1,0.2]:
        thr = np.quantile(s2, 1-flag); print("midrow", (lo_r,hi_r), "flag", flag, "recall", round((err&(s2>thr)).sum()/err.sum(),3))
# (c) max over a few fixed mid rows minus wmax
for rows in [[35,44,50],[32,38,44,50],[30,36,42,48,54]]:
    s3 = (W_[rows]@h_).max(0) - wmax
    for flag in [0.05,0.1,0.2]:
        thr = np.quantile(s3, 1-flag); print("rows", rows, "flag", flag, "recall", round((err&(s3>thr)).sum()/err.sum(),3))
