
import numpy as np
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_
FP=703.0
rng = np.random.default_rng(17)
n=3000000
L = rng.choice([6,7,8], n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64
Y = np.empty(n,int)
for i in range(0,n,250000): Y[i:i+250000] = (W_ @ E_[:, X[i:i+250000]].sum(2)).argmax(0)
mx = np.where(X==64,-1,X).max(1)
J = np.zeros((64,64)); np.add.at(J,(mx,Y),1); J/=n
def best_k(py, pm, k, rowcost=9):
    dp = {(0,0):(0.0,[])}
    keepc = rowcost*pm; dropc = 10*FP*py
    for j in range(64):
        nd={}
        for (r,ins),(c,path) in dp.items():
            key=(r,0); val=(c+dropc[j], path+[0])
            if key not in nd or val[0]<nd[key][0]: nd[key]=val
            r2 = r if ins else r+1
            if r2<=k:
                key=(r2,1); val=(c+keepc, path+[1])
                if key not in nd or val[0]<nd[key][0]: nd[key]=val
        dp=nd
    c,path = min(dp.values(), key=lambda v:v[0]); keep=np.array(path,bool)
    ivs=[]; j=0
    while j<64:
        if keep[j]:
            s=j
            while j<64 and keep[j]: j+=1
            ivs.append((s,j))
        else: j+=1
    return c, ivs
groups = [(0,35),(36,39),(40,43),(44,47)] + [(m,m) for m in range(48,64)]
design=[]; tot=0
for (u,v) in groups:
    py=J[u:v+1].sum(0); pm=py.sum(); k = 4 if u>=56 else 3
    c,ivs=best_k(py,pm,k); tot+=c; design.append(((u,v),ivs))
print("expected ops+penalty:", round(tot,1)); print(design)
def build(design):
    g = graph(example=[5,7,3,2,1,0,4,6])
    t = g.tokens()
    E = g.weight("embed"); Wg = g.weight("unembed") @ g.weight("hidden")
    Mfull = Wg @ E; M64 = Mfull[:, :64]
    T1 = M64.argmax(0)
    cm = lv1.cumsum(M64, axis=1) / (g.arange(64) + 1.0)
    TL2 = (M64 + cm).argmax(0); TL3 = (M64 + 2.0*cm).argmax(0); TL4 = (M64 + 3.0*cm).argmax(0)
    mx = lv1.maximum(lv1.maximum(t[:6].max(), t[6] % 64), t[7] % 64)
    R = g.arange(64)
    def leaf(ivs):
        nr = sum(b-a for a,b in ivs)
        if nr == 1: return ivs[0][0]
        if len(ivs) == 1:
            a,b = ivs[0]; return lv1.take_sum(Mfull[a:b], t, axis=1).argmax() + a
        Mr = lv1.concat([Mfull[a:b] for a,b in ivs], axis=0)
        idx = lv1.concat([R[a:b] for a,b in ivs], axis=0)
        return idx[lv1.take_sum(Mr, t, axis=1).argmax()]
    def tree(items):
        if len(items) == 1: return leaf(items[0][1])
        mid = len(items)//2; thr = items[mid][0][0]
        return lv1.cond(mx >= thr, tree(items[mid:]), tree(items[:mid]))
    TREE = tree(design)
    t0, t1 = t[0], t[1]
    pred = lv1.cond(t[4] == 64,
        lv1.cond(t[2] == 64,
            lv1.cond(t1 == 64, T1[t0], TL2[lv1.maximum(t0, t1)]),
            lv1.cond(t[3] == 64, TL3[t[:3].max()], TL4[t[:4].max()])),
        lv1.cond(t[5] == 64, t[:5].max(), TREE))
    return g, g.entry(interpretation=pred)
g, e = build(design)
print("nodes:", len(g.nodes))
m = measure(e); print({k: m[k] for k in ['fidelity','fidelity_low','cost','b','r','reward']})
if len(g.nodes) <= 400: save_entry("hybrid_v5", e)
