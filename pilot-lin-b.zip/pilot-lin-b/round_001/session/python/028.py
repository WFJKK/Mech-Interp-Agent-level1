
import numpy as np
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_
FP=703.0
rng = np.random.default_rng(18)
def best_k(py, pm, k, rowcost=9):
    dp = {(0,0):(0.0,[])}
    keepc = rowcost*pm; dropc = 10*FP*py
    for j in range(64):
        nd={}
        for (r,ins),(c,path) in dp.items():
            key=(r,0); val=(c+dropc[j], path+[0])
            if key not in nd or val[0]<nd[key][0]: nd[key]=val
            r2 = r if ins else r+1
            if r2<=k:
                key=(r2,1); val=(c+keepc, path+[1])
                if key not in nd or val[0]<nd[key][0]: nd[key]=val
        dp=nd
    c,path = min(dp.values(), key=lambda v:v[0]); keep=np.array(path,bool)
    ivs=[]; j=0
    while j<64:
        if keep[j]:
            s=j
            while j<64 and keep[j]: j+=1
            ivs.append((s,j))
        else: j+=1
    return c, ivs
n=3000000
X = rng.integers(0,64,(n,8)); X[:,5:] = 64
Y = np.empty(n,int)
for i in range(0,n,250000): Y[i:i+250000] = (W_ @ E_[:, X[i:i+250000]].sum(2)).argmax(0)
mx = X[:, :5].max(1)
J5 = np.zeros((64,64)); np.add.at(J5,(mx,Y),1); J5/=n
d = J5[np.arange(64),np.arange(64)].sum()
print("max err L=5:", round(1-d,4), "ops-eq", round(7+10*FP*(1-d),1))
for groups in [[(0,47),(48,51),(52,55),(56,57),(58,59),(60,61),(62,63)], [(0,51),(52,55),(56,59),(60,63)], [(0,55),(56,59),(60,63)], [(0,47),(48,55),(56,59),(60,61),(62,63)], [(0,47)]+[(m,m) for m in range(48,64)]]:
    tot=0; des=[]
    for (u,v) in groups:
        py=J5[u:v+1].sum(0); pm=py.sum(); c,ivs=best_k(py,pm,2); tot+=c; des.append(((u,v),ivs))
    nodes = sum(1 if sum(b-a for a,b in ivs)==1 else (4 if len(ivs)==1 else 9) for _,ivs in des) + 2*(len(groups)-1)
    print(len(groups), "groups: ops-eq", round(tot,1), "+ mx 4 + conds ~", 2*np.ceil(np.log2(len(groups))), "nodes ~", nodes)
    if len(groups) <= 7: print(des)
