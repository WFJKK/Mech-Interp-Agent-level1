
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
g = graph(example=[5,7,64,64,64,64,64,64])
print([n for n in dir(g) if not n.startswith('_')])
t = g.tokens()
print(t.shape, t.value, type(t))
print([n for n in dir(t) if not n.startswith('_')])
print(inspect.signature(lv1.cond), inspect.signature(lv1.take_sum))
E = g.weight("embed"); Wg = g.weight("unembed") @ g.weight("hidden")
h = lv1.take_sum(E, t, axis=1); print(h.shape)
m3 = t[:3].max(); print(m3.shape, m3.value)
sub = Wg[20:30] @ h; print(sub.shape)
r = lv1.cond(t[1] == 64, t[0], sub.argmax() + 20); print(r.value)
Mg = Wg @ E
T2 = (Mg[:, :64][:, :, None] + Mg[:, :64][:, None, :]).argmax(0) if hasattr(Mg,'__getitem__') else None
print(T2.shape)
v = T2[t[0], t[1]]; print(v.shape, v.value)
e = g.entry(interpretation=r)
print(measure(e))
