
import numpy as np
print("MAX_CONST_SCALARS", lv1.MAX_CONST_SCALARS, "MAX_NODES", lv1.MAX_NODES)
E_, H_, U_ = weights['embed'], weights['hidden'], weights['unembed']
W_ = U_ @ H_
rng = np.random.default_rng(15)
FP=703.0
def joint(Ls, n=3000000):
    L = rng.choice(Ls, n); X = rng.integers(0,64,(n,8)); X[np.arange(8)[None,:] >= L[:,None]] = 64
    out = np.empty(n, int)
    for i in range(0,n,250000):
        out[i:i+250000] = (W_ @ E_[:, X[i:i+250000]].sum(2)).argmax(0)
    mx = np.where(X==64, -1, X).max(1)
    J = np.zeros((64,64)); np.add.at(J, (mx, out), 1); return J/n
J = joint([6,7,8])
def best_k_intervals(py, pm, k):
    # DP over rows: state (runs used, currently inside)
    INF=1e18
    keepc = 9*pm; dropc = 10*FP*py
    # dp[r][inside] = (cost, path)
    dp = {(0,0):(0.0,[])}
    for j in range(64):
        nd={}
        for (r,ins),(c,path) in dp.items():
            # drop j
            key=(r,0); val=(c+dropc[j], path+[0])
            if key not in nd or val[0]<nd[key][0]: nd[key]=val
            # keep j
            r2 = r if ins else r+1
            if r2<=k:
                key=(r2,1); val=(c+keepc, path+[1])
                if key not in nd or val[0]<nd[key][0]: nd[key]=val
        dp=nd
    c,path = min(dp.values(), key=lambda v:v[0])
    keep=np.array(path,bool)
    # intervals
    ivs=[]; j=0
    while j<64:
        if keep[j]:
            s=j
            while j<64 and keep[j]: j+=1
            ivs.append((s,j))
        else: j+=1
    return c, ivs
groups = [(0,35),(36,39),(40,43),(44,47)] + [(m,m) for m in range(48,64)]
for k in [1,2,3,4]:
    tot=0; design=[]
    for (u,v) in groups:
        py=J[u:v+1].sum(0); pm=py.sum()
        c,ivs=best_k_intervals(py,pm,k); tot+=c; design.append(((u,v),ivs))
    print("k",k,"expected ops+penalty", round(tot,1))
    if k==3: D3=design
for d in D3: print(d)
