
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
rng = np.random.default_rng(2)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
X, L = sample(1000000)
h = E[:, X].sum(2).T
logits = h @ W.T
Y = logits.argmax(1)
Xm = np.where(X==64, -1, X); mx = Xm.max(1)
print("output counts:", np.bincount(Y, minlength=64))
d = Y - mx
wrong = Y != mx
print("dist of Y-mx when wrong:", np.percentile(d[wrong], [1,5,25,50,75,95,99]), "min", d.min(), "max", d.max())
# window around mx: fidelity for windows [mx-a, mx+b]
for a,b in [(4,2),(8,2),(8,4),(12,4),(16,4),(20,4),(24,4),(32,4)]:
    lo = np.maximum(mx-a,0); hi = np.minimum(mx+b,63)
    print((a,b), ((Y>=lo)&(Y<=hi)).mean())
# coarse-to-fine: grid every s, then refine around best grid point
for s in [2,3,4,5,6,8]:
    grid = np.arange(0,64,s)
    gbest = grid[logits[:,grid].argmax(1)]
    acc=[]
    for r in [s-1, s, s+1, 2*s]:
        lo = np.clip(gbest-r,0,63); hi=np.clip(gbest+r,0,63)
        acc.append(((Y>=lo)&(Y<=hi)).mean().round(5))
    print("s",s,acc)
