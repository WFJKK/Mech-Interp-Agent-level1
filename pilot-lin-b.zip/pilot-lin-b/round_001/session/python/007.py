
import numpy as np
E, H, U = weights['embed'], weights['hidden'], weights['unembed']
W = U @ H
M = W @ E
rng = np.random.default_rng(3)
def sample(n):
    L = rng.integers(1,9,n)
    X = rng.integers(0,64,(n,8))
    X[np.arange(8)[None,:] >= L[:,None]] = 64
    return X, L
X, L = sample(500000)
logits = M[:, X].sum(2).T
Y = logits.argmax(1)
srt = np.sort(logits, axis=1)
margin = srt[:,-1]-srt[:,-2]
print("margin percentiles", np.percentile(margin,[1,5,25,50,75,95]).round(2), "logit scale", np.abs(logits).mean().round(1))
Mc = M[:, :64] - M[:, :64].mean(0, keepdims=True)
print("sv of centered M:", np.linalg.svd(Mc, compute_uv=False).round(1))
A, s, Bt = np.linalg.svd(Mc, full_matrices=False)
for r in range(1,8):
    Mr = (A[:, :r]*s[:r]) @ Bt[:r]
    Mr = np.concatenate([Mr, np.zeros((64,1))], axis=1)
    Yr = Mr[:, X].sum(2).argmax(0)
    ok = Yr==Y
    print(r, ok.mean().round(4), [ok[L==l].mean().round(4) for l in range(1,9)])
# Also: optimal shift: minimize rank-r residual over shift in row space of E. Use W centered instead: Wc = W - mean row
