# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 2 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx slots. A slot holds a token, a whole number from 0 to d_vocab - 1, or it is empty,
which is written as the number d_vocab. An input has at least one token; its tokens fill the first
slots and the empty slots come after them.

The network has three weight matrices and no biases:

    embed     d_model x (d_vocab + 1)    its last column, the empty slot's, is all zeros
    hidden    d_model x d_model
    unembed   d_vocab x d_model

It adds up the columns of embed at the input's slots (an empty slot adds nothing), applies hidden,
applies unembed, and its output is the position of the highest of the d_vocab resulting numbers
(the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    h = lv1.take_sum(g.weight("embed"), g.tokens(), axis=1)
    logits = g.weight("unembed") @ (g.weight("hidden") @ h)
    return logits.argmax()
```

Sizes: n_ctx = 8, d_vocab = 64, d_model = 8, outputs: 64. One forward pass of the network costs 703 operations under the prices
below.

## The data set

An input is drawn like this. First a number of tokens is picked from 1 to 8, each equally likely. Then that many tokens are picked, each a whole number from 0 to 63 and equally likely. The tokens fill the first slots and the remaining slots are empty (64). The data set is every input that can be drawn this way, each counted as often as it is drawn: about 2.8 x 10^14 different inputs, far more with eight tokens than with one, yet every number of tokens makes up an eighth of the data set.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.8368 | 1.0000 | 0.99573 | 0.1093 | 0.99600 | 0.97000 |
| r1s2 | scored | 0.8636 | 1.0000 | 0.99500 | 0.0743 | 0.99630 | 0.97000 |
| r1s3 | scored | 0.8699 | 1.0000 | 0.99579 | 0.0768 | 0.99600 | 0.97000 |
| r1s4 | scored | 0.8731 | 1.0000 | 0.99597 | 0.0757 | 0.99600 | 0.97000 |

Notes of that round:

    ## What the network does
    It is a linear "noisy max": logits = U·H·Σ embed[:, tokens], and the output is approximately the largest token. Exact agreement with max is 94.5% overall (L=1: 81% because tokens 0–11 all map to output 10/11; L=3,4: ≥99.5%; L=8: 89%). Outputs 0–9 essentially never occur. When it fails on long inputs, the winner is typically well below the max (rows 30–57, whose unembed rows have the largest norms), and the failures are "needle" events driven by the particular sum of the smaller tokens, not by the second-largest token or by any low-rank structure: rank-7 truncation of the 64×64 logit matrix (even after centering) agrees with the argmax only 86% of the time, and no cheap linear risk score separates the failures. Failures on long inputs concentrate where the max is isolated far above the rest (gap ≥ 21: ~3% error vs 0.02% for gap 0). Sure of all this to the sampling precision used (1–3M random inputs per experiment).
    
    ## How you found it
    Both weights and outputs. Formed M = unembed·hidden·embed (64×65) and computed the network exactly in numpy on millions of drawn inputs; compared against max/min/first/last/sum/mean/median; studied per-length accuracy, per-max-value accuracy, SVD truncations, the joint distribution P(output | max token) by length, and the DP-optimal sets of candidate output rows to evaluate per max-token value (trading 9 ops per row against 10 forward passes per error).
    
    ## The best entry
    `hybrid_v5` (also saved: hybrid_v1…v4). Region: every input. Interpretation: nested `cond` on the number of tokens (tests token(k)==64).
    - L=1: table T1 = argmax of M columns (built from weights).
    - L=2,3,4: table TL_L[mx] = argmax_j (M[j,mx] + (L−1)·mean_{t≤mx} M[j,t]) (built from weights; mx = max of the first L tokens). Errors 0.4%, 0.08%, 0.1%.
    - L=5: plain max of the 5 tokens (1.05% error).
    - L≥6: mx = max(tokens with empties→0); a binary `cond` tree over mx with 20 leaves (mx<36, 36–39, 40–43, 44–47, then one leaf per value 48..63); each leaf computes the exact logits for a small fixed set of output rows (≤3–4 intervals, e.g. mx=60 → rows {22,34,44–49,52–60}) via `take_sum` on slices of the precomputed M, then argmax mapped back through slices of arange(64). ~0.5% error, ~90 ops.
    Saving comes from never computing the full 64-row matmul: cost 0.076 of a forward pass (build 0.007), fidelity 0.996, 326 nodes, 24 constant scalars (none tuned to the weights; only slice bounds encode this network's confusion pattern).
    
    ## Claims
    Claimed 0.996 on this network (measured 0.9958–0.9968 over four samples). Expected 0.97 on the second network: the tables for L≤4 and the mx-tree logits are recomputed from its weights, and max for L=5 should hold if it is also a noisy max, but the leaf row sets (which rows can win for a given max token) were tuned to this network's confusion statistics and may miss more often there.
    
    ## Next
    (1) Check robustness: widen leaf row sets by 1–2 rows where cheap, or derive them from the weights at build (rows whose unembed·hidden rows have large norm), to transfer better. (2) Separate row-set designs for L=6 vs 7–8 (worth ~+0.002) if nodes allow by merging more rare leaves. (3) A cheap second-level split on gap = mx − second max for the top leaves (errors are 10× higher when gap ≥ 21), if the second max can be had for <10 ops. (4) Exact pair table for L=2 instead of TL2 is break-even (build 0.045 vs penalty 0.043); not worth it unless build is amortized over more inputs.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.8731) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
