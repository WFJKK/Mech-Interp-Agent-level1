
import numpy as np, time
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0
Mt=M[:,:64]; Cm=np.cumsum(Mt,axis=1)/(np.arange(64)+1)
S=Mt+Cm; T2=S.argmax(0); S2=S.copy(); S2[T2,np.arange(64)]=-1e18; T2b=S2.argmax(0)
a,b=np.meshgrid(np.arange(64),np.arange(64),indexing='ij'); a=a.ravel(); b=b.ravel()
y2=np.argmax(Mt[:,a]+Mt[:,b],axis=0); mx2=np.maximum(a,b)
l1=Mt[T2[mx2],a]+Mt[T2[mx2],b]; l2=Mt[T2b[mx2],a]+Mt[T2b[mx2],b]
pred=np.where(l1>=l2,T2[mx2],T2b[mx2]); print("L=2 two-row (weights-derived 2nd) err:",np.mean(pred!=y2))
cnt2=np.array([np.bincount(y2[mx2==v],minlength=64) for v in range(64)])
emp2=np.array([np.argsort(-cnt2[v])[1] for v in range(64)]); 
l2e=Mt[emp2[mx2],a]+Mt[emp2[mx2],b]; pred2=np.where(l1>=l2e,T2[mx2],emp2[mx2]); print("L=2 two-row (empirical 2nd) err:",np.mean(pred2!=y2))
print("rows<10 anywhere in winners for L=2?",(y2<10).any())
# ---------- data for segmentation
rng=np.random.default_rng(6)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def best_rows(cnt,rowcost,kmax=24):
    n=cnt.sum(); order=np.argsort(-cnt); best=None
    for k in range(1,kmax+1):
        err=1-cnt[order[:k]].sum()/n; cost=rowcost*k+(k-1)+1; obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,[int(r) for r in order[:k]])
    return best
def segment(Ls,rowcost,lam):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64))
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    wv=cnt.sum(1)/N; G={}
    for lo in range(64):
        c=np.zeros(64)
        for hi in range(lo,64):
            c=c+cnt[hi]
            G[(lo,hi)]=(0,[lo]) if c.sum()==0 else (lambda bb:(bb[0]*c.sum()/N,bb[3]))(best_rows(c,rowcost))
    best=[(0,[])]+[None]*64
    for hi in range(64):
        best[hi+1]=min([(best[lo][0]+G[(lo,hi)][0]+lam,best[lo][1]+[(lo,hi)]) for lo in range(hi+1)],key=lambda x:x[0])
    return [(lo,hi,G[(lo,hi)][1],float(wv[lo:hi+1].sum())) for lo,hi in best[64][1]]
P6=segment((6,7,8),8,0.001); P5=segment((5,),5,0.002)
print("min row used:",min(min(p[2]) for p in P6+P5))
import functools
def opt_tree(parts):
    n=len(parts); w=[p[3] for p in parts]
    @functools.lru_cache(None)
    def f(i,j):
        if i==j: return (0.0,i)
        best=None
        for k in range(i,j):
            cl,tl=f(i,k); cr,tr=f(k+1,j); c=cl+cr+sum(w[i:j+1])
            if best is None or c<best[0]: best=(c,(parts[k+1][0],tl,tr))
        return best
    return f(0,n-1)[1]
def build(P6,P5,second_from_weights=True):
    g=graph(); t=g.tokens()
    M54=g.weight("unembed")[10:64]@(g.weight("hidden")@g.weight("embed"))   # 54 x 65
    Mfull=lv1.concat([M54[0:10]*0.0,M54],axis=0)   # rows 0..9 zero
    Mt=M54[:,0:64]
    Cm=lv1.cumsum(Mt,axis=1)/(g.arange(64)+1)
    c10=g.const(10)
    T1=Mt.argmax(axis=0)+c10; S=Mt+Cm; T2=S.argmax(axis=0)+c10; T3=(Mt+2.0*Cm).argmax(axis=0)+c10; T4=(Mt+3.0*Cm).argmax(axis=0)+c10
    if second_from_weights:
        mask=(g.arange(54).reshape(54,1)+c10)==T2.reshape(1,64)
        T2b=lv1.where(mask,-1e18,S).argmax(axis=0)+c10
    else:
        T2b=g.const([int(x) for x in emp2])
    allparts=[('6',p) for p in P6]+[('5',p) for p in P5]
    packed=[]; slots={}
    for idx,(kind,p) in enumerate(allparts):
        rows=p[2]; start=len(packed)*8
        for c in range(0,len(rows),8):
            chunk=rows[c:c+8]; packed.append(int(sum(r*64**i for i,r in enumerate(chunk))))
        slots[idx]=(start,start+len(rows))
    pk=g.const(packed); pw=g.const([64**i for i in range(8)])
    R=lv1.cast((pk.reshape(len(packed),1)//pw.reshape(1,8))%64,"int")
    Rflat=R.reshape(len(packed)*8)
    def leaf(idx,tok):
        a_,b_=slots[idx]; rows=Rflat[a_:b_]
        Mi=lv1.take(Mfull,rows,axis=0)
        lg=lv1.take_sum(Mi,tok,axis=1)
        return rows[lg.argmax()]
    def tree(node,mx,tok,offset):
        if isinstance(node,int): return leaf(node+offset,tok)
        thr,l,r=node
        return lv1.cond(mx<thr,tree(l,mx,tok,offset),tree(r,mx,tok,offset))
    c64=g.const(64)
    t0,t1,t2,t3,t4,t5,t6,t7=[g.token(i) for i in range(8)]
    o1=T1[t0]
    mx2=lv1.maximum(t0,t1); r1=T2[mx2]; r2=T2b[mx2]
    l1=Mfull[r1,t0]+Mfull[r1,t1]; l2=Mfull[r2,t0]+Mfull[r2,t1]
    o2=lv1.where(l1>=l2,r1,r2)
    o3=T3[lv1.maximum(mx2,t2)]; o4=T4[lv1.maximum(mx2,lv1.maximum(t2,t3))]
    low=lv1.cond(t2==c64, lv1.cond(t1==c64,o1,o2), lv1.cond(t3==c64,o3,o4))
    tok5=t[0:5]; mx5=tok5.max()
    o5=tree(opt_tree(P5),mx5,tok5,len(P6))
    mx6=lv1.maximum(lv1.maximum(t[0:6].max(),t6%c64),t7%c64)
    o6=tree(opt_tree(P6),mx6,t,0)
    high=lv1.cond(t5==c64,o5,o6)
    out=lv1.cond(t4==c64,low,high)
    return g.entry(interpretation=out)
ent=build(P6,P5,True)
print("nodes",len(ent['nodes']))
m=measure(ent); print({k:m[k] for k in ('fidelity','cost','b','r','reward','build_ops')})
save_entry("v2b",ent)
ev=lv1.Evaluator(ent,weights,8); rng2=np.random.default_rng(123)
tot=0
for L in range(1,9):
    T=np.full((5000,8),64); T[:,:L]=rng2.integers(0,64,(5000,L)); y=net(T); ops=0; err=0
    for x,tr in zip(T,y):
        ins,a_,cr,cp=ev.run(x); ops+=cp+cr; err+=int(a_!=tr)
    obj=ops/5000/FP+10*err/5000; tot+=obj/8
    print(f"L={L} err={err/5000:.4f} ops={ops/5000:.1f} obj={obj:.4f}")
print("expected reward ~",1-tot-m['b'])
