
import numpy as np, json
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(1)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def logits(T): return (W@E[:,T].sum(axis=2)).T  # N x 64
# pooled L=6,7,8
T=np.concatenate([draw(L,700_000) for L in (6,7,8)]); Lc=np.repeat([6,7,8],700_000)
Z=logits(T); y=Z.argmax(1); mx=np.where(T==64,0,T).max(1)
tot=len(T)
# For each leaf mx>=48: choose base set C = rows with P(win|mx) > thr ; evaluate stage-2 signal
for v in [52,56,58,60,62,63]:
    sel=mx==v; Zs=Z[sel]; ys=y[sel]; n=sel.sum()
    vals,cnt=np.unique(ys,return_counts=True); p=cnt/n
    C=vals[p>0.00114]; 
    inC=np.isin(ys,C)
    j1=C[Zs[:,C].argmax(1)]
    # margin of mx over best other candidate
    others=[c for c in C if c!=v]
    marg=Zs[:,v]-Zs[:,others].max(1)
    err=~inC
    print(f"mx={v} n={n} |C|={len(C)} err={err.mean():.4f}  P(j1!=mx)={np.mean(j1!=v):.3f}  P(err|j1!=mx)={err[j1!=v].mean():.4f} P(err|j1==mx)={err[j1==v].mean():.4f}")
    # margin quantiles for err vs ok
    print("   margin err q:",np.round(np.quantile(marg[err],[.1,.5,.9]),1)," ok q:",np.round(np.quantile(marg[~err],[.05,.1,.25,.5]),1))
    # if we evaluate on inputs with marg<thr the full argmax, what frac triggers & residual err
    for thr in [2,5,10]:
        trig=marg<thr; print(f"   thr={thr}: trig={trig.mean():.3f} resid_err={(err&~trig).mean():.4f}")
