
import inspect
print(inspect.signature(lv1.measure)); print(inspect.getsource(lv1.measure)[:3000])
print(inspect.signature(lv1.Evaluator.__init__))
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
print(inspect.signature(lv1.apply)); print(inspect.getsource(lv1.apply)[:1500])
print(inspect.signature(lv1.draw_inputs))
