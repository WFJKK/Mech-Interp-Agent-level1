
import numpy as np, time, pickle, os
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(2)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def logits(T): return (E[:,T].sum(axis=2).T@W.T)
FP=703.0
def design_leaf(Z,y,v,k1s=range(1,9),thrs=(-1e9,-5,0,2,4,6,8,10,13,16,20,25,30,40),verbose=False):
    """Z: n x 64 logits, y winners, v = mx row. Returns best design dict and also one-stage baseline."""
    n=len(y); vals,cnt=np.unique(y,return_counts=True); p=dict(zip(vals,cnt/n))
    order=[r for r in vals[np.argsort(-cnt)] if r!=v]
    # one-stage baseline
    best1=None
    for k in range(1,25):
        C=[v]+order[:k-1]; err=1-sum(p.get(r,0) for r in C); cost=8*k+(k-1)
        obj=cost/FP+10*err
        if best1 is None or obj<best1[0]: best1=(obj,k,err,cost)
    best=None
    for k1 in k1s:
        C1=[v]+order[:k1-1]
        lv=Z[:,v]
        mo=Z[:,C1[1:]].max(1) if k1>1 else np.full(n,-1e9)
        marg=lv-mo
        for thr in thrs:
            trig=marg<=thr; pt=trig.mean()
            err_a=np.mean(~trig & (y!=v))
            # stage2 rows: among triggered, rows not in C1
            if pt>0:
                yt=y[trig]; vals2,cnt2=np.unique(yt,return_counts=True)
                cand=[(r,c/n) for r,c in zip(vals2,cnt2) if r not in C1]
                cand.sort(key=lambda x:-x[1])
                C2=[r for r,q in cand if 10*q>9/FP]
                err_b=sum(q for r,q in cand if r not in C2)
            else: C2=[]; err_b=0
            k2=len(C2)
            cost=8*k1+(k1-2 if k1>1 else 0)+3+pt*(8*k2+(k1+k2-1)+2)
            obj=cost/FP+10*(err_a+err_b)
            if best is None or obj<best[0]: best=(obj,k1,thr,C2,err_a+err_b,cost,pt)
    return best,best1
res={}
T=np.concatenate([draw(L,600_000) for L in (6,7,8)]); Lc=np.repeat([6,7,8],600_000)
mx=np.where(T==64,0,T).max(1)
tot=len(T); sum_obj2=0; sum_obj1=0
for v in range(64):
    sel=mx==v
    if sel.sum()<2000: continue
    Z=logits(T[sel]); y=Z.argmax(1)
    b,b1=design_leaf(Z,y,v)
    w=sel.mean()
    sum_obj2+=w*b[0]; sum_obj1+=w*b1[0]
    res[v]=(b,b1,w)
    if v>=44: print(f"mx={v} w={w:.4f} | 2-stage obj={b[0]:.4f} k1={b[1]} thr={b[2]} k2={len(b[3])} err={b[4]:.4f} cost={b[5]:.1f} ptrig={b[6]:.3f} | 1-stage obj={b1[0]:.4f} k={b1[1]} err={b1[2]:.4f}")
print("weighted obj (L>=6): two-stage",sum_obj2,"one-stage",sum_obj1, "(reward diff*3/8:",(sum_obj1-sum_obj2)*3/8,")")
