
import numpy as np, functools
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0; PEN=11.85
Mt_np=M[:,:64]
a,b=np.meshgrid(np.arange(64),np.arange(64),indexing='ij'); a=a.ravel(); b=b.ravel()
y2=np.argmax(Mt_np[:,a]+Mt_np[:,b],axis=0); mx2=np.maximum(a,b)
cnt2=np.array([np.bincount(y2[mx2==v],minlength=64) for v in range(64)])
emp2=[int(np.argsort(-cnt2[v])[1]) for v in range(64)]
rng=np.random.default_rng(2024)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,2_000_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def best_rows(cnt,rowcost,kmax=24):
    n=cnt.sum(); order=np.argsort(-cnt); best=None
    for k in range(1,kmax+1):
        err=1-cnt[order[:k]].sum()/n; cost=rowcost*k+(k-1)+1; obj=cost/FP+PEN*err
        if best is None or obj<best[0]: best=(obj,k,err,[int(r) for r in order[:k]])
    return best
def segment(Ls,rowcost,lam):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64))
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    wv=cnt.sum(1)/N; G={}
    for lo in range(64):
        c=np.zeros(64)
        for hi in range(lo,64):
            c=c+cnt[hi]
            G[(lo,hi)]=(0,[lo]) if c.sum()==0 else (lambda bb:(bb[0]*c.sum()/N,bb[3]))(best_rows(c,rowcost))
    best=[(0,[])]+[None]*64
    for hi in range(64):
        best[hi+1]=min([(best[lo][0]+G[(lo,hi)][0]+lam,best[lo][1]+[(lo,hi)]) for lo in range(hi+1)],key=lambda x:x[0])
    return [(lo,hi,G[(lo,hi)][1],float(wv[lo:hi+1].sum())) for lo,hi in best[64][1]]
def opt_tree(parts):
    n=len(parts); w=[p[3] for p in parts]
    @functools.lru_cache(None)
    def f(i,j):
        if i==j: return (0.0,i)
        best=None
        for k in range(i,j):
            cl,tl=f(i,k); cr,tr=f(k+1,j); c=cl+cr+sum(w[i:j+1])
            if best is None or c<best[0]: best=(c,(parts[k+1][0],tl,tr))
        return best
    return f(0,n-1)[1]
def build(P6,P5):
    g=graph(); t=g.tokens(); consts={}
    def K(v):
        if v not in consts: consts[v]=g.const(v)
        return consts[v]
    M54=g.weight("unembed")[10:64]@(g.weight("hidden")@g.weight("embed"))
    Mfull=lv1.concat([M54[0:10]*0.0,M54],axis=0); Mt=M54[:,0:64]
    Cm=lv1.cumsum(Mt,axis=1)/(g.arange(64)+1)
    c10=K(10); S=Mt+Cm; S3=S+Cm; S4=S3+Cm
    T1=Mt.argmax(axis=0)+c10; T2=S.argmax(axis=0)+c10; T3=S3.argmax(axis=0)+c10; T4=S4.argmax(axis=0)+c10
    T2b=g.const(emp2)
    allparts=[('6',p) for p in P6]+[('5',p) for p in P5]
    packed=[]; slots={}
    for idx,(kind,p) in enumerate(allparts):
        rows=p[2]; start=len(packed)*8
        for c in range(0,len(rows),8):
            chunk=rows[c:c+8]; packed.append(int(sum(r*64**i for i,r in enumerate(chunk))))
        slots[idx]=(start,start+len(rows))
    pk=g.const(packed); pw=g.const([64**i for i in range(8)])
    R=lv1.cast((pk.reshape(len(packed),1)//pw.reshape(1,8))%64,"int"); Rflat=R.reshape(len(packed)*8)
    def leaf(idx,tok):
        a_,b_=slots[idx]; rows=Rflat[a_:b_]
        return rows[lv1.take_sum(lv1.take(Mfull,rows,axis=0),tok,axis=1).argmax()]
    def tree(node,mx,tok,offset):
        if isinstance(node,int): return leaf(node+offset,tok)
        thr,l,r=node
        return lv1.cond(mx<K(thr),tree(l,mx,tok,offset),tree(r,mx,tok,offset))
    c64=K(64); t0,t1,t2,t3,t4,t5,t6,t7=[g.token(i) for i in range(8)]
    o1=T1[t0]
    mx2=lv1.maximum(t0,t1); r1=T2[mx2]; r2=T2b[mx2]
    l1=Mfull[r1,t0]+Mfull[r1,t1]; l2=Mfull[r2,t0]+Mfull[r2,t1]
    o2=lv1.where(l1>=l2,r1,r2)
    o3=T3[lv1.maximum(mx2,t2)]; o4=T4[lv1.maximum(mx2,lv1.maximum(t2,t3))]
    low=lv1.cond(t2==c64, lv1.cond(t1==c64,o1,o2), lv1.cond(t3==c64,o3,o4))
    tok5=t[0:5]; o5=tree(opt_tree(P5),tok5.max(),tok5,len(P6))
    mx6=lv1.maximum(lv1.maximum(t[0:6].max(),t6%c64),t7%c64); o6=tree(opt_tree(P6),mx6,t,0)
    return g.entry(interpretation=lv1.cond(t5==c64, lv1.cond(t4==c64,low,o5), o6))
P6=segment((6,7,8),8,0.001); P5=segment((5,),5,0.0015)
ent=build(P6,P5); print("nodes",len(ent['nodes']),"leaves",len(P6),len(P5))
if len(ent['nodes'])>400:
    P5=segment((5,),5,0.002); ent=build(P6,P5); print("fallback nodes",len(ent['nodes']))
m=measure(ent); print({k:m[k] for k in ('fidelity','cost','b','reward')})
save_entry("v2e",ent)
# held-out comparison v2d vs v2e on the same inputs, per length
rng2=np.random.default_rng(4242); evs={'v2d':lv1.Evaluator(entries['v2d'],weights,8),'v2e':lv1.Evaluator(ent,weights,8)}
tot={'v2d':0,'v2e':0}
for L in range(1,9):
    T=np.full((6000,8),64); T[:,:L]=rng2.integers(0,64,(6000,L)); y=net(T)
    for name,ev in evs.items():
        ops=0; err=0
        for x,tr in zip(T,y):
            ins,a_,cr,cp=ev.run(x); ops+=cp+cr; err+=int(a_!=tr)
        obj=ops/6000/FP+10*err/6000; tot[name]+=obj/8
        print(f"{name} L={L} err={err/6000:.4f} ops={ops/6000:.1f}", end=" | ")
    print()
print("held-out expected reward: v2d",1-tot['v2d']-0.0078,"v2e",1-tot['v2e']-m['b'])
# edge cases: refusal risk
ev=evs['v2e']
edge=[[0]*8,[63]*8,[63]+[64]*7,[0]+[64]*7,[63,63]+[64]*6,[0,63,0,63,0,63,0,63],[10,11,12,13,14,15,16,17],[63,62,61,60,59,58,57,56],[47,47,47,47,47,64,64,64],[35,36]+[64]*6]
for x in edge:
    ins,a_,cr,cp=ev.run(np.array(x)); print(x,"->",a_,"true",net(np.array([x]))[0],"ops",cp)
