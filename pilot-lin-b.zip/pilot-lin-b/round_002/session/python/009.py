
import numpy as np, pickle
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(5)
FP=703.0
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def logits(T): return (E[:,T].sum(axis=2).T@W.T)
# tables TL_k[mx] = argmax_j M[j,mx] + (k-1)*mean_{t<=mx} M[j,t]
C=np.cumsum(M[:,:64],axis=1)/(np.arange(64)+1)
TL={k:np.argmax(M[:,:64]+(k-1)*C,axis=0) for k in range(1,9)}
data={}
for L in (5,6,7,8):
    T=draw(L,1_200_000); Z=logits(T); y=Z.argmax(1); mx=np.where(T==64,0,T).max(1)
    data[L]=(T,Z.astype(np.float32),y,mx)
def one_stage(y,v,rowcost,kmax=30):
    n=len(y); vals,cnt=np.unique(y,return_counts=True); p=cnt/n
    pv=p[vals==v][0] if v in vals else 0
    others=sorted([(r,q) for r,q in zip(vals,p) if r!=v],key=lambda x:-x[1])
    best=None
    for k in range(1,kmax):
        err=1-pv-sum(q for r,q in others[:k-1]); cost=rowcost*k+(k-1)+1
        obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,[v]+[r for r,q in others[:k-1]])
    return best
def two_stage(Z,y,v,rowcost):
    n=len(y); vals,cnt=np.unique(y,return_counts=True); p=cnt/n
    others=[r for r in vals[np.argsort(-cnt)] if r!=v]
    best=None
    for k1 in range(2,10):
        C1=[v]+others[:k1-1]; marg=Z[:,v]-Z[:,C1[1:]].max(1)
        for thr in np.arange(-6,60,2):
            trig=marg<=thr; pt=trig.mean(); err_a=np.mean(~trig&(y!=v))
            yt=y[trig]; vals2,cnt2=np.unique(yt,return_counts=True)
            cand=sorted([(r,c/n) for r,c in zip(vals2,cnt2) if r not in C1],key=lambda x:-x[1])
            C2=[r for r,q in cand if 10*q>(rowcost+1)/FP]; err_b=sum(q for r,q in cand if r not in C2)
            k2=len(C2); cost=rowcost*k1+(k1-2)+3+pt*(rowcost*k2+(k1+k2-1)+2)
            obj=cost/FP+10*(err_a+err_b)
            if best is None or obj<best[0]: best=(obj,k1,int(thr),C1,C2,err_a+err_b,cost,pt)
    return best
design={}
for name,Ls,rowcost in [("L6",(6,7,8),8),("L5",(5,),5)]:
    ys=np.concatenate([data[L][2] for L in Ls]); mxs=np.concatenate([data[L][3] for L in Ls]); Zs=np.concatenate([data[L][1] for L in Ls])
    tabk=7 if name=="L6" else 5
    print(name)
    tot=0; leaves={}
    for v in range(64):
        sel=mxs==v; w=sel.mean(); yv=ys[sel]
        e_tab=np.mean(yv!=TL[tabk][v]) if sel.sum() else 0
        e_max=np.mean(yv!=v) if sel.sum() else 0
        if sel.sum()<400: leaves[v]=("tab",w,10*e_tab,e_tab); tot+=w*10*e_tab; continue
        b1=one_stage(yv,v,rowcost); b2=two_stage(Zs[sel],yv,v,rowcost)
        opts=[("tab",10*e_tab+1/FP),("one",b1[0]),("two",b2[0])]
        kind,obj=min(opts,key=lambda x:x[1])
        leaves[v]=(kind,w,obj,e_tab,b1,b2); tot+=w*obj
        if v>=36: print(f" v={v} w={w:.4f} tab_err={e_tab:.4f} max_err={e_max:.4f} one:k={b1[1]} obj={b1[0]:.4f} err={b1[2]:.4f} two:k1={b2[1]} thr={b2[2]} k2={len(b2[4])} obj={b2[0]:.4f} err={b2[5]:.4f} -> {kind}")
    print(name,"total obj",tot)
    design[name]=leaves
pickle.dump(design,open("tmp/design.pkl","wb"))
