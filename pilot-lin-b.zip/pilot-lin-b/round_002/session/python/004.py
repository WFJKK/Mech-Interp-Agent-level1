
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
np.set_printoptions(linewidth=200, precision=1, suppress=True)
print("M[:,62] (response of each row to token 62):"); print(M[:,62])
print("M[:,48]:"); print(M[:,48])
print("M[22,:] (row 22 across tokens):"); print(M[22,:64])
print("M[62,:]:"); print(M[62,:64])
print("M[36,:]:"); print(M[36,:64])
# SVD of E and W
print("sv E",np.linalg.svd(E[:,:64],compute_uv=False)); print("sv W",np.linalg.svd(W,compute_uv=False))
# does the entry best have a structure? print node count and a summary of the json
b=entries['best']; print(type(b), list(b.keys()) if isinstance(b,dict) else None)
s=json.dumps(b); print(len(s)); print(s[:1500])
