
import numpy as np, functools, pickle
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0
rng=np.random.default_rng(6)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def best_rows(cnt,rowcost,kmax=24):
    n=cnt.sum(); order=np.argsort(-cnt); best=None
    for k in range(1,kmax+1):
        err=1-cnt[order[:k]].sum()/n; cost=rowcost*k+(k-1)+1; obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,[int(r) for r in order[:k]])
    return best
def counts(Ls):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64))
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    return cnt,N
def segment(Ls,rowcost,lam):
    cnt,N=counts(Ls); wv=cnt.sum(1)/N; G={}
    for lo in range(64):
        c=np.zeros(64)
        for hi in range(lo,64):
            c=c+cnt[hi]
            G[(lo,hi)]=(0,[lo]) if c.sum()==0 else (lambda bb:(bb[0]*c.sum()/N,bb[3]))(best_rows(c,rowcost))
    best=[(0,[])]+[None]*64
    for hi in range(64):
        best[hi+1]=min([(best[lo][0]+G[(lo,hi)][0]+lam,best[lo][1]+[(lo,hi)]) for lo in range(hi+1)],key=lambda x:x[0])
    parts=[(lo,hi,G[(lo,hi)][1],float(wv[lo:hi+1].sum())) for lo,hi in best[64][1]]
    return sum(G[(lo,hi)][0] for lo,hi,_,_ in parts),parts
c6,N6=counts((6,)); c78,N78=counts((7,8)); cp,Np=counts((6,7,8))
for lam6 in (0.001,0.0005):
    o6,p6=segment((6,7,8),8,lam6)
    print("lam6",lam6,"leaves",len(p6),"obj",round(o6,4))
    gains=[]
    for lo,hi,rows,w in p6:
        cpool=cp[lo:hi+1].sum(0); n=cpool.sum()
        bp=best_rows(cpool,8); 
        b6=best_rows(c6[lo:hi+1].sum(0),6); b78=best_rows(c78[lo:hi+1].sum(0),8)
        n6=c6[lo:hi+1].sum(); n78=c78[lo:hi+1].sum()
        split_obj=(n6*b6[0]+n78*b78[0])/(n6+n78)+2/FP
        gain=w*(bp[0]-split_obj)*3/8
        gains.append((gain,lo,hi,len(rows),b6[1],b78[1]))
    gains.sort(reverse=True)
    print(" top split gains (reward):",[(round(g,5),lo,hi,k,k6,k78) for g,lo,hi,k,k6,k78 in gains[:8]])
    print(" total gain if all split:",round(sum(g for g,*_ in gains),4))
for lam5 in (0.002,0.0015,0.001):
    o5,p5=segment((5,),5,lam5); print("lam5",lam5,"leaves",len(p5),"obj",round(o5,4),"reward delta vs 0.002:",round((0.0762-o5)/8,4))
