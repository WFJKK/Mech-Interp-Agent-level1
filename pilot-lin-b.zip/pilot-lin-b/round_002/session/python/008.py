
import numpy as np
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(4)
FP=703.0
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
def one_stage(y,v,rowcost,extra,kmax=30):
    n=len(y); vals,cnt=np.unique(y,return_counts=True); p=cnt/n
    order=[(r,q) for r,q in zip(vals,p)]; order.sort(key=lambda x:-x[1])
    pv=p[vals==v][0] if v in vals else 0
    others=[(r,q) for r,q in order if r!=v]
    best=None
    for k in range(1,kmax):
        C=[v]+[r for r,q in others[:k-1]]
        err=1-pv-sum(q for r,q in others[:k-1])
        cost=rowcost*k+(k-1)+extra
        obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,C)
    return best
# Data
res={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1)
    res[L]=(y,mx)
def leafobj(Ls,rowcost,extra):
    tot=0; rows=set(); n=0
    ys=np.concatenate([res[L][0] for L in Ls]); mxs=np.concatenate([res[L][1] for L in Ls])
    for v in range(64):
        sel=mxs==v; w=sel.mean()
        if sel.sum()<300: tot+=w*10*np.mean(ys[sel]!=v) if sel.sum()>0 else 0; continue
        b=one_stage(ys[sel],v,rowcost,extra); tot+=w*b[0]; rows|=set(b[3])
    return tot,len(rows)
for rc,ex,name in [(8,0,"rows@8"),(4,8,"pair@4+8")]:
    pooled,nr=leafobj((6,7,8),rc,ex)
    perL=[leafobj((L,),rc,ex) for L in (6,7,8)]
    l5=leafobj((5,),rc,ex)
    print(name,"L>=6 pooled obj",round(pooled,4),"rows",nr," per-L objs",[round(x[0],4) for x in perL],"mean",round(np.mean([x[0] for x in perL]),4)," L=5 obj",round(l5[0],4),"rows",l5[1])
# L=5 baseline: max only
y,mx=res[5]; print("L=5 max-only err",np.mean(y!=mx))
# also per-mx error of max for L=5
for v in [40,48,52,56,60,63]: sel=mx==v; print(v, round(np.mean(y[sel]!=v),4), end=" | ")
