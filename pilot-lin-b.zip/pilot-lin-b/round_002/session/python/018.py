
import numpy as np, functools
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0
rng=np.random.default_rng(6)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def counts(Ls):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64))
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    return cnt,N
def best_rows_dyn(c_tail,n,rowcost,kmax=24):
    # c_tail: counts of winners != mx (64-vector), n = total inputs in group; mx row is free (already computed)
    order=np.argsort(-c_tail); best=None
    for k in range(0,kmax+1):
        err=(c_tail.sum()-c_tail[order[:k]].sum())/n; cost=rowcost*k+k+1  # k static rows, argmax over k+1, gather
        obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,[int(r) for r in order[:k]])
    return best
def segment_dyn(Ls,rowcost,lam,fixed):
    cnt,N=counts(Ls); wv=cnt.sum(1)/N; G={}
    for lo in range(64):
        c=np.zeros(64); n=0
        for hi in range(lo,64):
            ch=cnt[hi].copy(); n+=ch.sum(); ch[hi]=0; c=c+ch
            G[(lo,hi)]=(0,[]) if n==0 else (lambda bb:(bb[0]*n/N,bb[3]))(best_rows_dyn(c,n,rowcost))
    best=[(0,[])]+[None]*64
    for hi in range(64):
        best[hi+1]=min([(best[lo][0]+G[(lo,hi)][0]+lam,best[lo][1]+[(lo,hi)]) for lo in range(hi+1)],key=lambda x:x[0])
    parts=[(lo,hi,G[(lo,hi)][1],float(wv[lo:hi+1].sum())) for lo,hi in best[64][1]]
    return sum(G[(lo,hi)][0] for lo,hi,_,_ in parts)+fixed/FP,parts
def tree_cost(parts):
    n=len(parts); w=[p[3] for p in parts]
    @functools.lru_cache(None)
    def f(i,j):
        if i==j: return 0.0
        return min(f(i,k)+f(k+1,j)+sum(w[i:j+1]) for k in range(i,j))
    return 2*f(0,n-1) if n>1 else 0
print("L5 static ref: obj 0.0692 + tree ~7.5 ops (17 leaves, 133 nodes)")
for lam in (0.001,0.002,0.003,0.004):
    o,p=segment_dyn((5,),5,lam,9); print(f"L5 dyn lam={lam}: obj {o:.4f} + tree {tree_cost(p):.1f} ops -> {o+tree_cost(p)/FP:.4f}  leaves {len(p)} nodes {7*len(p)+3*(len(p)-1)}")
print("L6 static ref: obj 0.1551 + tree 8.7 ops -> 0.1675 (25 leaves, 197 nodes)")
for lam in (0.001,0.002,0.003):
    o,p=segment_dyn((6,7,8),8,lam,15); print(f"L6 dyn lam={lam}: obj {o:.4f} + tree {tree_cost(p):.1f} ops -> {o+tree_cost(p)/FP:.4f}  leaves {len(p)} nodes {7*len(p)+3*(len(p)-1)}")
    if lam==0.002: print([(lo,hi,len(r)) for lo,hi,r,w in p])
