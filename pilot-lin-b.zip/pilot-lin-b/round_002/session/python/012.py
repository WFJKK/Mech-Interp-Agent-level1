
import numpy as np, itertools
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0
Mt=M[:,:64]; Cm=np.cumsum(Mt,axis=1)/(np.arange(64)+1)
TL={k:np.argmax(Mt+(k-1)*Cm,axis=0) for k in range(1,9)}
# (a) L=2 exact over all pairs
a,b=np.meshgrid(np.arange(64),np.arange(64),indexing='ij'); a=a.ravel(); b=b.ravel()
y2=np.argmax(Mt[:,a]+Mt[:,b],axis=0); mx2=np.maximum(a,b)
mode2=np.array([np.bincount(y2[mx2==v],minlength=64).argmax() for v in range(64)])
print("L=2 err TL2:",np.mean(y2!=TL[2][mx2])," mode2:",np.mean(y2!=mode2[mx2]))
# L=2: leaves with rows by mx? error if we evaluate top-k rows given mx (k=2,3,4)
cnt2=np.array([np.bincount(y2[mx2==v],minlength=64) for v in range(64)])
for k in (2,3,4):
    err=0
    for v in range(64):
        top=np.argsort(-cnt2[v])[:k]; err+=cnt2[v].sum()-cnt2[v][top].sum()
    print(f" L=2 top-{k} rows per mx: err={err/4096:.4f}")
rng=np.random.default_rng(7)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
for L in (3,4):
    T=draw(L,2_000_000); y=net(T); mx=T[:,:L].max(1)
    mode=np.array([np.bincount(y[mx==v],minlength=64).argmax() if (mx==v).any() else v for v in range(64)])
    T2=draw(L,1_000_000); yy=net(T2); mm=T2[:,:L].max(1)
    print(f"L={L} err TL:{np.mean(yy!=TL[L][mm]):.5f} mode:{np.mean(yy!=mode[mm]):.5f} max:{np.mean(yy!=mm):.5f}")
# (b) z-score ranking for L>=6 pooled
data={}
for L in (6,7,8):
    T=draw(L,1_000_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
ys=np.concatenate([data[L][0] for L in (6,7,8)]); mxs=np.concatenate([data[L][1] for L in (6,7,8)])
# Gaussian approx: rest = sum of (L-1) tokens uniform in [0,v]; mean mu_v=(L-1)*mean E[:, :v+1], cov = (L-1)*Cov
tot_emp=0; tot_z=0; tot_z_iso=0
for v in range(36,64):
    sel=mxs==v; cnt=np.bincount(ys[sel],minlength=64); n=cnt.sum()
    order=np.argsort(-cnt)
    # k from DP
    best=None
    for k in range(1,20):
        err=1-cnt[order[:k]].sum()/n; obj=(9*k)/FP+10*err
        if best is None or obj<best[0]: best=(obj,k)
    k=best[1]
    Ev=E[:,:v+1]; mu=Ev.mean(1); Cv=np.cov(Ev,bias=True)
    Lm=6.0  # effective (L-1)
    z=np.zeros(64); ziso=np.zeros(64)
    for r in range(64):
        if r==v: z[r]=-1e9; ziso[r]=-1e9; continue
        d=W[r]-W[v]; gap=d@E[:,v]+Lm*(d@mu); s=np.sqrt(Lm*d@Cv@d)+1e-9
        z[r]=gap/s; ziso[r]=gap/(np.linalg.norm(d)+1e-9)
    zs=[v]+list(np.argsort(-z)[:k-1]); zi=[v]+list(np.argsort(-ziso)[:k-1])
    e_emp=1-cnt[order[:k]].sum()/n; e_z=1-cnt[zs].sum()/n; e_zi=1-cnt[zi].sum()/n
    w=sel.mean(); tot_emp+=w*e_emp; tot_z+=w*e_z; tot_z_iso+=w*e_zi
    if v>=56: print(v,k,"emp",sorted(order[:k]),"z",sorted(zs),f"err emp={e_emp:.4f} z={e_z:.4f} ziso={e_zi:.4f}")
print("weighted err (mx>=36): emp",tot_emp,"z",tot_z,"ziso",tot_z_iso)
