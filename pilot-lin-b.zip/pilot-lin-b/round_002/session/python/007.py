
import numpy as np, time
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(3)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
ev=lv1.Evaluator(entries['best'],weights,8)
print("build",ev.build_cost)
t=time.time()
for L in range(1,9):
    T=draw(L,6000); y=net(T); ops=0; err=0
    for x,tr in zip(T,y):
        ins,a,cr,cp=ev.run(x); ops+=cp+cr; err+=int(a!=tr)
    print(f"L={L} err={err/len(T):.4f} ops={ops/len(T):.1f}  loss(obj)={ops/len(T)/703+10*err/len(T):.4f}  t={time.time()-t:.0f}s")
