
import numpy as np, time
print(info['check'], info['sample_size'], info['n_total'])
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
W=U@H; M=W@E
rng=np.random.default_rng(0)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T):
    h=E[:,T].sum(axis=2)  # 8 x N
    return np.argmax(W@h,axis=0)
t=time.time()
stats={}
for L in range(1,9):
    T=draw(L,1_000_000); y=net(T); mx=np.where(T==64,0,T).max(axis=1)
    stats[L]=(T,y,mx)
    print(L,"acc of max:",(y==mx).mean(), "time",time.time()-t)
# per leaf: for L>=6, distribution of winner y given mx
for L in [6,8]:
    T,y,mx=stats[L]
    for v in [40,48,56,60,63]:
        sel=mx==v; ys=y[sel]; vals,cnt=np.unique(ys,return_counts=True)
        o=np.argsort(-cnt); print(L,v,sel.sum(),[(vals[i],round(cnt[i]/sel.sum(),4)) for i in o[:14]])
