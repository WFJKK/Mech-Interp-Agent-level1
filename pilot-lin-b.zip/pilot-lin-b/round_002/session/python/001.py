
import numpy as np, json
print(info.keys() if hasattr(info,'keys') else info)
for k,v in weights.items(): print(k, v.shape)
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
W=U@H  # 64x8
M=W@E   # 64x65
print("embed col norms", np.round(np.linalg.norm(E,axis=0),2))
print("W row norms", np.round(np.linalg.norm(W,axis=1),2))
print("argmax M cols", np.argmax(M[:,:64],axis=0))
print(list(entries.keys()))
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
