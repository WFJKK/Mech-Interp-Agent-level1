
import numpy as np, pickle, os, time
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0
rng=np.random.default_rng(6)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def best_rows(cnt,rowcost,kmax=24):
    n=cnt.sum(); order=np.argsort(-cnt); best=None
    for k in range(1,kmax+1):
        err=1-cnt[order[:k]].sum()/n; cost=rowcost*k+(k-1)+1; obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,[int(r) for r in order[:k]])
    return best
def segment(Ls,rowcost,lam):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64))
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    wv=cnt.sum(1)/N; G={}
    for lo in range(64):
        c=np.zeros(64)
        for hi in range(lo,64):
            c=c+cnt[hi]
            G[(lo,hi)]=(0,[lo]) if c.sum()==0 else (lambda b:(b[0]*c.sum()/N,b[3]))(best_rows(c,rowcost))
    best=[(0,[])]+[None]*64
    for hi in range(64):
        best[hi+1]=min([(best[lo][0]+G[(lo,hi)][0]+lam,best[lo][1]+[(lo,hi)]) for lo in range(hi+1)],key=lambda x:x[0])
    obj,parts=best[64]
    return [(lo,hi,G[(lo,hi)][1],float(wv[lo:hi+1].sum())) for lo,hi in parts]
P6=segment((6,7,8),8,0.001); P5=segment((5,),5,0.002)
print(len(P6),len(P5))
# ---- builder
def opt_tree(parts):
    """optimal alphabetic BST over leaves (weights) minimizing expected depth; returns nested (thr,left,right) or leaf index"""
    n=len(parts); w=[p[3] for p in parts]
    import functools
    @functools.lru_cache(None)
    def f(i,j):  # leaves i..j inclusive
        if i==j: return (0.0,i)
        best=None
        for k in range(i,j):  # split: leaves i..k left, k+1..j right ; threshold = parts[k+1].lo
            cl,tl=f(i,k); cr,tr=f(k+1,j); c=cl+cr+sum(w[i:j+1])
            if best is None or c<best[0]: best=(c,(parts[k+1][0],tl,tr))
        return best
    return f(0,n-1)[1]
def build(P6,P5):
    g=graph(); t=g.tokens()
    Mfull=g.weight("unembed")@(g.weight("hidden")@g.weight("embed"))
    Mt=Mfull[:,0:64]
    Cm=lv1.cumsum(Mt,axis=1)/(g.arange(64)+1)
    T1=Mt.argmax(axis=0); T2=(Mt+Cm).argmax(axis=0); T3=(Mt+2.0*Cm).argmax(axis=0); T4=(Mt+3.0*Cm).argmax(axis=0)
    # pack rows
    allparts=[('6',p) for p in P6]+[('5',p) for p in P5]
    packed=[]; slots={}
    for idx,(kind,p) in enumerate(allparts):
        rows=p[2]; start=len(packed)*8
        for c in range(0,len(rows),8):
            chunk=rows[c:c+8]; packed.append(int(sum(r*64**i for i,r in enumerate(chunk))))
        slots[idx]=(start,start+len(rows))
    pk=g.const(packed); pw=g.const([64**i for i in range(8)])
    R=lv1.cast((pk.reshape(len(packed),1)//pw.reshape(1,8))%64,"int")
    Rflat=R.reshape(len(packed)*8)
    def leaf(idx,tok):
        a,b=slots[idx]; rows=Rflat[a:b]
        Mi=lv1.take(Mfull,rows,axis=0)
        lg=lv1.take_sum(Mi,tok,axis=1)
        return rows[lg.argmax()]
    def tree(node,mx,tok,offset):
        if isinstance(node,int): return leaf(node+offset,tok)
        thr,l,r=node
        return lv1.cond(mx<thr,tree(l,mx,tok,offset),tree(r,mx,tok,offset))
    c64=g.const(64)
    t0,t1,t2,t3,t4,t5,t6,t7=[g.token(i) for i in range(8)]
    # L<=4
    o1=T1[t0]; o2=T2[lv1.maximum(t0,t1)]; o3=T3[lv1.maximum(lv1.maximum(t0,t1),t2)]; o4=T4[lv1.maximum(lv1.maximum(t0,t1),lv1.maximum(t2,t3))]
    low=lv1.cond(t2==c64, lv1.cond(t1==c64,o1,o2), lv1.cond(t3==c64,o3,o4))
    # L=5
    tok5=t[0:5]; mx5=tok5.max()
    o5=tree(opt_tree(P5),mx5,tok5,len(P6))
    # L>=6
    mx6=lv1.maximum(lv1.maximum(t[0:6].max(),t6%c64),t7%c64)
    o6=tree(opt_tree(P6),mx6,t,0)
    high=lv1.cond(t5==c64,o5,o6)
    out=lv1.cond(t4==c64,low,high)
    return g.entry(interpretation=out)
ent=build(P6,P5)
print("nodes",len(ent['nodes']))
t=time.time(); m=measure(ent); print(m, time.time()-t)
save_entry("v2a",ent)
# per-length check on fresh inputs
ev=lv1.Evaluator(ent,weights,8); rng2=np.random.default_rng(99)
for L in range(1,9):
    T=np.full((4000,8),64); T[:,:L]=rng2.integers(0,64,(4000,L)); y=net(T); ops=0; err=0
    for x,tr in zip(T,y):
        ins,a,cr,cp=ev.run(x); ops+=cp+cr; err+=int(a!=tr)
    print(f"L={L} err={err/4000:.4f} ops={ops/4000:.1f} obj={ops/4000/FP+10*err/4000:.4f}")
