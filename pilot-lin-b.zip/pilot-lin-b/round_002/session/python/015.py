
import numpy as np, functools
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
FP=703.0
rng=np.random.default_rng(6)
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def best_rows(cnt,rowcost,kmax=24):
    n=cnt.sum(); order=np.argsort(-cnt); best=None
    for k in range(1,kmax+1):
        err=1-cnt[order[:k]].sum()/n; cost=rowcost*k+(k-1)+1; obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,[int(r) for r in order[:k]])
    return best
def segment(Ls,rowcost,lam):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64))
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    wv=cnt.sum(1)/N; G={}
    for lo in range(64):
        c=np.zeros(64)
        for hi in range(lo,64):
            c=c+cnt[hi]
            G[(lo,hi)]=(0,[lo]) if c.sum()==0 else (lambda bb:(bb[0]*c.sum()/N,bb[3]))(best_rows(c,rowcost))
    best=[(0,[])]+[None]*64
    for hi in range(64):
        best[hi+1]=min([(best[lo][0]+G[(lo,hi)][0]+lam,best[lo][1]+[(lo,hi)]) for lo in range(hi+1)],key=lambda x:x[0])
    parts=[(lo,hi,G[(lo,hi)][1],float(wv[lo:hi+1].sum())) for lo,hi in best[64][1]]
    obj=sum(G[(lo,hi)][0] for lo,hi,_,_ in parts)
    return obj,parts
def tree_depth_cost(parts):
    n=len(parts); w=[p[3] for p in parts]
    @functools.lru_cache(None)
    def f(i,j):
        if i==j: return 0.0
        return min(f(i,k)+f(k+1,j)+sum(w[i:j+1]) for k in range(i,j))
    return 2*f(0,n-1)
# current layout
o5,p5=segment((5,),5,0.002); o6,p6=segment((6,7,8),8,0.001)
cur=(o5+ (4+tree_depth_cost(p5))/FP + 3*(o6+(9+tree_depth_cost(p6))/FP))/4
print(f"current: L5 obj {o5:.4f} ({len(p5)} leaves, tree {tree_depth_cost(p5):.1f} ops)  L6-8 obj {o6:.4f} ({len(p6)} leaves, tree {tree_depth_cost(p6):.1f})  per-L>=5 input obj {cur:.4f}")
for lamA,lamB in [(0.001,0.001),(0.0015,0.001),(0.002,0.001),(0.002,0.0015)]:
    oA,pA=segment((5,6),6,lamA); oB,pB=segment((7,8),8,lamB)
    new=(2*(oA+(6+tree_depth_cost(pA))/FP)+2*(oB+(8+tree_depth_cost(pB))/FP))/4
    nodes=8*(len(pA)+len(pB))-6
    print(f"A/B lam {lamA}/{lamB}: A obj {oA:.4f} ({len(pA)} leaves) B obj {oB:.4f} ({len(pB)} leaves) per-input obj {new:.4f}  gain reward {(cur-new)/2:.4f} nodes {nodes}")
# also per-L errors implied for B and A
