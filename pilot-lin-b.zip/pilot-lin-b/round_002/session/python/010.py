
import numpy as np, pickle
E=weights['embed']; H=weights['hidden']; U=weights['unembed']; W=U@H; M=W@E
rng=np.random.default_rng(6)
FP=703.0
def draw(L,N):
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T): return (E[:,T].sum(axis=2).T@W.T).argmax(1)
data={}
for L in (5,6,7,8):
    T=draw(L,1_500_000); y=net(T); mx=np.where(T==64,0,T).max(1); data[L]=(y,mx)
def best_rows(cnt,rowcost,kmax=24):
    # cnt: 64-vector of winner counts in this leaf (pooled); choose k top rows
    n=cnt.sum(); order=np.argsort(-cnt); best=None
    for k in range(1,kmax+1):
        err=1-cnt[order[:k]].sum()/n; cost=rowcost*k+(k-1)+1
        obj=cost/FP+10*err
        if best is None or obj<best[0]: best=(obj,k,err,list(order[:k]))
    return best
def segment(Ls,rowcost,lam):
    ys=np.concatenate([data[L][0] for L in Ls]); mxs=np.concatenate([data[L][1] for L in Ls]); N=len(ys)
    cnt=np.zeros((64,64)); 
    for v in range(64):
        sel=mxs==v
        if sel.any(): cnt[v]=np.bincount(ys[sel],minlength=64)
    wv=cnt.sum(1)/N
    # cost of group [lo,hi]
    G={}
    for lo in range(64):
        c=np.zeros(64)
        for hi in range(lo,64):
            c=c+cnt[hi]
            if c.sum()==0: G[(lo,hi)]=(0,[]); continue
            b=best_rows(c,rowcost); G[(lo,hi)]=(b[0]*c.sum()/N,b[3])
    # DP
    best=[(0,[])]+[None]*64
    for hi in range(64):
        cands=[]
        for lo in range(hi+1):
            prev=best[lo]; cands.append((prev[0]+G[(lo,hi)][0]+lam,prev[1]+[(lo,hi)]))
        best[hi+1]=min(cands,key=lambda x:x[0])
    obj,parts=best[64]
    return obj-lam*len(parts),[(lo,hi,G[(lo,hi)][1],round(wv[lo:hi+1].sum(),4)) for lo,hi,*_ in parts]
for lam in [0.0005,0.001,0.002]:
    obj,parts=segment((6,7,8),8,lam); print("L>=6 lam",lam,"obj",round(obj,4),"leaves",len(parts),"consts",sum(len(p[2]) for p in parts))
    if lam==0.001: print(parts); P6=parts
for lam in [0.001,0.002,0.004]:
    obj,parts=segment((5,),5,lam); print("L=5 lam",lam,"obj",round(obj,4),"leaves",len(parts),"consts",sum(len(p[2]) for p in parts))
    if lam==0.002: print(parts); P5=parts
pickle.dump((P6,P5),open("tmp/parts.pkl","wb"))
