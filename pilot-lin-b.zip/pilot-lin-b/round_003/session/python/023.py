
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W=U@Hd; M=W@E; FP=703; ALPHA=12.0; NB=32
rng=np.random.default_rng(123)
S={}
for L in [5,6,7,8]:
    N=1_000_000; T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    y=(W@E[:,T].sum(axis=2)).argmax(0); Tt=np.where(T==64,0,T); mx=Tt.max(1); sm=Tt.sum(1)
    S[L]=dict(mx=mx,y=y,r=sm/(mx+1))
def mxfirst(G, lam_nodes, ovh):
    mx=np.concatenate([S[L]['mx'] for L in G]); y=np.concatenate([S[L]['y'] for L in G]); r=np.concatenate([S[L]['r'] for L in G])
    rcv=np.concatenate([np.full(len(S[L]['mx']),L+1) for L in G]); N=len(mx)
    qs=np.quantile(r,np.linspace(0,1,NB+1)[1:-1]); bn=np.searchsorted(qs,r)
    C=np.zeros((64,NB,64)); np.add.at(C,(mx,bn,y),1)
    R=np.zeros((64,NB)); np.add.at(R,(mx,bn),rcv)
    P=np.concatenate([np.zeros((1,NB,64)),np.cumsum(C,axis=0)]); Q=np.concatenate([np.zeros((1,NB)),np.cumsum(R,axis=0)])
    bld=40*N*8/len(G)/16384; lam=lam_nodes*FP*N*8/len(G)
    def leafcost(cnt, rcn):
        n=cnt.sum()
        if n==0: return 0, 0
        rows=cnt*ALPHA*FP>rcn+bld
        return (rcn+bld)*rows.sum()+ALPHA*FP*(n-cnt[rows].sum())+2*n, rows.sum()
    best=np.full(65,np.inf); best[0]=0; arg=[None]*65
    for j in range(1,65):
        for i in range(j):
            cnt=P[j]-P[i]; rcn=Q[j]-Q[i]   # NB x 64, NB
            tot_cnt=cnt.sum(0); tot_rc=rcn.sum()
            c0,_=leafcost(tot_cnt,tot_rc); c0+=3*lam   # unsplit: slice + lt + cond
            cs=np.inf
            cl=np.cumsum(cnt,axis=0); rl=np.cumsum(rcn)
            for s in range(1,NB):
                a,_=leafcost(cl[s-1],rl[s-1]); b,_=leafcost(tot_cnt-cl[s-1],tot_rc-rl[s-1])
                c=a+b+2*tot_cnt.sum()+8*lam   # extra lt+cond ops
                if c<cs: cs=c; sbest=s
            cnode=min(c0,cs)
            tot=best[i]+cnode
            if tot<best[j]: best[j]=tot; arg[j]=(i, cs<c0)
    segs=[]; j=64; nodes=0
    while j>0:
        i,sp=arg[j]; segs.append((i,j-1,sp)); nodes+=8 if sp else 3; j=i
    nseg=len(segs)
    total=best[64]-nodes*lam+(ovh+9)*N+2*np.ceil(np.log2(nseg))*N
    return round(total/(FP*N)*len(G)/8,4), nseg, nodes, sum(1 for s in segs if s[2])
t0=time.time()
for G,ovh in [((5,6),10),((7,8),12)]:
    for lam in [0.00003,0.00002,0.000015,0.00001]:
        print(G,lam,mxfirst(G,lam,ovh))
print(time.time()-t0)
