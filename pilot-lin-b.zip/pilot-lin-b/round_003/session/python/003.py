
import inspect
src = inspect.getsource(lv1.apply)
i = src.find('"gather"'); print(src[i-200:i+1500])
j = src.find('"take_sum"'); print(src[j-100:j+900])
k = src.find('"take"'); print(src[k-100:k+700])
src2 = inspect.getsource(lv1.Evaluator)
r = src2.find('def run'); print(src2[r:r+1500])
