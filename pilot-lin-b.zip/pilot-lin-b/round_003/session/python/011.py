
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W = U@Hd; M = W@E; FP=703
rng=np.random.default_rng(3)
def sample(L,N):
    T = np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
L=8; N=1_000_000
T=sample(L,N); h=E[:,T].sum(axis=2); logits=(W@h).T; y=logits.argmax(1); mx=T.max(1)
def opt_rows(cnt,n,rc=9):
    rows=np.where(cnt*10*FP>rc*n)[0]; return rows, rc*len(rows)*n+10*FP*(n-cnt[rows].sum())
tot_base=0; tot_2s={q:0 for q in [0.1,0.2,0.3,0.5]}; tot_2m={q:0 for q in [0.1,0.2,0.3,0.5]}
for v in range(64):
    sel=np.where(mx==v)[0]; n=len(sel)
    if n==0: continue
    ys=y[sel]; cnt=np.bincount(ys,minlength=64)
    core,bc=opt_rows(cnt,n); tot_base+=bc
    # core logits
    cl=logits[sel][:,core]
    best=cl.max(1); srt=np.sort(cl,1); marg=srt[:,-1]-srt[:,-2] if len(core)>1 else best
    for q in tot_2s:
        for name,stat,acc in [('low',best,tot_2s),('marg',marg,tot_2m)]:
            th=np.quantile(stat,q); trig=stat<th
            # low bucket: extra rows
            c2=np.bincount(ys[trig],minlength=64); c2[core]=0
            extra=np.where(c2*10*FP>9*trig.sum())[0]
            miss_trig=trig.sum()-cnt[core][...].sum()*0  # compute properly
            covered_trig=np.bincount(ys[trig],minlength=64)[np.concatenate([core,extra])].sum()
            covered_un=np.bincount(ys[~trig],minlength=64)[core].sum()
            cost=9*len(core)*n+2*n+9*len(extra)*trig.sum()+10*FP*((trig.sum()-covered_trig)+((~trig).sum()-covered_un))
            acc[q]+=cost
print('base',tot_base/N/FP)
for q in tot_2s: print(q,'low',round(tot_2s[q]/N/FP,4),'marg',round(tot_2m[q]/N/FP,4))
