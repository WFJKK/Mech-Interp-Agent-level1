
import numpy as np, time, itertools
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W = U@Hd; M = W@E; FP=703
rng=np.random.default_rng(2)
def sample(L,N):
    T = np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T):
    h = E[:,T].sum(axis=2); return (W@h).argmax(axis=0)
S={}
for L in [5,6,7,8]:
    T=sample(L,1_000_000); y=net(T); Tt=np.where(T==64,0,T)
    mx=Tt.max(1); sm=Tt.sum(1); r=sm/(mx+1)
    S[L]=dict(mx=mx,y=y,r=r)
def seg_dp(C, rc, lam_ops):
    # C: 64(v) x 64(row) counts; returns best cost (ops units per sample-count) and segments
    P=np.vstack([np.zeros((1,64)),np.cumsum(C,axis=0)])
    n_v=64
    # leaf cost for interval [i,j]
    best=np.full(n_v+1,np.inf); best[0]=0; arg=[None]*(n_v+1)
    leafinfo={}
    for j in range(1,n_v+1):
        for i in range(j):
            cnt=P[j]-P[i]; n=cnt.sum()
            if n==0:
                lc=0; rows=[]
            else:
                rows=np.where(cnt*10*FP>rc*n)[0]
                lc=rc*len(rows)*n+10*FP*(n-cnt[rows].sum())
            tot=best[i]+lc+lam_ops
            if tot<best[j]: best[j]=tot; arg[j]=(i,rows)
    segs=[]; j=n_v
    while j>0:
        i,rows=arg[j]; segs.append((i,j-1,list(rows))); j=i
    return best[n_v], segs[::-1]
def design(G, nb, rc, lam_nodes, N_per=None):
    # pooled samples, equal weight per length
    mx=np.concatenate([S[L]['mx'] for L in G]); y=np.concatenate([S[L]['y'] for L in G]); r=np.concatenate([S[L]['r'] for L in G])
    N=len(mx)
    qs=np.quantile(r, np.linspace(0,1,nb+1)[1:-1]) if nb>1 else np.array([])
    b=np.searchsorted(qs,r)
    lam_ops=lam_nodes*FP*N*8/len(G)/3*3  # convert node price (reward units per node) to ops units: reward = ops/(FP*N)*(|G|/8) per sample.. per leaf 3 nodes
    # reward loss per leaf = lam_nodes*3 ; in ops-sum units multiply by FP*N*8/|G|
    lam_ops=lam_nodes*3*FP*N*8/len(G)
    total=0; des=[]; nleaves=0
    for k in range(nb):
        sel=b==k
        C=np.zeros((64,64)); np.add.at(C,(mx[sel],y[sel]),1)
        cost,segs=seg_dp(C,rc,lam_ops)
        # depth cost
        nl=len(segs); depth=2*np.ceil(np.log2(max(nl,1)))
        total+=cost-lam_ops*nl+depth*sel.sum()
        des.append(segs); nleaves+=nl
    stat=(9+7+2)+2*np.ceil(np.log2(max(nb,1)))
    total+=stat*N
    loss=total/(FP*N)*len(G)/8
    nodes=3*nleaves+2*nb
    return loss,nodes,qs,des
t0=time.time()
res={}
for G,rc in [((5,),6),((6,),7),((5,6),7),((7,8),9),((6,7,8),9),((5,6,7,8),9)]:
    for nb in [1,2,3,4]:
        for lam in [0.0001,0.0002,0.0004,0.0008]:
            loss,nodes,qs,des=design(G,nb,rc,lam)
            res[(G,nb,lam)]=(loss,nodes)
            print(G,nb,lam,round(loss,4),nodes)
print(time.time()-t0)
