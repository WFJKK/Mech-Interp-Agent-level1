
import numpy as np, time, json
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W=U@Hd; M=W@E; FP=703
rng=np.random.default_rng(11)
S={}
for L in [5,6,7,8]:
    N=1_000_000; T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    y=(W@E[:,T].sum(axis=2)).argmax(0); Tt=np.where(T==64,0,T); mx=Tt.max(1); sm=Tt.sum(1)
    S[L]=dict(mx=mx,y=y,r=sm/(mx+1))
def seg_dp(Cs, ns_rc, lam_ops):
    P=np.vstack([np.zeros((1,64)),np.cumsum(Cs,axis=0)]); Q=np.concatenate([[0],np.cumsum(ns_rc)])
    best=np.full(65,np.inf); best[0]=0; arg=[None]*65
    for j in range(1,65):
        for i in range(j):
            cnt=P[j]-P[i]; n=cnt.sum(); rcn=Q[j]-Q[i]
            if n==0: lc=0; rows=np.array([],int)
            else:
                rows=np.where(cnt*10*FP>rcn)[0]
                lc=rcn*len(rows)+10*FP*(n-cnt[rows].sum())+2*n
            tot=best[i]+lc+lam_ops
            if tot<best[j]: best[j]=tot; arg[j]=(i,rows)
    segs=[]; j=64
    while j>0:
        i,rows=arg[j]; segs.append((i,j-1,sorted(map(int,rows)))); j=i
    return best[64], segs[::-1]
def design(G, nb, lam_nodes):
    mx=np.concatenate([S[L]['mx'] for L in G]); y=np.concatenate([S[L]['y'] for L in G]); r=np.concatenate([S[L]['r'] for L in G])
    rcv=np.concatenate([np.full(len(S[L]['mx']),L+1) for L in G]); N=len(mx)
    qs=np.quantile(r, np.linspace(0,1,nb+1)[1:-1]) if nb>1 else np.array([])
    b=np.searchsorted(qs,r); lam_ops=lam_nodes*3*FP*N*8/len(G)
    des=[]; wts=[]
    for k in range(nb):
        sel=b==k; C=np.zeros((64,64)); np.add.at(C,(mx[sel],y[sel]),1)
        nrc=np.bincount(mx[sel],weights=rcv[sel],minlength=64)
        cost,segs=seg_dp(C,nrc,lam_ops); des.append(segs)
        cm=np.bincount(mx[sel],minlength=64); wts.append([cm[lo:hi+1].sum() for lo,hi,_ in segs])
    return [float(q) for q in qs], des, wts
def bst(segs, w):
    n=len(segs); 
    if n==1: return ('leaf',0)
    INF=float('inf'); cost=[[0]*n for _ in range(n)]; split=[[None]*n for _ in range(n)]
    Wsum=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i,n): Wsum[i][j]=sum(w[i:j+1])
    for ln in range(2,n+1):
        for i in range(0,n-ln+1):
            j=i+ln-1; best=INF
            for k in range(i,j):
                c=cost[i][k]+cost[k+1][j]
                if c<best: best=c; split[i][j]=k
            cost[i][j]=best+2*Wsum[i][j]
    def build(i,j):
        if i==j: return ('leaf',i)
        k=split[i][j]; return ('node',k+1,build(i,k),build(k+1,j))
    return build(0,n-1)
def build_entry(cfg):
    g=graph(); toks=g.tokens(); t=[g.token(i) for i in range(8)]
    cc={}
    def C(v):
        key=(type(v).__name__,v)
        if key not in cc: cc[key]=g.const(v)
        return cc[key]
    Hg=g.weight('hidden'); Eg=g.weight('embed'); Ug=g.weight('unembed')
    Mp=Ug[10:64]@(Hg@Eg)
    M64=lv1.concat([Mp[0:10]*C(0.0), Mp], axis=0)   # 64x65
    Mv=M64[:,0:64]
    cum=lv1.cumsum(Mp[:,0:64],axis=1)/(g.arange(64)+C(1))
    A=Mp[:,0:64]; B1=A+cum; B2=B1+cum; B3=B2+cum
    T1=A.argmax(axis=0)+C(10); T2=B1.argmax(axis=0)+C(10); T3=B2.argmax(axis=0)+C(10); T4=B3.argmax(axis=0)+C(10)
    # L2 second-row table, packed
    R2=[0,0,0,0,0,0,0,0,11,11,11,15,15,18,0,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,34,34,0,0,0,0,0,0,0,0,0,0,0,0,0,0,34,0,0,0,0,0,0,0,0,0,0,0,0,0,0,33,34]
    def pack(lst, per=10):
        lst=list(lst)+[0]*((-len(lst))%per); ints=[]
        for i in range(0,len(lst),per): ints.append(sum(int(v)<<(6*k) for k,v in enumerate(lst[i:i+per])))
        return np.array(ints,dtype=np.int64)
    pw=g.const(np.array([64**k for k in range(10)],dtype=np.int64)).reshape(1,10)
    def unpack(ints, n):
        return lv1.cast((g.const(ints).reshape(-1,1)//pw)%C(64),'int').reshape(-1)[0:n]
    R2t=unpack(pack(R2),64)
    m01=lv1.maximum(t[0],t[1]); r1=T2[m01]; r2=R2t[m01]
    s1=M64[r1,t[0]]+M64[r1,t[1]]; s2=M64[r2,t[0]]+M64[r2,t[1]]
    out2=lv1.where(s1>=s2,r1,r2)
    out1=T1[t[0]]
    m012=lv1.maximum(m01,t[2]); out3=T3[m012]
    out4=T4[lv1.maximum(m012,t[3])]
    outL4=lv1.cond(t[2]==C(64), lv1.cond(t[1]==C(64),out1,out2), lv1.cond(t[3]==C(64),out3,out4))
    # trees
    allrows=[]; leafspec={}  # (tree,bucket,seg)->(off,K)
    trees={}
    for name,(G,nb,lam) in cfg.items():
        qs,des,wts=design(G,nb,lam); trees[name]=(qs,des,wts)
        for b,segs in enumerate(des):
            for si,(lo,hi,rows) in enumerate(segs):
                leafspec[(name,b,si)]=(len(allrows),len(rows)); allrows+=rows
    idx=unpack(pack(allrows),len(allrows))
    Blocks=lv1.concat([lv1.take(Mv,idx,axis=0), lv1.cast(idx,'float').reshape(-1,1)],axis=1)
    def tree_expr(name,mx,r):
        qs,des,wts=trees[name]
        def sub(b):
            segs=des[b]; tr=bst(segs,wts[b])
            def rec(node):
                if node[0]=='leaf':
                    off,K=leafspec[(name,b,node[1])]; return Blocks[off:off+K]
                _,k,l,rgt=node; return lv1.cond(mx<C(int(segs[k][0])), rec(l), rec(rgt))
            return rec(tr)
        subs=[sub(b) for b in range(len(des))]
        def brec(lo,hi):  # buckets lo..hi inclusive
            if lo==hi: return subs[lo]
            mid=(lo+hi)//2; return lv1.cond(r<C(qs[mid]), brec(lo,mid), brec(mid+1,hi))
        return brec(0,len(des)-1)
    # {5,6}
    t5m=t[5]%C(64); mx56=lv1.maximum(toks[0:5].max(),t5m); r56=(toks[0:5].sum()+t5m)/(mx56+C(1))
    toks56=lv1.cond(t[5]==C(64),toks[0:5],toks[0:6])
    blk56=tree_expr('t56',mx56,r56); s56=lv1.take_sum(blk56,toks56,axis=1); out56=lv1.cast(blk56[s56.argmax(),64],'int')
    t7m=t[7]%C(64); mx78=lv1.maximum(toks[0:7].max(),t7m); r78=(toks[0:7].sum()+t7m)/(mx78+C(1))
    toks78=lv1.cond(t[7]==C(64),toks[0:7],toks)
    blk78=tree_expr('t78',mx78,r78); s78=lv1.take_sum(blk78,toks78,axis=1); out78=lv1.cast(blk78[s78.argmax(),64],'int')
    out=lv1.cond(t[4]==C(64), outL4, lv1.cond(t[6]==C(64), out56, out78))
    ent=g.entry(interpretation=out)
    nconst=sum(np.asarray(json.loads(n['value']) if isinstance(n['value'],str) else n['value']).size for n in ent['nodes'] if n['op']=='const')
    return ent, len(ent['nodes']), nconst, sum(len(d) for _,d,_ in trees.values()), trees
t0=time.time()
for cfg in [dict(t56=((5,6),2,0.00005), t78=((7,8),2,0.00005)), dict(t56=((5,6),2,0.0001), t78=((7,8),3,0.0001))]:
    try:
        ent,nn,nc,nl,trees=build_entry(cfg)
        print(cfg,'nodes',nn,'consts',nc,'leaves',nl)
        if nn<=400 and nc<=256:
            m=measure(ent); print(m)
    except Exception as e:
        import traceback; traceback.print_exc()
print(time.time()-t0)
