
import numpy as np
print('MAX_HELD',lv1.MAX_HELD,'MAX_ELEMENTS',lv1.MAX_ELEMENTS,'MAX_NODES',lv1.MAX_NODES,'MAX_CONST',lv1.MAX_CONST_SCALARS)
# feasibility: cond between different-shaped build-time blocks
g=graph(example=[3,5,64,64,64,64,64,64])
E_=g.weight('embed'); H_=g.weight('hidden'); U_=g.weight('unembed')
Mg = U_@(H_@E_)   # 64x65 build
idx = g.const(np.array([[50,51,52],[60,61,62]]).reshape(6))
Mrows = lv1.take(Mg, idx, axis=0)   # 6x65
rowid = lv1.cast(idx,'float').reshape(6,1)
blocks = lv1.concat([Mrows, rowid], axis=1)  # 6x66
b1 = blocks[0:2]; b2 = blocks[2:6]
mx = g.tokens().max()
blk = lv1.cond(mx < 55, b1, b2)
toks = g.tokens()
s = lv1.take_sum(blk, toks, axis=1)   # K
k = s.argmax()
out = lv1.cast(blk[k, 65], 'int')
print(out.value, blk.shape, s.shape)
ent = g.entry(interpretation=out)
ev = lv1.Evaluator(ent, weights, 8)
for x in [[3,5,64,64,64,64,64,64],[60,5,64,64,64,64,64,64],[62,61,60,59,58,57,56,55]]:
    print(ev.run(x), 'build',ev.build_cost)
print(len(ent['nodes']))
