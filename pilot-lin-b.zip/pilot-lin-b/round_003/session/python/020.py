
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W=U@Hd; M=W@E; FP=703; ALPHA=12.0
rng=np.random.default_rng(11)
S={}
for L in [5,6,7,8]:
    N=1_000_000; T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    y=(W@E[:,T].sum(axis=2)).argmax(0); Tt=np.where(T==64,0,T); mx=Tt.max(1); sm=Tt.sum(1)
    S[L]=dict(mx=mx,y=y,r=sm/(mx+1),L=np.full(N,L))
def seg_dp(Cs, ns_rc, lam_ops, N):
    P=np.vstack([np.zeros((1,64)),np.cumsum(Cs,axis=0)]); Q=np.concatenate([[0],np.cumsum(ns_rc)])
    best=np.full(65,np.inf); best[0]=0; arg=[None]*65; bld=40*N/16384
    for j in range(1,65):
        for i in range(j):
            cnt=P[j]-P[i]; n=cnt.sum(); rcn=Q[j]-Q[i]+bld
            if n==0: lc=0; rows=np.array([],int)
            else:
                rows=np.where(cnt*ALPHA*FP>rcn)[0]
                lc=rcn*len(rows)+ALPHA*FP*(n-cnt[rows].sum())+2*n
            tot=best[i]+lc+lam_ops
            if tot<best[j]: best[j]=tot; arg[j]=(i,rows)
    segs=[]; j=64
    while j>0:
        i,rows=arg[j]; segs.append((i,j-1,sorted(map(int,rows)))); j=i
    return best[64], segs[::-1]
def design_loss(G, nb, lam_nodes, perlen, ovh):
    mx=np.concatenate([S[L]['mx'] for L in G]); y=np.concatenate([S[L]['y'] for L in G]); r=np.concatenate([S[L]['r'] for L in G]); Ls=np.concatenate([S[L]['L'] for L in G])
    rcv=Ls+1; N=len(mx)
    if perlen:
        b=np.zeros(N,int)
        for L in G:
            m=Ls==L; qs=np.quantile(r[m], np.linspace(0,1,nb+1)[1:-1]) if nb>1 else []
            b[m]=np.searchsorted(qs,r[m])
    else:
        qs=np.quantile(r, np.linspace(0,1,nb+1)[1:-1]) if nb>1 else []
        b=np.searchsorted(qs,r)
    lam_ops=lam_nodes*3*FP*N*8/len(G); total=ovh*N+(9+2*np.ceil(np.log2(nb))+perlen)*N*(nb>1); nl=0
    for k in range(nb):
        sel=b==k; C=np.zeros((64,64)); np.add.at(C,(mx[sel],y[sel]),1)
        nrc=np.bincount(mx[sel],weights=rcv[sel],minlength=64)
        cost,segs=seg_dp(C,nrc,lam_ops,N*8/len(G)); n_=len(segs); nl+=n_
        total+=cost-lam_ops*n_+2*np.ceil(np.log2(max(n_,1)))*sel.sum()
    return round(total/(FP*N)*len(G)/8,4), nl
for G,ovh in [((5,6),10),((7,8),12)]:
    for nb in [2,3]:
        for perlen in [False,True]:
            print(G,nb,'perlen',perlen,[design_loss(G,nb,lam,perlen,ovh) for lam in [0.00005,0.00003,0.00002]])
