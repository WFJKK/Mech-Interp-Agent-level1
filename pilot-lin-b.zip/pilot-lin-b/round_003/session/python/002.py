
import inspect
print(lv1.PRICES)
print(inspect.getsource(lv1.gather)[:3000])
print(inspect.getsource(lv1.take_sum)[:2000])
print(inspect.getsource(lv1.wilson_lower))
print(inspect.signature(lv1.Evaluator), inspect.getsource(lv1.Evaluator)[:2500])
