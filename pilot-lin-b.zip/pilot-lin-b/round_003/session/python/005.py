
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W = U@Hd  # 64x8
M = W@E
rng=np.random.default_rng(1)
def sample(L,N):
    T = np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L)); return T
def net(T):
    h = E[:,T].sum(axis=2)  # 8xN
    return (W@h).argmax(axis=0)
t0=time.time()
data={}
for L in [5,6,7,8]:
    T=sample(L,1_000_000); y=net(T); data[L]=(T,y)
print(time.time()-t0)
FP=703
def dp_cost(y_sub, rowcost=9):
    # optimal rows for a leaf: include row if P*10*703 > rowcost
    n=len(y_sub)
    if n==0: return 0,0,[]
    cnt=np.bincount(y_sub,minlength=64)/n
    rows=np.where(cnt*10*FP>rowcost)[0]
    miss=1-cnt[rows].sum()
    return rowcost*len(rows), 10*FP*miss, rows
for L in [5,6,7,8]:
    T,y=data[L]; mx=T[:,:L].max(1)
    tot_c=tot_p=0
    for v in range(64):
        sel=mx==v
        c,p,r=dp_cost(y[sel]); w=sel.mean()
        tot_c+=w*c; tot_p+=w*p
    print(L,'mx-only: rowcost/FP',tot_c/FP,'penalty',tot_p/FP, 'total',(tot_c+tot_p)/FP)
