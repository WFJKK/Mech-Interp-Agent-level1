
import numpy as np, time, json
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W=U@Hd; M=W@E; FP=703; ALPHA=12.0; NB=32
rng=np.random.default_rng(123)
S={}
for L in [5,6,7,8]:
    N=2_000_000; T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    y=(W@E[:,T].sum(axis=2)).argmax(0); Tt=np.where(T==64,0,T); mx=Tt.max(1); sm=Tt.sum(1)
    S[L]=dict(mx=mx,y=y,r=sm/(mx+1))
PAIRS=np.array([(s1,s2) for s1 in range(1,NB) for s2 in range(s1+1,NB)])
def design_mxfirst(G, lam_nodes, allow3=True):
    mx=np.concatenate([S[L]['mx'] for L in G]); y=np.concatenate([S[L]['y'] for L in G]); r=np.concatenate([S[L]['r'] for L in G])
    rcv=np.concatenate([np.full(len(S[L]['mx']),L+1) for L in G]); N=len(mx)
    qs=np.quantile(r,np.linspace(0,1,NB+1)[1:-1]); bn=np.searchsorted(qs,r)
    C=np.zeros((64,NB,64)); np.add.at(C,(mx,bn,y),1)
    R=np.zeros((64,NB)); np.add.at(R,(mx,bn),rcv)
    P=np.concatenate([np.zeros((1,NB,64)),np.cumsum(C,axis=0)]); Q=np.concatenate([np.zeros((1,NB)),np.cumsum(R,axis=0)])
    bld=40*N*8/len(G)/16384; lam=lam_nodes*FP*N*8/len(G)
    def lc(cnt, rcn):  # cnt (...,64), rcn (...)
        n=cnt.sum(-1); rows=cnt*ALPHA*FP>(rcn+bld)[...,None]
        return (rcn+bld)*rows.sum(-1)+ALPHA*FP*(n-(cnt*rows).sum(-1))+2*n, rows
    best=np.full(65,np.inf); best[0]=0; arg=[None]*65
    for j in range(1,65):
        for i in range(j):
            cnt=P[j]-P[i]; rcn=Q[j]-Q[i]; tot_cnt=cnt.sum(0); tot_rc=rcn.sum(); n=tot_cnt.sum()
            if n==0:
                tot=best[i]+3*lam
                if tot<best[j]: best[j]=tot; arg[j]=(i,('leaf',None,[],None))
                continue
            c0,rows0=lc(tot_cnt,tot_rc); c0+=3*lam
            cl=np.cumsum(cnt,axis=0); rl=np.cumsum(rcn)
            # 2-way for all s
            a,ra=lc(cl[:-1],rl[:-1]); b,rb=lc(tot_cnt-cl[:-1],tot_rc-rl[:-1])
            c2=a+b+11*n+6*lam; s=int(np.argmin(c2)); cs=c2[s]
            info=('leaf',None,sorted(np.where(rows0)[0].tolist()),None); cnode=c0
            if cs<cnode: cnode=cs; info=('split',float(qs[s]),sorted(np.where(ra[s])[0].tolist()),sorted(np.where(rb[s])[0].tolist()))
            if allow3:
                s1=PAIRS[:,0]-1; s2=PAIRS[:,1]-1
                A=cl[s1]; B=cl[s2]-cl[s1]; Cc=tot_cnt-cl[s2]; rA=rl[s1]; rB=rl[s2]-rl[s1]; rC=tot_rc-rl[s2]
                ca,ra3=lc(A,rA); cb,rb3=lc(B,rB); cc,rc3=lc(Cc,rC)
                nA=A.sum(-1); nC=Cc.sum(-1); nfirst=np.maximum(nA,nC)
                c3=ca+cb+cc+9*n+2*n+2*(n-nfirst)+9*lam; p=int(np.argmin(c3))
                if c3[p]<cnode:
                    cnode=c3[p]; first='A' if nA[p]>=nC[p] else 'C'
                    info=('split3',(float(qs[s1[p]]),float(qs[s2[p]]),first),sorted(np.where(ra3[p])[0].tolist()),(sorted(np.where(rb3[p])[0].tolist()),sorted(np.where(rc3[p])[0].tolist())))
            tot=best[i]+cnode
            if tot<best[j]: best[j]=tot; arg[j]=(i,info)
    segs=[]; j=64
    while j>0:
        i,info=arg[j]; segs.append((i,j-1)+info); j=i
    segs=segs[::-1]
    cm=np.bincount(mx,minlength=64); wts=[cm[lo:hi+1].sum() for lo,hi,*_ in segs]
    return segs, wts
def bst(n, w):
    if n==1: return ('leaf',0)
    INF=float('inf'); cost=[[0]*n for _ in range(n)]; split=[[None]*n for _ in range(n)]
    for ln in range(2,n+1):
        for i in range(0,n-ln+1):
            j=i+ln-1; b=INF
            for k in range(i,j):
                c=cost[i][k]+cost[k+1][j]
                if c<b: b=c; split[i][j]=k
            cost[i][j]=b+2*sum(w[i:j+1])
    def build(i,j):
        if i==j: return ('leaf',i)
        k=split[i][j]; return ('node',k+1,build(i,k),build(k+1,j))
    return build(0,n-1)
def order_blocks(keys, sets):
    glob=[]; specs={}; prev=[]
    for i,key in enumerate(keys):
        Sx=set(sets[i]); nxt=set(sets[i+1]) if i+1<len(keys) else set()
        k=0
        while k<len(prev) and prev[len(prev)-1-k] in Sx: k+=1
        shared=prev[len(prev)-k:]; rest=[r for r in sets[i] if r not in shared]
        rest.sort(key=lambda r:(r in nxt, r))
        off=len(glob)-k; block=shared+rest; glob+=rest; specs[key]=(off,len(block)); prev=block
    return glob,specs
R2=[0]*64
for v,r in zip([8,9,10,11,12,13,15],[11,11,11,15,15,18,18]): R2[v]=r
def build_entry(cfg):
    g=graph(); toks=g.tokens(); t=[g.token(i) for i in range(8)]
    cc={}
    def C(v):
        key=(type(v).__name__,v)
        if key not in cc: cc[key]=g.const(v)
        return cc[key]
    Hg=g.weight('hidden'); Eg=g.weight('embed'); Ug=g.weight('unembed')
    Mp=Ug[10:64]@(Hg@Eg)
    M64=lv1.concat([Mp[0:10]*C(0.0), Mp], axis=0); Mv=M64[:,0:64]
    A=Mp[:,0:64]; cum=lv1.cumsum(A,axis=1)/(g.arange(64)+C(1))
    B1=A+cum; B2=B1+cum; B3=B2+cum
    TT=lv1.stack([A,B1,B2,B3],axis=0).argmax(axis=1)+C(10)
    R2t=g.const(np.array(R2,dtype=np.int64))
    m01=lv1.maximum(t[0],t[1]); r1=TT[1,m01]; r2=R2t[m01]
    s1=M64[r1,t[0]]+M64[r1,t[1]]; s2=M64[r2,t[0]]+M64[r2,t[1]]
    out2=lv1.cond(r2==C(0), r1, lv1.where(s1>=s2,r1,r2)); out1=TT[0,t[0]]
    m012=lv1.maximum(m01,t[2]); out3=TT[2,m012]; out4=TT[3,lv1.maximum(m012,t[3])]
    outL4=lv1.cond(t[2]==C(64), lv1.cond(t[1]==C(64),out1,out2), lv1.cond(t[3]==C(64),out3,out4))
    def pack(lst, per=10):
        lst=list(lst)+[0]*((-len(lst))%per); ints=[]
        for i in range(0,len(lst),per): ints.append(sum(int(v)<<(6*k) for k,v in enumerate(lst[i:i+per])))
        return np.array(ints,dtype=np.int64)
    pw=g.const(np.array([64**k for k in range(10)],dtype=np.int64)).reshape(1,10)
    trees={}; keys=[]; sets=[]
    for name,(G,lam) in cfg.items():
        segs,wts=design_mxfirst(G,lam); trees[name]=(segs,wts)
        for si,(lo,hi,kind,q,ra,rb) in enumerate(segs):
            keys.append((name,si,0)); sets.append(ra)
            if kind=='split': keys.append((name,si,1)); sets.append(rb)
            if kind=='split3': keys.append((name,si,1)); sets.append(rb[0]); keys.append((name,si,2)); sets.append(rb[1])
    allrows,leafspec=order_blocks(keys,sets)
    idx=lv1.cast((g.const(pack(allrows)).reshape(-1,1)//pw)%C(64),'int').reshape(-1)[0:len(allrows)]
    Blocks=lv1.concat([lv1.take(Mv,idx,axis=0), lv1.cast(idx,'float').reshape(-1,1)],axis=1)
    def blk(key):
        off,K=leafspec[key]; return Blocks[off:off+K]
    def tree_expr(name,mx,r):
        segs,wts=trees[name]; tr=bst(len(segs),wts)
        def rec(node):
            if node[0]=='leaf':
                si=node[1]; lo,hi,kind,q,ra,rb=segs[si]
                if kind=='leaf': return blk((name,si,0))
                if kind=='split': return lv1.cond(r<C(q), blk((name,si,0)), blk((name,si,1)))
                q1,q2,first=q; bA,bB,bC=blk((name,si,0)),blk((name,si,1)),blk((name,si,2))
                if first=='A': return lv1.cond(r<C(q1), bA, lv1.cond(r<C(q2), bB, bC))
                return lv1.cond(r<C(q2), lv1.cond(r<C(q1), bA, bB), bC)
            _,k,l,rgt=node; return lv1.cond(mx<C(int(segs[k][0])), rec(l), rec(rgt))
        return rec(tr)
    t5m=t[5]%C(64); mx56=lv1.maximum(toks[0:5].max(),t5m); r56=(toks[0:5].sum()+t5m)/(mx56+C(1))
    toks56=lv1.cond(t[5]==C(64),toks[0:5],toks[0:6])
    blk56=tree_expr('t56',mx56,r56); s56=lv1.take_sum(blk56,toks56,axis=1); out56=lv1.cast(blk56[s56.argmax(),64],'int')
    t7m=t[7]%C(64); mx78=lv1.maximum(toks[0:7].max(),t7m); r78=(toks[0:7].sum()+t7m)/(mx78+C(1))
    toks78=lv1.cond(t[7]==C(64),toks[0:7],toks)
    blk78=tree_expr('t78',mx78,r78); s78=lv1.take_sum(blk78,toks78,axis=1); out78=lv1.cast(blk78[s78.argmax(),64],'int')
    out=lv1.cond(t[4]==C(64), outL4, lv1.cond(t[6]==C(64), out56, out78))
    ent=g.entry(interpretation=out)
    nconst=sum(np.asarray(json.loads(n['value']) if isinstance(n['value'],str) else n['value']).size for n in ent['nodes'] if n['op']=='const')
    kinds=[x[2] for s,_ in trees.values() for x in s]
    return ent, len(ent['nodes']), nconst, len(keys), len(allrows), (kinds.count('split'),kinds.count('split3'))
erng=np.random.default_rng(77)
EV={}
for L in range(1,9):
    N=40000 if L>=5 else 3000; T=np.full((N,8),64); T[:,:L]=erng.integers(0,64,(N,L)); EV[L]=(T,(W@E[:,T].sum(axis=2)).argmax(0))
def perlen(ent):
    ev=lv1.Evaluator(ent,weights,8); out=[]; tot=0
    for L in range(1,9):
        T,y=EV[L]; ops=0; err=0
        for i in range(len(T)):
            _,a,cr,cp=ev.run(T[i]); ops+=cr+cp; err+=(a!=y[i])
        loss=(ops/len(T)/FP+10*err/len(T))/8; tot+=loss; out.append((L,round(ops/len(T),1),round(err/len(T),4),round(loss,4)))
    return out, round(tot,4), round(ev.build_cost/16384/FP,4)
t0=time.time(); good=None
for lam in [0.00003,0.000024,0.00002,0.000017,0.000014,0.000011]:
    cfg=dict(t56=((5,6),lam), t78=((7,8),lam))
    ent,nn,nc,nl,nr,ns=build_entry(cfg); print(lam,'nodes',nn,'consts',nc,'blocks',nl,'rows',nr,'splits',ns, round(time.time()-t0,1))
    if nn<=400 and nc<=256: good=(lam,ent)
    else: break
lam,ent=good
pl,tot,b=perlen(ent); print(lam,pl,'total',tot,'build',b,'est',round(1-tot-b-0.006,4))
m=measure(ent); print({k:m[k] for k in ['fidelity','cost','b','fidelity_low','reward']})
save_entry('r3e',ent)
print(time.time()-t0)
