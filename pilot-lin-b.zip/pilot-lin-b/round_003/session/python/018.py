
import numpy as np
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W=U@Hd; M=W@E; FP=703
A=M[10:,:64]; cum=np.cumsum(A,axis=1)/(np.arange(64)+1)
rng=np.random.default_rng(7)
for L in [2,3,4]:
    N=2_000_000; T=rng.integers(0,64,(N,L)); y=(W@E[:,T].sum(axis=2)).argmax(0); mx=T.max(1)
    TL=(A+(L-1)*cum).argmax(0)+10
    pred=TL[mx]; err=(pred!=y)
    # second most frequent winner per mx
    R2=np.zeros(64,int); cover=0; amb=0
    for v in range(64):
        sel=mx==v; cnt=np.bincount(y[sel],minlength=64); cnt[TL[v]]=0
        if cnt.max()*10*FP > (2*L+4)*sel.sum():  # worth it
            R2[v]=cnt.argmax(); amb+=sel.mean()
        cover+=cnt[R2[v]] if R2[v] else 0
    # exact two-candidate compare
    r2=R2[mx]; s1=M[pred,:][np.arange(N)[:,None],T].sum(1); s2=M[r2,:][np.arange(N)[:,None],T].sum(1)
    pred2=np.where((r2>0)&(s2>s1),r2,pred)
    print(L,'err table',err.mean(),'err 2cand',(pred2!=y).mean(),'P(ambig)',round(amb,3),'R2 nonzero',np.nonzero(R2)[0].tolist(), R2[np.nonzero(R2)[0]].tolist())
