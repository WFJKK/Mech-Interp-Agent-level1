
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W = U@Hd; M = W@E; FP=703
rng=np.random.default_rng(3)
for L in [6,8]:
    N=1_000_000
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    h=E[:,T].sum(axis=2); y=(W@h).argmax(0)
    Tt=np.where(T==64,-1,T); srt=np.sort(Tt,1)[:,::-1]
    mx=srt[:,0]; sm=np.where(Tt<0,0,Tt).sum(1); r=sm/(mx+1)
    qs=np.quantile(r,[0.25,0.5,0.75]); b=np.searchsorted(qs,r)
    present=(T==y[:,None]).any(1)
    is_s1=y==srt[:,0]; is_s2=(~is_s1)&(y==srt[:,1]); is_s3=(~is_s1)&(~is_s2)&(y==srt[:,2])
    far=(~present)&(y<mx-10); near=(~present)&(y>=mx-10)
    for k in range(4):
        m=b==k
        print(L,k,'s1 %.4f s2 %.4f s3 %.4f otherpresent %.4f far %.4f near-notpresent %.4f'%(is_s1[m].mean(),is_s2[m].mean(),is_s3[m].mean(),(present&~is_s1&~is_s2&~is_s3)[m].mean(),far[m].mean(),near[m].mean()))
    # among high bucket, which far rows win
    m=b==0; print('far rows bucket0', np.bincount(y[m&far],minlength=64).argsort()[::-1][:12])
    m=b==3; print('not-present near rows bucket3', np.bincount(y[m&near],minlength=64).argsort()[::-1][:12])
