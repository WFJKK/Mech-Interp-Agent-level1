
import numpy as np, json, inspect
print(info)
print([k for k in dir(lv1) if not k.startswith('_')])
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
M = U@Hd@E  # 64x65
print(M.shape)
best = entries['best']
print(type(best), list(best.keys()) if isinstance(best,dict) else None)
s=json.dumps(best); print(len(s))
nodes = best.get('nodes', None)
print(len(nodes) if nodes is not None else [ (k, len(v) if hasattr(v,'__len__') else v) for k,v in best.items()])
