
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W=U@Hd; M=W@E; FP=703; ALPHA=12.0
rng=np.random.default_rng(21)
def opt_rows(cnt,n,rc):
    rows=np.where(cnt*ALPHA*FP>rc*n)[0]; return rows, rc*len(rows)*n+ALPHA*FP*(n-cnt[rows].sum())
for L in [6,8]:
    N=1_000_000; T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    h=E[:,T].sum(axis=2); logits=(W@h).T; y=logits.argmax(1); Tt=np.where(T==64,0,T); mx=Tt.max(1); r=Tt.sum(1)/(mx+1)
    qs=np.quantile(r,[0.5]); b=np.searchsorted(qs,r); rc=L+1
    base=0; ee=0; trig_rate=0; cnt_in=0
    for k in range(2):
        for v in range(64):
            sel=np.where((b==k)&(mx==v))[0]; n=len(sel)
            if n<50: continue
            ys=y[sel]; cnt=np.bincount(ys,minlength=64)
            rows,c0=opt_rows(cnt,n,rc); base+=c0+n*2
            # early exit: primary row = most frequent
            p=cnt.argmax(); lp=logits[sel,p]
            # candidates thetas: quantiles
            best=c0+n*2
            for q in np.linspace(0.05,0.95,19):
                th=np.quantile(lp,q); trig=lp<th
                # untriggered: answer p ; triggered: evaluate rest rows (opt for triggered subset)
                cnt_t=np.bincount(ys[trig],minlength=64); nt=trig.sum()
                rows_t,ct=opt_rows(cnt_t,nt,rc)  # includes p possibly; cost counts all rows incl p again -> subtract p's cost
                if p in rows_t: ct-=rc*nt
                miss_un=((~trig)&(ys!=p)).sum()
                cost=n*(rc+2)+ct+nt*2+ALPHA*FP*miss_un
                if cost<best: best=cost; bq=q
            ee+=best
    print(L,'base per input',round(base/N/FP,4),'early-exit',round(ee/N/FP,4),'gain reward',round((base-ee)/N/FP/8,4))
