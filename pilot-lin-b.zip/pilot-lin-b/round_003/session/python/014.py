
import numpy as np, time, json
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W = U@Hd; M = W@E; FP=703
rng=np.random.default_rng(11)
S={}
for L in [5,6,7,8]:
    N=600_000; T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    y=(W@E[:,T].sum(axis=2)).argmax(0); Tt=np.where(T==64,0,T); mx=Tt.max(1); sm=Tt.sum(1)
    S[L]=dict(mx=mx,y=y,r=sm/(mx+1))
def seg_dp(Cs, ns_rc, lam_ops):
    # Cs: 64x64 pooled counts; ns_rc: 64-vector of sum_L n_{L,v}*(rc_L+1) ; returns cost, segs
    P=np.vstack([np.zeros((1,64)),np.cumsum(Cs,axis=0)]); Q=np.concatenate([[0],np.cumsum(ns_rc)])
    best=np.full(65,np.inf); best[0]=0; arg=[None]*65
    for j in range(1,65):
        for i in range(j):
            cnt=P[j]-P[i]; n=cnt.sum(); rcn=Q[j]-Q[i]
            if n==0: lc=0; rows=np.array([],int)
            else:
                rows=np.where(cnt*10*FP>rcn)[0]
                lc=rcn*len(rows)+10*FP*(n-cnt[rows].sum())+2*n  # gather+cast
            tot=best[i]+lc+lam_ops
            if tot<best[j]: best[j]=tot; arg[j]=(i,rows)
    segs=[]; j=64
    while j>0:
        i,rows=arg[j]; segs.append((i,j-1,list(map(int,rows)))); j=i
    return best[64], segs[::-1]
def design(G, nb, lam_nodes, ovh):
    mx=np.concatenate([S[L]['mx'] for L in G]); y=np.concatenate([S[L]['y'] for L in G]); r=np.concatenate([S[L]['r'] for L in G])
    rcv=np.concatenate([np.full(len(S[L]['mx']),L+1) for L in G]); N=len(mx)
    qs=np.quantile(r, np.linspace(0,1,nb+1)[1:-1]) if nb>1 else np.array([])
    b=np.searchsorted(qs,r); lam_ops=lam_nodes*3*FP*N*8/len(G)
    total=ovh*N+(9+2*np.ceil(np.log2(nb)))*N*(nb>1); des=[]; nl=0
    for k in range(nb):
        sel=b==k; C=np.zeros((64,64)); np.add.at(C,(mx[sel],y[sel]),1)
        nrc=np.bincount(mx[sel],weights=rcv[sel],minlength=64)
        cost,segs=seg_dp(C,nrc,lam_ops); n_=len(segs)
        total+=cost-lam_ops*n_+2*np.ceil(np.log2(max(n_,1)))*sel.sum(); des.append(segs); nl+=n_
    return total/(FP*N)*len(G)/8, nl, qs, des
t0=time.time()
curves={}
for G,ovh in [((5,),6),((6,7,8),11),((5,6,7,8),12),((5,6),8),((7,8),11),((6,),8)]:
    for nb in [1,2,3,4]:
        pts=[]
        for lam in [0.00005,0.0001,0.00015,0.0002,0.0003,0.0004,0.0006,0.0008,0.0012]:
            loss,nl,qs,des=design(G,nb,lam,ovh); pts.append((nl,round(loss,4)))
        curves[(G,nb)]=pts; print(G,nb,pts)
print(time.time()-t0)
# L<=4 constants from best
nodes=entries['best']['nodes']
print(nodes[29]['value'])
