
import numpy as np
for name in ['r3d','r3e']:
    rs=[]
    for k in range(3):
        m=measure(entries[name]); rs.append((round(m['reward'],4),round(m['fidelity'],5),round(m['cost'],4)))
    print(name,rs)
