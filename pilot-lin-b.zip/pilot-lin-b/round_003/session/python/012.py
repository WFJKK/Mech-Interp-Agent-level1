
import numpy as np, time
E=weights['embed']; Hd=weights['hidden']; U=weights['unembed']
W = U@Hd; M = W@E; FP=703
rng=np.random.default_rng(5)
ev = lv1.Evaluator(entries['best'], weights, 8)
t0=time.time()
for L in range(1,9):
    N=6000
    T=np.full((N,8),64); T[:,:L]=rng.integers(0,64,(N,L))
    y=(W@E[:,T].sum(axis=2)).argmax(0)
    ops=0; err=0
    for i in range(N):
        inside,ans,cr,cp=ev.run(T[i]); ops+=cr+cp; err+=(ans!=y[i])
    print(L,'ops',ops/N,'err',err/N, 'loss', (ops/N/FP+10*err/N)/8)
print('build',ev.build_cost, ev.build_cost/16384/FP, time.time()-t0)
