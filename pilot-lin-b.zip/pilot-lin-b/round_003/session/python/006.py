
def cond_total(L, stat, nb, statcost, rowcost=9):
    T,y=data[L]; mx=T[:,:L].max(1)
    tot=0
    for v in range(64):
        sel=mx==v; w=sel.mean()
        if w==0: continue
        s=stat[sel]; ys=y[sel]
        qs=np.quantile(s, np.linspace(0,1,nb+1)[1:-1]) if nb>1 else []
        b=np.searchsorted(qs, s)
        sub=0
        for k in range(nb):
            m=b==k
            if m.sum()==0: continue
            c,p,r=dp_cost(ys[m],rowcost); sub+=m.mean()*(c+p)
        tot+=w*(sub+statcost+2*np.ceil(np.log2(nb)))
    return tot/FP
for L in [6,7,8]:
    T,y=data[L]; Tt=np.where(T==64,-1,T)
    mx=Tt.max(1); srt=np.sort(Tt,axis=1); m2=srt[:,-2]; sm=Tt[:, :L].sum(1)
    h=E[:,T].sum(axis=2); lmx=(W[mx]*h.T).sum(1)
    # logit of a fixed far row, e.g. 36, 13
    l36=(W[36]*h.T).sum(1); l13=(W[13]*h.T).sum(1)
    print(L,'base',cond_total(L,sm,1,0))
    for name,st,sc in [('sum',sm,9),('m2',m2,23),('lmx',lmx,0),('l36',l36,9),('l13',l13,9)]:
        print(L,name,[round(cond_total(L,st,nb,sc),4) for nb in (2,4,8)])
