
from collections import Counter
best = entries['best']
c = Counter(n['op'] for n in best['nodes'])
print(c)
# show first 60 nodes briefly
for i,n in enumerate(best['nodes'][:80]):
    print(i, {k:(v if k!='value' else (str(v)[:60])) for k,v in n.items()})
