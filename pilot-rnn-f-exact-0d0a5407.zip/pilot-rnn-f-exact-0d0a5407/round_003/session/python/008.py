
import numpy as np, json

def build(readout_mode="full", k_ro=0, example=None):
    g = graph() if example is None else graph(example=example)
    w = g.weight("input")[:, 0]
    rec = g.weight("recurrent")
    ro = g.weight("readout")
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    # ---- table for z2 (build) ----
    w2 = w.reshape(1, 16)
    sgn = g.const([[-1.0], [1.0]])
    hs = lv1.maximum(sgn * w2, 0.0)            # (2,16) relu(s w)
    recT = rec.T
    Bs = hs @ recT                              # (2,16)
    theta = -Bs / w2                            # (2,16)
    rank = lv1.argsort(lv1.argsort(theta, axis=1), axis=1).reshape(2, 1, 16)
    below = rank < g.arange(17).reshape(17, 1)  # (2,17,16)
    zero = g.const(0.0)
    mask = lv1.where(w2 == zero, (Bs.reshape(2, 1, 16) > zero), (w2 > zero) == below)
    Mf = lv1.cast(mask, "float")
    C1 = (Mf * w2) @ recT
    C0 = (Mf * (sgn * Bs).reshape(2, 1, 16)) @ recT
    T = lv1.stack([C0, C1, lv1.where(mask, w2, w2)], axis=3)   # (2,17,16,3)
    # ---- runtime z2 ----
    pos0 = x0 > zero
    sidx = lv1.cast(pos0, "int")
    u = x1 / abs(x0)
    th = lv1.cond(pos0, theta[1], theta[0])
    i = (th < u).sum()
    z = T[sidx, i] @ toks[0:3]                  # (16,)
    # ---- constant packed columns ----
    RW = lv1.concat([rec, w.reshape(16, 1)], axis=1)          # (16,17)
    ar17 = lv1.cast(g.arange(17), "float").reshape(1, 17)
    Rp = lv1.concat([RW, ar17], axis=0)                        # (17,17)
    cols = [Rp[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((17, 0)))
    for t in range(3, 10):
        pos = z > zero
        zp = lv1.concat([z, toks[t:t+1]])
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        idx = lv1.cast(A[16], "int")
        z = A[0:16] @ lv1.take(zp, idx)
    # ---- readout ----
    if readout_mode == "plain":
        logits = ro @ lv1.maximum(z, zero)
    else:
        ROp = lv1.concat([ro, Rp[16:17, 0:16]], axis=0)        # (11,16)
        Er = g.const(np.zeros((11, 0)))
        pos = z > zero
        k = k_ro
        parts = []
        if k > 0:
            parts.append(ROp[:, 0:k])
            zr = lv1.maximum(z, zero)
        else:
            zr = z
        parts += [lv1.cond(pos[j:j+1], ROp[:, j:j+1], Er) for j in range(k, 16)]
        A = lv1.concat(parts, axis=1)
        idx = lv1.cast(A[10], "int")
        logits = A[0:10] @ lv1.take(zr, idx)
    out = logits.argmax()
    return g, g.entry(interpretation=out)

for mode, k in [("plain", 0), ("full", 0), ("full", 4)]:
    g, e = build(mode, k)
    print(mode, k, "nodes", len(e["nodes"]), "consts", sum(np.asarray(n["value"]).size for n in e["nodes"] if n["op"]=="const"))
