
import numpy as np, json, collections
BUILDER = r'''
def build(example=None, ro_chain=True):
    g = graph() if example is None else graph(example=example)
    inp = g.weight("input")            # (16,1)
    rec = g.weight("recurrent")
    ro = g.weight("readout")
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    zero = g.const(0.0)
    w2 = inp.T                          # (1,16)
    sgn3 = g.const([[[-1.0]], [[1.0]]]) # (2,1,1)
    sw = sgn3 * w2                      # (2,1,16)
    hs = lv1.maximum(sw, zero)
    recT = rec.T
    Bs = hs @ recT                      # (2,1,16): B_s = rec @ relu(s w)
    sB = sgn3 * Bs                      # s*B_s
    th = -sB / w2                       # effective breakpoints, compared with v = x1/x0
    rank = lv1.argsort(lv1.argsort(th, axis=2), axis=2)   # (2,1,16)
    below = rank < g.arange(17).reshape(17, 1)              # (2,17,16)
    mask = lv1.where(w2 == zero, Bs > zero, (sw > zero) == below)
    Mf = lv1.cast(mask, "float")
    C1 = (Mf * w2) @ recT
    C0 = (Mf * sB) @ recT
    T = lv1.stack([C0, C1, lv1.where(mask, w2, w2)], axis=3)   # (2,17,16,3)
    pos0 = x0 >= zero
    sidx = lv1.cast(pos0, "int")
    v = x1 / x0
    the = lv1.cond(pos0, th[1], th[0])  # (1,16)
    i = (the < v).sum()
    z = T[sidx, i] @ toks[0:3]
    RW = lv1.concat([rec, inp], axis=1)                       # (16,17)
    crow = g.const([[float(j) for j in range(17)]])
    Rp = lv1.concat([RW, crow], axis=0)                        # (17,17)
    cols = [Rp[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((17, 0)))
    for t in range(3, 10):
        pos = z > zero
        zp = lv1.concat([z, toks[t:t+1]])
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        idx = lv1.cast(A[16], "int")
        z = A[0:16] @ lv1.take(zp, idx)
    if not ro_chain:
        logits = ro @ lv1.maximum(z, zero)
    else:
        crow16 = g.const([[float(j) for j in range(16)]])
        ROp = lv1.concat([ro, crow16], axis=0)                 # (11,16)
        Er = g.const(np.zeros((11, 0)))
        pos = z > zero
        A = lv1.concat([lv1.cond(pos[j:j+1], ROp[:, j:j+1], Er) for j in range(16)], axis=1)
        idx = lv1.cast(A[10], "int")
        logits = A[0:10] @ lv1.take(z, idx)
    return g, g.entry(interpretation=logits.argmax())
'''
exec(BUILDER)
g, e = build()
print("nodes", len(e["nodes"]), "consts", sum(np.asarray(n["value"]).size for n in e["nodes"] if n["op"]=="const"))
m = measure(e)
print({k: m[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']})
save_entry("idx2_v1", e)
