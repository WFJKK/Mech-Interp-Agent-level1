
import numpy as np
exec(BUILDER) if 'BUILDER' in dir() else None
