
import inspect, os
print(info.keys() if hasattr(info,'keys') else info)
print(list(entries.keys()))
print(measure(entries['best']))
src = inspect.getsource(lv1)
print(len(src))
print(src[:6000])
