
import collections
g, e = build("plain", 0)
nodes = e["nodes"]
print(collections.Counter(n["op"] for n in nodes))
# find how many nodes before the first chain step: locate the first 'tokens' slice with start 3
for i, n in enumerate(nodes[:70]):
    print(i, n if n['op']!='const' else (n['op'], 'const'))
m = measure(e)
print({k: m[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']})
