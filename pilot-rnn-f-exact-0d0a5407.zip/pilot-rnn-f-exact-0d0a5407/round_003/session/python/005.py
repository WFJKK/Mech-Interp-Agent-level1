
import collections, json
e = entries['best']
nodes = e['nodes']
print(len(nodes), e.keys())
print(collections.Counter(n['op'] for n in nodes))
for i,n in enumerate(nodes[:80]):
    print(i, n)
