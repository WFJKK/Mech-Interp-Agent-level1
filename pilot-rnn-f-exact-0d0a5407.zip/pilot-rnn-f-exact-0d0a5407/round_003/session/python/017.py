
import numpy as np
e = entries["idx2_v2"]
g0 = graph()
ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(7)
def test_weights(wts, n=1200, seed=1):
    r = np.random.default_rng(seed)
    X = r.standard_normal((n, 10))
    ans, ops = lv1.run_reference(ref, wts, 10, X)
    m = lv1.measure(e, wts, 10, X, ans, ops)
    return m['n_agree'], n, round(m['cost'], 3)
for scale in [0.05, 0.25, 1.0, 3.0]:
    wts = {"input": rng.uniform(-scale, scale, (16,1)), "recurrent": rng.uniform(-scale, scale, (16,16)), "readout": rng.uniform(-scale, scale, (10,16))}
    print(scale, test_weights(wts))
wts = {"input": rng.uniform(-0.25, 0.25, (16,1)), "recurrent": rng.uniform(-0.25, 0.25, (16,16)), "readout": rng.uniform(-0.25, 0.25, (10,16))}
wts["input"][[0, 5, 9], 0] = 0.0; wts["recurrent"][3, :] = 0; wts["recurrent"][:, 7] = 0; wts["recurrent"][:, 0] = 0
print("zeros", test_weights(wts))
wts = {"input": rng.uniform(0, 0.3, (16,1)), "recurrent": rng.uniform(0, 0.3, (16,16)), "readout": rng.uniform(-0.25, 0.25, (10,16))}
print("allpos", test_weights(wts))
wts = {"input": np.zeros((16,1)), "recurrent": rng.uniform(-0.3, 0.3, (16,16)), "readout": rng.uniform(-0.25, 0.25, (10,16))}
print("zero-w", test_weights(wts))
wts = {"input": np.ones((16,1))*0.2, "recurrent": rng.uniform(-0.3, 0.3, (16,16)), "readout": rng.uniform(-0.25, 0.25, (10,16))}
print("equal-w (tied breakpoints)", test_weights(wts))
wts = {"input": rng.standard_normal((16,1)), "recurrent": rng.standard_normal((16,16))*0.5, "readout": rng.standard_normal((10,16))}
print("gauss", test_weights(wts))
wts = {"input": rng.uniform(-0.25, 0.25, (16,1)), "recurrent": np.zeros((16,16)), "readout": rng.uniform(-0.25, 0.25, (10,16))}
print("zero-rec", test_weights(wts))
