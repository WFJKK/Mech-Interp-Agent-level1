
import numpy as np
BUILDER = r'''
def build(example=None):
    g = graph() if example is None else graph(example=example)
    inp = g.weight("input")            # (16,1)
    rec = g.weight("recurrent")
    ro = g.weight("readout")
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    zero = g.const(0.0)
    w2 = inp.T                          # (1,16)
    sgn3 = g.const([[[-1.0]], [[1.0]]]) # (2,1,1)
    sw = sgn3 * w2                      # (2,1,16)
    hs = lv1.maximum(sw, zero)
    recT = rec.T
    Bs = hs @ recT                      # (2,1,16): B_s = rec @ relu(s w)
    sB = sgn3 * Bs                      # s*B_s
    th = -sB / w2                       # effective breakpoints, compared with v = x1/x0
    rank = lv1.argsort(lv1.argsort(th, axis=2), axis=2)   # (2,1,16)
    below = rank < g.arange(17).reshape(17, 1)              # (2,17,16)
    mask = lv1.where(w2 == zero, Bs > zero, (sw > zero) == below)
    Mf = lv1.cast(mask, "float")
    C1 = (Mf * w2) @ recT
    C0 = (Mf * sB) @ recT
    T = lv1.stack([C0, C1, lv1.where(mask, w2, w2)], axis=3)   # (2,17,16,3)
    pos0 = x0 >= zero
    sidx = lv1.cast(pos0, "int")
    v = x1 / x0
    the = lv1.cond(pos0, th[1], th[0])  # (1,16)
    i = (the < v).sum()
    z = T[sidx, i] @ toks[0:3]
    RW = lv1.concat([rec, inp], axis=1)                       # (16,17)
    RO = lv1.concat([ro, g.const(np.zeros((10, 1)))], axis=1)  # (10,17)
    crow = g.const([[float(j) for j in range(17)]])
    P = lv1.concat([RW, RO, crow], axis=0)                     # (27,17)
    cols = [P[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27, 0)))
    zs = [z]
    for t in range(3, 10):
        pos = z > zero
        zp = lv1.concat([z, toks[t:t+1]])
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        idx = lv1.cast(A[26], "int")
        z = A[0:16] @ lv1.take(zp, idx)
        zs.append(z)
    pos = z > zero
    A = lv1.concat([lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
    idx = lv1.cast(A[26], "int")
    logits = A[16:26] @ lv1.take(z, idx)
    return g, g.entry(interpretation=logits.argmax()), zs, logits
'''
exec(BUILDER)
W = {k: np.array(v) for k, v in weights.items()}
def np_forward(x, W=W):
    w, rec, ro = W["input"][:, 0], W["recurrent"], W["readout"]
    h = np.maximum(w * x[0], 0); zs = []
    for t in range(1, 10):
        z = w * x[t] + rec @ h; h = np.maximum(z, 0)
        if t >= 2: zs.append(z)
    return zs, ro @ h
rng = np.random.default_rng(5)
cases = [rng.standard_normal(10) for _ in range(5)]
for x in [cases[0].copy()]:
    x0z = x.copy(); x0z[0] = 0.0; cases.append(x0z)
    x01 = x.copy(); x01[0] = 0.0; x01[1] = 0.0; cases.append(x01)
    x1z = x.copy(); x1z[1] = 0.0; cases.append(x1z)
    xt = x.copy(); xt[0] = 1e-200; cases.append(xt)
    xt = x.copy(); xt[0] = -1e-200; cases.append(xt)
    xt = x.copy(); xt[0] = 1e-320; cases.append(xt)
    xt = x * 1e6; cases.append(xt)
    xt = x * 1e-6; cases.append(xt)
    xt = x.copy(); xt[0] = -0.0; cases.append(xt)
    xt = x.copy(); xt[0] = 0.0; xt[1] = -1.3; cases.append(xt)
    xt = x.copy(); xt[2:] = 0.0; cases.append(xt)
    xt = np.zeros(10); cases.append(xt)
for ci, x in enumerate(cases):
    try:
        g, e, zs, lg = build(example=list(x))
        zr, lr = np_forward(x)
        errs = [np.max(np.abs(a.value - b)) / (np.max(np.abs(b)) + 1e-300) for a, b in zip(zs, zr)]
        ok = int(lg.value.argmax()) == int(lr.argmax())
        print(ci, "ok" if ok else "MISMATCH", "max rel err z:", f"{max(errs):.1e}", "logit relerr", f"{np.max(np.abs(lg.value - lr))/(np.max(np.abs(lr))+1e-300):.1e}")
    except Exception as ex:
        print(ci, "ERROR", type(ex).__name__, str(ex)[:200])
