
import re
src = inspect.getsource(lv1)
i = src.find('class Evaluator')
print(src[i:i+9000])
