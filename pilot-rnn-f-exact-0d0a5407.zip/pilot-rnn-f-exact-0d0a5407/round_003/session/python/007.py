
import inspect
src = inspect.getsource(lv1)
i = src.find('def _int_index')
print(src[i:i+900])
i = src.find('if op == "concat"')
print(src[i:i+1500])
