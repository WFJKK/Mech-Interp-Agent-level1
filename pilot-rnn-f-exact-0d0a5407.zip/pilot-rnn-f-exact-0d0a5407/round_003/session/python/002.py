
import inspect
src = inspect.getsource(lv1)
i = src.find('def _eval_node') 
# print sections: cond, slice, concat, take, gather, node counting
for key in ['"cond"', '"slice"', '"concat"', '"take"', '"gather"', 'max_nodes', 'n_nodes', 'def cond', 'def take', 'def gather', 'def __getitem__']:
    for m in __import__('re').finditer(__import__('re').escape(key), src):
        s = m.start()
        print('=====', key, s)
        print(src[max(0,s-300):s+900])
        break
