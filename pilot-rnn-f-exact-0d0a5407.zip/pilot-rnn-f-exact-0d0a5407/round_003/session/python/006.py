
import inspect
src = inspect.getsource(lv1)
i = src.find('def check_structure')
print(src[i:i+3500])
i = src.find('def apply')
print(src[i:i+6000])
