
import numpy as np
BUILDER = r'''
def build(example=None):
    g = graph() if example is None else graph(example=example)
    inp = g.weight("input")            # (16,1)
    rec = g.weight("recurrent")
    ro = g.weight("readout")
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    zero = g.const(0.0)
    w2 = inp.T                          # (1,16)
    sgn3 = g.const([[[-1.0]], [[1.0]]]) # (2,1,1): s = -1, +1
    hs = lv1.maximum(sgn3 * w2, zero)   # relu(s w)  (2,1,16)
    recT = rec.T
    Bs = hs @ recT                      # (2,1,16): B_s = rec @ relu(s w)
    sB = sgn3 * Bs                      # s*B_s : x0-coefficient of z1
    th = -Bs / w2                       # breakpoints: z1_j = w_j x1 + |x0| B_sj > 0  <=>  (w_j>0) == (th_j < u), u = x1/|x0|
    rank = lv1.argsort(lv1.argsort(th, axis=2), axis=2)   # (2,1,16)
    below = rank < g.arange(17).reshape(17, 1)              # (2,17,16): interval i has the i smallest th below u
    mask = lv1.where(w2 == zero, Bs > zero, (w2 > zero) == below)
    Mf = lv1.cast(mask, "float")
    C1 = (Mf * w2) @ recT               # x1-coefficient of z2 = rec @ (mask * w)
    C0 = (Mf * sB) @ recT               # x0-coefficient of z2 = rec @ (mask * s B_s)
    T = lv1.stack([C0, C1, lv1.where(mask, w2, w2)], axis=3)   # (2,17,16,3)
    pos0 = x0 > zero
    sidx = lv1.cast(pos0, "int")
    u = x1 / abs(x0)
    the = lv1.cond(pos0, th[1], th[0])  # (1,16)
    i = (the < u).sum()
    z = T[sidx, i] @ toks[0:3]          # z2
    RW = lv1.concat([rec, inp], axis=1)                       # (16,17): rec columns | w
    RO = lv1.concat([ro, g.const(np.zeros((10, 1)))], axis=1)  # (10,17)
    crow = g.const([[float(j) for j in range(17)]])            # index row
    P = lv1.concat([RW, RO, crow], axis=0)                     # (27,17) packed constant columns
    cols = [P[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27, 0)))
    zs = [z]
    for t in range(3, 10):
        pos = z > zero
        zp = lv1.concat([z, toks[t:t+1]])
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        idx = lv1.cast(A[26], "int")
        z = A[0:16] @ lv1.take(zp, idx)
        zs.append(z)
    pos = z > zero
    A = lv1.concat([lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
    idx = lv1.cast(A[26], "int")
    logits = A[16:26] @ lv1.take(z, idx)
    return g, g.entry(interpretation=logits.argmax()), zs, logits
'''
exec(BUILDER)
W = {k: np.array(v) for k, v in weights.items()}
def np_forward(x, W=W):
    w, rec, ro = W["input"][:, 0], W["recurrent"], W["readout"]
    h = np.maximum(w * x[0], 0); zs = []
    for t in range(1, 10):
        z = w * x[t] + rec @ h; h = np.maximum(z, 0)
        if t >= 2: zs.append(z)
    return zs, ro @ h
rng = np.random.default_rng(5)
cases = [rng.standard_normal(10) for _ in range(5)]
x = cases[0].copy()
for mod in [lambda a: a.__setitem__(0, 0.0), lambda a: (a.__setitem__(0, 0.0), a.__setitem__(1, 0.0)), lambda a: a.__setitem__(1, 0.0),
            lambda a: a.__setitem__(0, 1e-200), lambda a: a.__setitem__(0, -1e-200), lambda a: a.__setitem__(0, 1e-320), lambda a: a.__setitem__(0, -0.0),
            lambda a: (a.__setitem__(0, -0.0), a.__setitem__(1, -1.3)), lambda a: a.__setitem__(slice(2, 10), 0.0), lambda a: a.__setitem__(slice(0,10), 0.0),
            lambda a: a.__imul__(1e6), lambda a: a.__imul__(1e-6)]:
    xt = x.copy(); mod(xt); cases.append(xt)
worst = 0
for ci, x in enumerate(cases):
    g, e, zs, lg = build(example=list(x))
    zr, lr = np_forward(x)
    errs = [np.max(np.abs(a.value - b)) / (np.max(np.abs(b)) + 1e-300) for a, b in zip(zs, zr)]
    ok = int(lg.value.argmax()) == int(lr.argmax())
    worst = max(worst, max(errs))
    print(ci, "ok" if ok else "MISMATCH", f"{max(errs):.1e}", f"{np.max(np.abs(lg.value - lr))/(np.max(np.abs(lr))+1e-300):.1e}")
g, e, _, _ = build()
print("nodes", len(e["nodes"]))
m = measure(e)
print({k: m[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']})
save_entry("idx2_v2", e)
