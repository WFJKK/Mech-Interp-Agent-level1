I'll start by inspecting the sandbox: the saved best entry, the lv1 language internals (node counting, cond semantics), and the current measure.## What the network does

The weights are those of an untrained/random RNN (uniform ±0.25, full rank, no dead units); outputs are a skewed mix of classes with tiny logit margins (median ≈ 0.005), ≈ 47% of the 16 units active at every step (per-unit activity p from 0.29 to 0.68, ≈ 7.5 active units per step on average). No semantic description is exact, so the entry is again an exact, weight-independent re-implementation of the forward pass that is cheaper than the network. I am sure of exactness: intermediate states z₂…z₉ and the logits match a numpy forward pass to ≈ 3e-16 relative error on random inputs and on edge inputs (x₀ = 0, x₀ = x₁ = 0, x₀ = ±0.0, x₁ = 0, x₀ = ±1e-200, 1e-320, inputs scaled by 1e±6, all-zero input), and the entry agrees with the reference on 1200–1500 inputs for each of 10 other weight sets (scales 0.05–3, Gaussian weights, zero input weights, zero rows/columns of `recurrent`, all-zero `recurrent`, all-positive weights, all-equal input weights with tied breakpoints), and on 3 × 16384 verifier inputs.

## How you found it

Read the lv1 interpreter source again: `take(x, idx)` costs 1 per entry read and needs an int index; `cond` evaluates and charges only the chosen branch, and a chosen branch that is a build-time constant costs 0 at run time; `concat`/`slice` are free; matmul with an empty contraction is free. The round-2 design spent 3 nodes per conditioned unit per step (condition slice, per-step column slice, cond) and was node-limited (400). The new trick: make the selectable columns *constants* shared by all steps, by packing the unit index into the column (`P[:, j] = [rec[:, j]; ro[:, j]; j]`), so a step needs only 2 nodes per unit (pos slice + cond); the values are then fetched with one `take` on the state using the index row of the selected columns (cast to int). Node counts and costs were checked with `measure`, exactness with `graph(example=x)` + numpy intermediates and with `lv1.measure` against `lv1.run_reference` on random weight dicts.

## The best entry

`idx2_v1` (reward 0.4636, cost 0.534, coverage 1, fidelity 1, 394 nodes, 30 const scalars). `idx2_v2` is the same plus `abs(x0)` (handles x₀ = −0.0 exactly, +1 op; 0.4631/0.4630). Region: every input. Interpretation, exact for any weights (everything computed from the weights inside the entry; constants are only 0.0, the sign pair, index rows 0..16, zero/empty tensors):

1. **z₂ by the 1-D table (132 ops, 43 nodes)** as in round 2 but trimmed: w2 = input.T (1,16), sgn (2,1,1); B_s = relu(s·w) @ rec.T; breakpoints th = −B_s/w; ranks via argsort∘argsort along axis 2 (no reshapes); mask[s,i] = where(w==0, B_s>0, (w>0) == (rank < i)); T = stack([(M·sB)@rec.T, (M·w)@rec.T, w], axis=3) of shape (2,17,16,3). Run time: s = x₀>0, u = x₁/|x₀|, i = Σ[th_s < u], z₂ = T[s,i] @ x[0:3].
2. **Steps 3–9, 2 nodes per unit (41 nodes, ≈ 32 + 18·(n+1) ops per step, n = active units)**: constant packed matrix P (27×17) = [rec | w ; ro | 0 ; 0,1,…,16]; cols[j] = P[:, j:j+1] (17 shared slice nodes), E = zeros (27,0). Per step: pos = z > 0; zp = concat([z, x_t]); A = concat([cols[16]] + [cond(pos[j:j+1], cols[j], E) for j in 0..15], axis=1); idx = cast(A[26], int); z = A[0:16] @ take(zp, idx). No relu is needed (only positive units are selected).
3. **Readout with the same trick (40 nodes, ≈ 41 + 12·n ops)**: A from the same cols with pos = z₉ > 0; logits = A[16:26] @ take(z₉, cast(A[26], int)); argmax.
Totals: ≈ 1567 ops per input (7 steps ≈ 186 each, table 132, readout ≈ 133, build 22k/16384 ≈ 1.4).

## Claims

Claimed 1.0 on this network and expected 1.0 on the second: the entry is algebraically identical to the network for any weights (the table is an exact case analysis of the sign pattern after step 1, including w = 0 and x₀ = 0; the conds are exact column selections; `take` fetches exactly the selected units' values); only float summation order differs (≈ 1e-16 relative, far below observed margins ≥ 5e-8). Verified on 3 × 16384 verifier inputs, 10 random weight sets, and the edge inputs listed above.

## Next

- The design is at its structural floor under 400 nodes: per step 32 fixed (gt + 16 conds) + 18 per included column (16 matmul + cast + take); 5 nodes spare. Removing cast+take (−2 per active unit, ≈ 17 ops/step ≈ 0.006 reward per step) needs the per-step value-carrying columns of round 2 (+16 nodes per step) — not affordable; trimming found: th gather instead of cond (−2 nodes, +15 ops, not worth), P built as [rec; ro; row] plus a separate base column (−1 node).
- Grouping units (cond on `any` of a pair) saves nodes but costs ≈ 7 ops per pair; base (unconditioned) units never pay off (break-even p ≈ 0.89).
- A region cannot help (every input costs < 1 forward pass, so excluding any input lowers the reward).
- Remaining ideas with real upside need either more nodes or a new op: a cell table for step 3 (needs enumerating weight-dependent cells at build, impossible without loops) or a cheaper int index (an int-typed packed matrix would drop the cast).
- Builder code must be re-pasted each call; keep the `graph(example=x)` + numpy-intermediate comparison and the random-weight `lv1.measure` vs `lv1.run_reference` loop as the exactness tests.