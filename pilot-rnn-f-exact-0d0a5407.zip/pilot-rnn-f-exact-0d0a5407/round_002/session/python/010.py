
import numpy as np, time
rng = np.random.default_rng(0)
X = rng.standard_normal((4000, 10))
ref = lv1.run_reference(model, weights, 10, X) if False else None
print(inspect.signature(lv1.run_reference))
