
import inspect
src = inspect.getsource(lv1)
print(src[37400:41000])
