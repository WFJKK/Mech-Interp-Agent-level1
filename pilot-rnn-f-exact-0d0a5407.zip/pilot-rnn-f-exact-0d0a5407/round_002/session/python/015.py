
import numpy as np, time
CODE = r'''
def build_v2(ms, m_ro, perm, slice_cmp=True):
    """ms: dict t->m for t=3..9 (number of conditioned units, the last m in perm order); m_ro for readout."""
    g = graph()
    pm = g.const(np.asarray(perm, dtype=np.int64))
    win = lv1.take(g.weight("input")[:, 0], pm, axis=0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pm, axis=0), pm, axis=1)
    ro = lv1.take(g.weight("readout"), pm, axis=1)
    toks = g.tokens()
    x0, x1, x2 = toks[0], toks[1], toks[2]
    # ---- table for z2 (pre-activation at position 2), exact for any weights
    S = g.const(np.array([[1.0], [-1.0]]))
    hs = lv1.maximum(S * win.reshape(1, 16), 0.0)          # (2,16) h0 / |x0|
    Bs = hs @ rec.T                                          # (2,16)
    wsafe = lv1.where(win == 0.0, 1e-30, win)
    th = lv1.sort(-Bs / wsafe.reshape(1, 16), axis=1)        # (2,16) sorted breakpoints of u = x1/|x0|
    lo = th[:, 0:1] - 1.0
    hi = th[:, 15:16] + 1.0
    mids = (th[:, 0:15] + th[:, 1:16]) * 0.5
    U = lv1.concat([lo, mids, hi], axis=1)                   # (2,17)
    M = lv1.cast((win.reshape(1, 1, 16) * U.reshape(2, 17, 1) + Bs.reshape(2, 1, 16)) > 0.0, "float")  # (2,17,16)
    Pw = (M * win.reshape(1, 1, 16)) @ rec.T                 # (2,17,16)
    Qb = (M * Bs.reshape(2, 1, 16)) @ rec.T
    PQ = lv1.stack([Pw, Qb], axis=3)                         # (2,17,16,2)
    s = x0 > 0.0
    a = abs(x0)
    u = x1 / a
    ths = lv1.cond(s, th[0], th[1])
    i = (ths < u).sum()
    PQs = lv1.cond(s, PQ[0], PQ[1])
    v = lv1.stack([x1, x0], axis=0)
    z = win * x2 + PQs[i] @ v                                # z2
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    for t in range(3, 10):
        m = ms[t]; k = 16 - m
        bottom = lv1.concat([toks[t:t+1], z], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        if m == 0:
            z = B[0:16] @ B[16]
            continue
        c = (z[k:16] > 0.0) if slice_cmp else (z > 0.0)
        parts = [B[:, 0:k+1]]
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k] if slice_cmp else c[j], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1)
        z = A[0:16] @ A[16]
    m = m_ro; k = 16 - m
    B = lv1.concat([ro, z.reshape(1, 16)], axis=0)
    if m == 0:
        logits = ro @ lv1.maximum(z, 0.0)
    else:
        c = (z[k:16] > 0.0) if slice_cmp else (z > 0.0)
        parts = [B[:, 0:k]] if k > 0 else []
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k] if slice_cmp else c[j], B[:, j:j+1], empty_ro))
        A = lv1.concat(parts, axis=1)
        logits = A[0:10] @ A[10]
    return g, g.entry(interpretation=logits.argmax())
'''
exec(CODE)
perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
rng = np.random.default_rng(0)
X = rng.standard_normal((3000, 10))
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ans, ops = lv1.run_reference(ref_entry, weights, 10, X)
for ms_all, mro in [(0, 0), (16, 16), (12, 4)]:
    ms = {t: ms_all for t in range(3, 10)}
    g, e = build_v2(ms, mro, perm)
    st = lv1.check_structure(e)
    t0 = time.time()
    m = lv1.measure(e, weights, 10, X, ans, ops)
    print(ms_all, mro, st, {k: m[k] for k in ['fidelity', 'cost', 'b', 'build_ops']}, round(time.time()-t0, 1))
