
import numpy as np, time
CODE = r'''
def build_chain(cond_units, ro_units, perm=None):
    g = graph()
    win = g.weight("input")[:, 0]
    rec = g.weight("recurrent")
    ro = g.weight("readout")
    if perm is not None:
        pm = g.const(np.asarray(perm, dtype=np.int64))
        win = lv1.take(win, pm, axis=0)
        rec = lv1.take(lv1.take(rec, pm, axis=0), pm, axis=1)
        ro = lv1.take(ro, pm, axis=1)
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    toks = g.tokens()
    z = win * toks[0]
    for t in range(1, 10):
        units = cond_units[t]
        base = [j for j in range(16) if j not in units]
        k = len(base)
        assert base == list(range(k)), (t, base)
        bottom = lv1.concat([toks[t:t+1], z], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        c = z > 0.0
        parts = [B[:, 0:k+1]]
        for j in units:
            parts.append(lv1.cond(c[j], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1) if len(parts) > 1 else parts[0]
        z = A[0:16] @ A[16]
    units = ro_units
    base = [j for j in range(16) if j not in units]
    k = len(base)
    assert base == list(range(k))
    B = lv1.concat([ro, z.reshape(1, 16)], axis=0)
    c = z > 0.0
    parts = [B[:, 0:k]] if k > 0 else []
    for j in units:
        parts.append(lv1.cond(c[j], B[:, j:j+1], empty_ro))
    A = lv1.concat(parts, axis=1) if len(parts) > 1 else parts[0]
    logits = A[0:10] @ A[10]
    return g, g.entry(interpretation=logits.argmax())
'''
exec(CODE)
rng = np.random.default_rng(0)
X = rng.standard_normal((3000, 10))
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ans, ops = lv1.run_reference(ref_entry, weights, 10, X)
cu = {t: list(range(16)) for t in range(1, 10)}
g, e = build_chain(cu, list(range(16)))
t0=time.time()
m = lv1.measure(e, weights, 10, X, ans, ops)
print(m, time.time()-t0)
