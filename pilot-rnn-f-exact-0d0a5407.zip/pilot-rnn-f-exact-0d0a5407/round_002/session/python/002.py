
import inspect
src = inspect.getsource(lv1)
print(src[0:3600])
