
import os, inspect
print(info)
print(os.listdir('.'))
print([n for n in dir(lv1) if not n.startswith('_')])
src = inspect.getsource(lv1)
print(len(src))
import re
# find cond / concat / node counting definitions
for name in ['def cond', 'def concat', 'def _count', 'nodes', 'def measure', 'class Graph', 'def entry']:
    for m in re.finditer(name, src):
        print(name, m.start())
