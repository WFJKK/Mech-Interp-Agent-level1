
import numpy as np
exec(CODE) if 'CODE' in globals() else None
