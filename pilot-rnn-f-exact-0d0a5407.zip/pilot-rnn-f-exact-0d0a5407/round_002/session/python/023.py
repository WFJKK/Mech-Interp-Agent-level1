
import numpy as np
exec(open('tmp/code.py').read())
perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
ms = {t: 11 for t in range(3, 10)}
x = np.array([-2,0,0,0,0,0,0,0,0,0], dtype=float)
G = graph(example=x)
g, e = build_v6(ms, 0, perm, G=G)
w = weights['input'][:,0][perm]; rec = weights['recurrent'][np.ix_(perm, perm)]
# numpy reference states (permuted)
h = np.maximum(w * x[0], 0); 
z1 = w*x[1] + rec @ h; h1 = np.maximum(z1, 0)
z2 = w*x[2] + rec @ h1
print("z2 np", z2)
# find node for z2: it's the matmul T[sidx,i] @ toks[0:3]
for idx, node in enumerate(g.nodes):
    if node['op'] == 'matmul':
        v = g.values[idx]
        if v.shape == (16,):
            print(idx, v); break
# show th, u, i, mask
names = {}
for idx, node in enumerate(g.nodes):
    if node['op'] in ('sum', 'div', 'gather', 'cast', 'gt'):
        print(idx, node['op'], g.values[idx] if g.values[idx].size <= 20 else g.values[idx].shape)
print("mask np", (z1 > 0).astype(int))
