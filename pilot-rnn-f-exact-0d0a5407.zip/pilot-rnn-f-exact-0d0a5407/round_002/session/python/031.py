
import numpy as np, time
def build_v7(ms, m_ro, perm, G=None):
    g = G if G is not None else graph()
    pm = g.const(np.asarray(perm, dtype=np.int64))
    win = lv1.take(g.weight("input")[:, 0], pm, axis=0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pm, axis=0), pm, axis=1)
    ro = lv1.take(g.weight("readout"), pm, axis=1)
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    win_r = win.reshape(1, 1, 16)
    S = g.const(np.array([[-1.0], [1.0]]))
    hs = lv1.maximum(S * win.reshape(1, 16), 0.0)
    Bs = hs @ rec.T
    th = -Bs / win.reshape(1, 16)
    rank = lv1.argsort(lv1.argsort(th, axis=1), axis=1)
    below = rank.reshape(2, 1, 16) < g.arange(17).reshape(1, 17, 1)
    M = lv1.where(win_r > 0.0, below, lv1.where(win_r < 0.0, ~below, Bs.reshape(2, 1, 16) > 0.0))
    Mf = lv1.cast(M, "float")
    Pw = (Mf * win_r) @ rec.T
    Qb = (Mf * (S * Bs).reshape(2, 1, 16)) @ rec.T
    Wb = lv1.where(M, win_r, win_r)
    T = lv1.stack([Qb, Pw, Wb], axis=3)
    s = x0 > 0.0
    sidx = lv1.cast(s, "int")
    u = x1 / abs(x0)
    ths = lv1.cond(s, th[1], th[0])
    i = (ths < u).sum()
    z = T[sidx, i] @ toks[0:3]
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    for t in range(3, 10):
        m = ms[t]; k = 16 - m
        if m == 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
            B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
            z = B[0:16] @ B[16]
            continue
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = lv1.concat([toks[t:t+1], z], axis=0)
        else:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        parts = [B[:, 0:k+1]]
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1)
        z = A[0:16] @ A[16]
    m = m_ro; k = 16 - m
    if m == 0:
        logits = ro @ lv1.maximum(z, 0.0)
    else:
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = z
        else:
            bottom = lv1.maximum(z, 0.0)
        B = lv1.concat([ro, bottom.reshape(1, 16)], axis=0)
        parts = [B[:, 0:k]] if k > 0 else []
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j:j+1], empty_ro))
        A = lv1.concat(parts, axis=1)
        logits = A[0:10] @ A[10]
    return g, g.entry(interpretation=logits.argmax())

perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
ms = {3: 12, 4: 12, 5: 12, 6: 12, 7: 12, 8: 11, 9: 11}
g, e = build_v7(ms, 0, perm)
print(lv1.check_structure(e))
# quick exactness on random weights with outputs (fast, 300 inputs each)
rng = np.random.default_rng(11); X = rng.standard_normal((300, 10))
for seed, scale in [(21, 0.25), (22, 1.0), (23, 2.0)]:
    r = np.random.default_rng(seed)
    wts = {'input': r.uniform(-scale, scale, (16, 1)), 'recurrent': r.uniform(-scale, scale, (16, 16)), 'readout': r.uniform(-scale, scale, (10, 16))}
    if seed == 22: wts['input'][[1, 4], 0] = 0.0
    gr = lv1.Graph(wts, 10, real=True); re_ = gr.entry(interpretation=model.reference(gr, lv1))
    a, o = lv1.run_reference(re_, wts, 10, X)
    mm = lv1.measure(e, wts, 10, X, a, o)
    print(seed, scale, mm['fidelity'], round(mm['cost'], 4))
t0 = time.time(); print(measure(e), time.time() - t0)
save_entry("chain12", e)
