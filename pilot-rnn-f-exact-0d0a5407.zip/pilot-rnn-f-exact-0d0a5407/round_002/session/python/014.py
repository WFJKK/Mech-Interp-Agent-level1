
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
rng = np.random.default_rng(1)
X = rng.standard_normal((20000, 10))
H = np.zeros((20000, 16)); P = np.zeros((10, 16))
for t in range(10):
    H = np.maximum(w * X[:, t:t+1] + H @ rec.T, 0)
    P[t] = (H > 0).mean(0)
np.set_printoptions(precision=2, suppress=True, linewidth=150)
print(P)
print("overall", P[2:].mean(0))
order = np.argsort(-P[2:].mean(0))
print(order)
