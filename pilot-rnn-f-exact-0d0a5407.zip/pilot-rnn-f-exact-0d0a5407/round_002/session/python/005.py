
import inspect
src = inspect.getsource(lv1)
print(src[7600:11000])
