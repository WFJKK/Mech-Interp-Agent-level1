
import inspect, re
src = inspect.getsource(lv1)
for m in re.finditer('errstate', src):
    print(src[max(0,m.start()-300):m.start()+100].replace('\n','\n   '))
    print('-----')
