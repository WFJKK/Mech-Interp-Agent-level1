
import numpy as np, time
CODE = r'''
def build_v7(ms, m_ro, perm, G=None):
    g = G if G is not None else graph()
    pm = g.const(np.asarray(perm, dtype=np.int64))
    win = lv1.take(g.weight("input")[:, 0], pm, axis=0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pm, axis=0), pm, axis=1)
    ro = lv1.take(g.weight("readout"), pm, axis=1)
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    win_r = win.reshape(1, 1, 16)
    S = g.const(np.array([[-1.0], [1.0]]))                    # row 0: x0 <= 0, row 1: x0 > 0
    hs = lv1.maximum(S * win.reshape(1, 16), 0.0)            # (2,16)  h_0 / |x0|
    Bs = hs @ rec.T                                            # (2,16)  (rec @ h_0) / |x0|
    th = -Bs / win.reshape(1, 16)                              # (2,16)  breakpoints of sign(z_1) in u = x1/|x0|
    rank = lv1.argsort(lv1.argsort(th, axis=1), axis=1)        # (2,16)
    below = rank.reshape(2, 1, 16) < g.arange(17).reshape(1, 17, 1)   # (2,17,16): theta_j < u on interval i
    M = lv1.where(win_r > 0.0, below, lv1.where(win_r < 0.0, ~below, Bs.reshape(2, 1, 16) > 0.0))  # mask of h_1
    Mf = lv1.cast(M, "float")
    Pw = (Mf * win_r) @ rec.T                                  # coefficient of x1 in z_2
    Qb = (Mf * (S * Bs).reshape(2, 1, 16)) @ rec.T             # coefficient of x0 in z_2 (|x0| = S x0)
    Wb = lv1.where(M, win_r, win_r)                            # coefficient of x2
    T = lv1.stack([Qb, Pw, Wb], axis=3)                        # (2,17,16,3)
    s = x0 > 0.0
    sidx = lv1.cast(s, "int")
    u = x1 / abs(x0)
    ths = lv1.cond(s, th[1], th[0])
    i = (ths < u).sum()
    z = T[sidx, i] @ toks[0:3]                                 # z_2 exactly
    dbg = dict(z2=z)
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    for t in range(3, 10):
        m = ms[t]; k = 16 - m
        if m == 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
            B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
            z = B[0:16] @ B[16]
            dbg['z%d' % t] = z
            continue
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = lv1.concat([toks[t:t+1], z], axis=0)
        else:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        parts = [B[:, 0:k+1]]
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1)
        z = A[0:16] @ A[16]
        dbg['z%d' % t] = z
    m = m_ro; k = 16 - m
    if m == 0:
        logits = ro @ lv1.maximum(z, 0.0)
    else:
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = z
        else:
            bottom = lv1.maximum(z, 0.0)
        B = lv1.concat([ro, bottom.reshape(1, 16)], axis=0)
        parts = [B[:, 0:k]] if k > 0 else []
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j:j+1], empty_ro))
        A = lv1.concat(parts, axis=1)
        logits = A[0:10] @ A[10]
    dbg['logits'] = logits
    return g, g.entry(interpretation=logits.argmax()), dbg
'''
exec(CODE)
perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
ms = {t: 11 for t in range(3, 10)}

def np_states(wts, x, perm):
    w = wts['input'][:,0][perm]; rec = wts['recurrent'][np.ix_(perm, perm)]; ro = wts['readout'][:, perm]
    zs = {}
    h = np.zeros(16)
    for t in range(10):
        z = w * x[t] + rec @ h; h = np.maximum(z, 0); zs['z%d' % t] = z
    zs['logits'] = ro @ h
    return zs

def check_intermediates(wts, xs, perm, ms):
    worst = 0.0
    for x in xs:
        G = lv1.Graph(wts, 10, example=x, real=True)
        g, e, dbg = build_v7(ms, 0, perm, G=G)
        zs = np_states(wts, x, perm)
        for key in ['z2','z3','z5','z9','logits']:
            d = np.abs(dbg[key].value - zs[key]).max()
            worst = max(worst, d)
    return worst

rng = np.random.default_rng(5)
Xr = rng.standard_normal((40, 10))
Xe = np.array([[0]*10, [0,0,1,2,3,-1,-2,0.5,0.3,0.1], [0,1,0,0,0,0,0,0,0,0], [0,-1,0.3,0.2,-0.5,1,1,1,1,1], [1e-200, 1, 0.5]+[0.3]*7, [-1e-200, -1, 0.5]+[0.3]*7, [2,0,0,0,0,0,0,0,0,0], [-2,0,0,0,0,0,0,0,0,0], [1e100, 1e100, 1, 1, 1, 1, 1, 1, 1, 1], [-3, 1e-300, 0.1]+[0.2]*7], dtype=float)
print("this net, random:", check_intermediates(weights, Xr, perm, ms))
print("this net, edge  :", check_intermediates(weights, Xe, perm, ms))
# random weights, incl. zero input weights
for seed, scale in [(1, 0.25), (2, 1.0), (3, 0.05), (4, 3.0)]:
    r = np.random.default_rng(seed)
    wts = {'input': r.uniform(-scale, scale, (16, 1)), 'recurrent': r.uniform(-scale, scale, (16, 16)), 'readout': r.uniform(-scale, scale, (10, 16))}
    if seed == 2:
        wts['input'][[0, 5, 9], 0] = 0.0   # exact-zero input weights
    if seed == 3:
        wts['input'][:, 0] = 0.0           # all zero input weights
    print(seed, scale, "random:", check_intermediates(wts, Xr[:15], perm, ms), "edge:", check_intermediates(wts, Xe, perm, ms))
