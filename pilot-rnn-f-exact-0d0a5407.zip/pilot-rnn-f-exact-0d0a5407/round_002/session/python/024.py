
import numpy as np, time
CODE = r'''
def build_v6(ms, m_ro, perm, G=None):
    g = G if G is not None else graph()
    pm = g.const(np.asarray(perm, dtype=np.int64))
    win = lv1.take(g.weight("input")[:, 0], pm, axis=0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pm, axis=0), pm, axis=1)
    ro = lv1.take(g.weight("readout"), pm, axis=1)
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    win_r = win.reshape(1, 1, 16)
    S = g.const(np.array([[-1.0], [1.0]]))
    hs = lv1.maximum(S * win.reshape(1, 16), 0.0)
    Bs = hs @ rec.T
    th = -Bs / win.reshape(1, 16)
    rank = lv1.argsort(lv1.argsort(th, axis=1), axis=1)
    below = rank.reshape(2, 1, 16) < g.arange(17).reshape(1, 17, 1)
    M = lv1.where(win_r > 0.0, below, lv1.where(win_r < 0.0, ~below, Bs.reshape(2, 1, 16) > 0.0))
    Mf = lv1.cast(M, "float")
    Pw = (Mf * win_r) @ rec.T
    Qb = (Mf * Bs.reshape(2, 1, 16)) @ rec.T
    Wb = lv1.where(M, win_r, win_r)
    T = lv1.stack([Qb, Pw, Wb], axis=3)
    s = x0 > 0.0
    sidx = lv1.cast(s, "int")
    u = x1 / abs(x0)
    ths = lv1.cond(s, th[1], th[0])
    i = (ths < u).sum()
    z = T[sidx, i] @ toks[0:3]
    dbg = dict(th=th, rank=rank, M=M, u=u, i=i, z2=z, Bs=Bs, sidx=sidx)
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    for t in range(3, 10):
        m = ms[t]; k = 16 - m
        if m == 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
            B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
            z = B[0:16] @ B[16]
            continue
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = lv1.concat([toks[t:t+1], z], axis=0)
        else:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        parts = [B[:, 0:k+1]]
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1)
        z = A[0:16] @ A[16]
        dbg['z%d' % t] = z
    m = m_ro; k = 16 - m
    if m == 0:
        logits = ro @ lv1.maximum(z, 0.0)
    else:
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = z
        else:
            bottom = lv1.maximum(z, 0.0)
        B = lv1.concat([ro, bottom.reshape(1, 16)], axis=0)
        parts = [B[:, 0:k]] if k > 0 else []
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j:j+1], empty_ro))
        A = lv1.concat(parts, axis=1)
        logits = A[0:10] @ A[10]
    dbg['logits'] = logits
    return g, g.entry(interpretation=logits.argmax()), dbg
'''
exec(CODE)
perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
ms = {t: 11 for t in range(3, 10)}
x = np.array([-2,0,0,0,0,0,0,0,0,0], dtype=float)
G = graph(example=x)
g, e, dbg = build_v6(ms, 0, perm, G=G)
w = weights['input'][:,0][perm]; rec = weights['recurrent'][np.ix_(perm, perm)]
np.set_printoptions(precision=4, suppress=True, linewidth=160)
h = np.maximum(w * x[0], 0)
z1 = w*x[1] + rec @ h; h1 = np.maximum(z1, 0)
z2 = w*x[2] + rec @ h1
print("z2 np ", z2); print("z2 ent", dbg['z2'].value)
print("u", dbg['u'].value, "i", dbg['i'].value, 'sidx', dbg['sidx'].value)
print("th0", dbg['th'].value[0]); print("rank0", dbg['rank'].value[0])
print("mask np ", (z1 > 0).astype(int)); print("mask ent", dbg['M'].value[0, int(dbg['i'].value)].astype(int))
print("Bs0", dbg['Bs'].value[0]); print("w", w)
for t in range(3, 10):
    z = w*x[t] + rec @ np.maximum(z2 if t == 3 else z, 0)
    print(t, np.abs(z - dbg['z%d'%t].value).max())
