
import inspect, numpy as np
print(inspect.signature(lv1.run_reference))
print(inspect.getsource(lv1.run_reference)[:800])
