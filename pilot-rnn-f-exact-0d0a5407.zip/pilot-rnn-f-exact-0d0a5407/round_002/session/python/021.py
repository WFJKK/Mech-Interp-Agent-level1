
import numpy as np
exec(CODE) if 'CODE' in dir() else None
