
import numpy as np, time
exec(entries and "" or "")
# re-define builder (no persistence between calls)
CODE = open('/dev/null').read() if False else None
