
import numpy as np
W = weights
def build_chain(cond_units, ro_units, perm=None):
    """cond_units: list over steps t=1..9 (z_t from z_{t-1}) of lists of unit indices conditioned on.
    perm: optional unit permutation (applied to weights in build) so that unconditioned units are a contiguous prefix."""
    g = graph()
    win = g.weight("input")[:, 0]          # (16,)
    rec = g.weight("recurrent")
    ro = g.weight("readout")
    if perm is not None:
        pm = g.const(np.asarray(perm, dtype=np.int64))
        win = lv1.take(win, pm, axis=0)
        rec = lv1.take(lv1.take(rec, pm, axis=0), pm, axis=1)
        ro = lv1.take(ro, pm, axis=1)
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)   # (16, 17): col 0 = w, cols 1..16 = rec
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    toks = g.tokens()
    z = win * toks[0]                       # z_1 = w x_0 (16 ops)
    for t in range(1, 10):
        units = cond_units[t]
        base = [j for j in range(16) if j not in units]
        # require base contiguous prefix [0..k-1]
        k = len(base)
        assert base == list(range(k)), (t, base)
        bottom = lv1.concat([toks[t:t+1], z], axis=0)          # (17,)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)  # (17, 17)
        c = z > 0.0
        parts = [B[:, 0:k+1]]
        for j in units:
            parts.append(lv1.cond(c[j], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1) if len(parts) > 1 else parts[0]
        z = A[0:16] @ A[16]
    # readout
    units = ro_units
    base = [j for j in range(16) if j not in units]
    k = len(base)
    assert base == list(range(k))
    B = lv1.concat([ro, z.reshape(1, 16)], axis=0)   # (11, 16)
    c = z > 0.0
    parts = [B[:, 0:k]] if k > 0 else []
    for j in units:
        parts.append(lv1.cond(c[j], B[:, j:j+1], empty_ro))
    A = lv1.concat(parts, axis=1) if len(parts) > 1 else parts[0]
    logits = A[0:10] @ A[10]
    out = logits.argmax()
    return g, g.entry(interpretation=out)

cu = {t: list(range(16)) for t in range(1, 10)}
g, e = build_chain(cu, list(range(16)))
print(lv1.check_structure(e))
print(measure(e))
