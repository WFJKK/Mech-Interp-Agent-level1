
import inspect
print(inspect.signature(lv1.measure))
print(inspect.getsource(lv1.measure)[:1500])
