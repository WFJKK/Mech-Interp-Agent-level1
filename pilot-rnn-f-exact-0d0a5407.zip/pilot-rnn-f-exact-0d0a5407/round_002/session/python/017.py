
import numpy as np, time
CODE = r'''
def build_v4(ms, m_ro, perm):
    g = graph()
    pm = g.const(np.asarray(perm, dtype=np.int64))
    win = lv1.take(g.weight("input")[:, 0], pm, axis=0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pm, axis=0), pm, axis=1)
    ro = lv1.take(g.weight("readout"), pm, axis=1)
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    win_r = win.reshape(1, 1, 16)
    S = g.const(np.array([[1.0], [-1.0]]))
    hs = lv1.maximum(S * win.reshape(1, 16), 0.0)           # (2,16)  h_0 / |x_0| for sign +,-
    Bs = hs @ rec.T                                           # (2,16)
    wsafe = lv1.where(win == 0.0, 1e-30, win)
    th = -Bs / wsafe.reshape(1, 16)                           # (2,16) breakpoints of u = x1/|x0|
    rank = lv1.argsort(lv1.argsort(th, axis=1), axis=1)       # (2,16)
    I = g.arange(17).reshape(1, 17, 1)
    below = rank.reshape(2, 1, 16) < I                        # (2,17,16): theta_j < u in interval i
    M = lv1.where(win_r > 0.0, below, lv1.where(win_r < 0.0, ~below, Bs.reshape(2, 1, 16) > 0.0))
    Mf = lv1.cast(M, "float")
    Pw = (Mf * win_r) @ rec.T
    Qb = (Mf * Bs.reshape(2, 1, 16)) @ rec.T
    Wb = Mf * 0.0 + win_r
    T = lv1.stack([Qb, Pw, Wb], axis=3)                       # (2,17,16,3)
    s = x0 > 0.0
    u = x1 / abs(x0)
    ths = lv1.cond(s, th[0], th[1])
    i = (ths < u).sum()
    Ts = lv1.cond(s, T[0], T[1])
    z = Ts[i] @ toks[0:3]                                     # z_2
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    for t in range(3, 10):
        m = ms[t]; k = 16 - m
        if m == 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
            B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
            z = B[0:16] @ B[16]
            continue
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = lv1.concat([toks[t:t+1], z], axis=0)
        else:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        parts = [B[:, 0:k+1]]
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1)
        z = A[0:16] @ A[16]
    m = m_ro; k = 16 - m
    if m == 0:
        logits = ro @ lv1.maximum(z, 0.0)
    else:
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = z
        else:
            bottom = lv1.maximum(z, 0.0)
        B = lv1.concat([ro, bottom.reshape(1, 16)], axis=0)
        parts = [B[:, 0:k]] if k > 0 else []
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j:j+1], empty_ro))
        A = lv1.concat(parts, axis=1)
        logits = A[0:10] @ A[10]
    return g, g.entry(interpretation=logits.argmax())
'''
exec(CODE)
perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
rng = np.random.default_rng(0)
X = rng.standard_normal((2000, 10))
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ans, ops = lv1.run_reference(ref_entry, weights, 10, X)
for ms_all, mro in [(0, 0), (16, 16), (11, 0), (12, 0)]:
    ms = {t: ms_all for t in range(3, 10)}
    g, e = build_v4(ms, mro, perm)
    st = lv1.check_structure(e)
    t0 = time.time()
    m = lv1.measure(e, weights, 10, X, ans, ops)
    print(ms_all, mro, st, {k: m[k] for k in ['fidelity', 'cost', 'build_ops']}, round(time.time()-t0, 1))
