
import inspect
src = inspect.getsource(lv1)
i = src.find('class Expr')
print(src[i:i+3000])
print(lv1.show(entries['best'])[:1500])
print(lv1.check_structure(entries['best']))
