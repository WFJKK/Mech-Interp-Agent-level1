
import numpy as np, time
CODE = r'''
def build_v5(ms, m_ro, perm, safe_w=False):
    g = graph()
    pm = g.const(np.asarray(perm, dtype=np.int64))
    win = lv1.take(g.weight("input")[:, 0], pm, axis=0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pm, axis=0), pm, axis=1)
    ro = lv1.take(g.weight("readout"), pm, axis=1)
    toks = g.tokens()
    x0, x1 = toks[0], toks[1]
    win_r = win.reshape(1, 1, 16)
    S = g.const(np.array([[1.0], [-1.0]]))
    hs = lv1.maximum(S * win.reshape(1, 16), 0.0)           # (2,16)  h_0 / |x_0| for sign(x0) = +,-
    Bs = hs @ rec.T                                           # (2,16)  rec @ h_0 / |x_0|
    wd = lv1.where(win == 0.0, 1e-30, win) if safe_w else win
    th = -Bs / wd.reshape(1, 16)                              # (2,16)  breakpoints in u = x1/|x0| of sign(z_1)
    rank = lv1.argsort(lv1.argsort(th, axis=1), axis=1)       # (2,16)
    below = rank.reshape(2, 1, 16) < g.arange(17).reshape(1, 17, 1)   # (2,17,16): theta_j < u on interval i
    M = lv1.where(win_r > 0.0, below, lv1.where(win_r < 0.0, ~below, Bs.reshape(2, 1, 16) > 0.0))  # h_1 mask
    Mf = lv1.cast(M, "float")
    Pw = (Mf * win_r) @ rec.T                                 # coefficient of x1 in z_2
    Qb = (Mf * Bs.reshape(2, 1, 16)) @ rec.T                  # coefficient of |x0| -> times x0 with sign folded
    Wb = lv1.where(M, win_r, win_r)                           # coefficient of x2
    T = lv1.stack([Qb, Pw, Wb], axis=3)                       # (2,17,16,3)
    sidx = lv1.cast(x0 <= 0.0, "int")
    u = x1 / abs(x0)
    cnt = (th < u).sum(axis=1)                                # (2,)
    i = cnt[sidx]
    z = T[sidx, i] @ toks[0:3]                                # z_2 exactly
    rec_aug = lv1.concat([win.reshape(16, 1), rec], axis=1)
    empty = g.const(np.zeros((17, 0)))
    empty_ro = g.const(np.zeros((11, 0)))
    for t in range(3, 10):
        m = ms[t]; k = 16 - m
        if m == 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
            B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
            z = B[0:16] @ B[16]
            continue
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = lv1.concat([toks[t:t+1], z], axis=0)
        else:
            bottom = lv1.concat([toks[t:t+1], lv1.maximum(z, 0.0)], axis=0)
        B = lv1.concat([rec_aug, bottom.reshape(1, 17)], axis=0)
        parts = [B[:, 0:k+1]]
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j+1:j+2], empty))
        A = lv1.concat(parts, axis=1)
        z = A[0:16] @ A[16]
    m = m_ro; k = 16 - m
    if m == 0:
        logits = ro @ lv1.maximum(z, 0.0)
    else:
        zt = z[k:16]
        c = zt > 0.0
        if m >= 3 and k > 0:
            bottom = lv1.concat([lv1.maximum(z[0:k], 0.0), zt], axis=0)
        elif k == 0:
            bottom = z
        else:
            bottom = lv1.maximum(z, 0.0)
        B = lv1.concat([ro, bottom.reshape(1, 16)], axis=0)
        parts = [B[:, 0:k]] if k > 0 else []
        for j in range(k, 16):
            parts.append(lv1.cond(c[j - k], B[:, j:j+1], empty_ro))
        A = lv1.concat(parts, axis=1)
        logits = A[0:10] @ A[10]
    return g, g.entry(interpretation=logits.argmax())
'''
exec(CODE)
perm = [2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 12, 5, 10, 14]
rng = np.random.default_rng(0)
X = rng.standard_normal((2000, 10))
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ans, ops = lv1.run_reference(ref_entry, weights, 10, X)
for ms_all, mro in [(0, 0), (11, 0)]:
    ms = {t: ms_all for t in range(3, 10)}
    g, e = build_v5(ms, mro, perm)
    st = lv1.check_structure(e)
    m = lv1.measure(e, weights, 10, X, ans, ops)
    print(ms_all, mro, st, {k: m[k] for k in ['fidelity', 'cost', 'build_ops']})
# edge inputs and random weights
def check_weights(wts, Xe, msd, mro):
    gr = lv1.Graph(wts, 10, real=True); re_ = gr.entry(interpretation=model.reference(gr, lv1))
    a, o = lv1.run_reference(re_, wts, 10, Xe)
    gg = lv1.Graph(wts, 10, real=True)
    # build with these weights: need graph() replaced -> use global override
    return a, o
ms = {t: 11 for t in range(3, 10)}
Xe = np.array([[0]*10, [0,0,1,2,3,-1,-2,0.5,0.3,0.1], [0,1,0,0,0,0,0,0,0,0], [0,-1,0.3,0.2,-0.5,1,1,1,1,1], [1e-200, 1, 0.5]+[0.3]*7, [-1e-200, -1, 0.5]+[0.3]*7, [2,0,0,0,0,0,0,0,0,0], [-2,0,0,0,0,0,0,0,0,0]], dtype=float)
a, o = lv1.run_reference(ref_entry, weights, 10, Xe)
g, e = build_v5(ms, 0, perm)
m = lv1.measure(e, weights, 10, Xe, a, o)
print('edge', m['fidelity'], m['n_in_region'])
