
import inspect
src = inspect.getsource(lv1)
print(src[11000:17000])
