
print('CODE' in globals(), 'build_v7' in globals())
