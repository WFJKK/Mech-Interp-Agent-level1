
import inspect
src = inspect.getsource(lv1)
print(src[17000:23000])
