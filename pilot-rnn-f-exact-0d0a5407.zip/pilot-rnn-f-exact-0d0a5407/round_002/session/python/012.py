
import numpy as np, time
rng = np.random.default_rng(0)
X = rng.standard_normal((3000, 10))
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
t0=time.time()
ans, ops = lv1.run_reference(ref_entry, weights, 10, X)
print(ops, time.time()-t0)
cu = {t: list(range(16)) for t in range(1, 10)}
g, e = build_chain(cu, list(range(16)))
t0=time.time()
m = lv1.measure(e, weights, 10, X, ans, ops)
print(m, time.time()-t0)
