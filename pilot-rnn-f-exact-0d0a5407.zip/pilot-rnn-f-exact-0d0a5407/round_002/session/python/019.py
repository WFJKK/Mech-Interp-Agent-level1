
import inspect, re
src = inspect.getsource(lv1)
i = src.find('def _norm'); print(src[i:i+600])
i = src.find('def _guard'); print(src[i:i+400])
