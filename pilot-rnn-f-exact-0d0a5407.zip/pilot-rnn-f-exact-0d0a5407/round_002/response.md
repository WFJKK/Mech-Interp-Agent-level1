I'll start by inspecting the sandbox: the lv1 language internals (cond/concat semantics, node counting) and the saved best entry.Reward 0.433 locally, exact on this and random weights. Submitting.Submitted and scored: **chain12b** → reward 0.4352 (coverage 1, fidelity 1, cost 0.562, 400 nodes), up from 0.268 in round 1.

## What the network does

The weights look like an untrained/random RNN (uniform ±0.25, full rank, no dead units); outputs are a skewed mix of classes with tiny logit margins (median ~0.005), ~47% of units active per step, activity per unit stationary from position 2 on (per-unit p ranges 0.29–0.68). No semantic description is exact, so the entry is again an exact, weight-independent re-implementation that is cheaper than the forward pass. I am sure of its exactness: it matches the reference to ~5e-16 relative error on every intermediate state z_2…z_9 and the logits, on this network and on 6 random weight sets (scales 0.05–3, with exact-zero input weights, zero rows/columns of rec, all-positive weights) and on edge inputs (x0 = 0, x0 = x1 = 0, x0 = ±1e-200, 1e-320, huge values, x1 = 0).

## How you found it

Read the lv1 interpreter source: `cond` only computes and charges the chosen branch and does not require both branches to have the same shape, `concat` is free and accepts empty (17,0) tensors, matmul cost = result entries × contracted length (0 if empty). That allows a *linear-in-m* sparse matvec instead of the 2^m cond trees of round 1. Measured per-step per-unit activity with numpy (`network_outputs`-style re-run), chose a unit permutation by activity, counted nodes per design, and verified exactness by building the graph with `graph(example=x)` and comparing node values to a numpy reference, plus `lv1.measure` against `lv1.run_reference` on random weight dicts.

## The best entry

`chain12b` (also `chain12`, `chain11` are the same design with fewer units). Region: every input. Interpretation (all computed from the weights inside the entry; the only constants are the permutation, [[-1],[1]], 0.0, and two empty (17,0)/(11,0) tensors):
1. **z_2 by a 1-D table (≈132 ops).** Units are permuted (most-active first). h_0 = |x0|·relu(±w); mask of h_1 depends only on sign(x0) and u = x1/|x0| via 16 breakpoints θ = −B_s/w (B_s = rec@relu(±w)); masks per interval are computed from *ranks* (argsort∘argsort) with `where(w==0, B_s>0, (w>0)==below)` so w = 0 is exact; table T[s, i] = (16×3) coefficients of (x0, x1, x2) → z_2 = T[sidx, i] @ toks[0:3], i = Σ[θ_s < u].
2. **Dynamic-width sparse matvec for steps 3–9 (≈185 ops/step instead of 304).** B = [[w | rec]; [x_t | relu(z[:k]) | z[k:]]] (17×17, free concat). For each of the last m units (m = 12 at steps 3–8, 11 at step 9): `cond(z_j > 0, B[:, j], empty)`; concat the base block and the chosen columns (free), then z_next = A[0:16] @ A[16]: cost 16×(1 + k + #active). No relu on conditioned units (they enter only if positive). 3 nodes per unit, 13 per step — the 400-node limit is exactly filled.
3. Readout plain: ro @ relu(z_9), argmax.
Cost 0.562: 7 steps ≈ 1316 + table 132 + readout 185 + build 22.9k/16384.

## Claims

Claimed 1.0 on this network, expected 1.0 on the second: the entry is algebraically identical to the network for any weights (table = exact case analysis, conds = exact column selection); only float summation order differs (~1e-16 relative, far below observed margins ≥ 5e-8). Verified on 2×16384 verifier inputs and on random weights as above.

## Next

- The design is node-limited (3 nodes/unit, 13 fixed/step, ~60 for the table). Any further node trim converts to +7 ops per unit (≈ +0.0024 reward); candidates: avoid `toks[t:t+1]`/reshape per step, 2-node M construction. Nothing found below 3 nodes/unit (cond needs a scalar-bool node and a column node each).
- Full conditioning (m = 16 at all steps + readout) would give cost ≈ 0.49 (reward ≈ 0.50) if the node limit were ≥ 540.
- Readout chain is not worth nodes (10(1−p)−1 per unit); recurrent steps are (16(1−p)−1).
- Builder code must be re-pasted each call (nothing persists); keep the `graph(example=x)` + numpy intermediate comparison as the exactness test — it caught a sign bug (coefficient of x0 for x0<0) that output-level tests missed because errors decay ×0.35/step.