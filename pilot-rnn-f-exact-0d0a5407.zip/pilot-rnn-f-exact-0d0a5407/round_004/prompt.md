# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 4 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx real numbers, x_0 to x_(n_ctx - 1). The network reads them one at a time, in that order.
In an entry, g.token(t) is x_t, as a float, and g.tokens() is all of them; the output is still a whole number.

The network is a recurrent network with one layer of d_hidden units, a ReLU and no biases. Its weights:

    input       d_hidden x 1
    recurrent   d_hidden x d_hidden
    readout     n_outputs x d_hidden

Its state h, a vector of d_hidden numbers, starts at zero. At each position t, in order, it becomes

    h = relu(input x_t + recurrent h)

where relu sets every negative number to zero. After the last position, readout h gives n_outputs numbers,
and the output is the position of the highest (the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)  # the first position: the state before it is zero, and so is recurrent h
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()
```

Sizes: n_ctx = 10, d_hidden = 16, outputs: 10. One forward pass of the network costs 2,937 operations under the prices
below.

## The data set

An input is ten real numbers, x_0 to x_9, each drawn on its own from the standard normal distribution (mean 0, standard deviation 1). The data set is every input that can be drawn this way, each weighted by how likely it is to be drawn. There are infinitely many, so the verifier scores a sample.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

This run asks one more thing of an entry: that it be exact whatever the weights. When the rounds are
over, the entries are also run, unchanged, on several other networks of the same definition and sizes,
with other weights, and an entry counts only if it gives each network's output on every input of its
region that is checked there. So whatever depends on the weights has to be computed from the weights
inside the entry, and every shortcut has to hold for any weights: a rule that holds only for this
network makes the entry fail on the others.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.2022 | 1.0000 | 1.00000 | 0.7955 | 1.00000 | 1.00000 |
| r1s2 | scored | 0.2678 | 1.0000 | 1.00000 | 0.7298 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The weights look like a random/untrained RNN (uniform ±0.25 entries, no structure): outputs are a skewed mix of classes 7, 9, 4, 2, 3, 1 with tiny logit margins (median 0.005, min ~5e-8 in 16k samples), ~47% of hidden units active at every step, never an all-zero state. No task-level description holds exactly, so I did not interpret it semantically; instead I built an exact re-implementation that is cheaper than the forward pass for any weights (fidelity 1.0 on this network, on 11 random weight sets of various scales incl. exact-zero input weights, and on edge inputs such as x0 = 0, x0 = x1 = 0, x0 = 1e-200, scaled inputs).
    
    ## How you found it
    
    Looked at the weights (SVDs full rank, no dead units), the outputs' distribution, the hidden-unit activity statistics per step/unit (`network_outputs()` + numpy re-run), and the reference entry's op breakdown (2937 = 32 + 9×304 + 169). Then I searched for exact, weight-independent shortcuts in the cost model and measured each with `measure`, plus `lv1.measure` against `lv1.run_reference` on random weight dictionaries.
    
    ## The best entry
    
    `sparse_m43` (reward 0.268, cost 0.730, coverage 1, fidelity 1, 400 nodes, 22 const scalars). Region: every input. Interpretation, exact for any weights:
    1. **First two inputs by a 1-D table.** h1 = |x0|·relu(±w), so the step-2 mask depends only on sign(x0) and u = x1/|x0|, with 16 breakpoints θ_j = −s·B_j/w_j (B = rec@relu(±w)). Build sorts the breakpoints per sign and precomputes, for each of 2×17 intervals, P = rec@(M⊙w) and Q = rec@(M⊙B). At run time: interval index i = Σ[θ < u], gather P,Q (32 reads), z3 = [w P Q]@[x2 x1 x0] (48). This replaces 640 ops by ~148.
    2. **Fold w·x into the recurrent matmul**: [rec|w]@[h;x] (272 instead of 288 per step).
    3. **Sparsity cond-trees.** Units are permuted (constant perm, applied to w/rec/readout in build) so the least-active units (this network's statistics; exactness does not depend on it) sit last. For each of the 7 remaining steps, a nested `lv1.cond` tree on the activity of the last m units (m = 4 for 2 steps, 3 for 5 steps) chooses a static sub-matmul that includes only the active conditioned columns: saves 16 ops per inactive conditioned unit, ~25–32 per step. Node limit (400) is what caps m.
    Everything in it is computed from the weights inside the entry; constants are only eps values and the permutation.
    
    ## Claims
    
    Claimed fidelity 1.0 on this network and expected 1.0 on the second: the entry is algebraically identical to the network (tables and cond branches are exact selections, not approximations); the only deviation is float rounding ~1e-17, negligible against observed margins. Verified exact on 16384 verifier inputs twice and on random weights of scales 0.05–3.
    
    ## Next
    
    - Trim ~13 base nodes (rank-based interval masks instead of midpoints; store P/Q as a (34,16,2) table) and spend nodes on a third m=4 step (+~0.003).
    - Choose conditioned units per step from per-step activity statistics; a readout cond-tree (m=1–2) for a few more ops.
    - The step-3 "cell table" (591 mask cells, top-300 cover 95%) with sorted-key binary search was analysed and rejected: build cost (~770 ops/cell) exceeds the ~90 ops/input saving.
    - Fundamental floor of this approach is ~0.55 cost (full 16-unit trees) but the 400-node limit prevents it; look for a node-cheaper exact sparse matvec if any new op/pricing is available.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.4326 | 1.0000 | 1.00000 | 0.5650 | 1.00000 | 1.00000 |
| r2s2 | scored | 0.4352 | 1.0000 | 1.00000 | 0.5624 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The weights look like an untrained/random RNN (uniform ±0.25, full rank, no dead units); outputs are a skewed mix of classes with tiny logit margins (median ~0.005), ~47% of units active per step, activity per unit stationary from position 2 on (per-unit p ranges 0.29–0.68). No semantic description is exact, so the entry is again an exact, weight-independent re-implementation that is cheaper than the forward pass. I am sure of its exactness: it matches the reference to ~5e-16 relative error on every intermediate state z_2…z_9 and the logits, on this network and on 6 random weight sets (scales 0.05–3, with exact-zero input weights, zero rows/columns of rec, all-positive weights) and on edge inputs (x0 = 0, x0 = x1 = 0, x0 = ±1e-200, 1e-320, huge values, x1 = 0).
    
    ## How you found it
    
    Read the lv1 interpreter source: `cond` only computes and charges the chosen branch and does not require both branches to have the same shape, `concat` is free and accepts empty (17,0) tensors, matmul cost = result entries × contracted length (0 if empty). That allows a *linear-in-m* sparse matvec instead of the 2^m cond trees of round 1. Measured per-step per-unit activity with numpy (`network_outputs`-style re-run), chose a unit permutation by activity, counted nodes per design, and verified exactness by building the graph with `graph(example=x)` and comparing node values to a numpy reference, plus `lv1.measure` against `lv1.run_reference` on random weight dicts.
    
    ## The best entry
    
    `chain12b` (also `chain12`, `chain11` are the same design with fewer units). Region: every input. Interpretation (all computed from the weights inside the entry; the only constants are the permutation, [[-1],[1]], 0.0, and two empty (17,0)/(11,0) tensors):
    1. **z_2 by a 1-D table (≈132 ops).** Units are permuted (most-active first). h_0 = |x0|·relu(±w); mask of h_1 depends only on sign(x0) and u = x1/|x0| via 16 breakpoints θ = −B_s/w (B_s = rec@relu(±w)); masks per interval are computed from *ranks* (argsort∘argsort) with `where(w==0, B_s>0, (w>0)==below)` so w = 0 is exact; table T[s, i] = (16×3) coefficients of (x0, x1, x2) → z_2 = T[sidx, i] @ toks[0:3], i = Σ[θ_s < u].
    2. **Dynamic-width sparse matvec for steps 3–9 (≈185 ops/step instead of 304).** B = [[w | rec]; [x_t | relu(z[:k]) | z[k:]]] (17×17, free concat). For each of the last m units (m = 12 at steps 3–8, 11 at step 9): `cond(z_j > 0, B[:, j], empty)`; concat the base block and the chosen columns (free), then z_next = A[0:16] @ A[16]: cost 16×(1 + k + #active). No relu on conditioned units (they enter only if positive). 3 nodes per unit, 13 per step — the 400-node limit is exactly filled.
    3. Readout plain: ro @ relu(z_9), argmax.
    Cost 0.562: 7 steps ≈ 1316 + table 132 + readout 185 + build 22.9k/16384.
    
    ## Claims
    
    Claimed 1.0 on this network, expected 1.0 on the second: the entry is algebraically identical to the network for any weights (table = exact case analysis, conds = exact column selection); only float summation order differs (~1e-16 relative, far below observed margins ≥ 5e-8). Verified on 2×16384 verifier inputs and on random weights as above.
    
    ## Next
    
    - The design is node-limited (3 nodes/unit, 13 fixed/step, ~60 for the table). Any further node trim converts to +7 ops per unit (≈ +0.0024 reward); candidates: avoid `toks[t:t+1]`/reshape per step, 2-node M construction. Nothing found below 3 nodes/unit (cond needs a scalar-bool node and a column node each).
    - Full conditioning (m = 16 at all steps + readout) would give cost ≈ 0.49 (reward ≈ 0.50) if the node limit were ≥ 540.
    - Readout chain is not worth nodes (10(1−p)−1 per unit); recurrent steps are (16(1−p)−1).
    - Builder code must be re-pasted each call (nothing persists); keep the `graph(example=x)` + numpy intermediate comparison as the exactness test — it caught a sign bug (coefficient of x0 for x0<0) that output-level tests missed because errors decay ×0.35/step.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.4636 | 1.0000 | 1.00000 | 0.5340 | 1.00000 | 1.00000 |
| r3s2 | scored | 0.4631 | 1.0000 | 1.00000 | 0.5346 | 1.00000 | 1.00000 |
| r3s3 | scored | 0.4630 | 1.0000 | 1.00000 | 0.5347 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The weights are those of an untrained/random RNN (uniform ±0.25, full rank, no dead units); outputs are a skewed mix of classes with tiny logit margins (median ≈ 0.005), ≈ 47% of the 16 units active at every step (per-unit activity p from 0.29 to 0.68, ≈ 7.5 active units per step on average). No semantic description is exact, so the entry is again an exact, weight-independent re-implementation of the forward pass that is cheaper than the network. I am sure of exactness: intermediate states z₂…z₉ and the logits match a numpy forward pass to ≈ 3e-16 relative error on random inputs and on edge inputs (x₀ = 0, x₀ = x₁ = 0, x₀ = ±0.0, x₁ = 0, x₀ = ±1e-200, 1e-320, inputs scaled by 1e±6, all-zero input), and the entry agrees with the reference on 1200–1500 inputs for each of 10 other weight sets (scales 0.05–3, Gaussian weights, zero input weights, zero rows/columns of `recurrent`, all-zero `recurrent`, all-positive weights, all-equal input weights with tied breakpoints), and on 3 × 16384 verifier inputs.
    
    ## How you found it
    
    Read the lv1 interpreter source again: `take(x, idx)` costs 1 per entry read and needs an int index; `cond` evaluates and charges only the chosen branch, and a chosen branch that is a build-time constant costs 0 at run time; `concat`/`slice` are free; matmul with an empty contraction is free. The round-2 design spent 3 nodes per conditioned unit per step (condition slice, per-step column slice, cond) and was node-limited (400). The new trick: make the selectable columns *constants* shared by all steps, by packing the unit index into the column (`P[:, j] = [rec[:, j]; ro[:, j]; j]`), so a step needs only 2 nodes per unit (pos slice + cond); the values are then fetched with one `take` on the state using the index row of the selected columns (cast to int). Node counts and costs were checked with `measure`, exactness with `graph(example=x)` + numpy intermediates and with `lv1.measure` against `lv1.run_reference` on random weight dicts.
    
    ## The best entry
    
    `idx2_v1` (reward 0.4636, cost 0.534, coverage 1, fidelity 1, 394 nodes, 30 const scalars). `idx2_v2` is the same plus `abs(x0)` (handles x₀ = −0.0 exactly, +1 op; 0.4631/0.4630). Region: every input. Interpretation, exact for any weights (everything computed from the weights inside the entry; constants are only 0.0, the sign pair, index rows 0..16, zero/empty tensors):
    
    1. **z₂ by the 1-D table (132 ops, 43 nodes)** as in round 2 but trimmed: w2 = input.T (1,16), sgn (2,1,1); B_s = relu(s·w) @ rec.T; breakpoints th = −B_s/w; ranks via argsort∘argsort along axis 2 (no reshapes); mask[s,i] = where(w==0, B_s>0, (w>0) == (rank < i)); T = stack([(M·sB)@rec.T, (M·w)@rec.T, w], axis=3) of shape (2,17,16,3). Run time: s = x₀>0, u = x₁/|x₀|, i = Σ[th_s < u], z₂ = T[s,i] @ x[0:3].
    2. **Steps 3–9, 2 nodes per unit (41 nodes, ≈ 32 + 18·(n+1) ops per step, n = active units)**: constant packed matrix P (27×17) = [rec | w ; ro | 0 ; 0,1,…,16]; cols[j] = P[:, j:j+1] (17 shared slice nodes), E = zeros (27,0). Per step: pos = z > 0; zp = concat([z, x_t]); A = concat([cols[16]] + [cond(pos[j:j+1], cols[j], E) for j in 0..15], axis=1); idx = cast(A[26], int); z = A[0:16] @ take(zp, idx). No relu is needed (only positive units are selected).
    3. **Readout with the same trick (40 nodes, ≈ 41 + 12·n ops)**: A from the same cols with pos = z₉ > 0; logits = A[16:26] @ take(z₉, cast(A[26], int)); argmax.
    Totals: ≈ 1567 ops per input (7 steps ≈ 186 each, table 132, readout ≈ 133, build 22k/16384 ≈ 1.4).
    
    ## Claims
    
    Claimed 1.0 on this network and expected 1.0 on the second: the entry is algebraically identical to the network for any weights (the table is an exact case analysis of the sign pattern after step 1, including w = 0 and x₀ = 0; the conds are exact column selections; `take` fetches exactly the selected units' values); only float summation order differs (≈ 1e-16 relative, far below observed margins ≥ 5e-8). Verified on 3 × 16384 verifier inputs, 10 random weight sets, and the edge inputs listed above.
    
    ## Next
    
    - The design is at its structural floor under 400 nodes: per step 32 fixed (gt + 16 conds) + 18 per included column (16 matmul + cast + take); 5 nodes spare. Removing cast+take (−2 per active unit, ≈ 17 ops/step ≈ 0.006 reward per step) needs the per-step value-carrying columns of round 2 (+16 nodes per step) — not affordable; trimming found: th gather instead of cond (−2 nodes, +15 ops, not worth), P built as [rec; ro; row] plus a separate base column (−1 node).
    - Grouping units (cond on `any` of a pair) saves nodes but costs ≈ 7 ops per pair; base (unconditioned) units never pay off (break-even p ≈ 0.89).
    - A region cannot help (every input costs < 1 forward pass, so excluding any input lowers the reward).
    - Remaining ideas with real upside need either more nodes or a new op: a cell table for step 3 (needs enumerating weight-dependent cells at build, impossible without loops) or a cheaper int index (an int-typed packed matrix would drop the cast).
    - Builder code must be re-pasted each call; keep the `graph(example=x)` + numpy-intermediate comparison and the random-weight `lv1.measure` vs `lv1.run_reference` loop as the exactness tests.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.4636) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
