
import inspect
src = inspect.getsource(lv1)
for fn in ['def _norm', 'def _guard', 'def _int_index', 'def check_structure', 'def run(']:
    i = src.find(fn); print('='*20, fn); print(src[i:i+2200])
