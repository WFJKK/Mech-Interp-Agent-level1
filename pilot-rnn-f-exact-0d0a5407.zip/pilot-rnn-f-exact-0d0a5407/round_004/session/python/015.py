
import numpy as np
entry = entries['r4a']
gref = lv1.Graph(weights, 10, None, True)
ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
rng = np.random.default_rng(11)
def wset(kind, scale=0.25, seed=0):
    r = np.random.default_rng(seed)
    d = {'input': r.uniform(-scale, scale, (16,1)), 'recurrent': r.uniform(-scale, scale, (16,16)), 'readout': r.uniform(-scale, scale, (10,16))}
    if kind == 'zero_w': d['input'][[2,5,9],0] = 0.0
    if kind == 'tied': d['input'][:,0] = 0.1
    if kind == 'tied2': d['input'][:,0] = -0.1
    if kind == 'zero_rec': d['recurrent'][:] = 0
    return {k: np.asarray(v, dtype=np.float64) for k,v in d.items()}
base = rng.standard_normal((60,10))
edge = []
for x in base:
    for a in [0.0, -0.0, 1e-300, -1e-300, 1e-320]:
        for b in [None, 0.0, 1e-300]:
            y = x.copy(); y[0]=a
            if b is not None: y[1]=b
            edge.append(y)
    edge.append(x*1e8); edge.append(x*1e-8)
edge.append(np.zeros(10)); edge.append(-np.zeros(10))
edge = np.array(edge)
print(len(edge))
for kind in ['uni','zero_w','tied','tied2','zero_rec']:
    W2 = wset(kind, 0.25, 3) if kind!='uni' else weights
    ans, mops = lv1.run_reference(ref_entry, W2, 10, edge)
    m = lv1.measure(entry, W2, 10, edge, ans, mops)
    print(kind, m['fidelity'], m['n_agree'], len(edge))
