
e = entries['best']; nodes=e['nodes']
for i in list(range(0,70))+list(range(100,112))+list(range(386,394)):
    nd=dict(nodes[i]); v=nd.pop('value',None)
    print(i, nd, (np.asarray(v).shape if v is not None else ''))
print(e['predict'], e['rule'])
