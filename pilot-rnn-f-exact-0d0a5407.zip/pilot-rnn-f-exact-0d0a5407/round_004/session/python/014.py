
import numpy as np, time
entry = entries['r4a']
gref = lv1.Graph(weights, 10, None, True)
ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
rng = np.random.default_rng(7)
def wset(kind, scale=0.25, seed=0):
    r = np.random.default_rng(seed)
    d = {'input': r.uniform(-scale, scale, (16,1)), 'recurrent': r.uniform(-scale, scale, (16,16)), 'readout': r.uniform(-scale, scale, (10,16))}
    if kind == 'gauss':
        d = {k: r.standard_normal(v.shape)*scale for k,v in d.items()}
    if kind == 'zero_w':
        d['input'][[2,5,9],0] = 0.0
    if kind == 'zero_rows':
        d['recurrent'][[1,4],:] = 0; d['recurrent'][:,[3,7]] = 0
    if kind == 'zero_rec':
        d['recurrent'][:] = 0
    if kind == 'pos':
        d = {k: np.abs(v) for k,v in d.items()}
    if kind == 'tied':
        d['input'][:,0] = 0.1
    if kind == 'sparse_w':
        d['input'][:,0] = 0.0; d['input'][0,0] = 0.3
    return {k: np.asarray(v, dtype=np.float64) for k,v in d.items()}
configs = [('uni',0.25,1),('uni',0.05,2),('uni',1.0,3),('uni',3.0,4),('gauss',0.3,5),('zero_w',0.25,6),('zero_rows',0.25,7),('zero_rec',0.25,8),('pos',0.25,9),('tied',0.25,10),('sparse_w',0.25,11),('gauss',1.5,12)]
t0=time.time()
for kind, scale, seed in configs:
    W2 = wset(kind, scale, seed)
    X = rng.standard_normal((800,10))
    ans, mops = lv1.run_reference(ref_entry, W2, 10, X)
    m = lv1.measure(entry, W2, 10, X, ans, mops)
    print(kind, scale, 'fid', m['fidelity'], 'cost', round(m['cost'],4), 'nagree', m['n_agree'])
print(time.time()-t0)
