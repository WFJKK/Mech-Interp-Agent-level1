
import inspect
src = inspect.getsource(lv1)
i = src.find('class Graph'); print(src[i:i+200])
i = src.find('def load'); print(src[i:i+1500])
i = src.find('def measure'); print(src[i:i+2500])
