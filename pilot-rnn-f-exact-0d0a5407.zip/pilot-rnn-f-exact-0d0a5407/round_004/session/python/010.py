
import numpy as np, json

def build(with_abs=True):
    g = graph()
    w = g.weight("input"); rec = g.weight("recurrent"); ro = g.weight("readout")
    toks = g.tokens()
    x0 = toks[0]; x1 = toks[1]
    zero = g.const(0.0)
    sgn = g.const(np.array([[[-1.0]],[[1.0]]]))        # (2,1,1)
    sw = sgn * w                                        # (2,16,1)
    Bs = rec @ lv1.maximum(sw, zero)                    # (2,16,1)
    sB = sgn * Bs
    th = (-Bs) / w                                      # (2,16,1)
    ths = lv1.sort(th, axis=1)
    ranks = lv1.argsort(lv1.argsort(th, axis=1), axis=1)
    ii = g.const(np.arange(17).reshape(1,17))
    below = ranks < ii                                  # (2,16,17)
    M = lv1.where(w == zero, Bs > zero, (w > zero) == below)
    A = rec @ lv1.where(M, sB, zero)
    B = rec @ lv1.where(M, w, zero)
    C = lv1.where(M, w, w)
    T = lv1.stack([A, B, C], axis=3)                    # (2,16,17,3)
    # runtime table
    sbool = x0 >= zero
    sidx = lv1.cast(sbool, "int")
    u = x1 / abs(x0) if with_abs else x1 / x0
    ths_s = lv1.cond(sbool, ths[1], ths[0])             # (16,1)
    c1 = ths_s[7, 0] < u
    half = lv1.cond(c1, ths_s[8:16, 0], ths_s[0:8, 0])
    i = (half < u).sum() + c1 * 8
    Tsi = lv1.gather(T, [sidx, i], [0, 2])              # (16,3)
    z = Tsi @ toks[0:3]
    # packed columns
    P = lv1.concat([lv1.concat([rec, w], axis=1),
                    lv1.concat([ro, g.const(np.zeros((10,1)))], axis=1),
                    g.const(np.arange(17.).reshape(1,17))], axis=0)   # (27,17)
    cols = [P[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27,0)))
    zs = [z]
    for t in range(3, 10):
        pos = z > zero
        xt = toks[t:t+1]
        conds = [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)]
        Am = lv1.concat([cols[16]] + conds, axis=1)
        idx = lv1.cast(Am[26, 1:], "int")
        v = lv1.concat([xt, lv1.take(z, idx, axis=0)], axis=0)
        z = Am[0:16] @ v
        zs.append(z)
    pos = z > zero
    conds = [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)]
    Ar = lv1.concat(conds, axis=1)
    idx = lv1.cast(Ar[26], "int")
    v = lv1.take(z, idx, axis=0)
    logits = Ar[16:26] @ v
    out = logits.argmax()
    entry = g.entry(interpretation=out)
    return g, entry, zs, logits

g, entry, zs, logits = build()
print(len(entry['nodes']), sum(np.asarray(n.get('value',0)).size for n in entry['nodes'] if n['op']=='const'))
m = measure(entry); print(m)
save_entry('r4a', entry)
