
import inspect
src = inspect.getsource(lv1)
i = src.find('def run_reference'); print(src[i:i+800])
i = src.find('def __getitem__'); print(src[i:i+1800])
i = src.find('def gather'); print(src[i:i+400])
i = src.find('def take('); print(src[i:i+300])
