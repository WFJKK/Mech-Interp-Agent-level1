
import inspect, numpy as np
src = inspect.getsource(lv1.Graph.__init__); print(src[:1200])
