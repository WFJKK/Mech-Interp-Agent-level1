
import numpy as np
W = weights
def np_forward(x, W=W):
    w = W['input'][:,0]; rec = W['recurrent']; ro = W['readout']
    h = np.maximum(w*x[0], 0); zs=[]
    for t in range(1,10):
        z = w*x[t] + rec@h; zs.append(z); h = np.maximum(z,0)
    return zs, ro@h, int(np.argmax(ro@h))

def build_on(x, with_abs=True):
    # same builder but with example
    global graph
    orig = graph
    def graph2(**kw): return orig(example=list(x))
    globals()['graph'] = graph2
    try:
        return build(with_abs)
    finally:
        globals()['graph'] = orig

rng = np.random.default_rng(1)
worst = 0
tests = [rng.standard_normal(10) for _ in range(40)]
edge = []
for x in tests[:5]:
    for mod in [(0,0.0),(0,-0.0),(1,0.0)]:
        y = x.copy(); y[mod[0]] = mod[1]; edge.append(y)
    y = x.copy(); y[0]=0.0; y[1]=0.0; edge.append(y)
    y = x.copy(); y[0]=-0.0; y[1]=0.0; edge.append(y)
    y = x.copy(); y[0]=1e-200; edge.append(y)
    y = x.copy(); y[0]=-1e-200; edge.append(y)
    y = x.copy(); y[0]=1e-320; edge.append(y)
    y = x*1e6; edge.append(y)
    y = x*1e-6; edge.append(y)
    y = x.copy(); y[1]=0.0; y[0]=-abs(y[0]); edge.append(y)
edge.append(np.zeros(10))
allx = tests + edge
bad = 0
for x in allx:
    g2, e2, zs2, lg2 = build_on(x)
    zr, lr, ar = np_forward(x)
    # zs2[0] is z_3 (after 3 inputs) == zr[1]
    errs = []
    for k in range(8):
        a = zs2[k].value; b = zr[k+1]
        errs.append(np.max(np.abs(a-b))/(np.max(np.abs(b))+1e-300))
    el = np.max(np.abs(lg2.value - lr))/(np.max(np.abs(lr))+1e-300)
    pred = int(e2 and g2.values[e2['predict']]) if False else None
    worst = max(worst, max(errs), el)
    if max(errs) > 1e-12 or el > 1e-12:
        bad += 1; print('BAD', x, errs, el)
print('worst rel err', worst, 'bad', bad, 'n', len(allx))
