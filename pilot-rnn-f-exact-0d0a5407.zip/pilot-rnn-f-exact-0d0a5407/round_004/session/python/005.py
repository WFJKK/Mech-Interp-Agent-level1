
import inspect
src = inspect.getsource(lv1)
i = src.find('def _eval'); print(src[i:i+3500])
i = src.find('ARITY ='); print(src[i:i+1500])
