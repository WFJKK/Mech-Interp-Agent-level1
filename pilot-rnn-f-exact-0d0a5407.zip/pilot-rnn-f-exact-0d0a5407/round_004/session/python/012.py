
import numpy as np, json

def build(g, with_abs=True):
    w = g.weight("input"); rec = g.weight("recurrent"); ro = g.weight("readout")
    toks = g.tokens()
    x0 = toks[0]; x1 = toks[1]
    zero = g.const(0.0)
    sgn = g.const(np.array([[[-1.0]],[[1.0]]]))        # (2,1,1)
    sw = sgn * w                                        # (2,16,1)
    Bs = rec @ lv1.maximum(sw, zero)                    # (2,16,1)
    sB = sgn * Bs
    th = (-Bs) / w                                      # (2,16,1)
    ths = lv1.sort(th, axis=1)
    ranks = lv1.argsort(lv1.argsort(th, axis=1), axis=1)
    ii = g.const(np.arange(17).reshape(1,17))
    below = ranks < ii                                  # (2,16,17)
    M = lv1.where(w == zero, Bs > zero, (w > zero) == below)
    A = rec @ lv1.where(M, sB, zero)
    B = rec @ lv1.where(M, w, zero)
    C = lv1.where(M, w, w)
    T = lv1.stack([A, B, C], axis=3)                    # (2,16,17,3)
    sbool = x0 >= zero
    sidx = lv1.cast(sbool, "int")
    u = x1 / abs(x0) if with_abs else x1 / x0
    ths_s = lv1.cond(sbool, ths[1], ths[0])             # (16,1)
    c1 = ths_s[7, 0] < u
    half = lv1.cond(c1, ths_s[8:16, 0], ths_s[0:8, 0])
    i = (half < u).sum() + c1 * 8
    Tsi = lv1.gather(T, [sidx, i], [0, 2])              # (16,3)
    z = Tsi @ toks[0:3]
    P = lv1.concat([lv1.concat([rec, w], axis=1),
                    lv1.concat([ro, g.const(np.zeros((10,1)))], axis=1),
                    g.const(np.arange(17.).reshape(1,17))], axis=0)   # (27,17)
    cols = [P[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27,0)))
    zs = [z]
    for t in range(3, 10):
        pos = z > zero
        xt = toks[t:t+1]
        conds = [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)]
        Am = lv1.concat([cols[16]] + conds, axis=1)
        idx = lv1.cast(Am[26, 1:], "int")
        v = lv1.concat([xt, lv1.take(z, idx, axis=0)], axis=0)
        z = Am[0:16] @ v
        zs.append(z)
    pos = z > zero
    conds = [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)]
    Ar = lv1.concat(conds, axis=1)
    idx = lv1.cast(Ar[26], "int")
    v = lv1.take(z, idx, axis=0)
    logits = Ar[16:26] @ v
    out = logits.argmax()
    entry = g.entry(interpretation=out)
    return entry, zs, logits, out

W = weights
def np_forward(x, W=W):
    w = W['input'][:,0]; rec = W['recurrent']; ro = W['readout']
    h = np.maximum(w*x[0], 0); zs=[]
    for t in range(1,10):
        z = w*x[t] + rec@h; zs.append(z); h = np.maximum(z,0)
    return zs, ro@h, int(np.argmax(ro@h))

rng = np.random.default_rng(1)
tests = [rng.standard_normal(10) for _ in range(40)]
edge = []
for x in tests[:5]:
    for mod in [(0,0.0),(0,-0.0),(1,0.0)]:
        y = x.copy(); y[mod[0]] = mod[1]; edge.append(y)
    for a,b in [(0.0,0.0),(-0.0,0.0),(1e-200,None),(-1e-200,None),(1e-320,None),(-1e-320,None)]:
        y = x.copy(); y[0]=a
        if b is not None: y[1]=b
        edge.append(y)
    edge.append(x*1e6); edge.append(x*1e-6)
    y = x.copy(); y[1]=0.0; y[0]=-abs(y[0]); edge.append(y)
    y = x.copy(); y[1]=1e-300; edge.append(y)
    y = x.copy(); y[1]=-1e-300; y[0]=-0.0; edge.append(y)
edge.append(np.zeros(10))
allx = tests + edge
worst = 0; bad = 0
for x in allx:
    g2 = graph(example=list(x))
    e2, zs2, lg2, out2 = build(g2)
    zr, lr, ar = np_forward(x)
    errs = [np.max(np.abs(zs2[k].value - zr[k+1]))/(np.max(np.abs(zr[k+1]))+1e-300) for k in range(8)]
    el = np.max(np.abs(lg2.value - lr))/(np.max(np.abs(lr))+1e-300)
    worst = max(worst, max(errs), el)
    if max(errs) > 1e-12 or el > 1e-12 or int(out2.value) != ar:
        bad += 1; print('BAD', x, errs, el, int(out2.value), ar)
print('worst rel err', worst, 'bad', bad, 'n', len(allx))
