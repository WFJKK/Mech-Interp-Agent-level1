
import inspect, re
src = inspect.getsource(lv1)
print(len(src))
# print op names and cost function
i = src.find('def cost'); print(src[i:i+200] if i>=0 else 'no cost fn')
names = re.findall(r'\n    def (\w+)\(', src)
print(names)
names2 = re.findall(r'\ndef (\w+)\(', src)
print(names2)
