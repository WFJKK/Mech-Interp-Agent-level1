
import inspect
src = inspect.getsource(lv1)
i = src.find('def apply'); print(src[i:i+9000])
