
import numpy as np, json
e = entries['best']
nodes = e['nodes']
N = len(nodes)
# dependency on input
dep = [False]*N
for i,nd in enumerate(nodes):
    if nd['op'] in ('token','tokens'): dep[i]=True
    else: dep[i] = any(dep[a] for a in nd.get('args',[]))
def run_once(x, percost):
    tokens = np.asarray(x, dtype=np.float64)
    memo = {}; build = run_once.build
    def ev(root):
        stack=[root]
        while stack:
            i=stack[-1]
            store = memo if dep[i] else build
            if i in store: stack.pop(); continue
            nd=nodes[i]; args=nd.get('args',[])
            if nd['op']=='cond':
                c,a,b=args
                if c not in (memo if dep[c] else build): stack.append(c); continue
                pred=(memo if dep[c] else build)[c]
                chosen = a if bool(pred.reshape(())) else b
                if chosen not in (memo if dep[chosen] else build): stack.append(chosen); continue
                value,cost=(memo if dep[chosen] else build)[chosen],1
            else:
                missing=[j for j in args if j not in (memo if dep[j] else build)]
                if missing: stack.extend(reversed(missing)); continue
                vals=[(memo if dep[j] else build)[j] for j in args]
                with np.errstate(all='ignore'):
                    value,cost=lv1.apply(nd, vals, tokens if dep[i] else None, weights, store)
            store[i]=value
            if dep[i]: percost[i]+=cost
            stack.pop()
        return (memo if dep[root] else build)[root]
    return ev(e['predict'])
run_once.build = {}
rng = np.random.default_rng(0)
X = rng.standard_normal((2000,10))
percost = np.zeros(N)
for x in X: run_once(x, percost)
percost/=len(X)
print('total', percost.sum())
for i in range(N):
    if percost[i]>0.5: print(i, nodes[i]['op'], nodes[i].get('args'), round(percost[i],2))
