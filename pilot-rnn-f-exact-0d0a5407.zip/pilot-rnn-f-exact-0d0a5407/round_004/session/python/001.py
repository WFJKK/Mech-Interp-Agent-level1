
import json, inspect, os
print(info)
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
print(measure(e))
# count nodes
nodes = e.get('nodes') or e.get('graph') or None
print(len(json.dumps(e)))
print(json.dumps(e)[:1500])
