
import numpy as np, time
entry = entries['r4a']
gref = lv1.Graph(weights, 10, None, True)
ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
rng = np.random.default_rng(99)
tot=0
t0=time.time()
for seed in range(20, 32):
    r = np.random.default_rng(seed)
    scale = [0.02, 0.1, 0.25, 0.5, 2.0][seed % 5]
    W2 = {'input': r.uniform(-scale, scale, (16,1)), 'recurrent': r.uniform(-scale, scale, (16,16)), 'readout': r.uniform(-scale, scale, (10,16))}
    if seed % 4 == 0: W2['input'][r.integers(0,16,3),0] = 0.0
    if seed % 4 == 1: W2['recurrent'] = np.abs(W2['recurrent']); W2['input'] = np.abs(W2['input'])
    if seed % 4 == 2: W2['recurrent'][r.integers(0,16,2),:] = 0.0
    X = rng.standard_normal((500,10))
    X[0] = 0; X[1,0] = 0; X[2,0] = -0.0; X[3,:2] = 0
    ans, mops = lv1.run_reference(ref_entry, W2, 10, X)
    m = lv1.measure(entry, W2, 10, X, ans, mops)
    tot += m['n_agree']
    if m['n_agree'] != len(X): print('MISMATCH seed', seed, m['n_agree'])
print('agree', tot, 'of', 12*500, 'time', time.time()-t0)
