
import numpy as np
PERM=[2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 5, 12, 10, 14]
def runs(idx):
    out=[]; s=idx[0]; p=idx[0]
    for i in idx[1:]:
        if i==p+1: p=i
        else: out.append((s,p+1)); s=i; p=i
    out.append((s,p+1)); return out
def build(g, perm):
    pv = g.const(np.array(perm))
    w = lv1.take(g.weight("input")[:, 0], pv, 0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pv, 0), pv, 1)
    ro = lv1.take(g.weight("readout"), pv, 1)
    Bp = rec @ lv1.maximum(w, 0.0); Bm = rec @ lv1.minimum(w, 0.0)
    wsafe = lv1.where(w == 0.0, 1e-30, w)
    SB = lv1.stack([Bp, -Bm]); TH = -SB / wsafe[None, :]; THs = lv1.sort(TH, 1)
    lo = THs[:, 0:1] - (abs(THs[:, 0:1]) + 1.0); hi = THs[:, 15:16] + (abs(THs[:, 15:16]) + 1.0)
    mids = lv1.concat([lo, (THs[:, 0:15] + THs[:, 1:16]) * 0.5, hi], 1)
    Z = w[None, None, :] * mids[:, :, None] + SB[:, None, :]
    M = lv1.cast(Z > 0.0, "float"); Bst = lv1.stack([Bp, Bm])
    P = (M * w[None, None, :]).reshape(34, 16) @ rec.T
    Q = (M * Bst[:, None, :]).reshape(34, 16) @ rec.T
    PQ = lv1.concat([P, Q], 1)
    recw = lv1.concat([w.reshape(16, 1), rec], 1)
    return w, rec, ro, THs, PQ, recw
def slice_runs(v, idx, axis):
    parts=[(v[a:b] if axis==0 else v[:, a:b]) for a,b in runs(idx)]
    return parts[0] if len(parts)==1 else lv1.concat(parts, axis)
def interp(g, perm, m_list, eps=1e-300):
    w, rec, ro, THs, PQ, recw = build(g, perm)
    x = g.tokens(); x0, x1, x2 = x[0], x[1], x[2]
    si = lv1.cast(x0 <= 0.0, "int")
    u = x1 / lv1.maximum(abs(x0), eps)
    i = (THs[si] < u).sum(0)
    pq = PQ[si * 17 + i]
    W3 = lv1.concat([w.reshape(16, 1), pq[0:16].reshape(16, 1), pq[16:32].reshape(16, 1)], 1)
    h = lv1.maximum(W3 @ lv1.stack([x2, x1, x0]), 0.0)
    submats = {}
    for t in range(3, 10):
        m = m_list[t-3]
        v = lv1.concat([x[t:t+1], h], 0)
        if m == 0:
            z = recw @ v
        else:
            c = h[16-m:16] > 0.0
            def tree(level, S):
                if level == m:
                    keep = list(range(0, 17-m)) + sorted(1+16-m+s for s in S)
                    key = tuple(keep)
                    if key not in submats: submats[key] = slice_runs(recw, keep, 1)
                    return submats[key] @ slice_runs(v, keep, 0)
                return lv1.cond(c[level], tree(level+1, S | {level}), tree(level+1, S))
            z = tree(0, frozenset())
        h = lv1.maximum(z, 0.0)
    return (ro @ h).argmax()

for name, ml in [("m3", [3]*7), ("m43", [4,4,3,3,3,3,3]), ("m2", [2]*7)]:
    g = graph(); e = g.entry(interpretation=interp(g, PERM, ml))
    mm = measure(e)
    print(name, "nodes", len(e["nodes"]), {k: mm[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']})
    save_entry("sparse_"+name, e)
