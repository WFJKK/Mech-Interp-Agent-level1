
import inspect
for n in ['measure','run_reference','Evaluator','all_inputs','draw_inputs','apply','real_inputs']:
    obj = getattr(lv1, n)
    try: print(n, inspect.signature(obj))
    except Exception as ex: print(n, ex)
    doc = inspect.getdoc(obj); print("   ", (doc or "")[:300].replace("\n"," | "))
print(inspect.signature(lv1.Graph.load))
print(inspect.signature(measure))
