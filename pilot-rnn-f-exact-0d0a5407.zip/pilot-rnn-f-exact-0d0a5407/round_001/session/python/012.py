
import numpy as np
w_ = weights["input"][:,0]; rec_ = weights["recurrent"]
X, Y, ops = network_outputs(); X=np.asarray(X)
N=X.shape[0]; h=np.zeros((N,16)); inact=np.zeros(16); 
for t in range(10):
    h = np.maximum(X[:,t:t+1]*w_[None,:] + h@rec_.T, 0)
    if t>=3: inact += (h==0).mean(0)
inact/=7
order = np.argsort(inact)  # ascending inactivity: most active first, least active last
print("inactivity sorted", inact[order])
PERM = [int(i) for i in order]
print(PERM)

def runs(idx):
    """split sorted index list into contiguous (start, stop) runs"""
    out=[]; s=idx[0]; p=idx[0]
    for i in idx[1:]:
        if i==p+1: p=i
        else: out.append((s,p+1)); s=i; p=i
    out.append((s,p+1)); return out

def build(g, perm):
    pv = g.const(np.array(perm))
    w = lv1.take(g.weight("input")[:, 0], pv, 0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pv, 0), pv, 1)
    ro = lv1.take(g.weight("readout"), pv, 1)
    Bp = rec @ lv1.maximum(w, 0.0); Bm = rec @ lv1.minimum(w, 0.0)
    wsafe = lv1.where(w == 0.0, 1e-30, w)
    SB = lv1.stack([Bp, -Bm]); TH = -SB / wsafe[None, :]; THs = lv1.sort(TH, 1)
    lo = THs[:, 0:1] - (abs(THs[:, 0:1]) + 1.0); hi = THs[:, 15:16] + (abs(THs[:, 15:16]) + 1.0)
    mids = lv1.concat([lo, (THs[:, 0:15] + THs[:, 1:16]) * 0.5, hi], 1)
    Z = w[None, None, :] * mids[:, :, None] + SB[:, None, :]
    M = lv1.cast(Z > 0.0, "float"); Bst = lv1.stack([Bp, Bm])
    P = (M * w[None, None, :]).reshape(34, 16) @ rec.T
    Q = (M * Bst[:, None, :]).reshape(34, 16) @ rec.T
    PQ = lv1.concat([P, Q], 1)
    recw = lv1.concat([w.reshape(16, 1), rec], 1)   # columns: x, h0..h15
    return w, rec, ro, THs, PQ, recw

def slice_runs(v, idx, axis):
    parts=[]
    for a,b in runs(idx):
        parts.append(v[a:b] if axis==0 else v[:, a:b])
    return parts[0] if len(parts)==1 else lv1.concat(parts, axis)

def interp(g, perm, m_list, eps=1e-300):
    w, rec, ro, THs, PQ, recw = build(g, perm)
    x = g.tokens(); x0, x1, x2 = x[0], x[1], x[2]
    si = lv1.cast(x0 <= 0.0, "int")
    u = x1 / lv1.maximum(abs(x0), eps)
    i = (THs[si] < u).sum(0)
    pq = PQ[si * 17 + i]
    W3 = lv1.concat([w.reshape(16, 1), pq[0:16].reshape(16, 1), pq[16:32].reshape(16, 1)], 1)
    h = lv1.maximum(W3 @ lv1.stack([x2, x1, x0]), 0.0)
    submats = {}
    for t in range(3, 10):
        m = m_list[t-3]
        v = lv1.concat([x[t:t+1], h], 0)   # length 17; v[1+k] = h_k
        if m == 0:
            z = recw @ v
        else:
            c = h[16-m:16] > 0.0
            def tree(level, S):
                if level == m:
                    keep = list(range(0, 17-m)) + sorted(1+16-m+s for s in S)
                    key = tuple(keep)
                    if key not in submats: submats[key] = slice_runs(recw, keep, 1)
                    return submats[key] @ slice_runs(v, keep, 0)
                return lv1.cond(c[level], tree(level+1, S | {level}), tree(level+1, S))
            z = tree(0, frozenset())
        h = lv1.maximum(z, 0.0)
    return (ro @ h).argmax()

for ml in [[0]*7, [1]*7, [2]*7, [3]*7, [4]*7]:
    g = graph(); e = g.entry(interpretation=interp(g, PERM, ml))
    print(ml, "nodes", len(e["nodes"]))
