
print([n for n in dir(lv1) if not n.startswith('_')])
g = graph()
print([n for n in dir(g) if not n.startswith('_')])
x = g.tokens()
print(type(x), x.shape, x.value)
m = measure(model.reference(g, lv1))
print(m)
