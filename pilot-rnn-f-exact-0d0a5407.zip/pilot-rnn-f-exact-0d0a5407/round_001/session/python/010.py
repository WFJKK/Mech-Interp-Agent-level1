
import numpy as np, time
e = entries["front_table_v1b"]
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(123)
res = []
for trial in range(6):
    scale = [0.25, 0.25, 1.0, 0.05, 2.0, 0.25][trial]
    W = {"input": rng.uniform(-scale, scale, (16,1)), "recurrent": rng.uniform(-scale, scale, (16,16)), "readout": rng.uniform(-0.25,0.25,(10,16))}
    if trial == 5:
        W["input"][3,0] = 0.0; W["input"][7,0] = 0.0   # exact zeros in the input weight
    inputs = lv1.draw_inputs(info["data_set"], info["input_space"], 3000, rng)
    ans, mops = lv1.run_reference(ref, W, 10, inputs)
    t=time.time()
    m = lv1.measure(e, W, 10, inputs, ans, mops)
    res.append((trial, scale, m['n_agree'], m['n_in_region'], round(m['cost'],4), round(time.time()-t,1)))
    print(res[-1])
