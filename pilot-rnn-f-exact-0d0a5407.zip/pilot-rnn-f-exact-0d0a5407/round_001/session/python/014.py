
import numpy as np, time
e = entries["sparse_m43"]
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(99)
for trial in range(5):
    scale = [0.25, 1.0, 0.05, 3.0, 0.25][trial]
    W = {"input": rng.uniform(-scale, scale, (16,1)), "recurrent": rng.uniform(-scale, scale, (16,16)), "readout": rng.normal(0,0.3,(10,16))}
    if trial == 4:
        W["input"][PERM[13] if False else 3,0] = 0.0; W["input"][14,0] = 0.0
    inputs = lv1.draw_inputs(info["data_set"], info["input_space"], 2500, rng)
    ans, mops = lv1.run_reference(ref, W, 10, inputs)
    m = lv1.measure(e, W, 10, inputs, ans, mops)
    print(trial, scale, m['n_agree'], m['n_in_region'], round(m['cost'],4))
# edge inputs on real weights
inputs = rng.standard_normal((400,10))
inputs[:100,0] = 0.0; inputs[100:150,0] = 0.0; inputs[100:150,1] = 0.0
inputs[150:200,0] = 1e-200; inputs[200:250,1] = 0.0; inputs[250:300,0] = -1e-12
inputs[300:350,:3] = 0.0; inputs[350:400,:] *= 50
ans, mops = lv1.run_reference(ref, weights, 10, inputs)
m = lv1.measure(e, weights, 10, inputs, ans, mops)
print("edge", m['n_agree'], m['n_in_region'])
