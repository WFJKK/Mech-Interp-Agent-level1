
X, Y, ops = out
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
print("output distribution", np.bincount(Y, minlength=10))
# hidden activity stats
def run(X):
    N = X.shape[0]
    h = np.zeros((N,16)); hs=[]
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0)
        hs.append(h.copy())
    return np.stack(hs,1)
H = run(X)
Yc = (H[:,-1]@ro.T).argmax(1)
print("match", (Yc==Y).mean())
act = (H>0)
print("fraction active per step:", act.mean((0,2)))
print("fraction active per unit:", act.mean((0,1)))
print("mean # active per step", act.sum(2).mean(0))
print("all-zero h fraction per step", (act.sum(2)==0).mean(0))
print("logit margin stats:", np.percentile(np.sort(H[:,-1]@ro.T,1)[:,-1]-np.sort(H[:,-1]@ro.T,1)[:,-2],[1,5,25,50]))
