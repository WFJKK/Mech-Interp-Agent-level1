
import numpy as np
def build(g):
    w = g.weight("input")[:, 0]; rec = g.weight("recurrent"); ro = g.weight("readout")
    Bp = rec @ lv1.maximum(w, 0.0)
    Bm = rec @ lv1.minimum(w, 0.0)
    wsafe = lv1.where(w == 0.0, 1e-30, w)
    SB = lv1.stack([Bp, -Bm])
    TH = -SB / wsafe[None, :]
    THs = lv1.sort(TH, 1)
    lo = THs[:, 0:1] - (abs(THs[:, 0:1]) + 1.0)
    hi = THs[:, 15:16] + (abs(THs[:, 15:16]) + 1.0)
    inner = (THs[:, 0:15] + THs[:, 1:16]) * 0.5
    mids = lv1.concat([lo, inner, hi], 1)
    Z = w[None, None, :] * mids[:, :, None] + SB[:, None, :]
    M = lv1.cast(Z > 0.0, "float")
    Bst = lv1.stack([Bp, Bm])
    P = (M * w[None, None, :]).reshape(34, 16) @ rec.T
    Q = (M * Bst[:, None, :]).reshape(34, 16) @ rec.T
    PQ = lv1.concat([P, Q], 1)
    recw = lv1.concat([rec, w.reshape(16, 1)], 1)
    return w, rec, ro, THs, PQ, recw

def interp(g, eps=1e-300, boolsum=True):
    w, rec, ro, THs, PQ, recw = build(g)
    x = g.tokens()
    x0, x1, x2 = x[0], x[1], x[2]
    si = lv1.cast(x0 <= 0.0, "int")
    u = x1 / lv1.maximum(abs(x0), eps)
    th = THs[si]
    if boolsum:
        i = (th < u).sum(0)
    else:
        i = lv1.cast(th < u, "int").sum(0)
    pq = PQ[si * 17 + i]
    W3 = lv1.concat([w.reshape(16, 1), pq[0:16].reshape(16, 1), pq[16:32].reshape(16, 1)], 1)
    xs = lv1.stack([x2, x1, x0])
    h = lv1.maximum(W3 @ xs, 0.0)
    for t in range(3, 10):
        h = lv1.maximum(recw @ lv1.concat([h, x[t:t+1]], 0), 0.0)
    return (ro @ h).argmax()

for bs in [True, False]:
    try:
        g = graph()
        e = g.entry(interpretation=interp(g, boolsum=bs))
        m = measure(e)
        print(bs, {k: m[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']}, "nodes", len(e["nodes"]))
        save_entry("front_table_v1" if not bs else "front_table_v1b", e)
    except Exception as ex:
        print(bs, "failed:", ex)
