
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=200)
w = weights["input"][:,0]; rec = weights["recurrent"]; ro = weights["readout"]
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
print("output distribution", np.bincount(Y, minlength=10))
def run(X):
    N = X.shape[0]
    h = np.zeros((N,16)); hs=[]
    for t in range(10):
        h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0)
        hs.append(h.copy())
    return np.stack(hs,1)
H = run(X)
L = H[:,-1]@ro.T
Yc = L.argmax(1)
print("match", (Yc==Y).mean())
act = (H>0)
print("fraction active per step:", act.mean((0,2)))
print("fraction active per unit:", act.mean((0,1)))
print("mean # active per step", act.sum(2).mean(0))
print("all-zero h fraction per step", (act.sum(2)==0).mean(0))
Ls = np.sort(L,1)
print("logit margin pct:", np.percentile(Ls[:,-1]-Ls[:,-2],[1,5,25,50]))
print("h norm per step", np.linalg.norm(H,axis=2).mean(0))
