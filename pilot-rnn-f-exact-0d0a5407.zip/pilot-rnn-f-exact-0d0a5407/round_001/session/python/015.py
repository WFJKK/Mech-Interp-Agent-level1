
import numpy as np
PERM0=[2, 15, 11, 6, 4, 8, 13, 1, 9, 7, 0, 3, 5, 12, 10, 14]   # most active ... least active
def runs(idx):
    out=[]; s=idx[0]; p=idx[0]
    for i in idx[1:]:
        if i==p+1: p=i
        else: out.append((s,p+1)); s=i; p=i
    out.append((s,p+1)); return out
def build(g, perm):
    pv = g.const(np.array(perm))
    w = lv1.take(g.weight("input")[:, 0], pv, 0)
    rec = lv1.take(lv1.take(g.weight("recurrent"), pv, 0), pv, 1)
    ro = lv1.take(g.weight("readout"), pv, 1)
    Bp = rec @ lv1.maximum(w, 0.0); Bm = rec @ lv1.minimum(w, 0.0)
    wsafe = lv1.where(w == 0.0, 1e-30, w)
    SB = lv1.stack([Bp, -Bm]); TH = -SB / wsafe[None, :]; THs = lv1.sort(TH, 1)
    lo = THs[:, 0:1] - (abs(THs[:, 0:1]) + 1.0); hi = THs[:, 15:16] + (abs(THs[:, 15:16]) + 1.0)
    mids = lv1.concat([lo, (THs[:, 0:15] + THs[:, 1:16]) * 0.5, hi], 1)
    Z = w[None, None, :] * mids[:, :, None] + SB[:, None, :]
    M = lv1.cast(Z > 0.0, "float"); Bst = lv1.stack([Bp, Bm])
    P = (M * w[None, None, :]).reshape(34, 16) @ rec.T
    Q = (M * Bst[:, None, :]).reshape(34, 16) @ rec.T
    PQ = lv1.concat([P, Q], 1)
    recw = lv1.concat([rec, w.reshape(16, 1)], 1)   # columns: h0..h15, x
    return w, rec, ro, THs, PQ, recw
def interp(g, m_list, eps=1e-300):
    # state order: for step with m=(mA,mB): A units = least-active group at front, B at back.
    # we use ONE fixed state order for all steps: [A(2 units), fixed(12), B(2 units)] built from PERM0:
    # least active 4 units: PERM0[12:16]; A = two of them at the front, B = two at the back.
    perm = [PERM0[14], PERM0[12]] + PERM0[0:12] + [PERM0[13], PERM0[15]]
    w, rec, ro, THs, PQ, recw = build(g, perm)
    x = g.tokens(); x0, x1, x2 = x[0], x[1], x[2]
    si = lv1.cast(x0 <= 0.0, "int")
    u = x1 / lv1.maximum(abs(x0), eps)
    i = (THs[si] < u).sum(0)
    pq = PQ[si * 17 + i]
    W3 = lv1.concat([w.reshape(16, 1), pq[0:16].reshape(16, 1), pq[16:32].reshape(16, 1)], 1)
    h = lv1.maximum(W3 @ lv1.stack([x2, x1, x0]), 0.0)
    submats = {}
    for t in range(3, 10):
        mA, mB = m_list[t-3]
        v = lv1.concat([h, x[t:t+1]], 0)      # length 17; v[16] = x
        cond_units = list(range(2-mA, 2)) + list(range(14, 14+mB))   # v indices of conditioned units
        cs = [h[k] > 0.0 for k in cond_units]
        fixed = [k for k in range(17) if k not in cond_units]
        vslices = {}
        def vs(a, b):
            if (a, b) not in vslices: vslices[(a, b)] = v[a:b]
            return vslices[(a, b)]
        def tree(level, S):
            if level == len(cond_units):
                keep = sorted(fixed + [cond_units[s] for s in S])
                key = tuple(keep)
                if key not in submats:
                    parts = [recw[:, a:b] for a, b in runs(keep)]
                    submats[key] = parts[0] if len(parts) == 1 else lv1.concat(parts, 1)
                parts = [vs(a, b) for a, b in runs(keep)]
                vv = parts[0] if len(parts) == 1 else lv1.concat(parts, 0)
                return submats[key] @ vv
            return lv1.cond(cs[level], tree(level+1, S | {level}), tree(level+1, S))
        z = tree(0, frozenset()) if cond_units else recw @ v
        h = lv1.maximum(z, 0.0)
    return (ro @ h).argmax()

configs = {"L44": [(2,2)]*7, "L33": [(1,2)]*7, "L4443333": [(2,2)]*3+[(1,2)]*4, "L44443333": [(2,2)]*4+[(1,2)]*3}
for name, ml in configs.items():
    g = graph(); e = g.entry(interpretation=interp(g, ml))
    n = len(e["nodes"]); print(name, "nodes", n)
    if n <= 400:
        mm = measure(e); print("   ", {k: mm[k] for k in ['n_agree','predict_ops','cost','reward']}); save_entry("lay_"+name, e)
