
import numpy as np
e = entries["front_table_v1b"]
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(7)
inputs = rng.standard_normal((400,10))
inputs[:100,0] = 0.0
inputs[100:150,0] = 0.0; inputs[100:150,1] = 0.0
inputs[150:200,0] = 1e-200
inputs[200:250,1] = 0.0
inputs[250:300,0] = -1e-12
inputs[300:350,:3] = 0.0
inputs[350:400,:] *= 50
ans, mops = lv1.run_reference(ref, weights, 10, inputs)
m = lv1.measure(e, weights, 10, inputs, ans, mops)
print(m['n_agree'], m['n_in_region'])
