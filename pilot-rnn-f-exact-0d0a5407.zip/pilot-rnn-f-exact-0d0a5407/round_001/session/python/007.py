
import numpy as np
w = weights["input"][:,0]; rec = weights["recurrent"]; ro = weights["readout"]
X, Y, ops = network_outputs(); X=np.asarray(X)
N=X.shape[0]
h = np.zeros((N,16)); codes=[]
for t in range(10):
    h = np.maximum(X[:,t:t+1]*w[None,:] + h@rec.T, 0)
    codes.append(((h>0)*(1<<np.arange(16))).sum(1))
key = np.zeros(N, dtype=object)
for t in range(5):
    key = key*65536 + codes[t]
    vals, counts = np.unique(key, return_counts=True)
    counts = np.sort(counts)[::-1]
    cum = np.cumsum(counts)/N
    print(f"step {t+1}: distinct keys {len(vals)}; coverage top100 {cum[min(99,len(cum)-1)]:.3f}, top300 {cum[min(299,len(cum)-1)]:.3f}, top1000 {cum[min(999,len(cum)-1)]:.3f}")
L = h@ro.T; Ls=np.sort(L,1); m = Ls[:,-1]-Ls[:,-2]
print("min margins", np.sort(m)[:10])
