
import numpy as np
g = graph()
ref = g.entry(interpretation=model.reference(g, lv1))
print("ref", measure(ref))

def build(g, eps=1e-300):
    w = g.weight("input")[:, 0]          # (16,)
    rec = g.weight("recurrent")          # (16,16)
    ro = g.weight("readout")
    # ---- build-time tables (input independent) ----
    Bp = rec @ lv1.maximum(w, 0.0)       # rec @ relu(w)   : x0>0 -> rec@h1 = x0*Bp
    Bm = rec @ lv1.minimum(w, 0.0)       # rec @ min(w,0)  : x0<0 -> rec@h1 = x0*Bm
    # for sign s: unit j active at step 2 iff w_j*x1 + x0*B_j > 0 ; u = x1/|x0| ; s*B_j + w_j*u > 0
    wsafe = lv1.where(w == 0.0, 1e-30, w)
    SB = lv1.stack([Bp, -Bm])            # (2,16): s*B^s  (s=+ : Bp ; s=- : -Bm)
    TH = -SB / wsafe[None, :]            # breakpoints (2,16)
    THs = lv1.sort(TH, 1)                # sorted (2,16)
    # midpoints for the 17 intervals
    lo = THs[:, 0:1] - (abs(THs[:, 0:1]) + 1.0)
    hi = THs[:, 15:16] + (abs(THs[:, 15:16]) + 1.0)
    inner = (THs[:, 0:15] + THs[:, 1:16]) * 0.5
    mids = lv1.concat([lo, inner, hi], 1)        # (2,17)
    Z = w[None, None, :] * mids[:, :, None] + SB[:, None, :]   # (2,17,16)
    M = lv1.cast(Z > 0.0, "float")               # (2,17,16)
    Bst = lv1.stack([Bp, Bm])                    # (2,16) actual B^s (multiplies x0)
    Mw = M * w[None, None, :]                    # (2,17,16)
    MB = M * Bst[:, None, :]
    # P[s,i] = rec @ (M*w), Q[s,i] = rec @ (M*B): compute as matmuls
    P = Mw.reshape(34, 16) @ rec.T               # (34,16)
    Q = MB.reshape(34, 16) @ rec.T
    PQ = lv1.concat([P, Q], 1)                   # (34,32)
    recw = lv1.concat([rec, w.reshape(16, 1)], 1)  # (16,17)
    return w, rec, ro, THs, PQ, recw

def interp(g, eps=1e-300):
    w, rec, ro, THs, PQ, recw = build(g)
    x = g.tokens()
    x0, x1, x2 = x[0], x[1], x[2]
    s = x0 > 0.0
    si = lv1.cast(~s, "int")                      # 0 for +, 1 for -
    u = x1 / lv1.maximum(abs(x0), eps)
    th = THs[si]                                  # (16,) gather row
    i = lv1.cast(th < u, "int").sum(0)            # interval index 0..16
    pq = PQ[si * 17 + i]                          # (32,)
    W3 = lv1.concat([w.reshape(16, 1), pq[0:16].reshape(16, 1), pq[16:32].reshape(16, 1)], 1)  # (16,3)
    xs = lv1.stack([x2, x1, x0])
    z = W3 @ xs
    h = lv1.maximum(z, 0.0)                       # h_3  (state after reading x0,x1,x2)
    for t in range(3, 10):
        z = recw @ lv1.concat([h, x[t:t+1]], 0)
        h = lv1.maximum(z, 0.0)
    return (ro @ h).argmax()

g = graph()
e = g.entry(interpretation=interp(g))
print(measure(e))
print("nodes", len(e["nodes"]))
