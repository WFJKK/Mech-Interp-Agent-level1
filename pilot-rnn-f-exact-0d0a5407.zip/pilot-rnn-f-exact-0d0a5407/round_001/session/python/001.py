
import numpy as np
print(info)
for k,v in weights.items(): print(k, v.shape)
w = weights["input"][:,0]; rec = weights["recurrent"]; ro = weights["readout"]
np.set_printoptions(precision=3, suppress=True, linewidth=200)
print("w", w)
print("rec\n", rec)
print("readout\n", ro)
print("svd rec", np.linalg.svd(rec, compute_uv=False))
print("svd readout", np.linalg.svd(ro, compute_uv=False))
