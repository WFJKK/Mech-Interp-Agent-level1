I'll start by examining the weights, the network's behaviour on data, and the baseline cost of the reference entry.Nothing persists between calls; I'll redo it in one go.Exact on all random weight sets and edge inputs. Submitting the sparse version.## What the network does

The weights look like a random/untrained RNN (uniform ±0.25 entries, no structure): outputs are a skewed mix of classes 7, 9, 4, 2, 3, 1 with tiny logit margins (median 0.005, min ~5e-8 in 16k samples), ~47% of hidden units active at every step, never an all-zero state. No task-level description holds exactly, so I did not interpret it semantically; instead I built an exact re-implementation that is cheaper than the forward pass for any weights (fidelity 1.0 on this network, on 11 random weight sets of various scales incl. exact-zero input weights, and on edge inputs such as x0 = 0, x0 = x1 = 0, x0 = 1e-200, scaled inputs).

## How you found it

Looked at the weights (SVDs full rank, no dead units), the outputs' distribution, the hidden-unit activity statistics per step/unit (`network_outputs()` + numpy re-run), and the reference entry's op breakdown (2937 = 32 + 9×304 + 169). Then I searched for exact, weight-independent shortcuts in the cost model and measured each with `measure`, plus `lv1.measure` against `lv1.run_reference` on random weight dictionaries.

## The best entry

`sparse_m43` (reward 0.268, cost 0.730, coverage 1, fidelity 1, 400 nodes, 22 const scalars). Region: every input. Interpretation, exact for any weights:
1. **First two inputs by a 1-D table.** h1 = |x0|·relu(±w), so the step-2 mask depends only on sign(x0) and u = x1/|x0|, with 16 breakpoints θ_j = −s·B_j/w_j (B = rec@relu(±w)). Build sorts the breakpoints per sign and precomputes, for each of 2×17 intervals, P = rec@(M⊙w) and Q = rec@(M⊙B). At run time: interval index i = Σ[θ < u], gather P,Q (32 reads), z3 = [w P Q]@[x2 x1 x0] (48). This replaces 640 ops by ~148.
2. **Fold w·x into the recurrent matmul**: [rec|w]@[h;x] (272 instead of 288 per step).
3. **Sparsity cond-trees.** Units are permuted (constant perm, applied to w/rec/readout in build) so the least-active units (this network's statistics; exactness does not depend on it) sit last. For each of the 7 remaining steps, a nested `lv1.cond` tree on the activity of the last m units (m = 4 for 2 steps, 3 for 5 steps) chooses a static sub-matmul that includes only the active conditioned columns: saves 16 ops per inactive conditioned unit, ~25–32 per step. Node limit (400) is what caps m.
Everything in it is computed from the weights inside the entry; constants are only eps values and the permutation.

## Claims

Claimed fidelity 1.0 on this network and expected 1.0 on the second: the entry is algebraically identical to the network (tables and cond branches are exact selections, not approximations); the only deviation is float rounding ~1e-17, negligible against observed margins. Verified exact on 16384 verifier inputs twice and on random weights of scales 0.05–3.

## Next

- Trim ~13 base nodes (rank-based interval masks instead of midpoints; store P/Q as a (34,16,2) table) and spend nodes on a third m=4 step (+~0.003).
- Choose conditioned units per step from per-step activity statistics; a readout cond-tree (m=1–2) for a few more ops.
- The step-3 "cell table" (591 mask cells, top-300 cover 95%) with sorted-key binary search was analysed and rejected: build cost (~770 ops/cell) exceeds the ~90 ops/input saving.
- Fundamental floor of this approach is ~0.55 cost (full 16-unit trees) but the 400-node limit prevents it; look for a node-cheaper exact sparse matvec if any new op/pricing is available.