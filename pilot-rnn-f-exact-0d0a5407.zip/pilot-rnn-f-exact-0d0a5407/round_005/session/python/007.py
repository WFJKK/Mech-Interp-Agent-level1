
import inspect, re
src = inspect.getsource(lv1)
i = src.find('def const')
print(src[i-200:i+1500])
j = src.find('def cond(c, x, y)')
# how cond is evaluated
k = src.find('"cond"', 17000)
print(src[k-1500:k+1200])
# numpy int@float test
a = np.array([[2**60, 3]], dtype=np.int64); v = np.array([1.5, 2.0**-3])
print(repr(np.matmul(a, v)), 1.5*2**60 + 3*2.0**-3, np.matmul(a,v).dtype)
print(max(np.abs(weights[k]).max() for k in weights), {k: weights[k].shape for k in weights})
