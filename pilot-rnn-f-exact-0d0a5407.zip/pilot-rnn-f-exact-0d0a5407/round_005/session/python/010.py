
import inspect
src = inspect.getsource(lv1)
i = src.find('class Graph'); print(src[i:i+1800])
i = src.find('def draw_inputs'); print(src[i:i+500])
