
import json
for name in ['best','r5_int']:
    e = entries[name]
    m = measure(e)
    print(name, m)
    s = json.dumps(e)
    print(len(s), 'nodes approx:', s.count('"op"'))
e = entries['r5_int']
# print the structure summary
print(list(e.keys()))
ops = e.get('nodes') or e.get('graph') or e
import collections
try:
    print(collections.Counter(n.get('op') for n in e['nodes']))
except Exception as ex:
    print(ex); print(str(e)[:2000])
