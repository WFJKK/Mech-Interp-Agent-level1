
import numpy as np, collections
def per_node(ent, n=400):
    ev = lv1.Evaluator(ent, weights, 10)
    idmap = {id(nd): i for i, nd in enumerate(ev.nodes)}
    acc = collections.Counter(); orig = lv1.apply
    def wrapped(node, args, tokens, weights_, svd_cache=None):
        v, c = orig(node, args, tokens, weights_, svd_cache)
        if tokens is not None: acc[idmap[id(node)]] += c
        return v, c
    lv1.apply = wrapped
    try:
        X = np.random.default_rng(3).standard_normal((n,10))
        for x in X: ev.run(x)
    finally:
        lv1.apply = orig
    return {i: acc[i]/n for i in sorted(acc)}, ev
import inspect
print(inspect.signature(lv1.Evaluator.run))
for name in ['r5_cat', 'r5_desc']:
    ent = entries[name]
    try:
        pn, ev = per_node(ent)
    except Exception as er:
        print('err', er); break
    nodes = ent['nodes']
    tot = sum(pn.values()); print(name, 'total/input (excl cond)', tot)
    # group: table (nodes before the first 'cast'), steps
    for i, c in pn.items():
        if c >= 8: print(i, nodes[i]['op'], round(c,2))
