
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
for fn in ['measure','run_reference']:
    f = getattr(lv1, fn, None)
    if f: print(fn, inspect.signature(f))
print(inspect.signature(lv1.Graph.load))
