
import numpy as np, time
e = entries['r5_int']
def ref_entry():
    g = graph(); return model.reference(g, lv1)
def refgraph():
    g = graph(); r = model.reference(g, lv1); return g.entry(interpretation=r)
ref = refgraph()

def fwd(W, X):
    w, rec, ro = W['input'][:,0], W['recurrent'], W['readout']
    outs=[]; 
    for x in X:
        h = np.maximum(w*x[0],0)
        for t in range(1,len(x)): h = np.maximum(w*x[t]+rec@h,0)
        outs.append(int(np.argmax(ro@h)))
    return np.array(outs)

rng = np.random.default_rng(1)
def test(W, X, label):
    ans, mops = lv1.run_reference(ref, W, 10, X)
    m = lv1.measure(e, W, 10, X, ans, mops)
    mine = fwd(W, X)
    print(label, 'agree', m['n_agree'], '/', m['n_in_region'], 'cost', round(m['cost'],4), 'np-agree', int((mine==np.array(ans)).sum()))

X = rng.standard_normal((1500,10))
test(weights, X, 'this')
for k,scale in enumerate([0.02,0.05,0.1,0.25,0.5,1.0,3.0]):
    W = {'input': rng.uniform(-scale,scale,(16,1)), 'recurrent': rng.uniform(-scale,scale,(16,16)), 'readout': rng.uniform(-scale,scale,(10,16))}
    test(W, X, f'unif{scale}')
W = {'input': rng.standard_normal((16,1))*0.3, 'recurrent': rng.standard_normal((16,16))*0.3, 'readout': rng.standard_normal((10,16))*0.3}
test(W, X, 'gauss')
W = {k:v.copy() for k,v in weights.items()}; W['input'][[0,3,5]] = 0.0; test(W,X,'zero-w')
W = {k:v.copy() for k,v in weights.items()}; W['input'][:] = 0.1; test(W,X,'equal-w')
W = {k:v.copy() for k,v in weights.items()}; W['recurrent'][:,2]=0; W['recurrent'][4,:]=0; test(W,X,'zero rc')
W = {k:v.copy() for k,v in weights.items()}; W['recurrent'][:]=0; test(W,X,'zero rec')
W = {k:np.abs(v) for k,v in weights.items()}; test(W,X,'abs')
W = {k:v.copy() for k,v in weights.items()}; W['input'][:]=0; W['input'][7]=0.2; test(W,X,'15 zero')
W = {k:v.copy() for k,v in weights.items()}; W['input'][2]=1e-6; W['recurrent'][3,5]=1e-7; W['input'][9]=-3e-4; test(W,X,'tiny weights')
# edge inputs on this network
E = np.array([[0]*10, [0.0,1,2,3,4,5,6,7,8,9],[-0.0,1,-2,3,-4,5,6,7,8,9],[0,0,1,-1,1,-1,1,-1,1,-1],[1e-200,1,1,1,1,1,1,1,1,1],[-1e-200,1,1,1,1,1,1,1,1,1],[1e-320,-1,1,1,1,1,1,1,1,1],[0,1e-300,1,1,1,1,1,1,1,1]], float)
E2 = np.vstack([E, X[:50]*1e6, X[:50]*1e-6, X[:50]*1e8, X[:20]*1e-8, X[:5]*0, X[:50]*30])
test(weights, E2, 'edge')
