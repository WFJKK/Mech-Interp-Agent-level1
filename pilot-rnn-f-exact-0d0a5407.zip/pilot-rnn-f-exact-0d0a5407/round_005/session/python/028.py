
import numpy as np
# unit test of the descent + mask logic in numpy
def descent(ths17, u):
    Q = np.arange(17)  # cell ids
    t = ths17
    for mid, cut in [(7,8),(3,4),(1,2),(0,1),(0,1)]:
        c = t[mid] < u
        if c: Q = Q[cut:]; t = t[cut:]
    return Q[0]
rng = np.random.default_rng(0)
bad = 0
for trial in range(20000):
    th = rng.standard_normal(16)
    k = rng.integers(0,4)
    if k == 1: th[:3] = th[5]            # ties
    if k == 2: th[0] = -np.inf; th[1] = np.inf; th[2] = np.nan
    if k == 3: th[:] = np.round(th)      # many ties
    ths = np.sort(th); ths17 = np.append(ths, np.nan)
    u = rng.choice([rng.standard_normal(), ths[rng.integers(16)], np.inf, -np.inf, np.nan, 0.0])
    with np.errstate(invalid='ignore'):
        i = int((th < u).sum())
        d = descent(ths17, u)
        # mask check: below[j,i] = ~(th_j >= ths17[i]) must equal (th_j < u) for finite th_j
        below = ~(th >= ths17[d])
        fin = np.isfinite(th)
        ok = (d == i) and np.array_equal(below[fin], (th < u)[fin])
        if not ok and not (np.isnan(u)):
            # with ties, cells between equal thresholds: i counts strictly; check equivalence of masks only
            bad += 1
            if bad < 5: print('mismatch', th, u, i, d, below[fin], (th<u)[fin])
print('bad', bad)
test_all(entries['r5_desc'])
