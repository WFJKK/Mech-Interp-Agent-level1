
import inspect
src = inspect.getsource(lv1)
print(src[4000:10500])
