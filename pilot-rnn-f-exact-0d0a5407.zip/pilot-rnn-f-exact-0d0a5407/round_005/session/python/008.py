
import numpy as np
def build(g, S=2.0**60, split=True):
    w = g.weight("input")            # (16,1)
    rec = g.weight("recurrent")      # (16,16)
    ro = g.weight("readout")         # (10,16)
    x = g.tokens()
    x0, x1 = x[0], x[1]
    zero = g.const(0.0)
    sgn = g.const(np.array([[-1.0],[1.0]]).reshape(2,1,1))
    # table (as best)
    hs = lv1.maximum(sgn * w, zero)          # (2,16,1)
    B = rec @ hs                             # (2,16,1)
    sB = sgn * B
    th = (-B) / w                            # (2,16,1)
    ths = lv1.sort(th, axis=1)
    rk = lv1.argsort(lv1.argsort(th, axis=1), axis=1)
    irow = g.const(np.arange(17, dtype=np.int64).reshape(1,17))
    below = rk < irow                        # (2,16,17)
    M = lv1.where(w == zero, B > zero, (w > zero) == below)
    T = lv1.stack([rec @ lv1.where(M, sB, zero), rec @ lv1.where(M, w, zero), lv1.where(M, w, w)], axis=3)  # (2,16,17,3)
    s = x0 >= zero
    sidx = lv1.cast(s, "int")
    u = x1 / abs(x0)
    ths_s = lv1.cond(s, ths[1], ths[0])      # (16,1)
    if split:
        c1 = ths_s[7, 0] < u
        half = lv1.cond(c1, ths_s[8:16, 0], ths_s[0:8, 0])
        i = (half < u).sum() + c1 * g.const(np.int64(8))
    else:
        i = (ths_s[:, 0] < u).sum()
    Tsi = lv1.gather(T, [sidx, i], [0, 2])   # (16,3)
    z = Tsi @ x[0:3]
    # packed int matrix
    recw = lv1.concat([rec, w], axis=1)                      # (16,17)
    ro0 = lv1.concat([ro, g.const(np.zeros((10,1)))], axis=1)  # (10,17)
    jrow = g.const((np.arange(17) / S).reshape(1,17))        # exact floats j/S
    Pf = lv1.concat([recw, ro0, jrow], axis=0)               # (27,17)
    P = lv1.cast(Pf * g.const(S), "int")
    cols = [P[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27,0), dtype=np.int64))
    # scaled tokens for steps with tokens 4..9
    xs = x[4:10] * g.const(np.array([S**k for k in range(1,7)]))
    for t in range(3, 10):
        pos = z > zero
        xt = x[3:4] if t == 3 else xs[t-4:t-3]
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        idx = A[26, 1:]
        v = lv1.concat([xt, lv1.take(z, idx, axis=0)], axis=0)
        z = A[0:16] @ v
    pos = z > zero
    A = lv1.concat([lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
    logits = A[16:26] @ lv1.take(z, A[26], axis=0)
    return g.entry(interpretation=logits.argmax())

g = graph()
ent = build(g)
print(len(ent['nodes']))
m = measure(ent)
print(m)
save_entry("r5_int", ent)
