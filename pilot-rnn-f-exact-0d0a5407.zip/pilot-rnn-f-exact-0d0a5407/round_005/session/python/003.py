
import inspect
src = inspect.getsource(lv1)
print(src[10500:14500])
