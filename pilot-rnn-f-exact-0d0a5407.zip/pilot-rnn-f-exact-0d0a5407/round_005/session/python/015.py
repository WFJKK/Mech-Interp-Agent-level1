
e = entries['r5_int']
nodes = e['nodes']
for i,n in enumerate(nodes[119:], start=119):
    if n['op'] in ('slice','cond') and i>160: continue
    print(i, {k:(v if k!='value' else (str(v)[:200])) for k,v in n.items()})
print(nodes[53]['value'][-1][:5], nodes[77]['value'])
