
import inspect, re
src = inspect.getsource(lv1)
for name in ['_int_index', 'def cond', "'cond'", "'gather'", "'take'", 'def check_structure']:
    for m in re.finditer(re.escape(name), src):
        s = max(0, m.start()-100); print('-----', name); print(src[s:s+900]); break
