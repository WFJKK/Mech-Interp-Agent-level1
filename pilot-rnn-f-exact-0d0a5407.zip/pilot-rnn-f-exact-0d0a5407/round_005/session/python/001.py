
import inspect, os, re
print(info['sizes'] if 'sizes' in info else info.keys())
src = inspect.getsource(lv1)
print(len(src))
# find key functions
for name in ['_int_index','def cast','def take','def matmul','def cond','check_structure','dtype','astype','int64']:
    idxs=[m.start() for m in re.finditer(re.escape(name), src)]
    print(name, len(idxs), idxs[:8])
