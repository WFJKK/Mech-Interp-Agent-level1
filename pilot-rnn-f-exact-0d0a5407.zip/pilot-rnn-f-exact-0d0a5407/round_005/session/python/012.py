
import time
gref = graph(); ref_entry = model.reference(gref, lv1)
rng = np.random.default_rng(7)
def wset(kind, scale=0.25):
    if kind == 'uniform':
        return {'input': rng.uniform(-scale, scale, (16,1)), 'recurrent': rng.uniform(-scale, scale, (16,16)), 'readout': rng.uniform(-scale, scale, (10,16))}
    if kind == 'gauss':
        return {'input': rng.standard_normal((16,1))*scale, 'recurrent': rng.standard_normal((16,16))*scale, 'readout': rng.standard_normal((10,16))*scale}
cases = []
cases.append(('this', weights))
for sc in [0.02, 0.1, 0.25, 1.0, 3.0]:
    cases.append((f'uniform{sc}', wset('uniform', sc)))
for sc in [0.1, 1.0]:
    cases.append((f'gauss{sc}', wset('gauss', sc)))
w = wset('uniform'); w['input'][[2,5,9],0] = 0.0; cases.append(('zero inputs', w))
w = wset('uniform'); w['input'][:] = 0.0; cases.append(('all zero input', w))
w = wset('uniform'); w['recurrent'][3,:] = 0; w['recurrent'][:,7] = 0; cases.append(('zero row/col', w))
w = wset('uniform'); w['recurrent'][:] = 0; cases.append(('zero rec', w))
w = wset('uniform'); w = {k: np.abs(v) for k, v in w.items()}; cases.append(('positive', w))
w = wset('uniform'); w['input'][:] = 0.1; cases.append(('equal inputs', w))
w = wset('uniform'); w['input'][:15] = 0.0; cases.append(('15 zero inputs', w))
w = wset('uniform'); w['input'] *= 1e-4; cases.append(('tiny input w', w))
w = wset('uniform'); w['recurrent'] *= 1e-3; cases.append(('tiny rec', w))
w = wset('uniform'); w['input'] = np.round(w['input'], 2); w['recurrent'] = np.round(w['recurrent'], 2); cases.append(('rounded (ties)', w))
t0 = time.time()
for name, wts in cases:
    g = lv1.Graph(wts, 10, real=True)
    ent = build2(g)
    inputs = rng.standard_normal((800, 10))
    ans, mops = lv1.run_reference(ref_entry, wts, 10, inputs)
    m = lv1.measure(ent, wts, 10, inputs, ans, mops)
    print(f"{name:16s} agree {m['n_agree']}/{m['n_in_region']} cost {m['cost']:.4f}")
print(time.time()-t0)
