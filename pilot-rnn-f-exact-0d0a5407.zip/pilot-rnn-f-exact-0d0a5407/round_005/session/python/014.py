
e = entries['r5_int']
nodes = e['nodes']
for i,n in enumerate(nodes[:120]):
    print(i, {k:(v if k!='value' else (str(v)[:60])) for k,v in n.items()})
print('predict', e['predict'], 'rule', e['rule'])
