
import inspect, re
src = inspect.getsource(lv1.Evaluator)
print(src[:3500])
