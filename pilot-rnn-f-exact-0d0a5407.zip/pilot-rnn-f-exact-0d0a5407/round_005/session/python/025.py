
import numpy as np
S60 = 2.0**60
def build(g, ro_block=(1,9), pad='mod'):
    w = g.weight("input"); rec = g.weight("recurrent"); ro = g.weight("readout")
    toks = g.tokens(); x0 = toks[0]; x1 = toks[1]
    zero = g.const(0.0); S60c = g.const(S60)
    sgn = g.const(np.array([[[1.0]], [[-1.0]]]))          # -s
    nr = lv1.minimum(sgn * w, zero)                          # -relu(s w)   (2,16,1)
    Bp = rec @ nr                                            # -B_s
    sB = sgn * Bp                                            # s B_s
    weq0 = w == zero
    th = Bp / w                                              # -B_s/w  (2,16,1)
    ths = lv1.sort(th, axis=1)
    padv = (sgn % zero) if pad == 'mod' else sgn * (zero / zero)
    thsp = lv1.concat([ths, padv], axis=1)                   # (2,17,1), pad nan
    below = ~(th >= lv1.transpose(thsp, (0,2,1)))            # (2,16,17)
    M = lv1.where(weq0, Bp < zero, (w > zero) == below)
    T0 = rec @ lv1.where(M, sB, zero); T1 = rec @ lv1.where(M, w, zero)
    T = lv1.stack([T0, T1], axis=3)                          # (2,16,17,2)
    Tt = lv1.transpose(T, (0,2,1,3))                         # (2,17,16,2)
    thr = thsp.reshape(2,17,1,1)
    Q = lv1.concat([Tt, lv1.concat([thr, thr], axis=3)], axis=2)   # (2,17,17,2)
    s = x0 >= zero
    u = x1 / abs(x0)
    Qs = lv1.cond(s, Q[1], Q[0])
    for mid, cut in [(7,8),(3,4),(1,2),(0,1),(0,1)]:
        c = Qs[mid, 16, 0] < u
        Qs = lv1.cond(c, Qs[cut:], Qs)
    coef = Qs[0, 0:16, :]
    z = lv1.concat([coef, w], axis=1) @ toks[0:3]
    idxrow = g.const(np.arange(17, dtype=float)[None, :] / S60)
    z10 = g.const(np.zeros((10,1)))
    P = lv1.concat([lv1.concat([rec, w], axis=1), lv1.concat([ro, z10], axis=1), idxrow], axis=0)
    Pi = lv1.cast(P * S60c, "int")
    cols = [Pi[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27,0), dtype=np.int64))
    scales = g.const(np.array([S60**k for k in range(1,7)]))
    xs = toks[4:10] * scales
    for t in range(3, 10):
        xt = toks[3:4] if t == 3 else xs[t-4:t-3]
        pos = z > zero
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        v = lv1.concat([xt, lv1.take(z, A[26, 1:], axis=0)], axis=0)
        z = A[0:16] @ v
    pos = z > zero
    a, b = ro_block
    parts = [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16) if not (a <= j < b)]
    if b > a:
        A = lv1.concat([Pi[:, a:b]] + parts, axis=1)
        vals = lv1.concat([lv1.maximum(z[a:b], zero), lv1.take(z, A[26, b-a:], axis=0)], axis=0)
    else:
        A = lv1.concat(parts, axis=1)
        vals = lv1.take(z, A[26], axis=0)
    logits = A[16:26] @ vals
    return g.entry(interpretation=logits.argmax())

ex = [0.3,-1.2,0.5,0.1,0.2,-0.3,0.4,0.5,-0.6,0.7]
try:
    ent = build(graph(example=ex), pad='mod')
    print('mod pad ok, nodes', len(ent['nodes']))
    gq = graph(example=ex); 
except Exception as er:
    print('mod failed:', er); ent = build(graph(example=ex), pad='div'); print('div pad nodes', len(ent['nodes']))
lv1.check_structure(ent)
# check pad value
g2 = graph(example=ex); sgn = g2.const(np.array([[[1.0]],[[-1.0]]])); zero = g2.const(0.0)
try:
    print('mod value', (sgn % zero).value.ravel())
except Exception as er: print('mod err', er)
m = measure(ent); print({k:m[k] for k in ['n_agree','n_in_region','cost','reward']})
save_entry('r5_desc', ent)
