
import numpy as np
S60 = 2.0**60
def build(g, ro_block=0):
    w = g.weight("input"); rec = g.weight("recurrent"); ro = g.weight("readout")
    toks = g.tokens(); x0 = toks[0]; x1 = toks[1]
    zero = g.const(0.0); inf = g.const(float('inf'))
    sgn = g.const(np.array([[[1.0]], [[-1.0]]]))          # -s
    nr = lv1.minimum(sgn * w, zero)                          # -relu(s w)   (2,16,1)
    Bp = rec @ nr                                            # -B_s
    sB = sgn * Bp                                            # s B_s
    weq0 = w == zero
    th = lv1.where(weq0, inf, Bp / w)                        # (2,16,1)
    ths = lv1.sort(th, axis=1)
    infc = g.const(np.full((2,1,1), float('inf')))
    thsp = lv1.concat([ths, infc], axis=1)                   # (2,17,1)
    below = th < lv1.transpose(thsp, (0,2,1))                # (2,16,17)
    M = lv1.where(weq0, Bp < zero, (w > zero) == below)
    T0 = rec @ lv1.where(M, sB, zero); T1 = rec @ lv1.where(M, w, zero)
    T = lv1.stack([T0, T1], axis=3)                          # (2,16,17,2)
    Tt = lv1.transpose(T, (0,2,1,3))                         # (2,17,16,2)
    thr = thsp.reshape(2,17,1,1)
    Q = lv1.concat([Tt, lv1.concat([thr, thr], axis=3)], axis=2)   # (2,17,17,2)
    s = x0 >= zero
    u = x1 / abs(x0)
    Qs = lv1.cond(s, Q[1], Q[0])
    for mid, cut in [(7,8),(3,4),(1,2),(0,1),(0,1)]:
        c = Qs[mid, 16, 0] < u
        Qs = lv1.cond(c, Qs[cut:], Qs[:cut])
    coef = Qs[0, 0:16, :]
    z = lv1.concat([coef, w], axis=1) @ toks[0:3]
    # packed int matrix
    idxrow = g.const(np.arange(17, dtype=float)[None, :] / S60)
    z10 = g.const(np.zeros((10,1)))
    P = lv1.concat([lv1.concat([rec, w], axis=1), lv1.concat([ro, z10], axis=1), idxrow], axis=0)
    Pi = lv1.cast(P * g.const(S60), "int")
    cols = [Pi[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27,0), dtype=np.int64))
    scales = g.const(np.array([S60**k for k in range(1,7)]))
    xs = toks[4:10] * scales
    for t in range(3, 10):
        xt = toks[3:4] if t == 3 else xs[t-4:t-3]
        pos = z > zero
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        v = lv1.concat([xt, lv1.take(z, A[26, 1:], axis=0)], axis=0)
        z = A[0:16] @ v
    pos = z > zero
    nb = 16 - ro_block
    parts = [lv1.cond(pos[j:j+1], cols[j], E) for j in range(nb)]
    if ro_block:
        parts.append(Pi[:, nb:16])
        vals = lv1.concat([lv1.take(z, lv1.concat(parts, axis=1)[26], axis=0)], axis=0) if False else None
    A = lv1.concat(parts, axis=1)
    if ro_block:
        idx = lv1.concat(parts[:-1], axis=1)[26] if nb else None
        vals = lv1.take(z, idx, axis=0)
        vals = lv1.concat([vals, lv1.maximum(z[nb:16], zero)], axis=0)
    else:
        vals = lv1.take(z, A[26], axis=0)
    logits = A[16:26] @ vals
    return g.entry(interpretation=logits.argmax())

g = graph(example=[0.3,-1.2,0.5,0.1,0.2,-0.3,0.4,0.5,-0.6,0.7])
ent = build(g)
print('nodes', len(ent['nodes']))
ent2 = build(graph(example=[0.3,-1.2,0.5,0.1,0.2,-0.3,0.4,0.5,-0.6,0.7]), ro_block=0)
