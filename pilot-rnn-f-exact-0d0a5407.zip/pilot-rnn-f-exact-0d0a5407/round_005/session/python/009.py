
import inspect, re
src = inspect.getsource(lv1)
print(re.findall(r'^def (\w+)\(', src, re.M))
i = src.find('def measure'); print(src[i:i+900])
i = src.find('def run_reference'); print(src[i:i+600])
