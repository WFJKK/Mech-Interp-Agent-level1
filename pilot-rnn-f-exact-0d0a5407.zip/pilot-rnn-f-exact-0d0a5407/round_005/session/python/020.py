
import copy, json, numpy as np
e = copy.deepcopy(entries['r5_int'])
nodes = e['nodes']
# remove node 28 (where(M,w,w)), make stack of [25,27] only, insert concat after gather (47)
old = nodes
new = []
remap = {}
for i, n in enumerate(old):
    if i == 28: continue
    n = copy.deepcopy(n)
    if i == 29: n['args'] = [25, 27]
    remap[i] = len(new); new.append(n)
    if i == 47:
        # concat([gather(16,2), input weight (16,1)], axis=1)
        new.append({'op':'concat', 'args':[i, 0], 'axis':1}); remap[('cat',)] = len(new)-1
# renumber args
def rn(a): return remap[a]
for j, n in enumerate(new):
    if 'args' in n:
        n['args'] = [rn(a) if a != ('cat',) else a for a in n['args']]
# the concat node's args were [47, 0] in old numbering -> remapped. matmul (old 49) must use the concat node
cat_idx = remap[('cat',)]
m49 = remap[49]
assert new[m49]['op']=='matmul'
new[m49]['args'] = [cat_idx, remap[48]]
e['nodes'] = new
e['predict'] = remap[e['predict']]
if e.get('rule') is not None: e['rule'] = remap[e['rule']]
lv1.check_structure(e)
g, interp, region = lv1.Graph.load(e, weights, 10, example=[0.3,-1.2,0.5,0.1,0.2,-0.3,0.4,0.5,-0.6,0.7])
print('loaded ok, example value', interp.value)
m = measure(e); print({k:m[k] for k in ['n_agree','n_in_region','cost','reward']}, 'nodes', len(new))
save_entry('r5_cat', e)
