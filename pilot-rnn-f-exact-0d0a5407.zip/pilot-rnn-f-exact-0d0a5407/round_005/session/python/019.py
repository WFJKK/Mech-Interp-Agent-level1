
import inspect, re
src = inspect.getsource(lv1)
i = src.find('def apply'); print(src[i:i+6000])
