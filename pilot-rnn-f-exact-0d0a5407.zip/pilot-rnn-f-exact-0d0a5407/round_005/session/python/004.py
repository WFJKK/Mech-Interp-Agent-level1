
import inspect
src = inspect.getsource(lv1)
print(src[14500:17400])
print("......")
print(src[43700:46000])
