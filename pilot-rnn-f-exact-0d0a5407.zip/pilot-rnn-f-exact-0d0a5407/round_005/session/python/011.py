
import numpy as np
S = 2.0**60
def build2(g, S=2.0**60, split=True, trace=None):
    w = g.weight("input"); rec = g.weight("recurrent"); ro = g.weight("readout")
    x = g.tokens(); x0, x1 = x[0], x[1]
    zero = g.const(0.0)
    sgn = g.const(np.array([[-1.0],[1.0]]).reshape(2,1,1))
    hs = lv1.maximum(sgn * w, zero); B = rec @ hs; sB = sgn * B
    th = (-B) / w
    ths = lv1.sort(th, axis=1)
    rk = lv1.argsort(lv1.argsort(th, axis=1), axis=1)
    irow = g.const(np.arange(17, dtype=np.int64).reshape(1,17))
    below = rk < irow
    M = lv1.where(w == zero, B > zero, (w > zero) == below)
    T = lv1.stack([rec @ lv1.where(M, sB, zero), rec @ lv1.where(M, w, zero), lv1.where(M, w, w)], axis=3)
    s = x0 >= zero; sidx = lv1.cast(s, "int"); u = x1 / abs(x0)
    ths_s = lv1.cond(s, ths[1], ths[0])
    if split:
        c1 = ths_s[7, 0] < u
        half = lv1.cond(c1, ths_s[8:16, 0], ths_s[0:8, 0])
        i = (half < u).sum() + c1 * g.const(np.int64(8))
    else:
        i = (ths_s[:, 0] < u).sum()
    Tsi = lv1.gather(T, [sidx, i], [0, 2])
    z = Tsi @ x[0:3]
    recw = lv1.concat([rec, w], axis=1)
    ro0 = lv1.concat([ro, g.const(np.zeros((10,1)))], axis=1)
    jrow = g.const((np.arange(17) / S).reshape(1,17))
    Pf = lv1.concat([recw, ro0, jrow], axis=0)
    P = lv1.cast(Pf * g.const(S), "int")
    cols = [P[:, j:j+1] for j in range(17)]
    E = g.const(np.zeros((27,0), dtype=np.int64))
    xs = x[4:10] * g.const(np.array([S**k for k in range(1,7)]))
    zs = [z]
    for t in range(3, 10):
        pos = z > zero
        xt = x[3:4] if t == 3 else xs[t-4:t-3]
        A = lv1.concat([cols[16]] + [lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
        idx = A[26, 1:]
        v = lv1.concat([xt, lv1.take(z, idx, axis=0)], axis=0)
        z = A[0:16] @ v
        zs.append(z)
    pos = z > zero
    A = lv1.concat([lv1.cond(pos[j:j+1], cols[j], E) for j in range(16)], axis=1)
    logits = A[16:26] @ lv1.take(z, A[26], axis=0)
    if trace is not None: trace.extend(zs + [logits])
    return g.entry(interpretation=logits.argmax())

def np_forward(wts, x):
    w = wts['input'][:,0]; rec = wts['recurrent']; ro = wts['readout']
    h = np.maximum(w*x[0], 0); zs=[]
    for t in range(1, len(x)):
        z = w*x[t] + rec@h
        if t >= 2: zs.append(z)
        h = np.maximum(z, 0)
    lg = ro@h
    return zs, lg, int(np.argmax(lg))

def check(wts, x, S=2.0**60):
    g = lv1.Graph(wts, 10, example=x, real=True)
    tr = []
    build2(g, S=S, trace=tr)
    zs, lg, out = np_forward(wts, x)
    errs = []
    for k, (zv, zn) in enumerate(zip(tr[:-1], zs)):
        v = zv.value / (S**k)
        errs.append(np.max(np.abs(v - zn)) / max(np.max(np.abs(zn)), 1e-300))
    lv = tr[-1].value / (S**8)
    errs.append(np.max(np.abs(lv - lg)) / max(np.max(np.abs(lg)), 1e-300))
    return max(errs), errs

rng = np.random.default_rng(1)
worst = 0
for _ in range(30):
    x = rng.standard_normal(10)
    e, errs = check(weights, x); worst = max(worst, e)
print("random worst rel err", worst)
edge = [np.zeros(10), np.r_[0.0, rng.standard_normal(9)], np.r_[-0.0, rng.standard_normal(9)], np.r_[0.0, 0.0, rng.standard_normal(8)],
        np.r_[1e-200, rng.standard_normal(9)], np.r_[-1e-200, rng.standard_normal(9)], np.r_[1e-320, rng.standard_normal(9)],
        rng.standard_normal(10)*1e6, rng.standard_normal(10)*1e-6, rng.standard_normal(10)*1e8, np.r_[rng.standard_normal(1), 0.0, rng.standard_normal(8)]]
for x in edge:
    e, errs = check(weights, x)
    print(np.round(e, 18), [f"{v:.1e}" for v in errs])
