
import json
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
nodes = e['nodes'] if 'nodes' in e else None
print(len(nodes))
for i, n in enumerate(nodes[:80]):
    d = {k: (v if k != 'value' else (np.asarray(v).shape, np.asarray(v).ravel()[:4].tolist())) for k, v in n.items()}
    print(i, d)
