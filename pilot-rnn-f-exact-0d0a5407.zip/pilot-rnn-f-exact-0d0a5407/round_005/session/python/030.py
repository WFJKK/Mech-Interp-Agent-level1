
import numpy as np
e = entries['r5_desc']
# find the table matmul node (first matmul whose args include a concat of coef & weight): node 63 per instrumentation
nodes = e['nodes']; print(nodes[63])
w, rec = weights['input'][:,0], weights['recurrent']
def z3_np(x):
    h = np.maximum(w*x[0],0); h = np.maximum(w*x[1]+rec@h,0); return w*x[2]+rec@h
rng = np.random.default_rng(5)
X = list(rng.standard_normal((150,10)))
# adversarial: u exactly on thresholds
sgn = np.array([[[1.0]],[[-1.0]]]); nr = np.minimum(sgn*weights['input'],0); Bp = rec @ nr; th = (Bp/weights['input'])  # (2,16,1)
for s in (0,1):
    for j in range(16):
        x = rng.standard_normal(10); x[0] = abs(x[0]) * (1 if s else -1); x[1] = th[s,j,0]*abs(x[0]); X.append(x)
X += [np.array([0,0,1,2,3,4,5,6,7,8.]), np.array([-0.0,1,1,1,1,1,1,1,1,1.]), np.array([0,-1,1,1,1,1,1,1,1,1.]), np.array([1e-300,1,1,1,1,1,1,1,1,1.])]
worst = 0; bad = 0
for x in X:
    g, interp, region = lv1.Graph.load(e, weights, 10, example=list(x))
    v = g.nodes[63].value if hasattr(g, 'nodes') else None
    if v is None:
        ev = lv1.Evaluator(e, weights, 10); memo = {}; 
        ev._eval(63, memo, [0], np.asarray(x, float)); v = memo[63]
    ref = z3_np(x)
    err = np.max(np.abs(v - ref)) / (np.max(np.abs(ref)) + 1e-300)
    worst = max(worst, err)
    if err > 1e-12: bad += 1; print('x', x[:3], 'err', err)
print('inputs', len(X), 'worst rel err', worst, 'bad', bad)
