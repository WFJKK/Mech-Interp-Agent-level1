
e = entries['best']
nodes = e['nodes']
for i, n in enumerate(nodes[80:125]):
    i += 80
    d = {k: (v if k != 'value' else (np.asarray(v).shape, np.asarray(v).ravel()[:4].tolist())) for k, v in n.items()}
    print(i, d)
print('...')
for i, n in enumerate(nodes[355:400]):
    i += 355
    d = {k: (v if k != 'value' else (np.asarray(v).shape, np.asarray(v).ravel()[:4].tolist())) for k, v in n.items()}
    print(i, d)
print(e['predict'], e['rule'], e['format'])
