
import numpy as np, json
def load_sub(entry, stop_at, g=None):
    """load nodes [0, stop_at) into graph; returns g, ex (ex entries for loaded)"""
    g = g or graph(); ex = {}
    for i, node in enumerate(entry['nodes'][:stop_at]):
        node = dict(node); args = [ex[a] for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ex[i] = g._add(node, args)
    return g, ex
def load_rest(entry, g, ex, start, stop):
    for i in range(start, stop):
        node = dict(entry['nodes'][i]); args = [ex[a] for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ex[i] = g._add(node, args)

def build_new(K3=(2,3,5), K2=(3,), K4=(2,), argsort_refs=True, lookup=True):
    B = entries['best']
    g, ex = load_sub(B, 68)
    if argsort_refs:
        order = lv1.argsort(-ex[67], axis=1)[:, :3].reshape(9)
        ex[85] = lv1.take(order, g.const(np.array([0, 3, 4, 5, 6])), axis=0)
        load_rest(B, g, ex, 86, 229)
    else:
        load_rest(B, g, ex, 68, 229)
    S_ET, Spos, read, Zall, T4, tab1 = ex[31], ex[35], ex[44], ex[60], ex[228], ex[225]
    Wc448 = (ex[159] * 448).reshape(48)
    candOff = lv1.take(Wc448, ex[213], axis=0)
    code = lv1.where(ex[216], candOff[:, :, 0] // 448, ex[218])
    t = [g.token(i) for i in range(4)]
    tk = g.tokens()
    TK3 = lv1.concat([lv1.transpose(T4, (2,0,1)), lv1.transpose(Zall[1:4], (2,0,1))], axis=1)
    TK = TK3.reshape(64*448)
    one = g.const([1.0])
    kcol = (g.arange(64) * 448).reshape(1, 64)
    def weights_for(r):
        j = t[r]
        sc = [S_ET[r-1][j, t[i]] + Spos[r-1, i][j] for i in range(r)] + [read[r-1][j]]
        w = lv1.softmax(lv1.stack(sc, axis=0), axis=0)
        wz = lv1.concat([w[:r], w[r:] - 1.0, one], axis=0)
        off = (lv1.concat([tk[:r+1], tk[r:r+1]], axis=0) + g.const([i*64 for i in range(r+1)] + [(3+r)*64])).reshape(r+2, 1)
        return j, wz, off
    def kpath(r, K, j, wz, off):
        cs = candOff[r-1][:, :K][j]
        vals = TK[off + cs.reshape(1, K)]
        return cs[(wz @ vals).argmax()] // 448
    def chain(r, Ks, cd):
        j, wz, off = weights_for(r)
        res = (wz @ TK[off + kcol]).argmax()
        for K in sorted(Ks, reverse=True):
            res = lv1.cond(cd >= -K, kpath(r, K, j, wz, off), res)
        return res
    if lookup:
        zrow = (g.arange(64) * 0).reshape(1, 64)
        code12 = lv1.concat([code[0].reshape(64, 1) + zrow, tab1.reshape(1, 64)], axis=0)   # [t1, t0]
        code34 = lv1.concat([code[2].reshape(64, 1) + zrow, code[1].reshape(1, 64)], axis=0)  # [t3, t2]
        cd12 = code12[t[1], t[0]]
        cd34 = code34[t[3], t[2]]
        out12 = lv1.cond(cd12 >= 0, cd12, chain(1, K2, cd12))
        out34 = lv1.cond(cd34 >= 0, cd34, lv1.cond(t[3] == 64, chain(2, K3, cd34), chain(3, K4, cd34)))
        out = lv1.cond(t[2] == 64, out12, out34)
    else:
        def branch(r, Ks):
            cd = code[r-1][t[r]]
            return lv1.cond(cd >= 0, cd, chain(r, Ks, cd))
        n1 = tab1[t[0]]
        out = lv1.cond(t[2] == 64, lv1.cond(t[1] == 64, n1, branch(1, K2)), lv1.cond(t[3] == 64, branch(2, K3), branch(3, K4)))
    return g.entry(interpretation=out)

for K3, ar, lk in [((2,3,5), True, True), ((2,5), True, True), ((2,3,5), True, False)]:
    e = build_new(K3=K3, argsort_refs=ar, lookup=lk)
    print(K3, ar, lk, len(e['nodes']))
    if len(e['nodes']) <= 400:
        m = measure(e); print({k: m[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']})
        save_entry('v5c_%s_%d%d' % ('_'.join(map(str,K3)), ar, lk), e)
