
import numpy as np
W = weights
E = W['embed'][:64]; P = W['pos']; Wq=W['query']; Wk=W['key']; Wv=W['value']; Wo=W['out']; Un=W['unembed']
M = Wq@Wk.T/np.sqrt(32)
VOU = Wv@Wo@Un; ZU = Un+VOU
ET = E@VOU; PT = P@VOU; EU = E@Un; PU = P@Un; EZ = E@ZU; PZ = P@ZU
EME = E@M@E.T; EMP = E@M@P.T; PME = P@M@E.T; PMP = P@M@P.T
Ebar = E.mean(0); nEc = np.linalg.norm(E-Ebar,axis=1).max()
def refs(r):
    Z = EZ + PZ[r]; return np.argsort(-Z.sum(0))[:3]
def coarse(r,c,mode):
    Z = EZ+PZ[r]; U = EU+PU[r]
    sr = EME.diagonal()+EMP[:,r]+PME[r,np.arange(64)]+PMP[r,r]
    if mode=='exact':
        Zd = (Z[:,c][:,None]-Z).min(0); Ud = (U[:,c][:,None]-U).min(0)
    elif mode=='csU':
        dUn = Un[:,c][:,None]-Un
        Ud = (P[r]+Ebar)@dUn - nEc*np.linalg.norm(dUn,axis=0)
        Td = (ET[:,c][:,None]-ET).min(0) + PT[r,c]-PT[r]
        Zd = Ud + Td
    elif mode=='csU2':
        dUn = Un[:,c][:,None]-Un
        Ud = (P[r]+Ebar)@dUn - nEc*np.linalg.norm(dUn,axis=0)
        # Zd: exact min_j of (E_j (dUn+dV)) needs EZ; instead min_j E_j dUn (CS) + min_j Td (exact) -- same as csU
        Td = (ET[:,c][:,None]-ET).min(0) + PT[r,c]-PT[r]
        Zd = Ud + Td
    bound = Zd.copy()
    for i in range(r):
        Dmin = (ET[:,c][:,None]-ET).min(0) + PT[i,c]-PT[i]
        base = EME+PME[r][None,:]
        lo = np.exp(base.min(1)+EMP[:,i]+PMP[r,i]-sr).min(); hi=np.exp(base.max(1)+EMP[:,i]+PMP[r,i]-sr).max()
        a = Ud+Dmin
        bound += np.minimum(lo*a, hi*a)
    return bound > 1e-9
for r in [1,2,3]:
    cs_ = refs(r)
    for mode in ['exact','csU']:
        surv = np.ones(64,bool)
        for c in (cs_ if r==2 else cs_[:1]):
            surv &= ~coarse(r,c,mode)
        print(r, mode, surv.sum(), np.where(surv)[0])
