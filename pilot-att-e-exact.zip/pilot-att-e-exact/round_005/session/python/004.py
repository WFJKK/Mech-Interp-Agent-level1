
import numpy as np
W = weights
E = W['embed'][:64]; P = W['pos']; Wq=W['query']; Wk=W['key']; Wv=W['value']; Wo=W['out']; Un=W['unembed']
M = Wq@Wk.T/np.sqrt(32)
VOU = Wv@Wo@Un; ZU = Un+VOU
ET = E@VOU; PT = P@VOU; EU = E@Un; PU = P@Un; EZ = E@ZU; PZ = P@ZU
EME = E@M@E.T; EMP = E@M@P.T; PME = P@M@E.T; PMP = P@M@P.T
def exact_dom(r,c):
    Z = EZ+PZ[r]; U = EU+PU[r]
    Zd = Z[:,c][:,None]-Z; Ud = U[:,c][:,None]-U
    sr = EME.diagonal()+EMP[:,r]+PME[r,np.arange(64)]+PMP[r,r]
    bound = Zd.copy()
    for i in range(r):
        Dmin = (ET[:,c][:,None]-ET).min(0) + PT[i,c]-PT[i]
        base = EME+PME[r][None,:]
        lo = np.exp(base.min(1)+EMP[:,i]+PMP[r,i]-sr); hi=np.exp(base.max(1)+EMP[:,i]+PMP[r,i]-sr)
        a = Ud + Dmin[None,:]
        bound += np.minimum(lo[:,None]*a, hi[:,None]*a)
    return bound > 1e-9
for r in [1,2,3]:
    D = np.stack([exact_dom(r,c) for c in range(64)])  # (c,j,k)
    full = np.zeros((64,64),bool)  # j,k dominated by any c
    for c in range(64):
        d = D[c].copy(); d[:,c]=False
        full |= d
    cnt = 64 - full.sum(1)
    print("r",r,"cand count hist (any c):", np.bincount(cnt)[:8], "single:", (cnt==1).sum())
    # which c's are the dominating ones per single-cand j
    Z = EZ+PZ[r]
    order = np.argsort(-Z.sum(0))
    for nref in [1,2,3,4,5,6]:
        f = np.zeros((64,64),bool)
        for c in order[:nref]:
            d = D[c].copy(); d[:,c]=False; f |= d
        cnt = 64 - f.sum(1)
        print("   nref",nref, "refs", order[:nref], "hist", np.bincount(cnt)[:8], "single", (cnt==1).sum(), "mean cnt", cnt.mean())
