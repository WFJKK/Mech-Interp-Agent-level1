
import inspect, re
src = inspect.getsource(lv1)
for key in ['"gather"', '"take"', '"take_sum"', 'def gather', 'def take']:
    for m in re.finditer(re.escape(key), src):
        s = max(0, m.start()-200); print('-----', key); print(src[s:m.start()+600]); break
