
import numpy as np
W = weights
E = W['embed'][:64]; P = W['pos']; Wq=W['query']; Wk=W['key']; Wv=W['value']; Wo=W['out']; Un=W['unembed']
M = Wq@Wk.T/np.sqrt(32)
VOU = Wv@Wo@Un; ZU = Un+VOU
ET = E@VOU; PT = P@VOU; EU = E@Un; PU = P@Un; EZ = E@ZU; PZ = P@ZU
EME = E@M@E.T; EMP = E@M@P.T; PME = P@M@E.T; PMP = P@M@P.T
nE = np.linalg.norm(E,axis=1); nEmax = nE.max()
Ebar = E.mean(0); nEc = np.linalg.norm(E-Ebar,axis=1).max()
print("nE", nE.min(), nE.max(), "nEc", nEc, "||P||", np.linalg.norm(P,axis=1))
def refs(r):
    Z = EZ + PZ[r]
    cs = Z.sum(0)
    return np.argsort(-cs)[:3]
for r in [1,2,3]:
    print(r, refs(r))

def exact_dom(r,c):
    # returns dominated[j,k] boolean
    Z = EZ+PZ[r]; U = EU+PU[r]
    Zd = Z[:,c][:,None]-Z            # (j,k)
    Ud = U[:,c][:,None]-U
    sr = EME.diagonal()+EMP[:,r]+PME[r,np.arange(64)]+PMP[r,r]   # read score per j
    bound = Zd.copy()
    for i in range(r):
        Dmin = (ET[:,c][:,None]-ET).min(0) + PT[i,c]-PT[i]      # (k,)
        base = EME+PME[r][None,:]   # (j,t)
        lo = np.exp(base.min(1)+EMP[:,i]+PMP[r,i]-sr); hi=np.exp(base.max(1)+EMP[:,i]+PMP[r,i]-sr)
        a = Ud + Dmin[None,:]
        bound += np.minimum(lo[:,None]*a, hi[:,None]*a)
    return bound > 1e-9

def cs_dom(r,c, center=True):
    # coarse over all j using Cauchy-Schwarz
    dZU = ZU[:,c][:,None]-ZU; dUn = Un[:,c][:,None]-Un; dV = VOU[:,c][:,None]-VOU   # (32,k)
    if center:
        cen = Ebar; rad = nEc
    else:
        cen = np.zeros(32); rad = nEmax
    Zd = (P[r]+cen)@dZU - rad*np.linalg.norm(dZU,axis=0)
    Ud = (P[r]+cen)@dUn - rad*np.linalg.norm(dUn,axis=0)
    sr = EME.diagonal()+EMP[:,r]+PME[r,np.arange(64)]+PMP[r,r]
    bound = Zd.copy()
    for i in range(r):
        Dmin = (P[i]+cen)@dV - rad*np.linalg.norm(dV,axis=0)
        base = EME+PME[r][None,:]
        lo = np.exp(base.min(1)+EMP[:,i]+PMP[r,i]-sr).min(); hi=np.exp(base.max(1)+EMP[:,i]+PMP[r,i]-sr).max()
        a = Ud+Dmin
        bound += np.minimum(lo*a, hi*a)
    return bound > 1e-9

for r in [1,2,3]:
    cs_ = refs(r)
    ex = exact_dom(r, cs_[0])
    print("r",r,"c",cs_[0],"exact per-j dominated all-j survivors:", (~ex.all(0)).sum(), "single-cand tokens:", ((~ex).sum(1)==1).sum())
    for cen in [False, True]:
        d = cs_dom(r, cs_[0], cen)
        print("   CS center",cen,"survivors:", (~d).sum(), np.where(~d)[0])
