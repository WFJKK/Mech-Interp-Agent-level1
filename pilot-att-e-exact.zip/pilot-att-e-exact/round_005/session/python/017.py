
import numpy as np
e = entries['v5c_2_3_5_11']
g = graph(); ref = g.entry(interpretation=model.reference(g, lv1))
rng = np.random.default_rng(17)
def allinputs():
    X1 = np.full((64,4),64); X1[:,0]=np.arange(64)
    X2 = np.full((4096,4),64); X2[:,0]=np.repeat(np.arange(64),64); X2[:,1]=np.tile(np.arange(64),64)
    X3 = np.full((6000,4),64); X3[:,:3]=rng.integers(0,64,(6000,3))
    X4 = rng.integers(0,64,(6000,4))
    return np.concatenate([X1,X2,X3,X4])
X = allinputs()
def check(wts, label):
    ans, mops = lv1.run_reference(ref, wts, 4, X)
    m = lv1.measure(e, wts, 4, X, ans, mops)
    print(label, "agree", m['n_agree'], "/", len(X), "cost", round(m['cost'],4))
check(weights, "this")
def gauss(scale, seed):
    r = np.random.default_rng(seed); w = {}
    for k,v in weights.items():
        w[k] = (r.standard_normal(v.shape)*scale).astype(v.dtype)
    w['embed'][64] = 0
    return w
for s, sd in [(0.1,21),(1.0,23),(20.0,24)]:
    check(gauss(s, sd), f"gauss{s}")
def perturb(frac, seed):
    r = np.random.default_rng(seed); w={}
    for k,v in weights.items():
        w[k] = v + frac*np.abs(v).mean()*r.standard_normal(v.shape).astype(v.dtype)
    w['embed'][64]=0; return w
for f in [0.05, 0.1, 0.3]:
    check(perturb(f, 31), f"perturb{f}")
wi = {k: np.random.default_rng(6).integers(-2,3,v.shape).astype(v.dtype) for k,v in weights.items()}; wi['embed'][64]=0
check(wi, "int-2..2")
wz = {k: np.zeros_like(v) for k,v in weights.items()}; check(wz, "zeros")
ws = dict(weights); ws['query'] = weights['query']*6; check(ws, "sharp6")
wv = dict(weights); wv['value'] = weights['value']*8; check(wv, "value8")
wd = dict(weights); U2 = weights['unembed'].copy(); U2[:,5] = U2[:,16]; U2[:,7]=U2[:,36]; wd['unembed']=U2; check(wd, "dupcol")
wsc = {k: v*1e-3 for k,v in weights.items()}; check(wsc, "x1e-3")
