
import numpy as np, json
def load_all(entry):
    g = graph()
    ex = []
    for node in entry['nodes']:
        node = dict(node); args = [ex[a] for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ex.append(g._add(node, args))
    return g, ex

def build_new(K3=(2,3,5), K2=(3,), K4=(2,)):
    g, ex = load_all(entries['best'])
    S_ET, Spos, read, Zall, T4, code, cand, tab1 = ex[31], ex[35], ex[44], ex[60], ex[228], ex[219], ex[214], ex[225]
    t = [g.token(i) for i in range(4)]
    TK3 = lv1.concat([lv1.transpose(T4, (2,0,1)), lv1.transpose(Zall[1:4], (2,0,1))], axis=1)   # (64,7,64)
    TK = TK3.reshape(64*448)
    candOff = cand * 448
    one = g.const([1.0])
    def weights_for(r):
        j = t[r]
        sc = [S_ET[r-1][j, t[i]] + Spos[r-1, i][j] for i in range(r)] + [read[r-1][j]]
        w = lv1.softmax(lv1.stack(sc, axis=0), axis=0)
        wz = lv1.concat([w[:r], w[r:] - 1.0, one], axis=0)
        off = lv1.stack([t[i] + i*64 if i > 0 else t[0] for i in range(r)] + [t[r] + r*64, t[r] + (3+r)*64], axis=0)
        return j, wz, off
    def kpath(r, K, j, wz, off):
        cs = candOff[r-1][:, :K][j]                      # (K,) int offsets k*448
        idx = off.reshape(r+2, 1) + cs.reshape(1, K)
        vals = TK[idx]                                    # (r+2, K)
        lg = wz @ vals
        m = lg.argmax()
        return cs[m] // 448
    def fallback(r, wz, off):
        rows = lv1.stack([TK3[:, i][:, t[i]] for i in range(r+1)] + [TK3[:, 3+r][:, t[r]]], axis=0)  # (r+2, 64)
        return (wz @ rows).argmax()
    def branch(r, Ks):
        j, wz, off = weights_for(r)
        cd = code[r-1][j]
        res = fallback(r, wz, off)
        for K in sorted(Ks, reverse=True):
            res = lv1.cond(cd >= -K, kpath(r, K, j, wz, off), res)
        return lv1.cond(cd >= 0, cd, res)
    n1 = tab1[t[0]]
    out = lv1.cond(t[2] == 64, lv1.cond(t[1] == 64, n1, branch(1, K2)), lv1.cond(t[3] == 64, branch(2, K3), branch(3, K4)))
    return g.entry(interpretation=out)

e = build_new()
print(len(e['nodes']))
m = measure(e); print(m)
save_entry('v5a', e)
