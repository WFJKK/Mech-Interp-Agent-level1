
print([x for x in dir(lv1) if not x.startswith('_')])
import inspect
print(inspect.signature(lv1.measure))
print(inspect.getdoc(lv1.measure))
print(inspect.signature(lv1.run_reference)); print(inspect.getdoc(lv1.run_reference))
print(inspect.signature(lv1.Graph.load))
print(info['check'])
