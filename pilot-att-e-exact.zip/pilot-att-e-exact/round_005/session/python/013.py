
import numpy as np
e = entries['v5_2_5']
g = graph(); ref = g.entry(interpretation=model.reference(g, lv1))
# code table values: recover from loaded graph
def load_all(entry):
    g = graph(); ex = []
    for node in entry['nodes']:
        node = dict(node); args = [ex[a] for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ex.append(g._add(node, args))
    return g, ex
g2, ex = load_all(entries['best'])
code = ex[219].value
print("code r=2:", code[1])
for j, lab in [(int(np.where(code[1]>=0)[0][0]),'single'), (int(np.where(code[1]==-2)[0][0]),'K2'), (int(np.where(code[1]<=-3)[0][0]),'K5')]:
    X = np.array([[5, 7, j, 64]]*64); X[:,0] = np.arange(64)
    ans, mops = lv1.run_reference(ref, weights, 4, X)
    m = lv1.measure(e, weights, 4, X, ans, mops)
    print(lab, j, code[1][j], "ops/input", m['predict_ops']/64, m['n_agree'])
