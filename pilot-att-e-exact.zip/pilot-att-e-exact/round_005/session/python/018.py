
import numpy as np, json
B = entries['best']
def load_range(g, ex, start, stop):
    for i in range(start, stop):
        node = dict(B['nodes'][i]); args = [ex[a] for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ex[i] = g._add(node, args)

def build_new(K3=(2,3,5), K2=(3,), K4=(2,), split=True, coarse_ts=False):
    g = graph(); ex = {}
    load_range(g, ex, 0, 68)
    order = lv1.argsort(-ex[67], axis=1)[:, :3].reshape(9)
    ex[85] = lv1.take(order, g.const(np.array([0, 3, 4, 5, 6])), axis=0)
    load_range(g, ex, 86, 149)
    if coarse_ts:
        ci = lv1.cast(ex[148], "int")
        r2 = lv1.take_sum(ci, g.const(np.array([1,2,3])), axis=0)
        ex[157] = lv1.concat([ci[0:1], lv1.minimum(r2, 1).reshape(1,64), ci[4:5]], axis=0)
        load_range(g, ex, 158, 184)
    else:
        load_range(g, ex, 149, 184)
    if split:
        Y, D, lo, hi = ex[183], ex[179], ex[88], ex[87]
        a01 = Y.reshape(5,1,64,16) + D[:, :2].reshape(5,2,1,16)
        m01 = lv1.minimum(lo[:, :2].reshape(5,2,64,1) * a01, hi[:, :2].reshape(5,2,64,1) * a01).sum(axis=1)
        a2 = Y[4:5] + D[4:5, 2].reshape(1,1,16)
        m2 = lv1.minimum(lo[4:5, 2].reshape(1,64,1) * a2, hi[4:5, 2].reshape(1,64,1) * a2)
        ex[192] = lv1.concat([m01[0:4], m01[4:5] + m2], axis=0)
        load_range(g, ex, 193, 229)
    else:
        load_range(g, ex, 184, 229)
    S_ET, Spos, read, Zall, T4, tab1 = ex[31], ex[35], ex[44], ex[60], ex[228], ex[225]
    Wc448 = (ex[159] * 448).reshape(48)
    candOff = lv1.take(Wc448, ex[213], axis=0)
    code = lv1.where(ex[216], candOff[:, :, 0] // 448, ex[218])
    t = [g.token(i) for i in range(4)]
    tk = g.tokens()
    TK3 = lv1.concat([lv1.transpose(T4, (2,0,1)), lv1.transpose(Zall[1:4], (2,0,1))], axis=1)
    TK = TK3.reshape(64*448)
    one = g.const([1.0])
    kcol = (g.arange(64) * 448).reshape(1, 64)
    def weights_for(r):
        j = t[r]
        sc = [S_ET[r-1][j, t[i]] + Spos[r-1, i][j] for i in range(r)] + [read[r-1][j]]
        w = lv1.softmax(lv1.stack(sc, axis=0), axis=0)
        wz = lv1.concat([w[:r], w[r:] - 1.0, one], axis=0)
        off = (lv1.concat([tk[:r+1], tk[r:r+1]], axis=0) + g.const([i*64 for i in range(r+1)] + [(3+r)*64])).reshape(r+2, 1)
        return j, wz, off
    def kpath(r, K, j, wz, off):
        cs = candOff[r-1][:, :K][j]
        vals = TK[off + cs.reshape(1, K)]
        return cs[(wz @ vals).argmax()] // 448
    def chain(r, Ks, cd):
        j, wz, off = weights_for(r)
        res = (wz @ TK[off + kcol]).argmax()
        for K in sorted(Ks, reverse=True):
            res = lv1.cond(cd >= -K, kpath(r, K, j, wz, off), res)
        return res
    zrow = (g.arange(64) * 0).reshape(1, 64)
    code12 = lv1.concat([code[0].reshape(64, 1) + zrow, tab1.reshape(1, 64)], axis=0)
    code34 = lv1.concat([code[2].reshape(64, 1) + zrow, code[1].reshape(1, 64)], axis=0)
    cd12 = code12[t[1], t[0]]
    cd34 = code34[t[3], t[2]]
    out12 = lv1.cond(cd12 >= 0, cd12, chain(1, K2, cd12))
    out34 = lv1.cond(cd34 >= 0, cd34, lv1.cond(t[3] == 64, chain(2, K3, cd34), chain(3, K4, cd34)))
    out = lv1.cond(t[2] == 64, out12, out34)
    return g.entry(interpretation=out), ex

for K3, sp, cts in [((2,3,5), True, False), ((2,3,5), True, True), ((2,5), True, True)]:
    try:
        e, ex = build_new(K3=K3, split=sp, coarse_ts=cts)
    except Exception as er:
        print("ERR", K3, sp, cts, er); continue
    print(K3, sp, cts, len(e['nodes']))
    if len(e['nodes']) <= 400:
        m = measure(e); print({k: m[k] for k in ['n_agree','predict_ops','build_ops','cost','reward']})
        save_entry('v5d_%s_%d%d' % ('_'.join(map(str,K3)), sp, cts), e)
