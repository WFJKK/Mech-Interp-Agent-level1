
import numpy as np
g = graph(); ref = g.entry(interpretation=model.reference(g, lv1))
rng = np.random.default_rng(0)
def draw(n, m):
    X = np.full((m,4), 64, dtype=np.int64)
    X[:, :n] = rng.integers(0,64,size=(m,n))
    return X
best = entries['best']
for n in [1,2,3,4]:
    X = draw(n, 4096)
    ans, mops = lv1.run_reference(ref, weights, 4, X)
    m = lv1.measure(best, weights, 4, X, ans, mops)
    print(n, {k: m[k] for k in ['n_agree','predict_ops','build_ops','fidelity']}, "per-input", m['predict_ops']/4096)
