
import inspect
print(inspect.getsource(lv1.Graph.entry))
print(inspect.getsource(lv1.Graph._add)[:1500])
