
import json
print(list(entries.keys()))
print(info['sizes'] if 'sizes' in info else info.keys())
m = measure(entries['best'])
print(m)
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
print(len(e.get('nodes', [])) if isinstance(e, dict) else None)
