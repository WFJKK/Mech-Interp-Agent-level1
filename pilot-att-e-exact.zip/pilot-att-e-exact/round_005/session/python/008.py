
import inspect
print([x for x in dir(lv1.Graph) if not x.startswith('__')])
print([x for x in dir(lv1.Expr) if not x.startswith('__')])
src = inspect.getsource(lv1.Graph.load)
print(src[:3000])
