
best = entries['best']
nodes = best['nodes']
print(best['format'], best['predict'], best['rule'])
print(nodes[0])
import json
for i, nd in enumerate(nodes):
    s = json.dumps(nd)
    if len(s) > 160: s = s[:160]+'...'
    print(i, s)
