
import numpy as np
e = entries['v5_2_5']
g = graph(); ref = g.entry(interpretation=model.reference(g, lv1))
rng = np.random.default_rng(1)
def draw(n, m):
    X = np.full((m,4), 64, dtype=np.int64); X[:, :n] = rng.integers(0,64,size=(m,n)); return X
for n in [1,2,3,4]:
    X = draw(n, 4096)
    ans, mops = lv1.run_reference(ref, weights, 4, X)
    m = lv1.measure(e, weights, 4, X, ans, mops)
    print(n, m['n_agree'], "per-input", m['predict_ops']/4096, "build", m['build_ops'])
# node listing of the non-build part
nodes = e['nodes']
import json
# find first token node
first = min(i for i,nd in enumerate(nodes) if nd['op']=='token')
print("first token node", first, "total", len(nodes))
for i in range(first, len(nodes)):
    s = json.dumps(nodes[i]); print(i, s[:120])
