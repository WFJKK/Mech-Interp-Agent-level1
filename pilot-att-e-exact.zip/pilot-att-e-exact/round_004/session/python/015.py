
exec(SRC)
import numpy as np
g, entry, dbg = build(Wn=16, stop='build')
# numpy reference
W = weights
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
VOU = V@O@Un; ET = E@VOU; PT = P@VOU; EZ = E@(Un+VOU); PZ = P@(Un+VOU)
M = Q@K.T/np.sqrt(32); EME = E@M@E.T; PME = P@M@E.T; EMP = E@M@P.T; PMP = P@M@P.T
S_ET = EME[None] + PME[1:4][:,None,:]; Spos = EMP.T[None] + PMP[1:4][:,:,None]
read = np.array([S_ET[r-1, np.arange(64), np.arange(64)] + Spos[r-1, r, :] for r in (1,2,3)])
hi = np.exp(S_ET.max(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:]); lo = np.exp(S_ET.min(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])
Z = EZ[None] + PZ[1:4][:,None,:]; Y = Z - ET[None]
eps=1e-9
def fine(r, c):
    PTd = PT[:, c][:,None] - PT
    Zd = Z[r-1][:, c][:,None] - Z[r-1]; Ud = Y[r-1][:, c][:,None] - Y[r-1] - PTd[r][None]
    ETd_min = (ET[:, c][:,None] - ET).min(0); b = Zd.copy()
    for i in range(r):
        m = Ud + ETd_min[None] + PTd[i][None]
        b += np.minimum(lo[r-1, i][:,None]*m, hi[r-1,i][:,None]*m)
    return b - eps*(1+hi[r-1,:r].sum(0))[:,None]
c1 = dbg['c1'].value
for r in (1,2,3):
    f = fine(r, c1[r-1]); dom = f >= 0
    cnt_np = 64 - dom.sum(1)
    print(r, 'np hist', np.bincount(cnt_np).tolist(), 'entry hist', np.bincount(dbg['cnt'].value[r-1]).tolist())
    # compare candidate sets
    cand = dbg['cand'].value[r-1]; cnt_e = dbg['cnt'].value[r-1]
    diffs = 0
    for j in range(64):
        se = set(cand[j, :cnt_e[j]].tolist()); sn = set(np.where(~dom[j])[0].tolist())
        if se != sn: diffs += 1; 
        if se != sn and diffs < 4: print('  j', j, 'entry', sorted(se), 'np', sorted(sn))
    print('  rows differing', diffs)
# check lo/hi values in entry? compare hi: rebuild partial values
print('hi np', hi[1,:2,:3], )
