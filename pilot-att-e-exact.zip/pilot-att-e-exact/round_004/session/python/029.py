
import numpy as np, time
entry = entries['v4h']
def ref_entry(W2):
    gg = lv1.Graph(W2, 4)
    return gg.entry(interpretation=model.reference(gg, lv1))
def check(W2, inputs, label):
    ans, ops = lv1.run_reference(ref_entry(W2), W2, 4, inputs)
    m = lv1.measure(entry, W2, 4, inputs, ans, ops)
    print(label, {k: round(m[k],5) for k in ['fidelity','cost','b','r']}, 'n', m['n_inputs'])
rng = np.random.default_rng(23)
W = weights
inp1 = np.array([[a,64,64,64] for a in range(64)])
inp2 = np.array([[a,b,64,64] for a in range(64) for b in range(64)])
check(W, inp1, 'this n=1'); check(W, inp2, 'this n=2 all')
inp34 = np.concatenate([np.concatenate([rng.integers(0,64,(8000,3)), np.full((8000,1),64)],1), rng.integers(0,64,(8000,4))])
check(W, inp34, 'this n=3/4 rand')
def draw(n): return lv1.draw_inputs(info['data_set'], info['input_space'], n, rng)
for scale in [0.1, 0.3, 1.0, 3.0]:
    W2 = {k: rng.normal(0, scale, v.shape) for k,v in W.items()}; W2['embed'][64] = 0
    check(W2, draw(3000), f'gauss{scale}')
for s in [0.05, 0.1, 0.3]:
    W3 = {k: v + rng.normal(0, s*np.abs(v).mean(), v.shape) for k,v in W.items()}; W3['embed'][64]=0
    check(W3, draw(3000), f'pert{s}')
W4 = {k: rng.integers(-2, 3, v.shape).astype(float) for k,v in W.items()}; W4['embed'][64]=0
check(W4, draw(3000), 'int')
W4b = {k: rng.integers(-1, 2, v.shape).astype(float) for k,v in W.items()}; W4b['embed'][64]=0
check(W4b, draw(3000), 'int-1,0,1')
W5 = {k: np.zeros(v.shape) for k,v in W.items()}; check(W5, draw(2000), 'zeros')
W6 = {k: v*6 if k == 'query' else v for k,v in W.items()}; check(W6, draw(3000), 'sharp6')
W6b = {k: v*8 if k == 'value' else v for k,v in W.items()}; check(W6b, draw(3000), 'value8')
W7 = {k: v.copy() for k,v in W.items()}; W7['unembed'][:, 20] = W7['unembed'][:, 16]; check(W7, draw(3000), 'dup-col')
W8 = {k: v*1e-3 for k,v in W.items()}; check(W8, draw(3000), 'tiny')
W9 = {k: v*20 for k,v in W.items()}; check(W9, draw(3000), 'x20')
