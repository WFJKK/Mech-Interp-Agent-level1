
import numpy as np
g = graph(example=[3,5,64,64])
E = g.weight("embed")[:64]
A = E @ g.weight("unembed")   # 64x64
idx = g.const(np.array([[1,2,3],[4,5,6]]))
t = lv1.take(A, idx, axis=0)
print('take 2d idx', t.shape)
idx3 = g.const(np.array([[[1,2],[3,4]],[[5,6],[7,8]]]))
t3 = lv1.take(A.reshape(4096), idx3, axis=0)
print('take 3d idx on flat', t3.shape, np.allclose(t3.value, A.value.reshape(4096)[idx3.value]))
eye = (g.arange(64).reshape(64,1) == g.arange(64).reshape(1,64))
print(eye.shape, eye.value.dtype)
am = A.argmax(axis=1)
try:
    h = lv1.take_sum(lv1.cast(eye, "float"), am, axis=0)
    print('take_sum', h.shape, np.allclose(h.value, np.bincount(A.value.argmax(1), minlength=64)))
except Exception as ex:
    print('take_sum err', ex)
# argsort stable?
v = g.const(np.array([1,0,1,0,0,1,0]))
print(lv1.argsort(v, axis=0).value)
# gather with 2 scalar expressions on a 3-D
B = lv1.stack([A, A*2.0], axis=0)
tok = g.token(0)
print(B[1, tok, tok].value, A.value[3,3]*2)
# where with bool mask * float
print((lv1.where(eye, 1.0, 0.0)).shape)
# entry measure of a tiny thing for cost check
e = g.entry(interpretation=lv1.cast(h[tok], "int"))
print(measure(e))
