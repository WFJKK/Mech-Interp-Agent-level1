
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
for name in ['measure','run_reference','take_sum','take','cond','Graph']:
    f = getattr(lv1, name, None)
    if f is not None:
        try:
            print(name, inspect.signature(f))
        except Exception as ex:
            print(name, 'sig err', ex)
        d = inspect.getdoc(f)
        print('   ', (d or '')[:600])
print(inspect.signature(measure))
print(inspect.getdoc(measure))
g = graph()
print([n for n in dir(g) if not n.startswith('_')])
