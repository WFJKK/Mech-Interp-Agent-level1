
import numpy as np, math, json
SRC = r'''
def build(Wn=16, K2=(3,), K3=(3,5), K4=(2,), eps=1e-9, stop=None):
    g = graph()
    E = g.weight('embed')[:64]; P = g.weight('pos'); Q = g.weight('query'); Kw = g.weight('key')
    Vw = g.weight('value'); O = g.weight('out'); Un = g.weight('unembed')
    VOU = (Vw @ O) @ Un
    ET = E @ VOU; PT = P @ VOU
    UZ = Un + VOU; EZ = E @ UZ; PZ = P @ UZ
    M = (Q @ Kw.T) * (1.0/math.sqrt(Q.shape[1]))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMP = (EM @ P.T).T; PMP = PM @ P.T
    S_ET = EME.reshape(1,64,64) + PME[1:4].reshape(3,1,64)      # [r-1, j, t]
    Spos = EMP.reshape(1,4,64) + PMP[1:4].reshape(3,4,1)        # [r-1, i, j]
    SposF = Spos.reshape(12,64)
    diag = lv1.take(S_ET.reshape(3,4096), g.arange(64)*65, axis=1)
    rsel = g.const(np.array([1,6,11]))
    read = diag + lv1.take(SposF, rsel, axis=0)                  # (3,64)
    Smax = S_ET.max(axis=2); Smin = S_ET.min(axis=2)
    rr = read.reshape(3,1,64)
    mask = g.const(np.array([[1.,0,0],[1,1,0],[1,1,1]]).reshape(3,3,1))
    hi = lv1.exp(Smax.reshape(3,1,64) + Spos[:, :3, :] - rr) * mask   # (3,3,64) [r-1,i,j]
    lo = lv1.exp(Smin.reshape(3,1,64) + Spos[:, :3, :] - rr) * mask
    Z = EZ.reshape(1,64,64) + PZ[1:4].reshape(3,1,64)           # (3,64,64) [r-1, j, k]
    n_tables = len(g.nodes)
    am = Z.argmax(axis=2)                                        # (3,64)
    eyef = lv1.cast(g.arange(64).reshape(64,1) == g.arange(64).reshape(1,64), 'float')
    hist = lv1.stack([lv1.take_sum(eyef, am[r], axis=0) for r in range(3)], axis=0)   # (3,64)
    c1 = hist.argmax(axis=1)                                     # (3,)
    n_csel = len(g.nodes)
    ZT = lv1.transpose(Z, (0,2,1)).reshape(192,64)               # [r*64+k, j]
    r64 = g.const(np.array([0,64,128]))
    Zc = lv1.take(ZT, r64 + c1, axis=0)                          # (3,64) [r,j]
    ETc = lv1.take(ET.T, c1, axis=0)                             # (3,64) [r,t]
    PTc = lv1.take(PT.T, c1, axis=0)                             # (3r,4i)
    PTd = PTc.reshape(3,4,1) - PT.reshape(1,4,64)                # (3,4,64) [r,i,k]
    PTd_r = lv1.take(PTd.reshape(12,64), rsel, axis=0)           # (3,64)
    Zd_full = Zc.reshape(3,64,1) - Z                             # (3,64,64) [r,j,k]
    ETd_full = ETc.reshape(3,64,1) - ET.reshape(1,64,64)         # [r,t,k]
    Ud_full = Zd_full - ETd_full                                 # [r,j,k]
    ETd_min = ETd_full.min(axis=1)                               # (3,64)
    Ud_min = Ud_full.min(axis=1) - PTd_r
    lomin = lo.min(axis=2).reshape(3,3,1); himax = hi.max(axis=2).reshape(3,3,1)
    epsH = (1.0 + hi.sum(axis=1)) * eps                          # (3,64)
    m = (Ud_min + ETd_min).reshape(3,1,64) + PTd[:, :3, :]
    term = lv1.minimum(lomin*m, himax*m)
    coarse = Zd_full.min(axis=1) + term.sum(axis=1) - epsH.max(axis=1).reshape(3,1)
    key = lv1.cast(coarse >= 0.0, 'int')                         # (3,64)
    order = lv1.argsort(key, axis=1)
    Wcols = order[:, :Wn]                                        # (3,Wn)
    overflow = (64 - key.sum(axis=1)) > Wn
    n_coarse = len(g.nodes)
    rows = r64.reshape(3,1) + Wcols
    Zd = lv1.transpose(lv1.take(lv1.transpose(Zd_full, (0,2,1)).reshape(192,64), rows, axis=0), (0,2,1))   # (3,64j,Wn)
    Ud = lv1.transpose(lv1.take(lv1.transpose(Ud_full, (0,2,1)).reshape(192,64), rows, axis=0), (0,2,1))
    PTd_W = lv1.take(PTd.reshape(768), g.const((np.arange(3)*256).reshape(3,1,1) + (np.arange(3)*64).reshape(1,3,1)) + Wcols.reshape(3,1,Wn), axis=0)  # (3,3,Wn)
    offW = lv1.take((ETd_min - PTd_r).reshape(192), rows, axis=0)   # (3,Wn)
    mbase = Ud + offW.reshape(3,1,Wn)
    mi = mbase.reshape(3,1,64,Wn) + PTd_W.reshape(3,3,1,Wn)
    termW = lv1.minimum(lo.reshape(3,3,64,1)*mi, hi.reshape(3,3,64,1)*mi)
    b = Zd + termW.sum(axis=1) - epsH.reshape(3,64,1)
    domi = lv1.cast(b >= 0.0, 'int')                             # (3,64,Wn)
    cnt = (Wn - domi.sum(axis=2)) + 100*lv1.cast(overflow, 'int').reshape(3,1)   # (3,64)
    ordm = lv1.argsort(g.arange(Wn).reshape(1,1,Wn) + Wn*domi, axis=2)          # (3,64,Wn)
    cand = lv1.take(Wcols.reshape(3*Wn), g.const((np.arange(3)*Wn).reshape(3,1,1)) + ordm, axis=0)   # (3,64,Wn)
    code = lv1.where(cnt == 1, cand[:, :, 0], -cnt)              # (3,64)
    n_fine = len(g.nodes)
    t = [g.token(i) for i in range(4)]
    A1 = (EZ + PZ[0].reshape(1,64)).argmax(axis=1)
    if stop == 'build':
        return g, g.entry(interpretation=code[0][t[0]] + A1[t[0]] + lv1.cast(coarse[0][t[0]] > 0, 'int')), dict(code=code, cnt=cnt, cand=cand, overflow=overflow, c1=c1, coarse=coarse, counts=(n_tables, n_csel, n_coarse, n_fine))
    Trow = [ET + PT[i].reshape(1,64) for i in range(4)]
    Tflat = [Trow[i].reshape(4096) for i in range(4)]
    Zflat = [Z[r].reshape(4096) for r in range(3)]
    t64 = [t[i]*64 for i in range(4)]
    def weights_n(r, j):
        s = [S_ET[r-1][j, t[i]] + SposF[(r-1)*4+i, j] for i in range(r)] + [read[r-1][j]]
        w = lv1.softmax(lv1.stack(s, axis=0), axis=0)
        return lv1.concat([w[:r], w[r:] - 1.0], axis=0)
    def kpath(r, K, j, wm, candr):
        cs = candr[:K]
        js = t64[r] + cs
        rows = [lv1.take(Tflat[i], t64[i] + cs, axis=0) for i in range(r)] + [lv1.take(Tflat[r], js, axis=0)]
        logits = wm @ lv1.stack(rows, axis=0) + lv1.take(Zflat[r-1], js, axis=0)
        return cs[logits.argmax()]
    def fallback(r, j, wm):
        rows = [Trow[i][t[i]] for i in range(r)] + [Trow[r][j]]
        logits = wm @ lv1.stack(rows, axis=0) + Z[r-1][j]
        return logits.argmax()
    def path(r, Ks):
        j = t[r]
        cd = code[r-1][j]
        wm = weights_n(r, j)
        candr = cand[r-1][j]
        res = fallback(r, j, wm)
        for K in sorted(Ks, reverse=True):
            res = lv1.cond(cd >= -K, kpath(r, K, j, wm, candr), res)
        return lv1.cond(cd >= 0, cd, res)
    out = lv1.cond(t[2] == 64, lv1.cond(t[1] == 64, A1[t[0]], path(1, K2)), lv1.cond(t[3] == 64, path(2, K3), path(3, K4)))
    entry = g.entry(interpretation=out)
    return g, entry, dict(code=code, cnt=cnt, cand=cand, overflow=overflow, c1=c1, coarse=coarse, counts=(n_tables, n_csel, n_coarse, n_fine, len(g.nodes)))
'''
exec(SRC)
for Wn in (12, 16):
    g, entry, dbg = build(Wn=Wn, stop='build')
    print('Wn', Wn, 'node counts', dbg['counts'], 'overflow', dbg['overflow'].value, 'surv', (dbg['coarse'].value < 0).sum(1))
    cnt = dbg['cnt'].value
    print('cnt hist', [np.bincount(cnt[r]).tolist() for r in range(3)])
    m = measure(entry); print({k: m[k] for k in ['build_ops']})
g, entry, dbg = build(Wn=16)
print('full nodes', dbg['counts'])
m = measure(entry); print(m)
save_entry('v4b', entry)
