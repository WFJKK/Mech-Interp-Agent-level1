
import json
print(info.keys() if hasattr(info,'keys') else info)
print({k:v for k,v in info.items() if k!='data'} if hasattr(info,'keys') else '')
print(list(entries.keys()))
e = entries['best']
print(type(e), (list(e.keys()) if isinstance(e, dict) else None))
s = json.dumps(e)
print(len(s))
m = measure(e)
print(m)
