
import json
e = entries['best']
nodes = e['nodes']
print(e['format'], e['predict'], e['rule'], len(nodes))
print(nodes[0] if isinstance(nodes, list) else list(nodes.items())[:3])
# print compactly
def short(n):
    d = dict(n)
    if 'value' in d and isinstance(d['value'], list):
        v = json.dumps(d['value']); d['value'] = v[:60]
    return d
for i, n in enumerate(nodes[:400] if isinstance(nodes, list) else list(nodes.values())):
    print(i, short(n))
