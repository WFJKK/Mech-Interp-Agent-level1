
import numpy as np
W = weights
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
def tables(W):
    E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
    VOU = V@O@Un; ET = E@VOU; PT = P@VOU; EZ = E@(Un+VOU); PZ = P@(Un+VOU)
    M = Q@K.T/np.sqrt(Q.shape[1])
    EME = E@M@E.T; PME = P@M@E.T; EMP = E@M@P.T; PMP = P@M@P.T
    S_ET = EME[None] + PME[1:4][:,None,:]
    Spos = EMP.T[None] + PMP[1:4][:,:,None]
    read = np.array([S_ET[r-1, np.arange(64), np.arange(64)] + Spos[r-1, r, :] for r in (1,2,3)])
    hi = np.exp(S_ET.max(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])
    lo = np.exp(S_ET.min(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])
    Z = EZ[None] + PZ[1:4][:,None,:]; Y = Z - ET[None]
    return dict(ET=ET,PT=PT,EZ=EZ,PZ=PZ,S_ET=S_ET,Spos=Spos,read=read,hi=hi,lo=lo,Z=Z,Y=Y)
def cs(T):
    am = T['Z'].argmax(2)
    hist = np.array([np.bincount(am[r], minlength=64) for r in range(3)])
    c1 = hist.argmax(1); h2 = hist.copy()
    for r in range(3): h2[r, c1[r]] = 0
    return c1, h2.argmax(1)
eps=1e-9
def fine(T, r, c):
    Z,Y,ET,PT,lo,hi = T['Z'],T['Y'],T['ET'],T['PT'],T['lo'],T['hi']
    Zd = Z[r-1][:, c][:,None] - Z[r-1]; Ud = Y[r-1][:, c][:,None] - Y[r-1]
    ETd_min = (ET[:, c][:,None] - ET).min(0); PTd = PT[:, c][:,None] - PT
    b = Zd.copy()
    for i in range(r):
        m = Ud + ETd_min[None] + PTd[i][None]
        b += np.minimum(lo[r-1, i][:,None]*m, hi[r-1,i][:,None]*m)
    H = hi[r-1,:r].sum(0)
    return b - eps*(1+H)[:,None]
def coarse(T, r, c, loose=True):
    Z,Y,ET,PT,lo,hi = T['Z'],T['Y'],T['ET'],T['PT'],T['lo'],T['hi']
    Zd_min = Z[r-1][:, c].min() - Z[r-1].max(0)
    Ud_min = Y[r-1][:, c].min() - Y[r-1].max(0)
    ETd_min = (ET[:, c].min() - ET.max(0)) if loose else (ET[:, c][:,None] - ET).min(0)
    PTd = PT[:, c][:,None] - PT
    b = Zd_min.copy()
    for i in range(r):
        m = Ud_min + ETd_min + PTd[i]
        b += np.minimum(lo[r-1,i].min()*m, hi[r-1,i].max()*m)
    return b - eps*(1+hi[r-1,:r].sum(0).max())
def model_np(W, toks):  # toks: (N, n) int arrays with n tokens
    E = W['embed']; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
    n = toks.shape[1]
    x = E[toks] + P[:n][None]
    read = x[:, n-1]
    q = (read@Q)/np.sqrt(Q.shape[1]); s = np.einsum('nid,nd->ni', x@K, q)
    w = np.exp(s - s.max(1,keepdims=True)); w/= w.sum(1,keepdims=True)
    head = np.einsum('ni,nid->nd', w, x@V)
    return ((read + head@O)@Un).argmax(1)
def check(W, T=None, N=100000, seed=0):
    T = T or tables(W); c1,c2 = cs(T); rng = np.random.default_rng(seed)
    out = {}
    for n in (2,3,4):
        r = n-1
        dom = fine(T, r, c1[r-1]) >= 0
        if n == 3: dom |= fine(T, r, c2[r-1]) >= 0
        if n == 2:
            toks = np.array([(a,b) for a in range(64) for b in range(64)])
        else:
            toks = rng.integers(0,64,(N,n))
        y = model_np(W, toks)
        j = toks[:, -1]
        bad = dom[j, y].sum()
        co = coarse(T, r, c1[r-1]) >= 0
        if n == 3: co |= coarse(T, r, c2[r-1]) >= 0
        badc = co[y].sum()
        out[n] = (int(bad), int(badc), np.bincount(64-dom.sum(1)).tolist(), int((~co).sum()), int((~dom).any(0).sum()))
    return out
T = tables(W)
print(check(W, T))
rng = np.random.default_rng(1)
for scale in [0.3, 1.0, 3.0]:
    W2 = {k: rng.normal(0, scale, v.shape) for k,v in W.items()}; W2['embed'][64] = 0
    print('gauss', scale, check(W2, N=30000))
W3 = {k: v + rng.normal(0, 0.1*np.abs(v).mean(), v.shape) for k,v in W.items()}; W3['embed'][64]=0
print('perturbed', check(W3, N=30000))
