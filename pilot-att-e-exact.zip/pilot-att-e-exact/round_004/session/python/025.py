
import numpy as np
W = weights
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
VOU = V@O@Un; ET = E@VOU; PT = P@VOU; EZ = E@(Un+VOU); PZ = P@(Un+VOU)
M = Q@K.T/np.sqrt(32); EME = E@M@E.T; PME = P@M@E.T; EMP = E@M@P.T; PMP = P@M@P.T
S_ET = EME[None] + PME[1:4][:,None,:]; Spos = EMP.T[None] + PMP[1:4][:,:,None]
read = np.array([S_ET[r-1, np.arange(64), np.arange(64)] + Spos[r-1, r, :] for r in (1,2,3)])
hi = np.exp(S_ET.max(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:]); lo = np.exp(S_ET.min(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])
Z = EZ[None] + PZ[1:4][:,None,:]; Y = Z - ET[None]
eps=1e-9
def fine(r, c):
    PTd = PT[:, c][:,None] - PT
    Zd = Z[r-1][:, c][:,None] - Z[r-1]; Ud = Y[r-1][:, c][:,None] - Y[r-1] - PTd[r][None]
    ETd_min = (ET[:, c][:,None] - ET).min(0); b = Zd.copy()
    for i in range(r):
        m = Ud + ETd_min[None] + PTd[i][None]
        b += np.minimum(lo[r-1, i][:,None]*m, hi[r-1,i][:,None]*m)
    return b - eps*(1+hi[r-1,:r].sum(0))[:,None]
r = 2
cs_order = np.argsort(-Z[1].sum(0))[:8]
print('colsum order', cs_order)
dom12 = (fine(2, cs_order[0]) >= 0) | (fine(2, cs_order[1]) >= 0)
print('2 c:', np.bincount(64 - dom12.sum(1)).tolist())
for c3 in cs_order[2:8]:
    d3 = dom12 | (fine(2, c3) >= 0)
    print('c3', c3, np.bincount(64 - d3.sum(1)).tolist())
# what are the candidate sets for n=3?
cand_sets = [tuple(np.where(~dom12[j])[0]) for j in range(64)]
from collections import Counter
print(Counter(cand_sets).most_common(10))
# per-token candidate dominated by which c? fraction of tokens where the true output for n=3 is c1/c2
