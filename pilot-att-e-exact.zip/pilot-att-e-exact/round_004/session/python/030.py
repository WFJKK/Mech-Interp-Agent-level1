
import numpy as np
entry = entries['v4h']
rng = np.random.default_rng(23)
W = weights
# replay the same rng sequence to regenerate W4b: easier to just search new seeds for failures
def ref_entry(W2):
    gg = lv1.Graph(W2, 4); return gg.entry(interpretation=model.reference(gg, lv1))
def model_logits(W2, toks):
    E = W2['embed']; P = W2['pos']; Q=W2['query']; K=W2['key']; V=W2['value']; O=W2['out']; Un=W2['unembed']
    n = len(toks); x = E[np.array(toks)] + P[:n]; read = x[n-1]
    q = (read@Q)/np.sqrt(Q.shape[1]); s = (x@K)@q
    w = np.exp(s - s.max()); w /= w.sum()
    return (read + (w@(x@V))@O)@Un
found = 0
for seed in range(23, 60):
    rng = np.random.default_rng(seed)
    W4b = {k: rng.integers(-1, 2, v.shape).astype(float) for k,v in W.items()}; W4b['embed'][64]=0
    inputs = lv1.draw_inputs(info['data_set'], info['input_space'], 3000, rng)
    ans, ops = lv1.run_reference(ref_entry(W4b), W4b, 4, inputs)
    gl, pred, rule = lv1.Graph.load(entry, W4b, 4)
    # evaluate entry per input via lv1.measure? get predictions: use Evaluator
    m = lv1.measure(entry, W4b, 4, inputs, ans, ops)
    if m['fidelity'] < 1:
        print('seed', seed, 'fidelity', m['fidelity'])
        # find failing inputs by measuring one at a time (slow but fine for a few)
        bad = []
        for i in range(len(inputs)):
            mi = lv1.measure(entry, W4b, 4, inputs[i:i+1], ans[i:i+1], ops)
            if mi['fidelity'] < 1: bad.append(i)
            if len(bad) >= 2: break
        for i in bad:
            toks = [int(x) for x in inputs[i] if x != 64]
            lg = model_logits(W4b, toks)
            top = np.argsort(-lg)[:4]
            print(' input', toks, 'net answer', ans[i], 'top logits', [(int(k), float(lg[k])) for k in top], 'ties', (lg == lg.max()).sum())
        found += 1
        if found >= 2: break
print('done')
