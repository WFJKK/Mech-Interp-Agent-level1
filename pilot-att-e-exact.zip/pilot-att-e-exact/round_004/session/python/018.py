
import numpy as np
g = graph()
A = g.weight('embed')[:64] @ g.weight('unembed')
B = lv1.stack([A, A*2.0, A*3.0], axis=0)
C = lv1.stack([B, B+1.0], axis=0)   # (2,3,64,64)
t = g.token(0); u = g.token(1)
n0 = len(g.nodes)
x = C[1, 2, t, u]; n1 = len(g.nodes); print('C[1,2,t,u] nodes', n1-n0, [g.nodes[i]['op'] for i in range(n0, n1)])
y = B[1, t]; n2 = len(g.nodes); print('B[1,t] nodes', n2-n1, [g.nodes[i]['op'] for i in range(n1, n2)])
z = B[1][t]; n3 = len(g.nodes); print('B[1][t] nodes', n3-n2)
w = lv1.take(C.reshape(2*3*4096), (t*64+u) + 4096*5, axis=0); n4 = len(g.nodes); print('flat take', n4-n3)
v = A.min(axis=1); n5=len(g.nodes); 
try:
    v2 = A.min(axis=1, keepdims=True); print('keepdims ok', v2.shape)
except Exception as ex: print('keepdims err', ex)
n6 = len(g.nodes)
s = lv1.softmax(lv1.stack([x, y[0], z[1]], axis=0), axis=0) - g.const(np.array([0,0,1.0])); print('softmax-sub nodes', len(g.nodes)-n6)
e = g.entry(interpretation=lv1.cast(s[0] + w, 'int'))
m = measure(e); print(m['predict_ops']/16384, m['build_ops'])
# c selection quality via column sums
W = weights
E = W['embed'][:64]; P = W['pos']; V=W['value']; O=W['out']; Un=W['unembed']
EZ = E@(Un+V@O@Un); PZ = P@(Un+V@O@Un); Z = EZ[None] + PZ[1:4][:,None,:]
am = Z.argmax(2); hist = np.array([np.bincount(am[r], minlength=64) for r in range(3)])
print('mode c1', hist.argmax(1), 'colsum c', Z.sum(1).argmax(1), 'colmean top2', np.argsort(-Z.sum(1),axis=1)[:, :3], 'hist top', np.argsort(-hist,axis=1)[:, :3])
