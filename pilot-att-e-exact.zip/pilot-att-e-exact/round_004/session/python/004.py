
import numpy as np
W = weights
E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
VOU = V@O@Un
ET = E@VOU; PT = P@VOU
EZ = E@(Un+VOU); PZ = P@(Un+VOU)
M = Q@K.T/np.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMP = E@M@P.T; PMP = P@M@P.T
# S_ET[r-1, j, t] ; Spos[r-1, i, j]
S_ET = EME[None] + PME[1:4][:,None,:]
Spos = EMP.T[None] + PMP[1:4][:,:,None]
read = np.array([S_ET[r-1, np.arange(64), np.arange(64)] + Spos[r-1, r, :] for r in (1,2,3)])  # (3,64)
# ratio bounds rho_i(j) = exp(S_ET[j,t] + Spos[i,j] - read[j])
hi = np.exp(S_ET.max(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])  # (3,i,j)
lo = np.exp(S_ET.min(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])
Z = EZ[None] + PZ[1:4][:,None,:]   # (3,j,k)
Y = Z - ET[None]  # U_r[j,k] = EZ - ET + PZ_r  -> Y[r][j,k] = U_r[j,k]  (direct path)
# c selection
am = Z.argmax(2)
hist = np.array([np.bincount(am[r], minlength=64) for r in range(3)])
c1 = hist.argmax(1); h2 = hist.copy(); 
for r in range(3): h2[r, c1[r]] = 0
c2 = h2.argmax(1)
print('c1', c1, 'c2', c2, hist.max(1), h2.max(1))
pairs = [(1,c1[0]),(2,c1[1]),(2,c2[1]),(3,c1[2])]
eps=1e-9
def fine(r, c):
    # separable per-(j,k) bound, sign-split per slot: min over t and rho of rho*(Ud + D_i(t))
    Zd = Z[r-1][:, c][:,None] - Z[r-1]            # (j,k)
    Ud = Y[r-1][:, c][:,None] - Y[r-1]
    ETd_min = (ET[:, c][:,None] - ET).min(0)      # (k,)
    PTd = PT[:, c][:,None] - PT                   # (i,k)
    b = Zd.copy()
    for i in range(r):
        m = Ud + ETd_min[None] + PTd[i][None]     # (j,k)
        b += np.minimum(lo[r-1, i][:,None]*m, hi[r-1,i][:,None]*m)
    H = hi[r-1,:r].sum(0)
    return b - eps*(1+H)[:,None]  # dominated if >=0
def coarse(r, c):
    Zd_min = Z[r-1][:, c].min() - Z[r-1].max(0)
    Ud_min = Y[r-1][:, c].min() - Y[r-1].max(0)
    ETd_min = (ET[:, c][:,None] - ET).min(0)
    PTd = PT[:, c][:,None] - PT
    b = Zd_min.copy()
    for i in range(r):
        m = Ud_min + ETd_min + PTd[i]
        b += np.minimum(lo[r-1,i].min()*m, hi[r-1,i].max()*m)
    H = hi[r-1,:r].sum(0).max()
    return b - eps*(1+H)
for (r,c) in pairs:
    f = fine(r,c) >= 0
    co = coarse(r,c) >= 0
    print('r',r,'c',c,'fine: cand count hist', np.bincount(64 - f.sum(1)), 'coarse survivors', (~co).sum(), 'fine survivors (any j)', (~f).any(0).sum())
# combined for n=3
f3 = (fine(2,c1[1])>=0) | (fine(2,c2[1])>=0)
co3 = (coarse(2,c1[1])>=0) | (coarse(2,c2[1])>=0)
print('n=3 combined: cand hist', np.bincount(64-f3.sum(1)), 'coarse survivors', (~co3).sum(), 'fine any-j survivors', (~f3).any(0).sum())
print('rho ranges', lo.min(), hi.max())
