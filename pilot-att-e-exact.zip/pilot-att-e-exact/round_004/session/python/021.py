
import numpy as np, math, json
SRC = r'''
def build(Wn=16, K2=(3,), K3=(2,3,5), K4=(2,), eps=1e-9, clamp=700.0):
    g = graph()
    E = g.weight('embed')[:64]; P = g.weight('pos'); Q = g.weight('query'); Kw = g.weight('key')
    Vw = g.weight('value'); O = g.weight('out'); Un = g.weight('unembed')
    VOU = (Vw @ O) @ Un
    ET = E @ VOU; PT = P @ VOU
    UZ = Un + VOU; EZ = E @ UZ; PZ = P @ UZ
    M = (Q @ Kw.T) * (1.0/math.sqrt(Q.shape[1]))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMP = (EM @ P.T).T; PMP = PM @ P.T
    S_ET = EME.reshape(1,64,64) + PME[1:4].reshape(3,1,64)      # [r-1, j, t]
    Spos = EMP.reshape(1,4,64) + PMP[1:4].reshape(3,4,1)        # [r-1, i, j]
    SP = S_ET.reshape(3,1,64,64) + Spos[:, :3, :].reshape(3,3,64,1)   # [r-1, i, j, t]
    diag = lv1.take(S_ET.reshape(3,4096), g.arange(64)*65, axis=1)
    read = diag + lv1.take(Spos.reshape(12,64), g.const(np.array([1,6,11])), axis=0)    # (3,64)
    rr = read.reshape(3,1,64)
    hi3 = lv1.exp(S_ET.max(axis=2).reshape(3,1,64) + Spos[:, :3, :] - rr)   # (3,3,64) [r-1,i,j]
    lo3 = lv1.exp(S_ET.min(axis=2).reshape(3,1,64) + Spos[:, :3, :] - rr)
    Z4 = EZ.reshape(1,64,64) + PZ.reshape(4,1,64)               # (4,64,64) [r, j, k]
    Z = Z4[1:4]
    hist = Z.sum(axis=1)                                         # (3,64)
    c1 = hist.argmax(axis=1)                                     # (3,)
    eyef = lv1.cast(g.arange(64).reshape(64,1) == g.arange(64).reshape(1,64), 'float')
    c2 = (hist - 1e30 * lv1.take(eyef, c1, axis=0)).argmax(axis=1)
    cvec = lv1.concat([c1[0:2], c2[1:2], c1[2:3]], axis=0)       # (4,) pairs (1,c1),(2,c1),(2,c2),(3,c1)
    pr = g.const(np.array([0,1,1,2]))
    mask = g.const(np.array([[1.,0,0],[1,1,0],[1,1,0],[1,1,1]]).reshape(4,3,1))
    hi = lv1.take(hi3, pr, axis=0) * mask                        # (4,3,64)
    lo = lv1.take(lo3, pr, axis=0) * mask
    PZr = lv1.take(PZ, g.const(np.array([1,2,2,3])), axis=0)     # (4,64)
    Zmax = EZ.max(axis=0).reshape(1,64) + PZr                    # (4,64)
    Ymax = (EZ - ET).max(axis=0).reshape(1,64) + PZr
    ZT = lv1.transpose(Z, (0,2,1)).reshape(192,64)               # [r*64+k, j]
    p64 = g.const(np.array([0,64,64,128]))
    Zc = lv1.take(ZT, p64 + cvec, axis=0)                        # (4,64) [p,j]
    ETT = ET.T
    ETc = lv1.take(ETT, cvec, axis=0)                            # (4,64) [p,t]
    Yc = Zc - ETc
    PTc = lv1.take(PT.T, cvec, axis=0)                           # (4p,4i)
    PTd = PTc.reshape(4,4,1) - PT.reshape(1,4,64)                # (4,4,64) [p,i,k]
    PTd_r = lv1.take(PTd.reshape(16,64), g.const(np.array([1,6,10,15])), axis=0)   # (4,64)
    Zd_min = Zc.min(axis=1).reshape(4,1) - Zmax
    Ud_min = Yc.min(axis=1).reshape(4,1) - Ymax - PTd_r
    ETd_min = ETc.min(axis=1).reshape(4,1) - ET.max(axis=0).reshape(1,64)
    lomin = lo.min(axis=2).reshape(4,3,1); himax = hi.max(axis=2).reshape(4,3,1)
    epsH = (1.0 + hi.sum(axis=1)) * eps                          # (4,64)
    m = (Ud_min + ETd_min).reshape(4,1,64) + PTd[:, :3, :]
    term = lv1.minimum(lomin*m, himax*m)
    coarse = Zd_min + term.sum(axis=1) - epsH.max(axis=1).reshape(4,1)
    cdom = coarse >= 0.0
    key = lv1.cast(lv1.concat([cdom[0:1], cdom[1:2] | cdom[2:3], cdom[3:4]], axis=0), 'int')   # (3,64)
    order = lv1.argsort(key, axis=1)
    Wcols = order[:, :Wn]                                        # (3,Wn)
    extra = 100 * lv1.maximum((64 - Wn) - key.sum(axis=1), 0)    # (3,) >0 iff survivors > Wn
    Wp = lv1.take(Wcols, pr, axis=0)                             # (4,Wn)
    rows = p64.reshape(4,1) + Wp
    ZW = lv1.transpose(lv1.take(ZT, rows, axis=0), (0,2,1))      # (4,64j,Wn)
    ETW = lv1.transpose(lv1.take(ETT, Wp, axis=0), (0,2,1))      # (4,64t,Wn)
    Zd = Zc.reshape(4,64,1) - ZW
    ETd = ETc.reshape(4,64,1) - ETW
    PTd_W = lv1.take(PTd.reshape(1024), g.const((np.arange(4)*256).reshape(4,1,1) + (np.arange(3)*64).reshape(1,3,1)) + Wp.reshape(4,1,Wn), axis=0)  # (4,3,Wn)
    PTd_rW = lv1.take(PTd_r.reshape(256), g.const((np.arange(4)*64).reshape(4,1)) + Wp, axis=0)   # (4,Wn)
    mbase = Zd - ETd + (ETd.min(axis=1) - PTd_rW).reshape(4,1,Wn)
    mi = mbase.reshape(4,1,64,Wn) + PTd_W.reshape(4,3,1,Wn)
    termW = lv1.minimum(lo.reshape(4,3,64,1)*mi, hi.reshape(4,3,64,1)*mi)
    b = Zd + termW.sum(axis=1) - epsH.reshape(4,64,1)
    dom = b >= 0.0                                               # (4,64,Wn)
    domi = lv1.cast(lv1.concat([dom[0:1], dom[1:2] | dom[2:3], dom[3:4]], axis=0), 'int')   # (3,64,Wn)
    cnt = (Wn - domi.sum(axis=2)) + extra.reshape(3,1)           # (3,64)
    ordm = lv1.argsort(g.arange(Wn).reshape(1,1,Wn) + Wn*domi, axis=2)          # (3,64,Wn)
    cand = lv1.take(Wcols.reshape(3*Wn), g.const((np.arange(3)*Wn).reshape(3,1,1)) + ordm, axis=0)   # (3,64,Wn)
    code = lv1.where(cnt == 1, cand[:, :, 0], -cnt)              # (3,64)
    n_build = len(g.nodes)
    t = [g.token(i) for i in range(4)]
    A1 = Z4[0].argmax(axis=1)
    T4 = ET.reshape(1,64,64) + PT.reshape(4,1,64)                # (4,64,64)
    TZF = lv1.concat([T4.reshape(4*4096), Z.reshape(3*4096)], axis=0)
    tb = [(t[i] + 64*i)*64 for i in range(4)]                    # i*4096 + t_i*64
    one = g.const(np.array([1.0]))
    def weights_n(r, j):
        s = lv1.stack([SP[r-1, i, j, t[i]] for i in range(r)], axis=0)
        rho = lv1.exp(lv1.minimum(s - read[r-1, j], clamp))
        return lv1.concat([rho, one], axis=0)
    def kpath(r, K, j, wm1, candr, jz):
        cs = candr[:K]
        idx = lv1.concat([tb[i] + cs for i in range(r)] + [jz + cs], axis=0)
        logits = wm1 @ lv1.take(TZF, idx, axis=0).reshape(r+1, K)
        return cs[logits.argmax()]
    def fallback(r, j, wm1):
        rows = [T4[i, t[i]] for i in range(r)] + [Z[r-1, j]]
        return (wm1 @ lv1.stack(rows, axis=0)).argmax()
    def path(r, Ks):
        j = t[r]
        cd = code[r-1, j]
        wm1 = weights_n(r, j)
        candr = cand[r-1, j]
        jz = tb[r] + (3*4096)      # (j + 64 r)*64 + 12288 = 4*4096 + (r-1)*4096 + j*64
        res = fallback(r, j, wm1)
        for K in sorted(Ks, reverse=True):
            res = lv1.cond(cd >= -K, kpath(r, K, j, wm1, candr, jz), res)
        return lv1.cond(cd >= 0, cd, res)
    out = lv1.cond(t[2] == 64, lv1.cond(t[1] == 64, A1[t[0]], path(1, K2)), lv1.cond(t[3] == 64, path(2, K3), path(3, K4)))
    entry = g.entry(interpretation=out)
    return g, entry, dict(code=code, cnt=cnt, cand=cand, extra=extra, cvec=cvec, coarse=coarse, counts=(n_build, len(g.nodes)))
'''
exec(SRC)
for K3 in [(2,3,5), (3,5)]:
    g, entry, dbg = build(Wn=16, K3=K3)
    print('K3', K3, 'nodes', dbg['counts'], 'extra', dbg['extra'].value, 'cvec', dbg['cvec'].value)
    if dbg['counts'][-1] <= 400:
        m = measure(entry); print(m)
        save_entry('v4d_%d' % len(K3), entry)
