
SRC = SRC.replace("g = graph(example=[3,5,64,64])", "g = graph()")
exec(SRC)
g, entry, dbg = build()
print('nodes', len(entry['nodes']))
print('cvec', dbg['cvec'].value, 'nsurv', dbg['nsurv'].value)
cnt = dbg['cnt'].value
print('cnt hist', [np.bincount(cnt[r]).tolist() for r in range(3)])
m = measure(entry); print(m)
save_entry('v4a', entry)
