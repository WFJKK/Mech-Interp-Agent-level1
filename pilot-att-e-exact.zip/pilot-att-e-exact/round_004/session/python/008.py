
import numpy as np, math, json
SRC = r'''
def build(Wn=16, K2=(3,), K3=(2,3,5), K4=(2,), eps=1e-9):
    g = graph(example=[3,5,64,64])
    E = g.weight('embed')[:64]; P = g.weight('pos'); Q = g.weight('query'); Kw = g.weight('key')
    Vw = g.weight('value'); O = g.weight('out'); Un = g.weight('unembed')
    VOU = (Vw @ O) @ Un
    ET = E @ VOU; PT = P @ VOU
    UZ = Un + VOU; EZ = E @ UZ; PZ = P @ UZ
    M = (Q @ Kw.T) * (1.0/math.sqrt(Q.shape[1]))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMP = (EM @ P.T).T; PMP = PM @ P.T
    S_ET = EME.reshape(1,64,64) + PME[1:4].reshape(3,1,64)      # [r-1, j, t]
    Spos = EMP.reshape(1,4,64) + PMP[1:4].reshape(3,4,1)        # [r-1, i, j]
    diag = lv1.take(S_ET.reshape(3,4096), g.arange(64)*65, axis=1)
    read = diag + lv1.take(Spos.reshape(12,64), g.const(np.array([1,6,11])), axis=0)   # (3,64)
    Smax = S_ET.max(axis=2); Smin = S_ET.min(axis=2)
    hi = lv1.exp(Smax.reshape(3,1,64) + Spos[:, :3, :] - read.reshape(3,1,64))   # (3,3,64) [r-1,i,j]
    lo = lv1.exp(Smin.reshape(3,1,64) + Spos[:, :3, :] - read.reshape(3,1,64))
    Z = EZ.reshape(1,64,64) + PZ[1:4].reshape(3,1,64)           # (3,64,64) [r-1, j, k]
    # reference outputs
    am = Z.argmax(axis=2)                                        # (3,64)
    eyef = lv1.cast(g.arange(64).reshape(64,1) == g.arange(64).reshape(1,64), 'float')
    hist = lv1.stack([lv1.take_sum(eyef, am[r], axis=0) for r in range(3)], axis=0)   # (3,64)
    c1 = hist.argmax(axis=1)
    hist2 = hist * lv1.cast(g.arange(64).reshape(1,64) != c1.reshape(3,1), 'float')
    c2 = hist2.argmax(axis=1)
    cvec = lv1.concat([c1[0:1], c1[1:2], c2[1:2], c1[2:3]], axis=0)   # (4,)
    pr = g.const(np.array([0,1,1,2]))
    # coarse (per pair, all k)
    EZmax = EZ.max(axis=0)
    Zmax_r = EZmax.reshape(1,64) + PZ[1:4]
    Zmax_p = lv1.take(Zmax_r, pr, axis=0)                        # (4,64)
    EY = EZ - ET; EYmax = EY.max(axis=0)
    Ymax_p = lv1.take(EYmax.reshape(1,64) + PZ[1:4], pr, axis=0)
    ZT = lv1.transpose(Z, (0,2,1)).reshape(192,64)               # [r*64+k, j]
    Zc = lv1.take(ZT, pr*64 + cvec, axis=0)                      # (4,64) [p,j]
    ETT = ET.T
    ETc = lv1.take(ETT, cvec, axis=0)                            # (4,64) [p,t]
    Yc = Zc - ETc
    PTc = lv1.take(PT.T, cvec, axis=0)                           # (4p,4i)
    PTd = PTc.reshape(4,4,1) - PT.reshape(1,4,64)                # (4,4,64) [p,i,k]
    PTd_r = lv1.take(PTd.reshape(16,64), g.const(np.array([1,6,10,15])), axis=0)   # (4,64)
    Zd_min = Zc.min(axis=1).reshape(4,1) - Zmax_p
    Ud_min = Yc.min(axis=1).reshape(4,1) - Ymax_p - PTd_r
    ETmax = ET.max(axis=0)
    ETd_min = ETc.min(axis=1).reshape(4,1) - ETmax.reshape(1,64)
    mask = g.const(np.array([[1.,0,0],[1,1,0],[1,1,0],[1,1,1]]).reshape(4,3,1))
    lo_pm = lv1.take(lo, pr, axis=0) * mask                      # (4,3,64)
    hi_pm = lv1.take(hi, pr, axis=0) * mask
    lomin = lo_pm.min(axis=2); himax = hi_pm.max(axis=2)         # (4,3)
    H_p = hi_pm.sum(axis=1)                                      # (4,64)
    m = (Ud_min + ETd_min).reshape(4,1,64) + PTd[:, :3, :]
    term = lv1.minimum(lomin.reshape(4,3,1)*m, himax.reshape(4,3,1)*m)
    coarse = Zd_min + term.sum(axis=1) - (eps*(1.0 + H_p.max(axis=1))).reshape(4,1)
    cdom = coarse >= 0.0
    cdom_r = lv1.concat([cdom[0:1], cdom[1:2] & cdom[2:3], cdom[3:4]], axis=0)   # (3,64)
    key = lv1.cast(cdom_r, 'int')
    order = lv1.argsort(key, axis=1)
    Wcols = order[:, :Wn]                                        # (3,Wn)
    nsurv = 64 - key.sum(axis=1)
    overflow = nsurv > Wn
    Wp = lv1.take(Wcols, pr, axis=0)                             # (4,Wn)
    # fine pass on W columns
    ZW = lv1.transpose(lv1.take(ZT, (pr*64).reshape(4,1) + Wp, axis=0), (0,2,1))   # (4,64j,Wn)
    ETW = lv1.transpose(lv1.take(ETT, Wp, axis=0), (0,2,1))      # (4,64t,Wn)
    Zd = Zc.reshape(4,64,1) - ZW
    ETd = ETc.reshape(4,64,1) - ETW
    ETd_minW = ETd.min(axis=1)                                   # (4,Wn)
    PTd_W = lv1.take(PTd.reshape(1024), g.const((np.arange(4)*256).reshape(4,1,1) + (np.arange(3)*64).reshape(1,3,1)) + Wp.reshape(4,1,Wn), axis=0)  # (4,3,Wn)
    PTd_rW = lv1.take(PTd_r.reshape(256), g.const((np.arange(4)*64).reshape(4,1)) + Wp, axis=0)   # (4,Wn)
    Ud = Zd - ETd - PTd_rW.reshape(4,1,Wn)
    mbase = Ud + ETd_minW.reshape(4,1,Wn)
    mi = mbase.reshape(4,1,64,Wn) + PTd_W.reshape(4,3,1,Wn)
    termW = lv1.minimum(lo_pm.reshape(4,3,64,1)*mi, hi_pm.reshape(4,3,64,1)*mi)
    b = Zd + termW.sum(axis=1) - (eps*(1.0 + H_p)).reshape(4,64,1)
    dom = b >= 0.0                                               # (4,64,Wn)
    dom_r = lv1.concat([dom[0:1], dom[1:2] | dom[2:3], dom[3:4]], axis=0)   # (3,64,Wn)
    domi = lv1.cast(dom_r, 'int')
    cnt = (Wn - domi.sum(axis=2)) + 100*lv1.cast(overflow, 'int').reshape(3,1)   # (3,64)
    ordm = lv1.argsort(g.arange(Wn).reshape(1,1,Wn) + Wn*domi, axis=2)          # (3,64,Wn)
    cand = lv1.take(Wcols.reshape(3*Wn), g.const((np.arange(3)*Wn).reshape(3,1,1)) + ordm, axis=0)   # (3,64,Wn)
    code = lv1.where(cnt == 1, cand[:, :, 0], -cnt)              # (3,64)
    # per input
    t = [g.token(i) for i in range(4)]
    A1 = (EZ + PZ[0].reshape(1,64)).argmax(axis=1)
    Tflat = [(ET + PT[i].reshape(1,64)).reshape(4096) for i in range(4)]
    Zflat = [Z[r].reshape(4096) for r in range(3)]
    Trow = [ET + PT[i].reshape(1,64) for i in range(4)]
    def weights_n(r, j):
        n = r + 1
        s = [S_ET[r-1][j, t[i]] + Spos[r-1][i, j] for i in range(r)] + [read[r-1][j]]
        w = lv1.softmax(lv1.stack(s, axis=0), axis=0)
        return lv1.concat([w[:r], w[r:] - 1.0], axis=0)
    def kpath(r, K, j, wm):
        n = r + 1
        cs = cand[r-1][j][:K]                                     # (K,)
        js = j*64 + cs
        rows = [lv1.take(Tflat[i], t[i]*64 + cs, axis=0) for i in range(r)] + [lv1.take(Tflat[r], js, axis=0)]
        logits = wm @ lv1.stack(rows, axis=0) + lv1.take(Zflat[r-1], js, axis=0)
        return cs[logits.argmax()]
    def fallback(r, j, wm):
        rows = [Trow[i][t[i]] for i in range(r)] + [Trow[r][j]]
        logits = wm @ lv1.stack(rows, axis=0) + Z[r-1][j]
        return logits.argmax()
    def path(r, Ks):
        j = t[r]
        cd = code[r-1][j]
        wm = weights_n(r, j)
        res = fallback(r, j, wm)
        for K in sorted(Ks, reverse=True):
            res = lv1.cond(cd >= -K, kpath(r, K, j, wm), res)
        return lv1.cond(cd >= 0, cd, res)
    out = lv1.cond(t[2] == 64, lv1.cond(t[1] == 64, A1[t[0]], path(1, K2)), lv1.cond(t[3] == 64, path(2, K3), path(3, K4)))
    entry = g.entry(interpretation=out)
    return g, entry, dict(code=code, cnt=cnt, cand=cand, nsurv=nsurv, cvec=cvec, coarse=coarse)
'''
exec(SRC)
g, entry, dbg = build()
print('nodes', len(entry['nodes']))
print('cvec', dbg['cvec'].value, 'nsurv', dbg['nsurv'].value)
cnt = dbg['cnt'].value
print('cnt hist', [np.bincount(cnt[r]).tolist() for r in range(3)])
m = measure(entry); print(m)
save_entry('v4a', entry)
