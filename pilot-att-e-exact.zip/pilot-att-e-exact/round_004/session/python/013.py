
import numpy as np
W = weights
def tables(W):
    E = W['embed'][:64]; P = W['pos']; Q=W['query']; K=W['key']; V=W['value']; O=W['out']; Un=W['unembed']
    VOU = V@O@Un; ET = E@VOU; PT = P@VOU; EZ = E@(Un+VOU); PZ = P@(Un+VOU)
    M = Q@K.T/np.sqrt(Q.shape[1])
    EME = E@M@E.T; PME = P@M@E.T; EMP = E@M@P.T; PMP = P@M@P.T
    S_ET = EME[None] + PME[1:4][:,None,:]; Spos = EMP.T[None] + PMP[1:4][:,:,None]
    read = np.array([S_ET[r-1, np.arange(64), np.arange(64)] + Spos[r-1, r, :] for r in (1,2,3)])
    hi = np.exp(S_ET.max(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:]); lo = np.exp(S_ET.min(2)[:,None,:] + Spos[:, :3, :] - read[:,None,:])
    Z = EZ[None] + PZ[1:4][:,None,:]; Y = Z - ET[None]
    return dict(ET=ET,PT=PT,EZ=EZ,PZ=PZ,S_ET=S_ET,Spos=Spos,read=read,hi=hi,lo=lo,Z=Z,Y=Y)
def cs(T):
    am = T['Z'].argmax(2); hist = np.array([np.bincount(am[r], minlength=64) for r in range(3)])
    c1 = hist.argmax(1); h2 = hist.copy()
    for r in range(3): h2[r, c1[r]] = 0
    return c1, h2.argmax(1)
eps=1e-9
def coarse(T, r, c, ex=(False,False,False)):
    Z,Y,ET,PT,lo,hi = T['Z'],T['Y'],T['ET'],T['PT'],T['lo'],T['hi']
    PTd = PT[:, c][:,None] - PT
    Zd_min = (Z[r-1][:, c][:,None] - Z[r-1]).min(0) if ex[0] else Z[r-1][:, c].min() - Z[r-1].max(0)
    Ud_min = ((Y[r-1][:, c][:,None] - Y[r-1]).min(0) if ex[1] else Y[r-1][:, c].min() - Y[r-1].max(0)) - PTd[r]
    ETd_min = (ET[:, c][:,None] - ET).min(0) if ex[2] else (ET[:, c].min() - ET.max(0))
    b = Zd_min.copy()
    for i in range(r):
        m = Ud_min + ETd_min + PTd[i]
        b += np.minimum(lo[r-1,i].min()*m, hi[r-1,i].max()*m)
    return b - eps*(1+hi[r-1,:r].sum(0).max())
def fine(T, r, c):
    Z,Y,ET,PT,lo,hi = T['Z'],T['Y'],T['ET'],T['PT'],T['lo'],T['hi']
    PTd = PT[:, c][:,None] - PT
    Zd = Z[r-1][:, c][:,None] - Z[r-1]; Ud = Y[r-1][:, c][:,None] - Y[r-1] - PTd[r][None]
    ETd_min = (ET[:, c][:,None] - ET).min(0); b = Zd.copy()
    for i in range(r):
        m = Ud + ETd_min[None] + PTd[i][None]
        b += np.minimum(lo[r-1, i][:,None]*m, hi[r-1,i][:,None]*m)
    return b - eps*(1+hi[r-1,:r].sum(0))[:,None]
def report(W, label):
    T = tables(W); c1,c2 = cs(T)
    res = {}
    for r in (1,2,3):
        c = c1[r-1]
        fs = (~(fine(T,r,c)>=0)).any(0).sum()
        v = [int((coarse(T,r,c,ex)<0).sum()) for ex in [(0,0,0),(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,1,1)]]
        v2 = int(((coarse(T,r,c)<0) & (coarse(T,r,c2[r-1])<0)).sum())
        res[r] = (int(fs), v, v2)
    print(label, res)
report(W, 'this')
rng = np.random.default_rng(1)
for s in [0.05, 0.1, 0.2]:
    for k in range(2):
        W3 = {k_: v + rng.normal(0, s*np.abs(v).mean(), v.shape) for k_,v in W.items()}; W3['embed'][64]=0
        report(W3, f'pert{s}')
