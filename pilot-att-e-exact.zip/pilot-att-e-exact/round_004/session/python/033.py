
save_entry('v4best', entries['v4i_W16_2_nosp'])
m = measure(entries['v4best']); print({k: m[k] for k in ['predict_ops','build_ops','cost','b','r','fidelity','reward']})
print(sorted(entries.keys()))
