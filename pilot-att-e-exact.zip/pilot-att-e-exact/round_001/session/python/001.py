
import json
print({k:(v if not hasattr(v,'shape') else v.shape) for k,v in info.items()})
print({k:v.shape for k,v in weights.items()})
print([n for n in dir(lv1) if not n.startswith('_')])
g = graph()
ref = model.reference(g, lv1)
e = g.entry(interpretation=ref)
print(measure(e))
