
import math
def build(K3=14, K4=8):
    g = graph()
    embed, pos = g.weight("embed"), g.weight("pos")
    query, key, value, out, unembed = [g.weight(k) for k in ["query","key","value","out","unembed"]]
    t = g.tokens()
    n = (t != 64).sum()
    Eq = (embed @ query) * (1/math.sqrt(32)); Pq = (pos @ query) * (1/math.sqrt(32))
    Q = (Pq[:, None, :] + Eq[None, :, :])                        # 4x65x32
    Ek = embed @ key; Pk = pos @ key
    K = (Pk[:, None, :] + Ek[None, :, :]).reshape(260, 32)       # rows i*65+tok
    VOU = (value @ out) @ unembed
    Et = embed @ VOU; Pt = pos @ VOU
    T = (Pt[:, None, :] + Et[None, :, :]).reshape(260, 64)
    Eu = embed @ unembed; Pu = pos @ unembed
    U = (Pu[:, None, :] + Eu[None, :, :]).reshape(260, 64)
    Tf = T.reshape(260 * 64); Uf = U.reshape(260 * 64)
    # n = 1
    tab1 = (U[0:64] + T[0:64]).argmax(axis=1)
    # n = 2 table [b, a]
    S2 = Q[1, 0:64, :] @ K[0:130].T
    s0 = S2[:, 0:64]; s1 = S2[:, 65:129]
    eye = lv1.cast(g.arange(64)[:, None] == g.arange(64)[None, :], "float")
    s1d = (s1 * eye).sum(axis=1)
    sc = lv1.stack([s0, s1d[:, None] + 0.0 * s0], axis=2)
    w = lv1.softmax(sc, axis=2)
    L2 = U[65:129][:, None, :] + w[:, :, 0:1] * T[0:64][None, :, :] + w[:, :, 1:2] * T[65:129][:, None, :]
    tab2 = L2.argmax(axis=2)
    # score tables for n=3 (read slot 2) and n=4 (read slot 3)
    S3 = Q[2, 0:64, :] @ K[0:195].T          # 64 x 195
    S4 = Q[3, 0:64, :] @ K.T                 # 64 x 260
    # candidate tables: for read slot p=nn-1 and token tl: rows r = p*65+tl
    def cand_table(nn, Kn):
        p = nn - 1
        Tp = lv1.concat([T[i*65:i*65+64] for i in range(p)], axis=0)   # rows of slots < p
        Tmax = Tp.max(axis=0); Tmin = Tp.min(axis=0)                   # 64
        Tr = T[p*65:p*65+64]                                           # [tl, j]
        Ur = U[p*65:p*65+64]
        hi = Ur + lv1.maximum(Tmax[None, :], Tr)
        lo = Ur + lv1.minimum(Tmin[None, :], Tr)
        LB = lo.max(axis=1)                                            # [tl]
        isc = hi >= LB[:, None]                                        # [tl, j]
        cnt = lv1.cast(isc, "int").sum(axis=1)                         # [tl]
        keyv = lv1.where(isc, g.arange(64)[None, :] + 0, g.arange(64)[None, :] + 64)
        order = lv1.argsort(keyv, axis=1)[:, 0:Kn]                      # [tl, Kn] candidates asc then others
        return order, cnt
    C3, cnt3 = cand_table(3, K3)
    C4, cnt4 = cand_table(4, K4)
    def scores(nn, S):
        tl = t[nn - 1]
        cols = g.arange(nn) * 65 + t[0:nn]
        s = lv1.stack([S[tl, cols[i]] for i in range(nn)])
        return tl, cols, lv1.softmax(s, axis=0)
    def full(nn, S):
        tl, cols, ww = scores(nn, S)
        r = (nn - 1) * 65 + tl
        logits = U[r] + ww @ lv1.take(T, cols, axis=0)
        return logits.argmax()
    def pruned(nn, S, C):
        tl, cols, ww = scores(nn, S)
        r = (nn - 1) * 65 + tl
        cand = C[tl]                                                   # Kn ints
        idx = (cols * 64)[:, None] + cand[None, :]                     # nn x Kn
        Tsel = lv1.take(Tf, idx, axis=0)
        Usel = lv1.take(Uf, r * 64 + cand, axis=0)
        logits = Usel + ww @ Tsel
        return cand[logits.argmax()]
    p3 = lv1.cond(cnt3[t[2]] <= K3, pruned(3, S3, C3), full(3, S3))
    p4 = lv1.cond(cnt4[t[3]] <= K4, pruned(4, S4, C4), full(4, S4))
    pred = lv1.cond(n == 1, tab1[t[0]], lv1.cond(n == 2, tab2[t[1], t[0]], lv1.cond(n == 3, p3, p4)))
    return g.entry(interpretation=pred)
e = build()
m = measure(e); print(m)
save_entry("pruned_v2", e)
