
import math
def build(K2=6, K3=14, K4=8, shortcut=(2,3,4)):
    g = graph()
    embed, pos = g.weight("embed"), g.weight("pos")
    query, key, value, out, unembed = [g.weight(k) for k in ["query","key","value","out","unembed"]]
    t = g.tokens()
    n = (t != 64).sum()
    Eq = (embed @ query) * (1/math.sqrt(32)); Pq = (pos @ query) * (1/math.sqrt(32))
    Q = (Pq[:, None, :] + Eq[None, :, :])                        # 4x65x32
    Ek = embed @ key; Pk = pos @ key
    K = (Pk[:, None, :] + Ek[None, :, :]).reshape(260, 32)
    VOU = (value @ out) @ unembed
    Et = embed @ VOU; Pt = pos @ VOU
    T = (Pt[:, None, :] + Et[None, :, :]).reshape(260, 64)
    Eu = embed @ unembed; Pu = pos @ unembed
    U = (Pu[:, None, :] + Eu[None, :, :]).reshape(260, 64)
    Tf = T.reshape(260 * 64); Uf = U.reshape(260 * 64)
    tab1 = (U[0:64] + T[0:64]).argmax(axis=1)
    # score tables: S[n][tl, col] for col = i*65+tok ; n=2 uses slot0 cols and own diagonal
    S2a = Q[1, 0:64, :] @ K[0:64].T                      # 64 x 64
    S2d = (Q[1, 0:64, :] * K[65:129]).sum(axis=1)        # 64
    S3 = Q[2, 0:64, :] @ K[0:195].T
    S4 = Q[3, 0:64, :] @ K.T
    def cand_table(nn, Kn):
        p = nn - 1
        Tp = lv1.concat([T[i*65:i*65+64] for i in range(p)], axis=0)
        Tmax = Tp.max(axis=0); Tmin = Tp.min(axis=0)
        Tr = T[p*65:p*65+64]; Ur = U[p*65:p*65+64]
        hi = Ur + lv1.maximum(Tmax[None, :], Tr)
        lo = Ur + lv1.minimum(Tmin[None, :], Tr)
        LB = lo.max(axis=1)
        isc = hi >= LB[:, None]
        cnt = lv1.cast(isc, "int").sum(axis=1)
        keyv = lv1.where(isc, g.arange(64)[None, :] + 0, g.arange(64)[None, :] + 64)
        order = lv1.argsort(keyv, axis=1)[:, 0:Kn]
        return order, cnt
    C2, cnt2 = cand_table(2, K2); C3, cnt3 = cand_table(3, K3); C4, cnt4 = cand_table(4, K4)
    def scores(nn):
        tl = t[nn - 1]
        cols = g.arange(nn) * 65 + t[0:nn]
        if nn == 2:
            s = lv1.stack([S2a[tl, t[0]], S2d[tl]])
        else:
            S = S3 if nn == 3 else S4
            s = lv1.stack([S[tl, cols[i]] for i in range(nn)])
        return tl, cols, lv1.softmax(s, axis=0)
    def full(nn):
        tl, cols, ww = scores(nn)
        r = (nn - 1) * 65 + tl
        logits = U[r] + ww @ lv1.take(T, cols, axis=0)
        return logits.argmax()
    def pruned(nn, C):
        tl, cols, ww = scores(nn)
        r = (nn - 1) * 65 + tl
        cand = C[tl]
        idx = (cols * 64)[:, None] + cand[None, :]
        Tsel = lv1.take(Tf, idx, axis=0)
        Usel = lv1.take(Uf, r * 64 + cand, axis=0)
        logits = Usel + ww @ Tsel
        return cand[logits.argmax()]
    def branch(nn, C, cnt, Kn):
        tl = t[nn - 1]
        inner = lv1.cond(cnt[tl] <= Kn, pruned(nn, C), full(nn))
        if nn in shortcut:
            return lv1.cond(cnt[tl] <= 1, C[tl, 0], inner)
        return inner
    p2 = branch(2, C2, cnt2, K2); p3 = branch(3, C3, cnt3, K3); p4 = branch(4, C4, cnt4, K4)
    pred = lv1.cond(n == 1, tab1[t[0]], lv1.cond(n == 2, p2, lv1.cond(n == 3, p3, p4)))
    return g.entry(interpretation=pred)
for kw in [dict(), dict(shortcut=(2,)), dict(K2=5,K3=15,K4=9), dict(K2=6,K3=12,K4=7)]:
    e = build(**kw); m = measure(e); print(kw, {k: round(m[k],5) for k in ['cost','r','b','reward']}, m['n_agree'])
e = build(); save_entry("pruned_v3", e)
