
for k in [1,2,3,4]:
    m = n==k
    toks = inp[m][:, :k]; o = out[m]
    cands = {}
    if k==1:
        cands['63-a']=63-toks[:,0]; cands['-a%64']=(-toks[:,0])%64; cands['a+32']=(toks[:,0]+32)%64
    else:
        a,b=toks[:,0],toks[:,-1]
        cands['a-b']=(a-b)%64; cands['b-a']=(b-a)%64; cands['a*b']=(a*b)%64; cands['-(sum)']=(-toks.sum(1))%64
        cands['sorted-2nd']=np.sort(toks,1)[:,1]; cands['min+max']= (toks.min(1)+toks.max(1))%64
        cands['count>31'] = (toks>31).sum(1)
    print(k, {c: round((v==o).mean(),3) for c,v in cands.items()}, 'outputs hist top:', np.bincount(o,minlength=64).argsort()[-5:], np.bincount(o,minlength=64).max())
m=n==1
print(sorted(zip(inp[m][:,0], out[m]))[:40])
