
W = weights
embed,pos,query,key,value,out,unembed = [W[k] for k in ["embed","pos","query","key","value","out","unembed"]]
X = (pos[:,None,:] + embed[None,:,:]).reshape(260,32)
VOU = value@out@unembed; T = X@VOU; U = X@unembed
def counts_for(nn):
    rows = np.concatenate([np.arange(i*65, i*65+64) for i in range(nn-1)])
    Tmax = T[rows].max(0); Tmin = T[rows].min(0)
    cs=[]
    for tl in range(64):
        r=(nn-1)*65+tl
        hi = np.maximum(Tmax, T[r]); lo = np.minimum(Tmin, T[r])
        LB=(U[r]+lo).max(); cs.append(int((U[r]+hi>=LB).sum()))
    return np.array(cs)
c = counts_for(2)
print('n=2 counts mean', c.mean(), 'max', c.max(), sorted(c))
for K in range(4, 20):
    print(K, round(11*K + 40 + (c>K).mean()*450, 1), end=' | ')
