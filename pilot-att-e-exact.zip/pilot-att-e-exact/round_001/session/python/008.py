
import time
e = entries["tables_v1"]
gr = graph(); ref_entry = gr.entry(interpretation=model.reference(gr, lv1))
rng = np.random.default_rng(1)
def rand_weights(scale, seed):
    r = np.random.default_rng(seed)
    w = {k: (r.standard_normal(v.shape) * scale).astype(np.float64) for k, v in weights.items()}
    w['embed'][64] = 0.0
    return w
def sample_inputs(k, seed):
    r = np.random.default_rng(seed); res=[]
    for _ in range(k):
        n = int(r.integers(1,5)); x=[int(v) for v in r.integers(0,64,n)] + [64]*(4-n); res.append(x)
    return res
inputs = sample_inputs(4000, 7) + [[a,64,64,64] for a in range(64)]
for scale, seed in [(0.1,1),(1.0,2),(3.0,3),(0.02,4)]:
    ws = rand_weights(scale, seed)
    ans, mops = lv1.run_reference(ref_entry, ws, 4, inputs)
    m = lv1.measure(e, ws, 4, inputs, ans, mops)
    print('scale',scale,'seed',seed,'agree', m['n_agree'],'/',len(inputs), 'outputs distinct', len(set(ans)))
# degenerate: zero weights, and integer weights (many exact ties)
ws0 = {k: np.zeros_like(v) for k,v in weights.items()}
ans, mops = lv1.run_reference(ref_entry, ws0, 4, inputs); m = lv1.measure(e, ws0, 4, inputs, ans, mops); print('zeros agree', m['n_agree'], set(ans))
r = np.random.default_rng(9)
wsi = {k: r.integers(-1,2,v.shape).astype(np.float64) for k,v in weights.items()}; wsi['embed'][64]=0
ans, mops = lv1.run_reference(ref_entry, wsi, 4, inputs); m = lv1.measure(e, wsi, 4, inputs, ans, mops); print('int weights agree', m['n_agree'], len(set(ans)))
