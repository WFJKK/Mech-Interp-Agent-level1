
import math
def build(verbose=False):
    g = graph()
    embed, pos = g.weight("embed"), g.weight("pos")
    query, key, value, out, unembed = [g.weight(k) for k in ["query","key","value","out","unembed"]]
    t = g.tokens()
    n = (t != 64).sum()
    # build tables (input independent)
    Eq = (embed @ query) * (1/math.sqrt(32))      # 65x32
    Pq = (pos @ query) * (1/math.sqrt(32))         # 4x32
    Q = (Pq[:, None, :] + Eq[None, :, :])          # 4x65x32
    Ek = embed @ key; Pk = pos @ key
    K = (Pk[:, None, :] + Ek[None, :, :]).reshape(260, 32)   # rows i*65+tok
    VOU = (value @ out) @ unembed                  # 32x64
    Et = embed @ VOU; Pt = pos @ VOU
    T = (Pt[:, None, :] + Et[None, :, :]).reshape(260, 64)
    Eu = embed @ unembed; Pu = pos @ unembed
    U = (Pu[:, None, :] + Eu[None, :, :]).reshape(260, 64)
    # n = 1 table: weight 1 on itself
    L1 = U[0:64] + T[0:64]
    tab1 = L1.argmax(axis=1)                       # 64
    # n = 2 table: read at slot 1, token b; slot 0 token a
    S2 = Q[1, 0:64, :] @ K[0:130].T                # 64(b) x 130: col a (slot0), 65+tok (slot1)
    s0 = S2[:, 0:64]                               # [b, a]
    s1 = S2[:, 65:129]                             # [b, tok] need diagonal
    eye = lv1.cast(g.arange(64)[:, None] == g.arange(64)[None, :], "float")
    s1d = (s1 * eye).sum(axis=1)                   # [b]
    sc = lv1.stack([s0, s1d[:, None] + 0.0 * s0], axis=2)   # 64 x 64 x 2
    w = lv1.softmax(sc, axis=2)
    L2 = U[65:129][:, None, :] + w[:, :, 0:1] * T[0:64][None, :, :] + w[:, :, 1:2] * T[65:129][:, None, :]
    tab2 = L2.argmax(axis=2)                       # [b, a]
    # n >= 3 : general
    Q34 = Q[2:4].reshape(130, 32)
    S34 = Q34 @ K.T                                # 130 x 260
    def general(nn):
        r = (nn - 3) * 65 + t[nn - 1]
        cols = g.arange(nn) * 65 + t[0:nn]
        s = lv1.stack([S34[r, cols[i]] for i in range(nn)])
        ww = lv1.softmax(s, axis=0)
        Tsel = lv1.take(T, cols, axis=0)           # nn x 64
        logits = U[r + 130 - (nn-3)*65 + (nn-3)*65] if False else U[(nn - 1) * 65 + t[nn - 1]] + ww @ Tsel
        return logits.argmax()
    pred = lv1.cond(n == 1, tab1[t[0]],
           lv1.cond(n == 2, tab2[t[1], t[0]],
           lv1.cond(n == 3, general(3), general(4))))
    return g.entry(interpretation=pred)
e = build()
m = measure(e); print(m)
save_entry("tables_v1", e)
