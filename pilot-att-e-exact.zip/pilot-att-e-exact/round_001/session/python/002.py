
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
inp, out = (no['inputs'], no['outputs']) if isinstance(no, dict) else (no[0], no[1])
inp = np.array(inp); out = np.array(out)
print(inp.shape, out.shape, inp[:5], out[:5])
n = (inp != 64).sum(1)
for k in [1,2,3,4]:
    m = n==k
    toks = inp[m][:, :k]
    o = out[m]
    cands = {'last': toks[:, -1], 'first': toks[:, 0], 'max': toks.max(1), 'min': toks.min(1),
             'sum%64': toks.sum(1) % 64, 'sorted-median': np.sort(toks,1)[:, (k-1)//2]}
    print(k, m.sum(), {c: round((v==o).mean(),3) for c,v in cands.items()})
