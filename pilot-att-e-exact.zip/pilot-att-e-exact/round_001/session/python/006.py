
import inspect
print(inspect.signature(lv1.measure)); print(inspect.getdoc(lv1.measure))
print(inspect.signature(lv1.Graph.load)); print(inspect.getdoc(lv1.Graph.load))
print(inspect.signature(lv1.Evaluator)); print(inspect.getdoc(lv1.Evaluator))
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
print(inspect.signature(lv1.run_reference)); print(inspect.getdoc(lv1.run_reference))
print(inspect.signature(lv1.apply)); print(inspect.getdoc(lv1.apply))
