
import inspect, time
print(inspect.signature(lv1.Evaluator.run)); print(inspect.getdoc(lv1.Evaluator.run))
e = entries["tables_v1"]
# reference entry as dict
gr = graph(); ref_entry = gr.entry(interpretation=model.reference(gr, lv1))
def check(ws, inputs, label):
    t0=time.time()
    ans, mops = lv1.run_reference(ref_entry, ws, 4, inputs)
    m = lv1.measure(e, ws, 4, inputs, ans, mops)
    print(label, len(inputs), 'agree', m['n_agree'], 'cost', round(m['cost'],4), 'time', round(time.time()-t0,1))
    return m
# exhaustive n=1,2
in1 = [[a,64,64,64] for a in range(64)]
in2 = [[a,b,64,64] for a in range(64) for b in range(64)]
check(weights, in1, 'n=1 all'); check(weights, in2, 'n=2 all')
rng = np.random.default_rng(0)
in34 = [[int(x) for x in rng.integers(0,64,4)] for _ in range(3000)] + [[int(x) for x in rng.integers(0,64,3)]+[64] for _ in range(3000)]
check(weights, in34, 'n=3,4 random')
