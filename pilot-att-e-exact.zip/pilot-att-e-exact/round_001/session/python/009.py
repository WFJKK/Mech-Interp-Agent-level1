
W = weights
embed,pos,query,key,value,out,unembed = [W[k] for k in ["embed","pos","query","key","value","out","unembed"]]
X = (pos[:,None,:] + embed[None,:,:]).reshape(260,32)
VOU = value@out@unembed
T = X@VOU; U = X@unembed
for nn in [3,4]:
    rows = np.concatenate([np.arange(i*65, i*65+64) for i in range(nn)])
    Tmax = T[rows].max(0); Tmin = T[rows].min(0)
    counts=[]
    for tl in range(64):
        r = (nn-1)*65+tl
        LB = (U[r]+Tmin).max()
        cand = np.nonzero(U[r]+Tmax >= LB)[0]
        counts.append(len(cand))
    print(nn, 'cand counts: mean', np.mean(counts), 'max', max(counts), sorted(counts)[:10], sorted(counts)[-10:])
# also tighter bound using the read slot's own row: attention on read slot i=nn-1 token tl -> T[r] known.
# logit_j = U[r,j] + w_last*T[r,j] + sum_{i<nn-1} w_i T_ij ; still bounded by max over rows. skip.
print('spread of T columns (max-min):', (T.max(0)-T.min(0)).mean(), ' spread of U rows:', (U.max(1)-U.min(1)).mean())
