
W = weights
embed,pos,query,key,value,out,unembed = [W[k] for k in ["embed","pos","query","key","value","out","unembed"]]
X = (pos[:,None,:] + embed[None,:,:]).reshape(260,32)
VOU = value@out@unembed; T = X@VOU; U = X@unembed
def counts_for(nn, use_read_row):
    rows = np.concatenate([np.arange(i*65, i*65+64) for i in range(nn - (1 if use_read_row else 0))])
    Tmax = T[rows].max(0); Tmin = T[rows].min(0)
    cs=[]
    for tl in range(64):
        r=(nn-1)*65+tl
        hi = np.maximum(Tmax, T[r]) if use_read_row else Tmax
        lo = np.minimum(Tmin, T[r]) if use_read_row else Tmin
        LB=(U[r]+lo).max(); cs.append(int((U[r]+hi>=LB).sum()))
    return np.array(cs)
full = {3: 600, 4: 740}
for nn in [3,4]:
    for urr in [False, True]:
        c = counts_for(nn, urr)
        best = min(((3*nn+5)*K + 45 + (c>K).mean()*full[nn], K) for K in range(1,25))
        print(nn, 'read-row bound' if urr else 'plain', 'mean', c.mean(), 'max', c.max(), 'best (cost,K)', best)
