
e = entries["pruned_v3"]
gr = graph(); ref_entry = gr.entry(interpretation=model.reference(gr, lv1))
def check(ws, inputs, label):
    ans, mops = lv1.run_reference(ref_entry, ws, 4, inputs)
    m = lv1.measure(e, ws, 4, inputs, ans, mops)
    print(label, len(inputs), 'agree', m['n_agree'], 'r', round(m['r'],4), 'b', round(m['b'],4))
in1 = [[a,64,64,64] for a in range(64)]
in2 = [[a,b,64,64] for a in range(64) for b in range(64)]
check(weights, in1, 'n=1 all'); check(weights, in2, 'n=2 all')
rng = np.random.default_rng(5)
check(weights, [[int(x) for x in rng.integers(0,64,3)]+[64] for _ in range(8000)], 'n=3 random')
check(weights, [[int(x) for x in rng.integers(0,64,4)] for _ in range(8000)], 'n=4 random')
def rand_weights(scale, seed):
    r = np.random.default_rng(seed)
    w = {k: (r.standard_normal(v.shape) * scale).astype(np.float64) for k, v in weights.items()}
    w['embed'][64] = 0.0; return w
def sample_inputs(k, seed):
    r = np.random.default_rng(seed); res=[]
    for _ in range(k):
        n = int(r.integers(1,5)); res.append([int(v) for v in r.integers(0,64,n)] + [64]*(4-n))
    return res
inputs = sample_inputs(4000, 11)
for scale, seed in [(0.1,1),(1.0,2),(0.02,4),(0.3,5)]:
    check(rand_weights(scale, seed), inputs, f'rand scale {scale}')
check({k: np.zeros_like(v) for k,v in weights.items()}, inputs, 'zeros')
r = np.random.default_rng(9); wsi = {k: r.integers(-1,2,v.shape).astype(np.float64) for k,v in weights.items()}; wsi['embed'][64]=0; check(wsi, inputs, 'int weights')
for s in [3, 4]:
    wp = {k: v + 0.2*np.random.default_rng(s).standard_normal(v.shape)*v.std() for k,v in weights.items()}; wp['embed'][64]=0; check(wp, inputs, f'perturbed real {s}')
