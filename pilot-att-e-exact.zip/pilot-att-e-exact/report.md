# Run pilot-att-e-exact

- Model models/att-e, rounds on att-e-s0, seed check on att-e-s1.
- Agent: claude-fable-5-1 at effort high, through the claude_code backend.
- Data set: 17,043,520 inputs, 16,384 drawn afresh for each scoring. One forward pass: 12,987 operations (prices-v1).
- Reward: r_alpha, alpha = 10.
- Sandbox: seatbelt.
- The rounds ended: rounds_max (5) reached.

## The locked entry

Submission r5s3 (saved as `v5d_2_5_11`), 400 nodes, 86 numbers in constants, sha256 `7a68d26b20ad3335`.

| Network | Reward | Coverage | Fidelity | Cost | Fidelity claimed |
| --- | --- | --- | --- | --- | --- |
| att-e-s0 (the rounds) | 0.9922 | 1.0000 | 1.00000 | 0.0054 | 1.00000 |
| att-e-s0 (measured again, on a fresh sample) | 0.9922 | 1.0000 | 1.00000 | 0.0055 | 1.00000 |
| att-e-s1 (the seed check) | 0.9560 | 1.0000 | 1.00000 | 0.0416 | 1.00000 |

The first row is the best of several scorings, each on its own sample, so it leans high; the second row is one more scoring of the same entry.

```
n0 = weight(name="embed")
n1 = slice(n0, index=[{"start": null, "step": null, "stop": 64}])
n2 = weight(name="pos")
n3 = weight(name="query")
n4 = weight(name="key")
n5 = weight(name="value")
n6 = weight(name="out")
n7 = weight(name="unembed")
n8 = matmul(n5, n6)
n9 = matmul(n8, n7)
n10 = matmul(n1, n9)
n11 = matmul(n2, n9)
n12 = add(n7, n9)
n13 = matmul(n1, n12)
n14 = matmul(n2, n12)
n15 = transpose(n4)
n16 = matmul(n3, n15)
n17 = const(dtype="float", value=0.17677669529663687)
n18 = mul(n16, n17)
n19 = matmul(n1, n18)
n20 = transpose(n1)
n21 = matmul(n19, n20)
n22 = matmul(n2, n18)
n23 = matmul(n22, n20)
n24 = transpose(n2)
n25 = matmul(n19, n24)
n26 = transpose(n25)
n27 = matmul(n22, n24)
n28 = reshape(n21, shape=[1, 64, 64])
n29 = slice(n23, index=[{"start": 1, "step": null, "stop": 4}])
n30 = reshape(n29, shape=[3, 1, 64])
n31 = add(n28, n30)
n32 = reshape(n26, shape=[1, 4, 64])
n33 = slice(n27, index=[{"start": 1, "step": null, "stop": 4}])
n34 = reshape(n33, shape=[3, 4, 1])
n35 = add(n32, n34)
n36 = reshape(n31, shape=[3, 4096])
n37 = arange(n=64)
n38 = const(dtype="int", value=65)
n39 = mul(n37, n38)
n40 = take(n36, n39, axis=1)
n41 = reshape(n35, shape=[12, 64])
n42 = const(dtype="int", value=[1, 6, 11])
n43 = take(n41, n42, axis=0)
n44 = add(n40, n43)
n45 = slice(n35, index=[null, {"start": null, "step": null, "stop": 3}, null])
n46 = reshape(n44, shape=[3, 1, 64])
n47 = sub(n45, n46)
n48 = const(dtype="float", value=[[[0.0], [-1e+30], [-1e+30]], [[0.0], [0.0], [-1e+30]], [...)
n49 = add(n47, n48)
n50 = max(n31, axis=2)
n51 = reshape(n50, shape=[3, 1, 64])
n52 = add(n51, n49)
n53 = exp(n52)
n54 = min(n31, axis=2)
n55 = reshape(n54, shape=[3, 1, 64])
n56 = add(n55, n49)
n57 = exp(n56)
n58 = reshape(n13, shape=[1, 64, 64])
n59 = reshape(n14, shape=[4, 1, 64])
n60 = add(n58, n59)
n61 = slice(n60, index=[{"start": 1, "step": null, "stop": 4}])
n62 = sum(n13, axis=0)
n63 = reshape(n62, shape=[1, 64])
n64 = slice(n14, index=[{"start": 1, "step": null, "stop": 4}])
n65 = const(dtype="float", value=64.0)
n66 = mul(n65, n64)
n67 = add(n63, n66)
n68 = neg(n67)
n69 = argsort(n68, axis=1)
n70 = slice(n69, index=[null, {"start": null, "step": null, "stop": 3}])
n71 = reshape(n70, shape=[9])
n72 = const(dtype="int", value=[0, 3, 4, 5, 6])
n73 = take(n71, n72, axis=0)
n74 = const(dtype="int", value=[0, 1, 1, 1, 2])
n75 = take(n53, n74, axis=0)
n76 = take(n57, n74, axis=0)
n77 = const(dtype="int", value=[1, 2, 2, 2, 3])
n78 = take(n14, n77, axis=0)
n79 = max(n13, axis=0)
n80 = reshape(n79, shape=[1, 64])
n81 = add(n80, n78)
n82 = sub(n13, n10)
n83 = max(n82, axis=0)
n84 = reshape(n83, shape=[1, 64])
n85 = add(n84, n78)
n86 = transpose(n61, perm=[0, 2, 1])
n87 = reshape(n86, shape=[192, 64])
n88 = const(dtype="int", value=[0, 64, 64, 64, 128])
n89 = add(n88, n73)
n90 = take(n87, n89, axis=0)
n91 = transpose(n10)
n92 = take(n91, n73, axis=0)
n93 = sub(n90, n92)
n94 = transpose(n11)
n95 = take(n94, n73, axis=0)
n96 = reshape(n95, shape=[5, 4, 1])
n97 = reshape(n11, shape=[1, 4, 64])
n98 = sub(n96, n97)
n99 = reshape(n98, shape=[20, 64])
n100 = const(dtype="int", value=[1, 6, 10, 14, 19])
n101 = take(n99, n100, axis=0)
n102 = slice(n98, index=[null, {"start": null, "step": null, "stop": 3}, null])
n103 = reshape(n101, shape=[5, 1, 64])
n104 = sub(n102, n103)
n105 = min(n90, axis=1)
n106 = reshape(n105, shape=[5, 1])
n107 = sub(n106, n81)
n108 = min(n93, axis=1)
n109 = reshape(n108, shape=[5, 1])
n110 = sub(n109, n85)
n111 = min(n92, axis=1)
n112 = reshape(n111, shape=[5, 1])
n113 = max(n10, axis=0)
n114 = reshape(n113, shape=[1, 64])
n115 = sub(n112, n114)
n116 = min(n76, axis=2)
n117 = reshape(n116, shape=[5, 3, 1])
n118 = max(n75, axis=2)
n119 = reshape(n118, shape=[5, 3, 1])
n120 = sum(n75, axis=1)
n121 = const(dtype="float", value=1.0)
n122 = add(n121, n120)
n123 = const(dtype="float", value=1e-09)
n124 = mul(n122, n123)
n125 = add(n110, n115)
n126 = reshape(n125, shape=[5, 1, 64])
n127 = add(n126, n104)
n128 = mul(n117, n127)
n129 = mul(n119, n127)
n130 = minimum(n128, n129)
n131 = sum(n130, axis=1)
n132 = add(n107, n131)
n133 = max(n124, axis=null)
n134 = sub(n132, n133)
n135 = const(dtype="float", value=0.0)
n136 = ge(n134, n135)
n137 = cast(n136, dtype="int")
n138 = const(dtype="int", value=[1, 2, 3])
n139 = take_sum(n137, n138, axis=0)
n140 = slice(n137, index=[{"start": 0, "step": null, "stop": 1}])
n141 = const(dtype="int", value=1)
n142 = minimum(n139, n141)
n143 = reshape(n142, shape=[1, 64])
n144 = slice(n137, index=[{"start": 4, "step": null, "stop": 5}])
n145 = concat(n140, n143, n144, axis=0)
n146 = argsort(n145, axis=1)
n147 = slice(n146, index=[null, {"start": null, "step": null, "stop": 16}])
n148 = sum(n145, axis=1)
n149 = const(dtype="int", value=48)
n150 = ge(n148, n149)
n151 = reshape(n150, shape=[3, 1, 1])
n152 = take(n147, n74, axis=0)
n153 = reshape(n88, shape=[5, 1])
n154 = add(n153, n152)
n155 = take(n87, n154, axis=0)
n156 = transpose(n155, perm=[0, 2, 1])
n157 = take(n91, n152, axis=0)
n158 = transpose(n157, perm=[0, 2, 1])
n159 = reshape(n90, shape=[5, 64, 1])
n160 = sub(n159, n156)
n161 = reshape(n92, shape=[5, 64, 1])
n162 = sub(n161, n158)
n163 = reshape(n104, shape=[960])
n164 = const(dtype="int", value=[[[0], [64], [128]], [[192], [256], [320]], [[384], [448]...)
n165 = reshape(n152, shape=[5, 1, 16])
n166 = add(n164, n165)
n167 = take(n163, n166, axis=0)
n168 = sub(n160, n162)
n169 = min(n162, axis=1)
n170 = reshape(n169, shape=[5, 1, 16])
n171 = add(n168, n170)
n172 = reshape(n171, shape=[5, 1, 64, 16])
n173 = slice(n167, index=[null, {"start": null, "step": null, "stop": 2}])
n174 = reshape(n173, shape=[5, 2, 1, 16])
n175 = add(n172, n174)
n176 = slice(n76, index=[null, {"start": null, "step": null, "stop": 2}])
n177 = reshape(n176, shape=[5, 2, 64, 1])
n178 = mul(n177, n175)
n179 = slice(n75, index=[null, {"start": null, "step": null, "stop": 2}])
n180 = reshape(n179, shape=[5, 2, 64, 1])
n181 = mul(n180, n175)
n182 = minimum(n178, n181)
n183 = sum(n182, axis=1)
n184 = slice(n171, index=[{"start": 4, "step": null, "stop": 5}])
n185 = slice(n167, index=[{"start": 4, "step": null, "stop": 5}, 2])
n186 = reshape(n185, shape=[1, 1, 16])
n187 = add(n184, n186)
n188 = slice(n76, index=[{"start": 4, "step": null, "stop": 5}, 2])
n189 = reshape(n188, shape=[1, 64, 1])
n190 = mul(n189, n187)
n191 = slice(n75, index=[{"start": 4, "step": null, "stop": 5}, 2])
n192 = reshape(n191, shape=[1, 64, 1])
n193 = mul(n192, n187)
n194 = minimum(n190, n193)
n195 = slice(n183, index=[{"start": 0, "step": null, "stop": 4}])
n196 = slice(n183, index=[{"start": 4, "step": null, "stop": 5}])
n197 = add(n196, n194)
n198 = concat(n195, n197, axis=0)
n199 = add(n160, n198)
n200 = reshape(n124, shape=[5, 64, 1])
n201 = sub(n199, n200)
n202 = ge(n201, n135)
n203 = slice(n202, index=[{"start": 0, "step": null, "stop": 1}])
n204 = slice(n202, index=[{"start": 1, "step": null, "stop": 2}])
n205 = slice(n202, index=[{"start": 2, "step": null, "stop": 3}])
n206 = or(n204, n205)
n207 = slice(n202, index=[{"start": 3, "step": null, "stop": 4}])
n208 = or(n206, n207)
n209 = slice(n202, index=[{"start": 4, "step": null, "stop": 5}])
n210 = concat(n203, n208, n209, axis=0)
n211 = and(n210, n151)
n212 = cast(n211, dtype="int")
n213 = sum(n212, axis=2)
n214 = const(dtype="int", value=16)
n215 = sub(n214, n213)
n216 = argsort(n212, axis=2)
n217 = const(dtype="int", value=[[[0]], [[16]], [[32]]])
n218 = add(n217, n216)
n219 = eq(n215, n141)
n220 = neg(n215)
n221 = token(i=0)
n222 = token(i=1)
n223 = token(i=2)
n224 = token(i=3)
n225 = slice(n60, index=[0])
n226 = argmax(n225, axis=1)
n227 = reshape(n10, shape=[1, 64, 64])
n228 = reshape(n11, shape=[4, 1, 64])
n229 = add(n227, n228)
n230 = const(dtype="int", value=448)
n231 = mul(n147, n230)
n232 = reshape(n231, shape=[48])
n233 = take(n232, n218, axis=0)
n234 = slice(n233, index=[null, null, 0])
n235 = floordiv(n234, n230)
n236 = where(n219, n235, n220)
n237 = tokens()
n238 = transpose(n229, perm=[2, 0, 1])
n239 = transpose(n61, perm=[2, 0, 1])
n240 = concat(n238, n239, axis=1)
n241 = reshape(n240, shape=[28672])
n242 = const(dtype="float", value=[1.0])
n243 = mul(n37, n230)
n244 = reshape(n243, shape=[1, 64])
n245 = const(dtype="int", value=0)
n246 = mul(n37, n245)
n247 = reshape(n246, shape=[1, 64])
n248 = slice(n236, index=[0])
n249 = reshape(n248, shape=[64, 1])
n250 = add(n249, n247)
n251 = reshape(n226, shape=[1, 64])
n252 = concat(n250, n251, axis=0)
n253 = slice(n236, index=[2])
n254 = reshape(n253, shape=[64, 1])
n255 = add(n254, n247)
n256 = slice(n236, index=[1])
n257 = reshape(n256, shape=[1, 64])
n258 = concat(n255, n257, axis=0)
n259 = gather(n252, n222, n221, axes=[0, 1])
n260 = gather(n258, n224, n223, axes=[0, 1])
n261 = ge(n259, n245)
n262 = slice(n31, index=[0])
n263 = gather(n262, n222, n221, axes=[0, 1])
n264 = slice(n35, index=[0, 0])
n265 = gather(n264, n222, axes=[0])
n266 = add(n263, n265)
n267 = slice(n44, index=[0])
n268 = gather(n267, n222, axes=[0])
n269 = stack(n266, n268, axis=0)
n270 = softmax(n269, axis=0)
n271 = slice(n270, index=[{"start": null, "step": null, "stop": 1}])
n272 = slice(n270, index=[{"start": 1, "step": null, "stop": null}])
n273 = sub(n272, n121)
n274 = concat(n271, n273, n242, axis=0)
n275 = slice(n237, index=[{"start": null, "step": null, "stop": 2}])
n276 = slice(n237, index=[{"start": 1, "step": null, "stop": 2}])
n277 = concat(n275, n276, axis=0)
n278 = const(dtype="int", value=[0, 64, 256])
n279 = add(n277, n278)
n280 = reshape(n279, shape=[3, 1])
n281 = add(n280, n244)
n282 = take(n241, n281, axis=0)
n283 = matmul(n274, n282)
n284 = argmax(n283, axis=null)
n285 = const(dtype="int", value=-3)
n286 = ge(n259, n285)
n287 = slice(n233, index=[0])
n288 = slice(n287, index=[null, {"start": null, "step": null, "stop": 3}])
n289 = gather(n288, n222, axes=[0])
n290 = reshape(n289, shape=[1, 3])
n291 = add(n280, n290)
n292 = take(n241, n291, axis=0)
n293 = matmul(n274, n292)
n294 = argmax(n293, axis=null)
n295 = gather(n289, n294, axes=[0])
n296 = floordiv(n295, n230)
n297 = cond(n286, n296, n284)
n298 = cond(n261, n259, n297)
n299 = ge(n260, n245)
n300 = const(dtype="int", value=64)
n301 = eq(n224, n300)
n302 = slice(n31, index=[1])
n303 = gather(n302, n223, n221, axes=[0, 1])
n304 = slice(n35, index=[1, 0])
n305 = gather(n304, n223, axes=[0])
n306 = add(n303, n305)
n307 = gather(n302, n223, n222, axes=[0, 1])
n308 = slice(n35, index=[1, 1])
n309 = gather(n308, n223, axes=[0])
n310 = add(n307, n309)
n311 = slice(n44, index=[1])
n312 = gather(n311, n223, axes=[0])
n313 = stack(n306, n310, n312, axis=0)
n314 = softmax(n313, axis=0)
n315 = slice(n314, index=[{"start": null, "step": null, "stop": 2}])
n316 = slice(n314, index=[{"start": 2, "step": null, "stop": null}])
n317 = sub(n316, n121)
n318 = concat(n315, n317, n242, axis=0)
n319 = slice(n237, index=[{"start": null, "step": null, "stop": 3}])
n320 = slice(n237, index=[{"start": 2, "step": null, "stop": 3}])
n321 = concat(n319, n320, axis=0)
n322 = const(dtype="int", value=[0, 64, 128, 320])
n323 = add(n321, n322)
n324 = reshape(n323, shape=[4, 1])
n325 = add(n324, n244)
n326 = take(n241, n325, axis=0)
n327 = matmul(n318, n326)
n328 = argmax(n327, axis=null)
n329 = const(dtype="int", value=-5)
n330 = ge(n260, n329)
n331 = slice(n233, index=[1])
n332 = slice(n331, index=[null, {"start": null, "step": null, "stop": 5}])
n333 = gather(n332, n223, axes=[0])
n334 = reshape(n333, shape=[1, 5])
n335 = add(n324, n334)
n336 = take(n241, n335, axis=0)
n337 = matmul(n318, n336)
n338 = argmax(n337, axis=null)
n339 = gather(n333, n338, axes=[0])
n340 = floordiv(n339, n230)
n341 = cond(n330, n340, n328)
n342 = const(dtype="int", value=-2)
n343 = ge(n260, n342)
n344 = slice(n331, index=[null, {"start": null, "step": null, "stop": 2}])
n345 = gather(n344, n223, axes=[0])
n346 = reshape(n345, shape=[1, 2])
n347 = add(n324, n346)
n348 = take(n241, n347, axis=0)
n349 = matmul(n318, n348)
n350 = argmax(n349, axis=null)
n351 = gather(n345, n350, axes=[0])
n352 = floordiv(n351, n230)
n353 = cond(n343, n352, n341)
n354 = slice(n31, index=[2])
n355 = gather(n354, n224, n221, axes=[0, 1])
n356 = slice(n35, index=[2, 0])
n357 = gather(n356, n224, axes=[0])
n358 = add(n355, n357)
n359 = gather(n354, n224, n222, axes=[0, 1])
n360 = slice(n35, index=[2, 1])
n361 = gather(n360, n224, axes=[0])
n362 = add(n359, n361)
n363 = gather(n354, n224, n223, axes=[0, 1])
n364 = slice(n35, index=[2, 2])
n365 = gather(n364, n224, axes=[0])
n366 = add(n363, n365)
n367 = slice(n44, index=[2])
n368 = gather(n367, n224, axes=[0])
n369 = stack(n358, n362, n366, n368, axis=0)
n370 = softmax(n369, axis=0)
n371 = slice(n370, index=[{"start": null, "step": null, "stop": 3}])
n372 = slice(n370, index=[{"start": 3, "step": null, "stop": null}])
n373 = sub(n372, n121)
n374 = concat(n371, n373, n242, axis=0)
n375 = slice(n237, index=[{"start": null, "step": null, "stop": 4}])
n376 = slice(n237, index=[{"start": 3, "step": null, "stop": 4}])
n377 = concat(n375, n376, axis=0)
n378 = const(dtype="int", value=[0, 64, 128, 192, 384])
n379 = add(n377, n378)
n380 = reshape(n379, shape=[5, 1])
n381 = add(n380, n244)
n382 = take(n241, n381, axis=0)
n383 = matmul(n374, n382)
n384 = argmax(n383, axis=null)
n385 = slice(n233, index=[2])
n386 = slice(n385, index=[null, {"start": null, "step": null, "stop": 2}])
n387 = gather(n386, n224, axes=[0])
n388 = reshape(n387, shape=[1, 2])
n389 = add(n380, n388)
n390 = take(n241, n389, axis=0)
n391 = matmul(n374, n390)
n392 = argmax(n391, axis=null)
n393 = gather(n387, n392, axes=[0])
n394 = floordiv(n393, n230)
n395 = cond(n343, n394, n384)
n396 = cond(n301, n353, n395)
n397 = cond(n299, n260, n396)
n398 = eq(n223, n300)
n399 = cond(n398, n298, n397)   <- interpretation
```

## The baseline

This is a baseline run: its networks are those of a baseline model, for the shape of att-c, att-d. Its agent was given what a run on those is given, and asked for an entry exact for any weights of the design. What it achieved is generic; runs of that shape are read against it.

Frozen: r3s2 (`v3g`), sha256 `4728510ff7f407dd`, chosen as the highest reward on the second network, of the entries exact there, that passes the check, trying up to 3 different entries in that order (every submission is scored on the second network on one fixed sample) (0.9735 on att-e-s1). Scored again on the model's other networks, all on one fresh sample (seed 5990860670326728554):

| Network | Reward | With its sampling interval | Coverage | Fidelity | Wrong | Cost | Build part | Per input |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| att-e-s2 | 0.9854 | 0.9854 to 0.9877 | 1.0000 | 1.00000 | 0 | 0.0123 | 0.0052 | 0.0070 |
| att-e-s3 | 0.9775 | 0.9775 to 0.9798 | 1.0000 | 1.00000 | 0 | 0.0202 | 0.0052 | 0.0150 |
| att-e-s4 | 0.9899 | 0.9899 to 0.9922 | 1.0000 | 1.00000 | 0 | 0.0078 | 0.0052 | 0.0026 |
| att-e-s5 | 0.9900 | 0.9900 to 0.9923 | 1.0000 | 1.00000 | 0 | 0.0077 | 0.0052 | 0.0024 |

Verdict (the network's output on every input of its region on every other network): **passes**: it gave the network's output on every input of its region on all 4 networks.

## Reference entries

Scored here for comparison. They are withheld from the agent. Each number is the mean of 8 scorings on fixed samples. The task: Untrained. The networks were never trained: each is the state att-d's trainer starts from, drawn and kept as drawn. A model for the baseline of the shape it shares with att-c, att-d: a run on it is a usual run in everything the agent is given (the same prompt, sizes, data set, rounds, budgets and reward), with nothing learned to find, so what the agent achieves here is generic. Its networks behave like none of the trained ones; whatever regularity a run finds in one of them is an accident of that network, which its other networks show up.


| Entry | Network | Reward | Coverage | Fidelity | Cost | Reward, highest less lowest |
| --- | --- | --- | --- | --- | --- | --- |
| the network itself | att-e-s0 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| the network itself | att-e-s1 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| one_token_table_then_network | att-e-s0 | 0.2483 | 1.0000 | 1.00000 | 0.7494 | 0.0086 |
| one_token_table_then_network | att-e-s1 | 0.2483 | 1.0000 | 1.00000 | 0.7494 | 0.0086 |
| tables | att-e-s0 | 0.9548 | 1.0000 | 1.00000 | 0.0428 | 0.0005 |
| tables | att-e-s1 | 0.9548 | 1.0000 | 1.00000 | 0.0428 | 0.0005 |

## Rounds

| Round | Submissions | Best reward so far | Raised it | Ended with | Tool calls | Minutes | Output tokens | Programs run | Sandbox minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 3 | 0.9790 | yes | end_turn | 15 run_python, 3 submit_entry | 10.8 | 41,174 | 15 | 1.2 |
| 2 | 3 | 0.9904 | yes | end_turn | 29 run_python, 3 submit_entry | 18.6 | 81,831 | 29 | 1.0 |
| 3 | 2 | 0.9909 | yes | end_turn | 33 run_python, 2 submit_entry | 40.7 | 184,688 | 33 | 2.7 |
| 4 | 3 | 0.9918 | yes | end_turn | 33 run_python, 3 submit_entry | 38.0 | 181,773 | 33 | 2.0 |
| 5 | 4 | 0.9922 | yes | end_turn | 21 run_python, 4 submit_entry | 24.8 | 90,815 | 21 | 3.8 |

The rounds were billed to an API key: $41.63 by Claude Code's count.

## What the agent ran

Every program is kept in full in its round's `session/python/` folder, with what it got back; the round's `response.md` has what the agent wrote, and `stream_NN.jsonl` everything the CLI emitted.

The guard inside Python refused nothing: no program tried to reach files outside its folder, the network or other programs.

Programs whose text reaches for files or the system. A match is a reason to read the program, not a verdict:

- `round_003/session/python/003.py`: eval or exec, open(, os.
- `round_003/session/python/004.py`: eval or exec, open(
- `round_003/session/python/005.py`: eval or exec
- `round_003/session/python/006.py`: eval or exec
- `round_003/session/python/007.py`: eval or exec
- `round_003/session/python/009.py`: eval or exec
- `round_003/session/python/014.py`: eval or exec
- `round_003/session/python/015.py`: eval or exec
- `round_003/session/python/016.py`: eval or exec
- `round_003/session/python/018.py`: eval or exec
- `round_003/session/python/019.py`: eval or exec
- `round_003/session/python/020.py`: eval or exec
- `round_003/session/python/021.py`: eval or exec
- `round_003/session/python/024.py`: eval or exec
- `round_003/session/python/025.py`: eval or exec
- `round_003/session/python/026.py`: eval or exec
- `round_003/session/python/027.py`: eval or exec
- `round_003/session/python/029.py`: eval or exec
- `round_003/session/python/030.py`: eval or exec
- `round_003/session/python/031.py`: eval or exec
- `round_003/session/python/033.py`: eval or exec
- `round_004/session/python/008.py`: eval or exec
- `round_004/session/python/009.py`: eval or exec
- `round_004/session/python/010.py`: eval or exec
- `round_004/session/python/011.py`: eval or exec
- `round_004/session/python/012.py`: eval or exec
- `round_004/session/python/014.py`: eval or exec
- `round_004/session/python/015.py`: eval or exec
- `round_004/session/python/016.py`: eval or exec
- `round_004/session/python/017.py`: eval or exec
- `round_004/session/python/019.py`: eval or exec
- `round_004/session/python/020.py`: eval or exec, open(
- `round_004/session/python/021.py`: eval or exec
- `round_004/session/python/022.py`: eval or exec
- `round_004/session/python/023.py`: eval or exec
- `round_004/session/python/026.py`: eval or exec
- `round_004/session/python/027.py`: eval or exec
- `round_004/session/python/028.py`: eval or exec
- `round_004/session/python/031.py`: eval or exec, open(

## Submissions

Cost: everything the entry computes, per input of its region, over one forward pass. Right and wrong: the share of the inputs the entry answers rightly and wrongly. On the frontier: no other submission is at least as good in right share, wrong share and cost, and better in one. On the second network: the reward and the fidelity of the same entry on the seed check's network, every submission on one fixed sample, scored after its round; the agent never saw these, and they chose nothing.

| Entry | Saved as | Reward | Coverage | Fidelity | Cost | Right | Wrong | On the frontier | Claimed | Overclaim | On the second network | Fidelity there |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | `tables_v1` | 0.9561 | 1.0000 | 1.00000 | 0.0415 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9559 | 1.00000 |
| r1s2 | `pruned_v2` | 0.9733 | 1.0000 | 1.00000 | 0.0244 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9647 | 1.00000 |
| r1s3 | `pruned_v3` | 0.9790 | 1.0000 | 1.00000 | 0.0187 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9704 | 1.00000 |
| r2s1 | `v2c` | 0.9901 | 1.0000 | 1.00000 | 0.0076 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9458 | 1.00000 |
| r2s2 | `v2f` | 0.9904 | 1.0000 | 1.00000 | 0.0073 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9461 | 1.00000 |
| r2s3 | `v2h` | 0.9904 | 1.0000 | 1.00000 | 0.0073 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9462 | 1.00000 |
| r3s1 | `v3d` | 0.9908 | 1.0000 | 1.00000 | 0.0068 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9682 | 1.00000 |
| r3s2 | `v3g` | 0.9909 | 1.0000 | 1.00000 | 0.0068 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9735 | 1.00000 |
| r4s1 | `v4e` | 0.9916 | 1.0000 | 1.00000 | 0.0061 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9672 | 1.00000 |
| r4s2 | `v4h` | 0.9917 | 1.0000 | 1.00000 | 0.0059 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9672 | 1.00000 |
| r4s3 | `v4i_W16_2_nosp` | 0.9918 | 1.0000 | 1.00000 | 0.0058 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9672 | 1.00000 |
| r5s1 | `v5_2_5` | 0.9921 | 1.0000 | 1.00000 | 0.0056 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9672 | 1.00000 |
| r5s2 | `v5c_2_3_5_11` | 0.9922 | 1.0000 | 1.00000 | 0.0055 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9559 | 1.00000 |
| r5s3 | `v5d_2_5_11` | 0.9922 | 1.0000 | 1.00000 | 0.0054 | 1.0000 | 0.00000 | yes | 1.00000 | 0.00000 | 0.9561 | 1.00000 |
| r5s4 | `v5d_2_5_11` | 0.9922 | 1.0000 | 1.00000 | 0.0055 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.9561 | 1.00000 |

On the second network the best submission was r3s2 (`v3g`), 0.9735; the locked entry, r5s3, scored 0.9561 there on the same sample.

## The agent's closing notes

> ## What the network does
> Same finding as rounds 1–4, re-confirmed: a 1-layer, 1-head attention-only transformer with highly degenerate outputs (n=1 → mostly 40/47; n=2 → 16 on ~97%; n=3 → mostly 36/46/63; n=4 → 4 on ~97%) and nearly uniform attention. No semantic token rule; the exact computation is logits = U_r[j,:] + Σ_s w_s·T[s,t_s,:], U=(E+P)@Unembed, T=(E+P)@V@O@Unembed, w = softmax of (E_j+P_r)M(E_t+P_i)ᵀ, M=WqWkᵀ/√32. New exact fact used this round: with Z_r = U_r + T_r, logits = Z_r[j] + Σ_{i<r} w_i T_i(t_i) + (w_r − 1)·T_r(j), so the K-candidate path needs no U table (weights (w_0..w_{r−1}, w_r−1, 1) on rows (T_0..T_r, Z_r)). Also checked: the separable per-slot dominance bound with 3 reference outputs is already at its maximum for this bound (34/64 single-candidate tokens at n=3 with any references vs 33 used), and Cauchy–Schwarz/mean-centred bounds on the embedding part are far too loose (28–53 coarse survivors vs 4–15 exact), so the three 64×64×32 tables (≈627k ops) are a genuine floor. Certainty: exact — fidelity 1 on every verifier sample (4 × 16,384), all 64 n=1 and 4,096 n=2 inputs, 12,000 random n=3/4 inputs, and on gaussian (0.1–20), ±2 integer, zero, 3–50 %-perturbed, 6×-sharper query, 3×-key, 8×-value, duplicate-unembed-column, negated-unembed, zero-pos and ×1e-3 weight sets.
> 
> ## How you found it
> Both weights and outputs. Decompiled the round-4 JSON (`best`, 395 nodes) node by node (printed the whole node list) and measured its per-n cost with `lv1.measure` on inputs of fixed n (5 / 10.2 / 46.3 / 17.8 ops per input for n=1..4) and on single read tokens (single-candidate 7 ops, n=3 K=2 path 59, K=5 path 103). Found that `lv1.softmax` costs 3 per entry, that a gather of a row of a (64,16) table costs 16, and that the build is lazy (branches never taken never build their tables: n=1-only inputs build 260k instead of 907k), which makes the exact 64-wide fallback free on this network. Rebuilt only the per-input part (and small build pieces) on top of the loaded build nodes by re-adding the saved nodes with `g._add` and substituting my own nodes at chosen indices.
> 
> ## The best entry
> `v5best` (= `v5d_2_5_11`, scored 0.99223 and 0.99220; `v5c_2_3_5_11` 0.99217; `v5_2_5` 0.99205). Region: every input. Build (892k ops, 0.0042): round-4 tables and dominance machinery unchanged except: reference outputs via one argsort of column sums (−12 nodes), fine pass split by slot (slots 0–1 batched over all 5 (r,c) pairs, slot 2 only for the r=3 pair, segmented sum via slices/concat: −20k ops), coarse pair→r combination via `take_sum`, candidate table stored as k·448 offsets, a k-major flat table TK[k, slot, t] = (T_0..T_3, Z_1..Z_3) (64×7×64), and two (65×64) dispatch tables code12[t1,t0] (n=1 answers in row 64, n=2 codes elsewhere) and code34[t3,t2] (n=3 codes in row 64, n=4 codes elsewhere). Per input (16.0 ops avg, 0.0012): `cond(t2==64, …)` then ONE 2-D gather of the code, `cd>=0` → answer (5 ops for ~80 % of inputs, incl. n=1); otherwise K-candidate path: r score gathers + softmax, weight vector (w[:r], w[r]−1, 1), offsets (tokens + const), index = off[:,None] + cand_offsets[None,:], one flat take of (r+2)·K entries, (1×(r+2))@((r+2)×K), argmax, offset//448 (n=3 K=2: 53 ops, K=5: 99; n=4 K=2: 68; n=2 K=3: 54); else the exact 64-wide fallback via the same TK (never fires here). 400 nodes, 86 constants (index bookkeeping only).
> 
> ## Claims
> Claimed 1.0 on this network and expected 1.0 on the second: the entry is an exact table re-implementation plus the provably sound round-4 pruning (unchanged bound, only re-batched), with an exact fallback for anything unproven; verified bit-for-bit on 16 weight sets including degenerate/tie cases. Only cost differs on another seed (r=2 coarse survivors are 15 of W=16 here; an overflow there sends n=3 inputs to the exact fallback, ≈0.0135 cost, fidelity unaffected).
> 
> ## Next
> Remaining gain is ≤ ~0.0001 and node-bound (400/400): (1) a K=3 path for n=3 (+0.00005) needs 11 nodes — the only zero-op node savings found were ~5 (Spos transposed per r); (2) full slot split of the fine pass (−5k more) needs ~15 nodes; (3) the ρ-form (exp(s_i−s_r)) saves 3–4 ops per K-path but risks exp overflow on extreme weights — rejected; (4) per-(j,t0) refinement for n=3, pairwise sign tests for 2-candidate tokens, Cauchy–Schwarz coarse bounds, and W<16 all cost more than they save. The 627k table floor plus the fixed 0.0023 CI penalty cap the reward near 0.9925.
