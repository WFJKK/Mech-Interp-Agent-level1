# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 3 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx slots. A slot holds a token, a whole number from 0 to d_vocab - 1, or it is empty,
which is written as the number d_vocab. An input has at least one token; its tokens fill the first
slots and the empty slots come after them.

The network is a transformer with one layer, one attention head and no MLP, no layer norm and no biases.
Its weights:

    embed     (d_vocab + 1) x d_model   a row per token; the last row, an empty slot's, is all zeros
    pos       n_ctx x d_model            a row per slot
    query     d_model x d_head
    key       d_model x d_head
    value     d_model x d_head
    out       d_head x d_model
    unembed   d_model x d_vocab

Each slot's vector is its token's row of embed plus its own row of pos. The network is read at the slot of
the last token given: that slot's vector times query, divided by the square root of d_head, is scored
against every given slot's vector times key (a dot product per slot; empty slots take no part); the softmax
of the scores weights the given slots' vectors times value; the sum, times out, is added to the read slot's
vector; that times unembed gives d_vocab numbers, and the output is the position of the highest (the first
one on a tie).
"""

import math


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    t = g.tokens()
    embed, pos = g.weight("embed"), g.weight("pos")
    n_ctx, empty = pos.shape[0], embed.shape[0] - 1
    x = lv1.take(embed, t, axis=0) + pos                     # a vector per slot
    n = (t != empty).sum()                                    # the number of tokens given
    read = x[n - 1]                                           # the slot of the last token given
    q = (read @ g.weight("query")) * (1 / math.sqrt(g.weight("query").shape[1]))
    scores = (x @ g.weight("key")) @ q
    scores = lv1.where(g.arange(n_ctx) < n, scores, -1e30)    # empty slots take no part
    head = lv1.softmax(scores) @ (x @ g.weight("value"))
    logits = (read + head @ g.weight("out")) @ g.weight("unembed")
    return logits.argmax()
```

Sizes: n_ctx = 4, d_vocab = 64, d_model = 32, d_head = 32, outputs: 64. One forward pass of the network costs 12,987 operations under the prices
below.

## The data set

An input is drawn like this. First a number of tokens is picked from 1, 2, 3 and 4, each equally likely. Then that many tokens are picked, each a whole number from 0 to 63 and equally likely. The tokens fill the first slots and the remaining slots are empty (64). The data set is every input that can be drawn this way, each counted as often as it is drawn: about 17 million different inputs, most of them filling every slot, yet every number of tokens makes up a quarter of the data set.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

This run asks one more thing of an entry: that it be exact whatever the weights. When the rounds are
over, the entries are also run, unchanged, on several other networks of the same definition and sizes,
with other weights, and an entry counts only if it gives each network's output on every input of its
region that is checked there. So whatever depends on the weights has to be computed from the weights
inside the entry, and every shortcut has to hold for any weights: a rule that holds only for this
network makes the entry fail on the others.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.9561 | 1.0000 | 1.00000 | 0.0415 | 1.00000 | 1.00000 |
| r1s2 | scored | 0.9733 | 1.0000 | 1.00000 | 0.0244 | 1.00000 | 1.00000 |
| r1s3 | scored | 0.9790 | 1.0000 | 1.00000 | 0.0187 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    The network is a 1-layer, 1-head attention-only transformer with no clear simple rule in its outputs: no candidate (last/first/max/min/sum/difference/product of tokens, etc.) matched more than ~5% of outputs. Its outputs are highly concentrated: for n=2 tokens it answers 16 on ~97% of inputs, for n=4 it answers 4 on ~97%, for n=1 mostly 40 or 47 (and 62, 25 for a few tokens). For the read slot's token, the logits are dominated by the direct path (`embed+pos` → `unembed`), and the attention term only adjusts a few outputs. I did not identify a "task"; I instead characterised the computation exactly: logits = U[read row] + Σ_i w_i·T[slot i, token i], with U = (embed+pos)@unembed, T = (embed+pos)@value@out@unembed, and w the softmax of a precomputed score table. Certainty: exact (fidelity 1 on all 16,384 verifier inputs, all 64 n=1 inputs, all 4,096 n=2 inputs, 16,000 random n=3/4 inputs, and on 8 other weight sets including zeros, integer weights, random gaussians of several scales and perturbed copies).
    
    ## How you found it
    Looked at both outputs and weights. Ran `network_outputs()` to test simple token rules (none matched) and output histograms (very few dominant classes). Then wrote the forward pass in table form from the weights (position-and-token tables U, T, and per-read-slot score tables S), verified it against `model.reference` via `lv1.run_reference`/`lv1.measure` on exhaustive and random inputs and on random/degenerate weight sets passed to `lv1.measure`. Then found that sound per-read-token candidate sets (upper bound U_j + max_c T_cj vs. lower bound max_k(U_k + min_c T_ck), with c over rows of the non-read slots plus the exact read row) prune 64 outputs to ≤5 (n=2), ≤18 (n=3, mean 11), ≤12 (n=4, mean 6) on this network, and to a single output for 25/64 last tokens at n=2.
    
    ## The best entry
    Name: `pruned_v3` (saved; also `pruned_v2` 0.973 and `tables_v1` 0.956). Region: every input (coverage 1). Interpretation: computes n from the tokens, then branches with `lv1.cond`: n=1 → 64-entry table built from the weights; n=2,3,4 → gather the nn attention scores from build-time score tables (S2a/S2d, S3, S4 = Q_slot @ K.T), softmax them, then—if the build-time candidate count for the last token is 1—answer that candidate directly; if ≤K (K2=6, K3=14, K4=8) compute logits only on the K candidates (2-D gathers from flattened T and U, a (1×nn)@(nn×K) matmul, argmax, map back); otherwise fall back to the full 64-wide computation. Everything is computed from the weights inside the entry, and the fallback keeps it exact for any weights. Cost 0.0187 (build 0.0088 ≈ 1.9M ops amortised over 16,384 inputs; per-input ≈ 127 ops on average), fidelity 1, reward 0.979 (the 95% lower CI costs ~0.0023).
    
    ## Claims
    Claimed fidelity 1.0 on this network, expected 1.0 on the second network: the entry is an exact re-implementation (only floating-point re-association differs, which matters only at exact logit ties), the candidate pruning is a sound bound with an exact fallback, and it was verified bit-for-bit on random, zero, integer and perturbed weights. On the second network only the cost may differ (its candidate sets may be larger, triggering more fallbacks).
    
    ## Next
    Gains left are small (~0.002–0.004): (1) tighter pairwise candidate bounds D[j,k] = U_j−U_k + max_c(T_cj−T_ck) could make the count==1 shortcut fire far more often, but a naive build costs ~3M ops (~195 ops/input) — worth it only if restricted cheaply to the first-stage candidates; (2) tune K2/K3/K4 by measured cost (K3=15/K4=9 cost +0.0003 here but are safer if the other seed has larger candidate sets); (3) trim the score-table build (S3/S4 ≈ 0.95M ops) if a cheaper exact way to get the 3–4 scores per input exists; (4) do not spend effort on n=3 lookup tables (build too costly) or on reading a "task" rule — the network's outputs are too degenerate for a semantic rule to be exact.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.9901 | 1.0000 | 1.00000 | 0.0076 | 1.00000 | 1.00000 |
| r2s2 | scored | 0.9904 | 1.0000 | 1.00000 | 0.0073 | 1.00000 | 1.00000 |
| r2s3 | scored | 0.9904 | 1.0000 | 1.00000 | 0.0073 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Same finding as round 1, now confirmed and exploited further: a 1-layer, 1-head attention-only transformer whose outputs are highly degenerate (n=1 → mostly 40/47; n=2 → 16 on ~97%; n=3 → 46/36/63 (37/32/28%); n=4 → 4 on ~97%). No semantic token rule; the exact computation is logits = U[r, j, :] + Σ_i w_i · T[i, t_i, :], with U = (embed+pos)@unembed, T = (embed+pos)@value@out@unembed, w = softmax of scores S[r, i, j, t] = (E_j+P_r) M (E_t+P_i)ᵀ, M = Wq Wkᵀ/√32 (r = read slot = n−1, j = last token). The key new fact: for each read token j, a sound build-time dominance bound (see below) proves a single output for 61/64 tokens at n=2, 55/64 at n=4 and 21/64 at n=3 (33/64 with 3 reference outputs), so most inputs need no attention computation at all. Certainty: exact — fidelity 1 on all verifier samples (3 submissions × 16,384), all 64 n=1 and all 4,096 n=2 inputs, ~20k random n=3/4 inputs, and on 15+ other weight sets (gaussian scales 0.1–100, integer, {−1,0,1}, zeros, perturbed, duplicate unembed columns, 1e-3-scaled).
    
    ## How you found it
    Both weights and outputs. Rebuilt the round-1 table formulation, then (1) decomposed the score tables as EME + EMP + PME + PMP (M = WqWkᵀ/√32) instead of per-read-slot Q·Kᵀ tables (build 1.2M → 0.3M ops); (2) replaced the UB/LB candidate test by pairwise dominance against a few fixed reference outputs c (constants chosen for cost only; soundness holds for any weights): logit_c − logit_k ≥ Ud + d_r + Σ_{i<r} (D_i − d_r)·(hi_i if D_i<d_r else lo_i), where d_r is the read slot's exact row difference, D_i = min_t(T[i,t,c]−T[i,t,k]), and lo_i/hi_i are bounds on attention weight w_i from min/max over t of exp(score) (read slot's score exact). This is weak LP duality with λ = d_r, which kills the read-slot term; numerically it was as tight as the exact box-constrained LP. NaN-safe (overflowing exp → “not dominated”), eps = 1e-9 margin (logits are O(0.5)). Candidate counts per read token: n=2 hist [61,2,1], n=3 [21,23,14,5,1] (2 c's), n=4 [55,9]. Verified with lv1.run_reference/lv1.measure on many weight sets.
    
    ## The best entry
    `v2f` (reward 0.99038; `v2h` identical up to sample noise, 0.99036; `v2c` 0.99006). Region: every input (coverage 1). Interpretation: branch on n via t[1..3]==64 conds; n=1 → 64-entry table argmax(U[0]+T[0]); n=2,3,4 → gather cnt[j] from the build-time dominance tables; if 1 candidate → answer it directly (~4 ops); if ≤K (K=3 / {2,5} / 2) → gather the n attention scores from the assembled S table, softmax, compute logits only on the K candidates (flattened-table gathers + (1×n)@(n×K) matmul), argmax; else exact full 64-wide fallback (never fires on this network, keeps exactness for any weights). Cost 0.0073: build 1.17M ops (0.0055; tables EME/T/U ≈ 640k are the floor, dominance ≈ 290k, argsort/argmax ordering ≈ 74k), per-input ≈ 23 ops (0.0018). 396/400 nodes, 15 constants.
    
    ## Claims
    Claimed 1.0 on this network, expected 1.0 on the second: the entry is an exact re-implementation plus provably sound pruning (dominance bounds use only valid per-term bounds on the softmax weights and row differences, the fallback is exact), verified bit-for-bit across many random/degenerate weight sets including exact-tie cases. Only cost can differ on another seed (more fallbacks if its candidate sets are larger).
    
    ## Next
    Gains left are ≤ ~0.001: (1) the node limit (400) is binding — freeing ~14 nodes would allow a K=3 path for n=3 (≈ +0.0001) or a 3rd reference output for n=3; (2) build floor is the three 64×64×32 tables (≈640k ops ≈ 0.003 of reward) — no exact way found to avoid them; (3) dominance D_i could be split as min_t(ET diffs) + PT offsets to save ~32k build ops but costs ~18 nodes; (4) the n=3 K paths (≈46 ops avg per n=3 input) dominate per-input cost; a tighter n=3 bound would need per-input work that costs about as much as the exact K-candidate computation. Do not revisit semantic rules or n=3 lookup tables.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.9904) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
