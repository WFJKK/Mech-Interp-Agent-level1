
import numpy as np, math
W_ = {k: v.astype(np.float64) for k, v in weights.items()}
E = W_['embed'][:64]; P = W_['pos']
VOU = W_['value'] @ W_['out'] @ W_['unembed']
ET = E @ VOU; PT = P @ VOU; UV = W_['unembed'] + VOU
Zall = E @ UV; PZ = P @ UV
M = W_['query'] @ W_['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMPt = (E@M@P.T).T; PMP = P@M@P.T
Z = [Zall + PZ[r] for r in range(4)]
r = 1; eps = 1e-9
expA = np.exp(EME + PME[r]); expB = np.exp(EMPt + PMP[r][:, None])
er = np.diag(expA) * expB[r]
Hi = expA.max(1)[None,:] * expB[:r] / er[None,:]
H = Hi.sum(0)
c = 16
Zc = Z[r][:, c]; ETc = ET[:, c]; a = Zc - ETc
Dmin = (ETc[:,None] - ET).min(0)
PTd = PT[:, c][:,None] - PT; p = PTd[:r] - PTd[r][None,:]
cols = np.concatenate([np.stack([np.ones(64), H]), Hi])
rows = np.concatenate([np.stack([Zc + H*a - (1+H)*eps, Dmin]), p])
print(cols.shape, rows.shape)
j,k=24,54
print(cols[:, j], rows[:, k], cols[:, j] @ rows[:, k], (cols.T @ rows)[j,k])
print('H*a', (H*a)[j], H[j], a[j], Zc[j])
