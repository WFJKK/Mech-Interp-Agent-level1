
import numpy as np
w = {k: v.copy() for k, v in weights.items()}; w['query'] = (w['query'] * 6).astype(np.float32); w['key'] = (w['key'] * 6).astype(np.float32)
rng = np.random.default_rng(777)
inp = lv1.draw_inputs(info['data_set'], info['input_space'], 3000, rng)
gr = lv1.Graph(w, 4); refe = gr.entry(interpretation=model.reference(gr, lv1))
ans, mops = lv1.run_reference(refe, w, 4, inp)
for name in ['v3d', 'v3e', 'v3f']:
    mm = lv1.measure(entries[name], w, 4, inp, ans, mops)
    print(name, 'agree', mm['n_agree'], 'cost', round(mm['cost'],4), 'pred/inp', round(mm['predict_ops']/3000,1))
# load v3f graph and inspect node values? use Graph.load
gg, interp, rule = lv1.Graph.load(entries['v3f'], w, 4)
print(type(gg), len(gg.nodes))
# find nodes: look for the 'where' producing code (int) -> print value stats of nodes with shape (3,64)
cands = [(i, n) for i, n in enumerate(gg.nodes) if n.get('op') in ('where',)]
print([ (i, np.asarray(gg.values[i]).shape) for i, n in cands][:5])
for i, n in cands:
    v = np.asarray(gg.values[i])
    if v.shape == (3, 64):
        print('code table hist per r:', [np.bincount(np.where(v[r] < 0, -v[r], 1).astype(int)).tolist() for r in range(3)])
