
exec(SRC)
g, e = build_entry()
d = g.diag
import numpy as np, math
W_ = {k: v.astype(np.float64) for k, v in weights.items()}
E = W_['embed'][:64]; P = W_['pos']
VOU = W_['value'] @ W_['out'] @ W_['unembed']
ET = E @ VOU; PT = P @ VOU; UV = W_['unembed'] + VOU
Zall = E @ UV; PZ = P @ UV
M = W_['query'] @ W_['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMPt = (E@M@P.T).T; PMP = P@M@P.T
Z = [Zall + PZ[r] for r in range(4)]
def trick(r, c, eps=1e-9):
    expA = np.exp(EME + PME[r]); expB = np.exp(EMPt + PMP[r][:, None])
    er = np.diag(expA) * expB[r]
    Hi = expA.max(1)[None,:] * expB[:r] / er[None,:]; Li = expA.min(1)[None,:] * expB[:r] / er[None,:]
    H = Hi.sum(0); L = Li.sum(0); D = H - L
    Y = Z[r] - ET; YH = Y*H[:,None]; YD = Y*D[:,None]
    Zc = Z[r][:, c]; ETc = ET[:, c]; a = Zc - ETc
    Dmin = (ETc[:,None] - ET).min(0)
    PTd = PT[:, c][:,None] - PT; p = PTd[:r] - PTd[r][None,:]; pmax = p.max(0)
    AD = a[:,None] + Dmin[None,:]
    R = (Zc - (1+H)*eps)[:,None] + H[:,None]*AD + Hi.T @ p
    QD = (AD + pmax[None,:]) * D[:,None]
    bound = R - Z[r] - YH - np.maximum(QD - YD, 0)
    return ~(bound >= 0), dict(H=H, L=L, Hi=Hi, p=p, pmax=pmax, R=R, QD=QD, bound=bound)
for ri, r, c in [(0,1,16),(2,3,4)]:
    nd, dd = trick(r, c)
    f = d['flags'].value[ri]
    print(r, 'numpy hist', np.bincount(nd.sum(1)), 'entry hist', np.bincount(f.sum(1)), 'mismatch', (nd != f).sum())
    print('  H', dd['H'][:3], d['H'].value[[0,1,1,2].index(ri) if False else (0 if ri==0 else 3)][:3])
    print('  L', dd['L'][:3], d['L'].value[0 if ri==0 else 3][:3])
