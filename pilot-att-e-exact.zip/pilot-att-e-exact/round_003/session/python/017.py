
g = graph()
print([k for k in g.__dict__.keys()])
x = g.const(1.0) + g.token(0)
print({k: (len(v) if hasattr(v,'__len__') else v) for k,v in g.__dict__.items() if k not in ('weights',)})
