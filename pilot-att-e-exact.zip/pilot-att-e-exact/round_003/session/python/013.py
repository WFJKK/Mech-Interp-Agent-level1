
import inspect, numpy as np, traceback
print(inspect.signature(lv1.transpose), inspect.signature(lv1.matmul), inspect.signature(lv1.reshape))
g = graph()
x = g.const(np.arange(24.).reshape(2,3,4))
try:
    y = lv1.transpose(x, (0,2,1)); print('transpose ok', y.shape)
except Exception as e: print('transpose err', e)
try:
    z = lv1.matmul(x, g.const(np.ones((2,4,5)))); print('batched matmul ok', z.shape, z.value[0,0])
except Exception as e: print('batched matmul err', e)
try:
    w = lv1.take(g.const(np.arange(10.)), g.const(np.array([[1,2],[3,4]])), 0); print('2d take ok', w.shape, w.value)
except Exception as e: print('2d take err', e)
try:
    v = x[:, :, 0]; print('int index slice', v.shape)
except Exception as e: print('slice err', e)
try:
    m = x.max(axis=2); print('max axis ok', m.shape)
    s = x.sum(axis=1); print(s.shape)
except Exception as e: print('max err', e)
try:
    b = (x > 3).sum(axis=2); print('bool sum', b.value)
except Exception as e: print('bool sum err', e)
try:
    q = lv1.argsort(x, axis=2); print('argsort axis ok', q.shape)
except Exception as e: print('argsort err', e)
ent = g.entry(interpretation=g.token(0))
print(lv1.PRICES if hasattr(lv1,'PRICES') else '')
