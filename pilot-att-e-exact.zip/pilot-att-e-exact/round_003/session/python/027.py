
import numpy as np, math, traceback, time
exec(SRC) if 'SRC' in dir() else None
