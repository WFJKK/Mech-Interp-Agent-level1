
import math, numpy as np
from collections import Counter
SRC = r'''
import math
def build_entry(Ks={1:(3,),2:(2,5),3:(2,)}, ncs={1:1,2:2,3:1}, eps=1e-9, example=None, graph=graph):
    g = graph() if example is None else graph(example=example)
    g.diag = {}
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    EU = E @ Un; PU = P @ Un
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMP = EM @ P.T; PMP = PM @ P.T
    T = [ET + PT[i] for i in range(4)]
    U = [EU + PU[r] for r in range(4)]
    Z = [U[r] + T[r] for r in range(4)]
    Tf = [T[i].reshape(4096) for i in range(4)]
    Uf = [U[r].reshape(4096) for r in range(4)]
    tab1 = Z[0].argmax(axis=1)
    tok = [g.token(i) for i in range(4)]
    tok64 = [tok[i]*64 for i in range(4)]
    out_r = {}
    for r in (1,2,3):
        A = EME + PME[r][None, :]
        B = EMP.T + PMP[r][:, None]          # [4,64]: B[i,j]
        er = lv1.exp(A.reshape(4096)[ar*65] + B[r])   # e of read slot, [64]
        sumB = lv1.exp(B[:r]).sum(axis=0) if r > 1 else lv1.exp(B[0])
        q = sumB / er
        Lp = lv1.exp(A.min(axis=1)) * q
        Hp = lv1.exp(A.max(axis=1)) * q
        thr = (1.0 + Hp) * eps
        am = Z[r].argmax(axis=1)
        c = (am[:, None] == ar[None, :]).sum(axis=0).argmax()
        flags = None; cs = []
        for ci in range(ncs[r]):
            if ci > 0:
                colsum = flags.sum(axis=0)
                for cc in cs: colsum = colsum * (ar != cc)
                c = colsum.argmax()
            cs.append(c)
            Zd = Z[r][:, c][:, None] - Z[r]
            ETd = ET[:, c][:, None] - ET
            G = ETd.min(axis=0)[None, :] - ETd
            PTd = PT[:, c][:, None] - PT
            pm = PTd[0] - PTd[r]
            for i in range(1, r): pm = lv1.minimum(pm, PTd[i] - PTd[r])
            x = (Zd + G) + pm[None, :]
            dom = (Zd + lv1.minimum(x * Lp[:, None], x * Hp[:, None])) >= thr[:, None]
            flags = ~dom if flags is None else flags & ~dom
        cnt = flags.sum(axis=1)
        order = lv1.argsort(ar[None, :] + 64 * lv1.cast(~flags, 'int'), axis=1)
        g.diag[r] = (cnt, cs, Lp, Hp, flags)
        j = tok[r]
        cj = cnt[j]
        s = lv1.stack([A[j, tok[i]] for i in range(r+1)]) + B[:r+1, j]
        w = lv1.softmax(s)
        def kpath(K):
            cands = order[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok64[i] + cands) for i in range(r+1)])
            Ug = lv1.take(Uf[r], tok64[r] + cands)
            return cands[(w @ Tg + Ug).argmax()]
        def full():
            Trows = lv1.stack([T[i][tok[i]] for i in range(r+1)])
            return (w @ Trows + U[r][j]).argmax()
        res = full()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        res = lv1.cond(cj == 1, order[:, :1][j][0], res)
        out_r[r] = res
    out = lv1.cond(tok[1] == 64, tab1[tok[0]], lv1.cond(tok[2] == 64, out_r[1], lv1.cond(tok[3] == 64, out_r[2], out_r[3])))
    return g, g.entry(interpretation=out)
'''
exec(SRC)
g, e = build_entry()
for r in (1,2,3):
    cnt, cs, Lp, Hp, flags = g.diag[r]
    print(r, 'cs', [c.value for c in cs], 'cnt hist', np.bincount(cnt.value), 'Lp', np.round(Lp.value[:5],3), 'Hp', np.round(Hp.value[:5],3))
    print('  union of candidates', np.where(flags.value.any(0))[0])
