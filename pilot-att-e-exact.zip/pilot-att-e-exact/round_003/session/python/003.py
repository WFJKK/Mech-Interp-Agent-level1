
import math, numpy as np
src = r'''
import math
def build_entry(Ks={1:(3,),2:(2,5),3:(2,)}, ncs={1:1,2:2,3:1}, eps=1e-9, example=None, union=None):
    g = graph() if example is None else graph(example=example)
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    EU = E @ Un; PU = P @ Un
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMP = EM @ P.T; PMP = PM @ P.T
    T = [ET + PT[i] for i in range(4)]
    U = [EU + PU[r] for r in range(4)]
    Z = [U[r] + T[r] for r in range(4)]
    tab1 = Z[0].argmax(axis=1)
    t = g.tokens()
    tok = [g.token(i) for i in range(4)]
    out_r = {}
    for r in (1,2,3):
        A = EME + PME[r][None, :]
        B = EMP.T + PMP[r][:, None]          # [4,64]: B[i,j]
        er = lv1.exp(A.reshape(4096)[ar*65] + B[r])   # e of read slot, [64]
        sumB = lv1.exp(B[:r]).sum(axis=0) if r > 1 else lv1.exp(B[0])
        Lp = lv1.exp(A.min(axis=1)) * sumB / er
        Hp = lv1.exp(A.max(axis=1)) * sumB / er
        thr = (1.0 + Hp) * eps
        # reference outputs
        am = Z[r].argmax(axis=1)
        hist = (am[:, None] == ar[None, :]).sum(axis=0)
        c = hist.argmax()
        flags = None; cs = []
        for ci in range(ncs[r]):
            if ci > 0:
                colsum = flags.sum(axis=0)
                for cc in cs: colsum = colsum * (ar != cc)
                c = colsum.argmax()
            cs.append(c)
            Zd = Z[r][:, c][:, None] - Z[r]
            ETd = ET[:, c][:, None] - ET
            G = ETd.min(axis=0)[None, :] - ETd
            PTd = PT[:, c][:, None] - PT
            pm = PTd[0] - PTd[r]
            for i in range(1, r): pm = lv1.minimum(pm, PTd[i] - PTd[r])
            x = (Zd + G) + pm[None, :]
            bound = Zd + lv1.minimum(x * Lp[:, None], x * Hp[:, None])
            dom = bound >= thr[:, None]
            flags = ~dom if flags is None else flags & ~dom
        cnt = flags.sum(axis=1)
        order = lv1.argsort(ar[None, :] + 64 * lv1.cast(~flags, 'int'), axis=1)
        # per input
        j = tok[r]
        cj = cnt[j]
        s = lv1.stack([A[j, tok[i]] for i in range(r+1)]) + B[:r+1, j]
        w = lv1.softmax(s)
        Tf = [T[i].reshape(4096) for i in range(r+1)]
        Uf = U[r].reshape(4096)
        def kpath(K):
            cands = order[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok[i]*64 + cands) for i in range(r+1)])
            Ug = lv1.take(Uf, j*64 + cands)
            return cands[(w @ Tg + Ug).argmax()]
        def full():
            Trows = lv1.stack([T[i][tok[i]] for i in range(r+1)])
            return (w @ Trows + U[r][j]).argmax()
        res = full()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        res = lv1.cond(cj == 1, order[:, :1][j][0], res)
        out_r[r] = res
    out = lv1.cond(tok[1] == 64, tab1[tok[0]], lv1.cond(tok[2] == 64, out_r[1], lv1.cond(tok[3] == 64, out_r[2], out_r[3])))
    return g, g.entry(interpretation=out)
'''
import os
os.makedirs('tmp', exist_ok=True)
open('tmp/build.py','w').write(src)
exec(src)
g, e = build_entry()
print(type(e), list(e.keys()) if isinstance(e, dict) else '')
try:
    print('nodes', len(e['nodes']))
except Exception as ex: print(ex)
m = measure(e); print(m)
