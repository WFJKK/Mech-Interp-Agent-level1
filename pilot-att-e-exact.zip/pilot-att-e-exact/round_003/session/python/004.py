
exec(open('tmp/build.py').read())
g, e = build_entry()
from collections import Counter
nodes = e['nodes']
print(nodes[:3])
print(Counter(str(n.get('op', n.get('kind'))) for n in nodes).most_common())
# measure bypassing node limit
rng = np.random.default_rng(0)
inp = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
ref = model.reference
import inspect
print(inspect.signature(lv1.run_reference))
