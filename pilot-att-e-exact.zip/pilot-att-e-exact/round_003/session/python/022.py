
import numpy as np
g = graph()
x = np.random.default_rng(1).normal(size=(3,3,5))
X = g.const(x)
idx = g.const(np.array([0,1,1,2]))
t = lv1.take(X, idx, 0)
print('take3d ok?', np.abs(t.value - x[[0,1,1,2]]).max(), t.shape)
t2 = X.reshape(3, 15)[idx].reshape(4, 3, 5)
print('reshape gather ok?', np.abs(t2.value - x[[0,1,1,2]]).max())
t3 = lv1.take(X, idx, axis=0)
print(np.abs(t3.value - x[[0,1,1,2]]).max())
y = np.random.default_rng(2).normal(size=(3,64))
Yc = g.const(y)
print('take2d', np.abs(lv1.take(Yc, idx, 0).value - y[[0,1,1,2]]).max())
# take along axis 2
k = g.const(np.array([4,0,2]))
print('take axis2', np.abs(lv1.take(X, k, 2).value - x[:, :, [4,0,2]]).max())
# 3d index take
idx3 = g.const(np.array([[[1,0],[2,2]],[[0,0],[1,2]],[[2,1],[0,0]]]))
v = g.const(np.array([10.,20.,30.]))
print('take 3d index', np.abs(lv1.take(v, idx3, 0).value - np.array([10.,20.,30.])[idx3.value]).max())
import inspect
print(inspect.getsource(lv1.take))
