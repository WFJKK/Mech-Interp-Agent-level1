
import inspect
for f in [lv1.draw_inputs, lv1.all_inputs, lv1.take, lv1.gather, lv1.cond, lv1.softmax, lv1.argsort, lv1.stack, lv1.concat, lv1.wilson_lower, lv1.count_inputs, lv1.real_inputs]:
    try: print(f.__name__, inspect.signature(f), (inspect.getdoc(f) or '')[:300]); print('--')
    except Exception as e: print('err', e)
print(inspect.signature(lv1.Graph.__init__))
print([k for k in dir(lv1.Graph) if not k.startswith('_')])
print([k for k in dir(lv1.Expr) if not k.startswith('_')])
print(info['check'], info['sample_size'], info['data_set'])
