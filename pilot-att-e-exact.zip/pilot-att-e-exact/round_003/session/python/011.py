
import numpy as np, math
W_ = {k: v.astype(np.float64) for k, v in weights.items()}
E = W_['embed'][:64]; P = W_['pos']
VOU = W_['value'] @ W_['out'] @ W_['unembed']
ET = E @ VOU; PT = P @ VOU; UV = W_['unembed'] + VOU
Zall = E @ UV; PZ = P @ UV
M = W_['query'] @ W_['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMPt = (E@M@P.T).T; PMP = P@M@P.T
Z = [Zall + PZ[r] for r in range(4)]
r = 1; eps = 1e-9
expA = np.exp(EME + PME[r]); expB = np.exp(EMPt + PMP[r][:, None])
er = np.diag(expA) * expB[r]
Hi = expA.max(1)[None,:] * expB[:r] / er[None,:]; Li = expA.min(1)[None,:] * expB[:r] / er[None,:]
H = Hi.sum(0); L = Li.sum(0); D = H - L
Y = Z[r] - ET; YH = Y*H[:,None]; YD = Y*D[:,None]
c = 16
Zc = Z[r][:, c]; ETc = ET[:, c]; a = Zc - ETc
Dmin = (ETc[:,None] - ET).min(0)
PTd = PT[:, c][:,None] - PT; p = PTd[:r] - PTd[r][None,:]; pmax = p.max(0)
cols = np.concatenate([np.stack([np.ones(64), H]), Hi])
rows = np.concatenate([np.stack([Zc + H*a - (1+H)*eps, Dmin]), p])
R = cols.T @ rows
QD = (a[:,None] + (Dmin+pmax)[None,:]) * D[:,None]
bound = R - Z[r] - YH - np.maximum(QD - YD, 0)
Zd = Zc[:,None] - Z[r]; ETd = ETc[:,None] - ET; G = Dmin[None,:] - ETd
y = Zd + G; x = y + p[0][None,:]
tot = np.minimum(x*Li[0][:,None], x*Hi[0][:,None])
bound2 = Zd + tot - (1+H[:,None])*eps
j,k = np.unravel_index(np.abs(bound-bound2).argmax(), bound.shape)
print(j,k, bound[j,k], bound2[j,k])
print('Zd', Zd[j,k], 'y', y[j,k], 'x', x[j,k], 'L,H', Li[0][j], Hi[0][j], 'tot', tot[j,k])
print('R', R[j,k], 'Z', Z[r][j,k], 'YH', YH[j,k], 'QD-YD', QD[j,k]-YD[j,k])
print('R parts', Zc[j] + H[j]*a[j], H[j]*Dmin[k], Hi[0][j]*p[0][k])
print('yH + p0 H0 + Zd', y[j,k]*H[j] + p[0][k]*Hi[0][j] + Zd[j,k], ' xH', x[j,k]*H[j], 'max term', max(0,x[j,k])*D[j])
