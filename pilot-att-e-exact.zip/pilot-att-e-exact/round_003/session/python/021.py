
import math, numpy as np, traceback
SRC = r'''
import math
def build_entry(Ks={1:(3,),2:(2,5),3:(2,)}, eps=1e-9, W=16, graph=graph, cp=None):
    g = graph(); g.diag = {}
    def ck(name):
        if cp is not None: cp.append((name, len(g.nodes)))
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64); arW = g.arange(W)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    UV = Un + VOU
    Zall = E @ UV; PZ = P @ UV
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMPt = (EM @ P.T).T; PMP = PM @ P.T
    Tt = [ET + PT[i] for i in range(4)]
    Tf = [Tt[i].reshape(4096) for i in range(4)]
    tab1 = (Zall + PZ[0]).argmax(axis=1)
    tok = [g.token(i) for i in range(4)]
    tok64 = [tok[i]*64 for i in range(4)]
    ck('tables')
    rsel = g.const(np.array([1, 6, 11]))
    rmap = g.const(np.array([0, 1, 1, 2]))
    rrow4 = g.const(np.array([1, 6, 10, 15]))
    roff4 = g.const(np.array([0, 64, 64, 128]))
    maskb = g.const(np.array([[1.,0,0],[1,1,0],[1,1,1],[1,1,1]]))[:, :, None] > 0.5   # [4,3,1]
    expA = lv1.exp(EME[None] + PME[1:4][:, None, :])         # [3, j, t]
    expB = lv1.exp(EMPt[None] + PMP[1:4][:, :, None])        # [3, i, j]
    er = expA.reshape(3, 4096)[:, ar*65] * lv1.take(expB.reshape(12, 64), rsel, 0)   # [3, j]
    scale = lv1.take(expB[:, :3] / er[:, None, :], rmap, 0) * maskb                   # [4, i, j]
    Hi = lv1.take(expA.max(axis=2), rmap, 0)[:, None, :] * scale
    Li = lv1.take(expA.min(axis=2), rmap, 0)[:, None, :] * scale
    H = Hi.sum(axis=1); L = Li.sum(axis=1)                                            # [4, j]
    Hn = H[:, :, None]; Dn = (H - L)[:, :, None]
    Z3 = Zall[None] + PZ[1:4][:, None, :]                                            # [3, j, k]
    Z3t = lv1.transpose(Z3, (0, 2, 1)).reshape(192, 64)                              # [(r,k), j]
    Z4 = lv1.take(Z3, rmap, 0)
    Y = Z4 - ET[None]
    ZYH = Z4 + Y * Hn; YD = Y * Dn
    Zeh = (H + 1.0) * (-eps)
    ck('scores')
    am = Z3.argmax(axis=2)
    hist = (am[:, :, None] == ar).sum(axis=1)                  # [3, k]
    c1 = hist.argmax(axis=1)                                   # [3]
    c2 = (hist * (ar[None, :] != c1[:, None])).argmax(axis=1)
    c = lv1.concat([c1[:2], c2[1:2], c1[2:]])                  # [4]
    ck('csel')
    Zc = lv1.take(Z3t, roff4 + c, 0)                        # [b, j]
    ETc = lv1.take(ET.T, c, 0)                             # [b, t]
    a = Zc - ETc
    Dmin = (ETc[:, :, None] - ET[None]).min(axis=1)        # [b, k]
    PTd = lv1.take(PT.T, c, 0)[:, :, None] - PT[None]      # [b, 4, k]
    p = PTd[:, :3] - lv1.take(PTd.reshape(16, 64), rrow4, 0)[:, None, :]   # [b, 3, k]
    pmax = lv1.where(maskb, p, -1e30).max(axis=1)          # [b, k]
    AD = a[:, :, None] + Dmin[:, None, :]                   # [b, j, k]
    R = (Zc + Zeh)[:, :, None] + Hn * AD + lv1.matmul(lv1.transpose(Hi, (0, 2, 1)), p)
    QD = (AD + pmax[:, None, :]) * Dn
    nd = ~((R - ZYH - lv1.maximum(QD - YD, 0.0)) >= 0.0)
    flags = lv1.concat([nd[:1], nd[1:2] & nd[2:3], nd[3:]])   # [3, j, k]
    ck('pass')
    colany = flags.sum(axis=1).sum(axis=0)                       # [k]
    kidx = lv1.argsort(ar + 64 * lv1.cast(colany == 0, 'int'))[:W]   # [W]
    sub = lv1.take(flags, kidx, 2)                               # [3, j, W]
    subcnt = sub.sum(axis=2)
    cnt = flags.sum(axis=2)
    cntx = subcnt + 100 * lv1.cast(cnt > subcnt, 'int')         # [3, j]
    ordW = lv1.argsort(arW + W * lv1.cast(~sub, 'int'), axis=2)  # [3, j, W]
    cand = lv1.take(kidx, ordW, 0)                               # [3, j, W]
    code = lv1.where(cntx == 1, cand[:, :, 0], -cntx)
    g.diag = dict(cntx=cntx, c=c, flags=flags, cand=cand, H=H, L=L, kidx=kidx, Hi=Hi, p=p, pmax=pmax, R=R, QD=QD, nd=nd, scale=scale, er=er, Zc=Zc, a=a, Dmin=Dmin, AD=AD, Z4=Z4, ZYH=ZYH, YD=YD, expA=expA, expB=expB)
    ck('order')
    out_r = {}
    for r in (1, 2, 3):
        ri = r - 1
        j = tok[r]
        f = code[ri][j]
        cj = -f
        eA = expA[ri]; eB = expB[ri]
        e = lv1.stack([eA[j, tok[i]] for i in range(r+1)]) * eB[:r+1, j]
        se = e.sum()
        ep = lv1.concat([e[:r], e[r:] - se])
        Zf = Z3[ri].reshape(4096); candr = cand[ri]
        def kpath(K):
            cands = candr[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok64[i] + cands) for i in range(r+1)])
            Zg = lv1.take(Zf, tok64[r] + cands)
            return cands[(ep @ Tg + Zg * se).argmax()]
        Trows = lv1.stack([Tt[i][tok[i]] for i in range(r+1)])
        res = (ep @ Trows + Z3[ri][j] * se).argmax()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        out_r[r] = lv1.cond(f >= 0, f, res)
        ck('r%d' % r)
    out = lv1.cond(tok[2] == 64, lv1.cond(tok[1] == 64, tab1[tok[0]], out_r[1]), lv1.cond(tok[3] == 64, out_r[2], out_r[3]))
    ck('out')
    return g, g.entry(interpretation=out)
'''
exec(SRC)
g, e = build_entry()
d = g.diag
W_ = {k: v.astype(np.float64) for k, v in weights.items()}
E = W_['embed'][:64]; P = W_['pos']
VOU = W_['value'] @ W_['out'] @ W_['unembed']
ET = E @ VOU; PT = P @ VOU; UV = W_['unembed'] + VOU
Zall = E @ UV; PZ = P @ UV
M = W_['query'] @ W_['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMPt = (E@M@P.T).T; PMP = P@M@P.T
Z = [Zall + PZ[r] for r in range(4)]
def trick(r, c, eps=1e-9):
    expA = np.exp(EME + PME[r]); expB = np.exp(EMPt + PMP[r][:, None])
    er = np.diag(expA) * expB[r]
    Hi = expA.max(1)[None,:] * expB[:r] / er[None,:]; Li = expA.min(1)[None,:] * expB[:r] / er[None,:]
    H = Hi.sum(0); L = Li.sum(0); D = H - L
    Y = Z[r] - ET; YH = Y*H[:,None]; YD = Y*D[:,None]
    Zc = Z[r][:, c]; ETc = ET[:, c]; a = Zc - ETc
    Dmin = (ETc[:,None] - ET).min(0)
    PTd = PT[:, c][:,None] - PT; p = PTd[:r] - PTd[r][None,:]; pmax = p.max(0)
    AD = a[:,None] + Dmin[None,:]
    R = (Zc - (1+H)*eps)[:,None] + H[:,None]*AD + Hi.T @ p
    QD = (AD + pmax[None,:]) * D[:,None]
    bound = R - Z[r] - YH - np.maximum(QD - YD, 0)
    return ~(bound >= 0), dict(H=H, L=L, Hi=Hi, p=p, pmax=pmax, R=R, QD=QD, bound=bound, er=er, expA=expA, expB=expB, Zc=Zc, a=a, Dmin=Dmin, AD=AD, Y=Y, YH=YH, YD=YD)
for b, r, c in [(0,1,16),(3,3,4)]:
    nd, dd = trick(r, c)
    f = d['nd'].value[b]
    print(r, 'numpy hist', np.bincount(nd.sum(1)), 'entry hist', np.bincount(f.sum(1)), 'mismatch', (nd != f).sum())
    for k in ['H','L','er','Zc','a','Dmin','pmax','R','QD','YD']:
        v = d[k].value[b] if k not in ('er',) else d[k].value[0 if r==1 else 2]
        print('  ', k, np.abs(np.asarray(v) - dd[k]).max())
    print('  Hi', np.abs(d['Hi'].value[b][:r] - dd['Hi']).max(), 'p', np.abs(d['p'].value[b][:r] - dd['p']).max())
