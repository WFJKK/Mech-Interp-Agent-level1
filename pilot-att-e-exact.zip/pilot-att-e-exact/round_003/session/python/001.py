
import inspect
print([k for k in dir(lv1) if not k.startswith('_')])
print(info.keys() if hasattr(info,'keys') else info)
print({k:v.shape for k,v in weights.items()})
print(inspect.signature(measure))
try:
    print(inspect.signature(lv1.measure))
    print(inspect.getdoc(lv1.measure))
except Exception as e: print('err',e)
try:
    print(inspect.signature(lv1.run_reference)); print(inspect.getdoc(lv1.run_reference))
except Exception as e: print('err',e)
print(list(entries.keys()))
m = measure(entries['best']); print(m)
