
import numpy as np, math
W_ = weights
E = W_['embed'][:64]; P = W_['pos']
VOU = W_['value'] @ W_['out'] @ W_['unembed']
ET = E @ VOU; PT = P @ VOU; UV = W_['unembed'] + VOU
Zall = E @ UV; PZ = P @ UV
M = W_['query'] @ W_['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMPt = (E@M@P.T).T; PMP = P@M@P.T
Z = [Zall + PZ[r] for r in range(4)]
ar = np.arange(64)
# brute force n=2 outputs per j
def logits_n2(j, t0):
    x = np.stack([E[t0]+P[0], E[j]+P[1]])
    q = x[1] @ W_['query'] / math.sqrt(32); s = (x @ W_['key']) @ q; w = np.exp(s - s.max()); w /= w.sum()
    return (x[1] + w @ (x @ W_['value'] @ W_['out'])) @ W_['unembed']
reach = [set(int(np.argmax(logits_n2(j, t0))) for t0 in range(64)) for j in range(64)]
r = 1; eps = 1e-9
expA = np.exp(EME + PME[r]); expB = np.exp(EMPt + PMP[r][:, None])
er = np.diag(expA) * expB[r]
Hi = expA.max(1)[None,:] * expB[:r] / er[None,:]; Li = expA.min(1)[None,:] * expB[:r] / er[None,:]
H = Hi.sum(0); L = Li.sum(0); D = H - L
Y = Z[r] - ET; YH = Y*H[:,None]; YD = Y*D[:,None]
cols = np.concatenate([np.stack([np.ones(64), H]), Hi])
c = 16
Zc = Z[r][:, c]; ETc = ET[:, c]; a = Zc - ETc
Dmin = (ETc[:,None] - ET).min(0)
PTd = PT[:, c][:,None] - PT; p = PTd[:r] - PTd[r][None,:]; pmax = p.max(0)
rows = np.concatenate([np.stack([Zc + H*a - (1+H)*eps, Dmin]), p])
R = cols.T @ rows
QD = (a[:,None] + (Dmin+pmax)[None,:]) * D[:,None]
bound = R - Z[r] - YH - np.maximum(QD - YD, 0)
nd = ~(bound >= 0)
print('cnt hist', np.bincount(nd.sum(1)))
# compare with direct per-i formula
Zd = Zc[:,None] - Z[r]; ETd = ETc[:,None] - ET; G = Dmin[None,:] - ETd
y = Zd + G
x = y + p[0][None,:]
tot = np.minimum(x*Li[0][:,None], x*Hi[0][:,None])
bound2 = Zd + tot - (1+H[:,None])*eps
print('cnt hist direct', np.bincount((~(bound2>=0)).sum(1)))
print('y check', np.abs(y - (a[:,None] + Dmin[None,:] - Y)).max())
print('bound diff', np.abs(bound - bound2).max())
bad = [j for j in range(64) if not reach[j] <= set(np.where(~(bound2>=0))[1][nd.sum(1)[j]*0:0]) ]  # placeholder
cands2 = [set(np.where(~(bound2[j]>=0))[0]) for j in range(64)]
print('unsound js (direct):', [j for j in range(64) if not reach[j] <= cands2[j]][:10])
print('reach sizes', np.bincount([len(s) for s in reach]))
