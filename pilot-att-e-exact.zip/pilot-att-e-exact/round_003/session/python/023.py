
import numpy as np, math
W_ = {k: v.astype(np.float64) for k, v in weights.items()}
E = W_['embed'][:64]; P = W_['pos']
M = W_['query'] @ W_['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMPt = (E@M@P.T).T; PMP = P@M@P.T
g = graph()
Eg = g.weight('embed')[:64]; Pg = g.weight('pos')
Mg = (g.weight('query') @ g.weight('key').T) * (1/math.sqrt(32))
EMg = Eg @ Mg; EMEg = EMg @ Eg.T; PMg = Pg @ Mg; PMEg = PMg @ Eg.T; EMPtg = (EMg @ Pg.T).T; PMPg = PMg @ Pg.T
print('EME', np.abs(EMEg.value - EME).max(), 'PME', np.abs(PMEg.value - PME).max(), 'EMPt', np.abs(EMPtg.value - EMPt).max(), 'PMP', np.abs(PMPg.value - PMP).max())
expA = lv1.exp(EMEg[None] + PMEg[1:4][:, None, :])
print('expA', np.abs(expA.value[0] - np.exp(EME + PME[1])).max(), expA.shape)
expB = lv1.exp(EMPtg[None] + PMPg[1:4][:, :, None])
print('expB', np.abs(expB.value[0] - np.exp(EMPt + PMP[1][:, None])).max(), expB.shape)
mx = expA.max(axis=2)
print('max', np.abs(mx.value[0] - np.exp(EME + PME[1]).max(1)).max(), mx.shape)
mn = expA.min(axis=2)
print('min', np.abs(mn.value[0] - np.exp(EME + PME[1]).min(1)).max())
ar = g.arange(64)
er = expA.reshape(3, 4096)[:, ar*65] * lv1.take(expB.reshape(12, 64), g.const(np.array([1,6,11])), 0)
ern = np.diag(np.exp(EME + PME[1])) * np.exp(EMPt + PMP[1][:, None])[1]
print('er', np.abs(er.value[0] - ern).max())
scale0 = expB[:, :3] / er[:, None, :]
print('scale', np.abs(scale0.value[0] - np.exp(EMPt + PMP[1][:, None])[:3] / ern[None, :]).max())
print(expB[:, :3].shape, er[:, None, :].shape, scale0.shape)
rmap = g.const(np.array([0, 1, 1, 2]))
sc = lv1.take(scale0, rmap, 0)
print('scale take', np.abs(sc.value[0] - scale0.value[0]).max(), np.abs(sc.value[3] - scale0.value[2]).max())
maskb = g.const(np.array([[1.,0,0],[1,1,0],[1,1,1],[1,1,1]]))[:, :, None] > 0.5
sc2 = sc * maskb
print('maskb', maskb.value[:, :, 0], np.abs(sc2.value[0][0] - scale0.value[0][0]).max(), sc2.value[0][1:].max())
Hi = lv1.take(mx, rmap, 0)[:, None, :] * sc2
print('Hi', np.abs(Hi.value[0][0] - mx.value[0] * scale0.value[0][0]).max(), Hi.shape)
H = Hi.sum(axis=1)
print('H', np.abs(H.value[0] - Hi.value[0].sum(0)).max())
