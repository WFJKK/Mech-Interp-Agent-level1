
import math, numpy as np
from collections import Counter
SRC = r'''
import math
def build_entry(Ks={1:(3,),2:(2,5),3:(2,)}, ncs={1:1,2:2,3:1}, eps=1e-9, W=8, graph=graph):
    g = graph(); g.diag = {}
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64); arW = g.arange(W)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    UV = Un + VOU
    Zall = E @ UV; PZ = P @ UV
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMPt = (EM @ P.T).T; PMP = PM @ P.T
    Tf = [(ET + PT[i]).reshape(4096) for i in range(4)]
    Z = [Zall + PZ[r] for r in range(4)]
    tab1 = Z[0].argmax(axis=1)
    tok = [g.token(i) for i in range(4)]
    tok64 = [tok[i]*64 for i in range(4)]
    out_r = {}
    for r in (1,2,3):
        expA = lv1.exp(EME + PME[r])
        expB = lv1.exp(EMPt + PMP[r][:, None])      # [4,64]
        er = expA.reshape(4096)[ar*65] * expB[r]
        Hi = expA.max(axis=1)[None, :] * expB[:r] / er[None, :]   # [r,64]
        Li = expA.min(axis=1)[None, :] * expB[:r] / er[None, :]
        H = Hi.sum(axis=0) if r > 1 else Hi[0]
        L = Li.sum(axis=0) if r > 1 else Li[0]
        D = H - L
        Y = Z[r] - ET
        YH = Y * H[:, None]; YD = Y * D[:, None]
        ones = H * 0.0 + 1.0
        cols = lv1.concat([lv1.stack([ones, H]), Hi])     # [r+2, 64]
        am = Z[r].argmax(axis=1)
        c = (am[:, None] == ar[None, :]).sum(axis=0).argmax()
        flags = None; cs = []
        for ci in range(ncs[r]):
            if ci > 0:
                colsum = flags.sum(axis=0)
                for cc in cs: colsum = colsum * (ar != cc)
                c = colsum.argmax()
            cs.append(c)
            Zc = Z[r][:, c]; ETc = ET[:, c]; a = Zc - ETc
            Dmin = (ETc[:, None] - ET).min(axis=0)
            PTd = PT[:, c][:, None] - PT
            p = PTd[:r] - PTd[r][None, :]
            pmax = p.max(axis=0) if r > 1 else p[0]
            rows = lv1.concat([lv1.stack([Zc + H * a - (1.0 + H) * eps, Dmin]), p])
            R = cols.T @ rows
            QD = (a[:, None] + (Dmin + pmax)[None, :]) * D[:, None]
            bound = R - Z[r] - YH - lv1.maximum(QD - YD, 0.0)
            nd = ~(bound >= 0.0)
            flags = nd if flags is None else flags & nd
        colsum = flags.sum(axis=0)
        kidx = lv1.argsort(ar + 64 * lv1.cast(colsum == 0, 'int'))[:W]
        sub = lv1.take(flags, kidx, axis=1)
        subcnt = sub.sum(axis=1)
        cntx = subcnt + 100 * lv1.cast(flags.sum(axis=1) > subcnt, 'int')
        ord8 = lv1.argsort(arW[None, :] + W * lv1.cast(~sub, 'int'), axis=1)
        cand = lv1.take(kidx, ord8.reshape(64 * W)).reshape(64, W)
        first = lv1.where(cntx == 1, cand[:, 0], -1)
        g.diag[r] = (cntx, cs, flags, cand)
        j = tok[r]
        f = first[j]
        cj = cntx[j]
        e = lv1.stack([expA[j, tok[i]] for i in range(r+1)]) * expB[:r+1, j]
        se = e.sum()
        ep = lv1.concat([e[:r], e[r:] - se])
        Zf = Z[r].reshape(4096)
        def kpath(K):
            cands = cand[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok64[i] + cands) for i in range(r+1)])
            Zg = lv1.take(Zf, tok64[r] + cands)
            return cands[(ep @ Tg + Zg * se).argmax()]
        Trows = lv1.stack([lv1.take(Tf[i], tok64[i] + ar) for i in range(r+1)])
        res = (ep @ Trows + Z[r][j] * se).argmax()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        out_r[r] = lv1.cond(f >= 0, f, res)
    out = lv1.cond(tok[2] == 64, lv1.cond(tok[1] == 64, tab1[tok[0]], out_r[1]), lv1.cond(tok[3] == 64, out_r[2], out_r[3]))
    return g, g.entry(interpretation=out)
'''
exec(SRC)
g, e = build_entry()
nodes = e['nodes']; print('nodes', len(nodes))
print(Counter(str(n.get('op')) for n in nodes).most_common())
for r in (1,2,3):
    cnt, cs, flags, cand = g.diag[r]
    print(r, 'cs', [int(c.value) for c in cs], 'cnt hist', np.bincount(cnt.value), 'union', np.where(flags.value.any(0))[0], cand.value[:2])
rng = np.random.default_rng(0)
inp = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
gr = graph(); refe = gr.entry(interpretation=model.reference(gr, lv1))
ans, mops = lv1.run_reference(refe, weights, 4, inp)
m = lv1.measure(e, weights, 4, inp, ans, mops); print(m)
