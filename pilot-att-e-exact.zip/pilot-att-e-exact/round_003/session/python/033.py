
import math, numpy as np, traceback, time
SRC = r'''
import math
def build_entry(Ks={1:(3,),2:(2,3,5),3:(2,)}, pairs=((1,0),(2,0),(2,1),(3,0)), eps=1e-9, W=16, graph=graph, cp=None):
    g = graph(); g.diag = {}
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    UV = Un + VOU
    Zall = E @ UV; PZ = P @ UV
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMPt = (EM @ P.T).T; PMP = PM @ P.T
    Tt = [ET + PT[i] for i in range(4)]
    Tf = [Tt[i].reshape(4096) for i in range(4)]
    tab1 = (Zall + PZ[0]).argmax(axis=1)
    tok = [g.token(i) for i in range(4)]
    tok64 = [tok[i]*64 for i in range(4)]
    nb = len(pairs)
    rsel = g.const(np.array([1, 6, 11]))
    rmap = g.const(np.array([r - 1 for r, _ in pairs]))
    rrow = g.const(np.array([bi * 4 + r for bi, (r, _) in enumerate(pairs)]))
    roff = g.const(np.array([(r - 1) * 64 for r, _ in pairs]))
    maskf = g.const(np.array([[1. if i < r else 0. for i in range(3)] for r, _ in pairs]))[:, :, None]
    A3 = EME[None] + PME[1:4][:, None, :]                    # [3, j, t]  attention score, token/pos parts
    B3 = EMPt[None] + PMP[1:4][:, :, None]                   # [3, i, j]
    expB = lv1.exp(B3)
    er = lv1.exp(A3.reshape(3, 4096)[:, ar*65] + lv1.take(B3.reshape(12, 64), rsel, 0))   # [3, j] exp score of the read slot
    scale = lv1.take(expB[:, :3] / er[:, None, :], rmap, 0) * maskf                   # [b, i, j]
    Hi = lv1.take(lv1.exp(A3.max(axis=2)), rmap, 0)[:, None, :] * scale               # upper bounds on e_i/e_r
    Li = lv1.take(lv1.exp(A3.min(axis=2)), rmap, 0)[:, None, :] * scale
    H = Hi.sum(axis=1); L = Li.sum(axis=1)                                            # [b, j]
    Hn = H[:, :, None]; Dn = (H - L)[:, :, None]
    Z3 = Zall[None] + PZ[1:4][:, None, :]                                            # [3, j, k]  direct path + read-slot value path
    Z3t = lv1.transpose(Z3, (0, 2, 1)).reshape(192, 64)                              # [(r,k), j]
    Z4 = lv1.take(Z3, rmap, 0)
    Y = Z4 - ET[None]
    am = Z3.argmax(axis=2)
    hist = (am[:, :, None] == ar).sum(axis=1)                  # [3, k]
    c1 = hist.argmax(axis=1)                                   # [3]  most common direct-path answer
    cs = [c1]
    if any(ci == 1 for _, ci in pairs):
        cs.append((hist * (ar[None, :] != c1[:, None])).argmax(axis=1))
    c = lv1.concat([cs[ci][r-1:r] for r, ci in pairs])        # [b]
    Zc = lv1.take(Z3t, roff + c, 0)                        # [b, j]
    ETc = lv1.take(ET.T, c, 0)                             # [b, t]
    a = Zc - ETc
    Dmin = (ETc[:, :, None] - ET[None]).min(axis=1)        # [b, k]
    PTd = lv1.take(PT.T, c, 0)[:, :, None] - PT[None]      # [b, 4, k]
    p = PTd[:, :3] - lv1.take(PTd.reshape(4 * nb, 64), rrow, 0)[:, None, :]   # [b, 3, k]
    pmax = lv1.where(maskf > 0.5, p, -1e30).max(axis=1)    # [b, k]
    V = (a[:, :, None] + Dmin[:, None, :]) - Y              # [b, j, k]
    base = (Zc + (H + 1.0) * (-eps))[:, :, None] - Z4 + lv1.matmul(lv1.transpose(Hi, (0, 2, 1)), p)
    dom = (base + Hn * V - Dn * lv1.maximum(V + pmax[:, None, :], 0.0)) >= 0.0     # c beats k for every input; NaN -> False
    parts = []
    for r in (1, 2, 3):
        bs = [bi for bi, (rr, _) in enumerate(pairs) if rr == r]
        f = dom[bs[0]:bs[0]+1]
        for bi in bs[1:]: f = f | dom[bi:bi+1]
        parts.append(f)
    dom3 = lv1.concat(parts)                                     # [3, j, k]
    kidx = lv1.argsort(dom3.sum(axis=1).sum(axis=0))[:W]         # [W] the W most frequent candidates
    sub = lv1.take(dom3, kidx, 2)                                # [3, j, W]
    subcnt = W - sub.sum(axis=2)
    cntx = subcnt + 100 * lv1.cast(64 - dom3.sum(axis=2) > subcnt, 'int')   # [3, j]; candidates outside kidx -> fallback
    ordW = lv1.argsort(kidx + 64 * lv1.cast(sub, 'int'), axis=2)  # [3, j, W]
    cand = lv1.take(kidx, ordW, 0)                               # [3, j, W] candidates first, ascending
    code = lv1.where(cntx == 1, cand[:, :, 0], -cntx)
    g.diag = dict(cntx=cntx, c=c, dom3=dom3, cand=cand, H=H, L=L, kidx=kidx)
    out_r = {}
    for r in (1, 2, 3):
        ri = r - 1
        j = tok[r]
        f = code[ri][j]
        cj = -f
        Ar = A3[ri]; Br = B3[ri]
        s = lv1.stack([Ar[j, tok[i]] for i in range(r+1)]) + Br[:r+1, j]
        w = lv1.softmax(s)
        wp = lv1.concat([w[:r], w[r:] - 1.0])
        Zf = Z3[ri].reshape(4096); candr = cand[ri]
        def kpath(K):
            cands = candr[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok64[i] + cands) for i in range(r+1)])
            Zg = lv1.take(Zf, tok64[r] + cands)
            return cands[(wp @ Tg + Zg).argmax()]
        Trows = lv1.stack([Tt[i][tok[i]] for i in range(r+1)])
        res = (wp @ Trows + Z3[ri][j]).argmax()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        out_r[r] = lv1.cond(f >= 0, f, res)
    out = lv1.cond(tok[2] == 64, lv1.cond(tok[1] == 64, tab1[tok[0]], out_r[1]), lv1.cond(tok[3] == 64, out_r[2], out_r[3]))
    return g, g.entry(interpretation=out)
'''
exec(SRC)
g, e = build_entry()
print('nodes', len(e['nodes']), 'kidx', g.diag['kidx'].value, [np.bincount(g.diag['cntx'].value[ri]).tolist() for ri in range(3)], g.diag['cand'].value[1][:3,:6])
m = measure(e); print({k: m[k] for k in ('n_agree','build_ops','predict_ops','cost','reward')})
save_entry('v3g', e)
rng = np.random.default_rng(778)
inp = lv1.draw_inputs(info['data_set'], info['input_space'], 4000, rng)
inp2 = np.concatenate([np.array([[t,64,64,64] for t in range(64)]), np.array([[a,b,64,64] for a in range(64) for b in range(64)])])
allinp = np.concatenate([inp, inp2])
def test(name, w):
    try:
        gr = lv1.Graph(w, 4); refe = gr.entry(interpretation=model.reference(gr, lv1))
        ans, mops = lv1.run_reference(refe, w, 4, allinp)
        mm = lv1.measure(e, w, 4, allinp, ans, mops)
        print(name, 'agree', mm['n_agree'], '/', mm['n_inputs'], 'cost', round(mm['cost'],4))
    except Exception as ex:
        print(name, 'ERROR', repr(ex)[:300])
def gauss(scale, seed):
    r = np.random.default_rng(seed)
    w = {k: (r.normal(size=v.shape) * scale).astype(np.float64) for k, v in weights.items()}
    w['embed'][64] = 0
    return w
tests = [('orig', {k: v.copy() for k, v in weights.items()}), ('gauss0.2', gauss(0.2, 31)), ('gauss1', gauss(1.0, 32))]
w = {k: np.random.default_rng(29).integers(-2, 3, size=v.shape).astype(np.float64) for k, v in weights.items()}; w['embed'][64] = 0
tests.append(('int', w))
w = {k: v.copy().astype(np.float64) for k, v in weights.items()}; w['unembed'][:, 20] = w['unembed'][:, 16]; w['unembed'][:, 50] = w['unembed'][:, 4]; w['unembed'][:, 40] = w['unembed'][:, 36]; tests.append(('dupcols', w))
w = {k: v + np.random.default_rng(16).normal(size=v.shape)*0.1*np.abs(v).mean() for k, v in weights.items()}; w['embed'][64] = 0; tests.append(('perturbed', w))
w = {k: v.copy().astype(np.float64) for k, v in weights.items()}; w['query'] *= 6; w['key'] *= 6; tests.append(('sharpattn', w))
w = {k: np.zeros(v.shape) for k, v in weights.items()}; tests.append(('zeros', w))
for name, w in tests:
    test(name, {k: np.asarray(v, dtype=np.float32) if weights[k].dtype == np.float32 else v for k, v in w.items()})
