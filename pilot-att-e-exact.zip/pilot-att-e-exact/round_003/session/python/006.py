
exec(SRC.replace("        out_r[r] = res\n", "        out_r[r] = res\n        g.diag = getattr(g,'diag',{}); g.diag[r] = (cnt, cs, Lp, Hp, flags)\n"))
g, e = build_entry()
for r in (1,2,3):
    cnt, cs, Lp, Hp, flags = g.diag[r]
    print(r, 'cs', [c.value for c in cs], 'cnt hist', np.bincount(cnt.value), 'Lp', np.round(Lp.value[:5],3), 'Hp', np.round(Hp.value[:5],3))
    print('  union of candidates', np.where(flags.value.any(0))[0])
