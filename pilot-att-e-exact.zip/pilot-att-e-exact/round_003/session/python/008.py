
import numpy as np, math
W = weights
E = W['embed'][:64]; P = W['pos']
VOU = W['value'] @ W['out'] @ W['unembed']
ET = E @ VOU; PT = P @ VOU; EU = E @ W['unembed']; PU = P @ W['unembed']
M = W['query'] @ W['key'].T / math.sqrt(32)
EME = E@M@E.T; PME = P@M@E.T; EMP = E@M@P.T; PMP = P@M@P.T
T = [ET + PT[i] for i in range(4)]; U = [EU + PU[r] for r in range(4)]; Z = [U[r]+T[r] for r in range(4)]
print('PT range', np.abs(PT).max(), 'ET range', np.abs(ET).max(), 'PU', np.abs(PU).max(), 'EU', np.abs(EU).max())
def bounds(r, cs, mode, eps=1e-9):
    A = EME + PME[r][None,:]; B = EMP.T + PMP[r][:,None]
    er = np.exp(np.diag(A) + B[r])
    Li = [np.exp(A.min(1) + B[i]) / er for i in range(r)]
    Hi = [np.exp(A.max(1) + B[i]) / er for i in range(r)]
    flags = np.ones((64,64), bool)
    for c in cs:
        Zd = Z[r][:, c][:,None] - Z[r]
        ETd = ET[:, c][:,None] - ET
        G = ETd.min(0)[None,:] - ETd
        PTd = PT[:, c][:,None] - PT
        p = [PTd[i] - PTd[r] for i in range(r)]
        y = Zd + G
        if mode == 'peri':
            tot = sum(np.minimum((y+p[i][None,:])*Li[i][:,None], (y+p[i][None,:])*Hi[i][:,None]) for i in range(r))
        elif mode == 'merged':
            pm = np.min(p, axis=0); L = sum(Li); H = sum(Hi)
            x = y + pm[None,:]
            tot = np.minimum(x*L[:,None], x*H[:,None])
        elif mode == 'trick':
            pmax = np.max(p, axis=0); H = sum(Hi); L = sum(Li)
            SHp = sum(Hi[i][:,None]*p[i][None,:] for i in range(r))
            tot = y*H[:,None] + SHp - np.maximum(0, y + pmax[None,:])*(H-L)[:,None]
        thr = (1 + sum(Hi))*eps
        dom = (Zd + tot) >= thr[:,None]
        flags &= ~dom
    return flags
for r, cs in [(1,[16]),(2,[36,46]),(2,[36,46,63]),(3,[4])]:
    for mode in ['peri','merged','trick']:
        f = bounds(r, cs, mode)
        print(r, cs, mode, np.bincount(f.sum(1)), 'union', np.where(f.any(0))[0])
