
import numpy as np, math, traceback, time
e = entries['v3c']
rng = np.random.default_rng(123)
inp = lv1.draw_inputs(info['data_set'], info['input_space'], 6000, rng)
inp2 = np.concatenate([np.array([[t,64,64,64] for t in range(64)]), np.array([[a,b,64,64] for a in range(64) for b in range(64)])])
allinp = np.concatenate([inp, inp2])
def test(name, w):
    try:
        gr = lv1.Graph(w, 4); refe = gr.entry(interpretation=model.reference(gr, lv1))
        ans, mops = lv1.run_reference(refe, w, 4, allinp)
        t0 = time.time()
        m = lv1.measure(e, w, 4, allinp, ans, mops)
        print(name, 'agree', m['n_agree'], '/', m['n_inputs'], 'cost', round(m['cost'],4), 'build', m['build_ops'], 'pred/inp', round(m['predict_ops']/len(allinp),1), 't', round(time.time()-t0,1))
    except Exception as ex:
        print(name, 'ERROR', repr(ex)[:300])
def gauss(scale, seed):
    r = np.random.default_rng(seed)
    w = {k: (r.normal(size=v.shape) * scale).astype(np.float64) for k, v in weights.items()}
    w['embed'][64] = 0
    return w
tests = [('orig', {k: v.copy() for k, v in weights.items()}),
         ('gauss0.1', gauss(0.1, 1)), ('gauss0.3', gauss(0.3, 2)), ('gauss1', gauss(1.0, 3)),
         ('perturbed', {k: v + np.random.default_rng(5).normal(size=v.shape)*0.05*np.abs(v).mean() for k, v in weights.items()})]
w = {k: np.random.default_rng(7).integers(-2, 3, size=v.shape).astype(np.float64) for k, v in weights.items()}; w['embed'][64] = 0
tests.append(('int', w))
w = {k: np.zeros(v.shape) for k, v in weights.items()}; tests.append(('zeros', w))
w = {k: v.copy().astype(np.float64) for k, v in weights.items()}; w['unembed'][:, 20] = w['unembed'][:, 16]; w['unembed'][:, 50] = w['unembed'][:, 4]; tests.append(('dupcols', w))
w = {k: v.copy().astype(np.float64) for k, v in weights.items()}; w['query'] *= 4; w['key'] *= 4; tests.append(('sharpattn', w))
w = {k: v.copy().astype(np.float64) for k, v in weights.items()}; w['value'] *= 5; tests.append(('bigvalue', w))
for name, w in tests:
    test(name, {k: np.asarray(v, dtype=np.float32) if weights[k].dtype == np.float32 else v for k, v in w.items()})
