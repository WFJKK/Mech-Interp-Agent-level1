
import math, numpy as np, traceback
SRC = r'''
import math
def build_entry(Ks={1:(3,),2:(2,5),3:(2,)}, pairs=((1,0),(2,0),(2,1),(3,0)), eps=1e-9, W=16, graph=graph, cp=None):
    g = graph(); g.diag = {}
    def ck(name):
        if cp is not None: cp.append((name, len(g.nodes)))
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64); arW = g.arange(W)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    UV = Un + VOU
    Zall = E @ UV; PZ = P @ UV
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMPt = (EM @ P.T).T; PMP = PM @ P.T
    Tt = [ET + PT[i] for i in range(4)]
    Tf = [Tt[i].reshape(4096) for i in range(4)]
    tab1 = (Zall + PZ[0]).argmax(axis=1)
    tok = [g.token(i) for i in range(4)]
    tok64 = [tok[i]*64 for i in range(4)]
    ck('tables')
    nb = len(pairs)
    rsel = g.const(np.array([1, 6, 11]))
    rmap = g.const(np.array([r - 1 for r, _ in pairs]))
    rrow = g.const(np.array([bi * 4 + r for bi, (r, _) in enumerate(pairs)]))
    roff = g.const(np.array([(r - 1) * 64 for r, _ in pairs]))
    maskf = g.const(np.array([[1. if i < r else 0. for i in range(3)] for r, _ in pairs]))[:, :, None]
    expA = lv1.exp(EME[None] + PME[1:4][:, None, :])         # [3, j, t]
    expB = lv1.exp(EMPt[None] + PMP[1:4][:, :, None])        # [3, i, j]
    er = expA.reshape(3, 4096)[:, ar*65] * lv1.take(expB.reshape(12, 64), rsel, 0)   # [3, j]
    scale = lv1.take(expB[:, :3] / er[:, None, :], rmap, 0) * maskf                   # [b, i, j]
    Hi = lv1.take(expA.max(axis=2), rmap, 0)[:, None, :] * scale
    Li = lv1.take(expA.min(axis=2), rmap, 0)[:, None, :] * scale
    H = Hi.sum(axis=1); L = Li.sum(axis=1)                                            # [b, j]
    Hn = H[:, :, None]; Dn = (H - L)[:, :, None]
    Z3 = Zall[None] + PZ[1:4][:, None, :]                                            # [3, j, k]
    Z3t = lv1.transpose(Z3, (0, 2, 1)).reshape(192, 64)                              # [(r,k), j]
    Z4 = lv1.take(Z3, rmap, 0)
    Y = Z4 - ET[None]
    ck('scores')
    am = Z3.argmax(axis=2)
    hist = (am[:, :, None] == ar).sum(axis=1)                  # [3, k]
    c1 = hist.argmax(axis=1)                                   # [3]
    cs = [c1]
    if any(ci == 1 for _, ci in pairs):
        cs.append((hist * (ar[None, :] != c1[:, None])).argmax(axis=1))
    c = lv1.concat([cs[ci][r-1:r] for r, ci in pairs])        # [b]
    ck('csel')
    Zc = lv1.take(Z3t, roff + c, 0)                        # [b, j]
    ETc = lv1.take(ET.T, c, 0)                             # [b, t]
    a = Zc - ETc
    Dmin = (ETc[:, :, None] - ET[None]).min(axis=1)        # [b, k]
    PTd = lv1.take(PT.T, c, 0)[:, :, None] - PT[None]      # [b, 4, k]
    p = PTd[:, :3] - lv1.take(PTd.reshape(4 * nb, 64), rrow, 0)[:, None, :]   # [b, 3, k]
    pmax = lv1.where(maskf > 0.5, p, -1e30).max(axis=1)    # [b, k]
    V = (a[:, :, None] + Dmin[:, None, :]) - Y              # [b, j, k]
    base = (Zc + (H + 1.0) * (-eps))[:, :, None] - Z4 + lv1.matmul(lv1.transpose(Hi, (0, 2, 1)), p)
    bound = base + Hn * V - Dn * lv1.maximum(V + pmax[:, None, :], 0.0)
    nd = ~(bound >= 0.0)
    parts = []
    for r in (1, 2, 3):
        bs = [bi for bi, (rr, _) in enumerate(pairs) if rr == r]
        f = nd[bs[0]:bs[0]+1]
        for bi in bs[1:]: f = f & nd[bi:bi+1]
        parts.append(f)
    flags = lv1.concat(parts)                                    # [3, j, k]
    ck('pass')
    colany = flags.sum(axis=1).sum(axis=0)                       # [k]
    kidx = lv1.argsort(ar + 64 * lv1.cast(colany == 0, 'int'))[:W]   # [W]
    sub = lv1.take(flags, kidx, 2)                               # [3, j, W]
    subcnt = sub.sum(axis=2)
    cnt = flags.sum(axis=2)
    cntx = subcnt + 100 * lv1.cast(cnt > subcnt, 'int')         # [3, j]
    ordW = lv1.argsort(arW + W * lv1.cast(~sub, 'int'), axis=2)  # [3, j, W]
    cand = lv1.take(kidx, ordW, 0)                               # [3, j, W]
    code = lv1.where(cntx == 1, cand[:, :, 0], -cntx)
    g.diag = dict(cntx=cntx, c=c, flags=flags, cand=cand, H=H, L=L, kidx=kidx)
    ck('order')
    out_r = {}
    for r in (1, 2, 3):
        ri = r - 1
        j = tok[r]
        f = code[ri][j]
        cj = -f
        eA = expA[ri]; eB = expB[ri]
        e = lv1.stack([eA[j, tok[i]] for i in range(r+1)]) * eB[:r+1, j]
        se = e.sum()
        ep = lv1.concat([e[:r], e[r:] - se])
        Zf = Z3[ri].reshape(4096); candr = cand[ri]
        def kpath(K):
            cands = candr[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok64[i] + cands) for i in range(r+1)])
            Zg = lv1.take(Zf, tok64[r] + cands)
            return cands[(ep @ Tg + Zg * se).argmax()]
        Trows = lv1.stack([Tt[i][tok[i]] for i in range(r+1)])
        res = (ep @ Trows + Z3[ri][j] * se).argmax()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        out_r[r] = lv1.cond(f >= 0, f, res)
        ck('r%d' % r)
    out = lv1.cond(tok[2] == 64, lv1.cond(tok[1] == 64, tab1[tok[0]], out_r[1]), lv1.cond(tok[3] == 64, out_r[2], out_r[3]))
    ck('out')
    return g, g.entry(interpretation=out)
'''
exec(SRC)
rng = np.random.default_rng(0)
inp = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
gr = graph(); refe = gr.entry(interpretation=model.reference(gr, lv1))
ans, mops = lv1.run_reference(refe, weights, 4, inp)
configs = {
 'A4': dict(pairs=((1,0),(2,0),(2,1),(3,0)), Ks={1:(3,),2:(2,5),3:(2,)}),
 'A4k3': dict(pairs=((1,0),(2,0),(2,1),(3,0)), Ks={1:(3,),2:(2,3,5),3:(2,)}),
 'A3': dict(pairs=((1,0),(2,0),(3,0)), Ks={1:(3,),2:(2,5),3:(2,)}),
 'A3k': dict(pairs=((1,0),(2,0),(3,0)), Ks={1:(3,),2:(2,4,6),3:(2,)}),
}
for name, cfg in configs.items():
    try:
        g, e = build_entry(**cfg)
        d = g.diag
        m = lv1.measure(e, weights, 4, inp, ans, mops)
        print(name, 'nodes', len(e['nodes']), 'c', d['c'].value, [np.bincount(d['cntx'].value[ri]).tolist() for ri in range(3)])
        print('   agree', m['n_agree'], 'build', m['build_ops'], 'pred/inp', m['predict_ops']/16384, 'cost', round(m['cost'],6))
        save_entry(name, e)
    except Exception:
        traceback.print_exc()
