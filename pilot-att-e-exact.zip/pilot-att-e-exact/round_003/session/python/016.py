
import math, numpy as np, traceback
from collections import Counter
SRC = r'''
import math
def build_entry(Ks={1:(3,),2:(2,5),3:(2,)}, eps=1e-9, W=8, graph=graph, second=(1,)):
    g = graph(); g.diag = {}
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq,Wk,Wv,Wo,Un = [g.weight(n) for n in ('query','key','value','out','unembed')]
    ar = g.arange(64); arW = g.arange(W); ar3 = g.arange(3)
    VOU = (Wv @ Wo) @ Un
    ET = E @ VOU; PT = P @ VOU
    UV = Un + VOU
    Zall = E @ UV; PZ = P @ UV
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; EME = EM @ E.T; PM = P @ M; PME = PM @ E.T; EMPt = (EM @ P.T).T; PMP = PM @ P.T
    Tf = [(ET + PT[i]).reshape(4096) for i in range(4)]
    tab1 = (Zall + PZ[0]).argmax(axis=1)
    tok = [g.token(i) for i in range(4)]
    tok64 = [tok[i]*64 for i in range(4)]
    rsel = g.const(np.array([1, 6, 11]))
    mask = g.const(np.array([[1.,0,0],[1,1,0],[1,1,1]]))
    expA = lv1.exp(EME[None] + PME[1:4][:, None, :])         # [3, j, t]
    expB = lv1.exp(EMPt[None] + PMP[1:4][:, :, None])        # [3, i, j]
    er = expA.reshape(3, 4096)[:, ar*65] * lv1.take(expB.reshape(12, 64), rsel, 0)   # [3, j]
    scale = expB[:, :3] / er[:, None, :] * mask[:, :, None]                          # [3, i, j]
    Hi = expA.max(axis=2)[:, None, :] * scale
    Li = expA.min(axis=2)[:, None, :] * scale
    H = Hi.sum(axis=1); L = Li.sum(axis=1); D = H - L                                # [3, j]
    Z3 = Zall[None] + PZ[1:4][:, None, :]                                            # [3, j, k]
    Z3t = lv1.transpose(Z3, (0, 2, 1)).reshape(192, 64)                              # [(r,k), j]
    Y = Z3 - ET[None]
    ZYH = Z3 + Y * H[:, :, None]; YD = Y * D[:, :, None]
    Zeh = -(1.0 + H) * eps
    def dompass(c, sl, rrow, roff):
        Zc = lv1.take(Z3t, roff + c, 0)                        # [b, j]
        ETc = lv1.take(ET.T, c, 0)                             # [b, t]
        a = Zc - ETc
        Dmin = (ETc[:, :, None] - ET[None]).min(axis=1)        # [b, k]
        PTd = lv1.take(PT.T, c, 0)[:, :, None] - PT[None]      # [b, 4, k]
        p = PTd[:, :3] - lv1.take(PTd.reshape(-1, 64), rrow, 0)[:, None, :]   # [b, 3, k]
        pmax = lv1.where(mask[sl][:, :, None] > 0.5, p, -1e30).max(axis=1)          # [b, k]
        AD = a[:, :, None] + Dmin[:, None, :]                   # [b, j, k]
        R = (Zc + Zeh[sl])[:, :, None] + H[sl][:, :, None] * AD + lv1.matmul(lv1.transpose(Hi[sl], (0, 2, 1)), p)
        QD = (AD + pmax[:, None, :]) * D[sl][:, :, None]
        bound = R - ZYH[sl] - lv1.maximum(QD - YD[sl], 0.0)
        return ~(bound >= 0.0)
    am = Z3.argmax(axis=2)
    c1 = (am[:, :, None] == ar).sum(axis=1).argmax(axis=1)     # [3]
    flags = dompass(c1, slice(0, 3), rsel, ar3 * 64)
    for b in second:
        sl = slice(b, b + 1)
        colsum = flags[sl].sum(axis=1)
        c2 = (colsum * (ar[None, :] != c1[sl][:, None])).argmax(axis=1)
        nd2 = dompass(c2, sl, g.const(np.array([b + 1])), b * 64)
        parts = [flags[:b], flags[sl] & nd2, flags[b+1:]]
        flags = lv1.concat([q for q, keep in zip(parts, (b > 0, True, b < 2)) if keep])
    colsum = flags.sum(axis=1)                                   # [3, k]
    kidx = lv1.argsort(ar[None, :] + 64 * lv1.cast(colsum == 0, 'int'), axis=1)[:, :W]   # [3, W]
    sub = lv1.transpose(lv1.take(lv1.transpose(flags, (0, 2, 1)).reshape(192, 64), (ar3 * 64)[:, None] + kidx, 0), (0, 2, 1))  # [3, j, W]
    subcnt = sub.sum(axis=2)
    cntx = subcnt + 100 * lv1.cast(flags.sum(axis=2) > subcnt, 'int')              # [3, j]
    ordW = lv1.argsort(arW + W * lv1.cast(~sub, 'int'), axis=2)                      # [3, j, W]
    cand = lv1.take(kidx.reshape(3 * W), (ar3 * W)[:, None, None] + ordW, 0)         # [3, j, W]
    first = lv1.where(cntx == 1, cand[:, :, 0], -1)
    g.diag = dict(cntx=cntx, c1=c1, flags=flags, cand=cand, H=H, L=L)
    out_r = {}
    for r in (1, 2, 3):
        ri = r - 1
        j = tok[r]
        f = first[ri][j]
        cj = cntx[ri][j]
        eA = expA[ri]; eB = expB[ri]
        e = lv1.stack([eA[j, tok[i]] for i in range(r+1)]) * eB[:r+1, j]
        se = e.sum()
        ep = lv1.concat([e[:r], e[r:] - se])
        Zf = Z3[ri].reshape(4096); candr = cand[ri]
        def kpath(K):
            cands = candr[:, :K][j]
            Tg = lv1.stack([lv1.take(Tf[i], tok64[i] + cands) for i in range(r+1)])
            Zg = lv1.take(Zf, tok64[r] + cands)
            return cands[(ep @ Tg + Zg * se).argmax()]
        Trows = lv1.stack([lv1.take(Tf[i], tok64[i] + ar) for i in range(r+1)])
        res = (ep @ Trows + Z3[ri][j] * se).argmax()
        for K in reversed(Ks[r]):
            res = lv1.cond(cj <= K, kpath(K), res)
        out_r[r] = lv1.cond(f >= 0, f, res)
    out = lv1.cond(tok[2] == 64, lv1.cond(tok[1] == 64, tab1[tok[0]], out_r[1]), lv1.cond(tok[3] == 64, out_r[2], out_r[3]))
    return g, g.entry(interpretation=out)
'''
exec(SRC)
try:
    g, e = build_entry()
    nodes = e['nodes']; print('nodes', len(nodes))
    print(Counter(str(n.get('op')) for n in nodes).most_common())
    d = g.diag
    print('c1', d['c1'].value, 'H', d['H'].value[:, :3], 'L', d['L'].value[:, :3])
    for ri in range(3):
        print(ri+1, 'cnt hist', np.bincount(d['cntx'].value[ri]), 'union', np.where(d['flags'].value[ri].any(0))[0], d['cand'].value[ri][:2])
    rng = np.random.default_rng(0)
    inp = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
    gr = graph(); refe = gr.entry(interpretation=model.reference(gr, lv1))
    ans, mops = lv1.run_reference(refe, weights, 4, inp)
    m = lv1.measure(e, weights, 4, inp, ans, mops); print(m)
except Exception:
    traceback.print_exc()
