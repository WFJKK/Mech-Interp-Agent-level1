
import numpy as np, math
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]
U = X @ Wu; T = X @ (Wv @ Wo @ Wu); M = Wq @ Wk.T / math.sqrt(32)
# S[r][i, j, t]
def S(r, i): return (X[r] @ M) @ X[i].T    # 64 (j) x 64 (t)
def dom_mask(r, c): 
    rows = T[:r].reshape(-1,64); Dmin = (rows[:,c][:,None] - rows).min(0)
    bound = (U[r][:,c][:,None]-U[r]) + np.minimum(T[r][:,c][:,None]-T[r], Dmin[None]); d = bound > 0; d[:, c] = False; return d
def dom_lp(r, c):
    # per-slot Dmin_i[k], box constraints on w via scores
    n = r+1
    ex = [np.exp(S(r,i)) for i in range(n)]       # j x t
    emax = np.stack([e.max(1) for e in ex[:r]] + [np.diag(ex[r])])   # n x j ; read slot exact
    emin = np.stack([e.min(1) for e in ex[:r]] + [np.diag(ex[r])])
    tot_max = emax.sum(0); tot_min = emin.sum(0)
    wmin = emin / (emin + (tot_max - emax))      # n x j
    wmax = emax / (emax + (tot_min - emin))
    D = np.stack([(T[i][:,c][:,None] - T[i]).min(0) for i in range(r)])   # r x k  (min over t)
    out = np.zeros((64,64),bool)
    for j in range(64):
        dr = T[r][j,c] - T[r][j]      # k
        d = np.concatenate([D, dr[None]], 0)   # n x k
        # greedy LP min
        lo = wmin[:,j]; hi = wmax[:,j]
        w = np.repeat(lo[:,None], 64, 1)
        m = 1 - lo.sum()
        order = np.argsort(d, axis=0)
        rem = np.full(64, m)
        for p in range(n):
            idx = order[p]
            cap = hi[idx] - lo[idx]
            add = np.minimum(cap, rem)
            w[idx, np.arange(64)] += add
            rem -= add
        val = (U[r][j,c] - U[r][j]) + (w*d).sum(0)
        out[j] = val > 0
    out[:, c] = False
    return out
for r, cl in [(1,[16]),(2,[46,36,63]),(3,[4])]:
    m1 = np.ones((64,64),bool); m2 = np.ones((64,64),bool)
    for c in cl: m1 &= ~dom_mask(r,c); m2 &= ~dom_lp(r,c)
    print(r, 'old', np.bincount(m1.sum(1)), 'lp', np.bincount(m2.sum(1)), m2.sum(1).mean())
