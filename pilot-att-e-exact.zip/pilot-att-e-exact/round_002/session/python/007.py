
print([a for a in dir(lv1) if not a.startswith('_')])
g = graph()
t = g.tokens()
E = g.weight('embed')
print(type(E), [a for a in dir(E) if not a.startswith('_')])
x = E[:64]
print(x.shape, x.value.shape)
import inspect
print(inspect.signature(lv1.take), inspect.signature(lv1.cond), inspect.signature(lv1.argsort))
print(inspect.signature(g.entry))
