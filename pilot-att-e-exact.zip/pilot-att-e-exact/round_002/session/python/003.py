
import numpy as np, math
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]            # 4 x 64 x 32 : slot i, token t
U = X @ Wu                                  # 4 x 64 x 64
T = X @ (Wv @ Wo @ Wu)                      # 4 x 64 x 64
M = Wq @ Wk.T / math.sqrt(32)
# first-stage candidate sets as before
def cands(r):
    rows = T[:r].reshape(-1,64)             # other slots rows
    mx = rows.max(0); mn = rows.min(0)
    Ur, Tr = U[r], T[r]
    UB = Ur + np.maximum(mx[None], Tr)
    LB = (Ur + np.minimum(mn[None], Tr)).max(1)
    return UB >= LB[:,None]
for r in [1,2,3]:
    m = cands(r); cnt = m.sum(1)
    print('r',r,'counts: mean',cnt.mean(),'max',cnt.max(),'n1',(cnt==1).sum(), 'hist', np.bincount(cnt))
# output frequencies from network_outputs
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
