
e = entries['v2b']
from collections import Counter
cnt = Counter(nd['op'] for nd in e['nodes'])
print(cnt)
print([ (nd['value'] if 'value' in nd else nd) for nd in e['nodes'] if nd['op']=='const'])
