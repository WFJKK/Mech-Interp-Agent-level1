
import numpy as np, math, json
def build(cs={1:[16],2:[46,36,63],3:[4]}, Ks={1:[3],2:[3,5],3:[2]}, eps=1e-9):
    g = graph()
    t = g.tokens()
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq, Wk, Wv, Wo, Wu = [g.weight(k) for k in ['query','key','value','out','unembed']]
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; PM = P @ M
    EME = EM @ E.T; EMP = EM @ P.T; PME = PM @ E.T; PMP = PM @ P.T
    VOU = (Wv @ Wo) @ Wu
    T = (E @ VOU)[None] + (P @ VOU)[:, None, :]
    U = (E @ Wu)[None] + (P @ Wu)[:, None, :]
    Tflat = T.reshape(16384); Uflat = U.reshape(16384)
    tab1 = (U[0] + T[0]).argmax(axis=1)
    ar = g.arange(64)[None]
    def branch_r(r):
        n = r + 1
        j = t[r]
        Ur = U[r]; Tr = T[r]
        # score tables S: (n, 64 j, 64 t)
        A = EME + PME[r][None, :]
        B = EMP.T[:n] + PMP[r, :n][:, None]
        S3 = A[None] + B[:, :, None]
        S = S3.reshape(n*4096)
        # attention weight box bounds per slot (n x 64 j)
        ex = lv1.exp(S3)
        emax = ex.max(axis=2); emin = ex.min(axis=2)          # n x 64 ; read slot: need diag
        diag = lv1.take((ex[r]).reshape(4096), g.arange(64)*65, axis=0)[None]   # 1 x 64
        emax = lv1.concat([emax[:r], diag], axis=0); emin = lv1.concat([emin[:r], diag], axis=0)
        smax = emax.sum(axis=0)[None]; smin = emin.sum(axis=0)[None]
        lo = emin / (emin + (smax - emax)); hi = emax / (emax + (smin - emin))   # n x 64(j)
        mask = None
        for c in cs[r]:
            dr = Tr[:, c][:, None] - Tr                                  # j x k
            val = (Ur[:, c][:, None] - Ur) + dr
            for i in range(r):
                Di = (T[i][:, c][:, None] - T[i]).min(axis=0)[None]      # 1 x k
                val = val + (Di - dr) * lv1.where(Di < dr, hi[i][:, None], lo[i][:, None])
            notdom = val <= eps
            mask = notdom if mask is None else (mask & notdom)
        cnt = lv1.cast(mask, 'int').sum(axis=1)
        order = lv1.argsort(lv1.where(mask, ar, ar + 64), axis=1)
        j64 = j * 64
        sidx = (g.arange(n) * 4096 + j64) + t[:n]
        w = lv1.softmax(lv1.take(S, sidx, axis=0), axis=0)
        trow = g.arange(n) * 4096 + t[:n] * 64
        ubase = r * 4096 + j64
        def kpath(K):
            cand = order[:, :K][j] if K < 64 else order[j]
            Tk = lv1.take(Tflat, trow[:, None] + cand[None, :], axis=0)
            logits = lv1.take(Uflat, ubase + cand, axis=0) + (w @ Tk)
            return cand[logits.argmax()]
        cj = cnt[j]
        res = kpath(64)
        for K in sorted(Ks[r], reverse=True):
            res = lv1.cond(cj <= K, kpath(K), res)
        res = lv1.cond(cj <= 1, order[:, 0][j], res)
        return res
    b1 = tab1[t[0]]
    b2 = branch_r(1); b3 = branch_r(2); b4 = branch_r(3)
    out = lv1.cond(t[1] == 64, b1, lv1.cond(t[2] == 64, b2, lv1.cond(t[3] == 64, b3, b4)))
    return g.entry(interpretation=out)
ent = build()
print(len(ent['nodes']))
m = measure(ent); print(m)
save_entry('v2b', ent)
