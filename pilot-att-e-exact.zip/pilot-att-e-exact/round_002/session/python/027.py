
import numpy as np, time
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(11)
shapes = info['weights']
def rw(scale, rng, integer=False):
    w = {}
    for k, s in shapes.items():
        a = rng.normal(0, scale, size=s)
        if integer: a = np.round(a*3)
        if k == 'embed': a[64] = 0
        w[k] = a
    return w
def rand_inputs(n, rng):
    xs = []
    for _ in range(n):
        k = rng.integers(1,5); x = np.full(4, 64); x[:k] = rng.integers(0,64,k); xs.append(x)
    return np.array(xs)
def test(ent, wts, xs, label=''):
    ans, ops = lv1.run_reference(ref, wts, 4, xs)
    m = lv1.measure(ent, wts, 4, xs, ans, ops)
    print(label, 'n', len(xs), 'fid', m['fidelity'], 'agree', m['n_agree'], 'cost', round(m['cost'],4))
for name in ['v2f', 'v2e']:
    ent = entries[name]; print(name)
    test(ent, weights, rand_inputs(6000, rng), 'this')
    xs2 = np.array([[a,b,64,64] for a in range(64) for b in range(64)]); test(ent, weights, xs2, 'n=2 all')
    xs1 = np.array([[a,64,64,64] for a in range(64)]); test(ent, weights, xs1, 'n=1 all')
    for sc in [0.1, 0.5, 1.0, 5.0, 30.0]:
        test(ent, rw(sc, rng), rand_inputs(1500, rng), f'gauss{sc}')
    test(ent, rw(1.0, rng, True), rand_inputs(1500, rng), 'int')
    test(ent, {k: np.zeros(s) for k,s in shapes.items()}, rand_inputs(300, rng), 'zeros')
    w2 = {k: v + rng.normal(0, 0.05, v.shape) for k,v in weights.items()}; w2['embed'][64]=0
    test(ent, w2, rand_inputs(1500, rng), 'perturbed')
