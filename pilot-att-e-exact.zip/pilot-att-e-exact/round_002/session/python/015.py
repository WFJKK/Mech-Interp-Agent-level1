
print(lv1.MAX_RANK, lv1.MAX_NODES, lv1.MAX_CONST_SCALARS, lv1.MAX_ELEMENTS)
g = graph()
print([a for a in dir(g) if not a.startswith('_')])
