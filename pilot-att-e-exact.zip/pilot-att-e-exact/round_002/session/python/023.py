
import numpy as np, time
ent = entries['v2c']
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(0)
def rand_inputs(n, rng):
    xs = []
    for _ in range(n):
        k = rng.integers(1,5); x = np.full(4, 64); x[:k] = rng.integers(0,64,k); xs.append(x)
    return np.array(xs)
def test(wts, n=3000, label=''):
    xs = rand_inputs(n, rng)
    ans, ops = lv1.run_reference(ref, wts, 4, xs)
    t0=time.time(); m = lv1.measure(ent, wts, 4, xs, ans, ops); 
    print(label, 'fid', m['fidelity'], 'cost', round(m['cost'],4), 'b', round(m['b'],4), 'r', round(m['r'],4), 't', round(time.time()-t0,1))
shapes = info['weights']
def rw(scale, rng, integer=False):
    w = {}
    for k, s in shapes.items():
        a = rng.normal(0, scale, size=s)
        if integer: a = np.round(a*3)
        if k == 'embed': a[64] = 0
        w[k] = a
    return w
test(weights, 4000, 'this')
test(rw(0.2, rng), label='gauss0.2')
test(rw(1.0, rng), label='gauss1.0')
test(rw(3.0, rng), label='gauss3.0')
test(rw(1.0, rng, True), label='int')
test({k: np.zeros(s) for k,s in shapes.items()}, 500, label='zeros')
w2 = {k: v + np.random.default_rng(5).normal(0, 0.05, v.shape) for k,v in weights.items()}; w2['embed'][64]=0
test(w2, label='perturbed')
