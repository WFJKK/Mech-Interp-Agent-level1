
import numpy as np, math, json
def build(cs={1:[16],2:[46,36,63],3:[4]}, Ks={1:[3],2:[2,5],3:[2]}, eps=1e-9, verbose=False):
    g = graph()
    nc = lambda: len(g.nodes)
    t = g.tokens()
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq, Wk, Wv, Wo, Wu = [g.weight(k) for k in ['query','key','value','out','unembed']]
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; PM = P @ M
    EME = EM @ E.T; EMPT = (EM @ P.T).T; PME = PM @ E.T; PMP = PM @ P.T
    AA = EME[None] + PME[:, None, :]                 # r x j x t
    BB = EMPT[None] + PMP[:, :, None]                # r x i x j
    VOU = (Wv @ Wo) @ Wu
    T = (E @ VOU)[None] + (P @ VOU)[:, None, :]
    U = (E @ Wu)[None] + (P @ Wu)[:, None, :]
    Tflat = T.reshape(16384); Uflat = U.reshape(16384)
    tab1 = (U[0] + T[0]).argmax(axis=1)
    ar = g.arange(64)[None]; ar64 = ar + 64
    dEP = lv1.take(EME.reshape(4096), g.arange(64) * 65, axis=0)[None] + PME    # r x j : diag of AA
    if verbose: print('shared', nc())
    def branch_r(r):
        n = r + 1
        c0 = nc()
        j = t[r]; tn = t[:n]
        Ur = U[r]; Tr = T[r]
        A = AA[r]                                      # 64 j x 64 t
        B = BB[r, :n]                                  # n x 64 j
        S = (A[None] + B[:, :, None]).reshape(n*4096)
        c1 = nc()
        Bo = B[:r]
        emax = lv1.exp(A.max(axis=1) + Bo); emin = lv1.exp(A.min(axis=1) + Bo)  # r x 64(j)
        diag = lv1.exp(dEP[r] + B[r])                  # 64
        smax = emax.sum(axis=0) + diag; smin = emin.sum(axis=0) + diag
        lo = emin / (emin + (smax - emax)); hi = emax / (emax + (smin - emin))   # r x 64(j)
        c2 = nc()
        C = g.const(np.array(cs[r], dtype=np.int64))
        TrC = lv1.take(Tr, C, axis=1).T[:, :, None]            # m x j x 1
        UrC = lv1.take(Ur, C, axis=1).T[:, :, None]
        dr = TrC - Tr[None]                                    # m x j x k
        val = (UrC - Ur[None]) + dr
        dr = dr[:, None]                                       # m x 1 x j x k
        To = T[:r]                                             # r x t x k
        Di = lv1.transpose(lv1.take(To, C, axis=2), (2, 0, 1))[:, :, :, None] - To[None]   # m x r x t x k
        Di = Di.min(axis=2)[:, :, None, :]                     # m x r x 1 x k
        term = (Di - dr) * lv1.where(Di < dr, hi[None, :, :, None], lo[None, :, :, None])   # m x r x j x k
        val = val + term.sum(axis=1)
        mask = ~((val > eps).any(axis=0))
        cnt = lv1.cast(mask, 'int').sum(axis=1)
        order = lv1.argsort(lv1.where(mask, ar, ar64), axis=1)
        c3 = nc()
        j64 = j * 64
        base = g.arange(n) * 4096
        w = lv1.softmax(lv1.take(S, (base + j64) + tn, axis=0), axis=0)
        trow = (base + tn * 64)[:, None]
        ubase = r * 4096 + j64
        c4 = nc()
        def kpath(K):
            if K < 64:
                cand = order[:, :K][j]
                Tk = lv1.take(Tflat, trow + cand[None, :], axis=0)
                logits = lv1.take(Uflat, ubase + cand, axis=0) + (w @ Tk)
                return cand[logits.argmax()]
            Tk = lv1.take(Tflat, trow + ar, axis=0)
            return (Ur[j] + (w @ Tk)).argmax()
        cj = cnt[j]
        res = kpath(64)
        for K in sorted(Ks[r], reverse=True):
            res = lv1.cond(cj <= K, kpath(K), res)
        res = lv1.cond(cj <= 1, order[:, 0][j], res)
        if verbose: print('r', r, 'S', c1-c0, 'lohi', c2-c1, 'dom', c3-c2, 'perinput', c4-c3, 'paths', nc()-c4)
        return res
    b1 = tab1[t[0]]
    b2 = branch_r(1); b3 = branch_r(2); b4 = branch_r(3)
    out = lv1.cond(t[1] == 64, b1, lv1.cond(t[2] == 64, b2, lv1.cond(t[3] == 64, b3, b4)))
    return g.entry(interpretation=out)
ent = build(verbose=True)
print(len(ent['nodes']))
m = measure(ent); print(m)
save_entry('v2d', ent)
