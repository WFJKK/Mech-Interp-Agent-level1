
def dom_mask(r, c):
    rows = T[:r].reshape(-1,64)
    Dmin = (rows[:,c][:,None] - rows).min(0)          # 64: min over other rows of T[.,c]-T[.,k]
    Ur, Tr = U[r], T[r]
    bound = (Ur[:,c][:,None]-Ur) + np.minimum(Tr[:,c][:,None]-Tr, Dmin[None])
    d = bound > 0
    d[:, c] = False
    return d
tops = {1:[16,47,3], 2:[46,36,63,0], 3:[4,57,24]}
for r in [1,2,3]:
    m0 = cands(r)
    for ncs in range(0,4):
        m = m0.copy()
        for c in tops[r][:ncs]:
            m &= ~dom_mask(r,c)
        cnt = m.sum(1)
        print('r',r,'ncs',ncs,'mean',cnt.mean(),'max',cnt.max(),'n1',(cnt==1).sum(),'hist',np.bincount(cnt))
