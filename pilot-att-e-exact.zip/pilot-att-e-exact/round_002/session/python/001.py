
import json
print(info.keys())
print({k: info[k] for k in info if k not in ('data',)})
print(list(entries.keys()))
e = entries['best']
print(type(e), (list(e.keys()) if isinstance(e, dict) else None))
print(measure(e))
# count nodes and look at build-heavy ops
nodes = e.get('nodes', e)
print(len(nodes) if hasattr(nodes,'__len__') else nodes)
print(json.dumps(e)[:3000])
