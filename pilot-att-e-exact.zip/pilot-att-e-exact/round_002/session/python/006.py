
import numpy as np, math
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]
U = X @ Wu; T = X @ (Wv @ Wo @ Wu); M = Wq @ Wk.T / math.sqrt(32)
def cands(r):
    rows = T[:r].reshape(-1,64); mx = rows.max(0); mn = rows.min(0); Ur, Tr = U[r], T[r]
    UB = Ur + np.maximum(mx[None], Tr); LB = (Ur + np.minimum(mn[None], Tr)).max(1)
    return UB >= LB[:,None]
def dom_mask(r, c):
    rows = T[:r].reshape(-1,64)
    Dmin = (rows[:,c][:,None] - rows).min(0)
    Ur, Tr = U[r], T[r]
    bound = (Ur[:,c][:,None]-Ur) + np.minimum(Tr[:,c][:,None]-Tr, Dmin[None])
    d = bound > 0; d[:, c] = False
    return d
tops = {1:[16,47,3], 2:[46,36,63,0], 3:[4,57,24]}
for r in [1,2,3]:
    m0 = cands(r)
    for ncs in range(0,4):
        m = m0.copy()
        for c in tops[r][:ncs]:
            m &= ~dom_mask(r,c)
        cnt = m.sum(1)
        print('r',r,'ncs',ncs,'mean',cnt.mean(),'max',cnt.max(),'n1',(cnt==1).sum(),'hist',np.bincount(cnt))
