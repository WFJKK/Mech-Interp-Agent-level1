
no = network_outputs()
ins, outs, ops = no
ins = np.array(ins); outs = np.array(outs)
print(ins.shape, outs.shape, ops)
n = (ins != 64).sum(1)
for k in [1,2,3,4]:
    o = outs[n==k]
    bc = np.bincount(o, minlength=64)
    top = np.argsort(-bc)[:6]
    print(k, [(int(t), round(bc[t]/len(o),3)) for t in top])
