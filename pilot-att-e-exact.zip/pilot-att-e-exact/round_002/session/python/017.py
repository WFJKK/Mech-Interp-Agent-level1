
import numpy as np, math, itertools
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]
U = X @ Wu; T = X @ (Wv @ Wo @ Wu); M = Wq @ Wk.T / math.sqrt(32)
def S(r, i): return (X[r] @ M) @ X[i].T
def dualmask(r, c):
    n = r+1
    ex = [np.exp(S(r,i)) for i in range(n)]
    emax = np.stack([e.max(1) for e in ex[:r]] + [np.diag(ex[r])]); emin = np.stack([e.min(1) for e in ex[:r]] + [np.diag(ex[r])])
    tot_max = emax.sum(0); tot_min = emin.sum(0)
    lo = emin / (emin + (tot_max - emax)); hi = emax / (emax + (tot_min - emin))
    dr = T[r][:,c][:,None] - T[r]
    val = (U[r][:,c][:,None] - U[r]) + dr
    for i in range(r):
        Di = (T[i][:,c][:,None] - T[i]).min(0)[None]
        val = val + (Di - dr) * np.where(Di < dr, hi[i][:,None], lo[i][:,None])
    d = val > 0; d[:, c] = False; return d
r = 2
masks = {c: dualmask(r, c) for c in range(64)}
def cost3(cl, Ks):
    m = np.ones((64,64),bool)
    for c in cl: m &= ~masks[c]
    cnt = m.sum(1)
    per = []
    for cj in cnt:
        if cj == 1: per.append(6)
        else:
            ks = [K for K in Ks if cj <= K]
            per.append(5 + (13+14*min(ks)) if ks else 5+720)
    return np.mean(per), np.bincount(cnt)
for cl in [[46],[36],[63],[46,36],[46,63],[36,63],[46,36,63],[46,36,63,0]]:
    best = min(((cost3(cl,[K]),K) for K in range(2,15)), key=lambda x:x[0][0])
    print(cl, best)
# best single/pair over all c
sing = sorted(((cost3([c],[K])[0],c,K) for c in range(64) for K in range(2,15)))[:3]; print(sing)
