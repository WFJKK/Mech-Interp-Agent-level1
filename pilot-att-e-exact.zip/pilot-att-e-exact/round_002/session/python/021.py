
import inspect
print(inspect.signature(lv1.measure)); print(inspect.signature(lv1.run_reference)); print(inspect.signature(lv1.draw_inputs)); print(inspect.signature(lv1.Graph.load)); print(inspect.signature(lv1.Evaluator))
print(inspect.getsource(lv1.measure)[:2500])
