
import numpy as np, time, itertools
ent = entries['v2c']
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(1)
shapes = info['weights']
def rw(scale, rng):
    w = {}
    for k, s in shapes.items():
        a = rng.normal(0, scale, size=s)
        if k == 'embed': a[64] = 0
        w[k] = a
    return w
def rand_inputs(n, rng):
    xs = []
    for _ in range(n):
        k = rng.integers(1,5); x = np.full(4, 64); x[:k] = rng.integers(0,64,k); xs.append(x)
    return np.array(xs)
def test(wts, xs, label=''):
    ans, ops = lv1.run_reference(ref, wts, 4, xs)
    m = lv1.measure(ent, wts, 4, xs, ans, ops)
    print(label, 'n', len(xs), 'fid', m['fidelity'], 'cost', round(m['cost'],4), 'r', round(m['r'],4))
for sc in [10, 30, 100]:
    test(rw(sc, rng), rand_inputs(2000, rng), f'gauss{sc}')
# exhaustive n=1, n=2 on this network
xs1 = np.array([[a,64,64,64] for a in range(64)]); test(weights, xs1, 'n=1 all')
xs2 = np.array([[a,b,64,64] for a in range(64) for b in range(64)]); test(weights, xs2, 'n=2 all')
xs3 = rand_inputs(6000, rng); xs3 = xs3[(xs3!=64).sum(1)>=3]; test(weights, xs3, 'n=3,4 rand')
