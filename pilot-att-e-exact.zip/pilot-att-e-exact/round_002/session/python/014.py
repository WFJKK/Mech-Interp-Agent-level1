
import numpy as np, math, json
def build(cs={1:[16],2:[46,36,63],3:[4]}, Ks={1:[3],2:[3,5],3:[2]}, eps=1e-9):
    g = graph()
    t = g.tokens()
    E = g.weight('embed')[:64]; P = g.weight('pos')
    Wq, Wk, Wv, Wo, Wu = [g.weight(k) for k in ['query','key','value','out','unembed']]
    M = (Wq @ Wk.T) * (1/math.sqrt(32))
    EM = E @ M; PM = P @ M
    EME = EM @ E.T; EMP = EM @ P.T; PME = PM @ E.T; PMP = PM @ P.T
    VOU = (Wv @ Wo) @ Wu
    T = (E @ VOU)[None] + (P @ VOU)[:, None, :]
    U = (E @ Wu)[None] + (P @ Wu)[:, None, :]
    Tflat = T.reshape(16384); Uflat = U.reshape(16384)
    tab1 = (U[0] + T[0]).argmax(axis=1)
    ar = g.arange(64)[None]
    diag_idx = g.arange(64) * 65
    def branch_r(r):
        n = r + 1
        j = t[r]
        Ur = U[r]; Tr = T[r]
        A = EME + PME[r][None, :]
        B = EMP.T[:n] + PMP[r, :n][:, None]
        S3 = A[None] + B[:, :, None]
        S = S3.reshape(n*4096)
        ex = lv1.exp(S3)
        exo = ex[:r]
        emax = exo.max(axis=2); emin = exo.min(axis=2)          # r x 64(j)
        diag = lv1.take(ex.reshape(n*4096), diag_idx + r*4096, axis=0)[None]   # 1 x 64
        smax = emax.sum(axis=0)[None] + diag; smin = emin.sum(axis=0)[None] + diag
        lo = emin / (emin + (smax - emax)); hi = emax / (emax + (smin - emin))   # r x 64(j)
        C = g.const(np.array(cs[r], dtype=np.int64))
        m = len(cs[r])
        TrC = lv1.take(Tr, C, axis=1).T[:, :, None]            # m x j x 1
        UrC = lv1.take(Ur, C, axis=1).T[:, :, None]
        dr = TrC - Tr[None]                                   # m x j x k
        val = (UrC - Ur[None]) + dr
        for i in range(r):
            Ti = T[i]
            Di = (lv1.take(Ti, C, axis=1).T[:, :, None] - Ti[None]).min(axis=1)[:, None, :]   # m x 1 x k
            val = val + (Di - dr) * lv1.where(Di < dr, hi[i][None, :, None], lo[i][None, :, None])
        mask = (val <= eps).all(axis=0)
        cnt = lv1.cast(mask, 'int').sum(axis=1)
        order = lv1.argsort(lv1.where(mask, ar, ar + 64), axis=1)
        j64 = j * 64
        base = g.arange(n) * 4096
        w = lv1.softmax(lv1.take(S, (base + j64) + t[:n], axis=0), axis=0)
        trow = (base + t[:n] * 64)[:, None]
        ubase = r * 4096 + j64
        def kpath(K):
            if K < 64:
                cand = order[:, :K][j]
                Tk = lv1.take(Tflat, trow + cand[None, :], axis=0)
                logits = lv1.take(Uflat, ubase + cand, axis=0) + (w @ Tk)
                return cand[logits.argmax()]
            Tk = lv1.take(Tflat, trow + ar, axis=0)
            return (Ur[j] + (w @ Tk)).argmax()
        cj = cnt[j]
        res = kpath(64)
        for K in sorted(Ks[r], reverse=True):
            res = lv1.cond(cj <= K, kpath(K), res)
        res = lv1.cond(cj <= 1, order[:, 0][j], res)
        return res
    b1 = tab1[t[0]]
    b2 = branch_r(1); b3 = branch_r(2); b4 = branch_r(3)
    out = lv1.cond(t[1] == 64, b1, lv1.cond(t[2] == 64, b2, lv1.cond(t[3] == 64, b3, b4)))
    return g.entry(interpretation=out)
ent = build()
print(len(ent['nodes']))
m = measure(ent); print(m)
save_entry('v2b', ent)
