
import numpy as np
g0 = graph(); ref = g0.entry(interpretation=model.reference(g0, lv1))
rng = np.random.default_rng(3)
def rand_inputs(n, rng):
    xs = []
    for _ in range(n):
        k = rng.integers(1,5); x = np.full(4, 64); x[:k] = rng.integers(0,64,k); xs.append(x)
    return np.array(xs)
ent = entries['v2f']
# duplicate unembed columns (exact ties) on this network's weights
w = {k: v.copy() for k,v in weights.items()}
w['unembed'][:, 20] = w['unembed'][:, 4]; w['unembed'][:, 30] = w['unembed'][:, 16]; w['unembed'][:, 50] = w['unembed'][:, 46]
xs = rand_inputs(3000, rng)
ans, ops = lv1.run_reference(ref, w, 4, xs); m = lv1.measure(ent, w, 4, xs, ans, ops); print('dup cols', m['fidelity'], m['n_agree'])
# tiny weights (all logits ~0, near ties)
w = {k: v*1e-3 for k,v in weights.items()}
ans, ops = lv1.run_reference(ref, w, 4, xs); m = lv1.measure(ent, w, 4, xs, ans, ops); print('tiny', m['fidelity'], m['n_agree'], round(m['cost'],3))
# small-integer weights -> many exact ties
w = {k: rng.integers(-1, 2, size=s).astype(float) for k,s in info['weights'].items()}; w['embed'][64]=0
ans, ops = lv1.run_reference(ref, w, 4, xs); m = lv1.measure(ent, w, 4, xs, ans, ops); print('int01', m['fidelity'], m['n_agree'], round(m['cost'],3))
