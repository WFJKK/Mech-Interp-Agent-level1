
import numpy as np, math
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]
U = X @ Wu; T = X @ (Wv @ Wo @ Wu); M = Wq @ Wk.T / math.sqrt(32)
def S(r, i): return (X[r] @ M) @ X[i].T
def dualmask(r, c, uselo=True, usehi=True):
    n = r+1
    ex = [np.exp(S(r,i)) for i in range(n)]
    emax = np.stack([e.max(1) for e in ex[:r]] + [np.diag(ex[r])]); emin = np.stack([e.min(1) for e in ex[:r]] + [np.diag(ex[r])])
    tot_max = emax.sum(0); tot_min = emin.sum(0)
    lo = emin / (emin + (tot_max - emax)); hi = emax / (emax + (tot_min - emin))
    if not uselo: lo = 0*lo
    if not usehi: hi = 0*hi + 1
    dr = T[r][:,c][:,None] - T[r]
    val = (U[r][:,c][:,None] - U[r]) + dr
    for i in range(r):
        Di = (T[i][:,c][:,None] - T[i]).min(0)[None]
        val = val + (Di - dr) * np.where(Di < dr, hi[i][:,None], lo[i][:,None])
    d = val > 0; d[:, c] = False; return d
for r, cl in [(1,[16]),(2,[46,36,63]),(3,[4])]:
    for ul, uh in [(True,True),(False,True),(True,False)]:
        m = np.ones((64,64),bool)
        for c in cl: m &= ~dualmask(r,c,ul,uh)
        print(r, 'lo' if ul else '--', 'hi' if uh else '--', np.bincount(m.sum(1)), round(m.sum(1).mean(),3))
