
import json
e = entries['best']
for i,nd in enumerate(e['nodes']):
    d = {k:v for k,v in nd.items() if k!='op'}
    print(i, nd['op'], json.dumps(d)[:150])
print('predict', e['predict'], 'rule', e['rule'])
