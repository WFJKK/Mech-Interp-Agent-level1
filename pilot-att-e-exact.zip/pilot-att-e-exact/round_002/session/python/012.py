
import numpy as np, math
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]
U = X @ Wu; T = X @ (Wv @ Wo @ Wu); M = Wq @ Wk.T / math.sqrt(32)
def S(r, i): return (X[r] @ M) @ X[i].T
def setup(r, c):
    n = r+1
    ex = [np.exp(S(r,i)) for i in range(n)]
    emax = np.stack([e.max(1) for e in ex[:r]] + [np.diag(ex[r])]); emin = np.stack([e.min(1) for e in ex[:r]] + [np.diag(ex[r])])
    tot_max = emax.sum(0); tot_min = emin.sum(0)
    lo = emin / (emin + (tot_max - emax)); hi = emax / (emax + (tot_min - emin))   # n x j
    D = np.stack([(T[i][:,c][:,None] - T[i]).min(0) for i in range(r)])   # r x k
    dr = T[r][:,c][:,None] - T[r]   # j x k
    d = np.concatenate([np.repeat(D[:,None,:],64,1), dr[None]], 0)   # n x j x k
    Ud = U[r][:,c][:,None] - U[r]
    return n, lo[:,:,None], hi[:,:,None], d, Ud
def dual(d, lo, hi, lam):   # lam: j x k
    return lam + ((d - lam[None]) * np.where(d < lam[None], hi, lo)).sum(0)
def variants(r, c):
    n, lo, hi, d, Ud = setup(r,c)
    res = {}
    res['old'] = Ud + np.minimum(d[r], d[:r].min(0))
    # w_r lower bound only
    wr = lo[r]
    res['wr'] = Ud + np.minimum(d[r], wr*d[r] + (1-wr)*d[:r].min(0))
    res['lam_r'] = Ud + dual(d, lo, hi, d[r])
    res['lam_min'] = Ud + dual(d, lo, hi, d.min(0))
    res['lam_max'] = Ud + dual(d, lo, hi, d.max(0))
    res['lp'] = Ud + np.max(np.stack([dual(d, lo, hi, d[p]) for p in range(n)]), 0)
    res['lp2'] = Ud + np.maximum(dual(d, lo, hi, d[r]), dual(d, lo, hi, d.min(0)))
    return res
for r, cl in [(1,[16]),(2,[46,36,63]),(3,[4])]:
    masks = {}
    for c in cl:
        v = variants(r,c)
        for k,b in v.items():
            dm = b > 0; dm[:,c] = False
            masks[k] = masks.get(k, np.ones((64,64),bool)) & ~dm
    for k,m in masks.items():
        print(r, k, np.bincount(m.sum(1)), round(m.sum(1).mean(),3))
