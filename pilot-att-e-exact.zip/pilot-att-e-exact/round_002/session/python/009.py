
import numpy as np, math
W = weights
E, P, Wq, Wk, Wv, Wo, Wu = [W[k] for k in ['embed','pos','query','key','value','out','unembed']]
X = E[None,:64,:] + P[:,None,:]
U = X @ Wu; T = X @ (Wv @ Wo @ Wu)
def cands(r):
    rows = T[:r].reshape(-1,64); mx = rows.max(0); mn = rows.min(0); Ur, Tr = U[r], T[r]
    UB = Ur + np.maximum(mx[None], Tr); LB = (Ur + np.minimum(mn[None], Tr)).max(1)
    return UB >= LB[:,None]
def dom_mask(r, c):
    rows = T[:r].reshape(-1,64)
    Dmin = (rows[:,c][:,None] - rows).min(0)
    Ur, Tr = U[r], T[r]
    bound = (Ur[:,c][:,None]-Ur) + np.minimum(Tr[:,c][:,None]-Tr, Dmin[None])
    d = bound > 0; d[:, c] = False
    return d
for r, cl in [(1,[16]),(1,[16,47]),(2,[46,36,63]),(2,[46,36]),(3,[4]),(3,[4,57])]:
    for fs in [True, False]:
        m = cands(r) if fs else np.ones((64,64),bool)
        for c in cl: m &= ~dom_mask(r,c)
        cnt = m.sum(1)
        print(r, cl, 'first' if fs else 'nofirst', 'mean',cnt.mean(),'max',cnt.max(),'hist',np.bincount(cnt))
