
import numpy as np
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
