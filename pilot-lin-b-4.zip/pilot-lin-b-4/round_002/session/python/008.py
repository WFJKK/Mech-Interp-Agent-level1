
import numpy as np
X, Y, ops = network_outputs()
X=np.asarray(X); Y=np.asarray(Y); print(X.shape, Y.shape, ops, info['check'], info['sample_size'])
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M = U @ H @ E[:, :64]
L = M[:, X[:,0]] + M[:, X[:,1]] + M[:, X[:,2]] + M[:, X[:,3]]
mine = L.argmax(0)
print("disagree enumeration-vs-network_outputs:", (mine!=Y).sum())
pred = np.maximum(X.max(1), 10)
print("errors of pred vs Y:", (pred!=Y).sum(), " vs mine:", (pred!=mine).sum())
# margins
Ls = np.sort(L, axis=0); margin = Ls[-1]-Ls[-2]
print("min margin", margin.min(), "count margin<1e-6", (margin<1e-6).sum())
print(weights['embed'].dtype)
