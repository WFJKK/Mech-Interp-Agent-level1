
import numpy as np, itertools, math
from collections import Counter
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M = U @ H @ E[:, :64]
toks = np.array(list(itertools.combinations_with_replacement(range(64),4)))
logits = M[:, toks[:,0]] + M[:, toks[:,1]] + M[:, toks[:,2]] + M[:, toks[:,3]]
out = logits.argmax(0)
def nperm(r):
    c=Counter(r); d=24
    for v in c.values(): d//=math.factorial(v)
    return d
w = np.array([nperm(r) for r in toks]); tot=w.sum()
mx = toks[:,3]
for c in range(6,14):
    print(c, (w*(out!=np.maximum(mx,c))).sum()/tot)
print("single column argmax:", M.argmax(0)[:16])
print("all-equal outputs:", [int(np.argmax(4*M[:,t])) for t in range(16)])
# error table for small max: what does the net output when max = k, k in 8..13
for k in range(8,14):
    sel = mx==k
    d=Counter()
    for i in np.where(sel)[0]: d[int(out[i])]+=w[i]
    print(k, sorted(d.items()))
