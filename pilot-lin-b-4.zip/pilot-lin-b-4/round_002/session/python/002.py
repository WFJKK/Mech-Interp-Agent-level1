
ei = np.where(err)[0]
pat = Counter()
for i in ei:
    r = toks[i]; key=(int(mx[i]-r[2]), int(mx[i]-r[1]), int(mx[i]-r[0]) if mx[i]-r[0]<12 else 99, int(out[i]-mx[i]))
    pat[key]+= w[i]
tot=w.sum()
acc=0
for k,v in pat.most_common(40):
    acc+=v; print(k, v/tot, acc/tot)
# error by max value
bym = Counter()
for i in ei: bym[int(mx[i])]+=w[i]
print(sorted((k, round(v/tot*1e5,1)) for k,v in bym.items()))
