
import numpy as np, itertools, math
from collections import Counter
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M = U @ H @ E[:, :64]
toks = np.array(list(itertools.combinations_with_replacement(range(64),4)))
logits = M[:, toks[:,0]] + M[:, toks[:,1]] + M[:, toks[:,2]] + M[:, toks[:,3]]
out = logits.argmax(0)
def nperm(r):
    c=Counter(r); d=24
    for v in c.values(): d//=math.factorial(v)
    return d
w = np.array([nperm(r) for r in toks]); tot=w.sum()
mx = toks[:,3]; pred = np.maximum(mx,10); err = out!=pred
ei = np.where(err)[0]
pat = Counter()
for i in ei:
    r = toks[i]; key=(int(mx[i]-r[2]), int(mx[i]-r[1]), int(mx[i]-r[0]) if mx[i]-r[0]<12 else 99, int(out[i]-mx[i]))
    pat[key]+= w[i]
acc=0
for k,v in pat.most_common(40):
    acc+=v; print(k, round(v/tot*1e5,2), round(acc/tot*1e5,1))
bym = Counter()
for i in ei: bym[int(mx[i])]+=w[i]
print(sorted((k, round(v/tot*1e5,1)) for k,v in bym.items()))
# second-order: output relative to max
print(Counter({int(out[i]-mx[i]): 0 for i in ei}))
d=Counter()
for i in ei: d[int(out[i]-mx[i])]+=w[i]
print(sorted((k, round(v/tot*1e5,1)) for k,v in d.items()))
