
import numpy as np, itertools, math
from collections import Counter
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
M = U @ H @ E[:, :64]
toks = np.array(list(itertools.combinations_with_replacement(range(64),4)))
logits = M[:, toks[:,0]] + M[:, toks[:,1]] + M[:, toks[:,2]] + M[:, toks[:,3]]
out = logits.argmax(0)
def nperm(r):
    c=Counter(r); d=24
    for v in c.values(): d//=math.factorial(v)
    return d
w = np.array([nperm(r) for r in toks]); tot=w.sum()
mx = toks[:,3]
ca = M.argmax(0)
def rate(T): return (w*(out!=T[mx])).sum()/tot
k=np.arange(64)
print("T=argmax col", rate(ca))
for n in [2,4,8,12,16]:
    c = ca[:n].min(); print("min argmax over first",n,"cols =",c, rate(np.maximum(k,c)))
# smoothed: argmax of M[:,k]+M[:,k-1]... no. Alternative: argmax of sum of columns 0..n-1 (uniform small input)
for n in [4,8,11,16]:
    c = M[:, :n].sum(1).argmax(); print("argmax of sum of cols <",n, c, rate(np.maximum(k,c)))
# what does M look like: print M[:,20] rounded
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print(M[:,20]); print(M[:,40]); print(M[:,5])
