
import numpy as np, itertools, math
E=weights['embed']; H=weights['hidden']; U=weights['unembed']
print({k:v.shape for k,v in weights.items()}, info.keys())
M = U @ H @ E[:, :64]   # 64x64, logits = sum_i M[:, t_i]
# enumerate all sorted 4-multisets
toks = np.array(list(itertools.combinations_with_replacement(range(64),4)))  # sorted ascending
n=len(toks)
logits = M[:, toks[:,0]] + M[:, toks[:,1]] + M[:, toks[:,2]] + M[:, toks[:,3]]
out = logits.argmax(0)
# weights = number of orderings
from collections import Counter
def nperm(r):
    c=Counter(r); d=24
    for v in c.values(): d//=math.factorial(v)
    return d
w = np.array([nperm(r) for r in toks])
mx = toks[:,3]; pred = np.maximum(mx,10)
err = out!=pred
print("err rate", (w*err).sum()/w.sum())
# statistics
spread = mx - toks[:,0]
def4 = 4*mx - toks.sum(1)
gap3 = mx - toks[:,1]   # max - 3rd largest (second smallest)
gap2 = mx - toks[:,2]
for K in range(0,30):
    r_sp = (w*(err&(spread<=K))).sum()/w.sum(); p_sp=(w*(spread<=K)).sum()/w.sum()
    r_d = (w*(err&(def4<=K))).sum()/w.sum(); p_d=(w*(def4<=K)).sum()/w.sum()
    r_g = (w*(err&(gap3<=K))).sum()/w.sum(); p_g=(w*(gap3<=K)).sum()/w.sum()
    print(K, f"spread: caught {r_sp:.5f} p {p_sp:.4f} | def4: caught {r_d:.5f} p {p_d:.4f} | gap3: caught {r_g:.5f} p {p_g:.4f}")
