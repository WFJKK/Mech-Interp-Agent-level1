
g = graph()
t = g.tokens()
m = t.max()
E = g.weight("embed"); H = g.weight("hidden"); U = g.weight("unembed")
small = U @ (H @ E[:, 0:8])      # logits of the 8 smallest single tokens, 64 x 8
c = small.argmax(axis=0).min()   # weight-derived floor (10 on this network)
print("floor", c.value)
e1 = g.entry(interpretation=lv1.maximum(m, c))
save_entry("max_floor_w", e1)
print(measure(e1))
# constant version for comparison
g2 = graph(); m2 = g2.tokens().max()
e2 = g2.entry(interpretation=lv1.maximum(m2, 10))
print(measure(e2))
print(measure(entries['best']))
