# Run pilot-lin-b-4

- Model models/lin-b-4, rounds on lin-b-4-s0, seed check on lin-b-4-s1.
- Agent: claude-fable-5-1 at effort high, through the claude_code backend.
- Data set: 16,777,216 inputs, 16,384 drawn afresh for each scoring. One forward pass: 671 operations (prices-v1).
- Reward: r_alpha, alpha = 10.
- Sandbox: seatbelt.
- The rounds ended: rounds_max (5) reached.

## The locked entry

Submission r4s3 (saved as `best`), 11 nodes, 0 numbers in constants, sha256 `914b2c9a8f0b1dfd`.

| Network | Reward | Coverage | Fidelity | Cost | Fidelity claimed |
| --- | --- | --- | --- | --- | --- |
| lin-b-4-s0 (the rounds) | 0.9808 | 1.0000 | 0.99927 | 0.0064 | 0.99890 |
| lin-b-4-s0 (measured again, on a fresh sample) | 0.9740 | 1.0000 | 0.99872 | 0.0064 | 0.99890 |
| lin-b-4-s1 (the seed check) | 0.9800 | 1.0000 | 0.99921 | 0.0064 | 0.99800 |

The first row is the best of several scorings, each on its own sample, so it leans high; the second row is one more scoring of the same entry.

```
n0 = tokens()
n1 = max(n0, axis=null)
n2 = weight(name="embed")
n3 = weight(name="hidden")
n4 = weight(name="unembed")
n5 = slice(n2, index=[null, {"start": 0, "step": null, "stop": 8}])
n6 = matmul(n3, n5)
n7 = matmul(n4, n6)
n8 = argmax(n7, axis=0)
n9 = min(n8, axis=null)
n10 = maximum(n1, n9)   <- interpretation
```

## Against the baseline

The baseline run pilot-lin-f-4-exact-0d0a5407 froze r5s3, which **passes** the check on its model's other networks (it gave the network's output on every input of its region on all 4 networks). Its agent was given the same first prompt as this run's, byte for byte, but for the paragraph that asks for an entry exact for any weights: yes.

| | On lin-b-4-s0 (this run's network) | On lin-b-4-s1 (held out) |
| --- | --- | --- |
| The locked entry | 0.9740 to 0.9852 | 0.9800 to 0.9889 |
| The baseline, on the same inputs | 0.8239 to 0.8263 | 0.8272 to 0.8295 |
| The locked entry above the baseline | +0.1500 | +0.1528 |

| Part | Reward | With the sampling intervals |
| --- | --- | --- |
| The baseline on this run's network | 0.8239 | 0.8239 to 0.8263 |
| The excess kept on the held-out network | +0.1528 | +0.1505 to +0.1618 |
| The gap between this run's network and the held-out one | -0.0028 | -0.0141 to +0.0108 |
| Together: the locked entry on this run's network | 0.9740 | |

Each number is measured on the same inputs as the locked entry's own: its second scoring, on a fresh sample, and the seed check. The baseline's entry is exact on both, so it differs from the locked entry there only in what it costs and in what the locked entry gets wrong. This is accounting, not a causal split. The baseline is a generic score an agent reached, not the best possible one, so the excess can hold generic tricks the baseline run did not find as well as what the networks learned; and the gap can be sampling noise or a difference between the two networks as well as fitting this run's own network.

## Reference entries

Scored here for comparison. They are withheld from the agent. Each number is the mean of 8 scorings on fixed samples. The task: The network was trained to output the largest of its four tokens (max of 4), on inputs of exactly four tokens and on nothing else, and here it is asked about exactly those inputs: the data set is what it was trained on. The agent is told the data set in full, as for every model (four tokens, no empty slot), but not what the network was trained to do.


| Entry | Network | Reward | Coverage | Fidelity | Cost | Reward, highest less lowest |
| --- | --- | --- | --- | --- | --- | --- |
| contraction | lin-b-4-s0 | 0.5188 | 1.0000 | 1.00000 | 0.4788 | 0.0000 |
| contraction | lin-b-4-s1 | 0.5188 | 1.0000 | 1.00000 | 0.4788 | 0.0000 |
| target_everywhere | lin-b-4-s0 | 0.9707 | 1.0000 | 0.99828 | 0.0045 | 0.0108 |
| target_everywhere | lin-b-4-s1 | 0.9649 | 1.0000 | 0.99778 | 0.0045 | 0.0149 |
| the network itself | lin-b-4-s0 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| the network itself | lin-b-4-s1 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |

## Rounds

| Round | Submissions | Best reward so far | Raised it | Ended with | Tool calls | Minutes | Output tokens | Programs run | Sandbox minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 0.9752 | yes | end_turn | 9 run_python, 1 submit_entry | 2.9 | 11,433 | 9 | 0.1 |
| 2 | 4 | 0.9770 | yes | end_turn | 8 run_python, 4 submit_entry | 6.0 | 24,044 | 8 | 0.1 |
| 3 | 4 | 0.9785 | yes | end_turn | 6 run_python, 4 submit_entry | 3.7 | 14,934 | 6 | 0.2 |
| 4 | 4 | 0.9808 | yes | end_turn | 1 run_python, 4 submit_entry | 0.8 | 3,134 | 1 | 0.0 |
| 5 | 4 | 0.9808 | no | end_turn | 1 run_python, 4 submit_entry | 0.5 | 1,930 | 1 | 0.0 |

The rounds were billed to an API key: $4.31 by Claude Code's count.

## What the agent ran

Every program is kept in full in its round's `session/python/` folder, with what it got back; the round's `response.md` has what the agent wrote, and `stream_NN.jsonl` everything the CLI emitted.

The guard inside Python refused nothing: no program tried to reach files outside its folder, the network or other programs.

No program's text reaches for files or the system.

## Submissions

Cost: everything the entry computes, per input of its region, over one forward pass. Right and wrong: the share of the inputs the entry answers rightly and wrongly. On the frontier: no other submission is at least as good in right share, wrong share and cost, and better in one. On the second network: the reward and the fidelity of the same entry on the seed check's network, every submission on one fixed sample, scored after its round; the agent never saw these, and they chose nothing.

| Entry | Saved as | Reward | Coverage | Fidelity | Cost | Right | Wrong | On the frontier | Claimed | Overclaim | On the second network | Fidelity there |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | `max_floor10` | 0.9752 | 1.0000 | 0.99878 | 0.0060 | 0.9988 | 0.00122 | yes | 0.99890 | 0.00012 | 0.9651 | 0.99792 |
| r2s1 | `max_floor_w` | 0.9725 | 1.0000 | 0.99860 | 0.0064 | 0.9986 | 0.00140 | no | 0.99890 | 0.00030 | 0.9762 | 0.99890 |
| r2s2 | `max_floor_w` | 0.9718 | 1.0000 | 0.99854 | 0.0064 | 0.9985 | 0.00146 | no | 0.99890 | 0.00036 | 0.9762 | 0.99890 |
| r2s3 | `max_floor_w` | 0.9770 | 1.0000 | 0.99896 | 0.0064 | 0.9990 | 0.00104 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r2s4 | `max_floor_w` | 0.9747 | 1.0000 | 0.99878 | 0.0064 | 0.9988 | 0.00122 | no | 0.99890 | 0.00012 | 0.9762 | 0.99890 |
| r3s1 | `best` | 0.9785 | 1.0000 | 0.99908 | 0.0064 | 0.9991 | 0.00092 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r3s2 | `best` | 0.9762 | 1.0000 | 0.99890 | 0.0064 | 0.9989 | 0.00110 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r3s3 | `best` | 0.9762 | 1.0000 | 0.99890 | 0.0064 | 0.9989 | 0.00110 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r3s4 | `best` | 0.9785 | 1.0000 | 0.99908 | 0.0064 | 0.9991 | 0.00092 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r4s1 | `best` | 0.9762 | 1.0000 | 0.99890 | 0.0064 | 0.9989 | 0.00110 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r4s2 | `best` | 0.9770 | 1.0000 | 0.99896 | 0.0064 | 0.9990 | 0.00104 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r4s3 | `best` | 0.9808 | 1.0000 | 0.99927 | 0.0064 | 0.9993 | 0.00073 | yes | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r4s4 | `best` | 0.9740 | 1.0000 | 0.99872 | 0.0064 | 0.9987 | 0.00128 | no | 0.99890 | 0.00018 | 0.9762 | 0.99890 |
| r5s1 | `best` | 0.9785 | 1.0000 | 0.99908 | 0.0064 | 0.9991 | 0.00092 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r5s2 | `best` | 0.9755 | 1.0000 | 0.99884 | 0.0064 | 0.9988 | 0.00116 | no | 0.99890 | 0.00006 | 0.9762 | 0.99890 |
| r5s3 | `best` | 0.9762 | 1.0000 | 0.99890 | 0.0064 | 0.9989 | 0.00110 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |
| r5s4 | `best` | 0.9770 | 1.0000 | 0.99896 | 0.0064 | 0.9990 | 0.00104 | no | 0.99890 | 0.00000 | 0.9762 | 0.99890 |

On the second network the best submission was r2s1 (`max_floor_w`), 0.9762; the locked entry, r4s3, scored 0.9762 there on the same sample.

## The agent's closing notes

> ## What the network does
> The network computes the **maximum of its four tokens**, with a floor of 10. Logits are linear in the summed embeddings: output = argmax_o Σᵢ M[o, tᵢ] with M = unembed·hidden·embed (64×64), whose columns peak at o = t over a broad ramp. Exact enumeration of all 766,480 sorted 4-multisets (weighted by orderings, done in rounds 1–3) shows `max(max_token, 10)` is right on 99.889% of inputs (error 0.00111). The floor exists because every single-token column M[:, t] for t ≤ 10 has argmax 10 or 11, so the network never answers below 10. The residual errors are diffuse and depend on all four tokens: 57% are output max−1 (second token equal to max−1 or clustered 3–10 below), 15% max−2, ~20% max+1…max+4 (two tokens tied 4–7 below max). No cheap statistic (max, 4·max−sum, second-largest, min, duplicate max, spread) separates them. Very sure (full enumeration; this round's verifier samples: 15–19 errors per 16,384, consistent with 18.2 expected).
> 
> ## How you found it
> Rounds 1–3: both weights and outputs — built M from the weights, enumerated every multiset, compared with candidate rules, tabulated conditional error rates by cheap statistics, computed best-achievable errors for table rules, costed every alternative (1 op ≈ 0.0015 reward; removing all errors is worth ≈ 0.0137 ≈ 9 ops, including the Wilson 95% lower-bound shrinkage). This round: confirmed `measure(best)` (fidelity 0.99902 on the fixed sample, cost 0.0064) and spent all four submissions re-drawing the same entry.
> 
> ## The best entry
> `best` (= `max_floor_w`): region = every input; interpretation = `maximum(tokens.max(), c)` where c is computed from the weights at build: c = min over t∈0..7 of argmax(unembed @ (hidden @ embed[:, t])) — the smallest answer the network gives to single small tokens (= 10 here). Cost 4 ops per input + 5119 build ops once (0.0064 of a forward pass). The saving is the 671-op forward pass replaced by a 3-op max and a 1-op floor. Rewards this round: 0.9785, 0.9755, 0.9762, 0.9770; best across all rounds remains 0.9808 (round 4, submission 3).
> 
> ## Claims
> Claimed 0.9989 on this network (exact enumerated 0.99889; measured this round 0.99908, 0.99884, 0.99890, 0.99896 — all within sampling noise; one draw gave a negligible overclaim of 0.00006). Expected 0.998 on the second network: it should likewise compute max with a small floor, and the floor is read off that network's own weights (min of single-token argmaxes over tokens 0–7), so only the diffuse clustered-token errors (~0.1–0.2%) should remain.
> 
> ## Next
> Nothing structural remains: the entry is at the cost/fidelity optimum for this reward (no statistic cheaper than the logits separates the errors; every exact branch costs more ops than the fidelity it buys). Reward differences between draws (±0.003) are purely sampling noise of the verifier; the locked entry is the 0.9808 draw of `best`.
