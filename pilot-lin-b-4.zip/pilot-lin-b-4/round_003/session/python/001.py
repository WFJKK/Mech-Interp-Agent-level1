
import numpy as np, itertools
E,H,U = weights['embed'],weights['hidden'],weights['unembed']
M = U@H@E[:, :64]   # 64 x 64, M[o,t]
print(info)
# enumerate all sorted multisets
from math import factorial
from collections import Counter
rows=[]
for c in itertools.combinations_with_replacement(range(64),4):
    cnt=Counter(c); w=24
    for v in cnt.values(): w//=factorial(v)
    rows.append((c,w))
C=np.array([r[0] for r in rows]); W=np.array([r[1] for r in rows])
L=M[:,C[:,0]]+M[:,C[:,1]]+M[:,C[:,2]]+M[:,C[:,3]]
out=L.argmax(0)
mx=C.max(1)
pred=np.maximum(mx,10)
err=(out!=pred)
print("err rate", (W*err).sum()/W.sum())
# errors by output - max
print(Counter(zip((out-mx)[err], ))) 
d=out-mx
for k in sorted(set(d[err])): print(k, W[err&(d==k)].sum()/W.sum())
