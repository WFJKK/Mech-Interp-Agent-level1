
import numpy as np, itertools
from math import factorial
from collections import Counter
E,H,U = weights['embed'],weights['hidden'],weights['unembed']
M = U@H@E[:, :64]
rows=[]
for c in itertools.combinations_with_replacement(range(64),4):
    cnt=Counter(c); w=24
    for v in cnt.values(): w//=factorial(v)
    rows.append((c,w))
C=np.array([r[0] for r in rows]); W=np.array([r[1] for r in rows])
L=M[:,C[:,0]]+M[:,C[:,1]]+M[:,C[:,2]]+M[:,C[:,3]]
out=L.argmax(0); mx=C.max(1); pred=np.maximum(mx,10); err=(out!=pred); tot=W.sum(); toterr=(W*err).sum()
S=np.sort(C,1)
# rule: any token == m-1 -> m-1 ; evaluate net effect
has=(S[:,2]==mx-1)
new=np.where(has, mx-1, pred); new=np.maximum(new,10)
print("errors with rule any==m-1:", (W*(out!=new)).sum()/tot, " share has:", W[has].sum()/tot, " condErr in has:", W[has&err].sum()/W[has].sum())
# duplicated max
dup=(S[:,2]==mx)
print("dup max share", W[dup].sum()/tot, "condErr", W[dup&err].sum()/W[dup].sum())
# D-table decision m vs m-1 exact: how many errors fixed
Dsum=L[mx, np.arange(len(mx))]-L[np.maximum(mx-1,0), np.arange(len(mx))]
new2=np.where(Dsum<0, mx-1, mx); new2=np.maximum(new2,10)
print("errors with exact m vs m-1:", (W*(out!=new2)).sum()/tot)
