
import numpy as np
E,H,U = weights['embed'],weights['hidden'],weights['unembed']
M = U@H@E[:, :64]
print("col argmax", M.argmax(0)[:20])
# singular values of M
print(np.linalg.svd(M,compute_uv=False)[:8].round(2))
import json
g, interp, region = lv1.Graph.load(entries['best'], weights, info['sizes']['n_ctx'])
print(json.dumps(entries['best'])[:1500])
print(measure(entries['best']))
