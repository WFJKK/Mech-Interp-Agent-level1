
import numpy as np, itertools
from math import factorial
from collections import Counter
E,H,U = weights['embed'],weights['hidden'],weights['unembed']
M = U@H@E[:, :64]
rows=[]
for c in itertools.combinations_with_replacement(range(64),4):
    cnt=Counter(c); w=24
    for v in cnt.values(): w//=factorial(v)
    rows.append((c,w))
C=np.array([r[0] for r in rows]); W=np.array([r[1] for r in rows])
L=M[:,C[:,0]]+M[:,C[:,1]]+M[:,C[:,2]]+M[:,C[:,3]]
out=L.argmax(0); mx=C.max(1); pred=np.maximum(mx,10); err=(out!=pred)
tot=W.sum(); toterr=(W*err).sum()
s=C.sum(1); r=4*mx-s
cum_w=0;cum_e=0
for k in range(0,30):
    sel=(r==k); w=W[sel].sum(); e=W[sel&err].sum()
    cum_w+=w;cum_e+=e
    print(k, "share %.5f condErr %.4f  cumShare %.5f cumErrShare %.3f"%(w/tot, e/max(w,1), cum_w/tot, cum_e/toterr))
# by max value: conditional error
print("by max:")
for m in range(64):
    sel=mx==m; w=W[sel].sum(); e=W[sel&err].sum()
    if e: print(m, "share %.5f condErr %.4f"%(w/tot, e/w))
