
s=C.sum(1); r=4*mx-s
tot=W.sum()
cum_w=0;cum_e=0
for k in range(0,40):
    sel=(r==k); w=W[sel].sum(); e=W[sel&err].sum()
    cum_w+=w;cum_e+=e
    print(k, "share %.5f condErr %.4f  cumShare %.5f cumErrShare %.3f"%(w/tot, e/max(w,1), cum_w/tot, cum_e/(W*err).sum()))
