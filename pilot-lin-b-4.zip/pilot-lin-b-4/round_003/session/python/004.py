
import numpy as np, itertools
from math import factorial
from collections import Counter
E,H,U = weights['embed'],weights['hidden'],weights['unembed']
M = U@H@E[:, :64]
rows=[]
for c in itertools.combinations_with_replacement(range(64),4):
    cnt=Counter(c); w=24
    for v in cnt.values(): w//=factorial(v)
    rows.append((c,w))
C=np.array([r[0] for r in rows]); W=np.array([r[1] for r in rows])
L=M[:,C[:,0]]+M[:,C[:,1]]+M[:,C[:,2]]+M[:,C[:,3]]
out=L.argmax(0); mx=C.max(1); tot=W.sum()
# per-m majority
T=np.zeros(64,int)
for m in range(64):
    sel=mx==m
    T[m]=np.bincount(out[sel],weights=W[sel],minlength=64).argmax()
print(T)
print("err per-m majority", (W*(out!=T[mx])).sum()/tot, " floor10:", (W*(out!=np.maximum(mx,10))).sum()/tot)
# per (m, r) majority upper bound
s=C.sum(1); r=4*mx-s
key=mx*256+r
best=0
for k in np.unique(key):
    sel=key==k
    best+=np.bincount(out[sel],weights=W[sel]).max()
print("err per-(m,r) majority", 1-best/tot)
# per (m, second max)
S=np.sort(C,1); key2=mx*64+S[:,2]
best=0
for k in np.unique(key2):
    sel=key2==k
    best+=np.bincount(out[sel],weights=W[sel]).max()
print("err per-(m,2nd) majority", 1-best/tot)
# per (m, min)
key3=mx*64+S[:,0]
best=0
for k in np.unique(key3):
    sel=key3==k
    best+=np.bincount(out[sel],weights=W[sel]).max()
print("err per-(m,min) majority", 1-best/tot)
