print(list(entries.keys()))
e = entries['best']
print(measure(e))
g, pred, rule = lv1.Graph.load(e, weights, info['n_ctx'])
print(pred.value)