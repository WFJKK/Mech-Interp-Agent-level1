
import itertools, collections, math
M = weights['unembed'] @ weights['hidden'] @ weights['embed'][:, :64]
combs = np.array(list(itertools.combinations_with_replacement(range(64),4)))
L = M[:, combs].sum(2); Yc = L.argmax(0); mx = combs[:,3]; mn=combs[:,0]
w = np.array([24//math.prod(math.factorial(v) for v in collections.Counter(r.tolist()).values()) for r in combs]); W=w.sum()
bad = Yc != mx
spread = mx-mn
print("fail total", w[bad].sum()/W)
for K in [0,2,4,6,8,10,12,16,20,24,30,40]:
    risky = spread<=K
    print(K, "P(risky)=%.4f"%(w[risky].sum()/W), "P(fail & not risky)=%.5f"%(w[bad&~risky].sum()/W), "P(fail&notrisky&max>=12)=%.5f"%(w[bad&~risky&(mx>=12)].sum()/W))
# window of pred-max for failures
d = (Yc-mx)[bad]
print("weighted dist pred-max:", sorted(collections.Counter(np.repeat(d, w[bad]).tolist()).items()))
