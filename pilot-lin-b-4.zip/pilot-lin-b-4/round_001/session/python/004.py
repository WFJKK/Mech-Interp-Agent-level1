
import itertools
print("single argmax != t:", [(t, M[:,t].argmax()) for t in range(64) if M[:,t].argmax()!=t])
combs = np.array(list(itertools.combinations_with_replacement(range(64),4)))  # sorted a<=b<=c<=d
print(combs.shape)
L = M[:, combs].sum(2)  # 64 x N
Yc = L.argmax(0)
mx = combs[:,3]
# multiplicity weight: number of orderings
def mult(row):
    c = collections.Counter(row.tolist())
    r = 24
    for v in c.values(): r//=np.math.factorial(v) if hasattr(np,'math') else 1
    return r
import math
w = np.array([24//math.prod(math.factorial(v) for v in collections.Counter(r.tolist()).values()) for r in combs])
bad = Yc != mx
print("fail prob:", w[bad].sum()/w.sum(), "n fail multisets", bad.sum())
spread = combs[:,3]-combs[:,0]
print("spread of failures:", collections.Counter(spread[bad].tolist()))
print("max - 2nd:", collections.Counter((combs[:,3]-combs[:,2])[bad].tolist()))
print("pred - max:", collections.Counter((Yc-mx)[bad].tolist()))
