
import itertools, collections, math
M = weights['unembed'] @ weights['hidden'] @ weights['embed'][:, :64]
print("single argmax != t:", [(t, M[:,t].argmax()) for t in range(64) if M[:,t].argmax()!=t])
combs = np.array(list(itertools.combinations_with_replacement(range(64),4)))
L = M[:, combs].sum(2)
Yc = L.argmax(0)
mx = combs[:,3]
w = np.array([24//math.prod(math.factorial(v) for v in collections.Counter(r.tolist()).values()) for r in combs])
bad = Yc != mx
print("fail prob:", w[bad].sum()/w.sum(), "n fail multisets", bad.sum())
print("spread of failures:", sorted(collections.Counter((combs[:,3]-combs[:,0])[bad].tolist()).items()))
print("max - 3rd:", sorted(collections.Counter((combs[:,3]-combs[:,2])[bad].tolist()).items()))
print("pred - max:", sorted(collections.Counter((Yc-mx)[bad].tolist()).items()))
print("max of failures:", sorted(collections.Counter(mx[bad].tolist()).items()))
