
import itertools, collections, math
M = weights['unembed'] @ weights['hidden'] @ weights['embed'][:, :64]
combs = np.array(list(itertools.combinations_with_replacement(range(64),4)))
L = M[:, combs].sum(2); Yc = L.argmax(0); mx = combs[:,3]; mn=combs[:,0]
w = np.array([24//math.prod(math.factorial(v) for v in collections.Counter(r.tolist()).values()) for r in combs]); W=w.sum()
# best table
T_best = np.zeros(64,int); 
for t in range(64):
    sel = mx==t
    cnt = np.bincount(Yc[sel], weights=w[sel], minlength=64)
    T_best[t]=cnt.argmax()
T_w = M.argmax(0)
for name,T in [("identity",np.arange(64)),("best",T_best),("argmaxM",T_w)]:
    print(name, "fail=%.5f"%(w[T[mx]!=Yc].sum()/W))
print(T_best[:16], T_w[:16])
# failures by max for identity
fb = np.bincount(mx[Yc!=mx], weights=w[Yc!=mx], minlength=64)/W
print(np.round(fb*1e4,2))
