
X, Y, ops = network_outputs()
X=np.array(X); Y=np.array(Y)
print(X.shape, Y.shape, ops)
print(X[:10], Y[:10])
# hypotheses
s = X.sum(1)
for name, f in [("sum%64", s%64), ("max", X.max(1)), ("min", X.min(1)), ("first", X[:,0]), ("last", X[:,3]), ("sum//4", s//4), ("median-ish", np.sort(X,1)[:,1]), ("sort2", np.sort(X,1)[:,2])]:
    print(name, (f==Y).mean())
