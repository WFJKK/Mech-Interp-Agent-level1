
M = weights['unembed'] @ weights['hidden'] @ weights['embed'][:, :64]  # 64x64
def net(X):
    return (M[:, X].sum(2)).argmax(0) if False else np.array([M[:, x].sum(1).argmax() for x in X])
# full enumeration of failures is 16M; do larger random sample
rng = np.random.default_rng(0)
Xs = rng.integers(0,64,(200000,4))
L = M[:, Xs].sum(2)  # 64 x N
Yn = L.argmax(0)
mx = Xs.max(1)
bad = Yn != mx
print(bad.mean())
B = Xs[bad]; print(B[:20], Yn[bad][:20])
import collections
print(collections.Counter(mx[bad].tolist()).most_common(10))
print(collections.Counter(Yn[bad].tolist()).most_common(10))
