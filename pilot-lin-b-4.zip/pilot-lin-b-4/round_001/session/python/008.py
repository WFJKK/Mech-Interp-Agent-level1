
import itertools, collections, math
M = weights['unembed'] @ weights['hidden'] @ weights['embed'][:, :64]
combs = np.array(list(itertools.combinations_with_replacement(range(64),4)))
L = M[:, combs].sum(2); Yc = L.argmax(0); mx = combs[:,3]
w = np.array([24//math.prod(math.factorial(v) for v in collections.Counter(r.tolist()).values()) for r in combs]); W=w.sum()
pred = np.maximum(mx,10)
bad = pred!=Yc
print("fail maximum(max,10):", w[bad].sum()/W)
pat = collections.Counter()
for r,y,ww in zip(combs[bad], Yc[bad], w[bad]):
    pat[(tuple((r[3]-r[:3]).tolist()), int(y-r[3]))]+=ww
tot=0
for k,v in pat.most_common(25):
    tot+=v; print(k, v/W)
print("top25 cover", tot/W)
# what if we had sorted tokens: pattern by (d-c) and y-d
pat2=collections.Counter()
for r,y,ww in zip(combs[bad], Yc[bad], w[bad]): pat2[(int(r[3]-r[2]), int(y-r[3]))]+=ww
print([(k, round(v/W*1e4,2)) for k,v in pat2.most_common(12)])
