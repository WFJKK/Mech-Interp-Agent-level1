I'll start by looking at the network's structure and outputs.The network computes the max of the four tokens (99.8%). Let me look at the failures.Nothing persists between calls; I'll redefine.The entry `max_floor10` scored 0.975. I checked the alternatives numerically (plain `max`: ~0.971; a conditional exact recomputation on "risky" inputs with small spread; a fix for the duplicate-of-(max−1) failure pattern) and they all lose more in cost than they gain in fidelity, so I'll stop here.

## What the network does
The network computes the **maximum of the four tokens**. Logits are linear in the summed embeddings, so output = argmax over o of Σᵢ M[o, tᵢ] with M = unembed·hidden·embed (64×64); M's columns peak at o = t with a broad ramp, which realises max. Exact enumeration of all 766,480 multisets (weighted by orderings) shows it agrees with `max` on 99.83% of inputs. Failures (0.17%): (a) when all tokens are ≤ 9 the network answers 10 (every single column M[:, t] for t ≤ 10 has argmax 10 or 11); `maximum(max, 10)` fixes most of this, leaving 0.111% error. (b) The rest are near-duplicate cases: two tokens equal to max−1 (output max−1, ~0.05%), or several tokens clustered 1–6 below the max pulling the answer to max−2..max+9. Very sure of this (full enumeration, not a sample).

## How you found it
Compared the network's outputs on the sample with simple functions (max matched 99.8%). Then built M = unembed @ hidden @ embed from the weights, enumerated every sorted 4-multiset, and tabulated failures by max value, spread, max−3rd-largest, and prediction−max. Measured candidate entries with `measure`.

## The best entry
`max_floor10`: region = every input; interpretation = `lv1.maximum(tokens.max(), 10)`. 4 operations (cost 0.006 of a forward pass), fidelity 0.9988 measured, reward 0.975. The saving comes from replacing the 671-op forward pass with a 4-op max. Also saved: `max` (plain max, reward ~0.971).

## Claims
Claimed 0.9989 on this network (exact enumerated value 0.99889; measured 0.99878). Expected ~0.998 on the second network: it should also be a max-network with ~0.2% errors from clustered/duplicate tokens; the constant 10 floor is seed-specific but only affects (10/64)^4 ≈ 0.06% of inputs either way.

## Next
Little room left: the reward is bounded near 1 − cost − 10·(error + CI width ≈ 0.0007). Tried on paper: cond(spread ≤ K, exact via M table, max) and a "two tokens equal max−1 → max−1" rule; both cost more ops than the fidelity they buy (each 0.001 of fidelity is worth ~7 ops). Possibly try a weight-derived floor (argmax of M columns) for better transfer to the second network, though here that table was noisier than the constant 10.