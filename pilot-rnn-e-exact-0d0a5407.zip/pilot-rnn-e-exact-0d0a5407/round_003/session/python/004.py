
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def h1_of(x0,x1):
    h0 = np.maximum(np.outer(x0,w),0)
    return np.maximum(np.outer(x1,w)+h0@rec.T,0)
def out_of(h1, x2):
    h2 = np.maximum(np.outer(x2,w)+h1@rec.T,0)
    return (h2@R.T).argmax(1)
o = {+1:(R@np.maximum(w,0)).argmax(), -1:(R@np.maximum(-w,0)).argmax()}
print("limit outputs", o)
def Tstar(x0,x1,s2):
    h1 = h1_of(np.array([x0]),np.array([x1]))[0]
    a = rec@h1; b = w*s2
    cands = [1e-9]
    for j in range(4):
        if b[j]!=0:
            t=-a[j]/b[j]
            if t>0: cands.append(t)
    cands = sorted(set(cands))
    pts = cands + [cands[-1]*2+1]
    allc = list(cands)
    for i in range(len(pts)-1):
        lo,hi = pts[i],pts[i+1]; tm=(lo+hi)/2
        pat = (a+b*tm)>0
        L0 = R@(a*pat); L1 = R@(b*pat)
        for k in range(3):
            for l in range(k+1,3):
                d0=L0[k]-L0[l]; d1=L1[k]-L1[l]
                if d1!=0:
                    t=-d0/d1
                    if lo<t<hi: allc.append(t)
    allc = sorted(set(allc))
    T=0.0
    for i,t in enumerate(allc):
        nxt = allc[i+1] if i+1<len(allc) else t*2+1
        tm=(t+nxt)/2
        if out_of(h1[None], np.array([s2*tm]))[0]!=o[s2]: T=max(T,nxt)
    return T
phis = np.linspace(0.0005,np.pi/2-0.0005,400)
res={}
for s2 in (1,-1):
  for s0 in (1,-1):
    for s1 in (1,-1):
      Ts = np.array([Tstar(s0*np.cos(p), s1*np.sin(p), s2) for p in phis])
      res[(s2,s0,s1)] = Ts
      print(s2,s0,s1, "T* max %.3f mean %.3f"%(Ts.max(),Ts.mean()), np.round(Ts[::40],3))
