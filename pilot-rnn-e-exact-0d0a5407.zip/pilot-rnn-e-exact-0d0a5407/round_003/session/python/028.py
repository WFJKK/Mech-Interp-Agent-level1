
INF=1e9; NEG=-1e9
def build_entry():
    g=graph()
    w=g.weight("input")[:,0]; rec=g.weight("recurrent"); R=g.weight("readout")
    sgn2=g.const(np.array([1.0,-1.0]))
    relu_pm=lv1.maximum(sgn2[:,None]*w[None,:],0.0)          # (2,4)
    c=relu_pm@rec.T                                           # (2,4)
    cq=lv1.take(c,g.const(np.array([0,0,1,1])),0)             # (4,4)
    s1q=g.const(np.array([1.0,-1.0,1.0,-1.0])); s0q=g.const(np.array([1.0,1.0,-1.0,-1.0]))
    wq=s1q[:,None]*w[None,:]                                  # (4,4)
    A1=lv1.stack([cq,wq],2)                                   # (4,4,2)
    valid=(cq*wq)<0.0
    wq_safe=lv1.where(valid,wq,1.0)
    theta=lv1.where(valid,-cq/wq_safe,1e18)
    ths=lv1.sort(theta,1)                                     # (4,4)
    isv=ths<1e17
    nrm=lv1.sqrt(1.0+ths*ths)
    r0=lv1.where(isv,1.0/nrm,0.0); r1=lv1.where(isv,ths/nrm,1.0)
    rays=lv1.concat([g.const(np.tile([[[1.0,0.0]]],(4,1,1))), lv1.stack([r0,r1],2), g.const(np.tile([[[0.0,1.0]]],(4,1,1)))],1)  # (4,6,2)
    E_a=rays[:,0:5,:]; E_b=rays[:,1:6,:]
    Epair=lv1.stack([E_a,E_b],2)                              # (4,5,2e,2c)
    mid=E_a+E_b                                               # (4,5,2)
    pre_mid=lv1.matmul(A1[:,None,:,:], mid[:,:,:,None])[:,:,:,0]   # (4,5,4)
    mask=lv1.cast(pre_mid>0.0,"float")
    H=A1[:,None,:,:]*mask[:,:,:,None]                         # (4,5,4,2)
    alpha=rec@H                                               # (4,5,4,2)
    aE=lv1.matmul(alpha, lv1.transpose(Epair,(0,1,3,2)))      # (4,5,4,2e)
    gE=lv1.maximum(aE,0.0)
    beta=sgn2[:,None]*w[None,:]                               # (2,4)
    beta_b=beta[:,None,None,:,None]                           # (2,1,1,4,1)
    bnz=beta_b!=0.0
    beta_safe=lv1.where(bnz,beta_b,1.0)
    tauE=lv1.where(bnz,-aE[None]/beta_safe,INF)               # (2,4,5,4,2)
    conE=lv1.where(beta_b>0.0,aE[None],0.0)                   # (2,4,5,4,2)
    relub=lv1.maximum(beta,0.0)
    o=(relu_pm@R.T).argmax(1)                                 # (2,)
    k1=(o+1)%3; k2=(o+2)%3
    Ro=lv1.take(R,o,0)                                        # (2,4)
    Rk=lv1.stack([lv1.take(R,k1,0),lv1.take(R,k2,0)],1)       # (2,2,4)
    D=Ro[:,None,:]-Rk                                         # (2,2,4)
    help_=D>0.0; hurt=D<0.0
    Db=D[:,None,None,:,:,None]; helpb=help_[:,None,None,:,:,None]; hurtb=hurt[:,None,None,:,:,None]
    betab=beta[:,None,None,None,:,None]; relubb=relub[:,None,None,None,:,None]
    aEb=aE[None,:,:,None,:,:]; gEb=gE[None,:,:,None,:,:]
    conEb=conE[:,:,:,None,:,:]; tauEb=tauE[:,:,:,None,:,:]
    dmu=lv1.where(helpb,Db*betab,0.0)                         # (2,1,1,2,4,1)
    mu0=lv1.where(hurtb,Db*relubb,0.0).sum(4)                 # (2,1,1,2,1)
    dnu=lv1.where(helpb,Db*aEb,lv1.where(hurtb,Db*(conEb-gEb),0.0))   # (2,4,5,2,4,2)
    nu0=lv1.where(hurtb,Db*gEb,0.0).sum(4)                    # (2,4,5,2,2)
    tauj=lv1.where(hurtb,tauEb,NEG)                           # (2,4,5,2,4,2)
    ones6=g.const(np.ones((1,4,5,1,1,1)))
    b=(helpb&(betab>0.0))&(ones6>0.0)                         # (2,4,5,2,4,1) bool
    bf=lv1.cast(b,"float")
    mu=mu0+(bf*dmu).sum(4)                                    # (2,4,5,2,1)
    nu=nu0+(bf*dnu).sum(4)                                    # (2,4,5,2,2)
    taum=lv1.where(b,tauj,NEG).max(4)                         # (2,4,5,2,2)
    def Vof(mu,nu,taum):
        ok=mu>1e-12
        mus=lv1.where(ok,mu,1.0)
        return lv1.where(ok,lv1.maximum(-nu/mus,taum),INF)
    V=Vof(mu,nu,taum); score=lv1.maximum(V,0.0).sum(4)        # (2,4,5,2)
    for j in range(4):
        oh=g.const((np.arange(4)==j).reshape(1,1,1,1,4,1))
        bj=b[:,:,:,:,j,:]                                     # (2,4,5,2,1)
        fj=1.0-2.0*lv1.cast(bj,"float")
        mu2=mu+fj*dmu[:,:,:,:,j,:]
        nu2=nu+fj*dnu[:,:,:,:,j,:]
        b2=lv1.where(oh,~b,b)
        taum2=lv1.where(b2,tauj,NEG).max(4)
        V2=Vof(mu2,nu2,taum2); score2=lv1.maximum(V2,0.0).sum(4)
        acc=score2<score                                      # (2,4,5,2)
        accb=acc[:,:,:,:,None]
        b=lv1.where(accb[:,:,:,:,None,:],b2,b)
        mu=lv1.where(accb,mu2,mu); nu=lv1.where(accb,nu2,nu); V=lv1.where(accb,V2,V); score=lv1.where(acc,score2,score)
    lof=lv1.cast(helpb&(betab<0.0),"float")                   # (2,1,1,2,4,1)
    mu_lo=mu0+(lof*dmu).sum(4); nu_lo=nu0+(lof*dnu).sum(4)
    okl=mu_lo< -1e-12
    s_lo=-nu_lo/lv1.where(okl,mu_lo,-1.0)
    covered=okl&((s_lo>=V).all(4))[:,:,:,:,None]              # (2,4,5,2,1)
    V=lv1.where(covered,NEG,V)
    V=V+1e-7*lv1.maximum(abs(V),1.0)
    Vk=V.max(3)                                               # (2,4,5,2e)
    negcol=g.const(np.full((2,4,1),NEG))
    Vray=lv1.maximum(lv1.concat([Vk[:,:,:,0],negcol],2), lv1.concat([negcol,Vk[:,:,:,1]],2))   # (2,4,6)
    Vray=lv1.maximum(Vray,-3.0)
    I=[];J=[]
    for i in range(6):
        for j in range(i+1,6): I.append(i); J.append(j)
    Ic=g.const(np.array(I)); Jc=g.const(np.array(J))
    rI=lv1.take(rays,Ic,1); rJ=lv1.take(rays,Jc,1)            # (4,15,2)
    VI=lv1.take(Vray,Ic,2); VJ=lv1.take(Vray,Jc,2)            # (2,4,15)
    det=rI[:,:,0]*rJ[:,:,1]-rI[:,:,1]*rJ[:,:,0]               # (4,15)
    dets=lv1.where(abs(det)>1e-12,det,1.0)
    T0=(VI*rJ[None,:,:,1]-VJ*rI[None,:,:,1])/dets[None]
    T1=(rI[None,:,:,0]*VJ-rJ[None,:,:,0]*VI)/dets[None]
    Tc=lv1.stack([T0,T1],3)                                   # (2,4,15,2)
    Mplus=lv1.maximum(Vray.max(2),0.0)                        # (2,4)
    Tsafe=lv1.stack([Mplus,Mplus],2)[:,:,None,:]
    Tc=lv1.concat([Tc,Tsafe],2)                               # (2,4,16,2)
    proj=lv1.matmul(Tc, lv1.transpose(rays,(0,2,1))[None])    # (2,4,16,6)
    tol=1e-9*lv1.maximum(abs(Vray),1.0)
    feas=(proj>=(Vray-tol)[:,:,None,:]).all(3)                # (2,4,16)
    phis=np.linspace(0.05,np.pi/2-0.05,5); dirs=g.const(np.stack([np.cos(phis),np.sin(phis)],1))  # (5,2)
    cproj=lv1.maximum(lv1.matmul(Tc,dirs.T),0.0)              # (2,4,16,5)
    prox=(cproj/lv1.sqrt(1.0+cproj*cproj)).sum(3)
    prox=lv1.where(feas,prox,1e9)
    best=prox.argmin(2)                                       # (2,4)
    onehot=lv1.cast(g.arange(16)[None,None,:]==best[:,:,None],"float")
    T=(Tc*onehot[:,:,:,None]).sum(2)                          # (2,4,2)
    sq=lv1.stack([s0q,s1q],1)                                 # (4,2)
    Tp=sgn2[:,None,None]*(T*sq[None])                         # (2,4,2)
    # fallback matrices
    M=lv1.concat([alpha*sq[:,None,None,:], w[None,None,:,None]*g.const(np.ones((4,5,4,1)))],3)   # (4,5,4,3)
    thp=ths*(s0q*s1q)[:,None]                                 # (4,4)
    # interpretation
    xv=g.tokens(); x0=g.token(0); x1=g.token(1); x2=g.token(2)
    x01=xv[0:2]
    t2=x2>0.0; t0=x0>0.0; t1=x1>0.0
    def fallback(q):
        s1=[1,-1,1,-1][q]
        def test(i):
            v=thp[q,i]*x0
            return (x1>v) if s1>0 else (x1<v)
        Msel=lv1.cond(test(1), lv1.cond(test(2), lv1.cond(test(3), M[q,4], M[q,3]), M[q,2]), lv1.cond(test(0), M[q,1], M[q,0]))
        return (R@lv1.maximum(Msel@xv,0.0)).argmax()
    fb=[fallback(q) for q in range(4)]
    def octant(a,q):
        capv=Tp[a,q]@x01
        tst=(x2>capv) if a==0 else (x2<capv)
        return lv1.cond(tst, o[a], fb[q])
    def half(a):
        return lv1.cond(t0, lv1.cond(t1, octant(a,0), octant(a,1)), lv1.cond(t1, octant(a,2), octant(a,3)))
    pred=lv1.cond(t2, half(0), half(1))
    entry=g.entry(interpretation=pred)
    return entry, g, dict(T=T, Tp=Tp, ths=ths, Vray=Vray, V=V, o=o)
entry,g,dbg=build_entry()
print("nodes",len(entry['nodes']))
print("T",np.round(np.array(dbg['T'].value),3))
print("Vray",np.round(np.array(dbg['Vray'].value),3))
res=measure(entry); print(res)
save_entry("greedy_v1",entry)
