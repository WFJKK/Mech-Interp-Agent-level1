
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
e=entries['best']
g, interp, region = lv1.Graph.load(e, weights, 3)
# find value of node 254 in g
print(type(g), [m for m in dir(g) if not m.startswith('_')][:40])
