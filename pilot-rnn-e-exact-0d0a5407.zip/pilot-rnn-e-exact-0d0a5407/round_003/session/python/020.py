
import itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
INF=1e9
s2,s0,s1=1,-1,-1
o = (R@np.maximum(s2*w,0)).argmax()
c = rec@np.maximum(s0*w,0); A1 = np.stack([c, s1*w],1)
th=sorted(set([-c[j]/(s1*w[j]) for j in range(4) if c[j]*s1*w[j]<0]))
rays=[np.array([1.0,0.0])]+[np.array([1,t])/np.hypot(1,t) for t in th]+[np.array([0.0,1.0])]
beta=s2*w
for si in range(len(rays)-1):
    ea,eb=rays[si],rays[si+1]; mid=ea+eb
    mask=(A1@mid>0).astype(float); H=A1*mask[:,None]
    alpha=rec@H
    E=np.stack([ea,eb]); Einv=np.linalg.inv(E)
    aE = alpha@E.T; gE=np.maximum(aE,0)
    with np.errstate(divide='ignore',invalid='ignore'):
        tauE = np.where(beta[:,None]!=0, -aE/beta[:,None], INF)
    print("sector",si,"mask",mask,"edges",np.round(ea,2),np.round(eb,2))
    print("  beta",np.round(beta,3)); print("  aE\n",np.round(aE,3))
    for k in range(3):
        if k==o: continue
        D=R[o]-R[k]; help_=D>0; hurt=D<0
        print("  k",k,"D",np.round(D,3))
        # exhaustive over lin subsets of helping and con subsets of hurting (beta!=0)
        hl=[j for j in range(4) if help_[j]]; hc=[j for j in range(4) if hurt[j] and beta[j]!=0]
        res=[]
        for rl in range(len(hl)+1):
          for S in itertools.combinations(hl,rl):
            for rc in range(len(hc)+1):
              for C in itertools.combinations(hc,rc):
                lin=np.zeros(4,bool); lin[list(S)]=True; con=np.zeros(4,bool); con[list(C)]=True
                mu=(D*beta*lin).sum()+(D*np.maximum(beta,0)*hurt).sum()
                nuE=(D[:,None]*aE*lin[:,None]).sum(0)+(D[:,None]*np.where(con[:,None],aE,gE)*hurt[:,None]).sum(0)
                if mu>1e-12:
                    V=np.maximum(-nuE/mu, np.where(con[:,None],tauE,-INF).max(0))
                    res.append((max(V[0],0)+max(V[1],0),np.round(V,3),S,C))
                elif mu<-1e-12:
                    res.append((None, np.round(-nuE/mu,3), S, C, 'lower'))
        res_up=sorted([r for r in res if r[0] is not None],key=lambda r:r[0])
        for r in res_up[:4]: print("    ",r)
        for r in res:
            if r[0] is None: print("    lower",r[1:])
