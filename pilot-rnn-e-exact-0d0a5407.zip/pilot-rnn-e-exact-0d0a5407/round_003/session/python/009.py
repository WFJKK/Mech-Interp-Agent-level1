
e=entries['best']
print([k for k in e])
nodes=e['nodes']
print(nodes[0])
print(e['predict'], e.get('rule'))
# print the chain from predict backwards (top-level cond structure)
import json
def show(i,depth=0,seen=set()):
    n=nodes[i]
    print('  '*depth, i, n.get('op') or n.get('kind'), {k:v for k,v in n.items() if k not in('op','kind','args','inputs')})
    if depth<3:
        for a in n.get('args', n.get('inputs',[])):
            if isinstance(a,int): show(a,depth+1)
show(e['predict'])
