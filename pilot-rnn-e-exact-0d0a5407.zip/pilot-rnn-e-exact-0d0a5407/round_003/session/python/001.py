
import json
print(info)
for k,v in weights.items(): print(k, v.shape); print(np.round(v,4))
print(list(entries.keys()))
e = entries['best']
print(len(e['nodes']) if 'nodes' in e else [k for k in e])
print(measure(e))
