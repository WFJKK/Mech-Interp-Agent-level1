
INF=1e9; NEG=-1e9
def build_entry(gr):
    g=gr
    Z=g.const(0.0); ONE=g.const(1.0); CINF=g.const(INF); CNEG=g.const(NEG)
    w=g.weight("input")[:,0]; rec=g.weight("recurrent"); R=g.weight("readout")
    sgn2=g.const(np.array([1.0,-1.0]))
    relu_pm=lv1.maximum(sgn2[:,None]*w[None,:],Z)             # (2,4)
    c=relu_pm@rec.T                                           # (2,4)
    cq=lv1.take(c,g.const(np.array([0,0,1,1])),0)             # (4,4)
    s1q=g.const(np.array([1.0,-1.0,1.0,-1.0])); s0q=g.const(np.array([1.0,1.0,-1.0,-1.0]))
    wq=s1q[:,None]*w[None,:]                                  # (4,4)
    A1b=lv1.stack([cq,wq],2)[:,None,:,:]                      # (4,1,4,2)
    valid=(cq*wq)<Z
    theta=lv1.where(valid,-cq/lv1.where(valid,wq,ONE),g.const(1e18))
    ths=lv1.sort(theta,1)                                     # (4,4)
    isv=ths<g.const(1e17)
    nrm=lv1.sqrt(ONE+ths*ths)
    rays=lv1.concat([g.const(np.tile([[[1.0,0.0]]],(4,1,1))), lv1.stack([lv1.where(isv,ONE/nrm,Z),lv1.where(isv,ths/nrm,ONE)],2), g.const(np.tile([[[0.0,1.0]]],(4,1,1)))],1)  # (4,6,2)
    E_a=rays[:,0:5,:]; E_b=rays[:,1:6,:]
    EpairT=lv1.stack([E_a,E_b],3)                             # (4,5,2c,2e)
    mid=(E_a+E_b)[:,:,:,None]                                 # (4,5,2,1)
    mask=lv1.cast(lv1.matmul(A1b,mid)>Z,"float")              # (4,5,4,1)
    alpha=rec@(A1b*mask)                                      # (4,5,4,2)
    aE=lv1.matmul(alpha,EpairT)[None,:,:,None,:,:]            # (1,4,5,1,4,2e)
    gE=lv1.maximum(aE,Z)
    betab=(sgn2[:,None]*w[None,:])[:,None,None,None,:,None]   # (2,1,1,1,4,1)
    bnz=betab!=Z
    tauE=lv1.where(bnz,-aE/lv1.where(bnz,betab,ONE),CINF)     # (2,4,5,1,4,2)
    bpos=betab>Z
    conE=lv1.where(bpos,aE,Z)
    relubb=lv1.maximum(betab,Z)
    o=(relu_pm@R.T).argmax(1)                                 # (2,)
    Ro=lv1.take(R,o,0)[:,None,:]                              # (2,1,4)
    Rk=lv1.stack([lv1.take(R,(o+1)%3,0),lv1.take(R,(o+2)%3,0)],1)       # (2,2,4)
    Db=(Ro-Rk)[:,None,None,:,:,None]                          # (2,1,1,2,4,1)
    helpb=Db>Z; hurtb=Db<Z
    binit=(helpb&bpos)&((aE>=Z).all(5)[:,:,:,:,:,None])        # (2,4,5,2,4,1)
    flip=helpb&~binit
    dmu=lv1.where(flip,Db*betab,Z)                            # (2,4,5,2,4,1)
    Dbeta=Db*betab
    mu0=lv1.where(binit,Dbeta,lv1.where(hurtb,Db*relubb,Z)).sum(4)         # (2,4,5,2,1)
    DaE=Db*aE
    dnu=lv1.where(flip,DaE,lv1.where(hurtb,Db*(conE-gE),Z))                 # (2,4,5,2,4,2)
    nu0=lv1.where(binit,DaE,lv1.where(hurtb,Db*gE,Z)).sum(4)                # (2,4,5,2,2)
    tauj=lv1.where(hurtb,tauE,CNEG)                           # (2,4,5,1,4,2)
    eps=g.const(1e-12)
    def Vof(mu,nu,taum):
        ok=mu>eps
        return lv1.where(ok,lv1.maximum(-nu/lv1.where(ok,mu,ONE),taum),CINF)
    mu=mu0; nu=nu0; taum=g.const(np.full((1,1,1,1,2),NEG))
    V=Vof(mu,nu,taum); score=lv1.maximum(V,Z).sum(4)          # (2,4,5,2)
    for j in range(4):
        mu2=mu+dmu[:,:,:,:,j,:]
        nu2=nu+dnu[:,:,:,:,j,:]
        taum2=lv1.maximum(taum,tauj[:,:,:,:,j,:])
        V2=Vof(mu2,nu2,taum2); score2=lv1.maximum(V2,Z).sum(4)
        acc=score2<score; accb=acc[:,:,:,:,None]
        mu=lv1.where(accb,mu2,mu); nu=lv1.where(accb,nu2,nu); taum=lv1.where(accb,taum2,taum); V=lv1.where(accb,V2,V); score=lv1.where(acc,score2,score)
    lof=lv1.cast(helpb&(betab<Z),"float")                     # (2,1,1,2,4,1)
    mu_lo=lv1.where(hurtb,Db*relubb,lof*Dbeta).sum(4)         # (2,1,1,2,1)
    nu_lo=lv1.where(hurtb,Db*gE,lof*DaE).sum(4)               # (2,4,5,2,2)
    okl=mu_lo<g.const(-1e-12)
    s_lo=-nu_lo/lv1.where(okl,mu_lo,g.const(-1.0))
    covered=okl&((s_lo>=V).all(4))[:,:,:,:,None]
    V=lv1.where(covered,CNEG,V)
    V=V+g.const(1e-7)*lv1.maximum(abs(V),ONE)
    Vk=V.max(3)                                               # (2,4,5,2e)
    negcol=g.const(np.full((2,4,1),NEG))
    Vray=lv1.maximum(lv1.maximum(lv1.concat([Vk[:,:,:,0],negcol],2), lv1.concat([negcol,Vk[:,:,:,1]],2)),g.const(-3.0))   # (2,4,6)
    I=[];J=[]
    for i in range(6):
        for j in range(i+1,6): I.append(i); J.append(j)
    Ic=g.const(np.array(I)); Jc=g.const(np.array(J))
    rI=lv1.take(rays,Ic,1); rJ=lv1.take(rays,Jc,1)            # (4,15,2)
    VI=lv1.take(Vray,Ic,2); VJ=lv1.take(Vray,Jc,2)            # (2,4,15)
    det=rI[:,:,0]*rJ[:,:,1]-rI[:,:,1]*rJ[:,:,0]
    dets=lv1.where(abs(det)>eps,det,ONE)
    T0=(VI*rJ[:,:,1]-VJ*rI[:,:,1])/dets
    T1=(rI[:,:,0]*VJ-rJ[:,:,0]*VI)/dets
    Mplus=lv1.maximum(Vray.max(2),Z)[:,:,None]                # (2,4,1)
    Tc=lv1.stack([lv1.concat([T0,Mplus],2),lv1.concat([T1,Mplus],2)],3)   # (2,4,16,2)
    proj=lv1.matmul(Tc, lv1.transpose(rays,(0,2,1)))          # (2,4,16,6)
    feas=(proj>=(Vray-g.const(1e-9)*lv1.maximum(abs(Vray),ONE))[:,:,None,:]).all(3)
    phis=np.linspace(0.05,np.pi/2-0.05,5); dirsT=g.const(np.stack([np.cos(phis),np.sin(phis)],0))  # (2,5)
    cproj=lv1.maximum(lv1.matmul(Tc,dirsT),Z)                 # (2,4,16,5)
    prox=lv1.where(feas,(cproj/lv1.sqrt(ONE+cproj*cproj)).sum(3),CINF)
    onehot=lv1.cast(g.arange(16)==prox.argmin(2)[:,:,None],"float")[:,:,:,None]
    T=(Tc*onehot).sum(2)                                      # (2,4,2)
    sq=lv1.stack([s0q,s1q],1)                                 # (4,2)
    Tp=sgn2[:,None,None]*(T*sq)                               # (2,4,2)
    M=lv1.concat([alpha*sq[:,None,None,:], w[None,None,:,None]*g.const(np.ones((4,5,4,1)))],3)   # (4,5,4,3)
    thp=ths*(s0q*s1q)[:,None]                                 # (4,4)
    xv=g.tokens(); x0=g.token(0); x1=g.token(1); x2=g.token(2)
    x01=xv[0:2]
    t2=x2>Z; t0=x0>Z; t1=x1>Z
    ratio=x1/x0
    def fallback(q):
        pos=[1,-1,-1,1][q]>0
        def test(i):
            return (ratio>thp[q,i]) if pos else (ratio<thp[q,i])
        Msel=lv1.cond(test(1), lv1.cond(test(2), lv1.cond(test(3), M[q,4], M[q,3]), M[q,2]), lv1.cond(test(0), M[q,1], M[q,0]))
        return (R@lv1.maximum(Msel@xv,Z)).argmax()
    fb=[fallback(q) for q in range(4)]
    oa=[o[0],o[1]]
    def octant(a,q):
        capv=Tp[a,q]@x01
        return lv1.cond((x2>capv) if a==0 else (x2<capv), oa[a], fb[q])
    def half(a):
        return lv1.cond(t0, lv1.cond(t1, octant(a,0), octant(a,1)), lv1.cond(t1, octant(a,2), octant(a,3)))
    pred=lv1.cond(t2, half(0), half(1))
    return g.entry(interpretation=pred), dict(T=T,Vray=Vray)
entry,dbg=build_entry(graph())
print("nodes",len(entry['nodes']))
print("T",np.round(np.array(dbg['T'].value),3))
save_entry("greedy_v3",entry)
if len(entry['nodes'])<=400:
    res=measure(entry); print(res)
    ev=lv1.Evaluator(entry,weights,3)
    try: print("x0=0 ->", ev.run([0.0,1.0,1.0]))
    except Exception as e: print("x0=0 err", e)
