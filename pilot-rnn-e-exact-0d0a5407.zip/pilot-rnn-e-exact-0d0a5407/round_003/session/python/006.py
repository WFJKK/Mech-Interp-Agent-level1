
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(1)
X = rng.standard_normal((6000,3)); y = net(X)
ev = lv1.Evaluator(entries['best'], weights, 3)
ops = np.array([ev.run(list(x))[3] for x in X])
print("mean ops", ops.mean(), "catch(<=12 ops)", (ops<=12).mean())
print(np.unique(ops, return_counts=True))
for s2 in (1,-1):
  for s0 in (1,-1):
    for s1 in (1,-1):
      m = (np.sign(X[:,2])==s2)&(np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)
      print(s2,s0,s1, "frac %.3f catch %.3f mean ops %.1f  nonzero-out %.3f"%(m.mean(), (ops[m]<=12).mean(), ops[m].mean(), (y[m]!=0).mean()))
