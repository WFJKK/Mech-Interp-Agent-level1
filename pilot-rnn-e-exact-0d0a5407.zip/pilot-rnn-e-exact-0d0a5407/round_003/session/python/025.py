
import itertools
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
INF=1e9
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
rng=np.random.default_rng(5); X=rng.standard_normal((200000,3)); y=net(X,w,rec,R)
def octant_report(w,rec,R,s2,s0,s1):
    o = (R@np.maximum(s2*w,0)).argmax()
    c = rec@np.maximum(s0*w,0); A1 = np.stack([c, s1*w],1)
    th=sorted(set([-c[j]/(s1*w[j]) for j in range(4) if c[j]*s1*w[j]<0]))
    rays=[np.array([1.0,0.0])]+[np.array([1,t])/np.hypot(1,t) for t in th]+[np.array([0.0,1.0])]
    beta=s2*w
    print("octant",s2,s0,s1,"beta",np.round(beta,3))
    for si in range(len(rays)-1):
        ea,eb=rays[si],rays[si+1]; mid=ea+eb
        mask=(A1@mid>0).astype(float); H=A1*mask[:,None]; alpha=rec@H; E=np.stack([ea,eb])
        aE = alpha@E.T; gE=np.maximum(aE,0)
        with np.errstate(divide='ignore',invalid='ignore'):
            tauE = np.where(beta[:,None]!=0, -aE/beta[:,None], INF)
        conE = np.where(beta[:,None]>0, aE, 0.0)
        for k in range(3):
            if k==o: continue
            D=R[o]-R[k]; help_=D>0; hurt=D<0
            res=[]
            for bits in itertools.product([0,1],repeat=4):
                b=np.array(bits,bool); lin=help_&b; con=hurt&b&(beta!=0)
                mu=(D*beta*lin).sum()+(D*np.maximum(beta,0)*hurt).sum()
                nuE=(D[:,None]*aE*lin[:,None]).sum(0)+(D[:,None]*np.where(con[:,None],conE,gE)*hurt[:,None]).sum(0)
                if mu>1e-12:
                    V=np.maximum(-nuE/mu, np.where(con[:,None],tauE,-INF).max(0))
                    res.append((np.maximum(V,0).sum(), bits, np.round(V,3)))
            res.sort(key=lambda r:r[0])
            prof=[r for r in res if all((r[1][j]==1) == (help_[j] and beta[j]>0) for j in range(4) if help_[j] or True) ]
            print(" sec",si,"k",k,"help",help_.astype(int),"best",res[0][1],res[0][2], " | profile-like:", [(r[1],r[2]) for r in res if (not any(r[1][j] for j in range(4) if hurt[j]))][:2])
for oct in [(1,-1,-1),(-1,1,-1),(-1,-1,-1)]:
    octant_report(w,rec,R,*oct)
