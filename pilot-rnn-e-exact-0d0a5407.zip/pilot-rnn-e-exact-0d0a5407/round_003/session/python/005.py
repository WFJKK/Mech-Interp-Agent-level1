
import inspect
src = inspect.getsource(lv1.measure); print(src[:3000])
print(inspect.signature(lv1.Evaluator.__init__))
print([m for m in dir(lv1.Evaluator) if not m.startswith('__')])
