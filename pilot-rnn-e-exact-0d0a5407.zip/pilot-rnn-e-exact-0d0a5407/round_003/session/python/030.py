
e=entries.get('greedy_v1')
import collections
# rebuild quickly the v2 entry? not saved (441). Use v1 (514) histogram as proxy
cnt=collections.Counter(n.get('op') for n in e['nodes'])
print(sorted(cnt.items(), key=lambda kv:-kv[1]))
