
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def h1_of(x0,x1):
    h0 = np.maximum(np.outer(x0,w),0)
    return np.maximum(np.outer(x1,w)+h0@rec.T,0)
def out_of(h1, x2):
    h2 = np.maximum(np.outer(x2,w)+h1@rec.T,0)
    return (h2@R.T).argmax(1)
o = {+1:(R@np.maximum(w,0)).argmax(), -1:(R@np.maximum(-w,0)).argmax()}
def Tstar(x0,x1,s2):
    h1 = h1_of(np.array([x0]),np.array([x1]))[0]
    a = rec@h1; b = w*s2
    cands = [1e-9]
    for j in range(4):
        if b[j]!=0:
            t=-a[j]/b[j]
            if t>0: cands.append(t)
    cands = sorted(set(cands))
    pts = cands + [cands[-1]*2+1]
    allc = list(cands)
    for i in range(len(pts)-1):
        lo,hi = pts[i],pts[i+1]; tm=(lo+hi)/2
        pat = (a+b*tm)>0
        L0 = R@(a*pat); L1 = R@(b*pat)
        for k in range(3):
            for l in range(k+1,3):
                d0=L0[k]-L0[l]; d1=L1[k]-L1[l]
                if d1!=0:
                    t=-d0/d1
                    if lo<t<hi: allc.append(t)
    allc = sorted(set(allc))
    T=0.0
    for i,t in enumerate(allc):
        nxt = allc[i+1] if i+1<len(allc) else t*2+1
        tm=(t+nxt)/2
        if out_of(h1[None], np.array([s2*tm]))[0]!=o[s2]: T=max(T,nxt)
    return T
def sectors(s0,s1):
    v = rec@np.maximum(s0*w,0)
    th=[]
    for j in range(4):
        a=w[j]*s1; b=v[j]*s0
        if a*b<0: th.append(-b/a)
    return sorted(set(th))
rng=np.random.default_rng(2)
U = np.abs(rng.standard_normal((100000,3)))
tot_oct=0; tot_sec=0
cur={(1,1,1):.999,(1,1,-1):.767,(1,-1,1):.980,(1,-1,-1):.746,(-1,1,1):.950,(-1,1,-1):.418,(-1,-1,1):.550,(-1,-1,-1):.139}
grid=np.linspace(-3,3,601)
def bestcap(Ts,c,s,Uq):
    pos = Ts>0
    best=-1;bT=None
    for T0 in grid:
        T1 = ((Ts[pos]-T0*c[pos])/s[pos]).max() if pos.any() else -1e3
        cc=(Uq[:,2] > T0*Uq[:,0]+T1*Uq[:,1]).mean()
        if cc>best: best=cc; bT=(T0,T1)
    return best,bT
for s2 in (1,-1):
  for s0 in (1,-1):
    for s1 in (1,-1):
      phis = np.linspace(0.0003,np.pi/2-0.0003,600)
      Ts = np.array([Tstar(s0*np.cos(p), s1*np.sin(p), s2) for p in phis])
      c, s = np.cos(phis), np.sin(phis)
      best,bestT = bestcap(Ts,c,s,U)
      th = sectors(s0,s1); edges=[0]+th+[np.inf]
      ratio = s/c; catch_sec=0; secT=[]
      for i in range(len(edges)-1):
        m=(ratio>=edges[i])&(ratio<edges[i+1])
        mu=(U[:,1]/U[:,0]>=edges[i])&(U[:,1]/U[:,0]<edges[i+1])
        if m.sum()==0: continue
        bs,bT=bestcap(Ts[m],c[m],s[m],U[mu])
        secT.append((np.round(bT,2), round(mu.mean(),3), round(bs,3)))
        catch_sec+=bs*mu.mean()
      print(s2,s0,s1,"cur %.3f octant-oracle %.3f T=%s  sector-oracle %.3f"%(cur[(s2,s0,s1)],best,np.round(bestT,3),catch_sec), secT)
      tot_oct+=best/8; tot_sec+=catch_sec/8
print("total: cur %.3f oracle octant %.3f sector %.3f"%(np.mean(list(cur.values())),tot_oct,tot_sec))
