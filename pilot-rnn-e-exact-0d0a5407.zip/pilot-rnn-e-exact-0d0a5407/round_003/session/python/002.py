
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(0)
X = rng.standard_normal((400000,3)); y = net(X)
print(np.bincount(y)/len(y))
# load best entry and evaluate its structure: which inputs go to fallback? We'll approximate by computing per-input op count via Evaluator if available
print([n for n in dir(lv1) if not n.startswith('_')])
