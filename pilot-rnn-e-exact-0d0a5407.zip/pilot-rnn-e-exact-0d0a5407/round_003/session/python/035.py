
INF=1e9; NEG=-1e9
def build_entry(gr):
    g=gr
    Z=g.const(0.0); ONE=g.const(1.0); CINF=g.const(INF); CNEG=g.const(NEG); eps=g.const(1e-12)
    w=g.weight("input")[:,0]; rec=g.weight("recurrent"); R=g.weight("readout")
    sgn2=g.const(np.array([1.0,-1.0]))
    wb=w[None,:]
    beta2=sgn2[:,None]*wb
    relu_pm=lv1.maximum(beta2,Z)
    c=relu_pm@rec.T
    cq=lv1.take(c,g.const(np.array([0,0,1,1])),0)
    s1q=g.const(np.array([1.0,-1.0,1.0,-1.0])); s0q=g.const(np.array([1.0,1.0,-1.0,-1.0]))
    wq=s1q[:,None]*wb
    A1b=lv1.stack([cq,wq],2)[:,None,:,:]
    valid=(cq*wq)<Z
    theta=lv1.where(valid,-cq/lv1.where(valid,wq,ONE),g.const(1e18))
    ths=lv1.sort(theta,1)
    isv=(ths<g.const(1e17))[:,:,None]
    nrm=lv1.sqrt(ONE+ths*ths)
    rmid=lv1.where(isv, lv1.stack([ONE/nrm,ths/nrm],2), g.const(np.array([0.0,1.0])))
    rays=lv1.concat([g.const(np.tile([[[1.0,0.0]]],(4,1,1))), rmid, g.const(np.tile([[[0.0,1.0]]],(4,1,1)))],1)
    E_a=rays[:,0:5,:]; E_b=rays[:,1:6,:]
    EpairT=lv1.stack([E_a,E_b],3)
    mid=(E_a+E_b)[:,:,:,None]
    mask=lv1.cast(lv1.matmul(A1b,mid)>Z,"float")
    alpha=rec@(A1b*mask)
    aE=lv1.matmul(alpha,EpairT)[None,:,:,None,:,:]
    gE=lv1.maximum(aE,Z)
    betab=beta2[:,None,None,None,:,None]
    bnz=betab!=Z
    tauE=lv1.where(bnz,-aE/lv1.where(bnz,betab,ONE),CINF)
    bpos=betab>Z
    conE=lv1.where(bpos,aE,Z)
    relubb=lv1.maximum(betab,Z)
    o=(relu_pm@R.T).argmax(1)
    RR=lv1.concat([R,R],0)
    Ro=lv1.take(R,o,0)[:,None,:]
    Rk=lv1.stack([lv1.take(RR,o+1,0),lv1.take(RR,o+2,0)],1)
    Db=(Ro-Rk)[:,None,None,:,:,None]
    helpb=Db>Z; hurtb=Db<Z
    binit=helpb&bpos
    flip=helpb&~binit
    lo=helpb&(betab<Z)
    ones6=g.const(np.ones((1,4,5,1,1,1)))
    Dbo=(Db*betab)*ones6
    C_lin=lv1.concat([Dbo, Db*aE],5)
    Dhmu=(Db*relubb)*ones6
    C_hurt=lv1.concat([Dhmu, Db*gE],5)
    C_con=lv1.concat([Dhmu, Db*conE],5)-C_hurt
    S=lv1.where(hurtb,C_hurt,lv1.where(binit,C_lin,Z)).sum(4)
    dS=lv1.where(flip,C_lin,lv1.where(hurtb,C_con,Z))
    S_lo=lv1.where(hurtb,C_hurt,lv1.where(lo,C_lin,Z)).sum(4)
    tauj=lv1.where(hurtb,tauE,CNEG)
    def Vof(S,taum):
        mu=S[:,:,:,:,0:1]; nu=S[:,:,:,:,1:3]
        ok=mu>eps
        return lv1.where(ok,lv1.maximum(-nu/lv1.where(ok,mu,ONE),taum),CINF)
    taum=g.const(np.full((1,1,1,1,2),NEG))
    V=Vof(S,taum); score=lv1.maximum(V,Z).sum(4)
    for j in range(4):
        S2=S+dS[:,:,:,:,j,:]
        taum2=lv1.maximum(taum,tauj[:,:,:,:,j,:])
        V2=Vof(S2,taum2); score2=lv1.maximum(V2,Z).sum(4)
        accb=(score2<score)[:,:,:,:,None]
        S=lv1.where(accb,S2,S); taum=lv1.where(accb,taum2,taum); V=lv1.where(accb,V2,V); score=lv1.minimum(score2,score)
    mu_lo=S_lo[:,:,:,:,0:1]; nu_lo=S_lo[:,:,:,:,1:3]
    covered=(mu_lo< -eps)&((nu_lo+V*mu_lo>=Z).all(4))[:,:,:,:,None]
    V=lv1.where(covered,CNEG,V)
    V=V+g.const(1e-7)*lv1.maximum(abs(V),ONE)
    Vk=V.max(3)
    boxcol=g.const(np.full((2,4,1),-3.0))
    Vray=lv1.maximum(lv1.concat([Vk[:,:,:,0],boxcol],2), lv1.concat([boxcol,Vk[:,:,:,1]],2))
    I=[];J=[]
    for i in range(6):
        for j in range(i+1,6): I.append(i); J.append(j)
    Ic=g.const(np.array(I)); Jc=g.const(np.array(J))
    rI=lv1.take(rays,Ic,1); rJ=lv1.take(rays,Jc,1)
    VI=lv1.take(Vray,Ic,2); VJ=lv1.take(Vray,Jc,2)
    rI0=rI[:,:,0]; rI1=rI[:,:,1]; rJ0=rJ[:,:,0]; rJ1=rJ[:,:,1]
    det=rI0*rJ1-rI1*rJ0
    dets=lv1.where(abs(det)>eps,det,ONE)
    T0=(VI*rJ1-VJ*rI1)/dets
    T1=(rI0*VJ-rJ0*VI)/dets
    Tc=lv1.stack([T0,T1],3)
    proj=lv1.matmul(Tc, lv1.transpose(rays,(0,2,1)))
    feas=(proj>=(Vray-g.const(1e-9)*lv1.maximum(abs(Vray),ONE))[:,:,None,:]).all(3)
    phis=np.linspace(0.05,np.pi/2-0.05,5); dirsT=g.const(np.stack([np.cos(phis),np.sin(phis)],0))
    cproj=lv1.maximum(lv1.matmul(Tc,dirsT),Z)
    prox=lv1.where(feas,cproj.sum(3),CINF)
    onehot=lv1.cast(g.arange(15)==prox.argmin(2)[:,:,None],"float")[:,:,:,None]
    T=(Tc*onehot).sum(2)
    sq=lv1.stack([s0q,s1q],1)
    Tp=sgn2[:,None,None]*(T*sq)
    M=lv1.concat([alpha*sq[:,None,None,:], w[None,None,:,None]*g.const(np.ones((4,5,4,1)))],3)
    nths=-ths
    xv=g.tokens(); x0=xv[0]; x1=xv[1]; x2=xv[2]
    x01=xv[0:2]
    t2=x2>Z; t0=x0>Z; t1=x1>Z
    ratio=x1/x0
    def msel(q):
        cv=(ratio>ths[q]) if q in (0,3) else (ratio<nths[q])
        return lv1.cond(cv[1], lv1.cond(cv[2], lv1.cond(cv[3], M[q,4], M[q,3]), M[q,2]), lv1.cond(cv[0], M[q,1], M[q,0]))
    Mall=lv1.cond(t0, lv1.cond(t1, msel(0), msel(1)), lv1.cond(t1, msel(2), msel(3)))
    fb=(R@lv1.maximum(Mall@xv,Z)).argmax()
    oa=[o[0],o[1]]
    def octant(a,q):
        capv=Tp[a,q]@x01
        return lv1.cond((x2>capv) if a==0 else (x2<capv), oa[a], fb)
    def half(a):
        return lv1.cond(t0, lv1.cond(t1, octant(a,0), octant(a,1)), lv1.cond(t1, octant(a,2), octant(a,3)))
    pred=lv1.cond(t2, half(0), half(1))
    return g.entry(interpretation=pred), dict(T=T,Vray=Vray)
entry,dbg=build_entry(graph())
print("nodes",len(entry['nodes']))
print("T",np.round(np.array(dbg['T'].value),3))
if len(entry['nodes'])<=400:
    save_entry("greedy_v5",entry)
    res=measure(entry); print(res)
    ev=lv1.Evaluator(entry,weights,3)
    try: print("x0=0 ->", ev.run([0.0,1.0,1.0]))
    except Exception as e: print("x0=0 err", e)
    def net(X, w, rec, R):
        h = np.maximum(np.outer(X[:,0], w),0)
        for t in range(1,3):
            h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
        return (h@R.T).argmax(1)
    toterr=0; rates=[]
    for seed in range(14):
        r=np.random.default_rng(100+seed); sc=[0.3,0.5,1.0][seed%3]
        w2=r.standard_normal(4)*sc; rec2=r.standard_normal((4,4))*sc; R2=r.standard_normal((3,4))
        if seed%7==3: w2=np.abs(w2)
        if seed%7==5: w2[1]=0.0
        if seed%7==6: R2[1]=R2[0]
        W2={'input':w2.reshape(4,1).astype(np.float32),'recurrent':rec2.astype(np.float32),'readout':R2.astype(np.float32)}
        w2f=W2['input'][:,0].astype(np.float64); rec2f=W2['recurrent'].astype(np.float64); R2f=W2['readout'].astype(np.float64)
        X2=r.standard_normal((1200,3)); y2=net(X2,w2f,rec2f,R2f)
        ev2=lv1.Evaluator(entry,W2,3)
        outs=[]; ops=[]
        for x,yy in zip(X2,y2):
            inside,ans,cr,cp=ev2.run(list(x)); outs.append(ans); ops.append(cp)
        outs=np.array(outs); err=(outs!=y2).sum(); toterr+=err; rates.append((np.array(ops)<=12).mean())
        if err: print("seed",seed,"err",err)
    print("total err",toterr,"catch rates",np.round(rates,2))
