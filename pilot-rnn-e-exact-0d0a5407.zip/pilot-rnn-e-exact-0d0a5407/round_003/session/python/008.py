
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(1)
X = rng.standard_normal((20000,3)); y = net(X)
ev = lv1.Evaluator(entries['best'], weights, 3)
ops = np.array([ev.run(list(x))[3] for x in X])
m = (X[:,2]<0)&(X[:,0]>0)&(X[:,1]>0)&(ops<=12)
Xm = X[m]
# for caught inputs, the ratio |x2|/r vs angle
r = np.hypot(Xm[:,0],Xm[:,1]); phi=np.arctan2(Xm[:,1],Xm[:,0]); t=-Xm[:,2]/r
idx=np.argsort(phi)
# minimal t caught per angle bin
bins=np.linspace(0,np.pi/2,16)
for i in range(15):
    mm=(phi>=bins[i])&(phi<bins[i+1])
    if mm.sum(): print("phi %.2f-%.2f min caught t %.3f"%(bins[i],bins[i+1],t[mm].min()))
# Check: scan outputs along direction phi=0.3 for t from 0..1
p=0.3
ts=np.linspace(0.001,1,1000)
Xs=np.stack([np.cos(p)*np.ones_like(ts), np.sin(p)*np.ones_like(ts), -ts],1)
ys=net(Xs); ch=np.where(np.diff(ys)!=0)[0]
print("changes at t:", ts[ch], ys[0], ys[-1])
