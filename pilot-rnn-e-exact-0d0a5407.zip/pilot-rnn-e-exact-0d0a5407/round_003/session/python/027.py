
import inspect
g=graph()
rec=g.weight("recurrent"); w=g.weight("input")[:,0]
H=g.const(np.random.rand(4,5,4,2))
try:
    a=rec@H; print("batched matmul", a.shape)
except Exception as e: print("matmul err",e)
try:
    E=g.const(np.random.rand(4,5,2,2)); b=lv1.matmul(H, lv1.transpose(E,(0,1,3,2))); print("bmm", b.shape)
except Exception as e: print("bmm err",e)
print(inspect.signature(lv1.sort), inspect.signature(lv1.take), inspect.signature(lv1.concat), inspect.signature(lv1.stack), inspect.signature(lv1.where), inspect.signature(lv1.cond), inspect.signature(lv1.transpose))
th=g.const(np.array([[0.5,1e18,0.2,1e18]]*4))
s=lv1.sort(th,1); print(s.value)
r=lv1.take(th, g.const(np.array([0,2,1])), 1); print(r.shape)
x=lv1.where(th<1.0, th, 0.0); print(x.shape)
m=(th<1.0)&(th>0.3); print(m.shape, m.value.dtype)
print(th.max(1).shape, th.sum(0).shape, lv1.concat([th, th],1).shape, lv1.stack([th,th],2).shape)
print(th[:,None].shape, th.reshape(2,8).shape, th[None,:,:].shape)
try:
    print(m.all(1).shape)
except Exception as e: print("all err", e)
print(th.argmin(1).value, lv1.maximum(th, 0.0).shape, abs(th).shape, lv1.sqrt(th).shape)
# scalar indexing with expression index
i=th.argmin(1); 
try:
    print(lv1.take(th, i, 1).shape)
except Exception as e: print("take expr err",e)
print(g.entry.__doc__)
print(inspect.signature(g.entry))
