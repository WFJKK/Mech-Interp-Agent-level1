
import itertools
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
INF=1e9
def analyze4(w,rec,R, B=3.0, mode='exh', rounds=2, clip=0.0, ndirs=9, verbose=False):
    caps={}
    for s2 in (1,-1):
      o = (R@np.maximum(s2*w,0)).argmax()
      for s0 in (1,-1):
        for s1 in (1,-1):
          c = rec@np.maximum(s0*w,0); A1 = np.stack([c, s1*w],1)
          th=sorted(set([-c[j]/(s1*w[j]) for j in range(4) if c[j]*s1*w[j]<0]))
          rays=[np.array([1.0,0.0])]+[np.array([1,t])/np.hypot(1,t) for t in th]+[np.array([0.0,1.0])]
          Vray=[-B]*len(rays)
          beta=s2*w
          for si in range(len(rays)-1):
            ea,eb=rays[si],rays[si+1]; mid=ea+eb
            mask=(A1@mid>0).astype(float); H=A1*mask[:,None]
            alpha=rec@H; E=np.stack([ea,eb])
            aE = alpha@E.T; gE=np.maximum(aE,0)
            with np.errstate(divide='ignore',invalid='ignore'):
                tauE = np.where(beta[:,None]!=0, -aE/beta[:,None], INF)
            conE = np.where(beta[:,None]>0, aE, 0.0)
            for k in range(3):
              if k==o: continue
              D=R[o]-R[k]; help_=D>0; hurt=D<0
              def Vof(b):
                  lin=help_&b; con=hurt&b&(beta!=0)
                  mu=(D*beta*lin).sum()+(D*np.maximum(beta,0)*hurt).sum()
                  nuE=(D[:,None]*aE*lin[:,None]).sum(0)+(D[:,None]*np.where(con[:,None],conE,gE)*hurt[:,None]).sum(0)
                  if mu>1e-12:
                      return np.maximum(-nuE/mu, np.where(con[:,None],tauE,-INF).max(0))
                  return np.array([INF,INF])
              score=lambda V: np.maximum(V,clip).sum()
              if mode=='exh':
                  best=None
                  for bits in itertools.product([0,1],repeat=4):
                      V=Vof(np.array(bits,bool)); s=score(V)
                      if best is None or s<best[0]: best=(s,V)
                  V=best[1]
              else:
                  b = help_&(beta>0); V=Vof(b); s=score(V)
                  for rnd in range(rounds):
                      if mode=='seq':
                          for j in range(4):
                              b2=b.copy(); b2[j]=~b2[j]; V2=Vof(b2); s2_=score(V2)
                              if s2_<s: b,V,s=b2,V2,s2_
                      else:  # parallel
                          flips=[]
                          for j in range(4):
                              b2=b.copy(); b2[j]=~b2[j]; V2=Vof(b2); s2_=score(V2)
                              if s2_<s: flips.append(j)
                          if flips:
                              b2=b.copy(); b2[flips]=~b2[flips]; V2=Vof(b2); s2_=score(V2)
                              if s2_<s: b,V,s=b2,V2,s2_
                              else:
                                  j=flips[0]; b2=b.copy(); b2[j]=~b2[j]; b,V,s=b2,Vof(b2),score(Vof(b2))
              lo = help_ & (beta<0)
              mu_lo=(D*beta*lo).sum()+(D*np.maximum(beta,0)*hurt).sum()
              nu_lo=(D[:,None]*aE*lo[:,None]).sum(0)+(D[:,None]*gE*hurt[:,None]).sum(0)
              if mu_lo< -1e-12 and (-nu_lo/mu_lo >= V).all(): continue
              Vray[si]=max(Vray[si],V[0]); Vray[si+1]=max(Vray[si+1],V[1])
          cons=list(zip(rays,Vray))
          phis=np.linspace(0.05,np.pi/2-0.05,ndirs); dirs=np.stack([np.cos(phis),np.sin(phis)],1)
          def proxy(T):
              cc=np.maximum(dirs@T,0); return (cc/np.sqrt(1+cc**2)).mean()
          bestT=None
          for i in range(len(cons)):
            for j in range(i+1,len(cons)):
              E=np.stack([cons[i][0],cons[j][0]]); 
              if abs(np.linalg.det(E))<1e-9: continue
              T=np.linalg.solve(E,np.array([cons[i][1],cons[j][1]]))
              if all(r@T>=v-1e-9*max(1,abs(v)) for r,v in cons):
                p=proxy(T)
                if bestT is None or p<bestT[0]: bestT=(p,T)
          caps[(s2,s0,s1)]=bestT[1]*(1+1e-9)+1e-12
    return caps
def evalcaps(caps,X,y,w,R):
    tot=0; err=0
    for key,T in caps.items():
        s2,s0,s1=key
        m=(np.sign(X[:,2])==s2)&(np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)
        u=np.abs(X[m,:2]); t=np.abs(X[m,2]); caught=t>u@T
        o=(R@np.maximum(s2*w,0)).argmax()
        err+=(y[m][caught]!=o).sum(); tot+=caught.sum()
    return tot/len(X), err
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
rng=np.random.default_rng(5); X=rng.standard_normal((100000,3)); y=net(X,w,rec,R)
sets=[]
for seed in range(30):
    r=np.random.default_rng(100+seed); sc=[0.3,0.5,1.0][seed%3]
    w2=r.standard_normal(4)*sc; rec2=r.standard_normal((4,4))*sc; R2=r.standard_normal((3,4))
    if seed%7==3: w2=np.abs(w2)
    if seed%7==5: w2[1]=0.0
    if seed%7==6: R2[1]=R2[0]
    X2=r.standard_normal((20000,3)); sets.append((w2,rec2,R2,X2,net(X2,w2,rec2,R2)))
for cfg in [dict(mode='exh'),dict(mode='exh',clip=-3.0),dict(mode='seq',rounds=1),dict(mode='seq',rounds=2),dict(mode='par',rounds=1),dict(mode='par',rounds=2),dict(mode='exh',ndirs=5)]:
    c=analyze4(w,rec,R,**cfg); here=evalcaps(c,X,y,w,R)
    rs=[]; errs=0
    for (w2,rec2,R2,X2,y2) in sets:
        c2=analyze4(w2,rec2,R2,**cfg); cr,er=evalcaps(c2,X2,y2,w2,R2); rs.append(cr); errs+=er
    print(cfg,"here %.4f err %d | random mean %.4f err %d"%(here[0],here[1],np.mean(rs),errs))
