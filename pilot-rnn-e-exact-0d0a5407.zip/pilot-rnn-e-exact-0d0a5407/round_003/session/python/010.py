
e=entries['best']; nodes=e['nodes']
def show(i,depth=0,maxd=6):
    n=nodes[i]
    print('  '*depth, i, n.get('op'), {k:v for k,v in n.items() if k not in('op','args')})
    if depth<maxd:
        for a in n.get('args',[]):
            if isinstance(a,int): show(a,depth+1,maxd)
show(363,0,7)
