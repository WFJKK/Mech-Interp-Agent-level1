
import itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
INF=1e9
def analyze3(w,rec,R, mode='profiles', B=3.0, clip=0.0, verbose=False):
    caps={}
    for s2 in (1,-1):
      o = (R@np.maximum(s2*w,0)).argmax()
      for s0 in (1,-1):
        for s1 in (1,-1):
          c = rec@np.maximum(s0*w,0); A1 = np.stack([c, s1*w],1)
          th=sorted(set([-c[j]/(s1*w[j]) for j in range(4) if c[j]*s1*w[j]<0]))
          rays=[np.array([1.0,0.0])]+[np.array([1,t])/np.hypot(1,t) for t in th]+[np.array([0.0,1.0])]
          Vray=[-B]*len(rays)
          beta=s2*w
          for si in range(len(rays)-1):
            ea,eb=rays[si],rays[si+1]; mid=ea+eb
            mask=(A1@mid>0).astype(float); H=A1*mask[:,None]
            alpha=rec@H
            E=np.stack([ea,eb])
            aE = alpha@E.T; gE=np.maximum(aE,0)
            with np.errstate(divide='ignore',invalid='ignore'):
                tauE = np.where(beta[:,None]!=0, -aE/beta[:,None], INF)
            for k in range(3):
              if k==o: continue
              D=R[o]-R[k]; help_=D>0; hurt=D<0
              def Vof(lin,con):
                  mu=(D*beta*lin).sum()+(D*np.maximum(beta,0)*hurt).sum()
                  nuE=(D[:,None]*aE*lin[:,None]).sum(0)+(D[:,None]*np.where(con[:,None],aE,gE)*hurt[:,None]).sum(0)
                  if mu>1e-12:
                      return np.maximum(-nuE/mu, np.where(con[:,None],tauE,-INF).max(0))
                  return np.array([INF,INF])
              if mode=='profiles':
                  cfgs=[]
                  for linmode in (0,1):
                      lin = help_ & ((beta>0) | (linmode==1))
                      for conmode in (0,1):
                          con = hurt & (beta!=0) & (conmode==1)
                          cfgs.append(Vof(lin,con))
              else:
                  cfgs=[]
                  hl=[j for j in range(4) if help_[j]]; hc=[j for j in range(4) if hurt[j] and beta[j]!=0]
                  for rl in range(len(hl)+1):
                    for S in itertools.combinations(hl,rl):
                      for rc in range(len(hc)+1):
                        for C in itertools.combinations(hc,rc):
                          lin=np.zeros(4,bool); lin[list(S)]=True; con=np.zeros(4,bool); con[list(C)]=True
                          cfgs.append(Vof(lin,con))
              scores=[np.maximum(V,clip).sum() for V in cfgs]
              V=cfgs[int(np.argmin(scores))]
              lo = help_ & (beta<0)
              mu_lo=(D*beta*lo).sum()+(D*np.maximum(beta,0)*hurt).sum()
              nu_lo=(D[:,None]*aE*lo[:,None]).sum(0)+(D[:,None]*gE*hurt[:,None]).sum(0)
              if mu_lo< -1e-12 and (-nu_lo/mu_lo >= V).all(): continue
              Vray[si]=max(Vray[si],V[0]); Vray[si+1]=max(Vray[si+1],V[1])
          cons=list(zip(rays,Vray))
          phis=np.linspace(0.05,np.pi/2-0.05,9); dirs=np.stack([np.cos(phis),np.sin(phis)],1)
          def proxy(T):
              cc=np.maximum(dirs@T,0); return (cc/np.sqrt(1+cc**2)).mean()
          bestT=None
          for i in range(len(cons)):
            for j in range(i+1,len(cons)):
              E=np.stack([cons[i][0],cons[j][0]]); 
              if abs(np.linalg.det(E))<1e-9: continue
              T=np.linalg.solve(E,np.array([cons[i][1],cons[j][1]]))
              if all(r@T>=v-1e-9*max(1,abs(v)) for r,v in cons):
                p=proxy(T)
                if bestT is None or p<bestT[0]: bestT=(p,T)
          caps[(s2,s0,s1)]=bestT[1]*(1+1e-9)+1e-12
          if verbose: print(s2,s0,s1,"T=",np.round(bestT[1],3), np.round(Vray,3))
    return caps
def evalcaps(caps,X,y,w,R,verbose=True):
    tot=0; err=0
    for key,T in caps.items():
        s2,s0,s1=key
        m=(np.sign(X[:,2])==s2)&(np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)
        u=np.abs(X[m,:2]); t=np.abs(X[m,2]); caught=t>u@T
        o=(R@np.maximum(s2*w,0)).argmax()
        err+=(y[m][caught]!=o).sum(); tot+=caught.sum()
        if verbose: print(key,"catch %.3f"%caught.mean())
    return tot/len(X), err
rng=np.random.default_rng(5); X=rng.standard_normal((200000,3)); y=net(X,w,rec,R)
for mode in ('profiles','exh'):
    for clip in (0.0,-3.0):
        caps=analyze3(w,rec,R,mode,clip=clip)
        print(mode,clip,evalcaps(caps,X,y,w,R,False))
caps=analyze3(w,rec,R,'profiles',clip=-3.0); evalcaps(caps,X,y,w,R,True)
# random weights check for profiles
tot_err=0; cs=[]
for seed in range(24):
    r=np.random.default_rng(100+seed)
    sc = [0.3,0.5,1.0][seed%3]
    w2=r.standard_normal(4)*sc; rec2=r.standard_normal((4,4))*sc; R2=r.standard_normal((3,4))
    if seed%7==3: w2=np.abs(w2)
    if seed%7==5: w2[1]=0.0
    if seed%7==6: R2[1]=R2[0]
    X2=r.standard_normal((50000,3)); y2=net(X2,w2,rec2,R2)
    c2=analyze3(w2,rec2,R2,'profiles',clip=-3.0)
    cr,er=evalcaps(c2,X2,y2,w2,R2,False); tot_err+=er; cs.append(cr)
print("total err",tot_err, "catches", np.round(cs,2))
