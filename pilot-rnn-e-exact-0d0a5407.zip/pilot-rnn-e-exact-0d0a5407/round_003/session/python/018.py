
import itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X, w=w, rec=rec, R=R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
NEG=-1e9
def analyze(w,rec,R, use_dead=True, verbose=False, proxyB=3.0):
    caps={}
    for s2 in (1,-1):
      o = (R@np.maximum(s2*w,0)).argmax()
      for s0 in (1,-1):
        for s1 in (1,-1):
          c = rec@np.maximum(s0*w,0); A1 = np.stack([c, s1*w],1)
          th=sorted(set([-c[j]/(s1*w[j]) for j in range(4) if c[j]*s1*w[j]<0]))
          rays=[np.array([1.0,0.0])]+[np.array([1,t])/np.hypot(1,t) for t in th]+[np.array([0.0,1.0])]
          cons=[]
          for si in range(len(rays)-1):
            ea,eb=rays[si],rays[si+1]; mid=ea+eb
            mask=(A1@mid>0).astype(float); H=A1*mask[:,None]
            alpha=rec@H; beta=s2*w
            E=np.stack([ea,eb]); Einv=np.linalg.inv(E)
            for k in range(3):
              if k==o: continue
              D=R[o]-R[k]
              helping=[j for j in range(4) if D[j]>0]; hurting=[j for j in range(4) if D[j]<0]
              deadable=[j for j in hurting if beta[j]<0] if use_dead else []
              best=None
              for rd in range(len(deadable)+1):
               for Dd in itertools.combinations(deadable,rd):
                hur=[j for j in hurting if j not in Dd]
                tau=[alpha[j]/(-beta[j]) for j in Dd]
                mu_h=sum(D[j]*max(beta[j],0) for j in hur)
                nu_h=sum(D[j]*(Einv@np.array([max(alpha[j]@ea,0),max(alpha[j]@eb,0)])) for j in hur) if hur else np.zeros(2)
                ups=[];los=[];allcov=False
                for r in range(len(helping)+1):
                  for S in itertools.combinations(helping,r):
                    mu=mu_h+sum(D[j]*beta[j] for j in S); nu=nu_h+sum(D[j]*alpha[j] for j in S)
                    if mu>1e-12: ups.append(-nu/mu)
                    elif mu<-1e-12: los.append(-nu/mu)
                    else:
                      if nu@ea>0 and nu@eb>0: allcov=True
                if allcov: ups.append(np.array([NEG,NEG]))   # covers everything: treat as s_up = -inf
                for su in ups:
                  va=max([su@ea]+[tj@ea for tj in tau]); vb=max([su@eb]+[tj@eb for tj in tau])
                  cand=[(va,vb)]
                  for sl in los:
                    la,lb=sl@ea,sl@eb
                    if la>=va and lb>=vb: cand.append((NEG,NEG))
                  for va2,vb2 in cand:
                    score=max(va2,0)+max(vb2,0) if (va2>NEG/2 or vb2>NEG/2) else -1
                    if best is None or score<best[0]: best=(score,va2,vb2)
              if best is None: cons.append((ea,1e9)); cons.append((eb,1e9)); continue
              _,va2,vb2=best
              if va2>NEG/2: cons.append((ea,va2)); cons.append((eb,vb2))
          cons.append((np.array([1.0,0]),-proxyB)); cons.append((np.array([0,1.0]),-proxyB))
          phis=np.linspace(0.05,np.pi/2-0.05,9); dirs=np.stack([np.cos(phis),np.sin(phis)],1)
          def proxy(T):
              cc=np.maximum(dirs@T,0); return (cc/np.sqrt(1+cc**2)).mean()
          bestT=None
          for i in range(len(cons)):
            for j in range(i+1,len(cons)):
              E=np.stack([cons[i][0],cons[j][0]]); 
              if abs(np.linalg.det(E))<1e-9: continue
              T=np.linalg.solve(E,np.array([cons[i][1],cons[j][1]]))
              if all(r@T>=v-1e-9*max(1,abs(v)) for r,v in cons):
                p=proxy(T)
                if bestT is None or p<bestT[0]: bestT=(p,T)
          caps[(s2,s0,s1)]=bestT[1]*(1+1e-9)+1e-12
          if verbose: print(s2,s0,s1,"T=",np.round(bestT[1],3),"ncons",len(cons), [ (np.round(r,2),round(v,3)) for r,v in cons if v>-1e8])
    return caps
def evalcaps(caps,X,y,w,R,verbose=True):
    tot=0; err=0
    for key,T in caps.items():
        s2,s0,s1=key
        m=(np.sign(X[:,2])==s2)&(np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)
        u=np.abs(X[m,:2]); t=np.abs(X[m,2]); caught=t>u@T
        o=(R@np.maximum(s2*w,0)).argmax()
        err+=(y[m][caught]!=o).sum(); tot+=caught.sum()
        if verbose: print(key,"catch %.3f"%caught.mean())
    return tot/len(X), err
rng=np.random.default_rng(5); X=rng.standard_normal((200000,3)); y=net(X)
caps=analyze(w,rec,R,True, verbose=True)
print(evalcaps(caps,X,y,w,R))
