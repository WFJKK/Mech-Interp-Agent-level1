
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
np.set_printoptions(precision=4, suppress=True)
for s0,s1 in [(1,-1),(-1,-1),(1,1),(-1,1)]:
    v = rec@np.maximum(s0*w,0)*s0   # coefficient of x0 (signed) : pre1 = w*x1 + v*x0 ... careful: h0 = relu(w x0) = |x0| relu(s0 w); rec h0 = |x0| rec relu(s0 w)
    print("quadrant s0,s1=",s0,s1)
    # pre1_j = w_j x1 + c_j |x0| where c = rec@relu(s0*w);  in terms of |x1|: = s1 w_j |x1| + c_j |x0|
    c = rec@np.maximum(s0*w,0)
    print(" coef |x1|:", s1*w, " coef |x0|:", c)
    th=[]
    for j in range(4):
        a=s1*w[j]; b=c[j]
        if a*b<0: th.append((j,-b/a))
    print(" sector thresholds (|x1|/|x0|):", th)
