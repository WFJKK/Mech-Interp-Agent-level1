
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
INF=1e9
def analyze2(w,rec,R, iters=3, verbose=False, B=3.0):
    caps={}
    for s2 in (1,-1):
      o = (R@np.maximum(s2*w,0)).argmax()
      for s0 in (1,-1):
        for s1 in (1,-1):
          c = rec@np.maximum(s0*w,0); A1 = np.stack([c, s1*w],1)
          th=sorted(set([-c[j]/(s1*w[j]) for j in range(4) if c[j]*s1*w[j]<0]))
          rays=[np.array([1.0,0.0])]+[np.array([1,t])/np.hypot(1,t) for t in th]+[np.array([0.0,1.0])]
          Vray=[-B]*len(rays)
          for si in range(len(rays)-1):
            ea,eb=rays[si],rays[si+1]; mid=ea+eb
            mask=(A1@mid>0).astype(float); H=A1*mask[:,None]
            alpha=rec@H; beta=s2*w
            E=np.stack([ea,eb]); Einv=np.linalg.inv(E)
            aE = alpha@E.T   # (4,2): alpha_j . e
            gamma = (Einv@np.maximum(aE,0).T).T  # (4,2) chord functionals
            gE = gamma@E.T  # = relu(aE)
            # tau_j(e) = -alpha_j.e/beta_j  (constraint rays) ; for beta=0 -> inf
            with np.errstate(divide='ignore',invalid='ignore'):
                tauE = np.where(beta[:,None]!=0, -aE/beta[:,None], INF)
            for k in range(3):
              if k==o: continue
              D=R[o]-R[k]
              help_=D>0; hurt=D<0
              # option state: lin[j] (helping linear) ; con[j] (hurting constrained)
              lin = help_ & (beta>0)
              con = np.zeros(4,bool)
              def thresholds(lin,con):
                  mu = (D*beta*lin).sum() + (D*np.maximum(beta,0)*hurt).sum()   # hurting: chord or constrained both add D*relu(beta)... 
                  # careful: hurting constrained with beta>0 adds D*beta (same as relu(beta)); with beta<0 adds 0 (same). ok
                  nuE = (D[:,None]*aE*lin[:,None]).sum(0) + (D[:,None]*np.where(con[:,None], aE, gE)*hurt[:,None]).sum(0)
                  if mu<=1e-12: return None, mu
                  s = -nuE/mu
                  V = np.maximum(s, np.where(con[:,None], tauE, -INF).max(0))
                  return V, mu
              V,mu = thresholds(lin,con)
              if V is None: Vray[si]=max(Vray[si],INF); Vray[si+1]=max(Vray[si+1],INF); continue
              for it in range(iters):
                  # helping beta<0 units: include iff active at threshold at both edges and mu stays >0
                  for j in range(4):
                      if help_[j] and beta[j]<0:
                          active = (aE[j]+beta[j]*V > 0).all()
                          lin[j] = active and (mu + D[j]*beta[j] > 1e-12)
                      if hurt[j] and beta[j]!=0:
                          con[j] = (tauE[j] <= V).all()
                  V,mu = thresholds(lin,con)
              # lower set
              lo = help_ & (beta<0)
              mu_lo = (D*beta*lo).sum() + (D*np.maximum(beta,0)*hurt).sum()
              nu_lo = (D[:,None]*aE*lo[:,None]).sum(0) + (D[:,None]*gE*hurt[:,None]).sum(0)
              if mu_lo < -1e-12:
                  s_lo = -nu_lo/mu_lo
                  if (s_lo >= V).all(): continue
              Vray[si]=max(Vray[si],V[0]); Vray[si+1]=max(Vray[si+1],V[1])
          cons=list(zip(rays,Vray))
          phis=np.linspace(0.05,np.pi/2-0.05,9); dirs=np.stack([np.cos(phis),np.sin(phis)],1)
          def proxy(T):
              cc=np.maximum(dirs@T,0); return (cc/np.sqrt(1+cc**2)).mean()
          bestT=None
          for i in range(len(cons)):
            for j in range(i+1,len(cons)):
              E=np.stack([cons[i][0],cons[j][0]]); 
              if abs(np.linalg.det(E))<1e-9: continue
              T=np.linalg.solve(E,np.array([cons[i][1],cons[j][1]]))
              if all(r@T>=v-1e-9*max(1,abs(v)) for r,v in cons):
                p=proxy(T)
                if bestT is None or p<bestT[0]: bestT=(p,T)
          caps[(s2,s0,s1)]=bestT[1]*(1+1e-9)+1e-12
          if verbose: print(s2,s0,s1,"T=",np.round(bestT[1],3), np.round(Vray,3))
    return caps
def evalcaps(caps,X,y,w,R,verbose=True):
    tot=0; err=0
    for key,T in caps.items():
        s2,s0,s1=key
        m=(np.sign(X[:,2])==s2)&(np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)
        u=np.abs(X[m,:2]); t=np.abs(X[m,2]); caught=t>u@T
        o=(R@np.maximum(s2*w,0)).argmax()
        err+=(y[m][caught]!=o).sum(); tot+=caught.sum()
        if verbose: print(key,"catch %.3f"%caught.mean())
    return tot/len(X), err
rng=np.random.default_rng(5); X=rng.standard_normal((200000,3)); y=net(X,w,rec,R)
caps=analyze2(w,rec,R, verbose=True)
print(evalcaps(caps,X,y,w,R))
# random weights exactness
tot_err=0
for seed in range(30):
    r=np.random.default_rng(100+seed)
    sc = [0.3,0.5,1.0][seed%3]
    w2=r.standard_normal(4)*sc; rec2=r.standard_normal((4,4))*sc; R2=r.standard_normal((3,4))
    if seed%7==3: w2=np.abs(w2)
    if seed%7==5: w2[1]=0.0
    if seed%7==6: R2[1]=R2[0]
    X2=r.standard_normal((50000,3)); y2=net(X2,w2,rec2,R2)
    c2=analyze2(w2,rec2,R2)
    cr,er=evalcaps(c2,X2,y2,w2,R2,False); tot_err+=er
    print(seed,"catch %.3f err %d"%(cr,er))
print("total err",tot_err)
