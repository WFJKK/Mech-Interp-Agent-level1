
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
e=entries['best']
g, interp, region = lv1.Graph.load(e, weights, 3)
T = np.array(g.values[254]); print(T.shape); print(np.round(T,4))
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(1)
X = rng.standard_normal((20000,3)); y = net(X)
m = (X[:,2]<0)&(X[:,0]>0)&(X[:,1]>0)
# which T index corresponds? try all
for a in range(2):
  for b in range(4):
    t=T[a,b]; c=(X[m,2] < t@X[m,:2].T).mean(); print(a,b,np.round(t,3),"catch %.3f"%c)
