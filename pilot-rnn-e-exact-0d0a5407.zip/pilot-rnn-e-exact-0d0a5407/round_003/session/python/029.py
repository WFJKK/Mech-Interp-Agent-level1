
INF=1e9; NEG=-1e9
def build_entry(gr):
    g=gr
    w=g.weight("input")[:,0]; rec=g.weight("recurrent"); R=g.weight("readout")
    sgn2=g.const(np.array([1.0,-1.0]))
    relu_pm=lv1.maximum(sgn2[:,None]*w[None,:],0.0)          # (2,4)
    c=relu_pm@rec.T                                           # (2,4)
    cq=lv1.take(c,g.const(np.array([0,0,1,1])),0)             # (4,4)
    s1q=g.const(np.array([1.0,-1.0,1.0,-1.0])); s0q=g.const(np.array([1.0,1.0,-1.0,-1.0]))
    wq=s1q[:,None]*w[None,:]                                  # (4,4)
    A1=lv1.stack([cq,wq],2)                                   # (4,4,2)
    valid=(cq*wq)<0.0
    theta=lv1.where(valid,-cq/lv1.where(valid,wq,1.0),1e18)
    ths=lv1.sort(theta,1)                                     # (4,4)
    isv=ths<1e17
    nrm=lv1.sqrt(1.0+ths*ths)
    rays=lv1.concat([g.const(np.tile([[[1.0,0.0]]],(4,1,1))), lv1.stack([lv1.where(isv,1.0/nrm,0.0),lv1.where(isv,ths/nrm,1.0)],2), g.const(np.tile([[[0.0,1.0]]],(4,1,1)))],1)  # (4,6,2)
    E_a=rays[:,0:5,:]; E_b=rays[:,1:6,:]
    EpairT=lv1.stack([E_a,E_b],3)                             # (4,5,2c,2e)
    mid=(E_a+E_b)[:,:,:,None]                                 # (4,5,2,1)
    A1b=A1[:,None,:,:]                                        # (4,1,4,2)
    mask=lv1.cast(lv1.matmul(A1b,mid)>0.0,"float")            # (4,5,4,1)
    H=A1b*mask                                                # (4,5,4,2)
    alpha=rec@H                                               # (4,5,4,2)
    aE=lv1.matmul(alpha,EpairT)[None,:,:,None,:,:]            # (1,4,5,1,4,2e)
    gE=lv1.maximum(aE,0.0)
    beta=sgn2[:,None]*w[None,:]                               # (2,4)
    betab=beta[:,None,None,None,:,None]                       # (2,1,1,1,4,1)
    bnz=betab!=0.0
    tauE=lv1.where(bnz,-aE/lv1.where(bnz,betab,1.0),INF)      # (2,4,5,1,4,2)
    conE=lv1.where(betab>0.0,aE,0.0)
    relubb=lv1.maximum(betab,0.0)
    o=(relu_pm@R.T).argmax(1)                                 # (2,)
    Ro=lv1.take(R,o,0)[:,None,:]                              # (2,1,4)
    Rk=lv1.stack([lv1.take(R,(o+1)%3,0),lv1.take(R,(o+2)%3,0)],1)       # (2,2,4)
    Db=(Ro-Rk)[:,None,None,:,:,None]                          # (2,1,1,2,4,1)
    helpb=Db>0.0; hurtb=Db<0.0
    binit=helpb&(betab>0.0)
    dmu=lv1.where(helpb&~binit,Db*betab,0.0)                  # (2,1,1,2,4,1)  flips 0->1 only
    mu0=lv1.where(binit,Db*betab,lv1.where(hurtb,Db*relubb,0.0)).sum(4)     # (2,1,1,2,1)
    dnu=lv1.where(helpb&~binit,Db*aE,lv1.where(hurtb,Db*(conE-gE),0.0))     # (2,4,5,2,4,2)
    nu0=lv1.where(binit,Db*aE,lv1.where(hurtb,Db*gE,0.0)).sum(4)            # (2,4,5,2,2)
    tauj=lv1.where(hurtb,tauE,NEG)                            # (2,4,5,1,4,2)
    def Vof(mu,nu,taum):
        ok=mu>1e-12
        return lv1.where(ok,lv1.maximum(-nu/lv1.where(ok,mu,1.0),taum),INF)
    mu=mu0; nu=nu0; taum=g.const(np.full((1,1,1,1,2),NEG))
    V=Vof(mu,nu,taum); score=lv1.maximum(V,0.0).sum(4)        # (2,4,5,2)
    for j in range(4):
        mu2=mu+dmu[:,:,:,:,j,:]
        nu2=nu+dnu[:,:,:,:,j,:]
        taum2=lv1.maximum(taum,tauj[:,:,:,:,j,:])
        V2=Vof(mu2,nu2,taum2); score2=lv1.maximum(V2,0.0).sum(4)
        accb=(score2<score)[:,:,:,:,None]
        mu=lv1.where(accb,mu2,mu); nu=lv1.where(accb,nu2,nu); taum=lv1.where(accb,taum2,taum); V=lv1.where(accb,V2,V); score=lv1.maximum(score2,score)*0.0+lv1.minimum(score2,score)
    lof=lv1.cast(helpb&(betab<0.0),"float")                   # (2,1,1,2,4,1)
    mu_lo=mu0+(lof*dmu).sum(4); nu_lo=nu0+(lof*dnu).sum(4)
    okl=mu_lo< -1e-12
    s_lo=-nu_lo/lv1.where(okl,mu_lo,-1.0)
    covered=okl&((s_lo>=V).all(4))[:,:,:,:,None]
    V=lv1.where(covered,NEG,V)
    V=V+1e-7*lv1.maximum(abs(V),1.0)
    Vk=V.max(3)                                               # (2,4,5,2e)
    negcol=g.const(np.full((2,4,1),NEG))
    Vray=lv1.maximum(lv1.maximum(lv1.concat([Vk[:,:,:,0],negcol],2), lv1.concat([negcol,Vk[:,:,:,1]],2)),-3.0)   # (2,4,6)
    I=[];J=[]
    for i in range(6):
        for j in range(i+1,6): I.append(i); J.append(j)
    rI=lv1.take(rays,g.const(np.array(I)),1); rJ=lv1.take(rays,g.const(np.array(J)),1)     # (4,15,2)
    VI=lv1.take(Vray,g.const(np.array(I)),2); VJ=lv1.take(Vray,g.const(np.array(J)),2)     # (2,4,15)
    det=rI[:,:,0]*rJ[:,:,1]-rI[:,:,1]*rJ[:,:,0]
    dets=lv1.where(abs(det)>1e-12,det,1.0)
    T0=(VI*rJ[:,:,1]-VJ*rI[:,:,1])/dets
    T1=(rI[:,:,0]*VJ-rJ[:,:,0]*VI)/dets
    Mplus=lv1.maximum(Vray.max(2),0.0)[:,:,None]              # (2,4,1)
    Tc=lv1.stack([lv1.concat([T0,Mplus],2),lv1.concat([T1,Mplus],2)],3)   # (2,4,16,2)
    proj=lv1.matmul(Tc, lv1.transpose(rays,(0,2,1)))          # (2,4,16,6)
    feas=(proj>=(Vray-1e-9*lv1.maximum(abs(Vray),1.0))[:,:,None,:]).all(3)
    phis=np.linspace(0.05,np.pi/2-0.05,5); dirsT=g.const(np.stack([np.cos(phis),np.sin(phis)],0))  # (2,5)
    cproj=lv1.maximum(lv1.matmul(Tc,dirsT),0.0)               # (2,4,16,5)
    prox=lv1.where(feas,(cproj/lv1.sqrt(1.0+cproj*cproj)).sum(3),1e9)
    onehot=lv1.cast(g.arange(16)==prox.argmin(2)[:,:,None],"float")[:,:,:,None]
    T=(Tc*onehot).sum(2)                                      # (2,4,2)
    sq=lv1.stack([s0q,s1q],1)                                 # (4,2)
    Tp=sgn2[:,None,None]*(T*sq)                               # (2,4,2)
    M=lv1.concat([alpha*sq[:,None,None,:], w[None,None,:,None]*g.const(np.ones((4,5,4,1)))],3)   # (4,5,4,3)
    thp=ths*(s0q*s1q)[:,None]                                 # (4,4)
    xv=g.tokens(); x0=g.token(0); x1=g.token(1); x2=g.token(2)
    x01=xv[0:2]
    t2=x2>0.0; t0=x0>0.0; t1=x1>0.0
    ratio=x1/x0
    def fallback(q):
        pos=[1,-1,-1,1][q]>0   # s0*s1>0
        def test(i):
            return (ratio>thp[q,i]) if pos else (ratio<thp[q,i])
        Msel=lv1.cond(test(1), lv1.cond(test(2), lv1.cond(test(3), M[q,4], M[q,3]), M[q,2]), lv1.cond(test(0), M[q,1], M[q,0]))
        return (R@lv1.maximum(Msel@xv,0.0)).argmax()
    fb=[fallback(q) for q in range(4)]
    def octant(a,q):
        capv=Tp[a,q]@x01
        return lv1.cond((x2>capv) if a==0 else (x2<capv), o[a], fb[q])
    def half(a):
        return lv1.cond(t0, lv1.cond(t1, octant(a,0), octant(a,1)), lv1.cond(t1, octant(a,2), octant(a,3)))
    pred=lv1.cond(t2, half(0), half(1))
    return g.entry(interpretation=pred), dict(T=T,Vray=Vray)
entry,dbg=build_entry(graph())
print("nodes",len(entry['nodes']))
print("T",np.round(np.array(dbg['T'].value),3))
if len(entry['nodes'])<=400:
    res=measure(entry); print(res); save_entry("greedy_v2",entry)
    # x0 = 0 behaviour
    ev=lv1.Evaluator(entry,weights,3)
    try: print("x0=0 ->", ev.run([0.0,1.0,1.0]))
    except Exception as e: print("x0=0 err", e)
