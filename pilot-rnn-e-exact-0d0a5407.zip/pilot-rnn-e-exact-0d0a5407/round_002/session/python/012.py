
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
BIG=1e9
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def build_T(w,rec,R,THBIG=1e30):
    """numpy prototype of the in-entry build: returns T[s2idx,q] (2,4,2), theta sorted (4,4), Bp (4,5,4,3) acting on (x0,x1,x2)"""
    S0 = np.array([1,1,-1,-1.]); S1=np.array([1,-1,1,-1.])
    up = rec@np.maximum(w,0); um = -rec@np.maximum(-w,0)
    a = w[None,:]*S1[:,None]; b = np.where(S0[:,None]>0, up[None,:], um[None,:])*S0[:,None]
    asafe = np.where(a==0,1.0,a)
    th = np.where(a*b<0, -b/asafe, THBIG)
    ths = np.sort(th,axis=1)                       # (4,4)
    lo = np.concatenate([np.zeros((4,1)), ths],1)  # (4,5)
    hi = np.concatenate([ths, np.full((4,1),THBIG)],1)
    r = (lo+hi)/2
    alive = (a[:,None,:]*r[:,:,None] + b[:,None,:]) > 0   # (4,5,4)
    A = alive[...,None]*np.stack([b,a],2)[:,None,:,:]      # (4,5,4,2) on (|x0|,|x1|)
    B = np.einsum('jk,qikc->qijc', rec, A)                 # (4,5,4,2)
    Bp = np.concatenate([B*np.stack([S0,S1],1)[:,None,None,:], np.broadcast_to(w[None,None,:,None],(4,5,4,1))],3)  # (4,5,4,3) on (x0,x1,x2)
    # edges: m=0..5 ; e_m = (1,theta_{m-1}) with theta_{-1}=0, or (0,1) if theta>=THBIG; m=5 -> (0,1)
    thm = np.concatenate([np.zeros((4,1)), ths, np.full((4,1),THBIG)],1)   # (4,6)
    E = np.where(thm[...,None]>=THBIG, np.array([0.,1.]), np.stack([np.ones_like(thm), thm],-1))  # (4,6,2)
    T_all = np.zeros((2,4,2))
    for si,s2 in enumerate([1,-1]):
        o = (R@np.maximum(w*s2,0)).argmax()
        ks = [k for k in range(3) if k!=o]
        Bz = B*np.array([1.0,1.0])  # on (|x0|,|x1|) : B already acts on abs values
        Bz = np.concatenate([Bz, np.broadcast_to((w*s2)[None,None,:,None],(4,5,4,1))],3)  # (4,5,4,3) on (|x0|,|x1|,|x2|)
        P = (w*s2)>0
        Vreq = np.full((4,6), -BIG)
        for q in range(4):
            for i in range(5):
                cons=[]
                for k in ks:
                    d = R[o]-R[k]
                    c = (d[:,None]*Bz[q,i]*P[:,None]).sum(0); cons.append((c,True))
                    for j in range(4):
                        if d[j]<0: cons.append((Bz[q,i,j] if P[j] else -Bz[q,i,j], False))
                for m in (i,i+1):
                    e = E[q,m]
                    for g,strict in cons:
                        ge = g[0]*e[0]+g[1]*e[1]
                        if g[2]>0: v = -ge/g[2]
                        elif g[2]==0 and ge>0: v=-BIG
                        else: v=BIG
                        Vreq[q,m]=max(Vreq[q,m],v)
        for q in range(4):
            best=None
            cands=[np.array([BIG,BIG])]
            for m in range(6):
                for m2 in range(m+1,6):
                    e,e2=E[q,m],E[q,m2]; det=e[0]*e2[1]-e[1]*e2[0]
                    if abs(det)<1e-12: continue
                    cands.append(np.array([(Vreq[q,m]*e2[1]-Vreq[q,m2]*e[1])/det, (e[0]*Vreq[q,m2]-e2[0]*Vreq[q,m])/det]))
            for T in cands:
                if ((E[q]@T) >= Vreq[q]-1e-9*(1+abs(Vreq[q]))).all():
                    if best is None or T.sum()<best.sum(): best=T
            T_all[si,q]=best+1e-7*(1+np.abs(best))
    return T_all, ths, Bp
def predict_np(X,w,rec,R):
    T_all,ths,Bp = build_T(w,rec,R)
    out = np.zeros(len(X),int); fb=np.zeros(len(X),bool)
    Z=np.abs(X)
    for si,s2 in enumerate([1,-1]):
        o = (R@np.maximum(w*s2,0)).argmax()
        for q,(s0,s1) in enumerate([(1,1),(1,-1),(-1,1),(-1,-1)]):
            sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)
            T=T_all[si,q]
            c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1])
            out[c]=o
            rest = sel&~c; fb|=rest
            # sector index
            r = Z[rest,1]/np.maximum(Z[rest,0],1e-300)
            idx = (r[:,None] > ths[q][None,:]).sum(1)
            p = np.einsum('nkc,nc->nk', Bp[q][idx], X[rest])
            out[rest] = (np.maximum(p,0)@R.T).argmax(1)
    return out, fb
rng = np.random.default_rng(5)
X = rng.standard_normal((300000,3))
y = net(X,w,rec,R); yp,fb = predict_np(X,w,rec,R)
print('errors',(y!=yp).sum(),'fallback frac',fb.mean())
# random weights check
for seed in range(12):
    rg=np.random.default_rng(100+seed)
    sc = [0.3,0.5,1.0][seed%3]
    w2=rg.standard_normal(4)*sc; rec2=rg.standard_normal((4,4))*sc; R2=rg.standard_normal((3,4))*sc
    if seed==10: w2[0]=0.0
    if seed==11: R2[1]=R2[0]
    X2=rg.standard_normal((100000,3)); y2=net(X2,w2,rec2,R2); yp2,fb2=predict_np(X2,w2,rec2,R2)
    print(seed,'errors',(y2!=yp2).sum(),'fb',round(fb2.mean(),3), 'out dist',np.bincount(y2,minlength=3)/len(y2))
