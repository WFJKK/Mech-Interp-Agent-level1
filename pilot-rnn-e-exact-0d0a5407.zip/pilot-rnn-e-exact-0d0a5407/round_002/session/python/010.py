
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
INF=1e9
def net(X, w=w, rec=rec, R=R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def sectors(s0,s1, w=w, rec=rec):
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    th = sorted([(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0])
    edges = [0]+th+[np.inf]; out=[]
    for i in range(len(edges)-1):
        r = (edges[i]+edges[i+1])/2 if np.isfinite(edges[i+1]) else edges[i]+1
        alive = (a*r + b) > 0
        out.append((edges[i],edges[i+1],np.stack([b*alive, a*alive],1)))
    return out
def half_to_T(c):
    if c[2] > 0: return -c[:2]/c[2]
    if c[2] == 0 and (c[:2] >= 0).all(): return np.array([-INF,-INF])
    return None
def T_mask(B, d, mask, use_cons=True):
    P = B[:,2] > 0; c = np.zeros(3); cons=[]
    for j in range(4):
        if mask[j]:
            if P[j]:
                c += d[j]*B[j]
                if d[j] < 0:
                    if not use_cons: return None
                    cons.append(B[j])
            else:
                if d[j] < 0:
                    if not use_cons: return None
                    cons.append(-B[j])
        else:
            if d[j] < 0: c += d[j]*np.maximum(B[j],0)
    Ts = [half_to_T(c)] + [half_to_T(cc) for cc in cons]
    if any(t is None for t in Ts): return None
    return np.max(np.stack(Ts),0)
def quadrant_T_r1(s2,s0,s1,o, w=w, rec=rec, R=R):
    # round-1 style: h1 <= relu(a)|x1| + relu(b)|x0| bound (exact for same-sign units)
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    Aup = np.stack([np.maximum(b,0), np.maximum(a,0)],1)   # upper bound matrix on h1 (|x0|,|x1|)
    dead = (a<=0)&(b<=0); Aup[dead]=0
    lin = (a>=0)&(b>=0)
    Alo = np.zeros((4,2)); Alo[lin] = np.stack([b,a],1)[lin]    # lower bound (exact for linear)
    best = None
    Ts=[]
    for k in range(3):
        if k==o: continue
        d = R[o]-R[k]; opts=[]
        for mask in itertools.product([0,1],repeat=4):
            c = np.zeros(3)  # coefficient on (|x0|,|x1|,|x2|)
            ok=True
            for j in range(4):
                if mask[j]:   # linear: d_j p_j = d_j (rec_j h1 + w_j s2 |x2|) ; valid lower bound if d_j>=0
                    if d[j] < 0: ok=False; break
                    c[2] += d[j]*w[j]*s2
                    # d_j rec_j h1 >= sum_i d_j rec_ji * (lower if d_j rec_ji>=0 else upper)
                    for i in range(4):
                        coef = d[j]*rec[j,i]
                        c[:2] += coef*(Alo[i] if coef>=0 else Aup[i])
                else:
                    if d[j] < 0:
                        # d_j relu(p_j) >= d_j * relu-upper(p_j) ; p_j <= relu(w_j s2)|x2| + sum_i relu(rec_ji) h1_i <= ... Aup
                        c[2] += d[j]*max(w[j]*s2,0)
                        for i in range(4):
                            c[:2] += d[j]*max(rec[j,i],0)*Aup[i]
            if not ok: continue
            T = half_to_T(c)
            if T is not None: opts.append(T)
        Ts.append(min(opts,key=lambda t:t.sum()))
    return np.max(np.stack(Ts),0)
def quadrant_T_sector(s2,s0,s1,o, w=w, rec=rec, R=R, iters=3):
    secs = sectors(s0,s1,w,rec)
    Bs = [np.concatenate([rec@A,(w*s2)[:,None]],1) for _,_,A in secs]
    ks = [k for k in range(3) if k!=o]
    # options per (sector,k)
    opts = {(si,k):[T for m in itertools.product([0,1],repeat=4) for T in [T_mask(Bs[si],R[o]-R[k],m)] if T is not None] for si in range(len(Bs)) for k in ks}
    # same-mask variant
    best_same=None
    Tk=[]
    for k in ks:
        bestk=None
        for m in itertools.product([0,1],repeat=4):
            Ts=[T_mask(Bs[si],R[o]-R[k],m) for si in range(len(Bs))]
            if any(t is None for t in Ts): continue
            T=np.max(np.stack(Ts),0)
            if bestk is None or T.sum()<bestk.sum(): bestk=T
        Tk.append(bestk)
    T_same = np.max(np.stack(Tk),0)
    # coordinate descent
    choice = {key: min(range(len(v)), key=lambda i: v[i].sum()) for key,v in opts.items()}
    def total(choice): return np.max(np.stack([opts[key][i] for key,i in choice.items()]),0)
    cur = total(choice)
    for _ in range(iters):
        for key in opts:
            for i in range(len(opts[key])):
                c2 = dict(choice); c2[key]=i; t=total(c2)
                if t.sum() < cur.sum(): cur=t; choice=c2
    return T_same, cur
rng = np.random.default_rng(3); X = rng.standard_normal((400000,3)); y = net(X); Z=np.abs(X)
res = {}
for name in ['r1','same','cd']: res[name]=np.zeros(len(X),bool)
for s2 in [1,-1]:
    o = (R@np.maximum(w*s2,0)).argmax()
    for s0 in [1,-1]:
        for s1 in [1,-1]:
            sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)
            T1 = quadrant_T_r1(s2,s0,s1,o); Ts, Tc = quadrant_T_sector(s2,s0,s1,o)
            # also combine: min of r1 and cd componentwise is NOT valid; but max is. choose better by sum
            for name,T in [('r1',T1),('same',Ts),('cd',Tc)]:
                c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1]); assert (y[c]==o).all(); res[name]|=c
            print(s2,s0,s1,'r1',np.round(T1,3),'same',np.round(Ts,3),'cd',np.round(Tc,3))
for name in res: print(name, res[name].mean())
