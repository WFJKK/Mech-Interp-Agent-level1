
import numpy as np, itertools, json
BUILDER_SRC = r'''
def build_entry(profiles=((0,1),(1,0)), THBIG=1e30, BIG=1e9, bump=1e-6, tol=1e-9):
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    X = g.tokens(); x01 = lv1.stack([x0,x1])
    S0 = g.const([1.,1.,-1.,-1.]); S1 = g.const([1.,-1.,1.,-1.])
    up = rec @ lv1.maximum(w, 0.0); um = -(rec @ lv1.maximum(-w, 0.0))
    a = w.reshape(1,4) * S1.reshape(4,1)
    b = lv1.where(S0.reshape(4,1) > 0.0, up.reshape(1,4), um.reshape(1,4)) * S0.reshape(4,1)
    th = lv1.where(a*b < 0.0, -b / lv1.where(a == 0.0, 1.0, a), THBIG)
    ths = lv1.sort(th, axis=1)
    z41 = g.const(np.zeros((4,1))); big41 = g.const(np.full((4,1), THBIG))
    lo = lv1.concat([z41, ths], axis=1); hi = lv1.concat([ths, big41], axis=1)
    r = (lo + hi) * 0.5
    alive = (a.reshape(4,1,4) * r.reshape(4,5,1) + b.reshape(4,1,4)) > 0.0
    ba = lv1.stack([b, a], axis=2)
    A = lv1.cast(alive, "float").reshape(4,5,4,1) * ba.reshape(4,1,4,2)
    B = rec @ A                                   # (4,5,4,2)
    z4511 = g.const(np.zeros((4,5,1,1)))
    SS = lv1.stack([S0,S1], axis=1)               # (4,2)
    Bp = lv1.concat([B * SS.reshape(4,1,1,2), w.reshape(1,1,4,1) + z4511], axis=3)   # (4,5,4,3)
    thm = lv1.concat([z41, ths, big41], axis=1)   # (4,6)
    isinf = thm >= THBIG
    E0 = lv1.where(isinf, 0.0, 1.0); E1 = lv1.where(isinf, 1.0, thm)
    E0s = lv1.stack([E0[:,0:5], E0[:,1:6]], axis=2); E1s = lv1.stack([E1[:,0:5], E1[:,1:6]], axis=2)  # (4,5,2)
    W = 1.0 / (E0s + E1s)
    def vfun(G, strict, e0, e1):
        # G (...,3); e0,e1 broadcastable to G[...,0:1] shape with trailing 2
        n = len(G.shape)
        idx = lambda c: tuple([slice(None)]*(n-1) + [slice(c,c+1)])
        G0, G1, G2 = G[idx(0)], G[idx(1)], G[idx(2)]
        ge = G0*e0 + G1*e1
        pos = G2 > 0.0
        v = -(ge / lv1.where(pos, G2, 1.0))
        fz = (G2 == 0.0) & ((ge > 0.0) if strict else (ge >= 0.0))
        return lv1.where(pos, v, lv1.where(fz, -BIG, BIG))
    # batched over s2
    ws = lv1.stack([w, -w], axis=0)                                   # (2,4)
    o = (R @ lv1.maximum(ws, 0.0).T).argmax(axis=0)                   # (2,)
    P = lv1.cast(ws > 0.0, "float")                                   # (2,4)
    k1 = (o + 1) % 3; k2 = (o + 2) % 3
    Ro = lv1.take(R, o, axis=0); D = lv1.stack([Ro - lv1.take(R, k1, axis=0), Ro - lv1.take(R, k2, axis=0)], axis=1)   # (2,2,4)
    z2 = g.const(np.zeros((2,1,1,1,1))); z45 = g.const(np.zeros((1,4,5,1,1)))
    Bz = lv1.concat([B.reshape(1,4,5,4,2) + z2, ws.reshape(2,1,1,4,1) + z45], axis=4)    # (2,4,5,4,3)
    Bz6 = Bz.reshape(2,4,5,1,4,3); D6 = D.reshape(2,1,1,2,4,1); P6 = P.reshape(2,1,1,1,4,1)
    lin = D6 * Bz6
    relu_t = D6 * lv1.maximum(Bz6, 0.0)
    dpos = D6 >= 0.0; Pb = P6 > 0.0
    base = lin * P6
    E0s5 = E0s.reshape(1,4,5,1,2); E1s5 = E1s.reshape(1,4,5,1,2)
    vg_plus = vfun(Bz, False, E0s5, E1s5).reshape(2,4,5,1,4,2)
    vg_minus = vfun(-Bz, False, E0s5, E1s5).reshape(2,4,5,1,4,2)
    Dneg = D < 0.0                                                     # (2,2,4)
    actA = (Dneg & (P.reshape(2,1,4) > 0.0)).reshape(2,1,1,2,4,1)
    actB = (Dneg & (P.reshape(2,1,4) <= 0.0)).reshape(2,1,1,2,4,1)
    vals_list = []
    for (m2,m3) in profiles:
        if (m2,m3) == (0,1):
            contrib = lv1.where(dpos, base, lv1.where(Pb, lin, relu_t))
            vc = lv1.where(actA, vg_plus, -BIG).max(axis=4)
        elif (m2,m3) == (1,0):
            contrib = lv1.where(dpos, base, lv1.where(Pb, relu_t, 0.0))
            vc = lv1.where(actB, vg_minus, -BIG).max(axis=4)
        elif (m2,m3) == (0,0):
            contrib = lv1.where(dpos, base, lv1.where(Pb, lin, 0.0))
            vc = lv1.maximum(lv1.where(actA, vg_plus, -BIG), lv1.where(actB, vg_minus, -BIG)).max(axis=4)
        else:
            contrib = lv1.where(dpos, base, relu_t); vc = None
        c = contrib.sum(axis=4)                                          # (2,4,5,2,3)
        vm = vfun(c, True, E0s5, E1s5)                                   # (2,4,5,2,2)
        vals_list.append(vm if vc is None else lv1.maximum(vm, vc))
    W5 = W.reshape(1,4,5,1,2)
    best = vals_list[0]; bestsc = (best * W5).sum(axis=4)
    for vals in vals_list[1:]:
        sc = (vals * W5).sum(axis=4)
        better = sc < bestsc
        best = lv1.where(better.reshape(2,4,5,2,1), vals, best); bestsc = lv1.where(better, sc, bestsc)
    vals = best.max(axis=3)                                               # (2,4,5,2)
    zB = g.const(np.full((2,4,1), -BIG)); bigB = g.const(np.full((2,4,1), BIG))
    Vreq = lv1.maximum(lv1.concat([vals[:,:,:,0], zB], axis=2), lv1.concat([zB, vals[:,:,:,1]], axis=2))   # (2,4,6)
    pairsA = [m for m in range(6) for m2 in range(m+1,6)]; pairsB = [m2 for m in range(6) for m2 in range(m+1,6)]
    idxA = g.const(pairsA); idxB = g.const(pairsB)
    E0b = E0.reshape(1,4,6) + g.const(np.zeros((2,1,1))); E1b = E1.reshape(1,4,6) + g.const(np.zeros((2,1,1)))
    EA0 = lv1.take(E0b, idxA, axis=2); EA1 = lv1.take(E1b, idxA, axis=2); EB0 = lv1.take(E0b, idxB, axis=2); EB1 = lv1.take(E1b, idxB, axis=2)
    VA = lv1.take(Vreq, idxA, axis=2); VB = lv1.take(Vreq, idxB, axis=2)
    det = EA0*EB1 - EA1*EB0
    sing = abs(det) < 1e-12
    dsafe = lv1.where(sing, 1.0, det)
    T0 = lv1.where(sing, BIG, (VA*EB1 - VB*EA1)/dsafe); T1 = lv1.where(sing, BIG, (EA0*VB - EB0*VA)/dsafe)
    T0c = lv1.concat([T0, bigB], axis=2); T1c = lv1.concat([T1, bigB], axis=2)       # (2,4,16)
    lhs = E0b.reshape(2,4,6,1)*T0c.reshape(2,4,1,16) + E1b.reshape(2,4,6,1)*T1c.reshape(2,4,1,16)
    rhs = (Vreq - tol*(1.0 + abs(Vreq))).reshape(2,4,6,1)
    feas = (lhs >= rhs).all(axis=2)                                      # (2,4,16)
    score = lv1.where(feas, T0c + T1c, 2.0*BIG)
    idx = score.argmin(axis=2)                                            # (2,4)
    onehot = lv1.cast(g.arange(16).reshape(1,1,16) == idx.reshape(2,4,1), "float")
    T0sel = (T0c * onehot).sum(axis=2); T1sel = (T1c * onehot).sum(axis=2)   # (2,4)
    T0sel = T0sel + bump*(1.0 + abs(T0sel)); T1sel = T1sel + bump*(1.0 + abs(T1sel))
    SGN = g.const(np.array([[[s0*s2, s1*s2] for (s0,s1) in [(1,1),(1,-1),(-1,1),(-1,-1)]] for s2 in (1,-1)], dtype=float))  # (2,4,2)
    Tq = lv1.stack([T0sel, T1sel], axis=2) * SGN                           # (2,4,2)
    # runtime
    fallback = []
    for q in range(4):
        s0, s1 = [(1,1),(1,-1),(-1,1),(-1,-1)][q]
        def sec_test(m):
            c = ths[q, m] * float(s0*s1)
            return (x1 > c*x0) if s1 > 0 else (x1 < c*x0)
        def leaf(i): return Bp[q, i] @ X
        p = lv1.cond(sec_test(1), lv1.cond(sec_test(2), lv1.cond(sec_test(3), leaf(4), leaf(3)), leaf(2)), lv1.cond(sec_test(0), leaf(1), leaf(0)))
        fallback.append((R @ lv1.maximum(p, 0.0)).argmax())
    def leaf2(si, q):
        lin = Tq[si, q] @ x01
        test = (x2 > lin) if si == 0 else (x2 < lin)
        return lv1.cond(test, o[si], fallback[q])
    def side(si):
        return lv1.cond(x0 > 0.0, lv1.cond(x1 > 0.0, leaf2(si,0), leaf2(si,1)), lv1.cond(x1 > 0.0, leaf2(si,2), leaf2(si,3)))
    out = lv1.cond(x2 > 0.0, side(0), side(1))
    return g.entry(interpretation=out), g
'''
exec(BUILDER_SRC)
try:
    entry, g = build_entry()
    print('nodes', len(entry['nodes']))
    m = measure(entry); print(m)
    save_entry('sec_p2', entry)
    save_entry('builder_src', {'src': BUILDER_SRC})
except Exception as e:
    import traceback; traceback.print_exc()
