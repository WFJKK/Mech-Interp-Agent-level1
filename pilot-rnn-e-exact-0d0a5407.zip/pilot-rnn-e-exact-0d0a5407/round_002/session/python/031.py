
import inspect, numpy as np
src = inspect.getsource(lv1.Evaluator.run); print(src[:1500])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
ev = lv1.Evaluator(entries['sec_p2'], weights, 3)
rng = np.random.default_rng(9); X = rng.standard_normal((3000,3)); y = net(X)
res = []
for x in X:
    r = ev.run(list(x))
    res.append(r)
print(type(res[0]), res[0])
