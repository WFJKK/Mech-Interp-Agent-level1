
import os, collections, numpy as np
BUILDER_SRC = r'''
def build_entry(profiles=((0,1),(1,0)), THBIG=1e30, BIG=1e9, bump=1e-6, tol=1e-9):
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    X = g.tokens(); x01 = lv1.stack([x0,x1])
    wn = -w
    up = rec @ lv1.maximum(w, 0.0); um0 = rec @ lv1.maximum(wn, 0.0)
    a = lv1.stack([w, wn, w, wn], axis=0)          # (q,j) = w*s1
    b = lv1.stack([up, up, um0, um0], axis=0)      # (q,j) = u_{s0}*s0
    th = lv1.where(a*b < 0.0, -b / lv1.where(a == 0.0, 1.0, a), THBIG)
    ths = lv1.sort(th, axis=1)
    z41 = g.const(np.zeros((4,1))); big41 = g.const(np.full((4,1), THBIG))
    thm = lv1.concat([z41, ths, big41], axis=1)   # (4,6)
    thms = lv1.stack([thm[:,0:5], thm[:,1:6]], axis=2)   # (4,5,2)
    r = thms.sum(axis=2) * 0.5
    alive = (a.reshape(4,1,4) * r.reshape(4,5,1) + b.reshape(4,1,4)) > 0.0
    ba = lv1.stack([b, a], axis=2)
    A = lv1.cast(alive, "float").reshape(4,5,4,1) * ba.reshape(4,1,4,2)
    B = rec @ A                                   # (4,5,4,2)
    z4511 = g.const(np.zeros((4,5,1,1)))
    SS = g.const([[1.,1.],[1.,-1.],[-1.,1.],[-1.,-1.]])
    Bp = lv1.concat([B * SS.reshape(4,1,1,2), w.reshape(1,1,4,1) + z4511], axis=3)   # (4,5,4,3)
    isinf = thm >= THBIG
    E0 = lv1.where(isinf, 0.0, 1.0); E1 = lv1.where(isinf, 1.0, thm)
    thms5 = thms.reshape(1,4,5,1,2)
    isinf5 = thms5 >= THBIG
    E0s5 = lv1.where(isinf5, 0.0, 1.0); E1s5 = lv1.where(isinf5, 1.0, thms5)
    def comps(G):
        n = len(G.shape)
        idx = lambda c: tuple([slice(None)]*(n-1) + [slice(c,c+1)])
        return G[idx(0)], G[idx(1)], G[idx(2)]
    def vfun(G, strict):
        G0, G1, G2 = comps(G)
        ge = G0*E0s5 + G1*E1s5
        pos = G2 > 0.0
        v = -(ge / lv1.where(pos, G2, 1.0))
        fz = (G2 == 0.0) & ((ge > 0.0) if strict else (ge >= 0.0))
        return lv1.where(pos, v, lv1.where(fz, -BIG, BIG))
    def vfun_pm(G):
        G0, G1, G2 = comps(G)
        ge = G0*E0s5 + G1*E1s5
        z = G2 == 0.0
        pos = G2 > 0.0
        vp = lv1.where(pos, -(ge / lv1.where(pos, G2, 1.0)), lv1.where(z & (ge >= 0.0), -BIG, BIG))
        neg = G2 < 0.0
        vm = lv1.where(neg, ge / lv1.where(neg, -G2, 1.0), lv1.where(z & (ge <= 0.0), -BIG, BIG))
        return vp, vm
    ws = lv1.stack([w, wn], axis=0)                                   # (2,4)
    o = (R @ lv1.maximum(ws, 0.0).T).argmax(axis=0)                   # (2,)
    Pbool = ws > 0.0
    Ro = lv1.take(R, o, axis=0); D = lv1.stack([Ro - lv1.take(R, (o + 1) % 3, axis=0), Ro - lv1.take(R, (o + 2) % 3, axis=0)], axis=1)   # (2,2,4)
    Bz = lv1.concat([B.reshape(1,4,5,4,2) + g.const(np.zeros((2,1,1,1,1))), ws.reshape(2,1,1,4,1) + g.const(np.zeros((1,4,5,1,1)))], axis=4)    # (2,4,5,4,3)
    Bz6 = Bz.reshape(2,4,5,1,4,3); D6 = D.reshape(2,1,1,2,4,1); Pb = Pbool.reshape(2,1,1,1,4,1)
    lin = D6 * Bz6
    relu_t = D6 * lv1.maximum(Bz6, 0.0)
    dpos = D6 >= 0.0
    base = lin * lv1.cast(Pb, "float")
    vgp, vgm = vfun_pm(Bz)
    vg_plus = vgp.reshape(2,4,5,1,4,2); vg_minus = vgm.reshape(2,4,5,1,4,2)
    Dneg = (D < 0.0).reshape(2,1,1,2,4,1)
    actA = Dneg & Pb; actB = Dneg & ~Pb
    vals_list = []
    for (m2,m3) in profiles:
        if (m2,m3) == (0,1):
            contrib = lv1.where(dpos, base, lv1.where(Pb, lin, relu_t))
            vc = lv1.where(actA, vg_plus, -BIG).max(axis=4)
        elif (m2,m3) == (1,0):
            contrib = lv1.where(dpos, base, lv1.where(Pb, relu_t, 0.0))
            vc = lv1.where(actB, vg_minus, -BIG).max(axis=4)
        elif (m2,m3) == (0,0):
            contrib = lv1.where(dpos, base, lv1.where(Pb, lin, 0.0))
            vc = lv1.maximum(lv1.where(actA, vg_plus, -BIG), lv1.where(actB, vg_minus, -BIG)).max(axis=4)
        else:
            contrib = lv1.where(dpos, base, relu_t); vc = None
        vm = vfun(contrib.sum(axis=4), True)                             # (2,4,5,2,2)
        vals_list.append(vm if vc is None else lv1.maximum(vm, vc))
    scf = lambda v: v.sum(axis=4)
    best = vals_list[0]; bestsc = scf(best)
    for vals in vals_list[1:]:
        sc = scf(vals)
        better = sc < bestsc
        best = lv1.where(better.reshape(2,4,5,2,1), vals, best); bestsc = lv1.where(better, sc, bestsc)
    vals = best.max(axis=3)                                               # (2,4,5,2)
    zB = g.const(np.full((2,4,1), -BIG)); bigB = g.const(np.full((2,4,1), BIG))
    Vreq = lv1.maximum(lv1.concat([vals[:,:,:,0], zB], axis=2), lv1.concat([zB, vals[:,:,:,1]], axis=2))   # (2,4,6)
    pairsA = [m for m in range(6) for m2 in range(m+1,6)]; pairsB = [m2 for m in range(6) for m2 in range(m+1,6)]
    idxA = g.const(pairsA); idxB = g.const(pairsB)
    EA0 = lv1.take(E0, idxA, axis=1).reshape(1,4,15); EA1 = lv1.take(E1, idxA, axis=1).reshape(1,4,15)
    EB0 = lv1.take(E0, idxB, axis=1).reshape(1,4,15); EB1 = lv1.take(E1, idxB, axis=1).reshape(1,4,15)
    VA = lv1.take(Vreq, idxA, axis=2); VB = lv1.take(Vreq, idxB, axis=2)
    det = EA0*EB1 - EA1*EB0
    sing = abs(det) < 1e-12
    dsafe = lv1.where(sing, 1.0, det)
    T0 = lv1.where(sing, BIG, (VA*EB1 - VB*EA1)/dsafe); T1 = lv1.where(sing, BIG, (EA0*VB - EB0*VA)/dsafe)
    T0c = lv1.concat([T0, bigB], axis=2); T1c = lv1.concat([T1, bigB], axis=2)       # (2,4,16)
    lhs = E0.reshape(1,4,6,1)*T0c.reshape(2,4,1,16) + E1.reshape(1,4,6,1)*T1c.reshape(2,4,1,16)
    rhs = (Vreq - tol*(1.0 + abs(Vreq))).reshape(2,4,6,1)
    feas = (lhs >= rhs).all(axis=2)                                      # (2,4,16)
    score = lv1.where(feas, T0c + T1c, 2.0*BIG)
    smin = score.min(axis=2)                                              # (2,4)
    isbest = score == smin.reshape(2,4,1)
    T0sel = lv1.where(isbest, T0c, BIG).min(axis=2)
    T1sel = smin - T0sel
    Tsel = lv1.stack([T0sel, T1sel], axis=2)                              # (2,4,2)
    Tsel = Tsel + bump*(1.0 + abs(Tsel))
    SGN = g.const(np.array([[[s0*s2, s1*s2] for (s0,s1) in [(1,1),(1,-1),(-1,1),(-1,-1)]] for s2 in (1,-1)], dtype=float))  # (2,4,2)
    Tq = Tsel * SGN
    x1n = -x1
    # runtime
    fallback = []
    for q in range(4):
        s0, s1 = [(1,1),(1,-1),(-1,1),(-1,-1)][q]
        def sec_test(m):
            # |x1| > th |x0|  <=>  s1*x1 > th*s0*x0
            tx = ths[q, m] * x0
            if s0 > 0: return (x1 > tx) if s1 > 0 else (x1n > tx)
            else:      return (x1n < tx) if s1 > 0 else (x1 < tx)
        def leaf(i): return Bp[q, i]
        M = lv1.cond(sec_test(1), lv1.cond(sec_test(2), lv1.cond(sec_test(3), leaf(4), leaf(3)), leaf(2)), lv1.cond(sec_test(0), leaf(1), leaf(0)))
        fallback.append((R @ lv1.maximum(M @ X, 0.0)).argmax())
    def leaf2(si, q):
        lin = Tq[si, q] @ x01
        test = (x2 > lin) if si == 0 else (x2 < lin)
        return lv1.cond(test, o[si], fallback[q])
    def side(si):
        return lv1.cond(x0 > 0.0, lv1.cond(x1 > 0.0, leaf2(si,0), leaf2(si,1)), lv1.cond(x1 > 0.0, leaf2(si,2), leaf2(si,3)))
    out = lv1.cond(x2 > 0.0, side(0), side(1))
    return g.entry(interpretation=out), g
'''
exec(BUILDER_SRC)
entry, g = build_entry()
print('nodes', len(entry['nodes']))
m = measure(entry); print(m)
if m['fidelity'] == 1.0: save_entry('sec_p2', entry)
# random-weight checks
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
for seed in range(10):
    rg=np.random.default_rng(200+seed); sc=[0.3,0.5,1.0,2.0][seed%4]
    w2=rg.standard_normal((4,1))*sc; rec2=rg.standard_normal((4,4))*sc; R2=rg.standard_normal((3,4))*sc
    if seed==7: w2[1,0]=0.0
    if seed==8: R2[2]=R2[0]
    if seed==9: w2[:,0]=np.abs(w2[:,0])
    W2={'input':w2,'recurrent':rec2,'readout':R2}
    ev = lv1.Evaluator(entry, W2, 3)
    X2=rg.standard_normal((1500,3)); y2=net(X2,w2[:,0],rec2,R2)
    pred=[]; cost=[]
    for x in X2:
        r=ev.run(list(x)); pred.append(r[1]); cost.append(r[3])
    pred=np.array(pred); print(seed,'errors',(pred!=y2).sum(),'mean cost',np.mean(cost),'build',ev.build_cost)
