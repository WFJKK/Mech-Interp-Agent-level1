
import collections
entry = None
exec(open('/dev/null').read())
# rebuild quickly using the previous function? Not persisted. Re-define minimal: load from save? not saved. Rebuild here by re-running the builder source would be long; instead inspect node kinds from a small test graph
g = graph()
x = g.token(0)
y = (x > 0.0); z = (x > 0.0); u = x*1.0; v = x*1.0
print(len(g.nodes))
print(lv1.show(g.entry(interpretation=lv1.cast(y,'int')+lv1.cast(z,'int'))))
