
import os
try:
    os.makedirs('tmp', exist_ok=True); open('tmp/test.txt','w').write('x'); print('tmp write ok', os.listdir('tmp'))
except Exception as e: print('tmp fail', e)
