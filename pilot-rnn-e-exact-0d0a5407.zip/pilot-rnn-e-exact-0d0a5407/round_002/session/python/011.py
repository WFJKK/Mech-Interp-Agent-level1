
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
INF=1e9
def net(X, w=w, rec=rec, R=R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def sectors(s0,s1, w=w, rec=rec):
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    th = sorted([(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0])
    edges = [0]+th+[np.inf]; out=[]
    for i in range(len(edges)-1):
        r = (edges[i]+edges[i+1])/2 if np.isfinite(edges[i+1]) else edges[i]+1
        alive = (a*r + b) > 0
        out.append((edges[i],edges[i+1],np.stack([b*alive, a*alive],1)))
    return out
def option_cons(B, d, mask):
    """returns list of constraints c (3-vectors, need c.z>0) or None if invalid"""
    P = B[:,2] > 0; c = np.zeros(3); cons=[]
    for j in range(4):
        if mask[j]:
            if P[j]:
                c += d[j]*B[j]
                if d[j] < 0: cons.append(B[j])
            else:
                if d[j] < 0: cons.append(-B[j])
        else:
            if d[j] < 0: c += d[j]*np.maximum(B[j],0)
    return [c]+cons
def edge_vals(cons, edges):
    """for each edge e (2-vec), required threshold max over constraints of t.e where c.z>0 <=> |x2| > t.e... returns array or None"""
    vals=[]
    for e in edges:
        v=-INF
        for c in cons:
            if c[2] > 0: v = max(v, -(c[0]*e[0]+c[1]*e[1])/c[2])
            elif c[0]*e[0]+c[1]*e[1] >= 0 and c[2]==0: pass
            else: return None
        vals.append(v)
    return np.array(vals)
def solve_lp(cons_list):
    """cons_list: list of (e, v): need T.e >= v. minimize T0+T1. brute-force vertices."""
    A = np.array([e for e,v in cons_list]); b = np.array([v for e,v in cons_list])
    best=None
    n=len(A)
    cands=[]
    for i in range(n):
        for j in range(i+1,n):
            M = np.stack([A[i],A[j]]); 
            if abs(np.linalg.det(M))<1e-12: continue
            T = np.linalg.solve(M, b[[i,j]]); cands.append(T)
    for T in cands:
        if (A@T >= b-1e-9).all():
            if best is None or T.sum()<best.sum(): best=T
    return best
def quadrant_T_lp(s2,s0,s1,o,w=w,rec=rec,R=R):
    secs = sectors(s0,s1,w,rec); ks=[k for k in range(3) if k!=o]
    cons_list=[]
    for lo,hi,A in secs:
        B = np.concatenate([rec@A,(w*s2)[:,None]],1)
        edges = [np.array([1.0,lo]), (np.array([1.0,hi]) if np.isfinite(hi) else np.array([0.0,1.0]))]
        for k in ks:
            best=None
            for m in itertools.product([0,1],repeat=4):
                cons = option_cons(B,R[o]-R[k],m); v = edge_vals(cons,edges)
                if v is None: continue
                if best is None or v.sum()<best.sum(): best=v
            if best is None: return None
            for e,v in zip(edges,best): cons_list.append((e,v))
    return solve_lp(cons_list)
rng = np.random.default_rng(3); X = rng.standard_normal((400000,3)); y = net(X); Z=np.abs(X)
caught=np.zeros(len(X),bool)
for s2 in [1,-1]:
    o = (R@np.maximum(w*s2,0)).argmax()
    for s0 in [1,-1]:
        for s1 in [1,-1]:
            sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)
            T = quadrant_T_lp(s2,s0,s1,o)
            c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1]); assert (y[c]==o).all(); caught|=c
            print(s2,s0,s1,np.round(T,3),'catch',round(c.sum()/sel.sum(),3))
print('LP quadrant catch',caught.mean())
