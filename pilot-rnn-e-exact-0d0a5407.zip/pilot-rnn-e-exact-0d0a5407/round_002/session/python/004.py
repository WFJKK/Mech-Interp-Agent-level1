
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
INF=1e9
def T_options(B, s2, o, mode):
    """B: 4x3 rows act on z=(|x0|,|x1|,|x2|) giving p. returns list of candidate T (2-vectors) valid as sufficient tests."""
    P = B[:,2] > 0  # units firing in the limit
    def half_to_T(c):  # constraint c.z > 0 -> |x2| > T.z'  ; returns T or None if impossible
        if c[2] > 0: return -c[:2]/c[2]
        if c[2] == 0 and (c[:2] >= 0).all(): return np.array([-INF,-INF])
        return None
    cands = []
    for k in range(R.shape[0]):
        if k == o: continue
        d = R[o]-R[k]
        opts = []
        for mask in itertools.product([0,1], repeat=4):  # 1 = treat as linear with pattern constraint
            c = np.zeros(3); cons = []
            ok = True
            for j in range(4):
                if mask[j]:
                    if P[j]:
                        c += d[j]*B[j]
                        if d[j] < 0: cons.append(B[j])   # need B_j z >= 0 to be valid
                    else:
                        # treat as zero with constraint -B_j z >= 0 (if d_j<0) ; if d_j>=0 zero is valid w/o constraint
                        if d[j] < 0: cons.append(-B[j])
                else:
                    if d[j] >= 0:
                        pass   # bound by 0 (valid)  -- or could use d_j B_j z, skip
                    else:
                        c += d[j]*np.maximum(B[j],0)
            Ts = [half_to_T(c)] + [half_to_T(cc) for cc in cons]
            if any(t is None for t in Ts): continue
            opts.append(np.max(np.stack(Ts),0))
        cands.append(opts)
    return cands
def sector_matrices(s0,s1):
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    th = sorted([(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0])
    edges = [0]+th+[np.inf]
    out=[]
    for i in range(len(edges)-1):
        r = (edges[i]+min(edges[i+1],edges[i]+1.0))/2 if np.isfinite(edges[i+1]) else edges[i]+1
        alive = (a*r + b) > 0
        A = np.stack([b*alive, a*alive],1)  # h1 = A @ (|x0|,|x1|)
        out.append((edges[i],edges[i+1],A))
    return out
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(2); X = rng.standard_normal((400000,3)); y = net(X)
Z = np.abs(X)
caught_ind = np.zeros(len(X),bool); caught_joint = np.zeros(len(X),bool)
for s2 in [1,-1]:
    o = (R@np.maximum(w*s2,0)).argmax()
    for s0 in [1,-1]:
        for s1 in [1,-1]:
            for lo,hi,A in sector_matrices(s0,s1):
                B = np.concatenate([rec@A, (w*s2)[:,None]],1)
                cands = T_options(B,s2,o,None)
                sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)&(Z[:,1]>=lo*Z[:,0])&(Z[:,1]<hi*Z[:,0])
                # independent choice: per k pick min sum, then max
                Tind = np.max(np.stack([min(opts,key=lambda t:t.sum()) for opts in cands]),0)
                # joint: enumerate
                best=None
                for combo in itertools.product(*cands):
                    T = np.max(np.stack(combo),0)
                    if best is None or T.sum()<best.sum(): best=T
                for T,arr in [(Tind,caught_ind),(best,caught_joint)]:
                    c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1])
                    arr |= c
                    assert (y[c]==o).all()
                print(s2,s0,s1,round(lo,3),round(hi,3),'frac',round(sel.mean(),4),'Tind',np.round(Tind,2),'Tjoint',np.round(best,2),'catch',round((sel&(Z[:,2] > best[0]*Z[:,0]+best[1]*Z[:,1])).sum()/sel.sum(),3))
print('catch ind',caught_ind.mean(),'joint',caught_joint.mean())
