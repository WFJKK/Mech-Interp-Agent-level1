
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
BIG=1e9
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def vreq(g, e, strict=True):
    ge = g[0]*e[0]+g[1]*e[1]
    if g[2]>0: return -ge/g[2]
    if g[2]==0 and (ge>0 if strict else ge>=0): return -BIG
    return BIG
def unit_options(d, Bq, P, j):
    if d[j]>=0:
        lin=(d[j]*Bq[j], None); drop=(np.zeros(3),None)
        return (lin,drop) if P[j] else (drop,lin)
    else:
        if P[j]: return ((d[j]*Bq[j], Bq[j]), (d[j]*np.maximum(Bq[j],0), None))
        else: return ((np.zeros(3), -Bq[j]), (d[j]*np.maximum(Bq[j],0), None))
def utype(d,P,j):
    return 0 if (d[j]>=0 and P[j]) else 1 if d[j]>=0 else 2 if P[j] else 3
def sector_vals(c, cons, edges):
    return np.array([max([vreq(c,e)]+[vreq(g,e,False) for g in cons]) for e in edges])
def build_T(w,rec,R,profiles,THBIG=1e30):
    S0 = np.array([1,1,-1,-1.]); S1=np.array([1,-1,1,-1.])
    up = rec@np.maximum(w,0); um = -rec@np.maximum(-w,0)
    a = w[None,:]*S1[:,None]; b = np.where(S0[:,None]>0, up[None,:], um[None,:])*S0[:,None]
    asafe = np.where(a==0,1.0,a)
    th = np.where(a*b<0, -b/asafe, THBIG); ths = np.sort(th,axis=1)
    lo = np.concatenate([np.zeros((4,1)), ths],1); hi = np.concatenate([ths, np.full((4,1),THBIG)],1)
    r = (lo+hi)/2
    alive = (a[:,None,:]*r[:,:,None] + b[:,None,:]) > 0
    A = alive[...,None]*np.stack([b,a],2)[:,None,:,:]
    B = np.einsum('jk,qikc->qijc', rec, A)
    thm = np.concatenate([np.zeros((4,1)), ths, np.full((4,1),THBIG)],1)
    E = np.where(thm[...,None]>=THBIG, np.array([0.,1.]), np.stack([np.ones_like(thm), thm],-1))
    def score(vals, edges):
        ws = np.array([1.0/(e[0]+e[1]) for e in edges]); return (vals*ws).sum()
    T_all = np.zeros((2,4,2))
    for si,s2 in enumerate([1,-1]):
        o = (R@np.maximum(w*s2,0)).argmax(); ks=[k for k in range(3) if k!=o]
        Bz = np.concatenate([B, np.broadcast_to((w*s2)[None,None,:,None],(4,5,4,1))],3)
        P = (w*s2)>0
        Vreq = np.full((4,6), -BIG)
        for q in range(4):
            for i in range(5):
                for k in ks:
                    d = R[o]-R[k]; Bq=Bz[q,i]; edges=[E[q,i],E[q,i+1]]
                    opts=[unit_options(d,Bq,P,j) for j in range(4)]
                    best=None
                    for rule in profiles:
                        c=np.zeros(3); cons=[]
                        for j in range(4):
                            m = rule[utype(d,P,j)]
                            c=c+opts[j][m][0]
                            if opts[j][m][1] is not None: cons.append(opts[j][m][1])
                        vals=sector_vals(c,cons,edges)
                        if best is None or score(vals,edges)<score(best,edges): best=vals
                    vals=best
                    for t,m in enumerate((i,i+1)): Vreq[q,m]=max(Vreq[q,m],vals[t])
        for q in range(4):
            best=None; cands=[np.array([BIG,BIG])]
            for m in range(6):
                for m2 in range(m+1,6):
                    e,e2=E[q,m],E[q,m2]; det=e[0]*e2[1]-e[1]*e2[0]
                    if abs(det)<1e-12: continue
                    cands.append(np.array([(Vreq[q,m]*e2[1]-Vreq[q,m2]*e[1])/det, (e[0]*Vreq[q,m2]-e2[0]*Vreq[q,m])/det]))
            for T in cands:
                if ((E[q]@T) >= Vreq[q]-1e-9*(1+abs(Vreq[q]))).all():
                    if best is None or T.sum()<best.sum(): best=T
            T_all[si,q]=best+1e-7*(1+np.abs(best))
    return T_all
def fbfrac(X,w,rec,R,profiles):
    T_all = build_T(w,rec,R,profiles); Z=np.abs(X); fb=np.zeros(len(X),bool)
    for si,s2 in enumerate([1,-1]):
        for q,(s0,s1) in enumerate([(1,1),(1,-1),(-1,1),(-1,-1)]):
            sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)
            T=T_all[si,q]; fb |= sel & ~(Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1])
    return fb.mean()
P4 = [(0,0,0,0),(0,0,0,1),(0,0,1,0),(0,0,1,1)]
P8 = [r for r in itertools.product([0],[0,1],[0,1],[0,1])]
sets = {'cell':[(0,0,0,0)], 'f0001':[(0,0,0,1)], 'P2':[(0,0,0,1),(0,0,1,0)], 'P4':P4, 'P8':P8}
rng = np.random.default_rng(5); X = rng.standard_normal((60000,3))
print('this', {k:round(fbfrac(X,w,rec,R,v),3) for k,v in sets.items()})
for seed in range(8):
    rg=np.random.default_rng(100+seed); sc=[0.3,0.5,1.0][seed%3]
    w2=rg.standard_normal(4)*sc; rec2=rg.standard_normal((4,4))*sc; R2=rg.standard_normal((3,4))*sc
    X2=rg.standard_normal((30000,3))
    print(seed,{k:round(fbfrac(X2,w2,rec2,R2,v),3) for k,v in sets.items()})
