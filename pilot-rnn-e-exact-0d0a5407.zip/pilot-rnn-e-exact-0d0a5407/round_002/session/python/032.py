
import numpy as np, collections
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
ev = lv1.Evaluator(entries['sec_p2'], weights, 3)
rng = np.random.default_rng(9); X = rng.standard_normal((4000,3)); y = net(X)
pred = []; cost=[]
for x in X:
    r = ev.run(list(x)); pred.append(r[1]); cost.append(r[3])
pred=np.array(pred); cost=np.array(cost)
err = pred!=y
print('err rate', err.mean(), 'cost mean', cost.mean())
S = np.sign(X).astype(int)
cnt = collections.Counter(); tot = collections.Counter()
for s,c,e in zip(map(tuple,S),cost,err):
    key=(s, 'test' if c<=12 else 'fb'); tot[key]+=1; cnt[key]+=int(e)
for k in sorted(tot): print(k, tot[k], cnt[k])
# print a few error examples
idx = np.nonzero(err)[0][:8]
for i in idx: print(X[i], y[i], pred[i], cost[i])
print('fallback cost distribution', collections.Counter(cost[cost>12]).most_common(6))
