
def pats2(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    h = np.maximum(np.outer(X[:,1], w) + h@rec.T,0)
    p = np.outer(X[:,2], w) + h@rec.T
    return (p>0).astype(int)@np.array([1,2,4,8])
P2 = pats2(X)
tot_missed = 0
for s2 in [-1]:
    o = (R@np.maximum(w*s2,0)).argmax()
    for s0 in [1,-1]:
        for s1 in [1,-1]:
            for lo,hi,A in sector_matrices(s0,s1):
                sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)&(Z[:,1]>=lo*Z[:,0])&(Z[:,1]<hi*Z[:,0])
                miss = sel & ~caught_joint
                tot_missed += miss.mean()
                u,c = np.unique(P2[miss]*4+y[miss], return_counts=True)
                print(s0,s1,round(lo,2),round(hi,2),'missed frac',round(miss.mean(),4), [(bin(k//4)[2:].zfill(4)[::-1], k%4, round(cnt/miss.sum(),2)) for k,cnt in sorted(zip(u,c),key=lambda t:-t[1])[:5]])
print(tot_missed)
