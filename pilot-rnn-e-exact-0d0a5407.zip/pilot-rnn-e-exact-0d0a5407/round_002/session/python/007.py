
import inspect
print(inspect.signature(lv1.show)); print(inspect.signature(lv1.Evaluator)); print(inspect.signature(lv1.measure))
e = entries['best']
print(e.keys())
print(len(e['nodes']) if 'nodes' in e else None)
s = lv1.show(e) if True else None
print(str(s)[:6000])
