
import numpy as np, collections
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
seed=4
rg=np.random.default_rng(200+seed); sc=1.0
w2=rg.standard_normal((4,1))*sc; rec2=rg.standard_normal((4,4))*sc; R2=rg.standard_normal((3,4))*sc
W2={'input':w2,'recurrent':rec2,'readout':R2}
entry = entries['sec_p2']
ev = lv1.Evaluator(entry, W2, 3)
X2=rg.standard_normal((1500,3)); y2=net(X2,w2[:,0],rec2,R2)
pred=[]; cost=[]
for x in X2:
    r=ev.run(list(x)); pred.append(r[1]); cost.append(r[3])
pred=np.array(pred); cost=np.array(cost); err=pred!=y2
print('w',w2[:,0]); print('rec',rec2); print('R',R2)
for i in np.nonzero(err)[0][:10]: print(X2[i], y2[i], pred[i], cost[i])
# find build values: locate nodes for Tq etc. Instead recompute with numpy prototype pieces for the failing quadrant
w=w2[:,0]; rec=rec2; R=R2
S0 = np.array([1,1,-1,-1.]); S1=np.array([1,-1,1,-1.])
up = rec@np.maximum(w,0); um0 = rec@np.maximum(-w,0)
a = w[None,:]*S1[:,None]; b = np.stack([up,up,um0,um0])
th = np.where(a*b<0, -b/np.where(a==0,1,a), 1e30); ths=np.sort(th,1)
print('ths', ths)
# check failing inputs: which quadrant, sector, and what's the issue
for i in np.nonzero(err)[0][:5]:
    x=X2[i]; s0=1 if x[0]>0 else -1; s1=1 if x[1]>0 else -1; q=[(1,1),(1,-1),(-1,1),(-1,-1)].index((s0,s1))
    r=abs(x[1])/abs(x[0]); idx=(r>ths[q]).sum()
    h0=np.maximum(w*x[0],0); h1=np.maximum(w*x[1]+rec@h0,0); p=w*x[2]+rec@h1
    print('q',q,'r',r,'sector',idx,'h1',h1,'p',p, 'limit o', (R@np.maximum(w*np.sign(x[2]),0)).argmax())
