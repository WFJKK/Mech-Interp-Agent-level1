
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def sector_matrices(s0,s1):
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    th = sorted([(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0])
    edges = [0]+th+[np.inf]
    out=[]
    for i in range(len(edges)-1):
        r = (edges[i]+min(edges[i+1],edges[i]+1.0))/2 if np.isfinite(edges[i+1]) else edges[i]+1
        alive = (a*r + b) > 0
        A = np.stack([b*alive, a*alive],1)
        out.append((edges[i],edges[i+1],A))
    return out
rng = np.random.default_rng(2); X = rng.standard_normal((400000,3)); y = net(X); Z=np.abs(X)
s2=-1; o=0
tot=0
for s0 in [1,-1]:
    for s1 in [1,-1]:
        for lo,hi,A in sector_matrices(s0,s1):
            sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)&(Z[:,1]>=lo*Z[:,0])&(Z[:,1]<hi*Z[:,0])
            t = Z[sel,2]/(Z[sel,0]+Z[sel,1]); yy = y[sel]
            order = np.argsort(t); t=t[order]; yy=yy[order]
            bad = np.nonzero(yy!=o)[0]
            lam_low = t[bad[0]] if len(bad) else np.inf
            lam_high = t[bad[-1]] if len(bad) else 0
            # fraction with t<lam_low and t>lam_high
            print(s0,s1,round(lo,2),round(hi,2),'frac',round(sel.mean(),4),'lam_low',round(lam_low,3),'catch_low',round((t<lam_low).mean(),3),'lam_high',round(lam_high,3),'catch_high',round((t>lam_high).mean(),3), 'nonzero frac', round((yy!=o).mean(),3))
            tot += sel.mean()*((t<lam_low).mean()+(t>lam_high).mean())
print('oracle catch x2<0 (of all):',tot)
