
import collections, json
src = entries['builder_src']['src']; exec(src)
entry, g = build_entry()
ops = collections.Counter(n.get('op') for n in entry['nodes'])
print(ops.most_common())
# how many nodes before runtime section? find index of first token use
print(entry['nodes'][0])
