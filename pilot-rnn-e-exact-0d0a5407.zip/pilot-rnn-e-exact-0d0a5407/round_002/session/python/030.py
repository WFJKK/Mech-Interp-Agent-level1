
import inspect, numpy as np
print([a for a in dir(lv1.Evaluator) if not a.startswith('_')])
print(inspect.signature(lv1.Evaluator.__init__))
src = inspect.getsource(lv1.Evaluator)
print(src[:3000])
