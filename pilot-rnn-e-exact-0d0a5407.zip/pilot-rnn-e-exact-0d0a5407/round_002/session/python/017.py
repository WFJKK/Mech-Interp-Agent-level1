
import inspect
g = graph()
w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
S0 = g.const([1.,1.,-1.,-1.]); S1 = g.const([1.,-1.,1.,-1.])
up = rec @ lv1.maximum(w,0.0); um = -(rec @ lv1.maximum(-w,0.0))
try:
    a = w[None,:]*S1[:,None]; print('a',a.shape)
except Exception as e: print('None idx fail',e)
try:
    a = w.reshape(1,4)*S1.reshape(4,1); print('a',a.shape)
    b = lv1.where(S0.reshape(4,1)>0.0, up.reshape(1,4), um.reshape(1,4))*S0.reshape(4,1); print('b',b.shape)
    th = lv1.where(a*b<0.0, -b/lv1.where(a==0.0,1.0,a), 1e30); print('th',th.shape, th.value)
    ths = lv1.sort(th, axis=1); print('ths', ths.value)
    lo = lv1.concat(g.const(np.zeros((4,1))), ths, axis=1); print(lo.shape)
    A = g.const(np.ones((4,5,4,2)))
    try:
        B = lv1.matmul(rec, A); print('batched matmul', B.shape)
    except Exception as e: print('batched matmul fail', e)
    try:
        B2 = rec.reshape(1,1,4,4) @ A; print('bcast matmul', B2.shape)
    except Exception as e: print('bcast matmul fail', e)
    print(inspect.signature(lv1.take), inspect.signature(lv1.matmul), inspect.signature(lv1.sort))
    print(lv1.ARITY if hasattr(lv1,'ARITY') else None)
    print(lv1.REDUCE, lv1.ALONG)
    print(lv1.KINDS)
except Exception as e:
    import traceback; traceback.print_exc()
