
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def net(X, w=w, rec=rec, R=R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(1)
X = rng.standard_normal((400000,3)); y = net(X)
op = (R@np.maximum(w,0)).argmax(); om = (R@np.maximum(-w,0)).argmax()
print('limit outputs', op, om)
s2 = X[:,2]>0
print('frac out==limit: x2>0', (y[s2]==op).mean(), 'x2<0', (y[~s2]==om).mean())
# sectors: per quadrant, thresholds on r=|x1|/|x0|
u_plus = rec@np.maximum(w,0); u_minus = -rec@np.maximum(-w,0)
for s0 in [1,-1]:
    for s1 in [1,-1]:
        a = w*s1; b = (u_plus if s0>0 else u_minus)*s0   # h1_j = relu(a_j|x1| + b_j|x0|)
        th = [(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0]
        print(s0,s1,'a',np.round(a,3),'b',np.round(b,3),'thresholds r=|x1|/|x0|:',np.round(th,3))
