
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
INF=1e9
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def sector_matrices(s0,s1):
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    th = sorted([(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0])
    edges = [0]+th+[np.inf]
    out=[]
    for i in range(len(edges)-1):
        r = (edges[i]+min(edges[i+1],edges[i]+1.0))/2 if np.isfinite(edges[i+1]) else edges[i]+1
        alive = (a*r + b) > 0
        A = np.stack([b*alive, a*alive],1)
        out.append((edges[i],edges[i+1],A))
    return out
def T_options(B, o):
    P = B[:,2] > 0
    def half_to_T(c):
        if c[2] > 0: return -c[:2]/c[2]
        if c[2] == 0 and (c[:2] >= 0).all(): return np.array([-INF,-INF])
        return None
    cands = []
    for k in range(R.shape[0]):
        if k == o: continue
        d = R[o]-R[k]; opts=[]
        for mask in itertools.product([0,1], repeat=4):
            c = np.zeros(3); cons = []
            for j in range(4):
                if mask[j]:
                    if P[j]:
                        c += d[j]*B[j]
                        if d[j] < 0: cons.append(B[j])
                    else:
                        if d[j] < 0: cons.append(-B[j])
                else:
                    if d[j] < 0: c += d[j]*np.maximum(B[j],0)
            Ts = [half_to_T(c)] + [half_to_T(cc) for cc in cons]
            if any(t is None for t in Ts): continue
            opts.append(np.max(np.stack(Ts),0))
        cands.append(opts)
    best=None
    for combo in itertools.product(*cands):
        T = np.max(np.stack(combo),0)
        if best is None or T.sum()<best.sum(): best=T
    return best
rng = np.random.default_rng(3); X = rng.standard_normal((400000,3)); y = net(X); Z=np.abs(X)
Tq = {}
for s2 in [1,-1]:
    o = (R@np.maximum(w*s2,0)).argmax()
    for s0 in [1,-1]:
        for s1 in [1,-1]:
            Ts = [T_options(np.concatenate([rec@A, (w*s2)[:,None]],1), o) for lo,hi,A in sector_matrices(s0,s1)]
            Tq[(s2,s0,s1)] = np.max(np.stack(Ts),0)
            print(s2,s0,s1,np.round(Tq[(s2,s0,s1)],3))
caught = np.zeros(len(X),bool)
for (s2,s0,s1),T in Tq.items():
    sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)
    c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1]); assert (y[c]==0).all(); caught|=c
    print(s2,s0,s1,'catch',round(c.sum()/sel.sum(),3))
print('quadrant-level catch', caught.mean())
for s2 in [1,-1]:
    T = np.max(np.stack([Tq[(s2,a,b)] for a in [1,-1] for b in [1,-1]]),0)
    sel = np.sign(X[:,2])==s2
    c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1]); assert (y[c]==0).all()
    print('global T for s2',s2,np.round(T,3),'catch',c.sum()/sel.sum())
