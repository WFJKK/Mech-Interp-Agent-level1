
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
BIG=1e9
def net(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def vreq(g, e, strict=True):
    ge = g[0]*e[0]+g[1]*e[1]
    if g[2]>0: return -ge/g[2]
    if g[2]==0 and (ge>0 if strict else ge>=0): return -BIG
    return BIG
def build_T(w,rec,R,mode='heur',THBIG=1e30):
    S0 = np.array([1,1,-1,-1.]); S1=np.array([1,-1,1,-1.])
    up = rec@np.maximum(w,0); um = -rec@np.maximum(-w,0)
    a = w[None,:]*S1[:,None]; b = np.where(S0[:,None]>0, up[None,:], um[None,:])*S0[:,None]
    asafe = np.where(a==0,1.0,a)
    th = np.where(a*b<0, -b/asafe, THBIG)
    ths = np.sort(th,axis=1)
    lo = np.concatenate([np.zeros((4,1)), ths],1); hi = np.concatenate([ths, np.full((4,1),THBIG)],1)
    r = (lo+hi)/2
    alive = (a[:,None,:]*r[:,:,None] + b[:,None,:]) > 0
    A = alive[...,None]*np.stack([b,a],2)[:,None,:,:]
    B = np.einsum('jk,qikc->qijc', rec, A)
    Bp = np.concatenate([B*np.stack([S0,S1],1)[:,None,None,:], np.broadcast_to(w[None,None,:,None],(4,5,4,1))],3)
    thm = np.concatenate([np.zeros((4,1)), ths, np.full((4,1),THBIG)],1)
    E = np.where(thm[...,None]>=THBIG, np.array([0.,1.]), np.stack([np.ones_like(thm), thm],-1))
    T_all = np.zeros((2,4,2))
    for si,s2 in enumerate([1,-1]):
        o = (R@np.maximum(w*s2,0)).argmax(); ks=[k for k in range(3) if k!=o]
        Bz = np.concatenate([B, np.broadcast_to((w*s2)[None,None,:,None],(4,5,4,1))],3)
        P = (w*s2)>0
        Vreq = np.full((4,6), -BIG)
        for q in range(4):
            for i in range(5):
                for k in ks:
                    d = R[o]-R[k]; Bq=Bz[q,i]
                    c0 = (d[:,None]*Bq*P[:,None]).sum(0)
                    consj = {j:(Bq[j] if P[j] else -Bq[j]) for j in range(4) if d[j]<0}
                    reluadd = {j: d[j]*(np.maximum(Bq[j],0) - (Bq[j] if P[j] else 0)) for j in consj}
                    edges=[E[q,i],E[q,i+1]]
                    if mode=='brute':
                        best=None
                        for m in itertools.product([0,1],repeat=len(consj)):
                            c=c0.copy(); cons=[]
                            for (j,g),mm in zip(consj.items(),m):
                                if mm: cons.append(g)
                                else: c+=reluadd[j]
                            vals=np.array([max([vreq(c,e)]+[vreq(g,e,False) for g in cons]) for e in edges])
                            if best is None or vals.sum()<best.sum(): best=vals
                        vals=best
                    else:
                        vb = np.array([vreq(c0,e) for e in edges])
                        c=c0.copy(); cons=[]
                        for j,g in consj.items():
                            vc = np.array([max(vb[t],vreq(g,e,False)) for t,e in enumerate(edges)])
                            vr = np.array([vreq(c0+reluadd[j],e) for e in edges])
                            if vc.sum()<=vr.sum(): cons.append(g)
                            else: c+=reluadd[j]
                        vals=np.array([max([vreq(c,e)]+[vreq(g,e,False) for g in cons]) for e in edges])
                    for t,m in enumerate((i,i+1)): Vreq[q,m]=max(Vreq[q,m],vals[t])
        for q in range(4):
            best=None; cands=[np.array([BIG,BIG])]
            for m in range(6):
                for m2 in range(m+1,6):
                    e,e2=E[q,m],E[q,m2]; det=e[0]*e2[1]-e[1]*e2[0]
                    if abs(det)<1e-12: continue
                    cands.append(np.array([(Vreq[q,m]*e2[1]-Vreq[q,m2]*e[1])/det, (e[0]*Vreq[q,m2]-e2[0]*Vreq[q,m])/det]))
            for T in cands:
                if ((E[q]@T) >= Vreq[q]-1e-9*(1+abs(Vreq[q]))).all():
                    if best is None or T.sum()<best.sum(): best=T
            T_all[si,q]=best+1e-7*(1+np.abs(best))
    return T_all, ths, Bp
def predict_np(X,w,rec,R,mode):
    T_all,ths,Bp = build_T(w,rec,R,mode)
    out = np.zeros(len(X),int); fb=np.zeros(len(X),bool); Z=np.abs(X)
    for si,s2 in enumerate([1,-1]):
        o = (R@np.maximum(w*s2,0)).argmax()
        for q,(s0,s1) in enumerate([(1,1),(1,-1),(-1,1),(-1,-1)]):
            sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)
            T=T_all[si,q]; c = sel & (Z[:,2] > T[0]*Z[:,0]+T[1]*Z[:,1]); out[c]=o
            rest = sel&~c; fb|=rest
            r = Z[rest,1]/np.maximum(Z[rest,0],1e-300); idx = (r[:,None] > ths[q][None,:]).sum(1)
            p = np.einsum('nkc,nc->nk', Bp[q][idx], X[rest]); out[rest] = (np.maximum(p,0)@R.T).argmax(1)
    return out, fb
rng = np.random.default_rng(5); X = rng.standard_normal((200000,3)); y = net(X,w,rec,R)
for mode in ['heur','brute']:
    yp,fb = predict_np(X,w,rec,R,mode); print(mode,'errors',(y!=yp).sum(),'fallback frac',fb.mean())
for seed in range(8):
    rg=np.random.default_rng(100+seed); sc=[0.3,0.5,1.0][seed%3]
    w2=rg.standard_normal(4)*sc; rec2=rg.standard_normal((4,4))*sc; R2=rg.standard_normal((3,4))*sc
    X2=rg.standard_normal((50000,3)); y2=net(X2,w2,rec2,R2)
    res=[]
    for mode in ['heur','brute']:
        yp2,fb2=predict_np(X2,w2,rec2,R2,mode); res.append(((y2!=yp2).sum(), round(fb2.mean(),3)))
    print(seed,res)
