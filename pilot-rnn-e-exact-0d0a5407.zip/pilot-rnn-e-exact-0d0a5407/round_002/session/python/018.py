
import inspect
print(inspect.signature(lv1.concat), inspect.signature(lv1.stack), inspect.signature(lv1.take), inspect.signature(lv1.matmul), inspect.signature(lv1.sort), inspect.signature(lv1.where), inspect.signature(lv1.cond))
g = graph()
w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
A = g.const(np.ones((4,5,4,2)))
for name,f in [('matmul',lambda: lv1.matmul(rec, A)),('bcast',lambda: rec.reshape(1,1,4,4) @ A), ('mm2', lambda: lv1.matmul(A.reshape(20,4,2).T if False else A, rec))]:
    try: print(name, f().shape)
    except Exception as e: print(name,'fail',e)
# alternative: B[q,i,j,c] = sum_k rec[j,k] A[q,i,k,c] = (A reshaped (20,4,2) -> transpose to (4, 20*2)? ) use einsum-free: rec @ A.reshape(20,4,2) -> try
try:
    B = rec @ A.reshape(20,4,2); print('rec@ (20,4,2)', B.shape)
except Exception as e: print('fail2', e)
try:
    At = lv1.transpose(A.reshape(20,4,2), (1,0,2)).reshape(4,40); B = (rec @ At).reshape(4,20,2); print('via transpose', B.shape)
    Bq = lv1.transpose(B,(1,0,2)).reshape(4,5,4,2); print(Bq.shape)
except Exception as e: print('fail3', e)
x = g.const(np.arange(6.).reshape(2,3))
print(x.sum(axis=1).shape, x.max(axis=0).shape, (x>1.0).all(axis=1).shape, x.argmin(axis=1).shape)
print(lv1.take(x, g.const([1,0]), axis=0).shape)
print(abs(x).shape)
# cond with vector values
c = g.token(0) > 0.0
v = lv1.cond(c, x[0], x[1]); print('cond vec', v.shape)
print(lv1.PRICES if hasattr(lv1,'PRICES') else None)
