
import numpy as np, json
print({k:v.shape for k,v in weights.items()})
for k,v in weights.items(): print(k); print(np.round(v,4))
print({k:(v if not hasattr(v,'shape') else v.shape) for k,v in info.items() if k!='data'})
print(list(entries.keys()))
m = measure(entries['best']); print(m)
e = entries['best']; print(type(e), (len(json.dumps(e)) if not isinstance(e,str) else len(e)))
