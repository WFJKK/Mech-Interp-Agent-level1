
import numpy as np, itertools, json
def build_entry(profiles=((0,1),(1,0)), THBIG=1e30, BIG=1e9, bump=1e-6, tol=1e-9):
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    X = g.tokens(); x01 = lv1.stack([x0,x1])
    S0 = g.const([1.,1.,-1.,-1.]); S1 = g.const([1.,-1.,1.,-1.])
    up = rec @ lv1.maximum(w, 0.0); um = -(rec @ lv1.maximum(-w, 0.0))
    a = w.reshape(1,4) * S1.reshape(4,1)
    b = lv1.where(S0.reshape(4,1) > 0.0, up.reshape(1,4), um.reshape(1,4)) * S0.reshape(4,1)
    th = lv1.where(a*b < 0.0, -b / lv1.where(a == 0.0, 1.0, a), THBIG)
    ths = lv1.sort(th, axis=1)
    z41 = g.const(np.zeros((4,1))); big41 = g.const(np.full((4,1), THBIG))
    lo = lv1.concat([z41, ths], axis=1); hi = lv1.concat([ths, big41], axis=1)
    r = (lo + hi) * 0.5
    alive = (a.reshape(4,1,4) * r.reshape(4,5,1) + b.reshape(4,1,4)) > 0.0
    ba = lv1.stack([b, a], axis=2)
    A = lv1.cast(alive, "float").reshape(4,5,4,1) * ba.reshape(4,1,4,2)
    B = rec @ A                                   # (4,5,4,2)
    z4511 = g.const(np.zeros((4,5,1,1)))
    SS = lv1.stack([S0,S1], axis=1)               # (4,2)
    Bp = lv1.concat([B * SS.reshape(4,1,1,2), w.reshape(1,1,4,1) + z4511], axis=3)   # (4,5,4,3)
    thm = lv1.concat([z41, ths, big41], axis=1)   # (4,6)
    isinf = thm >= THBIG
    E0 = lv1.where(isinf, 0.0, 1.0); E1 = lv1.where(isinf, 1.0, thm)
    E0s = lv1.stack([E0[:,0:5], E0[:,1:6]], axis=2); E1s = lv1.stack([E1[:,0:5], E1[:,1:6]], axis=2)  # (4,5,2)
    W = 1.0 / (E0s + E1s)
    E0s5 = E0s.reshape(4,5,1,1,2); E1s5 = E1s.reshape(4,5,1,1,2)
    E0s4 = E0s.reshape(4,5,1,2); E1s4 = E1s.reshape(4,5,1,2)
    def vfun(G, strict, e0, e1):
        # G (...,3) -> (...,2)
        g0 = G[...,0:1] if False else None
        G0 = lv1.take(G, g.const([0]), axis=G.ndim-1) if False else None
        return None
    def vfun(Gc, strict, e0, e1):
        # Gc: tuple of (G0, G1, G2) each shape (...,1) broadcastable with e0 (..,2)
        G0,G1,G2 = Gc
        ge = G0*e0 + G1*e1
        pos = G2 > 0.0
        v = -(ge / lv1.where(pos, G2, 1.0))
        fz = (G2 == 0.0) & ((ge > 0.0) if strict else (ge >= 0.0))
        return lv1.where(pos, v, lv1.where(fz, -BIG, BIG))
    def split(G):  # G (...,3) -> components with trailing 1 dim
        n = len(G.shape)
        return tuple(lv1.take(G, g.const([c]), axis=n-1) for c in range(3))
    pairsA = [m for m in range(6) for m2 in range(m+1,6)]; pairsB = [m2 for m in range(6) for m2 in range(m+1,6)]
    idxA = g.const(pairsA); idxB = g.const(pairsB)
    zB41 = g.const(np.full((4,1), -BIG)); bigB41 = g.const(np.full((4,1), BIG))
    Tq_all = {}; o_all = {}
    for s2 in (1,-1):
        ws = w if s2 > 0 else -w
        o = (R @ lv1.maximum(ws, 0.0)).argmax()
        o_all[s2] = o
        P = lv1.cast(ws > 0.0, "float")
        Bz = lv1.concat([B, ws.reshape(1,1,4,1) + z4511], axis=3)       # (4,5,4,3)
        k1 = (o + 1) % 3; k2 = (o + 2) % 3
        Ro = R[o]; D = lv1.stack([Ro - R[k1], Ro - R[k2]], axis=0)        # (2,4)
        Bz5 = Bz.reshape(4,5,1,4,3); D5 = D.reshape(1,1,2,4,1); P5 = P.reshape(1,1,1,4,1)
        lin = D5 * Bz5
        relu_t = D5 * lv1.maximum(Bz5, 0.0)
        dpos = D5 >= 0.0; Pb = P5 > 0.0
        base = lin * P5
        # constraint v's for g=Bz (non-strict) and g=-Bz
        Bzc = split(Bz)                                                     # each (4,5,4,1)
        vg_plus = vfun(Bzc, False, E0s4, E1s4)                              # (4,5,4,2)
        vg_minus = vfun(tuple(-c for c in Bzc), False, E0s4, E1s4)
        Dneg = (D < 0.0)                                                    # (2,4)
        actA = (Dneg & (P.reshape(1,4) > 0.0)).reshape(1,1,2,4,1)
        actB = (Dneg & (P.reshape(1,4) <= 0.0)).reshape(1,1,2,4,1)
        vals_list = []
        for (m2,m3) in profiles:
            if (m2,m3) == (0,1):
                contrib = lv1.where(dpos, base, lv1.where(Pb, lin, relu_t))
                vc = lv1.where(actA, vg_plus.reshape(4,5,1,4,2), -BIG).max(axis=3)   # (4,5,2,2)
            elif (m2,m3) == (1,0):
                contrib = lv1.where(dpos, base, lv1.where(Pb, relu_t, 0.0))
                vc = lv1.where(actB, vg_minus.reshape(4,5,1,4,2), -BIG).max(axis=3)
            elif (m2,m3) == (0,0):
                contrib = lv1.where(dpos, base, lv1.where(Pb, lin, 0.0))
                vc = lv1.maximum(lv1.where(actA, vg_plus.reshape(4,5,1,4,2), -BIG), lv1.where(actB, vg_minus.reshape(4,5,1,4,2), -BIG)).max(axis=3)
            else:
                contrib = lv1.where(dpos, base, relu_t)
                vc = None
            c = contrib.sum(axis=3)                                          # (4,5,2,3)
            vm = vfun(split(c), True, E0s5[:,:,:,0,:], E1s5[:,:,:,0,:])      # (4,5,2,2)
            vals = vm if vc is None else lv1.maximum(vm, vc)
            vals_list.append(vals)
        best = vals_list[0]; bestsc = (best * W.reshape(4,5,1,2)).sum(axis=3)
        for vals in vals_list[1:]:
            sc = (vals * W.reshape(4,5,1,2)).sum(axis=3)
            better = sc < bestsc
            best = lv1.where(better.reshape(4,5,2,1), vals, best); bestsc = lv1.where(better, sc, bestsc)
        vals = best.max(axis=2)                                               # (4,5,2)
        Vreq = lv1.maximum(lv1.concat([vals[:,:,0], zB41], axis=1), lv1.concat([zB41, vals[:,:,1]], axis=1))   # (4,6)
        EA0 = lv1.take(E0, idxA, axis=1); EA1 = lv1.take(E1, idxA, axis=1); EB0 = lv1.take(E0, idxB, axis=1); EB1 = lv1.take(E1, idxB, axis=1)
        VA = lv1.take(Vreq, idxA, axis=1); VB = lv1.take(Vreq, idxB, axis=1)
        det = EA0*EB1 - EA1*EB0
        sing = abs(det) < 1e-12
        dsafe = lv1.where(sing, 1.0, det)
        T0 = lv1.where(sing, BIG, (VA*EB1 - VB*EA1)/dsafe); T1 = lv1.where(sing, BIG, (EA0*VB - EB0*VA)/dsafe)
        T0c = lv1.concat([T0, bigB41], axis=1); T1c = lv1.concat([T1, bigB41], axis=1)       # (4,16)
        lhs = E0.reshape(4,6,1)*T0c.reshape(4,1,16) + E1.reshape(4,6,1)*T1c.reshape(4,1,16)
        rhs = (Vreq - tol*(1.0 + abs(Vreq))).reshape(4,6,1)
        feas = (lhs >= rhs).all(axis=1)                                      # (4,16)
        score = lv1.where(feas, T0c + T1c, 2.0*BIG)
        idx = score.argmin(axis=1)                                            # (4,)
        Tq = []
        for q in range(4):
            t0 = T0c[q][idx[q]]; t1 = T1c[q][idx[q]]
            t0 = t0 + bump*(1.0 + abs(t0)); t1 = t1 + bump*(1.0 + abs(t1))
            s0, s1 = [(1,1),(1,-1),(-1,1),(-1,-1)][q]
            Tq.append(lv1.stack([t0 * float(s0*s2), t1 * float(s1*s2)]))
        Tq_all[s2] = Tq
    # runtime
    fallback = []
    for q in range(4):
        s0, s1 = [(1,1),(1,-1),(-1,1),(-1,-1)][q]
        def sec_test(m):
            c = ths[q, m] * float(s0*s1)
            return (x1 > c*x0) if s1 > 0 else (x1 < c*x0)
        def leaf(i): return Bp[q, i] @ X
        p = lv1.cond(sec_test(1), lv1.cond(sec_test(2), lv1.cond(sec_test(3), leaf(4), leaf(3)), leaf(2)), lv1.cond(sec_test(0), leaf(1), leaf(0)))
        fallback.append((R @ lv1.maximum(p, 0.0)).argmax())
    def leaf2(s2, q):
        lin = Tq_all[s2][q] @ x01
        test = (x2 > lin) if s2 > 0 else (x2 < lin)
        return lv1.cond(test, o_all[s2], fallback[q])
    def side(s2):
        return lv1.cond(x0 > 0.0, lv1.cond(x1 > 0.0, leaf2(s2,0), leaf2(s2,1)), lv1.cond(x1 > 0.0, leaf2(s2,2), leaf2(s2,3)))
    out = lv1.cond(x2 > 0.0, side(1), side(-1))
    return g.entry(interpretation=out), g
try:
    entry, g = build_entry()
    print('nodes', len(entry['nodes']))
    m = measure(entry); print(m)
    save_entry('sec_p2', entry)
except Exception as e:
    import traceback; traceback.print_exc()
