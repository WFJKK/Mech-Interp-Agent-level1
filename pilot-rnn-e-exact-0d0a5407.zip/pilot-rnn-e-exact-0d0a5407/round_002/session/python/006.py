
import numpy as np, itertools
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
INF=1e9
def net(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h@rec.T,0)
    return (h@R.T).argmax(1)
def pats2(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    h = np.maximum(np.outer(X[:,1], w) + h@rec.T,0)
    p = np.outer(X[:,2], w) + h@rec.T
    return (p>0).astype(int)@np.array([1,2,4,8])
def sector_matrices(s0,s1):
    u = rec@np.maximum(w,0) if s0>0 else -rec@np.maximum(-w,0)
    a = w*s1; b = u*s0
    th = sorted([(-b[j]/a[j]) for j in range(4) if a[j]*b[j]<0])
    edges = [0]+th+[np.inf]
    out=[]
    for i in range(len(edges)-1):
        r = (edges[i]+min(edges[i+1],edges[i]+1.0))/2 if np.isfinite(edges[i+1]) else edges[i]+1
        alive = (a*r + b) > 0
        A = np.stack([b*alive, a*alive],1)
        out.append((edges[i],edges[i+1],A))
    return out
rng = np.random.default_rng(2); X = rng.standard_normal((400000,3)); y = net(X); Z=np.abs(X); P2 = pats2(X)
for s2 in [-1]:
    o = (R@np.maximum(w*s2,0)).argmax()
    for s0 in [1,-1]:
        for s1 in [1,-1]:
            for lo,hi,A in sector_matrices(s0,s1):
                sel = (np.sign(X[:,0])==s0)&(np.sign(X[:,1])==s1)&(np.sign(X[:,2])==s2)&(Z[:,1]>=lo*Z[:,0])&(Z[:,1]<hi*Z[:,0])
                u,c = np.unique(P2[sel]*4+y[sel], return_counts=True)
                print(s0,s1,round(lo,2),round(hi,2),'frac',round(sel.mean(),4), [(bin(k//4)[2:].zfill(4)[::-1], k%4, round(cnt/sel.sum(),2)) for k,cnt in sorted(zip(u,c),key=lambda t:-t[1])[:6]])
