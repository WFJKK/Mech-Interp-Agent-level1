
import numpy as np
print([a for a in dir(lv1) if not a.startswith('_')])
g = graph()
print([a for a in dir(g) if not a.startswith('_')])
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w),0)
    pats=[]
    for t in range(1,3):
        p = np.outer(X[:,t], w) + h@rec.T
        pats.append(p>0)
        h = np.maximum(p,0)
    return (h@R.T).argmax(1), pats
rng = np.random.default_rng(0)
X = rng.standard_normal((200000,3))
y, pats = fwd(X)
print(np.bincount(y)/len(y))
# pattern stats
P1 = pats[0].astype(int)@np.array([1,2,4,8]); P2 = pats[1].astype(int)@np.array([1,2,4,8])
s0 = X[:,0]>0
key = s0.astype(int)*256 + P1*16 + P2
u,c = np.unique(key, return_counts=True)
print(len(u))
for k,cnt in sorted(zip(u,c), key=lambda t:-t[1])[:40]:
    sel = key==k
    print(k>>8, (k>>4)&15, k&15, cnt/len(y), np.bincount(y[sel],minlength=3)/sel.sum())
