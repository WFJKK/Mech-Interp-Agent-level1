# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 4 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx real numbers, x_0 to x_(n_ctx - 1). The network reads them one at a time, in that order.
In an entry, g.token(t) is x_t, as a float, and g.tokens() is all of them; the output is still a whole number.

The network is a recurrent network with one layer of d_hidden units, a ReLU and no biases. Its weights:

    input       d_hidden x 1
    recurrent   d_hidden x d_hidden
    readout     n_outputs x d_hidden

Its state h, a vector of d_hidden numbers, starts at zero. At each position t, in order, it becomes

    h = relu(input x_t + recurrent h)

where relu sets every negative number to zero. After the last position, readout h gives n_outputs numbers,
and the output is the position of the highest (the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)  # the first position: the state before it is zero, and so is recurrent h
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()
```

Sizes: n_ctx = 3, d_hidden = 4, outputs: 3. One forward pass of the network costs 78 operations under the prices
below.

## The data set

An input is three real numbers, x_0, x_1 and x_2, each drawn on its own from the standard normal distribution (mean 0, standard deviation 1). The data set is every input that can be drawn this way, each weighted by how likely it is to be drawn. There are infinitely many, so the verifier scores a sample.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

This run asks one more thing of an entry: that it be exact whatever the weights. When the rounds are
over, the entries are also run, unchanged, on several other networks of the same definition and sizes,
with other weights, and an entry counts only if it gives each network's output on every input of its
region that is checked there. So whatever depends on the weights has to be computed from the weights
inside the entry, and every shortcut has to hold for any weights: a rule that holds only for this
network makes the entry fail on the others.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.6195 | 1.0000 | 1.00000 | 0.3782 | 1.00000 | 1.00000 |
| r1s2 | scored | 0.6650 | 1.0000 | 1.00000 | 0.3326 | 1.00000 | 1.00000 |
| r1s3 | scored | 0.6897 | 1.0000 | 1.00000 | 0.3080 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Output is the argmax of `readout @ h2` with `h2 = relu(w·x2 + rec·relu(w·x1 + rec·relu(w·x0)))`. On this network the output is 0 on ~89% of inputs: for x2>0 it is 0 on 99.7% (the x2→+∞ limit output is argmax(R·relu(w)) = 0), for x2<0 it is 0 on 79%, else 1 (9.5%) or 2 (11.5%); outputs 1/2 need unit 2 or 3 to fire at step 2 with moderate negative x2 relative to h1. Structurally (and for any weights): h0 = x0·relu(±w) so `rec@h0` is a precomputable vector v± chosen by the sign of x0; in each sign quadrant of (x0,x1) some hidden units are provably dead or provably linear at step 1; and for |x2| large relative to a linear function of (x0,x1) the output is provably the limit output o± = argmax(R·relu(±w)). I'm certain of all of this (it's algebra, checked on random weights).
    
    ## How you found it
    Looked at weights, output distribution by signs of inputs, hidden-activation patterns, and the exact threshold in x2 beyond which the output is constant. Derived, from the weights only, one-sided linear lower bounds on the logit margins `(R_o − R_k)·h2 ≥ m·|x2| − c·h1` (treating chosen units as linear, bounding `relu(u_j) ≤ relu(rec_j)·h1`), then bounded `c·h1` per sign quadrant of (x0,x1) by linear functions of x0,x1 (exact where a unit's two terms have equal sign, zero where both are ≤0). Candidate unit subsets (16 masks) are scored at build time by the proxy "coefficient sum" (expected threshold), the best per (k, quadrant) is chosen, and thresholds are max-combined over k≠o. Evaluated catch rates in numpy, measured entries with `measure`, and verified exactness on 20 random weight sets with `lv1.Evaluator` versus a numpy reference.
    
    ## The best entry
    `cascade_v6_234`, region = all inputs (coverage 1). Interpretation: cond tree on sign(x2), sign(x0), sign(x1) (6 ops) → one linear test `x2 >(<) T[side,quad]·(x0,x1)` (3 ops) with build-time coefficient table; if it passes, output the constant o± (limit output); otherwise a fallback that computes the network exactly but cheaper: `h1 = relu([w,v±]@[x1,x0])` only over the units not provably dead in that quadrant (build-time cond among variants with 2/3/4 alive units), `p = [rec_alive | w]@[h1; x2]` as one matmul, `argmax(R@relu(p))`. The test catches ~72% of inputs at ~10 ops; fallback averages ~45 ops on the rest; build ≈ 11.9k ops (0.9%). Total ≈ 24 ops/input vs 78 → cost 0.308, reward ≈ 0.69. Earlier versions: cascade_v3 (0.619), cascade_v4 (0.665).
    
    ## Claims
    Claimed fidelity 1.0 on this network and expected 1.0 on the second: every shortcut is a weight-computed sufficient condition (strict inequalities, invalid margins disabled via 1e9 coefficients, tie-safe), and the fallback is the exact forward pass; verified 0 errors on 50k inputs across 20 random weight sets including zero/one-signed input weights and duplicate readout rows. Coverage on the other network is also 1; only its cost (catch rate) will differ.
    
    ## Next
    Gains left are small: (1) finer angular sectors (|x1| vs |x0| splits) raised catch only ~2% for ~3 ops; (2) a second-stage test at the h1 level was break-even; (3) dead-unit elimination at step 2 (per side × quadrant) or an n=1 variant would save <0.3 ops but exceed the 400-node limit; (4) build cost could be trimmed slightly (~0.5%). A different idea worth a try: a weight-computed cone decision tree over input directions with verified-constant leaves, if a generic way to verify leaves at build time can be found.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.7038 | 1.0000 | 1.00000 | 0.2939 | 1.00000 | 1.00000 |
| r2s2 | scored | 0.7078 | 1.0000 | 1.00000 | 0.2898 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Output = argmax of `readout @ h2`, h2 = relu(w·x2 + rec·relu(w·x1 + rec·relu(w·x0))). The function is positively homogeneous (depends only on the input direction). On this network the output is 0 on ~89% of inputs (99.6% when x2>0, 79% when x2<0; outputs 1/2 occur only for x2<0 at moderate |x2| relative to the step-1 state). Structurally, for any weights: in each sign quadrant of (x0,x1), h1 is *exactly linear* inside angular sectors |x1|/|x0| ∈ (θ_i, θ_{i+1}) whose thresholds θ_j = −b_j/a_j come from the units whose two input coefficients have opposite signs (≤4 thresholds → ≤5 sectors); so p = B_sector·(x0,x1,x2) is a 4×3 linear map and the only remaining nonlinearity is the step-2 relu. For |x2| large relative to (|x0|,|x1|) the output is the limit output o± = argmax(R·relu(±w)). Certain of all this (algebra, verified on 48 random/degenerate weight sets with 0 errors).
    
    ## How you found it
    Looked at weights, output distribution by sign/sector/activation pattern, oracle catch rates of "cap" tests |x2| > T·(|x0|,|x1|) per sector, and numpy prototypes of build procedures; compared several option-selection rules and LP objectives; then translated to lv1, debugged with lv1.Evaluator against a numpy reference (found a sector-test sign bug and an LP-tie bug on random weights), and measured with `measure`.
    
    ## The best entry
    `sec_p2v3` (reward 0.7078, coverage 1, fidelity 1, cost 0.290; 400 nodes exactly). Interpretation: cond tree on sign(x2), sign(x0), sign(x1) (6 ops) → one linear cap test `x2 ≷ T[s2,q]·(x0,x1)` (4 ops) → constant o± if it passes (~70% of inputs); otherwise a fallback: balanced cond tree over the sector thresholds (≈6 ops, each test `x1 ≷ θ·x0`) selecting a build-time 4×3 matrix M, then `argmax(R @ relu(M @ x))` (30 ops). Build (26k ops, 2%): per (s2, quadrant, sector, k≠o) it derives sufficient linear conditions for margin_k>0 (limit-pattern units linear, others relu-bounded or pattern-constrained, two fixed option profiles, best per case by a score), converts each to a required threshold at the sector's two edge rays, merges them, and solves the 2-D LP min T0+T1 s.t. T·e_m ≥ V_m by enumerating the 15 vertex pairs (+ an always-feasible huge candidate), with tolerance and a 1e-6 relative safety bump. Everything is computed from weights inside the entry; nothing network-specific is hard-coded. Earlier this round: sec_p2v2 (0.7038, same but 29.7k build).
    
    ## Claims
    Claimed fidelity 1.0 here and expected 1.0 on the second network: the cap test is a weight-derived sufficient condition (strict inequalities, conservative handling of zero/negative x2-coefficients, degenerate ties disabled), and the fallback is an exact re-parametrisation of the forward pass (sector-wise linear h1). Verified 0 errors on 24+24 random weight sets (including w_j=0, duplicate/zero readout rows, one-signed w) with 1000–1500 inputs each, plus 16384 on this network. Coverage is 1 everywhere; only the catch rate (cost) varies with weights.
    
    ## Next
    The node limit (400) is now the binding constraint. Ideas: (1) per-unit heuristic option selection (numpy: fallback 25% vs 30%, ≈+1.5% reward) needs ~40 nodes and ~10k more build ops; (2) a second, sector-level cap test inside the fallback (catches ~20% of fallbacks for 4 ops) needs ~50 nodes — would require freeing nodes by sharing the fallback's relu/readout across quadrants (costs +0.6 ops/input); (3) weighted edge score (3 nodes) is likely neutral; (4) build could still be cut ~5k ops by sharing the constraint v computations. A margin-based readout (instead of 12-op R@h2 + argmax) was not cheaper once exact tie-breaking is included.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.7182 | 1.0000 | 1.00000 | 0.2795 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    Output = argmax of `readout @ h2`, `h2 = relu(w·x2 + rec·relu(w·x1 + rec·relu(w·x0)))`; the function is positively homogeneous (depends only on the input direction). On this network the output is 0 on ~89% of inputs (99.6% when x2>0, 79% when x2<0; outputs 1/2 only for x2<0 at moderate |x2| relative to the step‑1 state). Structurally, for any weights: in each sign quadrant of (x0,x1), h1 is exactly linear inside angular sectors |x1|/|x0| ∈ (θ_i, θ_{i+1}) (thresholds from the units whose two input coefficients have opposite signs, ≤4 per quadrant), so p = M_sector·(x0,x1,x2) is a 4×3 linear map and only the step‑2 relu remains. For |x2| large relative to (|x0|,|x1|) the output is the limit output o± = argmax(R·relu(±w)). New this round: the exact "cap" threshold T*(direction) was computed (oracle): for x2>0 it is ≈0 in all quadrants here (output 0 for essentially all x2>0 once x0>0), and the best single linear cap per octant could catch 78% of inputs (vs 69% for round‑2's entry). I'm certain of the algebra (verified on random/degenerate weights with 0 errors).
    
    ## How you found it
    Computed exact per-direction thresholds T* by enumerating unit/margin crossings along rays, compared the round‑2 entry's per-octant catch rates (0.999/0.767/0.98/0.746/0.95/0.418/0.55/0.139) with the octant-oracle (1/1/.987/.985/.939/.524/.538/.275), then dissected the sectors where the old sufficient conditions were loose. Found two generic improvements: (1) per-unit option choice for the margin lower bound (helping unit: zero or linear; hurting unit: convex-chord bound or "constrained" exact-linear/dead with its own linear threshold t>τ_j), chosen by a 1‑pass greedy over the 4 units (matches the exhaustive 16‑combo search on this network: catch 0.756); (2) a "lower set" argument: helping units with β<0 give a bound valid for t<s_lo(u); if s_lo ≥ V at both sector edges, the whole (sector, k) constraint is void (this is what proves output 0 for all x2>0 in two quadrants). Prototyped in numpy (random-weight exactness), then rewrote the entire entry in lv1 (vectorized over 2 signs × 4 quadrants × 5 sectors × 2 classes × 4 units × 2 edges), fought the 400-node limit, and fixed two bugs found via the lv1 Evaluator on random weights (dead-unit option must contribute 0 to ν when β<0; infeasible LP candidates must be marked with a value larger than any feasible proxy).
    
    ## The best entry
    `greedy_v6` (reward 0.7182, coverage 1, fidelity 1, cost 0.279; exactly 400 nodes, build 33.8k ops = 2.6%). Interpretation: sign tree on x2,x0,x1 (6 ops) → one linear cap test `x2 ≷ T[s2,q]·(x0,x1)` (4 ops) → constant o± if it passes (~74% of inputs at 10 ops); otherwise a shared fallback: ratio x1/x0, per-quadrant vector compare with the 4 sorted sector thresholds, cond tree selecting the 4×3 sector matrix M, then `argmax(R @ relu(M @ x))` (~38 ops). Build: per (s2, quadrant, sector, k≠o) it forms the margin lower bound μ·t + ν(u) from per-unit options (initial: helping β>0 linear, hurting chord), greedily flips each unit's option if it lowers Σ_edges max(V,0) (V = max(−ν/μ, τ constraints)), voids the constraint if the lower set covers it, bumps V by 1e‑7 relative, merges to 6 ray constraints per octant, solves the 2‑D LP by enumerating the 15 vertex pairs (feasibility with 1e‑9 tolerance, box T ≥ −3, proxy = Σ_dirs max(T·dir,0)). Everything is computed from the weights inside the entry.
    
    ## Claims
    Claimed 1.0 here and expected 1.0 on the second network: every cap is a weight-derived sufficient condition (strict margins, invalid cases disabled via 1e9 thresholds, exact-linear sector fallback), verified 0 errors on 22 random weight sets (incl. all-positive/all-negative w, w_j=0, duplicate and zero readout rows) with 1000 inputs each plus 16384 here. Coverage is 1 everywhere; only the catch rate (cost) varies.
    
    ## Next
    The node limit is binding (400 exactly). Gains left: (1) per-quadrant fallback chains and scalar threshold tests instead of the shared chain/vector compares would save ~1 op/input (+1.3%) if ~25 nodes can be freed (e.g., fewer reshape/const nodes, merging the lower-set arrays); (2) the greedy only flips 0→1 from the initial set; allowing the tiny-β helping units to be dropped (exhaustive gave 0.203 vs 0.162 catch in octant (−,−,−)); (3) octant-oracle ceiling is 0.78 catch vs 0.756 now, sector-level caps 0.81 — a second cap test inside the fallback is break-even; (4) build could be trimmed (~5k ops) by dropping degenerate duplicate sectors from the LP.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.7182) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
