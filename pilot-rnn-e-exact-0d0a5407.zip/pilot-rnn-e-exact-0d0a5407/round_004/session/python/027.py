
import numpy as np
ent = entries['skip_v4']; nodes = ent['nodes']
ev = lv1.Evaluator(ent, weights, 3)
store = {}
for i,n in enumerate(nodes):
    if ev.dep[i]: continue
    if n['op']=='cond':
        c,a,b = n['args']; store[i] = store[a if bool(store[c].reshape(())) else b]; continue
    vals = [store[j] for j in n.get('args',[])]
    with np.errstate(all='ignore'):
        v,c = lv1.apply(n, vals, None, ev.weights, store)
    store[i]=v
cand = [i for i in store if store[i].shape==(2,4,15,2) and nodes[i]['op']=='stack'][0]
feas = [i for i in store if store[i].shape==(2,4,15) and nodes[i]['op']=='all'][0]
Tsel = [i for i in store if store[i].shape==(2,4,2) and nodes[i]['op']=='mul'][-1]
C = store[cand]; F = store[feas]; T = store[Tsel]
print(cand, feas, Tsel)
rng = np.random.default_rng(0); X = rng.standard_normal((100000,3)); Y = np.abs(X)
s = (X>0).astype(int)
quadsign = np.array([[1,1],[1,-1],[-1,1],[-1,-1]])
for side in range(2):
    for q in range(4):
        m = ((X[:,2]>0)==(side==0)) & (s[:,0]==(quadsign[q,0]>0)) & (s[:,1]==(quadsign[q,1]>0))
        Yq = Y[m]
        rates = []
        for c in range(15):
            if not F[side,q,c]: rates.append(-1); continue
            t = C[side,q,c]
            rates.append(np.mean(Yq[:,2] > t[0]*Yq[:,0] + t[1]*Yq[:,1]))
        tsel = T[side,q]*quadsign[q]*(1 if side==0 else -1)
        chosen = np.mean(Yq[:,2] > tsel[0]*Yq[:,0] + tsel[1]*Yq[:,1])
        print(side, q, "chosen %.3f"%chosen, "best cand %.3f"%max(rates), "T", np.round(tsel,3), "cands", np.round([r for r in rates if r>=0],3))
