
import copy, json, numpy as np
def surgery(base):
    nodes = copy.deepcopy(base['nodes'])
    # work with keyed list
    L = [dict(n, _id=i) for i,n in enumerate(nodes)]
    def redirect(old, new):
        for n in L:
            if 'args' in n: n['args'] = [new if a==old else a for a in n['args']]
    # 1. 1e30 -> 1e18
    redirect(6, 31)
    # 2. node 80 = 77 + 76 ; drop 79
    for n in L:
        if n['_id']==80: n['args'] = [77, 76]
    # 3. node 4 -> 1e-9, redirect 251 -> 4
    for n in L:
        if n['_id']==4: n['value'] = 1e-9
    redirect(251, 4)
    # 4. consts
    for n in L:
        if n['_id']==11: n['value'] = [[1.0],[-1.0]]
        if n['_id']==20: n['value'] = [[1.0],[-1.0],[1.0],[-1.0]]
        if n['_id']==272: n.clear(); n.update({'op':'const','dtype':'float','value':[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], '_id':272})
    redirect(13, 11); redirect(22, 20)
    dead = {6, 79, 251, 13, 22, 21}
    L = [n for n in L if n['_id'] not in dead]
    # 5. skip nodes inserted before 379
    new = [
        {'op':'mul','args':[275,272],'_id':'A'},
        {'op':'le','args':['A',0],'_id':'B'},
        {'op':'slice','args':['B'],'index':[0,{'start':0,'step':None,'stop':2},None],'_id':'C'},
        {'op':'all','args':['C'],'axis':None,'_id':'D'},
        {'op':'cond','args':['D',359,369],'_id':'E'},
    ]
    pos = [i for i,n in enumerate(L) if n['_id']==379][0]
    L = L[:pos] + new + L[pos:]
    for n in L:
        if n['_id']==379: n['args'] = [289,'E',378]
    remap = {n['_id']:i for i,n in enumerate(L)}
    out = []
    for n in L:
        m = {k:v for k,v in n.items() if k!='_id'}
        if 'args' in m: m['args'] = [remap[a] for a in m['args']]
        out.append(m)
    return {'format': base['format'], 'nodes': out, 'predict': remap[399], 'rule': None}
ent = surgery(entries['best'])
print(len(ent['nodes']))
print(lv1.check_structure(ent))
print(measure(ent))
save_entry('skip_v1', ent)
