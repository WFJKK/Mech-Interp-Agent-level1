
e = entries['best']
from collections import Counter
nodes = e['nodes']
print(nodes[0]); print(nodes[1]); print(e['predict'], e['rule'])
c = Counter(n.get('op', n.get('kind','?')) for n in nodes)
print(c)
# print a compact listing
for i,n in enumerate(nodes[:60]): print(i, n)
