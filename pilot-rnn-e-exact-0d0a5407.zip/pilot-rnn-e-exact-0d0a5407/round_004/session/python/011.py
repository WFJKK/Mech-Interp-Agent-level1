
import inspect
print(lv1.KINDS if not callable(lv1.KINDS) else '')
print(inspect.getsource(lv1.check_structure)[:2500])
# count const numbers
tot=0
for n in entries['best']['nodes']:
    if n['op']=='const': tot += np.array(n['value']).size
print("const numbers", tot, lv1.MAX_CONST_SCALARS, lv1.MAX_NODES)
