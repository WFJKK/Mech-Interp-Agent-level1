
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def fwd(X, w=w, rec=rec, R=R):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
rng = np.random.default_rng(0)
X = rng.standard_normal((16384,3)); y = fwd(X)
ev = lv1.Evaluator(entries['best'], weights, 3)
costs = np.array([ev.run(x)[3] for x in X]); fb = costs > 20
s = (X>0).astype(int); octi = s[:,2]*4 + s[:,0]*2 + s[:,1]
# per quadrant (s0,s1): A = [rec@relu(s0 w), s1 w]; thresholds for mixed rows
tot_cost = 0; tot_mass = 0
for o in range(8):
    s2,s0,s1 = [(1 if (o>>b)&1 else -1) for b in (2,1,0)]
    A = np.stack([rec @ np.maximum(s0*w,0), s1*w],1)  # 4x2, acting on y=(|x0|,|x1|)
    # sector thresholds: rows with mixed signs: a y0 + b y1 = 0 -> y1/y0 = -a/b
    th = []
    for j in range(4):
        a,b = A[j]
        if a*b < 0: th.append(-a/b)
    th = sorted(th); edges = [0]+th+[np.inf]
    m = octi==o
    Y = np.abs(X[m]); r = Y[:,1]/Y[:,0]; fbm = fb[m]
    for k in range(len(th)+1):
        lo,hi = edges[k], edges[k+1]
        rm = (r>=lo)&(r<hi)
        mid = (lo + (hi if np.isfinite(hi) else lo*2+1))/2
        act = (A @ np.array([1,mid]) > 0).astype(float)
        M = np.concatenate([ (rec @ (A*act[:,None])), (s2*w)[:,None]],1)  # 4x3 on y=(y0,y1,y2)
        cls = ['L' if (M[j]>=0).all() else ('D' if (M[j]<=0).all() else 'X') for j in range(4)]
        nX = cls.count('X'); nL = cls.count('L')
        # reduced cost: if nL==0: 3nX + nX + 3nX + 2 ; else fold: 9 + 3nX+nX+3nX+3 +2
        red = (3*nX+nX+3*nX+2) if nL==0 else (9+7*nX+3+2)
        mass = (rm&fbm).sum()/len(X)
        tot_cost += red*mass; tot_mass += mass
        print(o, k, "lo %.2f hi %.2f"%(lo,hi), "mass %.4f fbmass %.4f"%(rm.sum()/len(X), mass), cls, "red", red, "outs", np.bincount(y[m][rm&fbm],minlength=3))
print("fallback mass", tot_mass, "avg reduced cost", tot_cost/tot_mass)
