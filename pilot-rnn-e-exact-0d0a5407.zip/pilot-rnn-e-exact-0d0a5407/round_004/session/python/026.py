
import numpy as np
def fwd(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
ent = entries['skip_v4']
rng = np.random.default_rng(321); errs=0; tot=0; cs=[]
for k in range(60):
    sc = rng.choice([0.1,0.5,1.0,3.0])
    W = {'input': rng.standard_normal((4,1))*sc, 'recurrent': rng.standard_normal((4,4))*sc, 'readout': rng.standard_normal((3,4))*sc}
    r = k%15
    if r==1: W['input'][:,0] = [0,0,1,-1]
    if r==2: W['recurrent'][:] = 0
    if r==3: W['readout'][:] = 0
    if r==4: W['readout'][0] = W['readout'][1] = W['readout'][2]
    if r==5: W['input'][:,0] = np.abs(W['input'][:,0]); W['recurrent'] = -np.abs(W['recurrent'])
    if r==6: W['recurrent'] = np.round(W['recurrent'],1); W['input'] = np.round(W['input'],1)
    if r==7: W['input'][:2,0] = 0
    if r==8: W['recurrent'][0] = W['recurrent'][1]
    if r==9: W['readout'][:,0] = 0; W['readout'][:,3]=0
    if r==10: W['recurrent'] = np.eye(4)*sc
    if r==11: W['input'] = np.abs(W['input'])
    if r==12: W['input'] = -np.abs(W['input'])
    if r==13: W['recurrent'] = np.abs(W['recurrent'])
    if r==14: W['readout'][1] = W['readout'][0]
    X = rng.standard_normal((500,3))
    yy = fwd(X, W['input'][:,0], W['recurrent'], W['readout'])
    ev = lv1.Evaluator(ent, W, 3)
    try:
        res = [ev.run(x) for x in X]; pred = np.array([q[1] for q in res]); cs.append(np.mean([q[3] for q in res]))
    except Exception as ex:
        print("set", k, r, "EXC", ex); continue
    e = (pred!=yy).sum(); errs+=e; tot+=500
    if e: print("set", k, "r", r, "errors", e)
print("errors", errs, "/", tot, "cost range", min(cs), max(cs))
X = rng.standard_normal((50000,3)); yy = fwd(X, weights['input'][:,0], weights['recurrent'], weights['readout'])
ev = lv1.Evaluator(ent, weights, 3); res = [ev.run(x) for x in X]
pred = np.array([r[1] for r in res]); c = np.array([r[3] for r in res])
print("this net errors", (pred!=yy).sum(), "mean cost", c.mean(), {int(k):int(v) for k,v in zip(*np.unique(c, return_counts=True))})
