
import copy, numpy as np
base = entries['skip_v3_mixed']
# find the (2,5) const node (proxy dirs) and the structure of the greedy chain in the new numbering
nodes = base['nodes']
idx259 = [i for i,n in enumerate(nodes) if n['op']=='const' and np.array(n['value']).shape==(2,5)][0]
print("dirs node", idx259, nodes[idx259]['value'])
def with_dirs(e, angles_deg):
    e2 = copy.deepcopy(e); a = np.deg2rad(np.array(angles_deg))
    e2['nodes'][idx259]['value'] = np.stack([np.cos(a), np.sin(a)]).tolist()
    return e2
for angs in ([15,45,75],[10,30,50,70,80],[45],[20,70]):
    e2 = with_dirs(base, angs); m = measure(e2); print(angs, round(m['reward'],4), m['predict_ops'], m['build_ops'])
