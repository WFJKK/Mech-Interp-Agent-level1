
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def fwd(X, w=w, rec=rec, R=R):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
rng = np.random.default_rng(0)
X = rng.standard_normal((16384,3))
y = fwd(X)
ev = lv1.Evaluator(entries['best'], weights, 3)
costs = np.array([ev.run(x)[3] for x in X])
print(ev.build_cost, {int(k):int(v) for k,v in zip(*np.unique(costs, return_counts=True))})
fb = costs > 20
print("fallback frac", fb.mean(), "mean cost", costs.mean(), "fallback mean cost", costs[fb].mean())
s = (X>0).astype(int); octi = s[:,2]*4 + s[:,0]*2 + s[:,1]
for o in range(8):
    m = octi==o
    print(o, "s2,s0,s1=",(o>>2)&1,(o>>1)&1,o&1, "frac %.3f"%m.mean(), "fb %.3f"%fb[m].mean(), "outs", np.round(np.bincount(y[m],minlength=3)/m.sum(),3), "fb outs", np.bincount(y[m&fb],minlength=3))
