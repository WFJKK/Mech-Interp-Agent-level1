
costs = np.array([ev.run(x)[3] for x in X])
print(ev.build_cost, np.bincount(costs))
fb = costs > 20
print("fallback frac", fb.mean(), "mean cost", costs.mean(), "fallback mean cost", costs[fb].mean())
# octant stats
s = (X>0).astype(int); octi = s[:,2]*4 + s[:,0]*2 + s[:,1]
for o in range(8):
    m = octi==o
    print(o, "s2,s0,s1=",(o>>2)&1,(o>>1)&1,o&1, "frac %.3f"%m.mean(), "fb %.3f"%fb[m].mean(), "outs", np.bincount(y[m],minlength=3)/m.sum(), "fb outs", np.bincount(y[m&fb],minlength=3))
