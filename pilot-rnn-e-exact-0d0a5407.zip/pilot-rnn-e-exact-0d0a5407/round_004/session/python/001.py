
import json, numpy as np
print(info)
print({k:v.shape for k,v in weights.items()})
for k,v in weights.items(): print(k, np.round(v,4))
print(list(entries.keys()))
e = entries['best']
print(measure(e))
print(len(e.get('nodes', e.get('graph', []))) if isinstance(e, dict) else type(e))
print(list(e.keys()) if isinstance(e, dict) else None)
