
import numpy as np
e = entries['best']; nodes = e['nodes']
ev = lv1.Evaluator(e, weights, 3)
store = {}; costs = []
for i,n in enumerate(nodes):
    if ev.dep[i]: costs.append(0); continue
    if n['op']=='cond':
        c,a,b = n['args']; chosen = a if bool(store[c].reshape(())) else b
        store[i] = store[chosen]; costs.append(1); continue
    vals = [store[j] for j in n.get('args',[])]
    with np.errstate(all='ignore'):
        v,c = lv1.apply(n, vals, None, ev.weights, store)
    store[i]=v; costs.append(c)
costs = np.array(costs)
segs = [(0,61),(61,84),(84,113),(113,124),(124,144),(144,164),(164,184),(184,201),(201,224),(224,250),(250,264),(264,272),(272,400)]
for a,b in segs: print(a,b, costs[a:b].sum())
