
e = entries['best']; nodes = e['nodes']
ev = lv1.Evaluator(e, weights, 3)
for i in range(272, 400):
    n = nodes[i]
    d = {k:v for k,v in n.items() if k!='value'}
    if 'value' in n: d['value'] = np.array(n['value']).shape if np.ndim(n['value'])>0 else n['value']
    print(i, 'D' if ev.dep[i] else 'B', d)
