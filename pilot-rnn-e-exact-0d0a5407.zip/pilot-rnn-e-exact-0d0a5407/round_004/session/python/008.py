
import numpy as np, inspect
e = entries['best']; nodes = e['nodes']
print(inspect.signature(lv1.apply))
ev = lv1.Evaluator(e, weights, 3)
store = {}; costs = []
for i,n in enumerate(nodes):
    if ev.dep[i]: costs.append(0); continue
    if n['op']=='cond':
        c,a,b = n['args']; chosen = a if bool(store[c].reshape(())) else b
        store[i] = store[chosen]; costs.append(1); continue
    vals = [store[j] for j in n.get('args',[])]
    with np.errstate(all='ignore'):
        v,c = lv1.apply(n, vals, None, ev.weights, store)
    store[i]=v; costs.append(c)
costs = np.array(costs); print(costs.sum())
order = np.argsort(-costs)[:40]
for i in order: print(i, costs[i], nodes[i]['op'], store[i].shape, [ (j, store[j].shape) for j in nodes[i].get('args',[])])
