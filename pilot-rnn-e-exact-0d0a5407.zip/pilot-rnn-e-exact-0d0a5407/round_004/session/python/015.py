
import copy, json, numpy as np
def surgery2(base, per_sign_fb=True, bump=True, drop12=True):
    nodes = copy.deepcopy(base['nodes'])
    L = [dict(n, _id=i) for i,n in enumerate(nodes)]
    def redirect(old, new):
        for n in L:
            if 'args' in n: n['args'] = [new if a==old else a for a in n['args']]
    def get(i): return [n for n in L if n['_id']==i][0]
    def insert_before(i, new):
        nonlocal L
        pos = [k for k,n in enumerate(L) if n['_id']==i][0]
        L = L[:pos] + new + L[pos:]
    redirect(6, 31)
    get(80)['args'] = [77, 76]
    get(4)['value'] = 1e-9; redirect(251, 4)
    get(11)['value'] = [[1.0],[-1.0]]
    get(20)['value'] = [[1.0],[-1.0],[1.0],[-1.0]]
    n272 = get(272); n272.clear(); n272.update({'op':'const','dtype':'float','value':[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], '_id':272})
    redirect(13, 11); redirect(22, 20)
    dead = {6, 79, 251, 13, 22, 21}
    if drop12:
        redirect(12, 8); dead.add(12)
    if bump:
        insert_before(213, [{'op':'const','dtype':'float','value':1.0000001,'_id':'c1'},
                            {'op':'mul','args':[211,'c1'],'_id':'m1'}])
        get(216)['args'] = ['m1', 212]
        dead |= {213, 214, 215}
    insert_before(379, [
        {'op':'mul','args':[275,272],'_id':'A'},
        {'op':'le','args':['A',0],'_id':'B'},
        {'op':'slice','args':['B'],'index':[0,{'start':0,'step':None,'stop':2},None],'_id':'C'},
        {'op':'all','args':['C'],'axis':None,'_id':'D'},
        {'op':'cond','args':['D',359,369],'_id':'E'}])
    get(379)['args'] = [289,'E',378]
    if per_sign_fb:
        insert_before(354, [
            {'op':'matmul','args':[322,283],'_id':'p1'},{'op':'maximum','args':['p1',0],'_id':'p2'},
            {'op':'matmul','args':[10,'p2'],'_id':'p3'},{'op':'argmax','args':['p3'],'axis':None,'_id':'FBp'},
            {'op':'matmul','args':[353,283],'_id':'n1'},{'op':'maximum','args':['n1',0],'_id':'n2'},
            {'op':'matmul','args':[10,'n2'],'_id':'n3'},{'op':'argmax','args':['n3'],'axis':None,'_id':'FBn'}])
        for i in (364,368,383,387): get(i)['args'] = [a if a!=358 else 'FBp' for a in get(i)['args']]
        for i in (373,377,392,396): get(i)['args'] = [a if a!=358 else 'FBn' for a in get(i)['args']]
        dead |= {354,355,356,357,358}
    L = [n for n in L if n['_id'] not in dead]
    remap = {n['_id']:i for i,n in enumerate(L)}
    out = []
    for n in L:
        m = {k:v for k,v in n.items() if k!='_id'}
        if 'args' in m: m['args'] = [remap[a] for a in m['args']]
        out.append(m)
    return {'format': base['format'], 'nodes': out, 'predict': remap[399], 'rule': None}
ent = surgery2(entries['best'])
print(lv1.check_structure(ent))
m = measure(ent); print(m)
save_entry('skip_v2', ent)
