
nodes = entries['best']['nodes']
for i in (43, 92, 113, 218, 224, 225, 259, 279):
    print(i, np.array(nodes[i]['value']).squeeze().tolist() if i!=279 else np.unique(nodes[i]['value']))
