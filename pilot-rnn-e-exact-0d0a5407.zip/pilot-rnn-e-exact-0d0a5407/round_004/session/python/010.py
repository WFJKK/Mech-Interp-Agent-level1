
e = entries['best']; nodes = e['nodes']
reach = set(); st=[399]
while st:
    i = st.pop()
    if i in reach: continue
    reach.add(i); st.extend(nodes[i].get('args',[]))
print("unreachable:", [i for i in range(400) if i not in reach])
# users count
users = {i:[] for i in range(400)}
for i,n in enumerate(nodes):
    for a in n.get('args',[]): users[a].append(i)
ev = lv1.Evaluator(e, weights, 3)
for i in range(60, 272):
    n = nodes[i]
    d = {k:v for k,v in n.items() if k not in('value','op','args')}
    val = (np.array(n['value']).shape if np.ndim(n['value'])>0 else n['value']) if 'value' in n else ''
    print(i, n['op'], n.get('args',''), d if d else '', val, 'users', users[i])
