
import copy, numpy as np
base = entries['skip_v5']
nodes = base['nodes']
idx259 = [i for i,n in enumerate(nodes) if n['op']=='const' and np.array(n['value']).shape==(2,1)][0]
print(idx259, nodes[idx259]['value'])
def with_dirs(e, angles_deg):
    e2 = copy.deepcopy(e); a = np.deg2rad(np.array(angles_deg))
    e2['nodes'][idx259]['value'] = np.stack([np.cos(a), np.sin(a)]).tolist()
    return e2
rng = np.random.default_rng(99); X = rng.standard_normal((8000,3))
def cost_of(e):
    ev = lv1.Evaluator(e, weights, 3); return np.mean([ev.run(x)[3] for x in X]), ev.build_cost
print("base", cost_of(base))
for angs in ([10,30,50,70,80],[15,45,75],[30],[60]):
    print(angs, cost_of(with_dirs(base, angs)))
