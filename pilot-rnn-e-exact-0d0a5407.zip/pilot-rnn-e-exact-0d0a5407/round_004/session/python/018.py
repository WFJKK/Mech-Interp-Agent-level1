
import copy, json, numpy as np
def surgery3(base):
    nodes = copy.deepcopy(base['nodes'])
    L = [dict(n, _id=i) for i,n in enumerate(nodes)]
    def redirect(old, new):
        for n in L:
            if 'args' in n: n['args'] = [new if a==old else a for a in n['args']]
    def get(i): return [n for n in L if n['_id']==i][0]
    def insert_before(i, new):
        nonlocal L
        pos = [k for k,n in enumerate(L) if n['_id']==i][0]
        L = L[:pos] + new + L[pos:]
    dead = set()
    redirect(6, 31); dead.add(6)
    get(80)['args'] = [77, 76]; dead.add(79)
    get(4)['value'] = 1e-9; redirect(251, 4); dead.add(251)
    get(11)['value'] = [[1.0],[-1.0]]; redirect(13, 11); dead.add(13)
    get(20)['value'] = [[1.0],[-1.0],[1.0],[-1.0]]; redirect(22, 20); dead.add(22)
    redirect(12, 8); dead.add(12)
    # bump
    insert_before(213, [{'op':'const','dtype':'float','value':1.0000001,'_id':'c1'},
                        {'op':'mul','args':[211,'c1'],'_id':'m1'}])
    get(216)['args'] = ['m1', 212]; dead |= {213, 214, 215}
    # 55: cast+mul -> where
    n56 = get(56); n56.clear(); n56.update({'op':'where','args':[54,25,0],'_id':56}); dead.add(55)
    # 113 -> scalar 3
    redirect(113, 3); dead.add(113)
    # S3 trick
    S3 = [[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], [[-1.0,-1.0],[-1.0,1.0],[1.0,-1.0],[1.0,1.0]]]
    insert_before(275, [{'op':'const','dtype':'float','value':S3,'_id':'S3'}])
    get(275)['args'] = [271, 'S3']; dead |= {272, 273, 274, 21}
    # skip
    insert_before(379, [
        {'op':'slice','args':[271],'index':[0,{'start':0,'step':None,'stop':2},None],'_id':'A'},
        {'op':'le','args':['A',0],'_id':'B'},
        {'op':'all','args':['B'],'axis':None,'_id':'D'},
        {'op':'cond','args':['D',359,369],'_id':'E'}])
    get(379)['args'] = [289,'E',378]
    # fallbacks: x0>0 per sign (322), x0<0 per quadrant (337, 352)
    insert_before(354, [
        {'op':'matmul','args':[322,283],'_id':'p1'},{'op':'maximum','args':['p1',0],'_id':'p2'},
        {'op':'matmul','args':[10,'p2'],'_id':'p3'},{'op':'argmax','args':['p3'],'axis':None,'_id':'FBp'},
        {'op':'matmul','args':[337,283],'_id':'q1'},{'op':'maximum','args':['q1',0],'_id':'q2'},
        {'op':'matmul','args':[10,'q2'],'_id':'q3'},{'op':'argmax','args':['q3'],'axis':None,'_id':'FB2'},
        {'op':'matmul','args':[352,283],'_id':'r1'},{'op':'maximum','args':['r1',0],'_id':'r2'},
        {'op':'matmul','args':[10,'r2'],'_id':'r3'},{'op':'argmax','args':['r3'],'axis':None,'_id':'FB3'}])
    for i in (364,368,383,387): get(i)['args'] = [a if a!=358 else 'FBp' for a in get(i)['args']]
    for i in (373,392): get(i)['args'] = [a if a!=358 else 'FB2' for a in get(i)['args']]
    for i in (377,396): get(i)['args'] = [a if a!=358 else 'FB3' for a in get(i)['args']]
    dead |= {353,354,355,356,357,358}
    L = [n for n in L if n['_id'] not in dead]
    remap = {n['_id']:i for i,n in enumerate(L)}
    out = []
    for n in L:
        m = {k:v for k,v in n.items() if k!='_id'}
        if 'args' in m: m['args'] = [remap[a] for a in m['args']]
        out.append(m)
    return {'format': base['format'], 'nodes': out, 'predict': remap[399], 'rule': None}
ent = surgery3(entries['best'])
print(lv1.check_structure(ent))
m = measure(ent); print(m)
save_entry('skip_v3', ent)
# compare T tables between v2 and v3 on this network
def Ttable(e):
    ev = lv1.Evaluator(e, weights, 3); ev.run(np.zeros(3)); 
    # find node mul with args ending in const S3 / or 275-equivalent: pick build value of shape (2,4,2) feeding matmul slices
    return ev
