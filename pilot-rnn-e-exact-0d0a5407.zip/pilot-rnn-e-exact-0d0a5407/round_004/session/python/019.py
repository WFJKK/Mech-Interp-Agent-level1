
import copy, json, numpy as np
def surgery3(base, fb_mode='mixed'):
    nodes = copy.deepcopy(base['nodes'])
    L = [dict(n, _id=i) for i,n in enumerate(nodes)]
    def redirect(old, new):
        for n in L:
            if 'args' in n: n['args'] = [new if a==old else a for a in n['args']]
    def get(i): return [n for n in L if n['_id']==i][0]
    def insert_before(i, new):
        nonlocal L
        pos = [k for k,n in enumerate(L) if n['_id']==i][0]
        L = L[:pos] + new + L[pos:]
    dead = set()
    redirect(6, 31); dead.add(6)
    get(80)['args'] = [77, 76]; dead.add(79)
    get(4)['value'] = 1e-9; redirect(251, 4); dead.add(251)
    get(11)['value'] = [[1.0],[-1.0]]; redirect(13, 11); dead.add(13)
    get(20)['value'] = [[1.0],[-1.0],[1.0],[-1.0]]; redirect(22, 20); dead.add(22)
    n272 = get(272); n272.clear(); n272.update({'op':'const','dtype':'float','value':[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], '_id':272}); dead.add(21)
    redirect(12, 8); dead.add(12)
    insert_before(213, [{'op':'const','dtype':'float','value':1.0000001,'_id':'c1'},
                        {'op':'mul','args':[211,'c1'],'_id':'m1'}])
    get(216)['args'] = ['m1', 212]; dead |= {213, 214, 215}
    n56 = get(56); n56.clear(); n56.update({'op':'where','args':[54,25,0],'_id':56}); dead.add(55)
    redirect(113, 3); dead.add(113)
    S3 = [[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], [[-1.0,-1.0],[-1.0,1.0],[1.0,-1.0],[1.0,1.0]]]
    insert_before(275, [{'op':'const','dtype':'float','value':S3,'_id':'S3'}])
    get(275)['args'] = [271, 'S3']; dead |= {273, 274}
    insert_before(379, [
        {'op':'slice','args':[271],'index':[0,{'start':0,'step':None,'stop':2},None],'_id':'A'},
        {'op':'le','args':['A',0],'_id':'B'},
        {'op':'all','args':['B'],'axis':None,'_id':'D'},
        {'op':'cond','args':['D',359,369],'_id':'E'}])
    get(379)['args'] = [289,'E',378]
    def fbnodes(tag, Mnode):
        return [{'op':'matmul','args':[Mnode,283],'_id':tag+'1'},{'op':'maximum','args':[tag+'1',0],'_id':tag+'2'},
                {'op':'matmul','args':[10,tag+'2'],'_id':tag+'3'},{'op':'argmax','args':[tag+'3'],'axis':None,'_id':'FB'+tag}]
    if fb_mode=='mixed':
        insert_before(354, fbnodes('p',322)+fbnodes('q',337)+fbnodes('r',352))
        m = {364:'FBp',368:'FBp',383:'FBp',387:'FBp',373:'FBq',392:'FBq',377:'FBr',396:'FBr'}
        dead |= {353}
    elif fb_mode=='quad':
        insert_before(354, fbnodes('o',306)+fbnodes('p',321)+fbnodes('q',337)+fbnodes('r',352))
        m = {364:'FBo',383:'FBo',368:'FBp',387:'FBp',373:'FBq',392:'FBq',377:'FBr',396:'FBr'}
        dead |= {353, 322}
    for i,t in m.items(): get(i)['args'] = [a if a!=358 else t for a in get(i)['args']]
    dead |= {354,355,356,357,358}
    L = [n for n in L if n['_id'] not in dead]
    remap = {n['_id']:i for i,n in enumerate(L)}
    out = []
    for n in L:
        mm = {k:v for k,v in n.items() if k!='_id'}
        if 'args' in mm: mm['args'] = [remap[a] for a in mm['args']]
        out.append(mm)
    return {'format': base['format'], 'nodes': out, 'predict': remap[399], 'rule': None}
for mode in ('mixed','quad'):
    ent = surgery3(entries['best'], mode)
    try:
        print(mode, lv1.check_structure(ent)); print(measure(ent)); save_entry('skip_v3_'+mode, ent)
    except Exception as ex: print(mode, 'ERR', ex)
