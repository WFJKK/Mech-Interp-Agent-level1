
import copy, numpy as np
base = entries['best']
# in the original numbering, test dropping pass 4: redirect 200->182, remove 180,181,183..200
def drop_pass4(e):
    e2 = copy.deepcopy(e); nodes = e2['nodes']
    for n in nodes:
        if 'args' in n: n['args'] = [182 if a==200 else a for a in n['args']]
    return e2
e2 = drop_pass4(base); m = measure(e2); print("drop pass4", round(m['reward'],4), m['predict_ops'], m['build_ops'])
m0 = measure(base); print("base", round(m0['reward'],4), m0['predict_ops'], m0['build_ops'])
# also test dropping pass 3 and 4: redirect 200 -> 162
def drop_pass34(e):
    e2 = copy.deepcopy(e); nodes = e2['nodes']
    for n in nodes:
        if 'args' in n: n['args'] = [162 if a==200 else a for a in n['args']]
    return e2
e3 = drop_pass34(base); m = measure(e3); print("drop pass3+4", round(m['reward'],4), m['predict_ops'], m['build_ops'])
# compare per-octant catch on random weights: base vs drop4
def fwd(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
rng = np.random.default_rng(5); diffs=[]
for k in range(12):
    W = {'input': rng.standard_normal((4,1)), 'recurrent': rng.standard_normal((4,4))*0.5, 'readout': rng.standard_normal((3,4))}
    X = rng.standard_normal((400,3))
    ca = np.mean([lv1.Evaluator(base, W, 3).run(x)[3] for x in X]); cb = np.mean([lv1.Evaluator(e2, W, 3).run(x)[3] for x in X])
    diffs.append((round(ca,1), round(cb,1)))
print(diffs)
