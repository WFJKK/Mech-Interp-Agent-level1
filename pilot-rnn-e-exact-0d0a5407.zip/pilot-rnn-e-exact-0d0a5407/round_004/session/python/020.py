
import numpy as np
def fwd(X, w, rec, R):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
def verify(ent, nsets=20, n=1000, seed=1, ref=None):
    rng = np.random.default_rng(seed); errs = 0; tot=0; costs=[]; refc=[]
    for k in range(nsets):
        sc = rng.choice([0.3,0.5,1.0,2.0])
        W = {'input': rng.standard_normal((4,1))*sc, 'recurrent': rng.standard_normal((4,4))*sc, 'readout': rng.standard_normal((3,4))*sc}
        if k%8==1: W['input'] = np.abs(W['input'])
        if k%8==2: W['input'] = -np.abs(W['input'])
        if k%8==3: W['input'][1,0] = 0.0
        if k%8==4: W['readout'][2] = W['readout'][0]
        if k%8==5: W['readout'][1] = 0.0
        if k%8==6: W['recurrent'][:,2] = 0.0
        if k%8==7: W['recurrent'] = np.abs(W['recurrent'])
        X = rng.standard_normal((n,3))
        yy = fwd(X, W['input'][:,0], W['recurrent'], W['readout'])
        ev = lv1.Evaluator(ent, W, 3)
        pred = []; c=[]
        for x in X:
            r = ev.run(x); pred.append(r[1]); c.append(r[3])
        pred = np.array(pred); e = (pred!=yy).sum(); errs += e; tot += n
        costs.append(np.mean(c))
        if ref is not None:
            evr = lv1.Evaluator(ref, W, 3); refc.append(np.mean([evr.run(x)[3] for x in X]))
        if e: print("set", k, "errors", e, "at", np.where(pred!=yy)[0][:5])
    print("errors", errs, "/", tot, "mean costs", np.round(costs,1))
    if ref is not None: print("ref costs", np.round(refc,1))
verify(entries['skip_v3_mixed'], 32, 1000, seed=11, ref=entries['best'])
