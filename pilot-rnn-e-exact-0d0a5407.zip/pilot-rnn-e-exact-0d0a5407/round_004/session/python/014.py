
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
def grid(s0,s1,s2, n=40):
    # parametrize direction by (a,b) in [0,1]^2 : x = (s0*a, s1*b, s2*(1-max(a,b)))? use y2 fixed =1 and u=y0/y2, v=y1/y2 in log scale
    us = np.exp(np.linspace(np.log(0.05), np.log(20), n))
    rows=[]
    for v in us[::-1]:
        X = np.stack([s0*us, s1*np.full(n, v), s2*np.ones(n)],1)
        rows.append(''.join(str(k) for k in fwd(X)))
    print(f"octant s0={s0} s1={s1} s2={s2}: rows v=|x1|/|x2| from 20 down to 0.05 (log), cols u=|x0|/|x2| from 0.05 to 20")
    for r in rows: print(r)
grid(-1,-1,-1); grid(-1,1,-1); grid(1,-1,-1)
