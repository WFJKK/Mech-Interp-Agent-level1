
import numpy as np, inspect
w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ R.T).argmax(1)
rng = np.random.default_rng(0)
X = rng.standard_normal((16384,3))
y = fwd(X)
ev = lv1.Evaluator(entries['best'], weights, 3)
src = inspect.getsource(lv1.Evaluator.run); print(src[:1500])
