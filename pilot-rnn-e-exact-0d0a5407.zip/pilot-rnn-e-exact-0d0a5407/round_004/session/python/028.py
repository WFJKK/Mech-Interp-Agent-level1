
import copy, json, numpy as np
exec_src = '''
def surgery5(base, drop_helping=True, **kw):
    e = surgery4_pre(base, drop_helping=drop_helping, **kw)
    return e
'''
# re-define surgery4 with an extra option (copying the code from before with the addition)
def surgery4(base, drop4=True, dirs=[45], scalar_tree=True, fb_mode='quad', drop_helping=False):
    nodes = copy.deepcopy(base['nodes'])
    L = [dict(n, _id=i) for i,n in enumerate(nodes)]
    def redirect(old, new, only=None):
        for n in L:
            if 'args' in n and (only is None or n['_id'] in only): n['args'] = [new if a==old else a for a in n['args']]
    def get(i): return [n for n in L if n['_id']==i][0]
    def insert_before(i, new):
        nonlocal L
        pos = [k for k,n in enumerate(L) if n['_id']==i][0]
        L = L[:pos] + new + L[pos:]
    dead = set()
    redirect(6, 31); dead.add(6)
    get(80)['args'] = [77, 76]; dead.add(79)
    get(4)['value'] = 1e-9; redirect(251, 4); dead.add(251)
    get(11)['value'] = [[1.0],[-1.0]]; redirect(13, 11); dead.add(13)
    get(20)['value'] = [[1.0],[-1.0],[1.0],[-1.0]]; redirect(22, 20); dead.add(22)
    n272 = get(272); n272.clear(); n272.update({'op':'const','dtype':'float','value':[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], '_id':272}); dead.add(21)
    redirect(12, 8); dead.add(12)
    insert_before(213, [{'op':'const','dtype':'float','value':1.0000001,'_id':'c1'},
                        {'op':'mul','args':[211,'c1'],'_id':'m1'}])
    get(216)['args'] = ['m1', 212]; dead |= {213, 214, 215}
    n56 = get(56); n56.clear(); n56.update({'op':'where','args':[54,25,0],'_id':56}); dead.add(55)
    redirect(113, 3); dead.add(113)
    S3 = [[[1.0,1.0],[1.0,-1.0],[-1.0,1.0],[-1.0,-1.0]], [[-1.0,-1.0],[-1.0,1.0],[1.0,-1.0],[1.0,1.0]]]
    insert_before(275, [{'op':'const','dtype':'float','value':S3,'_id':'S3'}])
    get(275)['args'] = [271, 'S3']; dead |= {273, 274}
    insert_before(379, [
        {'op':'slice','args':[271],'index':[0,{'start':0,'step':None,'stop':2},None],'_id':'A'},
        {'op':'le','args':['A',0],'_id':'B'},
        {'op':'all','args':['B'],'axis':None,'_id':'D'},
        {'op':'cond','args':['D',359,369],'_id':'E'}])
    get(379)['args'] = [289,'E',378]
    if drop_helping:
        insert_before(109, [{'op':'neg','args':[96],'_id':'h1'},{'op':'where','args':[87,'h1',108],'_id':'h2'}])
        redirect(108, 'h2', only={124,144,164,184})
    if drop4:
        redirect(200, 182); dead |= {180,181} | set(range(183,201))
    if dirs is not None:
        a = np.deg2rad(np.array(dirs, float)); get(259)['value'] = np.stack([np.cos(a), np.sin(a)]).tolist()
    if scalar_tree:
        quads = [(33,'gt',{294:1,295:2,296:3,302:0},299), (282,'lt',{309:1,310:2,311:3,317:0},314),
                 (282,'lt',{325:1,326:2,327:3,333:0},330), (33,'gt',{340:1,341:2,342:3,348:0},345)]
        for q,(src,op,mp,first) in enumerate(quads):
            new=[]
            for old,j in mp.items():
                new += [{'op':'slice','args':[src],'index':[q,j],'_id':f't{q}{j}'},
                        {'op':op,'args':[291,f't{q}{j}'],'_id':f'c{q}{j}'}]
            insert_before(first, new)
            for old,j in mp.items(): redirect(old, f'c{q}{j}'); dead.add(old)
        dead |= {292,293,307,308,323,324,338,339}
    def fbnodes(tag, Mnode):
        return [{'op':'matmul','args':[Mnode,283],'_id':tag+'1'},{'op':'maximum','args':[tag+'1',0],'_id':tag+'2'},
                {'op':'matmul','args':[10,tag+'2'],'_id':tag+'3'},{'op':'argmax','args':[tag+'3'],'axis':None,'_id':'FB'+tag}]
    if fb_mode=='quad':
        insert_before(354, fbnodes('o',306)+fbnodes('p',321)+fbnodes('q',337)+fbnodes('r',352))
        m = {364:'FBo',383:'FBo',368:'FBp',387:'FBp',373:'FBq',392:'FBq',377:'FBr',396:'FBr'}
        dead |= {353, 322}
    for i,t in m.items(): get(i)['args'] = [a if a!=358 else t for a in get(i)['args']]
    dead |= {354,355,356,357,358}
    L = [n for n in L if n['_id'] not in dead]
    remap = {n['_id']:i for i,n in enumerate(L)}
    out = []
    for n in L:
        mm = {k:v for k,v in n.items() if k!='_id'}
        if 'args' in mm: mm['args'] = [remap[a] for a in mm['args']]
        out.append(mm)
    return {'format': base['format'], 'nodes': out, 'predict': remap[399], 'rule': None}
for dh in (False, True):
    for d4 in (True, False):
        ent = surgery4(entries['best'], drop_helping=dh, drop4=d4)
        m = measure(ent); print("drop_helping", dh, "drop4", d4, len(ent['nodes']), round(m['reward'],4), m['predict_ops'], m['build_ops'])
        if dh and d4: save_entry('skip_v5', ent)
