
import numpy as np
base = entries['lean_v2']
s = lv1.show(base).split('\n')
print('\n'.join(s[222:250]))
