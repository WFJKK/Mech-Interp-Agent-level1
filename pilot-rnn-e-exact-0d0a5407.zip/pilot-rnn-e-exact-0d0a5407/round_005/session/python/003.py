
import inspect
print(inspect.signature(lv1.show)); print(inspect.getsource(lv1.show)[:1500])
print(inspect.signature(lv1.Evaluator.__init__))
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
print(inspect.signature(lv1.Graph.load))
