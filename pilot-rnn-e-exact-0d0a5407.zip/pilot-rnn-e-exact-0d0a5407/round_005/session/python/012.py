
import numpy as np
e = entries['best']
g, pred, rule = lv1.Graph.load(e, weights, 3, real=True)
nodes = e['nodes']
dep=[]
for n in nodes: dep.append(n['op'] in ('token','tokens') or any(dep[a] for a in n.get('args',[])))
costs=[]
store={}
for i,n in enumerate(nodes):
    if dep[i] or n['op']=='cond': costs.append(0); continue
    vals=[g.values[a] for a in n.get('args',[])]
    try:
        v,c = lv1.apply(n, vals, None, g.weights, store)
    except Exception as ex:
        c=0; print('err',i,ex)
    costs.append(int(c))
costs=np.array(costs)
print("total build", costs.sum())
order=np.argsort(-costs)[:40]
s = lv1.show(e).split('\n')
for i in order: print(costs[i], s[i][:90])
# block sums
blocks={'lp(191-243)':(191,244),'greedy(108-190)':(108,191),'margins(53-107)':(53,108),'sectors(10-52)':(10,53)}
for k,(a,b) in blocks.items(): print(k, costs[a:b].sum())
