
import numpy as np, time
base = entries['lean_v1']
def rebuild(base, patches, weights):
    g = lv1.Graph(weights, 3, real=True); ids = {}
    N = lambda j: lv1.Expr(g, ids[j])
    for i, node in enumerate(base['nodes']):
        if i in patches:
            ids[i] = patches[i](g, N).id; continue
        node = dict(node)
        args = [N(a) for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ids[i] = g._add(node, args).id
    return g, ids, N
g, ids, N = rebuild(base, {176: lambda g,N: N(159)}, weights)
ent2 = g.entry(predict=N(399))
print("nodes", len(ent2['nodes']))
m = measure(ent2); print({k:m[k] for k in ('predict_ops','build_ops','cost','reward')})
# compare average predict ops on random weights: lean_v1 vs no-pass3
def net(x, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.maximum(w*x[:,0:1],0)
    for tt in (1,2):
        h = np.maximum(w*x[:,tt:tt+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(99); tot=[0,0]; errs=0
for trial in range(24):
    s = rng.uniform(0.3, 2.0)
    W = {'input': rng.standard_normal((4,1))*s, 'recurrent': rng.standard_normal((4,4))*s, 'readout': rng.standard_normal((3,4))*s}
    X = rng.standard_normal((300,3)); y = net(X, W)
    for k, en in enumerate((base, ent2)):
        ev = lv1.Evaluator(en, W, 3)
        r = [ev.run(X[i]) for i in range(len(X))]
        tot[k] += sum(x[3] for x in r)/len(X)
        if k==1: errs += sum(1 for i,x in enumerate(r) if x[1]!=y[i])
print("avg ops lean_v1 %.2f  nopass3 %.2f  errs %d" % (tot[0]/24, tot[1]/24, errs))
save_entry('nopass3', ent2)
