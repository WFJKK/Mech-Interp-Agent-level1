
import numpy as np, json, time
base = entries['best']
gold, _, _ = lv1.Graph.load(base, weights, 3, real=True)
def rebuild(base, patches, weights):
    g = lv1.Graph(weights, 3, real=True); ids = {}
    N = lambda j: lv1.Expr(g, ids[j])
    for i, node in enumerate(base['nodes']):
        if i in patches:
            ids[i] = patches[i](g, N).id; continue
        node = dict(node)
        args = [N(a) for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ids[i] = g._add(node, args).id
    return g, ids, N
def mk_common(g, N):
    if hasattr(g, '_mc'): return g._mc
    gam, rgam, beta, rbeta, gplus, Delta = N(53), N(54), N(55), N(63), N(62), N(77)
    ones = N(85); ones2 = g.const(np.ones((2,1,1,1,1,1)))
    Ah = lv1.minimum(Delta, N(0)); Al = lv1.where(N(80), Delta, N(0)); Alo = lv1.where(N(84), Delta, N(0)); Al2 = lv1.where(N(82), Delta, N(0))
    C1 = Al2 - Al
    bb = beta * ones
    G = lv1.concat([bb, gam * ones2], axis=5)
    rG = lv1.concat([rbeta * ones, rgam * ones2], axis=5)
    Gt = lv1.transpose(G, [0,1,2,3,5,4]); rGt = lv1.transpose(rG, [0,1,2,3,5,4])
    m1 = rGt @ Ah; m2 = Gt @ Al
    init = (m1 + m2).reshape([2,4,5,2,3])
    lo = (m1 + Gt @ Alo).reshape([2,4,5,2,3])
    dg = C1 * gam + Ah * (gplus - rgam)
    flip = lv1.concat([C1 * bb, dg], axis=5)
    g._mc = (init, flip, lo); return g._mc
def readout(hid):
    def f(g, N):
        R = N(9); D = R[1:3] - R[0:1]
        return lv1.argmax(lv1.concat([N(0).reshape([1]), D @ N(hid)], axis=0))
    return f
def msum(j): return lambda g,N: N(j) @ g.const(np.ones((2,1)))
patches = {
    99: lambda g,N: mk_common(g,N)[0], 103: lambda g,N: mk_common(g,N)[1], 106: lambda g,N: mk_common(g,N)[2],
    30: lambda g,N: N(28) < N(26),
    121: lambda g,N: N(120),
    234: lambda g,N: lv1.maximum(N(221).sum(axis=3), N(0)),
    117: msum(116), 131: msum(130), 151: msum(150), 171: msum(170),
    133: lambda g,N: N(132), 153: lambda g,N: N(152), 173: lambda g,N: N(172),
    369: lambda g,N: N(367).max(axis=None) <= N(0),
    334: readout(332), 338: readout(336), 342: readout(340), 346: readout(344),
}
g, ids, N = rebuild(base, patches, weights)
for j in (99,103,106,174,185,190,243,246,252,369):
    a, b = gold.values[j], g.values[ids[j]]
    print(j, (np.abs(a.astype(float)-b.astype(float)).max()) if a.shape==b.shape else 'shape!', end=' | ')
ent = g.entry(predict=N(391))
print("\nnodes", len(ent['nodes']))
m = measure(ent); print(m)
save_entry('lean_v1', ent)
