
import numpy as np
e = entries['lean_v1']
g, pred, rule = lv1.Graph.load(e, weights, 3, real=True)
nodes = e['nodes']
dep=[]
for n in nodes: dep.append(n['op'] in ('token','tokens') or any(dep[a] for a in n.get('args',[])))
costs=[]; store={}
for i,n in enumerate(nodes):
    if dep[i] or n['op']=='cond': costs.append(0); continue
    vals=[g.values[a] for a in n.get('args',[])]
    v,c = lv1.apply(n, vals, None, g.weights, store); costs.append(int(c))
costs=np.array(costs); print("total", costs.sum(), "nodes", len(nodes), "runtime nodes", sum(dep))
s = lv1.show(e).split('\n')
order=np.argsort(-costs)[:45]
for i in order: print(costs[i], s[i][:80])
