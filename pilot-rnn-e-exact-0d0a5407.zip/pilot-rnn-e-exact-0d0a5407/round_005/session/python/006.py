
s = lv1.show(entries['best']).split('\n')
print('\n'.join(s[240:300]))
