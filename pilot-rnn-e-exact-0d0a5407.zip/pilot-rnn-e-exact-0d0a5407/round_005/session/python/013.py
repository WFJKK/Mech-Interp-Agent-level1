
import numpy as np, json
e = entries['best']
g, pred, rule = lv1.Graph.load(e, weights, 3, real=True)
N = lambda i: lv1.Expr(g, i)
R = N(9)
D = R[1:3] - R[0:1]
zero1 = N(0).reshape([1])
print(D.shape, zero1.shape)
subst = {}
for q, hid in enumerate([332, 336, 340, 344]):
    h = N(hid)
    d = D @ h
    l = lv1.concat(zero1, d, axis=0)
    out = l.argmax(axis=None)
    subst[[334,338,342,346][q]] = out.id
# re-emit tail nodes 347..391 with substitution
nodes = e['nodes']
newid = {}
for i in range(347, 392):
    node = dict(nodes[i])
    args = [lv1.Expr(g, newid.get(a, subst.get(a, a))) for a in node.get('args', [])]
    if 'args' in node: node['args'] = [a.id for a in args]
    ex = g._add(node, args)
    newid[i] = ex.id
new_pred = lv1.Expr(g, newid[391])
ent = g.entry(predict=new_pred)
print(len(ent['nodes']))
m = measure(ent); print(m)
save_entry('margin_v1', ent)
