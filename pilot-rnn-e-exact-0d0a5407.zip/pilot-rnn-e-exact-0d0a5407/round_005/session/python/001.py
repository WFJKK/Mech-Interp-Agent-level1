
import json
print(info)
print({k:v.shape for k,v in weights.items()})
print(list(entries.keys()))
e = entries['best']
print(type(e), len(e['nodes']) if isinstance(e, dict) and 'nodes' in e else None)
print(list(e.keys()) if isinstance(e, dict) else None)
m = measure(e)
print(m)
