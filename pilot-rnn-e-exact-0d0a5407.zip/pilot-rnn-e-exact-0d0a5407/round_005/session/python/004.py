
s = lv1.show(entries['best']).split('\n')
# print the runtime part: nodes referencing tokens and downstream. Find tokens node
print('\n'.join(s[300:]))
