
import numpy as np, time
ent = entries['lean_v1']; old = entries['best']
def net(x, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.maximum(w*x[:,0:1],0)
    for tt in (1,2):
        h = np.maximum(w*x[:,tt:tt+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
def check(ent, W, X):
    ev = lv1.Evaluator(ent, W, 3)
    y = net(X, W); errs=0; ops=0
    for i in range(len(X)):
        inside, ans, cr, cp = ev.run(X[i]); ops += cp
        if (not inside) or ans != y[i]: errs += 1
    return errs, ops/len(X), ev.build_cost
rng = np.random.default_rng(777)
t0=time.time(); tot=0; mism=0
for trial in range(64):
    s = rng.uniform(0.3, 2.0)
    W = {'input': rng.standard_normal((4,1))*s, 'recurrent': rng.standard_normal((4,4))*s, 'readout': rng.standard_normal((3,4))*s}
    kind = trial % 10
    if kind==1: W['input'] = np.abs(W['input'])
    if kind==2: W['input'] = -np.abs(W['input'])
    if kind==3: W['input'][rng.integers(4),0] = 0.0
    if kind==4: W['readout'][1] = W['readout'][0]
    if kind==5: W['readout'][2] = 0.0
    if kind==6: W['recurrent'] = np.eye(4)*0.8
    if kind==7: W['readout'][2] = W['readout'][1]
    if kind==8: W['recurrent'] = np.zeros((4,4))
    if kind==9: W['recurrent'][rng.integers(4)] = 0.0
    X = rng.standard_normal((500,3)) * rng.choice([0.01, 1.0, 100.0])
    errs, ops, b = check(ent, W, X); tot+=errs
    # compare the cap tables with the old entry on these weights
    g1,_,_ = lv1.Graph.load(ent, W, 3, real=True); g0,_,_ = lv1.Graph.load(old, W, 3, real=True)
    # find n246-equivalent: compare predictions on a sample instead (cheap): old vs new ops
    ev0 = lv1.Evaluator(old, W, 3); ops0 = sum(ev0.run(X[i])[3] for i in range(100))/100
    print(trial, kind, errs, round(ops,1), round(ops0,1), b, end=' | ')
print("\ntotal errs", tot, "time", time.time()-t0)
