
import numpy as np
e = entries['best']
g, pred, rule = lv1.Graph.load(e, weights, 3, real=True)
val = lambda i: g.values[i]
V = val(190)            # [2,4,5,2]
E = val(45)             # [4,5,2,2]  (xy, edge)
S = val(245)            # signs
TLP = val(243)          # [2,4,2]
print(V.shape, E.shape, S.shape, TLP.shape)
print("S=",S.tolist())
c0,s0 = E[:,:,0,0], E[:,:,1,0]
c1,s1 = E[:,:,0,1], E[:,:,1,1]
det = c0*s1 - c1*s0     # [4,5]
V0, V1 = V[...,0], V[...,1]   # [2,4,5]
T0 = (V0*s1 - V1*s0)/det
T1 = (c0*V1 - c1*V0)/det
Tsec = np.stack([T0,T1],-1)   # [2,4,5,2]
ok = np.abs(det) > 1e-6
print("det", det)
print("Tsec", np.round(Tsec,3))
Tmax = np.where(ok[None,:,:,None], Tsec, -1e9).max(axis=2)
print("TLP", np.round(TLP,3)); print("Tmax", np.round(Tmax,3))
# sample catch rates
rng = np.random.default_rng(0)
X = rng.standard_normal((200000,3))
s2 = (X[:,2] <= 0).astype(int)
q = (X[:,0] <= 0).astype(int)*2 + (X[:,1] <= 0).astype(int)
u = np.abs(X[:,:2])
t = np.abs(X[:,2])
def catch(T):  # T [2,4,2] in abs coords
    Tq = T[s2, q]
    return (t > (Tq*u).sum(1))
# sector index per input
th = val(28)   # [4,4] sorted thresholds
r = u[:,1]/u[:,0]
sec = (r[:,None] > th[q]).sum(1)
cL = catch(TLP*0 + TLP) ; 
# TLP is sign-adjusted? check: n246 = n243*n245 -> raw. So n243 in abs coords. good
cM = catch(Tmax)
Ts = Tsec[s2,q,sec]
cS = (t > (Ts*u).sum(1)) & ok[q,sec]
print("catch LP", cL.mean(), "max", cM.mean(), "sector", cS.mean(), "LP|sec", (cL|cS).mean(), "max|sec", (cM|cS).mean())
for a in range(2):
    for b in range(4):
        m = (s2==a)&(q==b)
        print(a,b, round(cL[m].mean(),3), round(cM[m].mean(),3), round(cS[m].mean(),3))
# verify sector cap exactness vs network on sample
outs = []
def net(x):
    w = weights['input'][:,0]; rec = weights['recurrent']; R = weights['readout']
    h = np.maximum(w*x[:,0:1],0)
    for tt in (1,2):
        h = np.maximum(w*x[:,tt:tt+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
y = net(X)
o = val(66)
print("o", o, "errors sector cap:", (y[cS] != o[s2[cS]]).sum(), "errors max cap:", (y[cM] != o[s2[cM]]).sum())
