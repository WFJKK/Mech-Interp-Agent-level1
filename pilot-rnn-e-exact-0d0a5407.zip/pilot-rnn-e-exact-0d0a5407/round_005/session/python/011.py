
import inspect
src = inspect.getsource(lv1.Evaluator)
print(src[:5000])
