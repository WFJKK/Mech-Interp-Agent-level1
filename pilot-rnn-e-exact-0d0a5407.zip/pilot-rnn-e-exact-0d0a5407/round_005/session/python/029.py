
import numpy as np, time
base = entries['lean_v2']
gold, _, _ = lv1.Graph.load(base, weights, 3, real=True)
def rebuild(base, patches, weights):
    g = lv1.Graph(weights, 3, real=True); ids = {}
    N = lambda j: lv1.Expr(g, ids[j])
    for i, node in enumerate(base['nodes']):
        if i in patches:
            ids[i] = patches[i](g, N).id; continue
        node = dict(node)
        args = [N(a) for a in node.get('args', [])]
        if 'args' in node: node['args'] = [a.id for a in args]
        ids[i] = g._add(node, args).id
    return g, ids, N
def sel(g, N):
    C = N(223).reshape([120, 2])
    idx = N(237).reshape([8])
    base_idx = g.arange(120)[0:120:15]
    print("base_idx", base_idx.value, base_idx.shape)
    fid = idx + base_idx
    return lv1.take(C, fid, axis=0).reshape([2, 4, 2])
patches = {243: sel}
g, ids, N = rebuild(base, patches, weights)
for j in (243, 246, 248):
    a, b = gold.values[j], g.values[ids[j]]
    print(j, a.shape, (np.abs(a.astype(float)-b.astype(float)).max()) if a.shape==b.shape else 'shape!', end=' | ')
ent = g.entry(predict=N(399))
print("\nnodes", len(ent['nodes']))
m = measure(ent); print({k:m[k] for k in ('predict_ops','build_ops','cost','reward')})
save_entry('lean_v3', ent)
def net(x, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.maximum(w*x[:,0:1],0)
    for tt in (1,2):
        h = np.maximum(w*x[:,tt:tt+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(31337); errs=0; n=0; maxd=0
for trial in range(50):
    sc = rng.uniform(0.3, 2.0)
    W = {'input': rng.standard_normal((4,1))*sc, 'recurrent': rng.standard_normal((4,4))*sc, 'readout': rng.standard_normal((3,4))*sc}
    kind = trial % 10
    if kind==1: W['input'] = np.abs(W['input'])
    if kind==2: W['input'] = -np.abs(W['input'])
    if kind==3: W['input'][rng.integers(4),0] = 0.0
    if kind==4: W['readout'][1] = W['readout'][0]
    if kind==5: W['readout'][2] = 0.0
    if kind==6: W['recurrent'] = np.eye(4)*0.8
    if kind==7: W['readout'][2] = W['readout'][1]
    if kind==8: W['recurrent'] = np.zeros((4,4))
    if kind==9: W['recurrent'][rng.integers(4)] = 0.0
    # table equality old vs new on these weights
    g0,_,_ = lv1.Graph.load(base, W, 3, real=True); g1,_,_ = lv1.Graph.load(ent, W, 3, real=True)
    X = rng.standard_normal((400,3)) * rng.choice([0.01, 1.0, 100.0]); y = net(X, W)
    ev = lv1.Evaluator(ent, W, 3)
    for i in range(len(X)):
        inside, ans, cr, cp = ev.run(X[i]); n+=1
        if (not inside) or ans != y[i]: errs += 1
print("errs", errs, "of", n)
