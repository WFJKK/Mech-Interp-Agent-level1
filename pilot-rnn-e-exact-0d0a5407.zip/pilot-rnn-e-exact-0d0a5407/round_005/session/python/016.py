
import numpy as np, time
ent = entries['margin_v1']
def net(x, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.maximum(w*x[:,0:1],0)
    for tt in (1,2):
        h = np.maximum(w*x[:,tt:tt+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
def check(ent, W, X):
    ev = lv1.Evaluator(ent, W, 3)
    y = net(X, W); errs=0; ops=0
    for i in range(len(X)):
        inside, ans, cr, cp = ev.run(X[i]); ops += cp
        if (not inside) or ans != y[i]: errs += 1
    return errs, ops/len(X), ev.build_cost
rng = np.random.default_rng(123)
t0=time.time(); tot=0
for trial in range(40):
    s = rng.uniform(0.3, 1.5)
    W = {'input': rng.standard_normal((4,1))*s, 'recurrent': rng.standard_normal((4,4))*s, 'readout': rng.standard_normal((3,4))*s}
    kind = trial % 8
    if kind==1: W['input'] = np.abs(W['input'])
    if kind==2: W['input'] = -np.abs(W['input'])
    if kind==3: W['input'][1,0] = 0.0
    if kind==4: W['readout'][1] = W['readout'][0]
    if kind==5: W['readout'][2] = 0.0
    if kind==6: W['recurrent'] = np.eye(4)*0.8
    if kind==7: W['readout'][2] = W['readout'][1]
    X = rng.standard_normal((300,3))
    errs, ops, b = check(ent, W, X); tot+=errs
    print(trial, kind, errs, round(ops,1), b, end=' | ')
print("\ntotal errs", tot, "time", time.time()-t0)
