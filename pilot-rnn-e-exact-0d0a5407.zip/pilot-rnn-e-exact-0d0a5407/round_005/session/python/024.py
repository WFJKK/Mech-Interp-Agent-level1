
import numpy as np, time
base = entries['lean_v1']
s = lv1.show(base).split('\n')
# find pass-3 result node (where(.., n169, n156) analog) : print nodes 150-180 to locate
print('\n'.join(s[150:180]))
