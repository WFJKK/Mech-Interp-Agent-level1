
import inspect
print(inspect.signature(lv1.concat), inspect.signature(lv1.stack), inspect.signature(lv1.argmax))
