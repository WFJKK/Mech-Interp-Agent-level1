
import json
e = entries['best']
print(e['format'], e['predict'], e['rule'])
print([x for x in dir(lv1) if not x.startswith('_')])
nodes = e['nodes']
print(nodes[0]); print(nodes[1])
from collections import Counter
print(Counter(n.get('op') for n in nodes))
