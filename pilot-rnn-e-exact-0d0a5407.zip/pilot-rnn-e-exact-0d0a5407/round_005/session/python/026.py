
import numpy as np
base = entries['lean_v1']
s = lv1.show(base).split('\n')
print('\n'.join(s[74:92])); print(s[104:112])
