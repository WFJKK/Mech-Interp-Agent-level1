
print('\n'.join(s[240:300]))
