
import numpy as np, time
ent = entries['lean_v3']
def net(x, W):
    w = W['input'][:,0]; rec = W['recurrent']; R = W['readout']
    h = np.maximum(w*x[:,0:1],0)
    for tt in (1,2):
        h = np.maximum(w*x[:,tt:tt+1] + h@rec.T, 0)
    return (h@R.T).argmax(1)
rng = np.random.default_rng(4242); errs=0; n=0; t0=time.time()
for trial in range(60):
    sc = rng.choice([0.01, 0.1, 1.0, 5.0, 20.0])
    W = {'input': rng.standard_normal((4,1))*sc, 'recurrent': rng.standard_normal((4,4))*rng.uniform(0.2,3), 'readout': rng.standard_normal((3,4))*sc}
    kind = trial % 12
    if kind==1: W['input'] = np.abs(W['input'])
    if kind==2: W['input'] = -np.abs(W['input'])
    if kind==3: W['input'][rng.integers(4),0] = 0.0
    if kind==4: W['readout'][1] = W['readout'][0]
    if kind==5: W['readout'][2] = 0.0
    if kind==6: W['recurrent'] = -np.eye(4)*1.5
    if kind==7: W['readout'][2] = W['readout'][1]
    if kind==8: W['recurrent'][:, rng.integers(4)] = 0.0
    if kind==9: W['recurrent'] = np.abs(W['recurrent'])
    if kind==10: W['recurrent'] = -np.abs(W['recurrent'])
    if kind==11: W['readout'] = np.round(W['readout'])
    X = rng.standard_normal((500,3)); y = net(X, W)
    ev = lv1.Evaluator(ent, W, 3)
    for i in range(len(X)):
        inside, ans, cr, cp = ev.run(X[i]); n+=1
        if (not inside) or ans != y[i]: errs += 1; print("ERR", trial, kind, X[i], ans, y[i])
print("errs", errs, "of", n, "time", round(time.time()-t0,1))
# also this network, 60k inputs
X = rng.standard_normal((60000,3)); y = net(X, weights); ev = lv1.Evaluator(ent, weights, 3)
e2 = sum(1 for i in range(len(X)) if ev.run(X[i])[1] != y[i]); print("this net errs", e2)
