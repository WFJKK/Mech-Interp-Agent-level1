# Run pilot-rnn-e-exact-0d0a5407

- Model models/rnn-e, rounds on rnn-e-s0, seed check on rnn-e-s4.
- Agent: claude-fable-5-1 at effort high, through the claude_code backend.
- Data set: real-valued inputs, 16,384 drawn afresh for each scoring. One forward pass: 78 operations (prices-v1).
- Reward: r_alpha, alpha = 10.
- Sandbox: seatbelt.
- The rounds ended: rounds_max (5) reached.

## The locked entry

Submission r5s2 (saved as `lean_v1`), 400 nodes, 204 numbers in constants, sha256 `2e0129d0a51996a6`.

| Network | Reward | Coverage | Fidelity | Cost | Fidelity claimed |
| --- | --- | --- | --- | --- | --- |
| rnn-e-s0 (the rounds) | 0.7710 | 1.0000 | 1.00000 | 0.2267 | 1.00000 |
| rnn-e-s0 (measured again, on a fresh sample) | 0.7700 | 1.0000 | 1.00000 | 0.2277 | 1.00000 |
| rnn-e-s4 (the seed check) | 0.7232 | 1.0000 | 1.00000 | 0.2745 | 1.00000 |

The first row is the best of several scorings, each on its own sample, so it leans high; the second row is one more scoring of the same entry.

```
n0 = const(dtype="float", value=0.0)
n1 = const(dtype="float", value=1.0)
n2 = const(dtype="float", value=1000000000.0)
n3 = const(dtype="float", value=-1000000000.0)
n4 = const(dtype="float", value=1e-09)
n5 = const(dtype="float", value=-3.0)
n6 = weight(name="input")
n7 = slice(n6, index=[null, 0])
n8 = weight(name="recurrent")
n9 = weight(name="readout")
n10 = const(dtype="float", value=[[1.0], [-1.0]])
n11 = mul(n10, n7)
n12 = maximum(n11, n0)
n13 = transpose(n8)
n14 = matmul(n12, n13)
n15 = const(dtype="int", value=[0, 0, 1, 1])
n16 = take(n14, n15, axis=0)
n17 = const(dtype="float", value=[[1.0], [-1.0], [1.0], [-1.0]])
n18 = mul(n17, n7)
n19 = stack(n16, n18, axis=2)
n20 = reshape(n19, shape=[4, 1, 4, 2])
n21 = mul(n16, n18)
n22 = lt(n21, n0)
n23 = neg(n16)
n24 = where(n22, n18, n1)
n25 = div(n23, n24)
n26 = const(dtype="float", value=1e+18)
n27 = where(n22, n25, n26)
n28 = sort(n27, axis=1)
n29 = lt(n28, n26)
n30 = reshape(n29, shape=[4, 4, 1])
n31 = mul(n28, n28)
n32 = add(n1, n31)
n33 = sqrt(n32)
n34 = div(n1, n33)
n35 = div(n28, n33)
n36 = stack(n34, n35, axis=2)
n37 = const(dtype="float", value=[0.0, 1.0])
n38 = where(n30, n36, n37)
n39 = const(dtype="float", value=[[[1.0, 0.0]], [[1.0, 0.0]], [[1.0, 0.0]], [[1.0, 0.0]]])
n40 = const(dtype="float", value=[[[0.0, 1.0]], [[0.0, 1.0]], [[0.0, 1.0]], [[0.0, 1.0]]])
n41 = concat(n39, n38, n40, axis=1)
n42 = slice(n41, index=[null, {"start": 0, "step": null, "stop": 5}, null])
n43 = slice(n41, index=[null, {"start": 1, "step": null, "stop": 6}, null])
n44 = stack(n42, n43, axis=3)
n45 = add(n42, n43)
n46 = reshape(n45, shape=[4, 5, 2, 1])
n47 = matmul(n20, n46)
n48 = gt(n47, n0)
n49 = where(n48, n20, n0)
n50 = matmul(n8, n49)
n51 = matmul(n50, n44)
n52 = reshape(n51, shape=[1, 4, 5, 1, 4, 2])
n53 = maximum(n52, n0)
n54 = reshape(n11, shape=[2, 1, 1, 1, 4, 1])
n55 = ne(n54, n0)
n56 = neg(n52)
n57 = where(n55, n54, n1)
n58 = div(n56, n57)
n59 = where(n55, n58, n2)
n60 = gt(n54, n0)
n61 = where(n60, n52, n0)
n62 = maximum(n54, n0)
n63 = transpose(n9)
n64 = matmul(n12, n63)
n65 = argmax(n64, axis=1)
n66 = concat(n9, n9, axis=0)
n67 = take(n9, n65, axis=0)
n68 = reshape(n67, shape=[2, 1, 4])
n69 = const(dtype="int", value=1)
n70 = add(n65, n69)
n71 = take(n66, n70, axis=0)
n72 = add(n70, n69)
n73 = take(n66, n72, axis=0)
n74 = stack(n71, n73, axis=1)
n75 = sub(n68, n74)
n76 = reshape(n75, shape=[2, 1, 1, 2, 4, 1])
n77 = gt(n76, n0)
n78 = lt(n76, n0)
n79 = and(n77, n60)
n80 = not(n79)
n81 = and(n77, n80)
n82 = lt(n54, n0)
n83 = and(n77, n82)
n84 = const(dtype="float", value=[[[[[[1.0]]], [[[1.0]]], [[[1.0]]], [[[1.0]]], [[[1.0]]]]...)
n85 = const(dtype="float", value=[[[[[[1.0]]]]], [[[[[1.0]]]]]])
n86 = minimum(n76, n0)
n87 = where(n79, n76, n0)
n88 = where(n83, n76, n0)
n89 = where(n81, n76, n0)
n90 = sub(n89, n87)
n91 = mul(n54, n84)
n92 = mul(n52, n85)
n93 = concat(n91, n92, axis=5)
n94 = mul(n62, n84)
n95 = mul(n53, n85)
n96 = concat(n94, n95, axis=5)
n97 = transpose(n93, perm=[0, 1, 2, 3, 5, 4])
n98 = transpose(n96, perm=[0, 1, 2, 3, 5, 4])
n99 = matmul(n98, n86)
n100 = matmul(n97, n87)
n101 = add(n99, n100)
n102 = reshape(n101, shape=[2, 4, 5, 2, 3])
n103 = matmul(n97, n88)
n104 = add(n99, n103)
n105 = reshape(n104, shape=[2, 4, 5, 2, 3])
n106 = mul(n90, n52)
n107 = sub(n61, n53)
n108 = mul(n86, n107)
n109 = add(n106, n108)
n110 = mul(n90, n91)
n111 = concat(n110, n109, axis=5)
n112 = where(n78, n59, n3)
n113 = slice(n102, index=[null, null, null, null, {"start": 0, "step": null, "stop": 1}])
n114 = slice(n102, index=[null, null, null, null, {"start": 1, "step": null, "stop": 3}])
n115 = gt(n113, n4)
n116 = neg(n114)
n117 = where(n115, n113, n1)
n118 = div(n116, n117)
n119 = maximum(n118, n3)
n120 = where(n115, n119, n2)
n121 = maximum(n120, n0)
n122 = const(dtype="float", value=[[1.0], [1.0]])
n123 = matmul(n121, n122)
n124 = slice(n111, index=[null, null, null, null, 0, null])
n125 = add(n102, n124)
n126 = slice(n112, index=[null, null, null, null, 0, null])
n127 = slice(n125, index=[null, null, null, null, {"start": 0, "step": null, "stop": 1}])
n128 = slice(n125, index=[null, null, null, null, {"start": 1, "step": null, "stop": 3}])
n129 = gt(n127, n4)
n130 = neg(n128)
n131 = where(n129, n127, n1)
n132 = div(n130, n131)
n133 = maximum(n132, n126)
n134 = where(n129, n133, n2)
n135 = maximum(n134, n0)
n136 = matmul(n135, n122)
n137 = lt(n136, n123)
n138 = where(n137, n125, n102)
n139 = where(n137, n126, n3)
n140 = where(n137, n134, n120)
n141 = minimum(n136, n123)
n142 = slice(n111, index=[null, null, null, null, 1, null])
n143 = add(n138, n142)
n144 = slice(n112, index=[null, null, null, null, 1, null])
n145 = maximum(n139, n144)
n146 = slice(n143, index=[null, null, null, null, {"start": 0, "step": null, "stop": 1}])
n147 = slice(n143, index=[null, null, null, null, {"start": 1, "step": null, "stop": 3}])
n148 = gt(n146, n4)
n149 = neg(n147)
n150 = where(n148, n146, n1)
n151 = div(n149, n150)
n152 = maximum(n151, n145)
n153 = where(n148, n152, n2)
n154 = maximum(n153, n0)
n155 = matmul(n154, n122)
n156 = lt(n155, n141)
n157 = where(n156, n143, n138)
n158 = where(n156, n145, n139)
n159 = where(n156, n153, n140)
n160 = minimum(n155, n141)
n161 = slice(n111, index=[null, null, null, null, 2, null])
n162 = add(n157, n161)
n163 = slice(n112, index=[null, null, null, null, 2, null])
n164 = maximum(n158, n163)
n165 = slice(n162, index=[null, null, null, null, {"start": 0, "step": null, "stop": 1}])
n166 = slice(n162, index=[null, null, null, null, {"start": 1, "step": null, "stop": 3}])
n167 = gt(n165, n4)
n168 = neg(n166)
n169 = where(n167, n165, n1)
n170 = div(n168, n169)
n171 = maximum(n170, n164)
n172 = where(n167, n171, n2)
n173 = maximum(n172, n0)
n174 = matmul(n173, n122)
n175 = lt(n174, n160)
n176 = where(n175, n172, n159)
n177 = slice(n105, index=[null, null, null, null, {"start": 0, "step": null, "stop": 1}])
n178 = slice(n105, index=[null, null, null, null, {"start": 1, "step": null, "stop": 3}])
n179 = neg(n4)
n180 = lt(n177, n179)
n181 = mul(n176, n177)
n182 = add(n178, n181)
n183 = ge(n182, n0)
n184 = all(n183, axis=4)
n185 = reshape(n184, shape=[2, 4, 5, 2, 1])
n186 = and(n180, n185)
n187 = where(n186, n5, n176)
n188 = const(dtype="float", value=1e-07)
n189 = const(dtype="float", value=1.0000001)
n190 = mul(n187, n189)
n191 = add(n190, n188)
n192 = max(n191, axis=3)
n193 = const(dtype="float", value=[[[-3.0], [-3.0], [-3.0], [-3.0]], [[-3.0], [-3.0], [-3.0...)
n194 = slice(n192, index=[null, null, null, 0])
n195 = concat(n194, n193, axis=2)
n196 = slice(n192, index=[null, null, null, 1])
n197 = concat(n193, n196, axis=2)
n198 = maximum(n195, n197)
n199 = const(dtype="int", value=[0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 3, 3, 4])
n200 = const(dtype="int", value=[1, 2, 3, 4, 5, 2, 3, 4, 5, 3, 4, 5, 4, 5, 5])
n201 = take(n41, n199, axis=1)
n202 = take(n41, n200, axis=1)
n203 = take(n198, n199, axis=2)
n204 = take(n198, n200, axis=2)
n205 = slice(n201, index=[null, null, 0])
n206 = slice(n201, index=[null, null, 1])
n207 = slice(n202, index=[null, null, 0])
n208 = slice(n202, index=[null, null, 1])
n209 = mul(n205, n208)
n210 = mul(n206, n207)
n211 = sub(n209, n210)
n212 = abs(n211)
n213 = gt(n212, n4)
n214 = where(n213, n211, n1)
n215 = mul(n203, n208)
n216 = mul(n204, n206)
n217 = sub(n215, n216)
n218 = div(n217, n214)
n219 = mul(n205, n204)
n220 = mul(n207, n203)
n221 = sub(n219, n220)
n222 = div(n221, n214)
n223 = stack(n218, n222, axis=3)
n224 = transpose(n41, perm=[0, 2, 1])
n225 = matmul(n223, n224)
n226 = abs(n198)
n227 = maximum(n226, n1)
n228 = mul(n4, n227)
n229 = sub(n198, n228)
n230 = reshape(n229, shape=[2, 4, 1, 6])
n231 = ge(n225, n230)
n232 = all(n231, axis=3)
n233 = sum(n223, axis=3)
n234 = maximum(n233, n0)
n235 = where(n232, n234, n26)
n236 = arange(n=15)
n237 = argmin(n235, axis=2)
n238 = reshape(n237, shape=[2, 4, 1])
n239 = eq(n236, n238)
n240 = cast(n239, dtype="float")
n241 = reshape(n240, shape=[2, 4, 15, 1])
n242 = mul(n223, n241)
n243 = sum(n242, axis=2)
n244 = const(dtype="float", value=[[1.0, 1.0], [1.0, -1.0], [-1.0, 1.0], [-1.0, -1.0]])
n245 = const(dtype="float", value=[[[1.0, 1.0], [1.0, -1.0], [-1.0, 1.0], [-1.0, -1.0]], [[...)
n246 = mul(n243, n245)
n247 = reshape(n244, shape=[4, 1, 1, 2])
n248 = mul(n50, n247)
n249 = reshape(n7, shape=[1, 1, 4, 1])
n250 = const(dtype="float", value=[[[[1.0], [1.0], [1.0], [1.0]], [[1.0], [1.0], [1.0], [1....)
n251 = mul(n249, n250)
n252 = concat(n248, n251, axis=3)
n253 = neg(n28)
n254 = tokens()
n255 = slice(n254, index=[0])
n256 = slice(n254, index=[1])
n257 = slice(n254, index=[2])
n258 = slice(n254, index=[{"start": 0, "step": null, "stop": 2}])
n259 = gt(n257, n0)
n260 = gt(n255, n0)
n261 = gt(n256, n0)
n262 = div(n256, n255)
n263 = slice(n252, index=[0, 4])
n264 = slice(n252, index=[0, 3])
n265 = slice(n28, index=[0, 1])
n266 = gt(n262, n265)
n267 = slice(n28, index=[0, 2])
n268 = gt(n262, n267)
n269 = slice(n28, index=[0, 3])
n270 = gt(n262, n269)
n271 = slice(n28, index=[0, 0])
n272 = gt(n262, n271)
n273 = cond(n270, n263, n264)
n274 = slice(n252, index=[0, 2])
n275 = cond(n268, n273, n274)
n276 = slice(n252, index=[0, 1])
n277 = slice(n252, index=[0, 0])
n278 = cond(n272, n276, n277)
n279 = cond(n266, n275, n278)
n280 = slice(n252, index=[1, 4])
n281 = slice(n252, index=[1, 3])
n282 = slice(n253, index=[1, 1])
n283 = lt(n262, n282)
n284 = slice(n253, index=[1, 2])
n285 = lt(n262, n284)
n286 = slice(n253, index=[1, 3])
n287 = lt(n262, n286)
n288 = slice(n253, index=[1, 0])
n289 = lt(n262, n288)
n290 = cond(n287, n280, n281)
n291 = slice(n252, index=[1, 2])
n292 = cond(n285, n290, n291)
n293 = slice(n252, index=[1, 1])
n294 = slice(n252, index=[1, 0])
n295 = cond(n289, n293, n294)
n296 = cond(n283, n292, n295)
n297 = slice(n252, index=[2, 4])
n298 = slice(n252, index=[2, 3])
n299 = slice(n253, index=[2, 1])
n300 = lt(n262, n299)
n301 = slice(n253, index=[2, 2])
n302 = lt(n262, n301)
n303 = slice(n253, index=[2, 3])
n304 = lt(n262, n303)
n305 = slice(n253, index=[2, 0])
n306 = lt(n262, n305)
n307 = cond(n304, n297, n298)
n308 = slice(n252, index=[2, 2])
n309 = cond(n302, n307, n308)
n310 = slice(n252, index=[2, 1])
n311 = slice(n252, index=[2, 0])
n312 = cond(n306, n310, n311)
n313 = cond(n300, n309, n312)
n314 = slice(n252, index=[3, 4])
n315 = slice(n252, index=[3, 3])
n316 = slice(n28, index=[3, 1])
n317 = gt(n262, n316)
n318 = slice(n28, index=[3, 2])
n319 = gt(n262, n318)
n320 = slice(n28, index=[3, 3])
n321 = gt(n262, n320)
n322 = slice(n28, index=[3, 0])
n323 = gt(n262, n322)
n324 = cond(n321, n314, n315)
n325 = slice(n252, index=[3, 2])
n326 = cond(n319, n324, n325)
n327 = slice(n252, index=[3, 1])
n328 = slice(n252, index=[3, 0])
n329 = cond(n323, n327, n328)
n330 = cond(n317, n326, n329)
n331 = matmul(n279, n254)
n332 = maximum(n331, n0)
n333 = slice(n9, index=[{"start": 1, "step": null, "stop": 3}])
n334 = slice(n9, index=[{"start": 0, "step": null, "stop": 1}])
n335 = sub(n333, n334)
n336 = reshape(n0, shape=[1])
n337 = matmul(n335, n332)
n338 = concat(n336, n337, axis=0)
n339 = argmax(n338, axis=null)
n340 = matmul(n296, n254)
n341 = maximum(n340, n0)
n342 = matmul(n335, n341)
n343 = concat(n336, n342, axis=0)
n344 = argmax(n343, axis=null)
n345 = matmul(n313, n254)
n346 = maximum(n345, n0)
n347 = matmul(n335, n346)
n348 = concat(n336, n347, axis=0)
n349 = argmax(n348, axis=null)
n350 = matmul(n330, n254)
n351 = maximum(n350, n0)
n352 = matmul(n335, n351)
n353 = concat(n336, n352, axis=0)
n354 = argmax(n353, axis=null)
n355 = slice(n65, index=[0])
n356 = slice(n65, index=[1])
n357 = slice(n246, index=[0, 0])
n358 = matmul(n357, n258)
n359 = gt(n257, n358)
n360 = cond(n359, n355, n339)
n361 = slice(n246, index=[0, 1])
n362 = matmul(n361, n258)
n363 = gt(n257, n362)
n364 = cond(n363, n355, n344)
n365 = cond(n261, n360, n364)
n366 = slice(n246, index=[0, 2])
n367 = matmul(n366, n258)
n368 = gt(n257, n367)
n369 = cond(n368, n355, n349)
n370 = slice(n246, index=[0, 3])
n371 = matmul(n370, n258)
n372 = gt(n257, n371)
n373 = cond(n372, n355, n354)
n374 = cond(n261, n369, n373)
n375 = slice(n243, index=[0, {"start": 0, "step": null, "stop": 2}, null])
n376 = max(n375, axis=null)
n377 = le(n376, n0)
n378 = cond(n377, n355, n365)
n379 = cond(n260, n378, n374)
n380 = slice(n246, index=[1, 0])
n381 = matmul(n380, n258)
n382 = lt(n257, n381)
n383 = cond(n382, n356, n339)
n384 = slice(n246, index=[1, 1])
n385 = matmul(n384, n258)
n386 = lt(n257, n385)
n387 = cond(n386, n356, n344)
n388 = cond(n261, n383, n387)
n389 = slice(n246, index=[1, 2])
n390 = matmul(n389, n258)
n391 = lt(n257, n390)
n392 = cond(n391, n356, n349)
n393 = slice(n246, index=[1, 3])
n394 = matmul(n393, n258)
n395 = lt(n257, n394)
n396 = cond(n395, n356, n354)
n397 = cond(n261, n392, n396)
n398 = cond(n260, n388, n397)
n399 = cond(n259, n379, n398)   <- interpretation
```

## The baseline

This is a baseline run: its networks are those of a baseline model, for the shape of rnn-b. Its agent was given what a run on those is given, and asked for an entry exact for any weights of the design. What it achieved is generic; runs of that shape are read against it.

Frozen: r5s3 (`lean_v3`), sha256 `4758552453b0f6a4`, chosen as the highest reward on the second network, of the entries exact there, that passes the check, trying up to 3 different entries in that order (every submission is scored on the second network on one fixed sample) (0.7241 on rnn-e-s4). Scored again on the model's other networks, all on one fresh sample (seed 1119164715966372202):

| Network | Reward | With its sampling interval | Coverage | Fidelity | Wrong | Cost | Build part | Per input |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| rnn-e-s1 | 0.7717 | 0.7717 to 0.7741 | 1.0000 | 1.00000 | 0 | 0.2259 | 0.0190 | 0.2070 |
| rnn-e-s2 | 0.7609 | 0.7609 to 0.7632 | 1.0000 | 1.00000 | 0 | 0.2368 | 0.0190 | 0.2178 |
| rnn-e-s3 | 0.5349 | 0.5349 to 0.5373 | 1.0000 | 1.00000 | 0 | 0.4627 | 0.0190 | 0.4437 |

Verdict (the network's output on every input of its region on every other network): **passes**: it gave the network's output on every input of its region on all 3 networks.

## Reference entries

Scored here for comparison. They are withheld from the agent. Each number is the mean of 8 scorings on fixed samples. The task: Untrained. The networks were never trained: each is the state AlgZoo's trainer starts from for one seed of rnn-b's networks (2nd argmax, hidden size 4, three numbers), saved by AlgZoo before its first step (0 training sequences) and converted as published. A model for the baseline of the shape it shares with rnn-b: a run on it is a usual run in everything the agent is given (the same prompt, sizes, data set, rounds, budgets and reward), with nothing learned to find, so what the agent achieves here is generic. Its networks behave like none of the trained ones, and their outputs are lopsided (how_often_each_output); whatever regularity a run finds in one of them is an accident of that network, which its other networks show up.


| Entry | Network | Reward | Coverage | Fidelity | Cost | Reward, highest less lowest |
| --- | --- | --- | --- | --- | --- | --- |
| the network itself | rnn-e-s0 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| the network itself | rnn-e-s4 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| folded_first_step | rnn-e-s0 | 0.2284 | 1.0000 | 1.00000 | 0.7693 | 0.0000 |
| folded_first_step | rnn-e-s4 | 0.2284 | 1.0000 | 1.00000 | 0.7693 | 0.0000 |

## Rounds

| Round | Submissions | Best reward so far | Raised it | Ended with | Tool calls | Minutes | Output tokens | Programs run | Sandbox minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 3 | 0.6897 | yes | end_turn | 29 run_python, 3 submit_entry | 23.9 | 102,877 | 29 | 1.2 |
| 2 | 2 | 0.7078 | yes | end_turn | 37 run_python, 2 submit_entry | 37.5 | 186,294 | 37 | 0.4 |
| 3 | 1 | 0.7182 | yes | end_turn | 37 run_python, 1 submit_entry | 37.0 | 181,380 | 37 | 0.5 |
| 4 | 3 | 0.7539 | yes | end_turn | 33 run_python, 3 submit_entry | 25.9 | 107,259 | 33 | 1.6 |
| 5 | 4 | 0.7710 | yes | end_turn | 30 run_python, 4 submit_entry | 26.0 | 111,909 | 30 | 0.5 |

The rounds were billed to an API key: $49.11 by Claude Code's count.

## What the agent ran

Every program is kept in full in its round's `session/python/` folder, with what it got back; the round's `response.md` has what the agent wrote, and `stream_NN.jsonl` everything the CLI emitted.

The guard inside Python refused nothing: no program tried to reach files outside its folder, the network or other programs.

Programs whose text reaches for files or the system. A match is a reason to read the program, not a verdict:

- `round_002/session/python/022.py`: eval or exec, open(
- `round_002/session/python/023.py`: eval or exec
- `round_002/session/python/024.py`: eval or exec
- `round_002/session/python/025.py`: eval or exec
- `round_002/session/python/026.py`: open(, os.
- `round_002/session/python/027.py`: eval or exec, open(, os.
- `round_002/session/python/028.py`: eval or exec
- `round_002/session/python/029.py`: eval or exec
- `round_002/session/python/033.py`: eval or exec
- `round_002/session/python/035.py`: eval or exec
- `round_002/session/python/036.py`: eval or exec
- `round_002/session/python/037.py`: eval or exec

## Submissions

Cost: everything the entry computes, per input of its region, over one forward pass. Right and wrong: the share of the inputs the entry answers rightly and wrongly. On the frontier: no other submission is at least as good in right share, wrong share and cost, and better in one. On the second network: the reward and the fidelity of the same entry on the seed check's network, every submission on one fixed sample, scored after its round; the agent never saw these, and they chose nothing.

| Entry | Saved as | Reward | Coverage | Fidelity | Cost | Right | Wrong | On the frontier | Claimed | Overclaim | On the second network | Fidelity there |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | `cascade_v3` | 0.6195 | 1.0000 | 1.00000 | 0.3782 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.5644 | 1.00000 |
| r1s2 | `cascade_v4` | 0.6650 | 1.0000 | 1.00000 | 0.3326 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6273 | 1.00000 |
| r1s3 | `cascade_v6_234` | 0.6897 | 1.0000 | 1.00000 | 0.3080 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6548 | 1.00000 |
| r2s1 | `sec_p2v2` | 0.7038 | 1.0000 | 1.00000 | 0.2939 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6681 | 1.00000 |
| r2s2 | `sec_p2v3` | 0.7078 | 1.0000 | 1.00000 | 0.2898 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6710 | 1.00000 |
| r3s1 | `greedy_v6` | 0.7182 | 1.0000 | 1.00000 | 0.2795 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6581 | 1.00000 |
| r4s1 | `skip_v1` | 0.7308 | 1.0000 | 1.00000 | 0.2669 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6548 | 1.00000 |
| r4s2 | `skip_v2` | 0.7353 | 1.0000 | 1.00000 | 0.2624 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.6598 | 1.00000 |
| r4s3 | `skip_v5` | 0.7539 | 1.0000 | 1.00000 | 0.2437 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.7027 | 1.00000 |
| r5s1 | `margin_v1` | 0.7627 | 1.0000 | 1.00000 | 0.2349 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.7186 | 1.00000 |
| r5s2 | `lean_v1` | 0.7710 | 1.0000 | 1.00000 | 0.2267 | 1.0000 | 0.00000 | yes | 1.00000 | 0.00000 | 0.7231 | 1.00000 |
| r5s3 | `lean_v3` | 0.7692 | 1.0000 | 1.00000 | 0.2285 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.7241 | 1.00000 |
| r5s4 | `lean_v3` | 0.7693 | 1.0000 | 1.00000 | 0.2284 | 1.0000 | 0.00000 | no | 1.00000 | 0.00000 | 0.7241 | 1.00000 |

On the second network the best submission was r5s3 (`lean_v3`), 0.7241; the locked entry, r5s2, scored 0.7231 there on the same sample.

## The agent's closing notes

> ## What the network does
> Output = argmax of `readout @ h2`, `h2 = relu(w·x2 + rec·relu(w·x1 + rec·relu(w·x0)))`; the function is positively homogeneous (depends only on the input direction). On this network the output is 0 on ~89% of inputs: provably 0 on the whole quadrant x2>0, x0>0 (the weight‑derived cap threshold is ≤0 there), 0 on 99.6% of x2>0 overall, and on 79% of x2<0; outputs 1 (9.5%) and 2 (11.5%) only occur for x2<0 at moderate |x2| relative to (|x0|,|x1|), mostly in the octants (x2<0, x0>0, x1<0), (x2<0, x0<0, x1>0) and especially (x2<0, x0<0, x1<0). Structurally, for any weights: in each sign quadrant of (x0,x1), h1 is exactly linear inside angular sectors |x1|/|x0| ∈ (θ_i, θ_{i+1}) (≤4 thresholds from units whose two input coefficients have opposite signs), so `logits = R @ relu(M_sector @ x)` with a build‑time 4×3 matrix per sector; for |x2| large relative to (|x0|,|x1|) the output is the limit output o± = argmax(R·relu(±w)). New this round: the exact per‑sector linear cap (2×2 solve at the sector's two edge rays) would catch 80% of inputs vs 76% for the per‑octant LP cap, but a componentwise max of sector caps is far worse (60%), so the LP stays. Certain of all this (algebra; 0 errors on >170 random/degenerate weight sets).
> 
> ## How you found it
> Loaded the round‑4 entry (`best`, 392 nodes) with `lv1.Graph.load`, printed it with `lv1.show`, computed per‑node build costs with `lv1.apply`, and computed oracle catch rates of sector‑level caps in numpy from the graph's build values. Then rebuilt the entry node‑by‑node with a `rebuild(base, patches)` function (re‑emits every node, substituting patched ones), checked that patched build values are bit‑identical (or within 1e‑16) to the originals, measured with `measure`, and verified exactness with `lv1.Evaluator` against a numpy forward pass on ~170 random and degenerate weight sets (one‑signed w, w_j=0, duplicate/zero readout rows, identity/zero/one‑signed recurrent, scales 0.01–20, input scales 0.01–100) plus 60k inputs here.
> 
> ## The best entry
> `lean_v3` (and `lean_v1`, same interpretation, 1.3k more build ops): region = all inputs, 400 nodes, build 24.3k ops (1.9%). Interpretation: sign tree on x2, x0 (4 ops) → if x2>0 & x0>0 and the build‑time check `max(T_LP[side0, quads 0,1]) ≤ 0` holds, output o+ (5 ops, 25% of inputs); else x1 sign (2 ops) → linear cap `x2 ≷ T[s2,q]·(x0,x1)` (3 ops) → o± if it passes (~51% at 9 ops); else per‑quadrant fallback: ratio x1/x0, scalar sector tests in a balanced cond tree, `h = relu(M_sector @ x)` (16 ops), then **`argmax(concat([0], D @ h))` with `D = R[1:] − R[0]`** (10 ops instead of 14 for `argmax(R @ h)`; ties behave identically because structural ties give exactly d = 0). Fallback ≈ 42 ops on 24% of inputs. Build changes vs round 4 (values identical): margin coefficient sums as matmuls of Δ‑masks against a [β, γ_edge0, γ_edge1] table instead of where‑chains over 960‑element arrays; the per‑unit flip deltas as `(C1+Ah)·where(hurting, γ⁺−relu γ, γ)`; greedy‑pass sums as matmul with a ones vector (keeps the dimension, no reshape); LP proxy as `max(T0+T1, 0)`; LP candidate selection by `take` on the flattened table with `arange(120)[::15]`; `θ < 1e18` validity test; dropped a redundant −1e9 floor. Cost 0.227 (predict 16.1 ops/input + build 1.5), reward ≈ 0.770.
> 
> ## Claims
> Claimed fidelity 1.0 here and expected 1.0 on the second network: every shortcut is computed from the weights inside the entry (caps are weight‑derived sufficient conditions with strict inequalities and 1e‑7 bumps; the skip fires only when the LP's T is componentwise ≤0; the fallback is the exact sector‑wise re‑parametrisation with a margin readout whose ties coincide with the network's). Verified 0 errors on ~170 random/degenerate weight sets (300–500 inputs each) and 60k inputs here. Coverage is 1 everywhere; only the catch rate (cost) varies with the weights. Measure‑zero caveat as before: x0 == 0.0 exactly picks the wrong sector in quadrants with x0 ≤ 0.
> 
> ## Next
> The 400‑node limit is binding again. Remaining ideas, all small: (1) sector‑level second cap inside the fallback (catch 80% vs 76%, ≈+0.35%) needs ~60 nodes; (2) the LP feasibility check (2.8k build ops) could be replaced by the dual "bracketing‑pair" argument (≈+0.2%) but needs careful handling of a threshold exactly at the proxy direction; (3) separate μ/ν matmuls would save ~1k build ops for +4 nodes; (4) dropping greedy pass 3 frees 17 nodes but costs ~4% more predict ops here, so it is not worth it; (5) any further predict‑ops gain needs a fundamentally cheaper exact fallback than 42 ops, which I did not find.
