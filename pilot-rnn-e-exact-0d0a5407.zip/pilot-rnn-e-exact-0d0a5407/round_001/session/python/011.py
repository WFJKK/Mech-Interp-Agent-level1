
import numpy as np
def build(use_fallback=True):
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    wp = lv1.maximum(w,0.0); wm = lv1.maximum(-w,0.0)
    vp = rec@wp; vm = -(rec@wm)
    recp = lv1.maximum(rec,0.0)
    ks = g.arange(3)
    def side(sgn):
        sw = w*sgn
        hb = lv1.maximum(sw,0.0)
        o = (R@hb).argmax()
        D = R[o][None,:] - R            # 3x4
        useA = lv1.cast((sw>0.0)[None,:] & (D>=0.0), "float")
        DA = D*useA
        Dn = lv1.maximum(-D,0.0)
        m = DA@sw - Dn@hb                 # 3
        c = -(DA@rec) + Dn@recp           # 3x4
        cp = lv1.maximum(c,0.0)
        valid = m>0.0
        Md = lv1.where(valid, m, 1.0)
        isO = ks==o
        def coef(vec):
            a = (cp@vec)/Md
            a = lv1.where(valid, a, 1e9)
            a = lv1.where(isO, -1e9, a)
            return a.max()
        ap = coef(lv1.maximum(vp,0.0)); am = coef(lv1.maximum(-vm,0.0))
        bp = coef(wp); bm = coef(wm)
        return o, ap, am, bp, bm
    sx0 = x0>0.0; sx1 = x1>0.0; sx2 = x2>0.0
    def fallback():
        v = lv1.cond(sx0, vp, vm)
        h1 = lv1.maximum(w*x1 + v*x0, 0.0)
        h2 = lv1.maximum(w*x2 + rec@h1, 0.0)
        return (R@h2).argmax()
    def branch(sgn):
        o, ap, am, bp, bm = side(sgn)
        A = lv1.where(sx0, ap, -am); B = lv1.where(sx1, bp, -bm)
        s2 = x2 if sgn==1 else -x2
        test = s2 > A*x0 + B*x1
        if use_fallback:
            return lv1.cond(test, o, fallback()), test
        return o, test
    outp, tp = branch(1); outm, tm = branch(-1)
    pred = lv1.cond(sx2, outp, outm)
    if use_fallback:
        return g.entry(interpretation=pred)
    region = lv1.where(sx2, tp, tm)
    return g.entry(interpretation=pred, region=region)
e1 = build(True); save_entry("cascade_v2", e1)
print(measure(e1))
e2 = build(False); save_entry("region_only_v2", e2)
print(measure(e2))
import json
print(len(json.dumps(e1)), str(e1)[:300])
