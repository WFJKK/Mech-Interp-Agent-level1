
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)
v = np.where(X[:,0:1]>0, vp, vm)
Z = w*X[:,1:2] + v*X[:,0:1]
H1 = np.maximum(Z, 0)
q0 = np.maximum(X[:,0],0); q0m=np.maximum(-X[:,0],0); q1=np.maximum(X[:,1],0); q1m=np.maximum(-X[:,1],0)
def test_h1(sgn,k,S,o,cheap):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0)
    useA=np.zeros(4); useA[list(S)]=1
    m = (D*useA)@(sgn*w) - np.maximum(-D,0)@hb
    c = -(useA*D)@rec + (np.maximum(-D,0)[:,None]*np.maximum(rec,0)).sum(0)
    s2=sgn*X[:,2]
    if not cheap:
        return s2*m > H1@c
    cp=np.maximum(c,0); cn=np.maximum(-c,0)
    # upper bound part: cp . (relu(w x1)+relu(v x0)); lower bound part: cn . (w x1 + v x0) = cn.Z
    ub = (cp@wp)*q1 + (cp@wm)*q1m + np.where(X[:,0]>0, (cp@np.maximum(vp,0))*q0, (cp@np.maximum(-vm,0))*q0m)
    lb = Z@cn
    return s2*m > ub - lb
for sgn in [1,-1]:
    hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    pos = sgn*X[:,2]>0
    for cheap in [False, True]:
        for name in ["A","A+all","allsubsets"]:
            ok = pos.copy()
            for k in ks:
                D=R[o]-R[k]
                Dpos=[j for j in range(4) if D[j]>=0]
                SA = tuple(j for j in Dpos if sgn*w[j]>0)
                if name=="A": subsets=[SA]
                elif name=="A+all": subsets=[SA, tuple(Dpos)]
                else: subsets=[s for r in range(len(Dpos)+1) for s in itertools.combinations(Dpos,r)]
                okk=np.zeros(len(X),bool)
                for S in subsets: okk |= test_h1(sgn,k,S,o,cheap)
                ok &= okk
            print("side",sgn,"cheap" if cheap else "h1   ",name,"catch",round(ok.mean(),4),(Y[ok]==o).all(), "n subsets", [len([s for r in range(len([j for j in range(4) if (R[o]-R[k])[j]>=0])+1) for s in itertools.combinations(range(4),r)]) for k in ks] if name=="allsubsets" else "")
    print(" true", (pos&(Y==o)).mean())
