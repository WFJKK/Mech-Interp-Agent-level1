
import numpy as np
no = network_outputs()
X, Y, ops = no
X=np.array(X); Y=np.array(Y)
print(X.shape, Y.shape, ops if not hasattr(ops,'__len__') or len(ops)<20 else type(ops))
print(np.bincount(Y))
for name, f in [("sign x2", X[:,2]>0), ("sign x1", X[:,1]>0), ("sign x0", X[:,0]>0)]:
    for v in [False, True]:
        m = f==v
        print(name, v, np.bincount(Y[m], minlength=3)/m.sum())
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
def fwd(x):
    h=np.maximum(w*x[0],0)
    for t in range(1,3): h=np.maximum(w*x[t]+rec@h,0)
    return (R@h).argmax(), h
print(sum(fwd(x)[0]==y for x,y in zip(X,Y))/len(Y))
H1 = []
for x in X:
    h=np.maximum(w*x[0],0); h=np.maximum(w*x[1]+rec@h,0); H1.append(h)
H1=np.array(H1)
u,c = np.unique((H1>0).astype(int), axis=0, return_counts=True)
print("active pattern counts step1:"); print(u); print(c)
H2=np.array([fwd(x)[1] for x in X])
u,c = np.unique((H2>0).astype(int), axis=0, return_counts=True)
print("active pattern counts step2:"); print(u); print(c)
