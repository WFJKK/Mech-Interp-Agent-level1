
import numpy as np, json, itertools
def build(variants=(2,3,4)):
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    wp = lv1.maximum(w,0.0); wm = lv1.maximum(-w,0.0)
    vp = rec@wp; vm = -(rec@wm)
    recp = lv1.maximum(rec,0.0)
    Q0 = g.const(np.array([-1.0,-1.0,1.0,1.0])); Q1 = g.const(np.array([-1.0,1.0,-1.0,1.0]))
    masks = g.const(np.array([[float(b) for b in np.binary_repr(i,4)] for i in range(16)]))  # (16,4)
    oth = g.const(np.array([[1,2],[0,2],[0,1]]))
    V = lv1.where((Q0>0.0)[:,None], vp[None,:], vm[None,:])      # (4 quad, 4 unit)
    VQ = V*Q0[:,None]; WQ = w[None,:]*Q1[:,None]
    ub0 = V*lv1.cast(VQ>0.0,"float"); ub1 = w[None,:]*lv1.cast(WQ>0.0,"float")
    same = lv1.cast((VQ>=0.0)&(WQ>=0.0),"float")
    lb0 = V*same; lb1 = w[None,:]*same
    UB = lv1.concat([ub0, ub1], axis=0); LB = lv1.concat([lb0, lb1], axis=0); QQ = lv1.concat([Q0, Q1])
    nS = g.arange(16)
    def side(sgn):
        sw = w*sgn
        hb = lv1.maximum(sw,0.0)
        o = (R@hb).argmax()
        D = R[o][None,:] - R[oth[o]]     # (2,4)
        useA = masks[:,None,:]*lv1.cast(D>=0.0,"float")[None,:,:]
        DA = D[None,:,:]*useA
        Dn = lv1.maximum(-D,0.0)
        m = DA@sw - (Dn@hb)[None,:]
        c = (Dn@recp)[None,:,:] - DA@rec
        cp = lv1.maximum(c,0.0); cn = lv1.maximum(-c,0.0)
        valid = m>0.0
        Md = lv1.where(valid, m, 1.0)
        AB = (cp@UB.T - cn@LB.T)/Md[:,:,None]
        ABp = lv1.where(valid[:,:,None], AB*QQ[None,None,:], 1e9)
        score = ABp[:,:,0:4] + ABp[:,:,4:8]
        bi = score.argmin(axis=0)
        sel = lv1.cast(nS[:,None,None] == bi[None,:,:], "float")
        ABs = (ABp*lv1.concat([sel,sel],axis=2)).sum(axis=0)
        star = ABs.max(axis=0)*QQ
        T = lv1.stack([star[0:4], star[4:8]], axis=1)
        if sgn==-1: T = -T
        return o, T
    sx0 = x0>0.0; sx1 = x1>0.0; sx2 = x2>0.0
    xx = lv1.stack([x0,x1]); x10 = lv1.stack([x1,x0]); x2v = lv1.stack([x2])
    # dead units per quadrant
    dead = lv1.cast((VQ<=0.0)&(WQ<=0.0), "int")       # (4 quad, 4)
    nalive = 4 - dead.sum(axis=1)                      # (4,)
    perm = lv1.argsort(dead, axis=1)                   # alive first
    Wv_all = lv1.stack([lv1.stack([w, V[q]], axis=1) for q in range(4)])   # (4 quad, 4 unit, 2)
    def fallback(q):
        idx = perm[q]
        def variant(n):
            ii = idx[0:n]
            Wv = lv1.take(Wv_all[q], ii, 0)            # (n,2)
            recn = lv1.take(rec, ii, 1)                 # (4,n)
            h1 = lv1.maximum(Wv @ x10, 0.0)
            p = lv1.concat([recn, w[:,None]], axis=1) @ lv1.concat([h1, x2v])
            return (R@lv1.maximum(p,0.0)).argmax()
        na = nalive[q]
        vs = {n: variant(n) for n in variants}
        if variants==(2,3,4):
            return lv1.cond(na<=2, vs[2], lv1.cond(na<=3, vs[3], vs[4]))
        elif variants==(4,):
            return vs[4]
        else:
            return lv1.cond(na<=2, vs[2], vs[4])
    fb = {q: fallback(q) for q in range(4)}
    def side_branch(sgn):
        o, T = side(sgn)
        def q0branch(q0):
            def leaf(q1):
                q = (q0>0)*2 + (q1>0)
                thr = T[q] @ xx
                test = (x2 > thr) if sgn==1 else (x2 < thr)
                return lv1.cond(test, o, fb[q])
            return lv1.cond(sx1, leaf(1), leaf(-1))
        return lv1.cond(sx0, q0branch(1), q0branch(-1))
    pred = lv1.cond(sx2, side_branch(1), side_branch(-1))
    return g.entry(interpretation=pred)
for variants in [(4,), (2,4), (2,3,4)]:
    e = build(variants); name="cascade_v6_"+"".join(map(str,variants)); save_entry(name, e)
    m = measure(e); print(variants, "nodes", len(e['nodes']), {k:m[k] for k in ['predict_ops','build_ops','cost','reward']})
