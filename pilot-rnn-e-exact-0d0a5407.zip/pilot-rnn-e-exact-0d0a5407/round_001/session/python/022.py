
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm); recp=np.maximum(rec,0)
Q0=np.array([-1,-1,1,1.]); Q1=np.array([-1,1,-1,1.])
V = np.where(Q0[:,None]>0, vp[None,:], vm[None,:]); VQ=V*Q0[:,None]; WQ=w[None,:]*Q1[:,None]
ub0=V*(VQ>0); ub1=w[None,:]*(WQ>0); same=(VQ>=0)&(WQ>=0); lb0=V*same; lb1=w[None,:]*same
quadX = (X[:,0]>0).astype(int)*2+(X[:,1]>0).astype(int)
def mc(sgn,o,k,S):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0); useA=np.zeros(4); useA[list(S)]=1
    m=(D*useA)@(sgn*w) - np.maximum(-D,0)@hb
    c=-(useA*D)@rec + (np.maximum(-D,0)[:,None]*recp).sum(0)
    return m,c
def evaluate(proxy, verbose=False):
    total=0
    for sgn in [1,-1]:
        hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
        s2=sgn*X[:,2]; pos=s2>0
        thr_comb=np.zeros(len(X))
        for k in ks:
            D=R[o]-R[k]; Dpos=[j for j in range(4) if D[j]>=0]
            subsets=[S for r in range(len(Dpos)+1) for S in itertools.combinations(Dpos,r)]
            Ap=[];Bp=[]
            for S in subsets:
                m,c=mc(sgn,o,k,S); cp=np.maximum(c,0); cn=np.maximum(-c,0)
                A=(ub0@cp-lb0@cn); B=(ub1@cp-lb1@cn)
                if m>0: Ap.append(A*Q0/m); Bp.append(B*Q1/m)
                else: Ap.append(np.full(4,1e9)); Bp.append(np.full(4,1e9))
            Ap=np.array(Ap); Bp=np.array(Bp)
            score = proxy(Ap,Bp); bi = score.argmin(0)
            if verbose: print("  side",sgn,"k",k,"chosen",[subsets[b] for b in bi])
            thr = (Ap[bi,np.arange(4)]*Q0)[quadX]*X[:,0] + (Bp[bi,np.arange(4)]*Q1)[quadX]*X[:,1]
            thr_comb=np.maximum(thr_comb,thr)
        ok=pos&(s2>thr_comb); total+=ok.mean()
        assert (Y[ok]==o).all()
    return total
print("sum proxy", evaluate(lambda a,b: a+b, True))
print("max proxy", evaluate(lambda a,b: np.maximum(a,b)))
print("sumsq proxy", evaluate(lambda a,b: a**2+b**2))
print("relu-sum proxy", evaluate(lambda a,b: np.maximum(a,0)+np.maximum(b,0)))
rng=np.random.default_rng(1); G=np.abs(rng.normal(size=(2000,3)))
def mcproxy(a,b):
    out=np.zeros_like(a)
    for i in range(a.shape[0]):
        for q in range(4):
            out[i,q] = -(G[:,2] > a[i,q]*G[:,0]+b[i,q]*G[:,1]).mean()
    return out
print("MC proxy", evaluate(mcproxy, True))
