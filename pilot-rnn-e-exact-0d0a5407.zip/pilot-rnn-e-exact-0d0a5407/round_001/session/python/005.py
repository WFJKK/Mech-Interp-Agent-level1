
import numpy as np
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)
v = np.where(X[:,0:1]>0, vp, vm)
H1 = np.maximum(w*X[:,1:2] + v*X[:,0:1], 0)
U = H1@rec.T
def side(sgn):
    hb = np.maximum(sgn*w,0)
    o = (R@hb).argmax()
    ks=[k for k in range(3) if k!=o]
    m = np.array([(R[o]-R[k])@hb for k in ks])
    print("side",sgn,"o",o,"margins",m)
    # one-sided bound: D_k.h2 >= m_k*sgn*x2 - sum_{D>=0} D relu(-u) - sum_{D<0}|D| relu(u)
    C=[]
    for k in ks:
        D=R[o]-R[k]
        c = (np.maximum(D,0)[:,None]*np.maximum(-rec,0)).sum(0) + (np.maximum(-D,0)[:,None]*np.maximum(rec,0)).sum(0)
        C.append(c)
    C=np.array(C)
    # exact-u test
    tu = np.all([(sgn*X[:,2]*m[i] > (np.maximum(R[o]-R[k],0)@np.maximum(-U,0).T) + (np.maximum(-(R[o]-R[k]),0)@np.maximum(U,0).T)) for i,k in enumerate(ks)],axis=0)
    print(" u-test catch", tu.mean(), (Y[tu]==o).all())
    Cp = C/np.maximum(m,1e-12)[:,None]
    cc = Cp.max(axis=0)
    th = sgn*X[:,2] > H1@cc
    print(" h1-test catch", th.mean(), (Y[th]==o).all(), "cc",cc)
    th2 = np.all([sgn*X[:,2] > H1@Cp[i] for i in range(2)],axis=0)
    print(" h1-test (2 tests) catch", th2.mean())
    a = cc@np.maximum(np.abs(vp),np.abs(vm)); b = cc@np.abs(w)
    tc = sgn*X[:,2] > a*np.abs(X[:,0])+b*np.abs(X[:,1])
    print(" cheap test catch", tc.mean(), (Y[tc]==o).all())
    # cheap with sign of x0 known: h1_i <= |w_i||x1| + relu(sgn0*v_i)|x0|... actually h1_i <= relu(w_i x1) + relu(v_i x0)
    ap = cc@np.maximum(vp,0); am = cc@np.maximum(-vm,0)
    bp = cc@np.maximum(w,0); bm = cc@np.maximum(-w,0)
    B = np.where(X[:,0]>0, ap*X[:,0], -am*X[:,0]) + np.where(X[:,1]>0, bp*X[:,1], -bm*X[:,1])
    tc2 = sgn*X[:,2] > B
    print(" cheap signed test catch", tc2.mean(), (Y[tc2]==o).all())
side(1); side(-1)
print("y dist when x2<0:", np.bincount(Y[X[:,2]<0]))
