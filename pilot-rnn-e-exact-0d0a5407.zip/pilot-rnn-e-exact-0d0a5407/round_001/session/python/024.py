
import numpy as np
e1 = entries["cascade_v4"]
def ref(wts, x):
    w=wts['input'][:,0]; rec=wts['recurrent']; R=wts['readout']
    h=np.maximum(w*x[0],0)
    for t in range(1,3): h=np.maximum(w*x[t]+rec@h,0)
    return (R@h).argmax()
rng = np.random.default_rng(7)
bad_total=0
for trial in range(16):
    scale = [0.3,1.0,2.0,0.6][trial%4]
    wts = {'input': rng.normal(size=(4,1))*scale, 'recurrent': rng.normal(size=(4,4))*scale*0.5, 'readout': rng.normal(size=(3,4))*scale}
    if trial==15: wts = {k: v.copy() for k,v in weights.items()}; wts['readout'] = -wts['readout']
    ev = lv1.Evaluator(e1, wts, 3)
    xs = rng.normal(size=(2500,3))
    bad=0; ops=0
    for x in xs:
        ins, ans, cr, cp = ev.run(x)
        ops+=cp
        if ans != ref(wts,x): bad+=1
    bad_total+=bad
    print(trial, "bad", bad, "avg ops", round(ops/len(xs),1), "build", ev.build_cost)
print("total bad", bad_total)
