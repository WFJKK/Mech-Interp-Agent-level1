
import numpy as np, json, itertools
def build():
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    wp = lv1.maximum(w,0.0); wm = lv1.maximum(-w,0.0)
    vp = rec@wp; vm = -(rec@wm)
    recp = lv1.maximum(rec,0.0)
    ks = g.arange(3)
    Q0 = g.const(np.array([-1.0,-1.0,1.0,1.0])); Q1 = g.const(np.array([-1.0,1.0,-1.0,1.0]))
    masks = g.const(np.array([[float(b) for b in np.binary_repr(i,4)] for i in range(16)]))  # (16,4)
    V = lv1.where((Q0>0.0)[:,None], vp[None,:], vm[None,:])      # (4 quad, 4 unit)
    VQ = V*Q0[:,None]; WQ = w[None,:]*Q1[:,None]
    ub0 = V*lv1.cast(VQ>0.0,"float"); ub1 = w[None,:]*lv1.cast(WQ>0.0,"float")
    same = lv1.cast((VQ>=0.0)&(WQ>=0.0),"float")
    lb0 = V*same; lb1 = w[None,:]*same
    nS = g.arange(16)
    def side(sgn):
        sw = w*sgn
        hb = lv1.maximum(sw,0.0)
        o = (R@hb).argmax()
        D = R[o][None,:] - R            # (3,4)
        useA = masks[:,None,:]*lv1.cast(D>=0.0,"float")[None,:,:]    # (16,3,4)
        DA = D[None,:,:]*useA
        Dn = lv1.maximum(-D,0.0)        # (3,4)
        m = DA@sw - (Dn@hb)[None,:]     # (16,3)
        c = -(DA@rec) + (Dn@recp)[None,:,:]   # (16,3,4)
        cp = lv1.maximum(c,0.0); cn = lv1.maximum(-c,0.0)
        valid = m>0.0
        Md = lv1.where(valid, m, 1.0)
        A = (cp@ub0.T - cn@lb0.T)/Md[:,:,None]     # (16,3,4 quad)
        B = (cp@ub1.T - cn@lb1.T)/Md[:,:,None]
        Ap = lv1.where(valid[:,:,None], A*Q0[None,None,:], 1e9)   # coefficient on |x0|
        Bp = lv1.where(valid[:,:,None], B*Q1[None,None,:], 1e9)
        score = Ap + Bp
        bi = score.argmin(axis=0)                      # (3,4)
        sel = lv1.cast(nS[:,None,None] == bi[None,:,:], "float")
        Aps = (Ap*sel).sum(axis=0); Bps = (Bp*sel).sum(axis=0)   # (3,4)
        isO = (ks==o)[:,None]
        Aps = lv1.where(isO, -1e9, Aps); Bps = lv1.where(isO, -1e9, Bps)
        Astar = Aps.max(axis=0)*Q0; Bstar = Bps.max(axis=0)*Q1    # (4,) coefficients on x0, x1
        T = lv1.stack([Astar, Bstar], axis=1)   # (4 quad, 2)
        if sgn==-1: T = -T
        return o, T
    sx0 = x0>0.0; sx1 = x1>0.0; sx2 = x2>0.0
    xx = lv1.stack([x0,x1])
    def fallback(v):
        h1 = lv1.maximum(lv1.stack([w,v],axis=1) @ lv1.stack([x1,x0]), 0.0)
        p = lv1.concat([rec, w[:,None]], axis=1) @ lv1.concat([h1, lv1.stack([x2])])
        h2 = lv1.maximum(p, 0.0)
        return (R@h2).argmax()
    fb = {1: fallback(vp), -1: fallback(vm)}
    def side_branch(sgn):
        o, T = side(sgn)
        def q0branch(q0):
            def t(q1):
                thr = T[(q0>0)*2 + (q1>0)] @ xx
                return (x2 > thr) if sgn==1 else (x2 < thr)
            test = lv1.cond(sx1, t(1), t(-1))
            return lv1.cond(test, o, fb[q0])
        return lv1.cond(sx0, q0branch(1), q0branch(-1))
    pred = lv1.cond(sx2, side_branch(1), side_branch(-1))
    return g.entry(interpretation=pred)
e = build(); save_entry("cascade_v4", e)
m = measure(e); print(m); print("nodes", len(e['nodes']))
