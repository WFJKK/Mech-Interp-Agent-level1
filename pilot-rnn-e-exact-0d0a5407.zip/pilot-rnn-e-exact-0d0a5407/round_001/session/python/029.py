
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm); recp=np.maximum(rec,0)
Q0=np.array([-1,-1,1,1.]); Q1=np.array([-1,1,-1,1.])
V = np.where(Q0[:,None]>0, vp[None,:], vm[None,:]); VQ=V*Q0[:,None]; WQ=w[None,:]*Q1[:,None]
ub0=V*(VQ>0); ub1=w[None,:]*(WQ>0); same=(VQ>=0)&(WQ>=0); lb0=V*same; lb1=w[None,:]*same
quadX = (X[:,0]>0).astype(int)*2+(X[:,1]>0).astype(int)
masks=np.array([[int(b) for b in np.binary_repr(i,4)] for i in range(16)],float)
def coefs(sgn,o,k):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0)
    useA=masks*(D>=0)[None,:]; DA=D[None,:]*useA
    m=DA@(sgn*w) - np.maximum(-D,0)@hb
    c=(np.maximum(-D,0)@recp)[None,:] - DA@rec
    cp=np.maximum(c,0); cn=np.maximum(-c,0)
    A=(cp@ub0.T-cn@lb0.T); B=(cp@ub1.T-cn@lb1.T)
    valid=m>0; Md=np.where(valid,m,1)
    Ap=np.where(valid[:,None], A*Q0[None,:]/Md[:,None], 1e9); Bp=np.where(valid[:,None], B*Q1[None,:]/Md[:,None], 1e9)
    return Ap,Bp
for mode in ["indep","joint"]:
    total=0
    for sgn in [1,-1]:
        hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
        s2=sgn*X[:,2]; pos=s2>0
        (A1,B1),(A2,B2)=[coefs(sgn,o,k) for k in ks]
        if mode=="indep":
            b1=(A1+B1).argmin(0); b2=(A2+B2).argmin(0)
            a=np.maximum(A1[b1,np.arange(4)],A2[b2,np.arange(4)]); b=np.maximum(B1[b1,np.arange(4)],B2[b2,np.arange(4)])
        else:
            AM=np.maximum(A1[:,None,:],A2[None,:,:]); BM=np.maximum(B1[:,None,:],B2[None,:,:])
            sc=(AM+BM).reshape(256,4); bi=sc.argmin(0)
            a=AM.reshape(256,4)[bi,np.arange(4)]; b=BM.reshape(256,4)[bi,np.arange(4)]
        thr=(a*Q0)[quadX]*X[:,0]+(b*Q1)[quadX]*X[:,1]
        ok=pos&(s2>thr); assert (Y[ok]==o).all(); total+=ok.mean()
    print(mode,total)
