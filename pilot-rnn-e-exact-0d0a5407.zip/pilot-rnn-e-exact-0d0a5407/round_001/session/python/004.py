
import numpy as np
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)   # u after step0 = x0*vp if x0>0 else x0*vm  (x0*vm = -|x0| rec@wm)
print("vp",vp,"vm",vm)
# bound test for x2 -> +inf
def side(sgn):
    hb = np.maximum(sgn*w,0)
    o = (R@hb).argmax()
    m = np.array([(R[o]-R[k])@hb for k in range(3) if k!=o])
    d = np.array([np.abs(R[o]-R[k]) for k in range(3) if k!=o])  # 2x4
    print("side",sgn,"o",o,"margins",m)
    mm = max(m.min(),0)
    # |u_j| <= sum_i |rec_ji| h1_i ; h1_i <= |w_i||x1| + max(|vp_i|,|vm_i|)|x0|
    e = (d@np.abs(rec)).max(axis=0)   # 4-vector: coefficient on h1
    a = e@np.maximum(np.abs(vp),np.abs(vm)); b = e@np.abs(w)
    print("e",e,"a",a,"b",b,"mm",mm)
    test1 = sgn*X[:,2]*mm > a*np.abs(X[:,0]) + b*np.abs(X[:,1])
    print("frac caught by cheap test:", test1.mean(), "correct:", (Y[test1]==o).all() if test1.any() else None)
    # tighter: exact h1
    v = np.where(X[:,0:1]>0, vp, vm)
    H1 = np.maximum(w*X[:,1:2] + v*X[:,0:1], 0)
    test2 = sgn*X[:,2]*mm > H1@e
    print("frac caught by h1 test:", test2.mean(), "correct:", (Y[test2]==o).all() if test2.any() else None)
    # exact with u
    U = H1@rec.T
    test3 = sgn*X[:,2]*mm > np.abs(U)@d.max(axis=0)
    print("frac caught by u test:", test3.mean(), "correct:", (Y[test3]==o).all() if test3.any() else None)
    return o
side(1); side(-1)
print("frac x2>0 & y==0", ((X[:,2]>0)&(Y==0)).mean())
