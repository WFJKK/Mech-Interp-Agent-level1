
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
ev = lv1.Evaluator(entries["cascade_v3"], weights, 3)
caught = np.array([ev.run(x)[3] < 20 for x in X])   # cheap path -> few ops
print("caught frac", caught.mean())
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm)
V = np.where(X[:,0:1]>0, vp, vm); H1=np.maximum(w*X[:,1:2]+V*X[:,0:1],0); U=H1@rec.T
P = w*X[:,2:3]+U; H2=np.maximum(P,0); L=H2@R.T
for sgn in [1,-1]:
    m = (~caught)&(sgn*X[:,2]>0)&(Y==0)
    print("side",sgn,"uncaught y=0 frac",m.mean())
    u,c=np.unique((H2[m]>0).astype(int),axis=0,return_counts=True)
    for uu,cc in zip(u,c): print("   h2 pattern",uu,cc)
    u,c=np.unique((H1[m]>0).astype(int),axis=0,return_counts=True)
    for uu,cc in zip(u,c): print("   h1 pattern",uu,cc)
    # margins
    print("   logit margins (L0-L1, L0-L2) quantiles", np.quantile(L[m,0]-L[m,1],[0.05,0.5]), np.quantile(L[m,0]-L[m,2],[0.05,0.5]))
    m2 = (~caught)&(sgn*X[:,2]>0)&(Y!=0)
    print("   uncaught y!=0 frac", m2.mean())
