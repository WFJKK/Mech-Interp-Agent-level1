
import numpy as np
print([n for n in dir(lv1) if not n.startswith('_')])
g = graph()
w = g.weight("input")[:,0]
print(type(w), w.shape, w.value)
R = g.weight("readout")
o = (R @ lv1.maximum(w,0.0)).argmax()
print(o.shape, o.value)
row = R[o]
print(row.shape, row.value)
print([n for n in dir(w) if not n.startswith('_')])
