
import numpy as np
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)
v = np.where(X[:,0:1]>0, vp, vm)
H1 = np.maximum(w*X[:,1:2] + v*X[:,0:1], 0)
def bounds(sgn):
    hb = np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    res={}
    for variant in ["A","B"]:
        C=[]; M=[]
        for k in ks:
            D=R[o]-R[k]
            useA = ((sgn*w>0)&(D>=0)).astype(float) if variant=="A" else np.zeros(4)
            m = (D*useA)@(sgn*w) - np.maximum(-D,0)@hb
            c = -(useA*D)@rec + (np.maximum(-D,0)[:,None]*np.maximum(rec,0)).sum(0)
            M.append(m); C.append(c)
        res[variant]=(np.array(M),np.array(C))
    return o,ks,res
pos = {1: X[:,2]>0, -1: X[:,2]<0}
for sgn in [1,-1]:
    o,ks,res=bounds(sgn)
    tests={}
    for variant,(M,C) in res.items():
        ok = pos[sgn].copy()
        for i in range(2):
            ok &= (sgn*X[:,2]*M[i] > H1@C[i])
        tests[variant]=ok
        print("side",sgn,variant,"catch", ok.mean(), (Y[ok]==o).all())
    okk=pos[sgn].copy()
    for i in range(2):
        okk &= (sgn*X[:,2]*res["A"][0][i] > H1@res["A"][1][i]) | (sgn*X[:,2]*res["B"][0][i] > H1@res["B"][1][i])
    print(" per-k OR catch", okk.mean(), (Y[okk]==o).all(), " of side total", pos[sgn].mean(), "y==o on side", ((Y==o)&pos[sgn]).mean())
    # cheap level: h1_i <= relu(w_i x1)+relu(v_i x0); bound C.h1 <= sum_i relu(C_i)*(...)  (C_i<0 -> 0)
    for variant,(M,C) in res.items():
        ok = pos[sgn].copy()
        for i in range(2):
            cp=np.maximum(C[i],0)
            B = np.where(X[:,0]>0, (cp@np.maximum(vp,0))*X[:,0], -(cp@np.maximum(-vm,0))*X[:,0]) + np.where(X[:,1]>0, (cp@np.maximum(w,0))*X[:,1], -(cp@np.maximum(-w,0))*X[:,1])
            ok &= sgn*X[:,2]*M[i] > B
        print("  cheap",variant,"catch",ok.mean(), (Y[ok]==o).all())
