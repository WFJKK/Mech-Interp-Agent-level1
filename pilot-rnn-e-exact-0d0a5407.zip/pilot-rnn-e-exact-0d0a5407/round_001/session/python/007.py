
import numpy as np
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)
v = np.where(X[:,0:1]>0, vp, vm)
H1 = np.maximum(w*X[:,1:2] + v*X[:,0:1], 0)
U = H1@rec.T
def bounds(sgn):
    hb = np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    res={}
    for variant in ["A","B"]:
        C=[]; M=[]
        for k in ks:
            D=R[o]-R[k]
            useA = ((sgn*w>0)&(D>=0)).astype(float) if variant=="A" else np.zeros(4)
            m = (D*useA)@hb   # margin only from units kept linear... careful
            # bound: D.h2 >= sum_{useA} D_j (w_j x2 + u_j) - sum_{D<0} |D_j| (relu(sgn w_j) |x2| + relu(u_j))
            m = (D*useA)@(sgn*w) - np.maximum(-D,0)@hb
            c = -(useA*D)@rec + (np.maximum(-D,0)[:,None]*np.maximum(rec,0)).sum(0)
            M.append(m); C.append(c)
        res[variant]=(np.array(M),np.array(C))
    return o,ks,res
for sgn in [1,-1]:
    o,ks,res=bounds(sgn)
    tests={}
    for variant,(M,C) in res.items():
        print("side",sgn,variant,"M",M)
        print("  C",C)
        ok = np.ones(len(X),bool)
        for i in range(2):
            ok &= (sgn*X[:,2]*M[i] > H1@C[i])
        tests[variant]=ok
        print("  catch", ok.mean(), (Y[ok]==o).all())
    both = tests["A"]|tests["B"]
    print(" OR catch", both.mean(), (Y[both]==o).all())
    # mixed: per k choose best? per k, OR of A and B
    okk=np.ones(len(X),bool)
    for i in range(2):
        okk &= (sgn*X[:,2]*res["A"][0][i] > H1@res["A"][1][i]) | (sgn*X[:,2]*res["B"][0][i] > H1@res["B"][1][i])
    print(" per-k OR catch", okk.mean(), (Y[okk]==o).all())
