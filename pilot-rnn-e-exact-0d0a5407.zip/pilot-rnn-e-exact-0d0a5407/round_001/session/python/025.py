
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm); recp=np.maximum(rec,0)
def mc(sgn,o,k,S):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0); useA=np.zeros(4); useA[list(S)]=1
    m=(D*useA)@(sgn*w) - np.maximum(-D,0)@hb
    c=-(useA*D)@rec + (np.maximum(-D,0)[:,None]*recp).sum(0)
    return m,c
def evaluate(ratios):
    # sectors: quadrant x ratio bins on |x1|/|x0| with boundaries ratios (list), e.g. [1.0] -> 2 bins
    bounds=[0.0]+list(ratios)+[np.inf]
    nb=len(bounds)-1
    r = np.abs(X[:,1])/np.maximum(np.abs(X[:,0]),1e-300)
    binX = np.clip(np.searchsorted(bounds, r, side='right')-1, 0, nb-1)
    sec = ((X[:,0]>0).astype(int)*2+(X[:,1]>0).astype(int))*nb + binX
    nsec=4*nb
    # per sector coefficient structures
    q0=np.repeat([-1,-1,1,1.],nb); q1=np.repeat([-1,1,-1,1.],nb)
    lo=np.tile(bounds[:-1],4); hi=np.tile(bounds[1:],4)   # |x1| in [lo|x0|, hi|x0|]
    V=np.where(q0[:,None]>0, vp[None,:], vm[None,:]); VQ=V*q0[:,None]; WQ=w[None,:]*q1[:,None]
    # Z_i = WQ|x1| + VQ|x0|; with |x1| in [lo,hi]|x0|: Z>=0 guaranteed if min over range >=0
    with np.errstate(invalid='ignore'):
        zmin = np.minimum(WQ*lo[:,None], np.where(np.isinf(hi)[:,None], np.where(WQ<0,-np.inf,0)*1.0, WQ*hi[:,None]))+VQ
        zmax = np.maximum(WQ*lo[:,None], np.where(np.isinf(hi)[:,None], np.where(WQ>0,np.inf,0)*1.0, WQ*hi[:,None]))+VQ
    zmin=np.nan_to_num(zmin, nan=0.0); zmax=np.nan_to_num(zmax,nan=0.0)
    posg = zmin>=0; negg = zmax<=0
    ub0 = np.where(negg, 0.0, V*(VQ>0)); ub1=np.where(negg,0.0, w[None,:]*(WQ>0))
    ub0 = np.where(posg, V, ub0); ub1=np.where(posg, w[None,:], ub1)
    lb0 = np.where(posg, V, 0.0); lb1=np.where(posg, w[None,:], 0.0)
    total=0
    for sgn in [1,-1]:
        hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
        s2=sgn*X[:,2]; pos=s2>0
        thr_comb=np.zeros(len(X))
        for k in ks:
            D=R[o]-R[k]; Dpos=[j for j in range(4) if D[j]>=0]
            subsets=[S for r_ in range(len(Dpos)+1) for S in itertools.combinations(Dpos,r_)]
            Ap=[];Bp=[]
            for S in subsets:
                m,c=mc(sgn,o,k,S); cp=np.maximum(c,0); cn=np.maximum(-c,0)
                A=(ub0@cp-lb0@cn); B=(ub1@cp-lb1@cn)
                if m>0: Ap.append(A*q0/m); Bp.append(B*q1/m)
                else: Ap.append(np.full(nsec,1e9)); Bp.append(np.full(nsec,1e9))
            Ap=np.array(Ap); Bp=np.array(Bp)
            # proxy: expected threshold within sector ~ a*E|x0| + b*E|x1| ; use sector-conditional means via sample
            score = Ap+Bp
            bi=score.argmin(0)
            thr = (Ap[bi,np.arange(nsec)]*q0)[sec]*X[:,0] + (Bp[bi,np.arange(nsec)]*q1)[sec]*X[:,1]
            thr_comb=np.maximum(thr_comb,thr)
        ok=pos&(s2>thr_comb); total+=ok.mean()
        assert (Y[ok]==o).all(), "invalid"
    return total
print("4 sectors", evaluate([]))
print("8 sectors (ratio 1)", evaluate([1.0]))
print("12 sectors", evaluate([0.5,2.0]))
print("16 sectors", evaluate([0.5,1.0,2.0]))
print("20 sectors", evaluate([0.33,0.66,1.5,3.0]))
