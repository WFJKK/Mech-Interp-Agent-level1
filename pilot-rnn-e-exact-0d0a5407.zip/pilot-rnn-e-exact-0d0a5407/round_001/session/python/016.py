
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm); recp=np.maximum(rec,0)
q0s=np.sign(X[:,0]); q1s=np.sign(X[:,1])
V = np.where(q0s[:,None]>0, vp[None,:], vm[None,:])
VQ=V*q0s[:,None]; WQ=w[None,:]*q1s[:,None]
ub0=V*(VQ>0); ub1=w[None,:]*(WQ>0); same=(VQ>=0)&(WQ>=0); lb0=V*same; lb1=w[None,:]*same
H1 = np.maximum(w*X[:,1:2]+V*X[:,0:1],0)
def mc(sgn,o,k,S):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0); useA=np.zeros(4); useA[list(S)]=1
    m=(D*useA)@(sgn*w) - np.maximum(-D,0)@hb
    c=-(useA*D)@rec + (np.maximum(-D,0)[:,None]*recp).sum(0)
    return m,c
def cheap_test(sgn,m,c):
    cp=np.maximum(c,0); cn=np.maximum(-c,0)
    thr = (ub0@cp - lb0@cn)*X[:,0] + (ub1@cp - lb1@cn)*X[:,1]
    return (sgn*X[:,2]>0) & (sgn*X[:,2]*m > thr)
def h1_test(sgn,m,c):
    return (sgn*X[:,2]>0) & (sgn*X[:,2]*m > H1@c)
for sgn in [1,-1]:
    hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    per_k={}
    for k in ks:
        D=R[o]-R[k]; Dpos=[j for j in range(4) if D[j]>=0]
        SA=tuple(j for j in Dpos if sgn*w[j]>0)
        print("side",sgn,"k",k,"D",np.round(D,3),"A=",SA)
        res={}
        for r in range(len(Dpos)+1):
            for S in itertools.combinations(Dpos,r):
                m,c=mc(sgn,o,k,S)
                res[S]=(cheap_test(sgn,m,c), h1_test(sgn,m,c))
                print("   S",S,"m",round(m,3),"cheap",round(res[S][0].mean(),4),"h1",round(res[S][1].mean(),4))
        per_k[k]=res
    # best combos: for each k pick 1 or 2 subsets, AND over k
    best=None
    for S1 in per_k[ks[0]]:
        for S2 in per_k[ks[1]]:
            v=(per_k[ks[0]][S1][0]&per_k[ks[1]][S2][0]).mean()
            if best is None or v>best[0]: best=(v,S1,S2)
    print(" best single-subset per k (cheap):",best)
    best2=None
    for S1 in itertools.combinations(per_k[ks[0]],2):
        for S2 in itertools.combinations(per_k[ks[1]],2):
            v=((per_k[ks[0]][S1[0]][0]|per_k[ks[0]][S1[1]][0])&(per_k[ks[1]][S2[0]][0]|per_k[ks[1]][S2[1]][0])).mean()
            if best2 is None or v>best2[0]: best2=(v,S1,S2)
    print(" best two-subsets per k (cheap):",best2)
