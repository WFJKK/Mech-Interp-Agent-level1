
import numpy as np, json
def build(use_fallback=True):
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    wp = lv1.maximum(w,0.0); wm = lv1.maximum(-w,0.0)
    vp = rec@wp; vm = -(rec@wm)
    recp = lv1.maximum(rec,0.0)
    ks = g.arange(3)
    Q0 = g.const(np.array([-1.0,-1.0,1.0,1.0])); Q1 = g.const(np.array([-1.0,1.0,-1.0,1.0]))
    V = lv1.where((Q0>0.0)[:,None], vp[None,:], vm[None,:])      # (4 quad, 4 unit)
    VQ = V*Q0[:,None]; WQ = w[None,:]*Q1[:,None]
    ub0 = V*lv1.cast(VQ>0.0,"float"); ub1 = w[None,:]*lv1.cast(WQ>0.0,"float")
    same = lv1.cast((VQ>=0.0)&(WQ>=0.0),"float")
    lb0 = V*same; lb1 = w[None,:]*same
    def side(sgn):
        sw = w*sgn
        hb = lv1.maximum(sw,0.0)
        o = (R@hb).argmax()
        D = R[o][None,:] - R            # 3x4
        useA = lv1.cast((sw>0.0)[None,:] & (D>=0.0), "float")
        DA = D*useA
        Dn = lv1.maximum(-D,0.0)
        m = DA@sw - Dn@hb                 # 3
        c = -(DA@rec) + Dn@recp           # 3x4
        cp = lv1.maximum(c,0.0); cn = lv1.maximum(-c,0.0)
        valid = m>0.0
        Md = lv1.where(valid, m, 1.0)
        isO = ks==o
        A = (cp@ub0.T - cn@lb0.T)/Md[:,None]     # (3 k, 4 quad)
        B = (cp@ub1.T - cn@lb1.T)/Md[:,None]
        def star(A, Q):
            AQ = A*Q[None,:]
            AQ = lv1.where(valid[:,None], AQ, 1e9)
            AQ = lv1.where(isO[:,None], -1e9, AQ)
            return AQ.max(axis=0)*Q
        T = lv1.stack([star(A,Q0), star(B,Q1)], axis=1)   # (4 quad, 2)
        if sgn==-1: T = -T
        return o, T.reshape(2,2,2)
    sx0 = x0>0.0; sx1 = x1>0.0; sx2 = x2>0.0
    i0 = lv1.cast(sx0,"int"); i1 = lv1.cast(sx1,"int")
    xx = lv1.stack([x0,x1])
    def fallback():
        v = lv1.cond(sx0, vp, vm)
        h1 = lv1.maximum(lv1.stack([w,v],axis=1) @ lv1.stack([x1,x0]), 0.0)
        p = lv1.concat([rec, w[:,None]], axis=1) @ lv1.concat([h1, lv1.stack([x2])])
        h2 = lv1.maximum(p, 0.0)
        return (R@h2).argmax()
    def branch(sgn):
        o, T = side(sgn)
        coef = T[i0, i1]
        thr = coef @ xx
        test = (x2 > thr) if sgn==1 else (x2 < thr)
        if use_fallback:
            return lv1.cond(test, o, fallback()), test
        return o, test
    outp, tp = branch(1); outm, tm = branch(-1)
    pred = lv1.cond(sx2, outp, outm)
    if use_fallback:
        return g.entry(interpretation=pred)
    region = lv1.where(sx2, tp, tm)
    return g.entry(interpretation=pred, region=region)
e1 = build(True); save_entry("cascade_v3", e1)
m1 = measure(e1); print(m1)
print("nodes", len(e1['nodes']))
e2 = build(False); print(measure(e2))
