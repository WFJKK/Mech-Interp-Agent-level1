
import inspect
for name in ["Evaluator","measure","run_reference","apply","Graph.load","Graph.__init__","draw_inputs","real_inputs","all_inputs"]:
    obj = lv1
    for part in name.split("."): obj = getattr(obj, part)
    try:
        print(name, inspect.signature(obj))
    except Exception as ex: print(name, ex)
print(inspect.getsource(lv1.measure)[:3000])
