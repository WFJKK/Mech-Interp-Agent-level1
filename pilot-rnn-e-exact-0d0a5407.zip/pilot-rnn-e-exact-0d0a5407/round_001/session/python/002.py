
X, Y, ops = no
X=np.array(X); Y=np.array(Y)
print(X.shape, Y.shape, ops)
print(np.bincount(Y))
# simple stats
for name, f in [("sign x2", X[:,2]>0), ("sign x1", X[:,1]>0), ("sign x0", X[:,0]>0)]:
    for v in [False, True]:
        m = f==v
        print(name, v, np.bincount(Y[m], minlength=3)/m.sum())
# fit: logistic? first look at relation with x2 only
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
def fwd(x):
    h=np.maximum(w*x[0],0)
    for t in range(1,3): h=np.maximum(w*x[t]+rec@h,0)
    return (R@h).argmax(), h
print(sum(fwd(x)[0]==y for x,y in zip(X,Y))/len(Y))
# how often is h after step1 all zero, etc.
H1 = []
for x in X:
    h=np.maximum(w*x[0],0); h=np.maximum(w*x[1]+rec@h,0); H1.append(h)
H1=np.array(H1)
print("active pattern counts step1:", np.unique((H1>0).astype(int), axis=0, return_counts=True))
