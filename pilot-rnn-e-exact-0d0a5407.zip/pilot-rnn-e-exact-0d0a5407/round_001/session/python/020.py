
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm); recp=np.maximum(rec,0)
Q0=np.array([-1,-1,1,1.]); Q1=np.array([-1,1,-1,1.])
V = np.where(Q0[:,None]>0, vp[None,:], vm[None,:]); VQ=V*Q0[:,None]; WQ=w[None,:]*Q1[:,None]
ub0=V*(VQ>0); ub1=w[None,:]*(WQ>0); same=(VQ>=0)&(WQ>=0); lb0=V*same; lb1=w[None,:]*same
quadX = (X[:,0]>0).astype(int)*2+(X[:,1]>0).astype(int)
Vx = np.where(X[:,0:1]>0, vp, vm); H1=np.maximum(w*X[:,1:2]+Vx*X[:,0:1],0)
def mc(sgn,o,k,S):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0); useA=np.zeros(4); useA[list(S)]=1
    m=(D*useA)@(sgn*w) - np.maximum(-D,0)@hb
    c=-(useA*D)@rec + (np.maximum(-D,0)[:,None]*recp).sum(0)
    return m,c
for sgn in [1,-1]:
    hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    s2=sgn*X[:,2]; pos=s2>0
    for k in ks:
        D=R[o]-R[k]; Dpos=[j for j in range(4) if D[j]>=0]
        for r in range(len(Dpos)+1):
            for S in itertools.combinations(Dpos,r):
                m,c=mc(sgn,o,k,S); cp=np.maximum(c,0); cn=np.maximum(-c,0)
                A=(ub0@cp-lb0@cn); B=(ub1@cp-lb1@cn)
                thr = A[quadX]*X[:,0]+B[quadX]*X[:,1]
                # check bound validity: thr >= c.h1 ?
                viol = (thr < H1@c - 1e-9)
                okt = pos & (s2*m > thr)
                wrong = okt & (Y!=o)
                if viol.any() or wrong.any():
                    print("side",sgn,"k",k,"S",S,"m",round(m,4),"bound violations",viol.sum(),"wrong",wrong.sum(), "c",np.round(c,3))
                    # also check h1-level test wrongness
                    okh = pos & (s2*m > H1@c); print("    h1-level wrong:", (okh&(Y!=o)).sum())
