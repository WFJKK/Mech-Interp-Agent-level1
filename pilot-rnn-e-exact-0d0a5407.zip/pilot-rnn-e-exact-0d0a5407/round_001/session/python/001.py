
import numpy as np
print({k:(v.shape) for k,v in weights.items()})
for k,v in weights.items(): print(k); print(np.round(v,4))
print(info)
no = network_outputs()
print(type(no), (no.keys() if isinstance(no,dict) else len(no)))
