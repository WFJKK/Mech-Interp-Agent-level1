
import numpy as np, itertools
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0); vp=rec@wp; vm=-(rec@wm); recp=np.maximum(rec,0)
def quad_coefs(Xs):
    q0s=np.sign(Xs[:,0]); q1s=np.sign(Xs[:,1])
    V = np.where(q0s[:,None]>0, vp[None,:], vm[None,:])
    VQ=V*q0s[:,None]; WQ=w[None,:]*q1s[:,None]
    ub0=V*(VQ>0); ub1=w[None,:]*(WQ>0); same=(VQ>=0)&(WQ>=0); lb0=V*same; lb1=w[None,:]*same
    return ub0,ub1,lb0,lb1
def mc(sgn,o,k,S):
    D=R[o]-R[k]; hb=np.maximum(sgn*w,0); useA=np.zeros(4); useA[list(S)]=1
    m=(D*useA)@(sgn*w) - np.maximum(-D,0)@hb
    c=-(useA*D)@rec + (np.maximum(-D,0)[:,None]*recp).sum(0)
    return m,c
def thr_norm(Xs, m, c):   # normalized threshold (x2 > thr) or inf if invalid
    ub0,ub1,lb0,lb1 = quad_coefs(Xs)
    cp=np.maximum(c,0); cn=np.maximum(-c,0)
    thr = (ub0@cp - lb0@cn)*Xs[:,0] + (ub1@cp - lb1@cn)*Xs[:,1]
    if m<=0: return np.full(len(Xs), np.inf)
    return thr/m
# probes: Kronecker sequence on cube
P=512
i=np.arange(1,P+1)
alpha=np.array([0.7548776662, 0.5698402910, 0.3287441900])
probes = 2*((i[:,None]*alpha[None,:])%1)-1
def sel_table(Xs):
    # returns per side: dict quad-> combined threshold function params? we just compute catch on X using best subsets selected on Xs
    total=0
    for sgn in [1,-1]:
        hb=np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
        s2=sgn*X[:,2]; pos=s2>0
        quadX = (X[:,0]>0).astype(int)*2+(X[:,1]>0).astype(int)
        quadP = (Xs[:,0]>0).astype(int)*2+(Xs[:,1]>0).astype(int)
        thr_comb = np.zeros(len(X))
        for k in ks:
            D=R[o]-R[k]; Dpos=[j for j in range(4) if D[j]>=0]
            subsets=[S for r in range(len(Dpos)+1) for S in itertools.combinations(Dpos,r)]
            # probe thresholds
            thrP = np.array([thr_norm(Xs, *mc(sgn,o,k,S)) for S in subsets])   # (nS, P)
            thrX = np.array([thr_norm(X, *mc(sgn,o,k,S)) for S in subsets])
            # per quadrant best subset: maximize count of probes with sgn*x2 > thr (probe x2 sign side)
            s2P = sgn*Xs[:,2]
            best_thr = np.zeros(len(X))
            for q in range(4):
                mq = quadP==q
                score = ((s2P[None,mq] > thrP[:,mq])&(s2P[None,mq]>0)).sum(1)
                bi = score.argmax()
                best_thr[quadX==q] = thrX[bi, quadX==q]
            thr_comb = np.maximum(thr_comb, best_thr)
        ok = pos & (s2 > thr_comb)
        print("side",sgn,"catch",ok.mean(),(Y[ok]==o).all())
        total+=ok.mean()
    print("total",total)
print("selected on probes:"); sel_table(probes)
print("selected on gaussian sample (upper est):"); sel_table(X[:4000])
