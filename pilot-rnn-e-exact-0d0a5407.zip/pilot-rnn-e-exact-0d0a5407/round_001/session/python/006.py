
import numpy as np
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)
v = np.where(X[:,0:1]>0, vp, vm)
H1 = np.maximum(w*X[:,1:2] + v*X[:,0:1], 0)
U = H1@rec.T
def fwd_x2(x0,x1,x2s):
    h=np.maximum(w*x0,0); h=np.maximum(w*x1+rec@h,0)
    P = w[None,:]*x2s[:,None] + (rec@h)[None,:]
    return (np.maximum(P,0)@R.T).argmax(1)
# exact threshold T for x2>0 side: smallest t such that output==0 for all x2>t (on a grid)
grid = np.linspace(0,6,601)
T=[]
for i in range(2000):
    out = fwd_x2(X[i,0],X[i,1],grid)
    bad = np.where(out!=0)[0]
    T.append(grid[bad.max()] if len(bad) else 0.0)
T=np.array(T)
print("T quantiles", np.quantile(T,[0.5,0.9,0.99,1]))
print("frac T==0:", (T==0).mean())
def side(sgn):
    hb = np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    C=[]; M=[]
    for k in ks:
        D=R[o]-R[k]; m=D@hb; M.append(m)
        c = -((w*sgn>0)&(D>=0))*D@rec + (np.maximum(-D,0)[:,None]*np.maximum(rec,0)).sum(0)
        C.append(c)
    C=np.array(C); M=np.array(M)
    Cp = C/np.maximum(M,1e-12)[:,None]; cc=Cp.max(0)
    print("side",sgn,"M",M,"cc",cc)
    th = sgn*X[:,2] > H1@cc
    print(" h1 test catch", th.mean(), (Y[th]==o).all())
    ccp=np.maximum(cc,0)
    ap = ccp@np.maximum(vp,0); am = ccp@np.maximum(-vm,0); bp = ccp@np.maximum(w,0); bm = ccp@np.maximum(-w,0)
    B = np.where(X[:,0]>0, ap*X[:,0], -am*X[:,0]) + np.where(X[:,1]>0, bp*X[:,1], -bm*X[:,1])
    tc = sgn*X[:,2] > B
    print(" cheap signed catch", tc.mean(), (Y[tc]==o).all(), ap,am,bp,bm)
    if sgn==1:
        print(" bound vs exact T: B>=T?", (B[:2000]>=T).all(), "median gap", np.median(B[:2000]-T))
side(1); side(-1)
