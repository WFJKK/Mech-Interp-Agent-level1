
import numpy as np, json, itertools
def build():
    g = graph()
    w = g.weight("input")[:,0]; rec = g.weight("recurrent"); R = g.weight("readout")
    x0,x1,x2 = g.token(0), g.token(1), g.token(2)
    wp = lv1.maximum(w,0.0); wm = lv1.maximum(-w,0.0)
    vp = rec@wp; vm = -(rec@wm)
    recp = lv1.maximum(rec,0.0)
    Q0 = g.const(np.array([-1.0,-1.0,1.0,1.0])); Q1 = g.const(np.array([-1.0,1.0,-1.0,1.0]))
    masks = g.const(np.array([[float(b) for b in np.binary_repr(i,4)] for i in range(16)]))  # (16,4)
    oth = g.const(np.array([[1,2],[0,2],[0,1]]))   # rows: the two k != o
    V = lv1.where((Q0>0.0)[:,None], vp[None,:], vm[None,:])      # (4 quad, 4 unit)
    VQ = V*Q0[:,None]; WQ = w[None,:]*Q1[:,None]
    ub0 = V*lv1.cast(VQ>0.0,"float"); ub1 = w[None,:]*lv1.cast(WQ>0.0,"float")
    same = lv1.cast((VQ>=0.0)&(WQ>=0.0),"float")
    lb0 = V*same; lb1 = w[None,:]*same
    UB = lv1.concat([ub0, ub1], axis=0)    # (8, 4): rows 0-3 quad coef on x0, rows 4-7 on x1
    LB = lv1.concat([lb0, lb1], axis=0)
    QQ = lv1.concat([Q0, Q1])               # (8,)
    nS = g.arange(16)
    def side(sgn):
        sw = w*sgn
        hb = lv1.maximum(sw,0.0)
        o = (R@hb).argmax()
        Ro = R[o]                        # (4,)
        Rk = R[oth[o]]                   # (2,4)
        D = Ro[None,:] - Rk              # (2,4)
        useA = masks[:,None,:]*lv1.cast(D>=0.0,"float")[None,:,:]    # (16,2,4)
        DA = D[None,:,:]*useA
        Dn = lv1.maximum(-D,0.0)        # (2,4)
        m = DA@sw - (Dn@hb)[None,:]     # (16,2)
        c = (Dn@recp)[None,:,:] - DA@rec   # (16,2,4)
        cp = lv1.maximum(c,0.0); cn = lv1.maximum(-c,0.0)
        valid = m>0.0
        Md = lv1.where(valid, m, 1.0)
        AB = (cp@UB.T - cn@LB.T)/Md[:,:,None]     # (16,2,8)
        ABp = lv1.where(valid[:,:,None], AB*QQ[None,None,:], 1e9)   # coefficients on |x0| (0-3), |x1| (4-7)
        score = ABp[:,:,0:4] + ABp[:,:,4:8]       # (16,2,4)
        bi = score.argmin(axis=0)                 # (2,4)
        sel = lv1.cast(nS[:,None,None] == bi[None,:,:], "float")   # (16,2,4)
        ABs = (ABp*lv1.concat([sel,sel],axis=2)).sum(axis=0)       # (2,8)
        star = ABs.max(axis=0)*QQ                 # (8,) coefficients on x0 (quad 0-3), x1 (quad 0-3)
        T = lv1.stack([star[0:4], star[4:8]], axis=1)   # (4 quad, 2)
        if sgn==-1: T = -T
        return o, T
    sx0 = x0>0.0; sx1 = x1>0.0; sx2 = x2>0.0
    xx = lv1.stack([x0,x1])
    Wrec = lv1.concat([rec, w[:,None]], axis=1)
    def fallback(v):
        h1 = lv1.maximum(lv1.stack([w,v],axis=1) @ lv1.stack([x1,x0]), 0.0)
        p = Wrec @ lv1.concat([h1, lv1.stack([x2])])
        h2 = lv1.maximum(p, 0.0)
        return (R@h2).argmax()
    fb = {1: fallback(vp), -1: fallback(vm)}
    def side_branch(sgn):
        o, T = side(sgn)
        def q0branch(q0):
            def t(q1):
                thr = T[(q0>0)*2 + (q1>0)] @ xx
                return (x2 > thr) if sgn==1 else (x2 < thr)
            test = lv1.cond(sx1, t(1), t(-1))
            return lv1.cond(test, o, fb[q0])
        return lv1.cond(sx0, q0branch(1), q0branch(-1))
    pred = lv1.cond(sx2, side_branch(1), side_branch(-1))
    return g.entry(interpretation=pred)
e = build(); save_entry("cascade_v5", e)
m = measure(e); print(m); print("nodes", len(e['nodes']))
