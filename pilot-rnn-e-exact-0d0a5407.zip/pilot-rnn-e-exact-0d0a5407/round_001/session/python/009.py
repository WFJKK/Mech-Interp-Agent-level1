
import numpy as np
X, Y, ops = network_outputs(); X=np.array(X); Y=np.array(Y)
w=weights['input'][:,0]; rec=weights['recurrent']; R=weights['readout']
wp=np.maximum(w,0); wm=np.maximum(-w,0)
vp=rec@wp; vm=-(rec@wm)
def bounds(sgn):
    hb = np.maximum(sgn*w,0); o=(R@hb).argmax(); ks=[k for k in range(3) if k!=o]
    C=[]; M=[]
    for k in ks:
        D=R[o]-R[k]
        useA = ((sgn*w>0)&(D>=0)).astype(float)
        m = (D*useA)@(sgn*w) - np.maximum(-D,0)@hb
        c = -(useA*D)@rec + (np.maximum(-D,0)[:,None]*np.maximum(rec,0)).sum(0)
        M.append(m); C.append(c)
    return o,np.array(M),np.array(C)
pos = {1: X[:,2]>0, -1: X[:,2]<0}
tot={}
for sgn in [1,-1]:
    o,M,C=bounds(sgn)
    cp=np.maximum(C,0)  # 2x4
    # per quadrant coefficients, normalized by M
    ap = (cp@np.maximum(vp,0))/M; am=(cp@np.maximum(-vm,0))/M; bp=(cp@np.maximum(w,0))/M; bm=(cp@np.maximum(-w,0))/M
    print("side",sgn,"o",o,"M",M, "ap,am,bp,bm", ap,am,bp,bm)
    q0 = np.where(X[:,0]>0, X[:,0], 0); q0m=np.where(X[:,0]>0,0,-X[:,0]); q1=np.where(X[:,1]>0,X[:,1],0); q1m=np.where(X[:,1]>0,0,-X[:,1])
    s2 = sgn*X[:,2]
    V1 = pos[sgn] & np.all([s2 > ap[i]*q0+am[i]*q0m+bp[i]*q1+bm[i]*q1m for i in range(2)],axis=0)
    V2 = pos[sgn] & (s2 > ap.max()*q0+am.max()*q0m+bp.max()*q1+bm.max()*q1m)
    V3 = pos[sgn] & (s2 > max(ap.max(),am.max())*np.abs(X[:,0]) + max(bp.max(),bm.max())*np.abs(X[:,1]))
    V4 = pos[sgn] & np.all([s2 > max(ap[i],am[i])*np.abs(X[:,0]) + max(bp[i],bm[i])*np.abs(X[:,1]) for i in range(2)],axis=0)
    for n,Vv in [("V1",V1),("V2",V2),("V3",V3),("V4",V4)]:
        print(" ",n,Vv.mean(),(Y[Vv]==o).all()); tot[n]=tot.get(n,0)+Vv.mean()
print(tot)
