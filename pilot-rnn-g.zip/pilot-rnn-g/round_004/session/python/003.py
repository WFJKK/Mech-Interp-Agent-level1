
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
s = json.dumps(e)
print(len(s))
# print constants
nodes = e.get('nodes', e)
cnt=0
for i,n in enumerate(nodes if isinstance(nodes,list) else []):
    if n.get('op')=='const' or 'value' in n:
        print(i, n); cnt+=1
    if cnt>40: break
print(str(e)[:3000])
