
f23 = np.array([0.03614968879534096, 0.033, 0.027609780875624497, 0.027609780875624497, 0.03042449670906653, 0.033, 0.03614968879534096, 0.03904612656845746, 0.033, 0.033])
g23 = m2 - np.maximum(m3, 0); g12 = m1 - m2
z23 = g23 < np.maximum(1.1*f23[p2]*m1, 0.03)
z12 = g12 < 0.022*m1
zneg = m2 < 0
zone = z23 | z12 | zneg
print("zone frac", zone.mean(), "z23", z23.mean(), "z12", z12.mean(), "zneg", zneg.mean())
print("err outside zone", (y[~zone] != p2[~zone]).mean(), "overall err of hybrid", (y[~zone] != p2[~zone]).sum()/len(y))
p4 = o[:,3]
for name, s in [("zone", zone), ("z23 only", z23 & ~z12 & ~zneg), ("z12 only", z12 & ~z23 & ~zneg), ("zneg", zneg)]:
    yy, a, b, c, d = y[s], p1[s], p2[s], p3[s], p4[s]
    print(name, s.mean(), "y in p1p2p3:", ((yy==a)|(yy==b)|(yy==c)).mean(), "y in p2p3:", ((yy==b)|(yy==c)).mean(), "y in p1p2:", ((yy==a)|(yy==b)).mean(), "in top4", ((yy==a)|(yy==b)|(yy==c)|(yy==d)).mean())
