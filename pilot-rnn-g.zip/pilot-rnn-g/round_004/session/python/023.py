
import inspect
no = network_outputs()
print(type(no), (list(no.keys()) if isinstance(no, dict) else len(no)))
print(inspect.signature(lv1.measure)); print(inspect.getsource(lv1.measure)[:2500])
print(inspect.signature(lv1.Evaluator)); print([a for a in dir(lv1.Evaluator) if not a.startswith('_')])
