
import numpy as np, time, gc
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
def feats(X):
    N=len(X); y = fwd(X); ar = np.arange(N)
    o = np.argsort(-X, axis=1); S = -np.sort(-X,axis=1); m1 = S[:,0]
    p1,p2,p3 = o[:,0],o[:,1],o[:,2]; del o
    F = {'p1':p1.astype(np.int8),'p2':p2.astype(np.int8),'p3':p3.astype(np.int8),'m1':m1,'m2':S[:,1],'m3':S[:,2]}
    F['g23'] = ((F['m2']-np.maximum(F['m3'],0))/m1).astype(np.float32); F['g12']=((m1-F['m2'])/m1).astype(np.float32)
    F['sum'] = (X.sum(1)/m1).astype(np.float32); F['err'] = y != p2
    Xn = (X/m1[:,None]).astype(np.float32); del S
    for nm,p in [('1',p1),('2',p2),('3',p3)]:
        F['l'+nm] = Xn[ar,(p+9)%10]; F['r'+nm] = Xn[ar,(p+1)%10]
    cs = np.cumsum(Xn,1)
    F['b2'] = cs[ar,p2]-Xn[ar,p2]; F['b3'] = cs[ar,p3]-Xn[ar,p3]; del cs
    mx = np.maximum(Xn,0); cs = np.cumsum(mx,1); F['b2p'] = cs[ar,p2]-mx[ar,p2]; F['b3p'] = cs[ar,p3]-mx[ar,p3]
    del mx, cs, Xn; gc.collect()
    return F
def onehot(v, n=10):
    oh = np.zeros((len(v),n), dtype=np.float32); oh[np.arange(len(v)), v.astype(int)] = 1; return oh
def design(F, s, extra=()):
    n = s.sum(); lg = np.log(F['g23'][s]+1e-4); lg12 = np.log(F['g12'][s]+1e-4)
    r2 = (F['m2'][s]/F['m1'][s]).astype(np.float32); neg = (F['m3'][s]<0).astype(np.float32)
    cols = [np.ones(n,np.float32), lg, F['g23'][s], lg12, F['g12'][s], r2, F['sum'][s], neg, lg*lg12,
            onehot(F['p2'][s].astype(int)*10+F['p3'][s], 100), onehot(F['p1'][s].astype(int)*10+F['p2'][s], 100)]
    for ex in extra: cols.append(F[ex][s])
    return np.column_stack(cols)
def fit_logistic(A, t, l2=1e-2, iters=12):
    beta = np.zeros(A.shape[1], np.float32); n=len(A); C=150000
    for it in range(iters):
        H = l2*np.eye(A.shape[1]); g = l2*beta.astype(np.float64)
        for i in range(0,n,C):
            Ai = A[i:i+C]; p = 1/(1+np.exp(-(Ai@beta))); W = (p*(1-p)).astype(np.float32)
            H += (Ai*W[:,None]).T@Ai; g += Ai.T@(p-t[i:i+C]).astype(np.float32)
        beta = (beta - np.linalg.solve(H, g)).astype(np.float32)
    return beta
LO23, LO12, HI23, HI12 = 0.015, 0.008, 0.1, 0.08
def evband(F): return (F['m2']>0)&(F['g23']>=LO23)&(F['g12']>=LO12)&((F['g23']<HI23)|(F['g12']<HI12))
rng = np.random.default_rng(21)
Ftr = feats(rng.standard_normal((1200000,10))); str_ = evband(Ftr); ttr = Ftr['err'][str_].astype(np.float32)
Fte = feats(rng.standard_normal((1000000,10))); ste = evband(Fte)
e = Fte['err']; sure = (Fte['m2']<0)|(Fte['g23']<LO23)|(Fte['g12']<LO12)
FB=0.716; EC=10.9; OPS=2937
def total(zone, evaluated, model_ops):
    r = 1 - 59/OPS - evaluated*(model_ops+1)/OPS - np.where(zone, FB, EC*e)
    return r.mean()
for extra, mops in [((),36), (('l2','r2'),44), (('l3','r3'),44), (('l1','r1'),44), (('l2','r2','l3','r3'),52), (('b2','b3'),52), (('b2p','b3p'),64), (('l2','r2','l3','r3','b2','b3'),68)]:
    A = design(Ftr, str_, extra); beta = fit_logistic(A, ttr); del A; gc.collect()
    Ate = design(Fte, ste, extra); pte = np.zeros(len(e)); pte[ste] = 1/(1+np.exp(-(Ate@beta))); del Ate; gc.collect()
    res = max((round(total(sure | (ste & (pte>thr)), ste, mops),5), thr) for thr in [0.05,0.055,0.06])
    print(extra, len(beta), res)
