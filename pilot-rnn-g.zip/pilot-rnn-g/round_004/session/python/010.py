
import numpy as np, time
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+200000]) for i in range(0,len(X),200000)])
def feats(X):
    N=len(X); y = fwd(X)
    o = np.argsort(-X, axis=1)
    p1, p2, p3, p4 = o[:,0], o[:,1], o[:,2], o[:,3]
    ar = np.arange(N)
    m1 = X[ar, p1]; m2 = X[ar, p2]; m3 = X[ar, p3]; m4 = X[ar,p4]
    g23 = (m2 - np.maximum(m3, 0))/m1; g12 = (m1 - m2)/m1; g34 = (np.maximum(m3,0)-np.maximum(m4,0))/m1
    sneg = np.minimum(X,0).sum(1)/m1
    err = (y != p2)
    return {'p1':p1,'p2':p2,'p3':p3,'m1':m1,'m2':m2,'m3':m3,'g23':g23,'g12':g12,'g34':g34,'sneg':sneg,'err':err,'y':y}
def design(F, s):
    n = s.sum()
    cols = [np.ones(n), np.log(F['g23'][s]+1e-4), F['g23'][s], np.log(F['g34'][s]+0.01), np.log(F['g12'][s]), F['m2'][s]/F['m1'][s], F['sneg'][s], (F['m3'][s]<0).astype(float)]
    for key in ['p1','p2','p3']:
        oh = np.zeros((n,10)); oh[np.arange(n), F[key][s]] = 1; cols.append(oh[:,1:])
    cell = np.zeros((n,100), dtype=np.float32); cell[np.arange(n), F['p2'][s]*10+F['p3'][s]] = 1
    cols.append(cell)
    return np.column_stack(cols).astype(np.float32)
def fit_logistic(A, t, l2=1e-2, iters=25):
    beta = np.zeros(A.shape[1])
    for it in range(iters):
        p = 1/(1+np.exp(-(A@beta)))
        W = (p*(1-p)).astype(np.float32)
        H = (A*W[:,None]).T@A + l2*np.eye(A.shape[1], dtype=np.float32)
        g = A.T@(p-t).astype(np.float32) + l2*beta
        beta -= np.linalg.solve(H.astype(np.float64), g.astype(np.float64))
    return beta
t0=time.time()
rng = np.random.default_rng(3)
Ftr = feats(rng.standard_normal((2000000,10)))
Fte = feats(rng.standard_normal((2000000,10)))
print("feats", time.time()-t0)
def band(F): return (F['g12']>=0.022)&(F['m2']>0)&(F['g23']>0.01)&(F['g23']<0.12)
str_, ste = band(Ftr), band(Fte)
A = design(Ftr, str_); beta = fit_logistic(A, Ftr['err'][str_].astype(float))
print("fit", time.time()-t0, "band frac", str_.mean())
Ate = design(Fte, ste); pte = 1/(1+np.exp(-(Ate@beta)))
ete = Fte['err'][ste]
bins = np.digitize(pte, [0.02,0.04,0.06,0.08,0.1,0.15,0.2,0.3])
for k in range(9):
    s = bins==k; print(k, s.mean().round(4), pte[s].mean().round(4), ete[s].mean().round(4))
f23 = np.array([0.03614968879534096, 0.033, 0.027609780875624497, 0.027609780875624497, 0.03042449670906653, 0.033, 0.03614968879534096, 0.03904612656845746, 0.033, 0.033])
FB = 0.716; EC = 10.9
def value(inzone, e): return np.where(inzone, 1-FB, 1-EC*e).sum()/len(Fte['err'])
g23b = Fte['g23'][ste]; m1b = Fte['m1'][ste]; p2b = Fte['p2'][ste]
base = g23b*m1b < np.maximum(1.1*f23[p2b]*m1b, 0.03)
print("baseline zone in band", base.mean(), "value", value(base, ete))
for thr in [0.05,0.06,0.066,0.07,0.08]:
    mz = pte > thr
    print("model thr", thr, "zone frac", mz.mean(), "value", value(mz, ete))
print("oracle-ish (uses true err):", value(ete, ete))
np.save('tmp/beta.npy', beta)
