
import numpy as np, time, gc
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
def feats(X):
    N=len(X); y = fwd(X)
    o = np.argsort(-X, axis=1).astype(np.int8); S = -np.sort(-X,axis=1); m1 = S[:,0]
    F = {'p1':o[:,0],'p2':o[:,1],'p3':o[:,2],'m1':m1,'m2':S[:,1],'m3':S[:,2],'y':y}
    F['g23'] = (F['m2']-np.maximum(F['m3'],0))/m1; F['g12']=(m1-F['m2'])/m1
    F['sum'] = X.sum(1)/m1; F['err'] = y != F['p2']
    return F
def onehot(v, n=10):
    oh = np.zeros((len(v),n), dtype=np.float32); oh[np.arange(len(v)), v.astype(int)] = 1; return oh
def design(F, s):
    n = s.sum(); lg = np.log(F['g23'][s]+1e-4).astype(np.float32); lg12 = np.log(F['g12'][s]+1e-4).astype(np.float32)
    cols = [np.ones(n,np.float32), lg, F['g23'][s].astype(np.float32), lg12, F['g12'][s].astype(np.float32),
            (F['m2'][s]/F['m1'][s]).astype(np.float32), F['sum'][s].astype(np.float32), (F['m3'][s]<0).astype(np.float32), lg*lg12,
            onehot(F['p2'][s].astype(int)*10+F['p3'][s], 100), onehot(F['p1'][s].astype(int)*10+F['p2'][s], 100)]
    return np.column_stack(cols)
def fit_logistic(A, t, l2=1e-2, iters=12):
    beta = np.zeros(A.shape[1], np.float32); n=len(A); C=150000
    for it in range(iters):
        H = l2*np.eye(A.shape[1]); g = l2*beta.astype(np.float64)
        for i in range(0,n,C):
            Ai = A[i:i+C]; p = 1/(1+np.exp(-(Ai@beta))); W = (p*(1-p)).astype(np.float32)
            H += (Ai*W[:,None]).T@Ai; g += Ai.T@(p-t[i:i+C]).astype(np.float32)
        beta = (beta - np.linalg.solve(H, g)).astype(np.float32)
    return beta
LO23, LO12, HI23, HI12, THR = 0.015, 0.008, 0.1, 0.08, 0.055
def evband(F): return (F['m2']>0)&(F['g23']>=LO23)&(F['g12']>=LO12)&((F['g23']<HI23)|(F['g12']<HI12))
rng = np.random.default_rng(21)
Ftr = feats(rng.standard_normal((3000000,10))); str_ = evband(Ftr)
A = design(Ftr, str_); beta = fit_logistic(A, Ftr['err'][str_].astype(np.float32)); del A, Ftr; gc.collect()
beta = beta.astype(np.float64)
print("beta0..8", beta[:9])

def build(simplify_steps=(), thr=THR, lo23=LO23, lo12=LO12, hi23=HI23, hi12=HI12):
    g, _, _ = lv1.Graph.load(entries['best'], weights, 10, real=True)
    assert len(g.nodes) == 369, len(g.nodes)
    E = lambda i: lv1.Expr(g, i)
    tokens, p1, p2, p3, m1, m2, m3, zero, g23a, g12a = E(0), E(2), E(3), E(4), E(5), E(6), E(7), E(8), E(10), E(11)
    M14, M15, M16, M14_15, M14_16, Mfull = E(35), E(36), E(37), E(39), E(41), E(34)
    Ro14, Ro15, Ro14_15, Ro = E(42), E(43), E(45), E(32)
    h = E(148)
    def step(h, t, full_tree):
        v = lv1.concat([g.token(t).reshape(1), h], axis=0)
        e13 = h[13] == zero; e14 = h[14] == zero; e15 = h[15] == zero
        v14 = v[:14]; v15 = v[:15]; v16 = v[:16]
        a = lv1.cond(e13, M14 @ v14, M15 @ v15)
        b = lv1.cond(e13, M14_15 @ lv1.concat([v14, v[15:16]], axis=0), M16 @ v16)
        inner = lv1.cond(e14, a, b)
        fullm = Mfull @ v
        if full_tree:
            c = lv1.cond(e14, lv1.cond(e13, M14_16 @ lv1.concat([v14, v[16:17]], axis=0), fullm), fullm)
        else:
            c = fullm
        return lv1.maximum(lv1.cond(e15, inner, c), zero)
    for t in range(3, 10):
        h = step(h, t, t not in simplify_steps)
    e14 = h[14] == zero; e15 = h[15] == zero
    out = lv1.cond(e15, lv1.cond(e14, Ro14 @ h[:14], Ro15 @ h[:15]), lv1.cond(e14, Ro14_15 @ lv1.concat([h[:14], h[15:16]], axis=0), Ro @ h))
    fallback = out.argmax()
    # zone
    g23n = g23a / m1; g12n = g12a / m1
    sure = (g23n < lo23) | (g12n < lo12) | (m2 < zero)
    ev = (g23n < hi23) | (g12n < hi12)
    lg23 = lv1.log(g23n + 1e-4); lg12 = lv1.log(g12n + 1e-4)
    fv = lv1.stack([lg23, g23n, lg12, g12n, m2 / m1, tokens.sum() / m1, lv1.cast(m3 < zero, "float"), lg23 * lg12], axis=0)
    lin = g.const(beta[1:9]) @ fv
    C23 = g.const(beta[9:109]); C12 = g.const(beta[109:209])
    logit = lin + float(beta[0]) + C23[p2 * 10 + p3] + C12[p1 * 10 + p2]
    thr_logit = float(np.log(thr / (1 - thr)))
    model = lv1.cond(ev, logit > thr_logit, g.const(False))
    zone = lv1.cond(sure, g.const(True), model)
    interp = lv1.cond(zone, fallback, p2)
    return g.entry(interpretation=interp)
for ss in [(), (3,), (3,4)]:
    ent = build(simplify_steps=ss)
    nconst = sum(np.asarray(n['value']).size for n in ent['nodes'] if n['op']=='const')
    print(ss, "nodes", len(ent['nodes']), "consts", nconst)
    if len(ent['nodes']) <= 400:
        t0=time.time(); print(measure(ent), time.time()-t0)
        save_entry("model_zone_v1", ent); break
