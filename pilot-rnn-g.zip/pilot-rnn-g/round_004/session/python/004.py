
import json
e = entries['best']
nodes = e['nodes']
print(len(nodes), e['predict'], e['rule'])
for i,n in enumerate(nodes[:80]):
    print(i, {k:(v if k!='value' or (isinstance(v,(int,float)) or len(str(v))<200) else str(v)[:200]) for k,v in n.items()})
