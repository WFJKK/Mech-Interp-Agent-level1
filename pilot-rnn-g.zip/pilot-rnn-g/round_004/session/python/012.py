
import numpy as np, time, gc
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+200000]) for i in range(0,len(X),200000)])
def feats(X):
    N=len(X); y = fwd(X)
    o = np.argsort(-X, axis=1)
    S = -np.sort(-X,axis=1)
    m1 = S[:,0]
    F = {'p1':o[:,0],'p2':o[:,1],'p3':o[:,2],'p4':o[:,3],'m1':m1,'m2':S[:,1],'m3':S[:,2],'S':(S/m1[:,None]).astype(np.float32),'Xn':(X/m1[:,None]).astype(np.float32),'y':y}
    F['g23'] = (F['m2']-np.maximum(F['m3'],0))/m1; F['g12']=(m1-F['m2'])/m1; F['g34']=(np.maximum(S[:,2],0)-np.maximum(S[:,3],0))/m1
    F['sneg'] = np.minimum(X,0).sum(1)/m1; F['err'] = y != F['p2']
    return F
def onehot(v, n=10):
    oh = np.zeros((len(v),n), dtype=np.float32); oh[np.arange(len(v)), v] = 1; return oh
def design(F, s, spec):
    n = s.sum(); lg = np.log(F['g23'][s]+1e-4).astype(np.float32)
    cols = [np.ones(n,np.float32), lg, F['g23'][s].astype(np.float32)]
    if 'g34' in spec: cols.append(np.log(F['g34'][s]+0.01).astype(np.float32))
    if 'g12' in spec: cols.append(np.log(F['g12'][s]).astype(np.float32))
    if 'm2' in spec: cols.append((F['m2'][s]/F['m1'][s]).astype(np.float32))
    if 'sneg' in spec: cols.append(F['sneg'][s].astype(np.float32))
    if 'm3neg' in spec: cols.append((F['m3'][s]<0).astype(np.float32))
    for key in ['p1','p2','p3','p4']:
        if key in spec: cols.append(onehot(F[key][s])[:,1:])
    if 'cell' in spec: cols.append(onehot(F['p2'][s]*10+F['p3'][s], 100))
    if 'slope2' in spec: cols.append(onehot(F['p2'][s])*lg[:,None])
    if 'slope3' in spec: cols.append(onehot(F['p3'][s])*lg[:,None])
    if 'xn' in spec: cols.append(F['Xn'][s])
    if 'sorted' in spec: cols.append(F['S'][s][:,3:])
    if 'xn2' in spec: cols.append(F['Xn'][s]**2)
    return np.column_stack(cols)
def fit_logistic(A, t, l2=1e-2, iters=20):
    beta = np.zeros(A.shape[1])
    for it in range(iters):
        p = 1/(1+np.exp(-(A@beta)))
        W = (p*(1-p)).astype(np.float32)
        H = (A*W[:,None]).T@A + l2*np.eye(A.shape[1], dtype=np.float32)
        g = A.T@(p-t).astype(np.float32) + l2*beta
        beta -= np.linalg.solve(H.astype(np.float64), g.astype(np.float64))
    return beta
rng = np.random.default_rng(3)
Ftr = feats(rng.standard_normal((1500000,10)))
Fte = feats(rng.standard_normal((1500000,10)))
def band(F): return (F['g12']>=0.022)&(F['m2']>0)&(F['g23']>0.01)&(F['g23']<0.12)
str_, ste = band(Ftr), band(Fte)
FB = 0.716; EC = 10.9
ete = Fte['err'][ste]
def value(inzone, e): return np.where(inzone, 1-FB, 1-EC*e).sum()/len(Fte['err'])
full = ['g34','g12','m2','sneg','m3neg','p1','p2','p3','cell']
specs = {'full':full, '-sneg':[f for f in full if f!='sneg'], '-p1':[f for f in full if f!='p1'], '-cell':[f for f in full if f!='cell'], '-g34':[f for f in full if f!='g34'],
         '+p4':full+['p4'], '+slopes':full+['slope2','slope3'], '+xn':full+['xn'], '+sorted':full+['sorted'], '+all':full+['p4','slope2','slope3','xn','sorted','xn2']}
ttr = Ftr['err'][str_].astype(float)
for name, spec in specs.items():
    A = design(Ftr, str_, spec); beta = fit_logistic(A, ttr); del A; gc.collect()
    pte = 1/(1+np.exp(-(design(Fte, ste, spec)@beta)))
    best = max((value(pte>thr, ete), thr) for thr in [0.05,0.055,0.06,0.065,0.07,0.075])
    print(name, len(beta), best); gc.collect()
