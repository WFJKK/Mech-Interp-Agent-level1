
import inspect
src = inspect.getsource(lv1.Graph)
print(src[:6000])
