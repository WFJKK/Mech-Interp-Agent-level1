
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
rng = np.random.default_rng(2)
N=3000000
X = rng.standard_normal((N, 10))
y = fwd(X)
o = np.argsort(-X, axis=1)
p1, p2, p3, p4 = o[:,0], o[:,1], o[:,2], o[:,3]
ar = np.arange(N)
m1 = X[ar, p1]; m2 = X[ar, p2]; m3 = X[ar, p3]
g23 = (m2 - np.maximum(m3, 0))/m1; g12 = (m1 - m2)/m1
err = (y != p2)
# band analysis for g23 given g12 >= 0.022 and m2>0
ok = (g12 >= 0.022) & (m2 > 0)
np.set_printoptions(precision=3, suppress=True, linewidth=200)
for lo, hi in [(0.0,0.015),(0.015,0.03),(0.03,0.045),(0.045,0.06),(0.06,0.08)]:
    s = ok & (g23>=lo) & (g23<hi)
    print("band", lo, hi, "frac", s.mean(), "err", err[s].mean())
    T = np.zeros((10,10)); C = np.zeros((10,10))
    np.add.at(T, (p2[s], p3[s]), err[s]); np.add.at(C, (p2[s], p3[s]), 1)
    print((T/np.maximum(C,1)))
    print("by p2:", T.sum(1)/C.sum(1), "by p3:", T.sum(0)/C.sum(0))
