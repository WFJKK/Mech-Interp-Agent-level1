
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
print([n for n in dir(lv1) if not n.startswith('_')])
rng = np.random.default_rng(0)
X = rng.standard_normal((400000, 10))
y = fwd(X)
o = np.argsort(-X, axis=1)
p1, p2, p3 = o[:,0], o[:,1], o[:,2]
m1 = X[np.arange(len(X)), p1]; m2 = X[np.arange(len(X)), p2]; m3 = X[np.arange(len(X)), p3]
print("agree p2:", (y==p2).mean())
# m2<0 subzone
s = m2 < 0
print("m2<0 frac", s.mean(), "y==p1", (y[s]==p1[s]).mean(), "y==p2", (y[s]==p2[s]).mean(), "y==p3",(y[s]==p3[s]).mean())
# what else? 
s0 = s & (m1 < 0)
print("all neg frac", s0.mean(), "y==p1", (y[s0]==p1[s0]).mean(), "y==p2", (y[s0]==p2[s0]).mean())
s1 = s & (m1 > 0)
print("one pos frac", s1.mean(), "y==p1", (y[s1]==p1[s1]).mean(), "y==p2", (y[s1]==p2[s1]).mean(), "y==p3",(y[s1]==p3[s1]).mean())
# relation of y to positions in one-pos case
import collections
print(collections.Counter(zip(p1[s1][:40], y[s1][:40], p2[s1][:40])))
