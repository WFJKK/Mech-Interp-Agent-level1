
import numpy as np, json
print(info.keys() if hasattr(info,'keys') else info)
print({k:v.shape for k,v in weights.items()})
print(list(entries.keys()))
m = measure(entries['best'])
print(m)
