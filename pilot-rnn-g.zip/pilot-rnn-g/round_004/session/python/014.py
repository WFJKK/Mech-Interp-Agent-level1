
import numpy as np, time, gc
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
rng = np.random.default_rng(5)
N=3000000
X = rng.standard_normal((N,10)); y = fwd(X)
o = np.argsort(-X, axis=1); S = -np.sort(-X,axis=1); m1=S[:,0]; m2=S[:,1]; m3=S[:,2]
p1,p2,p3 = o[:,0],o[:,1],o[:,2]
g12 = (m1-m2)/m1; g23=(m2-np.maximum(m3,0))/m1
err = y!=p2
np.set_printoptions(precision=3, suppress=True, linewidth=200)
ok = (m2>0)&(g23>=0.045)
for lo,hi in [(0,0.005),(0.005,0.01),(0.01,0.015),(0.015,0.022),(0.022,0.03),(0.03,0.04),(0.04,0.06),(0.06,0.1)]:
    s = ok&(g12>=lo)&(g12<hi)
    print("g12 band",lo,hi,"frac",s.mean().round(4),"err",err[s].mean().round(4), "y==p1", (y[s]==p1[s]).mean().round(3))
    T = np.zeros((10,10)); C = np.zeros((10,10))
    np.add.at(T,(p1[s],p2[s]),err[s]); np.add.at(C,(p1[s],p2[s]),1)
    print("by p1:", T.sum(1)/C.sum(1), "by p2:", T.sum(0)/C.sum(0))
    if lo>=0.015 and lo<0.04: print(T/np.maximum(C,1))
# m3<0 region: err vs m2/m1 
s = (m2>0)&(m3<0)&(g12>=0.022)
print("m3<0 frac", s.mean())
for lo,hi in [(0,0.02),(0.02,0.04),(0.04,0.06),(0.06,0.08),(0.08,0.1),(0.1,0.15),(0.15,0.2)]:
    ss = s&(g23>=lo)&(g23<hi); print("m3<0 m2/m1 band",lo,hi,"frac",ss.mean().round(5),"err",err[ss].mean().round(3))
