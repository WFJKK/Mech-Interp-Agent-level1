
e = entries['best']; nodes = e['nodes']
from collections import Counter
print(Counter(n['op'] for n in nodes))
for i,n in enumerate(nodes[80:], start=80):
    d = {k:v for k,v in n.items() if k!='op'}
    if 'value' in d and not isinstance(d['value'], (int,float)): d['value'] = f"<{len(d['value'])}>"
    print(i, n['op'], d)
