
import numpy as np, time, gc, resource
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
def feats(X):
    N=len(X); y = fwd(X)
    o = np.argsort(-X, axis=1).astype(np.int8); S = -np.sort(-X,axis=1); m1 = S[:,0]
    F = {'p1':o[:,0],'p2':o[:,1],'p3':o[:,2],'m1':m1,'m2':S[:,1],'m3':S[:,2],'y':y}
    F['g23'] = (F['m2']-np.maximum(F['m3'],0))/m1; F['g12']=(m1-F['m2'])/m1
    F['sneg'] = np.minimum(X,0).sum(1)/m1; F['sum'] = X.sum(1)/m1; F['err'] = y != F['p2']
    return F
def onehot(v, n=10):
    oh = np.zeros((len(v),n), dtype=np.float32); oh[np.arange(len(v)), v.astype(int)] = 1; return oh
def design(F, s, spec):
    n = s.sum(); lg = np.log(F['g23'][s]+1e-4).astype(np.float32); lg12 = np.log(F['g12'][s]+1e-4).astype(np.float32)
    cols = [np.ones(n,np.float32), lg, F['g23'][s].astype(np.float32), lg12, F['g12'][s].astype(np.float32)]
    if 'm2' in spec: cols.append((F['m2'][s]/F['m1'][s]).astype(np.float32))
    if 'sneg' in spec: cols.append(F['sneg'][s].astype(np.float32))
    if 'sum' in spec: cols.append(F['sum'][s].astype(np.float32))
    if 'm3neg' in spec: cols.append((F['m3'][s]<0).astype(np.float32))
    for key in ['p1','p2','p3']:
        if key in spec: cols.append(onehot(F[key][s])[:,1:])
    if 'c23' in spec: cols.append(onehot(F['p2'][s].astype(int)*10+F['p3'][s], 100))
    if 'c12' in spec: cols.append(onehot(F['p1'][s].astype(int)*10+F['p2'][s], 100))
    if 'c13' in spec: cols.append(onehot(F['p1'][s].astype(int)*10+F['p3'][s], 100))
    if 'x12' in spec: cols.append(lg[:,None]*lg12[:,None])
    return np.column_stack(cols)
def fit_logistic(A, t, l2=1e-2, iters=12):
    beta = np.zeros(A.shape[1], np.float32); n=len(A); C=150000
    for it in range(iters):
        H = l2*np.eye(A.shape[1]); g = l2*beta.astype(np.float64)
        for i in range(0,n,C):
            Ai = A[i:i+C]; p = 1/(1+np.exp(-(Ai@beta))); W = (p*(1-p)).astype(np.float32)
            H += (Ai*W[:,None]).T@Ai; g += Ai.T@(p-t[i:i+C]).astype(np.float32)
        beta = (beta - np.linalg.solve(H, g)).astype(np.float32)
    return beta
rng = np.random.default_rng(7)
Ftr = feats(rng.standard_normal((1200000,10))); Fte = feats(rng.standard_normal((1200000,10)))
def band(F): return (F['m2']>0)&((F['g23']<0.12)|(F['g12']<0.1))
str_, ste = band(Ftr), band(Fte)
print("band frac", ste.mean())
FB = 0.716; EC = 10.9
ete = Fte['err'][ste]
def value(inzone, e): return np.where(inzone, 1-FB, 1-EC*e).sum()/len(Fte['err'])
f23 = np.array([0.03614968879534096, 0.033, 0.027609780875624497, 0.027609780875624497, 0.03042449670906653, 0.033, 0.03614968879534096, 0.03904612656845746, 0.033, 0.033])
g23b = Fte['g23'][ste]; m1b = Fte['m1'][ste]; p2b = Fte['p2'][ste].astype(int); g12b = Fte['g12'][ste]
base = (g23b*m1b < np.maximum(1.1*f23[p2b]*m1b, 0.03)) | (g12b < 0.022)
print("baseline zone in band", base.mean(), "value", value(base, ete))
ttr = Ftr['err'][str_].astype(np.float32)
full = ['m2','sneg','m3neg','p3','c23','c12']
specs = {'full':full, '-sneg':[f for f in full if f!='sneg'], 'sum_for_sneg':[f if f!='sneg' else 'sum' for f in full], '-p3':[f for f in full if f!='p3'], '+p1p2':full+['p1','p2'], '+c13':full+['c13'], '+x12':full+['x12'], 'nocells':['m2','sneg','m3neg','p1','p2','p3']}
for name, spec in specs.items():
    A = design(Ftr, str_, spec); beta = fit_logistic(A, ttr); del A; gc.collect()
    Ate = design(Fte, ste, spec); pte = 1/(1+np.exp(-(Ate@beta))); del Ate; gc.collect()
    res = [(round(value(pte>thr, ete),5), thr, round((pte>thr).mean(),4)) for thr in [0.05,0.055,0.06,0.065,0.07]]
    print(name, len(beta), max(res), "mem", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e6)
    if name=='full': np.save('tmp/beta_full.npy', beta)
