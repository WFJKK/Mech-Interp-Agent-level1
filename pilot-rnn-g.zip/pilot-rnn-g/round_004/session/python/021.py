
import numpy as np, time, gc, os
print(os.path.exists('tmp/beta.npy'))
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
def feats(X):
    N=len(X); y = fwd(X)
    o = np.argsort(-X, axis=1).astype(np.int8); S = -np.sort(-X,axis=1); m1 = S[:,0]
    F = {'p1':o[:,0],'p2':o[:,1],'p3':o[:,2],'m1':m1,'m2':S[:,1],'m3':S[:,2],'y':y}
    F['g23'] = (F['m2']-np.maximum(F['m3'],0))/m1; F['g12']=(m1-F['m2'])/m1
    F['sum'] = X.sum(1)/m1; F['err'] = y != F['p2']
    return F
def onehot(v, n=10):
    oh = np.zeros((len(v),n), dtype=np.float32); oh[np.arange(len(v)), v.astype(int)] = 1; return oh
def design(F, s):
    n = s.sum(); lg = np.log(F['g23'][s]+1e-4).astype(np.float32); lg12 = np.log(F['g12'][s]+1e-4).astype(np.float32)
    cols = [np.ones(n,np.float32), lg, F['g23'][s].astype(np.float32), lg12, F['g12'][s].astype(np.float32),
            (F['m2'][s]/F['m1'][s]).astype(np.float32), F['sum'][s].astype(np.float32), (F['m3'][s]<0).astype(np.float32), lg*lg12,
            onehot(F['p2'][s].astype(int)*10+F['p3'][s], 100), onehot(F['p1'][s].astype(int)*10+F['p2'][s], 100)]
    return np.column_stack(cols)
def fit_logistic(A, t, l2=1e-2, iters=12):
    beta = np.zeros(A.shape[1], np.float32); n=len(A); C=150000
    for it in range(iters):
        H = l2*np.eye(A.shape[1]); g = l2*beta.astype(np.float64)
        for i in range(0,n,C):
            Ai = A[i:i+C]; p = 1/(1+np.exp(-(Ai@beta))); W = (p*(1-p)).astype(np.float32)
            H += (Ai*W[:,None]).T@Ai; g += Ai.T@(p-t[i:i+C]).astype(np.float32)
        beta = (beta - np.linalg.solve(H, g)).astype(np.float32)
    return beta
LO23, LO12, HI23, HI12 = 0.015, 0.008, 0.1, 0.08
def evband(F): return (F['m2']>0)&(F['g23']>=LO23)&(F['g12']>=LO12)&((F['g23']<HI23)|(F['g12']<HI12))
rng = np.random.default_rng(21)
t0=time.time()
Ftr = feats(rng.standard_normal((3000000,10))); str_ = evband(Ftr)
A = design(Ftr, str_); beta = fit_logistic(A, Ftr['err'][str_].astype(np.float32)); del A, Ftr; gc.collect()
np.save('tmp/beta2.npy', beta); print("fit done", time.time()-t0, beta[:9])
Fte = feats(rng.standard_normal((2000000,10))); ste = evband(Fte)
Ate = design(Fte, ste); pte = np.zeros(len(ste)); pte[ste] = 1/(1+np.exp(-(Ate@beta))); del Ate
N = len(pte); e = Fte['err']; g23=Fte['g23']; g12=Fte['g12']; m2=Fte['m2']; m1=Fte['m1']
FB=0.716; EC=10.9; OPS=2937; CHEAP=58; MODEL=32
def total(zone, evaluated):
    r = 1 - CHEAP/OPS - evaluated*(MODEL+1)/OPS - np.where(zone, FB, EC*e)
    return r.mean()
for thr in [0.05,0.055,0.06,0.065,0.07]:
  for lo23, lo12, hi23, hi12 in [(0.015,0.008,0.1,0.08),(0.015,0.008,0.09,0.07),(0.015,0.008,0.08,0.06),(0.02,0.01,0.08,0.06),(0.02,0.01,0.09,0.07)]:
    sure = (m2<0)|(g23<lo23)|(g12<lo12)
    ev = ~sure & ((g23<hi23)|(g12<hi12))
    zone = sure | (ev & (pte>thr))
    print(thr, (lo23,lo12,hi23,hi12), "total", round(total(zone, ev),5), "zone", zone.mean().round(4), "evaluated", ev.mean().round(4), "err", (e & ~zone).mean().round(5))
