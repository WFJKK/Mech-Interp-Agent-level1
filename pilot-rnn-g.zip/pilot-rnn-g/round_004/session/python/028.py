
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
ent = entries['model_zone_v1']
consts = [np.asarray(n['value']) for n in ent['nodes'] if n['op']=='const']
b8 = [c for c in consts if c.size==8][0]; c100 = [c for c in consts if c.size==100]
C23, C12 = c100[0], c100[1]
b0 = [float(c) for c in consts if c.size==1 and c.dtype.kind=='f' and float(c) < -5][0]
def entry_sim(X, C23, C12, perm=None):
    y = fwd(X); o = np.argsort(-X, axis=1); p1,p2,p3 = o[:,0],o[:,1],o[:,2]
    S = -np.sort(-X,axis=1); m1=S[:,0]; m2=S[:,1]; m3=S[:,2]
    g23=(m2-np.maximum(m3,0))/m1; g12=(m1-m2)/m1
    sure = (m2<0)|(g23<0.015)|(g12<0.008); evb = (g23<0.1)|(g12<0.08)
    with np.errstate(all='ignore'):
        lg23=np.log(g23+1e-4); lg12=np.log(g12+1e-4)
        fv = np.stack([lg23,g23,lg12,g12,m2/m1,X.sum(1)/m1,(m3<0).astype(float),lg23*lg12],1)
        logit = fv@b8 + b0 + C23[p2*10+p3] + C12[p1*10+p2]
    zone = sure | (evb & (logit > np.log(0.055/0.945)))
    err = (~zone) & (y != p2)
    return zone.mean(), err.mean()
rng = np.random.default_rng(5)
X = rng.standard_normal((1000000,10))
print("as is", entry_sim(X, C23, C12))
print("tables zeroed", entry_sim(X, np.zeros(100), np.zeros(100)))
print("tables mean-filled", entry_sim(X, np.full(100, C23.mean()), np.full(100, C12.mean())))
for k in range(3):
    perm = rng.permutation(10)
    P23 = C23.reshape(10,10)[perm][:,perm].ravel(); P12 = C12.reshape(10,10)[perm][:,perm].ravel()
    print("tables position-permuted", entry_sim(X, P23, P12))
# also: fidelity of the OLD simple zone (fold_v3) for reference
