
import numpy as np, time, gc
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
def feats(X):
    N=len(X); y = fwd(X)
    o = np.argsort(-X, axis=1).astype(np.int8); S = -np.sort(-X,axis=1); m1 = S[:,0]
    F = {'p1':o[:,0],'p2':o[:,1],'p3':o[:,2],'m1':m1,'m2':S[:,1],'m3':S[:,2],'m4':S[:,3]}
    F['g23'] = ((F['m2']-np.maximum(F['m3'],0))/m1).astype(np.float32); F['g12']=((m1-F['m2'])/m1).astype(np.float32); F['g34']=((np.maximum(F['m3'],0)-np.maximum(F['m4'],0))/m1).astype(np.float32)
    F['sum'] = (X.sum(1)/m1).astype(np.float32); F['err'] = y != F['p2']; F['npos'] = (X>0).sum(1).astype(np.int8)
    F['x0'] = (X[:,0]/m1).astype(np.float32); F['x9'] = (X[:,9]/m1).astype(np.float32)
    return F
def onehot(v, n=10):
    oh = np.zeros((len(v),n), dtype=np.float32); oh[np.arange(len(v)), v.astype(int)] = 1; return oh
def design(F, s, extra=()):
    n = s.sum(); lg = np.log(F['g23'][s]+1e-4); lg12 = np.log(F['g12'][s]+1e-4)
    r2 = (F['m2'][s]/F['m1'][s]).astype(np.float32); neg = (F['m3'][s]<0).astype(np.float32)
    cols = [np.ones(n,np.float32), lg, F['g23'][s], lg12, F['g12'][s], r2, F['sum'][s], neg, lg*lg12,
            onehot(F['p2'][s].astype(int)*10+F['p3'][s], 100), onehot(F['p1'][s].astype(int)*10+F['p2'][s], 100)]
    for ex in extra:
        if ex=='lg*neg': cols.append(lg*neg)
        if ex=='lg*r2': cols.append(lg*r2)
        if ex=='lg12*r2': cols.append(lg12*r2)
        if ex=='lg2': cols.append(lg*lg)
        if ex=='lg12sq': cols.append(lg12*lg12)
        if ex=='g34': cols.append(np.log(F['g34'][s]+0.01))
        if ex=='adj': cols.append((np.abs(F['p2'][s].astype(int)-F['p3'][s])==1).astype(np.float32))
        if ex=='npos': cols.append(F['npos'][s].astype(np.float32))
        if ex=='x0': cols.append(F['x0'][s])
        if ex=='x9': cols.append(F['x9'][s])
        if ex=='slope2': cols.append(onehot(F['p2'][s])*lg[:,None])
        if ex=='slope1': cols.append(onehot(F['p1'][s])*lg12[:,None])
        if ex=='r2sq': cols.append(r2*r2)
    return np.column_stack(cols)
def fit_logistic(A, t, l2=1e-2, iters=12):
    beta = np.zeros(A.shape[1], np.float32); n=len(A); C=150000
    for it in range(iters):
        H = l2*np.eye(A.shape[1]); g = l2*beta.astype(np.float64)
        for i in range(0,n,C):
            Ai = A[i:i+C]; p = 1/(1+np.exp(-(Ai@beta))); W = (p*(1-p)).astype(np.float32)
            H += (Ai*W[:,None]).T@Ai; g += Ai.T@(p-t[i:i+C]).astype(np.float32)
        beta = (beta - np.linalg.solve(H, g)).astype(np.float32)
    return beta
LO23, LO12, HI23, HI12, THR = 0.015, 0.008, 0.1, 0.08, 0.055
def evband(F): return (F['m2']>0)&(F['g23']>=LO23)&(F['g12']>=LO12)&((F['g23']<HI23)|(F['g12']<HI12))
rng = np.random.default_rng(21)
Ftr = feats(rng.standard_normal((2000000,10))); str_ = evband(Ftr); ttr = Ftr['err'][str_].astype(np.float32)
Fte = feats(rng.standard_normal((1500000,10))); ste = evband(Fte)
e = Fte['err']; sure = (Fte['m2']<0)|(Fte['g23']<LO23)|(Fte['g12']<LO12)
FB=0.716; EC=10.9; OPS=2937
def total(zone, evaluated, model_ops):
    r = 1 - 59/OPS - evaluated*(model_ops+1)/OPS - np.where(zone, FB, EC*e)
    return r.mean()
for extra, mops in [((),36), (('lg*neg',),37), (('lg*r2',),37), (('lg12*r2',),37), (('lg2',),37), (('lg12sq',),37), (('g34',),41), (('adj',),39), (('npos',),47), (('x0','x9'),40), (('slope2',),39), (('slope1',),39), (('r2sq',),37), (('lg*neg','lg*r2','lg12*r2','lg2','lg12sq','r2sq'),42)]:
    A = design(Ftr, str_, extra); beta = fit_logistic(A, ttr); del A; gc.collect()
    Ate = design(Fte, ste, extra); pte = np.zeros(len(e)); pte[ste] = 1/(1+np.exp(-(Ate@beta))); del Ate; gc.collect()
    res = max((round(total(sure | (ste & (pte>thr)), ste, mops),5), thr) for thr in [0.05,0.055,0.06])
    print(extra, len(beta), res)
