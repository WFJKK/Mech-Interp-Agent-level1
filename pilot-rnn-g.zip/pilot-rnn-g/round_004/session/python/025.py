
import numpy as np, time, gc
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd1(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
def fwd(X): return np.concatenate([fwd1(X[i:i+100000]) for i in range(0,len(X),100000)])
# pull beta from the saved entry's constants
ent = entries['model_zone_v1']
consts = [np.asarray(n['value']) for n in ent['nodes'] if n['op']=='const']
b8 = [c for c in consts if c.size==8][0]; c100 = [c for c in consts if c.size==100]
C23, C12 = c100[0], c100[1]
b0 = [float(c) for c in consts if c.size==1 and c.dtype.kind=='f' and float(c) < -5][0]
print(b8, b0, C23[:5], C12[:5])
def entry_sim(X):
    y = fwd(X); o = np.argsort(-X, axis=1); p1,p2,p3 = o[:,0],o[:,1],o[:,2]
    S = -np.sort(-X,axis=1); m1=S[:,0]; m2=S[:,1]; m3=S[:,2]
    g23=(m2-np.maximum(m3,0))/m1; g12=(m1-m2)/m1
    sure = (m2<0)|(g23<0.015)|(g12<0.008); evb = (g23<0.1)|(g12<0.08)
    lg23=np.log(g23+1e-4); lg12=np.log(g12+1e-4)
    fv = np.stack([lg23,g23,lg12,g12,m2/m1,X.sum(1)/m1,(m3<0).astype(float),lg23*lg12],1)
    logit = fv@b8 + b0 + C23[p2*10+p3] + C12[p1*10+p2]
    zone = sure | (evb & (logit > np.log(0.055/0.945)))
    err = (~zone) & (y != p2)
    return zone, err, evb & ~sure
inputs, outs, ops = network_outputs(); X = np.asarray(inputs, float)
zone, err, evb = entry_sim(X); print("fixed sample: zone", zone.mean(), "errors", err.sum(), "ev", evb.mean())
rng = np.random.default_rng(99)
cnts=[]; zs=[]; evs=[]
for k in range(60):
    Xs = rng.standard_normal((16384,10)); z,e,ev = entry_sim(Xs); cnts.append(e.sum()); zs.append(z.mean()); evs.append(ev.mean())
cnts=np.array(cnts); print("fresh samples: errors mean", cnts.mean(), "sd", cnts.std(), "min/max", cnts.min(), cnts.max(), "zone", np.mean(zs), "ev", np.mean(evs))
# reward estimate per sample
def reward(errs, zone, ev):
    fid = 1-errs/16384; low = lv1.wilson_lower(16384-errs, 16384) if hasattr(lv1,'wilson_lower') else fid
    cost = (59 + ev*36 + zone*2120)/2937
    return (1-cost) - 10*(1-low)
try:
    import inspect; print(inspect.signature(lv1.wilson_lower))
except Exception as ex: print(ex)
