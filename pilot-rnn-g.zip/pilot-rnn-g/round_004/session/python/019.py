
g, interp, region = lv1.Graph.load(entries['best'], weights, info['sizes']['n_ctx'] if 'n_ctx' in info['sizes'] else 10)
print(type(g), type(interp), region)
print([a for a in dir(g) if not a.startswith('__')])
print([a for a in dir(interp) if not a.startswith('__')])
print(interp.op if hasattr(interp,'op') else None, getattr(interp,'args',None))
