
import numpy as np
inputs, outs, ops = network_outputs()
X = np.asarray(inputs, dtype=float); Y = np.asarray(outs)
print(X.shape, Y.shape, ops if np.isscalar(ops) else type(ops))
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
print("sim agree", (fwd(X)==Y).mean())
ev = lv1.Evaluator(entries['model_zone_v1'], weights, 10)
ans = []; cps = []
for x in X:
    inside, a, cr, cp = ev.run(x); ans.append(a); cps.append(cp)
ans = np.array(ans); cps = np.array(cps)
o = np.argsort(-X, axis=1); p2 = o[:,1]
zone_entry = cps > 1000
print("entry zone frac", zone_entry.mean(), "errors", (ans != Y).sum(), "errors in zone", ((ans != Y) & zone_entry).sum(), "errors outside", ((ans!=Y)&~zone_entry).sum())
print("cheap path ops hist", np.unique(cps[~zone_entry], return_counts=True))
print("zone ops mean", cps[zone_entry].mean())
# compare with numpy zone
S = -np.sort(-X,axis=1); m1=S[:,0]; m2=S[:,1]; m3=S[:,2]
g23=(m2-np.maximum(m3,0))/m1; g12=(m1-m2)/m1
sure = (m2<0)|(g23<0.015)|(g12<0.008); evb = ~sure & ((g23<0.1)|(g12<0.08))
print("sure frac", sure.mean(), "ev frac", evb.mean(), "sure subset of entry zone:", (zone_entry[sure]).all())
err = Y != p2
print("errors outside entry zone by band: sure", (err&~zone_entry&sure).sum(), "ev", (err&~zone_entry&evb).sum(), "far", (err&~zone_entry&~sure&~evb).sum())
print("far frac", (~sure&~evb).mean(), "far err rate", err[~sure&~evb].mean())
