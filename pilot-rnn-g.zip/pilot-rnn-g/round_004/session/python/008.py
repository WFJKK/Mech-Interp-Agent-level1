
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Wo = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], w) + h @ R.T, 0)
    return (h @ Wo.T).argmax(1)
rng = np.random.default_rng(2)
N=3000000
X = rng.standard_normal((N, 10))
y = fwd(X)
o = np.argsort(-X, axis=1)
p1, p2, p3, p4 = o[:,0], o[:,1], o[:,2], o[:,3]
ar = np.arange(N)
m1 = X[ar, p1]; m2 = X[ar, p2]; m3 = X[ar, p3]; m4 = X[ar,p4]
g23 = (m2 - np.maximum(m3, 0))/m1; g12 = (m1 - m2)/m1; g34 = (np.maximum(m3,0)-np.maximum(m4,0))/m1
err = (y != p2)
ok = (g12 >= 0.022) & (m2 > 0)
band = ok & (g23>=0.03) & (g23<0.06)
def tab(name, v, edges):
    idx = np.digitize(v[band], edges)
    out=[]
    for k in range(len(edges)+1):
        s = idx==k
        out.append((round(s.mean(),3), round(err[band][s].mean(),3) if s.any() else None))
    print(name, edges, out)
tab("g34", g34, [0.01,0.03,0.06,0.1,0.2,0.4])
tab("g12", g12, [0.05,0.1,0.2,0.3,0.5])
tab("m2/m1", m2/m1, [0.3,0.5,0.7,0.8,0.9])
tab("m1", m1, [0.8,1.2,1.6,2.0,2.5])
tab("m3<0", (m3<0).astype(float), [0.5])
nneg = (X<0).sum(1); tab("nneg", nneg.astype(float), [2.5,4.5,6.5,7.5])
sneg = np.minimum(X,0).sum(1)/m1; tab("sneg/m1", sneg, [-6,-4,-3,-2,-1])
tab("p3>p2", (p3>p2).astype(float), [0.5])
tab("|p3-p2|", np.abs(p3-p2).astype(float), [1.5,2.5,4.5,6.5])
tab("p1", p1.astype(float), [0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5])
tab("p4", p4.astype(float), [0.5,1.5,2.5,3.5,4.5,5.5,6.5,7.5,8.5])
# the sum of x after p2 and after p3?
