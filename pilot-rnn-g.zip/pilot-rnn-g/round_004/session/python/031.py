
import inspect, numpy as np
print(inspect.signature(lv1.draw_inputs))
print(inspect.getsource(lv1.draw_inputs)[:1500])
print(info['data_set'], info['check'], info['sample_size'], info['input_space'])
