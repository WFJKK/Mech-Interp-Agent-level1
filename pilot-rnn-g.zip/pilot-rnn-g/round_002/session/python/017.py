
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(12345)
X = rng.standard_normal((400000,10)); Y = fwd(X)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p2=A[:,1]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2)
print("overall p2 error", err.mean())
FB=0.843; RULE=80/2937
def est(zone):
    e = err[~zone].sum()/len(err)
    return 1-RULE-zone.mean()*FB-10*e, zone.mean(), e
print("round1 thresholds", est((g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)))
print("m1-rel pick", est((g23<0.03)|(g23<0.03*m1)|(g12<0.02)|(m2<0)))
best=[]
for a in [0.02,0.025,0.03,0.035,0.04,0.045,0.05]:
    for b in [0.02,0.025,0.03,0.035,0.04,0.05]:
        for c in [0.015,0.02,0.025,0.03]:
            for d in [0,0.01,0.02,0.03]:
                z=(g23<a)|(g23<b*m1)|(g12<c)|(g12<d*m1)|(m2<0)
                r,zf,e=est(z); best.append((round(r,4),a,b,c,d,round(zf,4),round(e,5)))
best.sort(reverse=True)
for b in best[:10]: print(b)
best=[]
for a in [0.02,0.03,0.04,0.05]:
    for b in [0.02,0.03,0.04,0.05,0.06]:
        for c in [0.015,0.02,0.025,0.03]:
            z=(g23<a)|(g23<b*m2)|(g12<c)|(m2<0)
            r,zf,e=est(z); best.append((round(r,4),a,b,c,round(zf,4),round(e,5)))
best.sort(reverse=True)
for b in best[:5]: print("m2rel",b)
