
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
def prep(seed,n):
    rng = np.random.default_rng(seed); X = rng.standard_normal((n,10)); Y = fwd(X)
    S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
    return dict(m1=S[:,0],m2=S[:,1],m3=S[:,2],p1=A[:,0],p2=A[:,1],p3=A[:,2],err=(Y!=A[:,1]))
D=prep(7,400000); E=prep(99,400000)
FB=0.843; RULE=90/2937
def est(d, a,b,c,dd, f23=np.ones(10), f12=np.ones(10)):
    g23=d['m2']-np.maximum(d['m3'],0); g12=d['m1']-d['m2']
    z=(g23<a)|(g23<b*d['m1']*f23[d['p2']])|(g12<c)|(g12<dd*d['m1']*f12[d['p1']])|(d['m2']<0)
    e=d['err'][~z].sum()/len(z); return 1-RULE-z.mean()*FB-10*e
base=(0.025,0.03,0.015,0.02)
print("base train", est(D,*base), "test", est(E,*base))
f23=np.ones(10); f12=np.ones(10)
for rnd in range(3):
    for i in range(10):
        bestv,bestf=-1,None
        for f in [0.5,0.7,0.85,1,1.2,1.4,1.7,2.0]:
            t=f23.copy(); t[i]=f; v=est(D,*base,t,f12)
            if v>bestv: bestv,bestf=v,f
        f23[i]=bestf
    for i in range(10):
        bestv,bestf=-1,None
        for f in [0.5,0.7,0.85,1,1.2,1.4,1.7,2.0]:
            t=f12.copy(); t[i]=f; v=est(D,*base,f23,t)
            if v>bestv: bestv,bestf=v,f
        f12[i]=bestf
print("f23",f23,"f12",f12)
print("tuned train", est(D,*base,f23,f12), "test", est(E,*base,f23,f12))
