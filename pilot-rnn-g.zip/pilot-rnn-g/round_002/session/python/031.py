
import numpy as np, itertools
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwdH(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return np.stack(H,1)
H=fwdH(X)
S = np.sort(X,1)[:,::-1]; m1,m2,m3=S[:,0],S[:,1],S[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone=(g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
Z=(H[zone]==0)
def exp_cost(Zt, order, levels, nrows=16):
    # levels: list of k (number of trailing units that must be zero), descending k
    # nested: check largest k first. cost: each check: (k-1 max ops +1 eq) +1 cond; matmul nrows*(16-k)
    n=len(Zt); total=0; remaining=np.ones(n,bool)
    for k in levels:
        idx=order[16-k:]
        ok=remaining & Zt[:,idx].all(1)
        total += remaining.sum()*(k+1)          # check cost (k-1 max + 1 eq + 1 cond)
        total += ok.sum()*nrows*(16-k)
        remaining &= ~ok
    total += remaining.sum()*nrows*16
    return total/n
plan={}
for t in range(2,10):   # h_t used in step t+1 matmul (t=2..8) and readout uses h_9
    Zt=Z[:,t,:]
    order=np.argsort(Zt.mean(0))  # ascending zero-prob; trailing = most sparse
    best=(256,None)
    for L in [1,2,3]:
        for levels in itertools.combinations(range(1,8),L):
            lv=sorted(levels,reverse=True)
            c=exp_cost(Zt,order,lv)
            if c<best[0]: best=(c,lv)
    plan[t]=(order.tolist(),best[1],best[0])
    print(t, "order", order.tolist(), "levels", best[1], "exp cost", round(best[0],1), "zero-probs", np.round(np.sort(Zt.mean(0))[::-1][:6],2))
# readout on h9
Zt=Z[:,9,:]; order=np.argsort(Zt.mean(0))
best=(160,None)
for L in [1,2]:
    for levels in itertools.combinations(range(1,6),L):
        lv=sorted(levels,reverse=True); c=exp_cost(Zt,order,lv,nrows=10)
        if c<best[0]: best=(c,lv)
print("readout", best)
