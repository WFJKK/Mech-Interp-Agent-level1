
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwdH(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return np.stack(H,1)
H=fwdH(X)
S = np.sort(X,1)[:,::-1]; m1,m2,m3=S[:,0],S[:,1],S[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone=(g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
np.set_printoptions(precision=2, suppress=True, linewidth=200)
act = (H[zone]>0).mean(0)  # 10 x 16
print("active fraction per step (rows t=0..9) x unit")
print(act)
Z = (H[zone]==0)
for sets in [[4,9],[4,9,5],[4,9,5,3],[4,9,5,0],[4,9,5,1]]:
    print(sets, "P(all zero) per step t=2..9:", [round(Z[:,t,sets].all(1).mean(),2) for t in range(2,10)])
