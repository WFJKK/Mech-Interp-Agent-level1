
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
def prep(seed,n):
    rng = np.random.default_rng(seed); X = rng.standard_normal((n,10)); Y = fwd(X)
    S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
    m1,m2,m3=S[:,0],S[:,1],S[:,2]
    return dict(m1=m1,m2=m2,m3=m3,p1=A[:,0],p2=A[:,1],g23=m2-np.maximum(m3,0),g12=m1-m2,err=(Y!=A[:,1]))
D=prep(21,600000); E=prep(99,400000)
f23=np.sqrt(np.array([1.2,1.,0.7,0.7,0.85,1.,1.2,1.4,1.,1.])); f12=np.sqrt(np.array([1.4,1.2,0.7,0.5,0.7,0.5,0.7,0.7,0.7,1.4]))
FB=0.76
def loss(d,a,b,c,dd,ia=0,ib=0):
    z=(d['g23']<a)|(d['g23']<b*d['m1']*f23[d['p2']])|(d['g12']<c)|(d['g12']<dd*d['m1']*f12[d['p1']])|(d['m2']<0)
    if ia>0: z=z|((d['g23']<ia*d['m1'])&(d['g12']<ib*d['m1']))
    return z.mean()*FB+10*d['err'][~z].sum()/len(z), z.mean()
print("current", loss(D,0.025,0.03,0.015,0.02), loss(E,0.025,0.03,0.015,0.02))
res=[]
for a in [0.02,0.025,0.03,0.035]:
    for b in [0.025,0.03,0.035,0.04]:
        for c in [0.01,0.015,0.02]:
            for dd in [0.015,0.02,0.025,0.03]:
                for ia,ib in [(0,0),(0.06,0.05),(0.07,0.05),(0.06,0.07),(0.08,0.06)]:
                    res.append((loss(D,a,b,c,dd,ia,ib)[0],a,b,c,dd,ia,ib))
res.sort()
for r in res[:8]: print(r, "test", loss(E,*r[1:]))
