
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X, R=R, w=w, Ro=Ro):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1), h
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone = (g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)
for thr in [0.02,0.05,0.1,0.15,0.2,0.3]:
    Rs = np.where(np.abs(R)>=thr, R, 0)
    P,_ = fwd(X, Rs)
    print(f"thr {thr}: nnz={np.count_nonzero(Rs)} agree all={(P==Y).mean():.4f} zone={(P[zone]==Y[zone]).mean():.4f} outside={(P[~zone]==Y[~zone]).mean():.4f}")
# keep top-k per row
for k in [3,4,5,6,8]:
    Rs = np.zeros_like(R)
    for i in range(16):
        idx = np.argsort(-np.abs(R[i]))[:k]; Rs[i,idx]=R[i,idx]
    P,_ = fwd(X, Rs)
    print(f"topk {k}: agree all={(P==Y).mean():.4f} zone={(P[zone]==Y[zone]).mean():.4f} outside={(P[~zone]==Y[~zone]).mean():.4f}")
# rank picks in zone with m2>0
rank = np.argsort(np.argsort(-X,1),1); rY = rank[np.arange(len(Y)),Y]
zp = zone&(m2>0)
print("zone m2>0 n", zp.sum(), np.bincount(rY[zp],minlength=10))
_,h = fwd(X)
u,s,vt = np.linalg.svd(h-h.mean(0), full_matrices=False); print("sv", s/s[0])
