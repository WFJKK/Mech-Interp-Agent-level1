
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(7)
X = rng.standard_normal((400000,10)); Y = fwd(X)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3,m4 = S[:,0],S[:,1],S[:,2],S[:,3]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2)
zone=(g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
o=~zone
np.set_printoptions(precision=3, suppress=True, linewidth=200)
r23=g23/m1; r12=g12/m1
bins=[0,0.05,0.08,0.12,0.2,0.4,10]
print("err by p3 position (rows) x r23 bin (cols)")
T=np.zeros((10,6)); N=np.zeros((10,6))
for i in range(10):
    for j in range(6):
        mk=o&(p3==i)&(r23>=bins[j])&(r23<bins[j+1]); T[i,j]=err[mk].mean(); N[i,j]=mk.sum()
print(T); print(N.astype(int))
print("err by p1 position (rows) x r12 bin (cols)")
T=np.zeros((10,6))
for i in range(10):
    for j in range(6):
        mk=o&(p1==i)&(r12>=bins[j])&(r12<bins[j+1]); T[i,j]=err[mk].mean()
print(T)
print("err by p2 position (rows) x r23 bin (cols)")
T=np.zeros((10,6))
for i in range(10):
    for j in range(6):
        mk=o&(p2==i)&(r23>=bins[j])&(r23<bins[j+1]); T[i,j]=err[mk].mean()
print(T)
print("err by p2 position (rows) x r12 bin (cols)")
T=np.zeros((10,6))
for i in range(10):
    for j in range(6):
        mk=o&(p2==i)&(r12>=bins[j])&(r12<bins[j+1]); T[i,j]=err[mk].mean()
print(T)
