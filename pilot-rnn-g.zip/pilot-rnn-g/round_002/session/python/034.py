
import numpy as np, inspect
print(inspect.signature(lv1.Graph.load))
print([n for n in dir(lv1.Graph) if not n.startswith('_')])
print([n for n in dir(lv1) if not n.startswith('_')])
