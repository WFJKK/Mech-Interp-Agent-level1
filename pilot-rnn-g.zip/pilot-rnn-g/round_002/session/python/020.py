
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(7)
X = rng.standard_normal((400000,10)); Y = fwd(X)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3,m4 = S[:,0],S[:,1],S[:,2],S[:,3]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2).astype(float)
zone=(g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
o=~zone
X=X[o];Y=Y[o];m1=m1[o];m2=m2[o];m3=m3[o];m4=m4[o];p1=p1[o];p2=p2[o];p3=p3[o];g23=g23[o];g12=g12[o];e=err[o]
def onehot(p): return (p[:,None]==np.arange(10)[None,:]).astype(float)
neg = np.minimum(X,0); pos=np.maximum(X,0)
F = np.column_stack([np.log(g23/m1), np.log(g12/m1), m2/m1, np.maximum(m3,0)/m1, np.maximum(m4,0)/m1, -neg.sum(1)/m1, (pos.sum(1)-m1-m2)/m1,
                     (X>0).sum(1), onehot(p1), onehot(p2), onehot(p3), (p2<p1), (p3<p2), (p3<p1),
                     ((X>(m2-0.15*m1)[:,None])&(X<m2[:,None])).sum(1), ((X>(m2-0.3*m1)[:,None])&(X<m2[:,None])).sum(1), np.abs(X).sum(1)/m1, np.log(m1), np.ones(len(X))])
n=len(F); tr=np.arange(n)<int(0.7*n); te=~tr
beta=np.zeros(F.shape[1]); lam=1e-3
for it in range(25):
    z=F[tr]@beta; p=1/(1+np.exp(-z)); W=p*(1-p)
    H=(F[tr]*W[:,None]).T@F[tr]+lam*np.eye(len(beta)); gr=F[tr].T@(e[tr]-p)-lam*beta
    beta+=np.linalg.solve(H,gr)
pte=1/(1+np.exp(-(F[te]@beta)))
print("test base err", e[te].mean(), "n test", te.sum())
for thr in [0.02,0.03,0.05,0.07,0.084,0.1,0.15]:
    mk=pte>thr; print(f"thr {thr}: frac={mk.mean():.4f} err_in={e[te][mk].mean() if mk.sum() else 0:.3f} err_out={e[te][~mk].mean():.4f}")
mk=pte>0.084
print("gain", 10*e[te][mk].sum()/te.sum() - 0.843*mk.mean())
np.set_printoptions(precision=2, suppress=True, linewidth=200); print(beta)
