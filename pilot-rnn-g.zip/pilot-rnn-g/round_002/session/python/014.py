
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
mk = m2<0
np.set_printoptions(precision=2, suppress=True, linewidth=220)
print("n", mk.sum())
print("Y dist", np.bincount(Y[mk],minlength=10))
print("p1 dist", np.bincount(p1[mk],minlength=10))
# relation Y vs p1
print("Y==p1", (Y[mk]==p1[mk]).mean(), "Y==p2", (Y[mk]==p2[mk]).mean(), "Y==0", (Y[mk]==0).mean())
# Y==0 when p1 != 0?
sub = mk&(p1!=0)
print("p1!=0: Y==0 frac", (Y[sub]==0).mean(), "Y==p2", (Y[sub]==p2[sub]).mean())
idx=np.where(mk)[0][:30]
for i in idx: print(X[i], "p1",p1[i],"p2",p2[i],"Y",Y[i])
