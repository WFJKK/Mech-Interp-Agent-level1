
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return (h@Ro.T).argmax(1), np.stack(H,1)
P, H = fwd(X)
print("match", (P==Y).mean())
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
print("second argmax agreement", (A[:,1]==Y).mean())
np.set_printoptions(precision=3, suppress=True, linewidth=200)
print("mean h at last", H[:,-1].mean(0))
print("frac active", (H[:,-1]>0).mean(0))
print("std h", H[:,-1].std(0))
