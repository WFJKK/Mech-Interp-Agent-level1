
import numpy as np
g = graph(example=[0.3,-0.5,1.0,0.2,-1.1,0.4,0.9,-0.3,0.1,0.6])
w = g.weight("input")[:,0]; R = g.weight("recurrent"); Ro = g.weight("readout")
x = g.tokens()
x0, x1 = g.token(0), g.token(1)
wp = lv1.maximum(w, 0.0); wn = lv1.minimum(w, 0.0)
def table(v, s):
    b = -(v * s) / w                      # breakpoints, 16
    bs = lv1.sort(b, 0)
    mids = (bs[:-1] + bs[1:]) * 0.5       # 15
    reps = lv1.concat([bs[0:1] - 1.0, mids, bs[15:16] + 1.0], 0)  # 17
    M = lv1.cast((reps[:, None] * w[None, :] + (v * s)[None, :]) > 0.0, "float")  # 17x16
    Tw = (M * w[None, :]) @ R.T          # 17x16  rows: R(m*w)
    Tv = (M * v[None, :]) @ R.T          # 17x16  rows: R(m*v)
    return bs, Tw, Tv
rho = x1 / abs(x0)
def branch(v, s):
    bs, Tw, Tv = table(v, s)
    k = lv1.cast(bs < rho, "int").sum(0)
    return x1 * Tw[k] + x0 * Tv[k]
Rh1 = lv1.cond(x0 > 0.0, branch(R @ wp, 1.0), branch(R @ wn, -1.0))
h = lv1.maximum(w * g.token(2) + Rh1, 0.0)
for t in range(3, 10):
    h = lv1.maximum(w * g.token(t) + R @ h, 0.0)
pred = (Ro @ h).argmax()
entry = g.entry(interpretation=pred)
m = measure(entry); print(m)
# compare with numpy
print("pred on example", pred.value)
