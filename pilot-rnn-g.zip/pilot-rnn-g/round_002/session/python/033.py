
import numpy as np
e = entries["hybrid_fast_v3"]
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
tests = [np.zeros(10), np.array([0,0,1,0.5,0,0,0,0,0,0]), np.array([0,1,0.99,0,0,0,0,0,0,0]), np.array([-1,0,0,0,0,0,0,0,0,0.5]),
         np.array([0.0,-0.3,0.2,0.1,-1,2,0.1,0.1,-0.2,0.05]), np.array([1,1,1,1,1,1,1,1,1,1.]), np.array([-1,-1,-1,-1,-1,-1,-1,-1,-1,-1.]),
         np.array([1e-9,-0.5,1.0,0.2,-1.1,0.4,0.9,-0.3,0.1,0.6]), np.array([-1e-12,0.5,1.0,0.2,-1.1,0.4,0.9,-0.3,0.1,0.6])]
for x in tests:
    try:
        gg, interp, region = lv1.Graph.load(e, weights, 10)
        # evaluate on example: rebuild with example
        g2 = graph(example=list(map(float,x)))
        gg2, interp2, region2 = lv1.Graph.load(e, weights, 10) 
        print("loaded", type(interp2))
        break
    except Exception as ex:
        print("load err", ex); break
