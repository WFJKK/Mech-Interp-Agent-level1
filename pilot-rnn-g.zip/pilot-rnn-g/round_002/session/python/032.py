
import numpy as np
f23=np.sqrt(np.array([1.2,1.,0.7,0.7,0.85,1.,1.2,1.4,1.,1.])); f12=np.sqrt(np.array([1.4,1.2,0.7,0.5,0.7,0.5,0.7,0.7,0.7,1.4]))
perm=[0,1,2,3,6,7,8,10,11,12,13,14,15,5,9,4]
def build(a=0.025,b=0.03,c=0.015,d=0.02,f23=f23,f12=f12):
    g = graph(example=[0.3,-0.5,1.0,0.2,-1.1,0.4,0.9,-0.3,0.1,0.6])
    P = g.const(np.array(perm))
    w0 = g.weight("input")[:,0]; R0 = g.weight("recurrent"); Ro0 = g.weight("readout")
    w = w0[P]; R = lv1.take(lv1.take(R0, P, 0), P, 1); Ro = lv1.take(Ro0, P, 1)
    x = g.tokens(); x0, x1 = g.token(0), g.token(1)
    s = lv1.sort(x, 0)
    m1, m2, m3 = s[9], s[8], s[7]
    p2 = (x == m2).argmax()
    p1 = x.argmax()
    g23 = m2 - lv1.maximum(m3, 0.0); g12 = m1 - m2
    t23 = g.const(b*f23)[p2] * m1; t12 = g.const(d*f12)[p1] * m1
    zone = (g23 < a) | (g23 < t23) | (g12 < c) | (g12 < t12) | (m2 < 0.0)
    wp = lv1.maximum(w, 0.0); wn = lv1.minimum(w, 0.0)
    def table(v, sgn):
        bb = -(v * sgn) / w
        bs = lv1.sort(bb, 0)
        mids = (bs[:-1] + bs[1:]) * 0.5
        reps = lv1.concat([bs[0:1] - 1.0, mids, bs[15:16] + 1.0], 0)
        M = lv1.cast((reps[:, None] * w[None, :] + (v * sgn)[None, :]) > 0.0, "float")
        return bs, (M * w[None, :]) @ R.T, (M * v[None, :]) @ R.T
    def Mh(Mat, h, levels):
        if not levels: return Mat @ h
        k = levels[0]
        test = (h[16-k:].max() == 0.0) if k > 1 else (h[15] == 0.0)
        return lv1.cond(test, Mat[:, :16-k] @ h[:16-k], Mh(Mat, h, levels[1:]))
    def fallback():
        rho = x1 / abs(x0)
        def branch(v, sgn):
            bs, Tw, Tv = table(v, sgn)
            k = lv1.cast(bs < rho, "int").sum(0)
            return x1 * Tw[k] + x0 * Tv[k]
        Rh1 = lv1.cond(x0 > 0.0, branch(R @ wp, 1.0), branch(R @ wn, -1.0))
        h = lv1.maximum(w * g.token(2) + Rh1, 0.0)
        for t in range(3, 10):
            h = lv1.maximum(w * g.token(t) + Mh(R, h, [3,2,1]), 0.0)
        return Mh(Ro, h, [3,2]).argmax()
    pred = lv1.cond(zone, fallback(), p2)
    return g.entry(interpretation=pred)
entry = build()
m = measure(entry); print({k:m[k] for k in ['n_agree','predict_ops','build_ops','cost','fidelity','fidelity_low','reward']})
print("nodes", len(entry['nodes']))
save_entry("hybrid_fast_v3", entry)
