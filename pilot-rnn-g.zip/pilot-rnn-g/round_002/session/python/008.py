
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2)
big = err & (g23/m2>0.3) & (g12/m2>0.3) & (m2>0)
np.set_printoptions(precision=2, suppress=True, linewidth=220)
print(big.sum())
idx = np.where(big)[0][:25]
for i in idx:
    print(X[i], "p1",p1[i],"p2",p2[i],"p3",p3[i],"Y",Y[i])
