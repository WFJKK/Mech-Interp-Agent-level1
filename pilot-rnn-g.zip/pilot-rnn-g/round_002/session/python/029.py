
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(3); X = rng.standard_normal((600000,10)); Y = fwd(X)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3=S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23=m2-np.maximum(m3,0); g12=m1-m2; err=(Y!=p2)
f23=np.sqrt(np.array([1.2,1.,0.7,0.7,0.85,1.,1.2,1.4,1.,1.])); f12=np.sqrt(np.array([1.4,1.2,0.7,0.5,0.7,0.5,0.7,0.7,0.7,1.4]))
z=(g23<0.025)|(g23<0.03*m1*f23[p2])|(g12<0.015)|(g12<0.02*m1*f12[p1])|(m2<0)
o=~z
r23=g23/m1; r12=g12/m1
b1=[0,0.04,0.06,0.09,0.13,0.2,0.3,0.5,10]; b2=[0,0.03,0.05,0.08,0.12,0.2,0.35,0.6,10]
np.set_printoptions(precision=3, suppress=True, linewidth=200)
T=np.zeros((8,8)); N=np.zeros((8,8),int)
for i in range(8):
    for j in range(8):
        mk=o&(r23>=b1[i])&(r23<b1[i+1])&(r12>=b2[j])&(r12<b2[j+1]); T[i,j]=err[mk].mean() if mk.sum() else -1; N[i,j]=mk.sum()
print("rows r23 bins", b1); print("cols r12 bins", b2); print(T); print(N)
# error by m3 negative vs positive, in low r23 bins
for lo,hi in [(0,0.06),(0.06,0.13),(0.13,0.3)]:
    mk=o&(r23>=lo)&(r23<hi)
    print(f"r23 [{lo},{hi}) m3<0: err={err[mk&(m3<0)].mean():.4f} n={(mk&(m3<0)).sum()}  m3>0: err={err[mk&(m3>0)].mean():.4f}")
