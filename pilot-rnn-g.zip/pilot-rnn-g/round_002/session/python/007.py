
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2)
def rate(mask, label):
    print(f"{label}: n={mask.sum()} err={err[mask].mean():.4f}")
for den,name in [(m1,"m1"),(m2,"m2"),(np.abs(X).sum(1),"L1"),(np.sqrt((X**2).sum(1)),"L2"), (np.maximum(X,0).sum(1),"L1+")]:
    r = g23/np.maximum(den,1e-9)
    print(name)
    qs = np.quantile(r[m2>0], np.linspace(0,1,21))
    for i in range(20):
        mk=(m2>0)&(r>=qs[i])&(r<qs[i+1])
        print(f"  [{qs[i]:.3f},{qs[i+1]:.3f}) err={err[mk].mean():.4f}", end="")
    print()
