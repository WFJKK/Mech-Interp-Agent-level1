
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
def prep(seed,n):
    rng = np.random.default_rng(seed); X = rng.standard_normal((n,10)); Y = fwd(X)
    S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
    m1,m2,m3=S[:,0],S[:,1],S[:,2]
    d=dict(X=X,m1=m1,m2=m2,m3=m3,p1=A[:,0],p2=A[:,1],p3=A[:,2],err=(Y!=A[:,1]).astype(float))
    d['g23']=m2-np.maximum(m3,0); d['g12']=m1-m2
    return d
D=prep(7,600000); E=prep(99,400000)
def onehot(p): return (p[:,None]==np.arange(10)[None,:]).astype(float)
def feats(d, p3=False, cross=False):
    l23=np.log(np.maximum(d['g23'],1e-9)/d['m1']); l12=np.log(np.maximum(d['g12'],1e-9)/d['m1'])
    cols=[l23, l12, onehot(d['p1']), onehot(d['p2'])]
    if p3: cols.append(onehot(d['p3']))
    if cross: cols += [onehot(d['p2'])*l23[:,None], onehot(d['p1'])*l12[:,None]]
    return np.column_stack(cols)
FB=0.843
def fit(F,e):
    beta=np.zeros(F.shape[1]); lam=1e-3
    for it in range(30):
        z=F@beta; p=1/(1+np.exp(-z)); W=p*(1-p)
        H=(F*W[:,None]).T@F+lam*np.eye(len(beta)); gr=F.T@(e-p)-lam*beta
        beta+=np.linalg.solve(H,gr)
    return beta
loss = lambda d,z,ops: z.mean()*FB + 10*d['err'][~z].sum()/len(z) + ops/2937
f23=np.sqrt(np.array([1.2,1.,0.7,0.7,0.85,1.,1.2,1.4,1.,1.])); f12=np.sqrt(np.array([1.4,1.2,0.7,0.5,0.7,0.5,0.7,0.7,0.7,1.4]))
zcur=(E['g23']<0.025)|(E['g23']<0.03*E['m1']*f23[E['p2']])|(E['g12']<0.015)|(E['g12']<0.02*E['m1']*f12[E['p1']])|(E['m2']<0)
print("current entry loss (test)", loss(E,zcur,12))
posD=D['m2']>0; posE=E['m2']>0
for p3 in [False, True]:
  for cross in [False, True]:
    F=feats(D,p3,cross)[posD]; beta=fit(F,D['err'][posD])
    pE=1/(1+np.exp(-(feats(E,p3,cross)@beta)))
    ops = 14 + (19 if p3 else 0) + (6 if cross else 0)
    for thr in [0.07,0.084,0.1]:
        z=(E['m2']<0)|(pE>thr)
        print(f"p3={p3} cross={cross} thr={thr}: loss={loss(E,z,ops):.4f} zone={z.mean():.4f} err={E['err'][~z].mean():.5f}")
