
import numpy as np
print(info)
for k,v in weights.items(): print(k, v.shape)
print(list(entries.keys()))
np.set_printoptions(precision=3, suppress=True, linewidth=200)
print("input", weights["input"][:,0])
print("rec\n", weights["recurrent"])
print("readout\n", weights["readout"])
