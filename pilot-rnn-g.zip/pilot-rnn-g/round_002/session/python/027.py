
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
def prep(seed,n):
    rng = np.random.default_rng(seed); X = rng.standard_normal((n,10)); Y = fwd(X)
    S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
    m1,m2,m3=S[:,0],S[:,1],S[:,2]
    d=dict(X=X,m1=m1,m2=m2,m3=m3,p1=A[:,0],p2=A[:,1],p3=A[:,2],err=(Y!=A[:,1]).astype(float))
    d['g23']=m2-np.maximum(m3,0); d['g12']=m1-m2
    d['L1']=np.abs(X).sum(1); d['neg']=-np.minimum(X,0).sum(1); d['pos']=np.maximum(X,0).sum(1)
    return d
D=prep(7,600000); E=prep(99,400000)
def onehot(p): return (p[:,None]==np.arange(10)[None,:]).astype(float)
def feats(d, which):
    cols=[np.log(np.maximum(d['g23'],1e-6)/d['m1']), np.log(np.maximum(d['g12'],1e-6)/d['m1'])]
    if 'pos' in which: cols += [onehot(d['p1']), onehot(d['p2']), onehot(d['p3'])]
    if 'L1' in which: cols += [d['L1']/d['m1']]
    if 'neg' in which: cols += [d['neg']/d['m1'], (d['pos']-d['m1']-d['m2'])/d['m1']]
    if 'm3' in which: cols += [np.maximum(d['m3'],0)/d['m1']]
    cols.append(np.ones(len(d['m1'])))
    return np.column_stack(cols)
FB=0.843
def fit(F,e):
    beta=np.zeros(F.shape[1]); lam=1e-3
    for it in range(30):
        z=F@beta; p=1/(1+np.exp(-z)); W=p*(1-p)
        H=(F*W[:,None]).T@F+lam*np.eye(len(beta)); gr=F.T@(e-p)-lam*beta
        beta+=np.linalg.solve(H,gr)
    return beta
zone_fn=lambda d: (d['g23']<0.025)|(d['g23']<0.03*d['m1'])|(d['g12']<0.015)|(d['g12']<0.02*d['m1'])|(d['m2']<0)
zD=zone_fn(D); zE=zone_fn(E)
base_loss = lambda d,z: z.mean()*FB + 10*d['err'][~z].sum()/len(z)
print("base loss test", base_loss(E,zE))
for which in [[], ['pos'], ['pos','L1'], ['pos','L1','neg','m3'], ['L1','neg','m3']]:
    F=feats(D,which)[~zD]; beta=fit(F,D['err'][~zD])
    FE=feats(E,which); pE=1/(1+np.exp(-(FE@beta)))
    for thr in [0.06,0.084,0.1,0.12]:
        z=zE|(pE>thr)
        print(which, thr, "loss", round(base_loss(E,z),4), "zone", round(z.mean(),4), "err", round(E['err'][~z].mean(),5))
