
import numpy as np, importlib
for m in ["sklearn","scipy","torch"]:
    try: importlib.import_module(m); print(m,"ok")
    except Exception as e: print(m,"no")
