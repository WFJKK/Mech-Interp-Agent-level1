
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone = (g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)
print("zone frac", zone.mean(), "err in zone", (Y[zone]!=p2[zone]).mean(), "err outside", (Y[~zone]!=p2[~zone]).mean())
# what does the network output in error cases: rank of chosen
rank = np.argsort(np.argsort(-X,1),1)  # rank of each position
rY = rank[np.arange(len(Y)),Y]
for name,mask in [("zone",zone),("outside",~zone),("m2<0",m2<0)]:
    e = mask & (Y!=p2)
    print(name, "n err", e.sum(), "rank dist", np.bincount(rY[e], minlength=10))
# m2<0 cases: what does the network pick
e = (m2<0)
print("m2<0: n", e.sum(), "picks p1", (Y[e]==p1[e]).mean(), "picks p2", (Y[e]==p2[e]).mean(), "picks p3",(Y[e]==p3[e]).mean())
print("output position dist for m2<0 errors", np.bincount(Y[e&(Y!=p2)], minlength=10))
print("positions of p2 in m2<0", np.bincount(p2[e],minlength=10))
