
e = entries["hybrid_fast_v2"]
print(len(e['nodes']))
import json
consts = [n for n in e['nodes'] if n.get('op') in ('const','constant')]
print(len(consts), [ (n.get('op'), np.asarray(n.get('value', n.get('data', 0))).size) for n in e['nodes'] if 'const' in str(n.get('op'))][:10])
print(e['nodes'][0])
