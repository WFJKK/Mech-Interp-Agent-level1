
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone = (g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)
o = ~zone; err = (Y!=p2)
def rate(mask, label):
    print(f"{label}: n={mask.sum()} err={err[mask].mean():.4f}")
rate(o&(p2<p1), "p2 before p1"); rate(o&(p2>p1), "p2 after p1")
rate(o&(p3<p2), "p3 before p2"); rate(o&(p3>p2), "p3 after p2")
for a in range(10):
    rate(o&(p2==a), f"p2 pos {a}")
print()
for a in range(10):
    rate(o&(p1==a), f"p1 pos {a}")
print()
for a in range(10):
    rate(o&(p3==a), f"p3 pos {a}")
# relative gap bins
rel = g23/np.maximum(m2,1e-9)
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1),(1,10)]:
    rate(o&(rel>=lo)&(rel<hi), f"rel gap23 [{lo},{hi})")
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,1),(1,10)]:
    rate(o&(g12>=lo)&(g12<hi), f"g12 [{lo},{hi})")
