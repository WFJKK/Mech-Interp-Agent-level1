
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2).astype(float)
zone0 = (g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)
def reward(zone, cost_rule=75/2937):
    # fallback exact on zone, p2 elsewhere
    e = err[~zone].sum()/len(err)
    cost = cost_rule + zone.mean()
    return 1-cost-10*e, zone.mean(), e
print("zone0", reward(zone0))
# in-zone sub-bins
pos = m2>0
for name,mk in [("m2<0",m2<0),("g12<0.02",pos&(g12<0.02)),("g12<0.01",pos&(g12<0.01)),("g12 in[0.01,0.02)",pos&(g12>=0.01)&(g12<0.02)),
                ("g23<0.04 only",pos&(g23<0.04)&(g12>=0.02)),("g23<0.02",pos&(g23<0.02)),("g23 in [0.02,0.04)",pos&(g23>=0.02)&(g23<0.04)),
                ("g23 in [0.04,0.06)",pos&(g23>=0.04)&(g23<0.06)),("rel<0.04 & g23>0.04",pos&(g23<0.04*m2)&(g23>=0.04)),
                ("g23/m1<0.03 & g23>=0.04 & rel>=0.04", pos&(g23/m1<0.03)&(g23>=0.04)&(g23>=0.04*m2)),
                ("g23/m1 in [0.03,0.05) & not zone", pos&(g23/m1<0.05)&(g23/m1>=0.03)&~zone0),
                ("g12/m1 <0.03 not zone", pos&(g12/m1<0.03)&~zone0),("g12/m1 in [0.03,0.06) not zone", pos&(g12/m1<0.06)&(g12/m1>=0.03)&~zone0)]:
    print(f"{name}: n={mk.sum()} err={err[mk].mean():.3f}")
