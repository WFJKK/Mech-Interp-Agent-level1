
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
err = (Y!=p2)
FB=0.843; RULE=80/2937
def est(zone):
    e = err[~zone].sum()/len(err)
    return 1-RULE-zone.mean()*FB-10*e, zone.mean(), e
print("round1 thresholds", est((g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)))
best=[]
for a in [0.03,0.035,0.04,0.045,0.05,0.055,0.06]:
    for b in [0.03,0.04,0.05,0.06,0.07]:
        for c in [0.015,0.02,0.025,0.03,0.04]:
            for d in [0, 0.02, 0.03, 0.04]:
                z=(g23<a)|(g23<b*m2)|(g12<c)|(g12<d*m1)|(m2<0)
                r,zf,e=est(z); best.append((r,a,b,c,d,zf,e))
best.sort(reverse=True)
for b in best[:12]: print(b)
# also with g23 relative to m1
best2=[]
for a in [0.03,0.04,0.05]:
    for b in [0.02,0.03,0.04,0.05]:
        for c in [0.02,0.03]:
            z=(g23<a)|(g23<b*m1)|(g12<c)|(m2<0)
            r,zf,e=est(z); best2.append((r,a,b,c,zf,e))
best2.sort(reverse=True)
for b in best2[:5]: print("m1-rel", b)
