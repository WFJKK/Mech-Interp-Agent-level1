
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone = (g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)
o=~zone; err = (Y!=p2)
def table(r, mask, name, nb=15):
    qs = np.quantile(r[mask], np.linspace(0,1,nb+1)); print(name)
    for i in range(nb):
        mk=mask&(r>=qs[i])&(r<=qs[i+1]); print(f"  [{qs[i]:.3f},{qs[i+1]:.3f}) n={mk.sum()} err={err[mk].mean():.4f}")
table(m2/m1, o, "m2/m1 outside zone")
negsum = np.minimum(X,0).sum(1)
table(m2/(m1-negsum), o, "m2/(m1+|neg|) outside")
table(m2/np.sqrt((X**2).sum(1)), o, "m2/L2 outside")
