
import numpy as np
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
np.set_printoptions(precision=2, suppress=True, linewidth=220)
def fwd(X):
    h = np.zeros((X.shape[0],16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return (h@Ro.T), np.stack(H,1)
# single positive at position i
Xs = np.eye(10)
L,H = fwd(Xs)
print("single +1 at i -> output", L.argmax(1))
print("single -1 at i -> output", fwd(-np.eye(10))[0].argmax(1))
# two positives: x_i=1, x_j=r
for r in [0.3,0.6,0.9,0.97]:
    out = np.zeros((10,10),int)
    for i in range(10):
        for j in range(10):
            if i==j: out[i,j]=-1; continue
            x=np.zeros((1,10)); x[0,i]=1; x[0,j]=r
            out[i,j]=fwd(x)[0].argmax()
    print("r",r, "rows i (max pos), cols j (second pos): output\n", out)
