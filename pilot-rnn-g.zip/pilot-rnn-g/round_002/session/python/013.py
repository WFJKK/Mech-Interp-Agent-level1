
import numpy as np
X, Y, ops = network_outputs()
X = np.asarray(X, dtype=float); Y = np.asarray(Y)
w = weights["input"][:,0]; R = weights["recurrent"]; Ro = weights["readout"]
def fwd(X):
    h = np.zeros((X.shape[0],16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
S = np.sort(X,1)[:,::-1]; A = np.argsort(X,1)[:,::-1]
m1,m2,m3 = S[:,0],S[:,1],S[:,2]; p1,p2,p3=A[:,0],A[:,1],A[:,2]
g23 = m2-np.maximum(m3,0); g12=m1-m2
zone = (g23<0.04)|(g23<0.04*m2)|(g12<0.02)|(m2<0)
def rep(name, Xm):
    P = fwd(Xm); print(f"{name}: agree all={(P==Y).mean():.4f} zone={(P[zone]==Y[zone]).mean():.4f} outside={(P[~zone]==Y[~zone]).mean():.4f}  outside-vs-p2 {(P[~zone]==p2[~zone]).mean():.4f}")
rep("relu(x)", np.maximum(X,0))
rank = np.argsort(np.argsort(-X,1),1)
for k in [2,3,4,5]:
    rep(f"top{k} only", np.where(rank<k, X, 0))
rep("top3 + negatives", np.where((rank<3)|(X<0), X, 0))
rep("clip neg at -0.5", np.maximum(X,-0.5))
rep("x*0.5 for neg", np.where(X<0, 0.5*X, X))
