# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 3 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx real numbers, x_0 to x_(n_ctx - 1). The network reads them one at a time, in that order.
In an entry, g.token(t) is x_t, as a float, and g.tokens() is all of them; the output is still a whole number.

The network is a recurrent network with one layer of d_hidden units, a ReLU and no biases. Its weights:

    input       d_hidden x 1
    recurrent   d_hidden x d_hidden
    readout     n_outputs x d_hidden

Its state h, a vector of d_hidden numbers, starts at zero. At each position t, in order, it becomes

    h = relu(input x_t + recurrent h)

where relu sets every negative number to zero. After the last position, readout h gives n_outputs numbers,
and the output is the position of the highest (the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)  # the first position: the state before it is zero, and so is recurrent h
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()
```

Sizes: n_ctx = 10, d_hidden = 16, outputs: 10. One forward pass of the network costs 2,937 operations under the prices
below.

## The data set

An input is ten real numbers, x_0 to x_9, each drawn on its own from the standard normal distribution (mean 0, standard deviation 1). The data set is every input that can be drawn this way, each weighted by how likely it is to be drawn. There are infinitely many, so the verifier scores a sample.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.7033 | 0.8394 | 0.98902 | 0.0335 | 0.99100 | 0.97000 |
| r1s2 | scored | 0.7221 | 1.0000 | 0.98755 | 0.1353 | 0.98800 | 0.97500 |
| r1s3 | scored | 0.7261 | 1.0000 | 0.98724 | 0.1280 | 0.98800 | 0.97500 |
| r1s4 | scored | 0.7313 | 1.0000 | 0.99103 | 0.1633 | 0.99000 | 0.98000 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the second-largest of the ten inputs** (the index of the 2nd-highest x_t). On random normal inputs it agrees with exact second-argmax on ~95.5% of inputs. Its errors are concentrated where the task is nearly ambiguous: when the 2nd and 3rd largest values are within ~0.05 of each other (error 25–30% when the gap is < 0.03), when the 1st and 2nd are within ~0.02 (it then often picks the max), and when the 2nd-largest value is negative (≈70% wrong; the network effectively treats negative values as ~0, so the relevant gap is v2 − max(v3, 0)). Resolution is roughly relative: errors rise again for large v2 (>1.5) at the same absolute gap. Outside those zones the residual error (~1.2% of all inputs) is diffuse — not predictable from positions, sums, counts of positives, or order of the near-tied tokens (a logistic regression on many such features gave no gain). I am very confident about the second-argmax description; the error structure is well characterised statistically but not mechanistically.
    
    ## How you found it
    Looked at outputs first: the class mean of x_c given output c was ~1.0 for every c but P(output = argmax) was below chance (0.9%); the rank of x_output was 1 (second) 95.5% of the time. Then tabulated the error rate against sorted-value gaps (g12, g23), v2, v3, positions, npos, and fitted small logistic models on halves of the sample. Weights: input weights are large on units 1,6,7,8 (negative-x detectors), unit 4 (positive-x detector); unit 2 tracks the running max (corr 0.89); ablating any single hidden unit destroys accuracy, so no cheap pruned forward pass exists; R is essentially full rank (no low-rank saving). Everything above was done on the 16,384-input `network_outputs()` sample with a numpy re-implementation of the forward pass (verified to match 100%).
    
    ## The best entry
    `hybrid_sort_v2` (and the near-identical `hybrid_sort_v1` with tighter thresholds). Region: every input. Interpretation: sort the ten tokens (40 ops), take m1, m2, m3 = top three values, p2 = position of m2 via `(x == m2).argmax()`. Compute g23 = m2 − max(m3, 0) and g12 = m1 − m2. If the input is in the "ambiguous zone" — g23 < 0.04 or g23 < 0.04·m2 or g12 < 0.02 or m2 < 0 (v1 uses 0.03/0.03/0.01/0) — a `lv1.cond` runs the full forward pass of the network (exact, cost 1); otherwise it answers p2. The saving comes from answering ~85–89% of inputs with ~75 operations (≈2.5% of a forward pass) and paying for the real network only where the second-argmax rule is unreliable (p_err > ~10%, the break-even against the ×10 error penalty). Measured: coverage 1, fidelity 0.991 (v2) / 0.987 (v1), cost 0.163 / 0.128, reward 0.731 / 0.726. The pure-region entry `second_argmax_margin` (region = clear margin, interpretation = p2, no fallback) is equivalent in value and scored 0.703.
    
    ## Claims
    Claimed fidelity 0.99 for v2 (0.988 for v1) on this network — measured 0.991 / 0.987, so the claims were on target (overclaim ≤ 0.0008). For the second network I expect ~0.98 (v2) / ~0.975 (v1): the entry recomputes the forward pass from that network's weights, so the ambiguous zone is exact by construction; the only risk is the other network's residual error outside the zone, which should be similar (~1–1.5%) if it was trained the same way, but could be larger if that network is less accurate, which is why I claimed below the measured value here.
    
    ## Next
    (1) Reverse-engineer the mechanism (unit 2 = running max, units 1/6/7/8 = negative-input detectors, 4 = "current input exceeds running max" detector, 5/9 = previous input) to find a cheaper surrogate that reproduces the network's near-tie decisions; a surrogate costing ≤0.3 of a forward pass with ≥99.5% agreement in the moderate-gap band (gap 0.03–0.2, where 1–8% of errors live) would add ~0.05–0.1. (2) Try a reduced forward pass that only runs in the ambiguous zone with the top-3 readout rows (saves ~4% of the fallback cost) once rare "picks 4th or worse" cases are understood. (3) Re-tune the zone thresholds on a fresh sample (verifier samples show ~1.25% residual error vs 1.1% on the fixed sample), and consider slightly more generous thresholds for robustness on the second network since the fallback is exact there.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.7627 | 1.0000 | 0.99188 | 0.1412 | 0.99200 | 0.98500 |
| r2s2 | scored | 0.7684 | 1.0000 | 0.99249 | 0.1421 | 0.99200 | 0.98500 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the second-largest of the ten inputs** (confirmed again: exact second-argmax agrees on 95.4% of inputs; on clean two-value inputs x_i=1, x_j=r it is perfect for every pair of positions and r up to ~0.97). The network has no biases, so it is positively homogeneous: only the *direction* of x matters, and every error scale is relative (gaps normalised by the max m1 work slightly better than by m2). Errors are concentrated where the task is nearly ambiguous: g23 = m2 − max(m3,0) small, g12 = m1 − m2 small, or m2 < 0 (negative values act like ≈0). The remaining ≈0.8% "diffuse" error outside the ambiguous zone is deterministic interference from the *other* values (running the network on only the top-2 values agrees with second-argmax 99.5% outside the zone; adding the 3rd value and the negatives creates the errors). It is mildly predictable: higher when p1, p2 ∈ {0, 6, 7, 9}, when p3 is late (7–9), when m3 < 0 and g23/m1 < 0.06, and when both g23/m1 < 0.06 and g12/m1 < 0.05 (≈10–12%). But no cheaply-computable subset outside the zone has error above the ≈8% break-even, so the residual cannot be profitably removed; a logistic model on ~45 features (positions one-hot, log relative gaps, sums) finds a 2% subset at 16% error, worth less than its own cost. The network is dense/chaotic: zeroing recurrent entries |r|<0.02 loses 18% agreement, top-k-per-row pruning destroys it, the final state is high-dimensional (16 non-negligible singular values), so no cheap approximate surrogate exists.
    
    ## How you found it
    Numpy re-implementation of the forward pass (matches the 16,384 given outputs 100%), then fresh samples of 400k–600k normal inputs for low-noise tuning. Tabulated error rate vs. relative gaps (normalised by m1, m2, L1, L2), positions of p1/p2/p3, 2-D gap tables, m3 sign; fitted IRLS logistic regressions on held-out data; tested sparsified recurrent matrices; measured per-step, per-unit activation sparsity on the zone inputs; probed the network on hand-made clean inputs. For the entry itself, I derived an exact cheaper forward pass from the structure h0 = x0·relu(±w): the activation pattern of h1 depends only on ρ = x1/|x0| through 16 breakpoints, so R·h1 = x1·Tw[k] + x0·Tv[k] with build-time tables (17 regions × 2 signs) and k = #breakpoints below ρ; and I exploited that hidden units 4, 9, 5 are zero most of the time (89%, 88%, 68%) with nested `lv1.cond` to multiply by a 13/14/15-column slice of a unit-permuted R.
    
    ## The best entry
    `hybrid_fast_v3` (reward 0.7684 scored; 0.776 on the fixed sample; nodes 295, 42 constants). Region: every input. Interpretation: sort the tokens (40 ops) → m1, m2, m3; p2 = (x == m2).argmax(); p1 = x.argmax(); zone = g23 < 0.025 | g23 < 0.03·m1·f23[p2] | g12 < 0.015 | g12 < 0.02·m1·f12[p1] | m2 < 0, with mild position factors f23, f12 (sqrt-shrunk, ≈0.7–1.2). Outside the zone (≈84.5% of inputs) it answers p2 at ≈80 ops; inside (≈15.5%) `lv1.cond` runs an exact but cheaper forward pass (≈0.76 of a forward pass instead of 1): steps 0–1 replaced by the breakpoint-table lookup (≈113 ops instead of ≈335), steps 3–9 and the readout use nested conds that skip the columns of the (permuted) recurrent/readout matrices for units 5, 9, 4 when they are exactly zero. Fidelity is unchanged from round 1's zone (≈0.992–0.993); cost fell from 0.163 to 0.142; the position factors add ≈+0.004.
    
    ## Claims
    Claimed 0.992 on this network: measured 0.9925 (overclaim 0). For the second network I expect ≈0.985: the fallback is computed from that network's weights so the zone is exact by construction; the hard-coded unit permutation only affects cost (if other units are sparse there, the conds just fail: ≈+5 ops/step), and the position factors are small. The only real risk is that network's own residual error outside the zone being larger than ≈0.8%, which is why I claim below the measurement here.
    
    ## Next
    (1) Remaining structural gains are small: thresholds and position factors are at the optimum (±0.001 on 600k held-out inputs); the fallback is ≈2,240 ops and only the 7 remaining 16×16 recurrent matmuls are left (already ≈230 ops each via sparsity conds). (2) A possible further saving is a step-2 table on (k, activation pattern of h2) if the number of geometrically realisable patterns is small enough to enumerate at build time cheaply (build cost must stay ≪ 1M ops since it is amortised over only 16,384 inputs). (3) If more fidelity is wanted, a cheap rule for the cells {g23/m1 < 0.06 & g12/m1 < 0.05} and {m3 < 0 & g23/m1 < 0.06} (≈10% error) adds ≈+0.001; everything else outside the zone is below the 8% break-even. (4) Do not spend effort on surrogates: the recurrence is dense and sensitive, and its residual errors are interference effects that only the real dynamics reproduce.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.7684) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
