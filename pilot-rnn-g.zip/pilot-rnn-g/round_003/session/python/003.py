
print("w", w)
print("R max per row", R.max(1))
print("R min per row", R.min(1))
Xz = X[zone]; Hz = H[zone]
# certificate: w_j x_t + max_k R_jk * sum(h_{t-1}) < 0
cert = np.zeros((10,16)); zero = np.zeros((10,16))
for t in range(1,10):
    hp = Hz[:,t-1]; l1 = hp.sum(1)
    bound = w[None,:]*Xz[:,t:t+1] + R.max(1)[None,:]*l1[:,None]
    cert[t] = (bound<0).mean(0); zero[t] = (Hz[:,t]==0).mean(0)
print("cert frac\n", cert[1:]); print("zero frac\n", zero[1:])
# tighter: use max of R_jk over k with k active? no. Use bound with L-inf: max_k R_jk*h_k <= ... same. 
# alternative bound using h_max: sum_k max(R_jk,0) h_k <= (sum_k max(R_jk,0)) * max(h)
cert2 = np.zeros((10,16))
for t in range(1,10):
    hp = Hz[:,t-1]; hm = hp.max(1)
    bound = w[None,:]*Xz[:,t:t+1] + np.maximum(R,0).sum(1)[None,:]*hm[:,None]
    cert2[t] = (bound<0).mean(0)
print("cert2 frac\n", cert2[1:])
