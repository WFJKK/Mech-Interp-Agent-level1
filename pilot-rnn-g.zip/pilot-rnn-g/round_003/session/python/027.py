
import numpy as np, time
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
F23 = np.array(entries['best']['nodes'][23]['value'])
for name, seed, reported in [("fold_v2", 3455043299306422092, 16254), ("fold_v3", 15020548907487623766, 16249), ("fold_v3", 5295256198092107378, 16247)]:
    for rngf in [np.random.default_rng]:
        rng = rngf(seed)
        Xs = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
        y = fwd(Xs)
        order = np.argsort(Xs, axis=1); p2 = order[:,8]; ar=np.arange(len(Xs))
        m1,m2,m3 = Xs[ar,order[:,9]], Xs[ar,p2], Xs[ar,order[:,7]]
        g23 = m2-np.maximum(m3,0); g12 = m1-m2
        z = (g23<np.maximum(1.1*F23[p2]*m1,0.03))|(g12<0.022*m1)|(m2<0)
        print(name, seed, "reported agree", reported, "| sim agree", 16384-((y!=p2)&~z).sum(), "zone", z.mean(), "first input", Xs[0,:3])
