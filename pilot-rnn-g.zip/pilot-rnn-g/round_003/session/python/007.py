
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(1)
X = rng.standard_normal((600000,10))
y = fwd(X)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1); p3 = (X==m3[:,None]).argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
z23 = (g23<0.025)|(g23<0.03*m1)
z12 = (g12<0.015)|(g12<0.02*m1)
zneg = m2<0
print("fracs z23 z12 zneg", z23.mean(), z12.mean(), zneg.mean(), "overlap", (z23&z12).mean())
# in z12 only (not z23, not zneg): outputs
sel = z12 & ~z23 & ~zneg
print("z12-only frac", sel.mean(), "out==p1", (y[sel]==p1[sel]).mean(), "out==p2", (y[sel]==p2[sel]).mean())
# vs order
for name, m in [("p1<p2", p1<p2), ("p1>p2", p1>p2)]:
    s = sel & m
    print(name, s.sum(), "out==p1", (y[s]==p1[s]).mean(), "out==p2", (y[s]==p2[s]).mean())
# as function of g12/m1 bins and order
rel = g12/m1
for lo,hi in [(0,0.005),(0.005,0.01),(0.01,0.015),(0.015,0.02)]:
    s = sel & (rel>=lo)&(rel<hi)
    print(lo,hi, s.sum(), "P(out=p1) early-p1", (y[s&(p1<p2)]==p1[s&(p1<p2)]).mean(), "late-p1", (y[s&(p1>p2)]==p1[s&(p1>p2)]).mean())
sel3 = z23 & ~z12 & ~zneg
print("z23-only frac", sel3.mean(), "out==p2", (y[sel3]==p2[sel3]).mean(), "out==p3", (y[sel3]==p3[sel3]).mean())
for name, m in [("p2<p3", p2<p3), ("p2>p3", p2>p3)]:
    s = sel3 & m
    print(name, s.sum(), "out==p2", (y[s]==p2[s]).mean(), "out==p3", (y[s]==p3[s]).mean())
rel3 = g23/m1
for lo,hi in [(0,0.005),(0.005,0.01),(0.01,0.02),(0.02,0.03)]:
    s = sel3 & (rel3>=lo)&(rel3<hi)
    print(lo,hi, s.sum(), "P(out=p2) early-p2", (y[s&(p2<p3)]==p2[s&(p2<p3)]).mean(), "late-p2", (y[s&(p2>p3)]==p2[s&(p2>p3)]).mean())
