
import numpy as np, time
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
F23 = np.array(entries['best']['nodes'][23]['value'])
ss = np.random.SeedSequence(777)
counts=[]; t0=time.time()
for seed in ss.generate_state(150, dtype=np.uint64):
    rng = np.random.default_rng(int(seed))
    Xs = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
    y = fwd(Xs)
    order = np.argsort(Xs, axis=1); p2 = order[:,8]; ar=np.arange(len(Xs))
    m1,m2,m3 = Xs[ar,order[:,9]], Xs[ar,p2], Xs[ar,order[:,7]]
    g23 = m2-np.maximum(m3,0); g12 = m1-m2
    z = (g23<np.maximum(1.1*F23[p2]*m1,0.03))|(g12<0.022*m1)|(m2<0)
    counts.append(((y!=p2)&~z).sum())
counts=np.array(counts)
print("time", time.time()-t0, "mean", counts.mean(), "sd", counts.std(), "quantiles", np.quantile(counts,[0.05,0.25,0.5,0.75,0.95]), "P(>=130)", (counts>=130).mean())
e = counts/16384
rew = 1 - 0.134 - 10*(e + 1.96*np.sqrt(e*(1-e)/16384))
print("reward mean", rew.mean(), "sd", rew.std(), "quantiles", np.quantile(rew,[0.05,0.5,0.95]))
