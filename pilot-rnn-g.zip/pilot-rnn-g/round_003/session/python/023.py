
import numpy as np, itertools
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(2024)
X = lv1.draw_inputs(info['data_set'], info['input_space'], 1500000, rng)
y = fwd(X)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
err = (y!=p2)
F23 = np.array(entries['best']['nodes'][23]['value'])
CFB, CCH = 2105., 56.
def reward(zone):
    cost = (CCH + CFB*zone.mean())/2937
    e = (err & ~zone).mean()
    return 1 - cost - 10*e - 10*1.96*np.sqrt(e*(1-e)/16384)
def mk(f, a23, u12): return (g23<np.maximum(f[p2]*m1, a23))|(g12<u12*m1)|(m2<0)
f = 1.1*F23; a23=0.03; u12=0.022
cur = reward(mk(f,a23,u12)); print("start", cur)
# split into two halves to check overfitting
half = np.arange(len(X)) < len(X)//2
def reward_h(zone, hsel):
    cost = (CCH + CFB*zone[hsel].mean())/2937
    e = (err[hsel] & ~zone[hsel]).mean()
    return 1 - cost - 10*e - 10*1.96*np.sqrt(e*(1-e)/16384)
for it in range(3):
    for i in range(10):
        bestv, bestr = f[i], reward_h(mk(f,a23,u12), half)
        for v in f[i]*np.array([0.8,0.9,1.1,1.2,1.3]):
            f2 = f.copy(); f2[i]=v; r = reward_h(mk(f2,a23,u12), half)
            if r > bestr: bestr, bestv = r, v
        f[i] = bestv
    for a in [0.02,0.025,0.03,0.035,0.04]:
        if reward_h(mk(f,a,u12), half) > reward_h(mk(f,a23,u12), half): a23 = a
    for u in [0.018,0.02,0.022,0.024,0.026]:
        if reward_h(mk(f,a23,u), half) > reward_h(mk(f,a23,u12), half): u12 = u
    print(it, "train", reward_h(mk(f,a23,u12), half), "test", reward_h(mk(f,a23,u12), ~half), "base test", reward_h(mk(1.1*F23,0.03,0.022), ~half))
print("f", list(np.round(f,5)), "a23", a23, "u12", u12)
