
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X, dt=np.float64):
    w_, R_, Ro_ = w.astype(dt), R.astype(dt), Ro.astype(dt)
    X = X.astype(dt); N = X.shape[0]; h = np.zeros((N,16), dtype=dt)
    for t in range(10):
        h = np.maximum(w_[None,:]*X[:,t:t+1] + h@R_.T, 0)
    return (h@Ro_.T).argmax(1)
F23 = np.array(entries['best']['nodes'][23]['value'])
rng = np.random.default_rng(99)
X = lv1.draw_inputs(info['data_set'], info['input_space'], 500000, rng)
y64 = fwd(X); y32 = fwd(X, np.float32)
order = np.argsort(X, axis=1); p2 = order[:,8]; ar=np.arange(len(X))
m1,m2,m3 = X[ar,order[:,9]], X[ar,p2], X[ar,order[:,7]]
g23 = m2-np.maximum(m3,0); g12 = m1-m2
z = (g23<np.maximum(1.1*F23[p2]*m1,0.03))|(g12<0.022*m1)|(m2<0)
d = y64!=y32
print("float32 vs 64 disagreement: all", d.mean(), "in zone", (d&z).sum()/z.sum(), "outside", (d&~z).sum()/(~z).sum())
print("err outside 64:", ((y64!=p2)&~z).mean(), "err outside 32:", ((y32!=p2)&~z).mean())
# how large is the typical logit margin outside zone? sensitivity to tiny perturbation of weights
def fwd_pert(X, eps, seed):
    r = np.random.default_rng(seed)
    R2 = R*(1+eps*r.standard_normal(R.shape)); w2 = w*(1+eps*r.standard_normal(w.shape))
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w2[None,:]*X[:,t:t+1] + h@R2.T, 0)
    return (h@Ro.T).argmax(1)
for eps in [1e-7, 1e-5, 1e-3]:
    yp = fwd_pert(X[:200000], eps, 1); dd = yp != y64[:200000]
    print("eps", eps, "disagree all", dd.mean(), "outside", (dd&~z[:200000]).sum()/(~z[:200000]).sum(), "inside", (dd&z[:200000]).sum()/z[:200000].sum())
