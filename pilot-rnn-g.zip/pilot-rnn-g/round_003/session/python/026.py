
import numpy as np
np.set_printoptions(precision=17, linewidth=150)
print(weights['input'][:6,0])
print(weights['recurrent'][0,:6])
print(weights['readout'][0,:6])
print(weights['recurrent'].dtype)
# are they float32-representable?
for k,v in weights.items():
    print(k, "float32-exact:", np.all(v.astype(np.float32).astype(np.float64)==v), "decimals≤4:", np.all(np.abs(np.round(v,4)-v)<1e-12), "≤6:", np.all(np.abs(np.round(v,6)-v)<1e-12))
no = network_outputs()
print(type(no), (no.keys() if isinstance(no, dict) else len(no)))
