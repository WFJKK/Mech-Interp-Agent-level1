
import numpy as np, time
e = entries['fold_v3']
rng = np.random.default_rng(5)
W2 = {k: v + 0.3*rng.standard_normal(v.shape)*np.abs(v).mean() for k,v in weights.items()}
# a more realistic "other seed": permute hidden units of the real network (same function) + small noise
perm = rng.permutation(16)
W3 = {'input': weights['input'][perm], 'recurrent': weights['recurrent'][perm][:,perm], 'readout': weights['readout'][:,perm]}
Xs = rng.standard_normal((4000,10))
def fwd(X, W):
    w = W['input'][:,0]; R = W['recurrent']; Ro = W['readout']
    h = np.zeros((len(X),16))
    for t in range(10): h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
S = np.sort(Xs,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (Xs==m2[:,None]).argmax(1)
for name, W in [("orig", weights), ("perturbed", W2), ("unit-permuted", W3)]:
    ev = lv1.Evaluator(e, W, 10)
    outs = [ev.run(xi) for xi in Xs]
    pred = np.array([o[1] for o in outs]); ops = np.array([o[3] for o in outs])
    y = fwd(Xs, W)
    fb = ops > 100
    print(name, "agreement all", (pred==y).mean(), "| fallback inputs:", fb.mean(), "agreement", (pred[fb]==y[fb]).mean(), "mean fallback ops", ops[fb].mean(), "| cheap agreement", (pred[~fb]==y[~fb]).mean(), "cheap ops", ops[~fb].mean())
