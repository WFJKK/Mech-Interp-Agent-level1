
import numpy as np, itertools
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(11)
X = rng.standard_normal((1000000,10))
y = fwd(X)
S = np.sort(X,1); m1,m2,m3,m4 = S[:,-1],S[:,-2],S[:,-3],S[:,-4]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
err = (y!=p2)
F23 = np.array(entries['best']['nodes'][23]['value'])
z0 = (g23<0.03)|(g23<1.1*F23[p2]*m1)|(g12<0.022*m1)|(m2<0)
rank = (X > X[np.arange(len(X)), y][:,None]).sum(1)
o = ~z0
npos = (X>0).sum(1)
print("outside: err by npos", [(n, round((err&o&(npos==n)).sum()/max(1,(o&(npos==n)).sum()),4), round((o&(npos==n)).mean(),4)) for n in range(0,11)])
# rank>=3 errors outside: npos, m2
o3 = o & err & (rank>=3)
print("rank>=3 errs outside frac of inputs", o3.mean(), "npos dist", np.bincount(npos[o3], minlength=11)/o3.sum())
print("m2 quantiles", np.quantile(m2[o3],[0.1,0.5,0.9]), "m1 q", np.quantile(m1[o3],[0.1,0.5,0.9]))
# error rate outside for m3<0 by m2 bins
sel = o & (m3<0)
for lo,hi in [(0,0.3),(0.3,0.5),(0.5,0.7),(0.7,1),(1,1.5),(1.5,9)]:
    s = sel&(m2>=lo)&(m2<hi); print("m3<0, m2 in",lo,hi, "frac", round(s.mean(),5), "err", round((err&s).sum()/max(1,s.sum()),4))
# error rate outside for npos==3 by m3 
sel = o & (npos==3)
for lo,hi in [(0,0.1),(0.1,0.2),(0.2,0.4),(0.4,9)]:
    s = sel&(m3>=lo)&(m3<hi); print("npos3, m3 in",lo,hi, "frac", round(s.mean(),5), "err", round((err&s).sum()/max(1,s.sum()),4))
# general: outside error by m2 (small m2 means weak signal?)
for lo,hi in [(0,0.3),(0.3,0.5),(0.5,0.7),(0.7,1),(1,1.5),(1.5,9)]:
    s = o&(m2>=lo)&(m2<hi); print("m2 in",lo,hi, "frac", round(s.mean(),5), "err", round((err&s).sum()/max(1,s.sum()),4))
