
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X, w=w, R=R, Ro=Ro):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(0)
X = rng.standard_normal((200000,10))
y = fwd(X)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
zone = (g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
Xz = X[zone]; yz = y[zone]
print("zone n", len(Xz))
for j in range(16):
    R2 = R.copy(); R2[:,j]=0; R2[j,:]=0; w2=w.copy(); w2[j]=0
    print(j, "ablate agreement in zone", (fwd(Xz,w2,R2,Ro)==yz).mean(), " overall", (fwd(X[:50000],w2,R2,Ro)==y[:50000]).mean())
# low-rank R
U,s,Vt = np.linalg.svd(R)
for r in [15,14,13,12]:
    Rr = (U[:,:r]*s[:r])@Vt[:r]
    print("rank",r,"agreement zone", (fwd(Xz,w,Rr,Ro)==yz).mean())
for thr in [0.005,0.01,0.02]:
    Rp = np.where(abs(R)<thr,0,R); print("prune",thr,"nnz",(Rp!=0).sum(),"agreement zone",(fwd(Xz,w,Rp,Ro)==yz).mean())
