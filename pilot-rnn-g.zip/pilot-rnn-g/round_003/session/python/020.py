
import numpy as np, time, inspect
print(inspect.signature(lv1.draw_inputs))
rng = np.random.default_rng(12345)
t0=time.time()
Xd = lv1.draw_inputs(info['data_set'], info['input_space'], 100000, rng)
print(Xd.shape, Xd.dtype, Xd.mean(), Xd.std(), time.time()-t0)
print("unique check", len(np.unique(Xd[:,0])), np.quantile(Xd[:,0],[0.001,0.5,0.999]))
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
y = fwd(Xd)
S = np.sort(Xd,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (Xd==m2[:,None]).argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
F23 = np.array(entries['best']['nodes'][23]['value'])
z0 = (g23<np.maximum(1.1*F23[p2]*m1,0.03))|(g12<0.022*m1)|(m2<0)
print("draw_inputs: zone frac", z0.mean(), "outside err", ((y!=p2)&~z0).mean())
# compare against reference evaluator on a subset
t0=time.time()
ref = lv1.run_reference(model.reference if False else None, weights, 10, Xd[:2000]) if False else None
print("time", time.time()-t0)
