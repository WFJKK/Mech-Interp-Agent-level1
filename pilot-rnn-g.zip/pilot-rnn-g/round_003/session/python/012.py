
import numpy as np, itertools
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(7)
X = rng.standard_normal((800000,10))
y = fwd(X)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
err = (y!=p2)
F23 = np.array(entries['best']['nodes'][23]['value']); F12 = np.array(entries['best']['nodes'][26]['value'])
CFB = 2123.
def reward(zone, ccheap=85.):
    cost = (ccheap + CFB*zone.mean())/2937
    e = (err & ~zone).mean()
    return 1 - cost - 10*e - 10*1.96*np.sqrt(e*(1-e)/16384), cost, e, zone.mean()
base = (g23<0.025)|(g23<F23[p2]*m1)|(g12<0.015)|(g12<F12[p1]*m1)|(m2<0)
print("base", reward(base))
# no f12 position factor (uniform), saving 11 ops
for u in [0.016,0.018,0.02,0.022]:
    z = (g23<0.025)|(g23<F23[p2]*m1)|(g12<0.015)|(g12<u*m1)|(m2<0)
    print("uniform12", u, reward(z, 74.))
# drop absolute thresholds
z = (g23<F23[p2]*m1)|(g12<F12[p1]*m1)|(m2<0); print("no abs", reward(z, 81.))
z = (g23<F23[p2]*m1)|(g12<0.015)|(g12<F12[p1]*m1)|(m2<0); print("no abs23", reward(z, 83.))
z = (g23<0.025)|(g23<F23[p2]*m1)|(g12<F12[p1]*m1)|(m2<0); print("no abs12", reward(z, 83.))
best=None
for a23,s23,a12,s12 in itertools.product([0.02,0.025,0.03,0.035],[0.9,1.0,1.1,1.2],[0.01,0.015,0.02],[0.9,1.0,1.15,1.3]):
    z = (g23<a23)|(g23<s23*F23[p2]*m1)|(g12<a12)|(g12<s12*F12[p1]*m1)|(m2<0)
    r = reward(z)
    if best is None or r[0]>best[0]: best=(r[0],a23,s23,a12,s12,r)
print(best)
