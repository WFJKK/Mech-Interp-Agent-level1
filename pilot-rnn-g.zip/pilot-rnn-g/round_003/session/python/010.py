
import numpy as np, json, traceback
print("MAX_RANK", lv1.MAX_RANK, "MAX_NODES", lv1.MAX_NODES, "MAX_CONST", lv1.MAX_CONST_SCALARS)
PERM = [0,1,2,3,6,7,8,10,11,12,13,14,15,5,9,4]
F23 = entries['best']['nodes'][23]['value']; F12 = entries['best']['nodes'][26]['value']
print(F23, F12)

def build(th23a=0.025, f23=F23, th12a=0.015, f12=F12, perm=PERM, mode="hybrid"):
    g = graph(example=[0.3,-1.2,0.8,0.1,-0.4,1.5,0.2,-0.9,0.6,-0.1])
    # ---- cheap path
    x = g.tokens()
    S = lv1.sort(x)
    m1, m2, m3 = S[9], S[8], S[7]
    p2 = (x == m2).argmax()
    p1 = x.argmax()
    g23 = m2 - lv1.maximum(m3, 0.0)
    g12 = m1 - m2
    c23 = g.const(np.array(f23, dtype=float)); c12 = g.const(np.array(f12, dtype=float))
    zone = (g23 < th23a) | (g23 < c23[p2] * m1) | (g12 < th12a) | (g12 < c12[p1] * m1) | (m2 < 0.0)
    # ---- build-time matrices
    P = g.const(np.array(perm, dtype=int))
    wv = g.weight("input")[:, 0]
    wP = lv1.take(wv, P, 0)
    RP = lv1.take(lv1.take(g.weight("recurrent"), P, 0), P, 1)
    RoP = lv1.take(g.weight("readout"), P, 1)
    Raug = lv1.concat([wP.reshape(16, 1), RP], axis=1)   # cols: x, u[0..12], u5, u9, u4
    def cols(Mat, pre, sub):
        parts = [Mat[:, :pre]] + [Mat[:, j:j+1] for j in sub]
        return parts[0] if len(parts) == 1 else lv1.concat(parts, axis=1)
    SUBS = [(), (14,), (15,), (14,15), (16,), (14,16), (15,16), (14,15,16)]
    RM = {sub: cols(Raug, 14, sub) for sub in SUBS}
    OSUBS = [tuple(j-1 for j in sub) for sub in SUBS]
    OM = {sub: cols(RoP, 13, sub) for sub in OSUBS}
    # ---- steps 0-2 table
    cp = RP @ lv1.maximum(wP, 0.0); cm = RP @ lv1.maximum(-wP, 0.0)
    def table(c):
        b = -c / wP
        B = lv1.sort(b)
        mids = (B[:-1] + B[1:]) * 0.5
        reps = lv1.concat([B[0:1] - 1.0, mids, B[15:16] + 1.0], axis=0)
        M = lv1.cast((reps.reshape(17, 1) * wP.reshape(1, 16) + c.reshape(1, 16)) > 0.0, "float")
        Tw = (M * wP.reshape(1, 16)) @ RP.T
        Tv = (M * c.reshape(1, 16)) @ RP.T
        return B, lv1.concat([Tw, Tv], axis=1)   # 17 x 32
    Bp, Tp = table(cp); Bm, Tm = table(cm)
    Ball = lv1.stack([Bp, Bm], axis=0)   # 2x16
    Tall = lv1.concat([Tp, Tm], axis=0)  # 34x32
    x0, x1, x2 = g.token(0), g.token(1), g.token(2)
    s = lv1.cast(x0 < 0.0, "int")
    ax0 = abs(x0); rho = x1 / ax0
    Bs = Ball[s]
    k = lv1.cast((rho > Bs).sum(), "int")
    idx = s * 17 + k
    Tsel = Tall[idx].reshape(2, 16).T   # 16x2 : [Tw_k, Tv_k]
    M3 = lv1.concat([wP.reshape(16, 1), Tsel], axis=1)
    v = lv1.stack([x2, x1, ax0], axis=0)
    h = lv1.maximum(M3 @ v, 0.0)
    # ---- steps 3..9
    def vec(a, pre, sub):
        # contiguous shortcut
        if sub == tuple(range(pre, pre+len(sub))):
            return a[:pre+len(sub)] if pre+len(sub) < a.shape[0] else a
        parts = [a[:pre]] + [a[j:j+1] for j in sub]
        return lv1.concat(parts, axis=0)
    def tree(e5, e9, e4, br):
        return lv1.cond(e4, lv1.cond(e9, lv1.cond(e5, br(()), br((14,))), lv1.cond(e5, br((15,)), br((14,15)))),
                            lv1.cond(e9, lv1.cond(e5, br((16,)), br((14,16))), lv1.cond(e5, br((15,16)), br((14,15,16)))))
    for t in range(3, 10):
        xt = g.token(t)
        a = lv1.concat([xt[None], h], axis=0)
        e5 = h[13] == 0.0; e9 = h[14] == 0.0; e4 = h[15] == 0.0
        z = tree(e5, e9, e4, lambda sub: RM[sub] @ vec(a, 14, sub))
        h = lv1.maximum(z, 0.0)
    e5 = h[13] == 0.0; e9 = h[14] == 0.0; e4 = h[15] == 0.0
    logits = tree(e5, e9, e4, lambda sub: OM[tuple(j-1 for j in sub)] @ vec(h, 13, tuple(j-1 for j in sub)))
    fb = logits.argmax()
    if mode == "fallback_all":
        return g.entry(interpretation=fb)
    if mode == "fallback_zone":
        return g.entry(interpretation=fb, region=zone)
    if mode == "cheap_outside":
        return g.entry(interpretation=p2, region=~zone)
    pred = lv1.cond(zone, fb, p2)
    return g.entry(interpretation=pred)

try:
    e = build(mode="fallback_all")
    print("nodes", len(e['nodes']))
    print(measure(e))
    e2 = build(mode="fallback_zone"); print(measure(e2))
    e3 = build(mode="cheap_outside"); print(measure(e3))
    e4 = build(); print("nodes", len(e4['nodes'])); m = measure(e4); print(m)
    save_entry("fold_v1", e4)
except Exception as ex:
    traceback.print_exc()
