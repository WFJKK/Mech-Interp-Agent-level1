
import numpy as np, time
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X, return_h=False):
    N = X.shape[0]
    h = np.zeros((N,16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    out = (h@Ro.T).argmax(1)
    return (out, np.stack(H,1)) if return_h else out
rng = np.random.default_rng(0)
X = rng.standard_normal((300000,10))
y, H = fwd(X, True)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1); p3=(X==m3[:,None]).argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
zone = (g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
print("zone frac", zone.mean(), "err outside", (y[~zone]!=p2[~zone]).mean(), "err inside p2", (y[zone]!=p2[zone]).mean())
# per-unit per-step zero frequency in zone
Z = (H[zone]==0)
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print("zero freq per step (rows) x unit (cols), zone inputs")
print(Z.mean(0))
print("mean # zero units per step", Z.sum(2).mean(0))
# rank of network output in zone
rank = (X > X[np.arange(len(X)), y][:,None]).sum(1)
print("rank of chosen in zone:", np.bincount(rank[zone], minlength=10)/zone.sum())
print("rank of chosen overall:", np.bincount(rank, minlength=10)/len(X))
