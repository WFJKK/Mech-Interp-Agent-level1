
import numpy as np, time
e = entries['fold_v3']
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
F23 = np.array(entries['best']['nodes'][23]['value'])
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
for seed in [1, 2, 3]:
    rng = np.random.default_rng(seed)
    Xs = lv1.draw_inputs(info['data_set'], info['input_space'], 16384, rng)
    t0 = time.time()
    ans, mops = lv1.run_reference(ref_entry, weights, 10, Xs)
    ans = np.asarray(ans)
    m = lv1.measure(e, weights, 10, Xs, ans, mops)
    if seed == 1: print(m.keys())
    y = fwd(Xs)
    S = np.sort(Xs,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
    p2 = (Xs==m2[:,None]).argmax(1); g23 = m2-np.maximum(m3,0); g12 = m1-m2
    z0 = (g23<np.maximum(1.1*F23[p2]*m1,0.03))|(g12<0.022*m1)|(m2<0)
    ev = lv1.Evaluator(e, weights, 10)
    pred = np.array([ev.run(xi)[1] for xi in Xs])
    print(seed, "verifier-like fidelity", m.get('fidelity'), "| numpy-ref agreement", (y==ans).mean(), "| my sim errors", ((y!=p2)&~z0).sum(), "| entry vs ref errors", (pred!=ans).sum(), "entry errors in zone", ((pred!=ans)&z0).sum(), "entry vs numpy-pred", (pred!=np.where(z0,y,p2)).sum(), round(time.time()-t0,1))
