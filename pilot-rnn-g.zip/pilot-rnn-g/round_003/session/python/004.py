
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X, return_h=False):
    N = X.shape[0]; h = np.zeros((N,16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    out = (h@Ro.T).argmax(1)
    return (out, np.stack(H,1)) if return_h else out
rng = np.random.default_rng(0)
X = rng.standard_normal((300000,10))
y, H = fwd(X, True)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1); p3=(X==m3[:,None]).argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
zone = (g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
np.set_printoptions(precision=2, suppress=True, linewidth=200)
print("w", w)
print("R max per row", R.max(1))
print("R min per row", R.min(1))
Xz = X[zone]; Hz = H[zone]
cert = np.zeros((10,16)); zero = np.zeros((10,16)); cert2 = np.zeros((10,16))
for t in range(1,10):
    hp = Hz[:,t-1]; l1 = hp.sum(1); hm = hp.max(1)
    bound = w[None,:]*Xz[:,t:t+1] + R.max(1)[None,:]*l1[:,None]
    cert[t] = (bound<0).mean(0); zero[t] = (Hz[:,t]==0).mean(0)
    bound2 = w[None,:]*Xz[:,t:t+1] + np.maximum(R,0).sum(1)[None,:]*hm[:,None]
    cert2[t] = (bound2<0).mean(0)
print("cert frac\n", cert[1:]); print("zero frac\n", zero[1:]); print("cert2 frac\n", cert2[1:])
