
import numpy as np, inspect, time
print(inspect.signature(lv1.Evaluator.run)); print((lv1.Evaluator.run.__doc__ or '')[:300])
e = entries['fold_v3']
rng = np.random.default_rng(5)
# perturbed weights: random re-draw with similar scale (a 'different network')
W2 = {k: v + 0.3*rng.standard_normal(v.shape)*np.abs(v).mean() for k,v in weights.items()}
Xs = rng.standard_normal((3000,10))
def fwd(X, W):
    w = W['input'][:,0]; R = W['recurrent']; Ro = W['readout']
    h = np.zeros((len(X),16))
    for t in range(10): h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
for name, W in [("orig", weights), ("perturbed", W2)]:
    ev = lv1.Evaluator(e, W, 10)
    t0=time.time(); outs=[]; costs=[]
    for xi in Xs:
        r = ev.run(xi); outs.append(r)
    print(name, "time", time.time()-t0, "first result", outs[0])
    outs_arr = np.array([o[0] if isinstance(o, tuple) else o for o in outs])
    y = fwd(Xs, W)
    print(name, "agreement", (outs_arr==y).mean())
