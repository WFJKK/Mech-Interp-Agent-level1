
import numpy as np, itertools
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
rng = np.random.default_rng(11)
X = rng.standard_normal((1000000,10))
y = fwd(X)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
err = (y!=p2)
F23 = np.array(entries['best']['nodes'][23]['value']); F12 = np.array(entries['best']['nodes'][26]['value'])
CFB = 2100.
def reward(zone, ccheap=85.):
    cost = (ccheap + CFB*zone.mean())/2937
    e = (err & ~zone).mean()
    return round(1 - cost - 10*e - 10*1.96*np.sqrt(e*(1-e)/16384),5), round(cost,4), round(e,5), round(zone.mean(),4)
base = (g23<0.025)|(g23<F23[p2]*m1)|(g12<0.015)|(g12<F12[p1]*m1)|(m2<0)
print("base", reward(base))
res=[]
for a23,s23,a12,u12 in itertools.product([0.02,0.025,0.03],[1.0,1.1,1.2],[0.0,0.01,0.015],[0.018,0.02,0.022]):
    z = (g23<a23)|(g23<s23*F23[p2]*m1)|(g12<a12)|(g12<u12*m1)|(m2<0)
    cc = 74. - (2 if a12==0 else 0)
    res.append((reward(z,cc),a23,s23,a12,u12))
res.sort(key=lambda r:-r[0][0]); print(res[:6])
r0 = res[0]; a23,s23,a12,u12 = r0[1:]
z0 = (g23<a23)|(g23<s23*F23[p2]*m1)|(g12<a12)|(g12<u12*m1)|(m2<0)
for t1 in [0.04,0.05,0.06,0.07]:
    z = z0 | ((m3<0)&(g23<t1*m1)); print("m3neg", t1, reward(z, 77.))
for t1,t2 in [(0.05,0.04),(0.06,0.05),(0.07,0.06),(0.08,0.05)]:
    z = z0 | ((g23<t1*m1)&(g12<t2*m1)); print("both", t1,t2, reward(z, 78.))
# error structure outside z0
o = ~z0 & err
rank = (X > X[np.arange(len(X)), y][:,None]).sum(1)
print("outside errors rank dist", np.bincount(rank[o], minlength=10)/o.sum())
rel = g23/m1
print("outside err by g23/m1 bins", [(lo, round((err&~z0&(rel>=lo)&(rel<hi)).sum()/max(1,(~z0&(rel>=lo)&(rel<hi)).sum()),4), round((~z0&(rel>=lo)&(rel<hi)).mean(),4)) for lo,hi in [(0,0.04),(0.04,0.05),(0.05,0.06),(0.06,0.08),(0.08,0.1),(0.1,0.15),(0.15,0.3),(0.3,9)]])
