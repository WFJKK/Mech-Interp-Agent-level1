
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X, return_h=False):
    N = X.shape[0]; h = np.zeros((N,16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    out = (h@Ro.T).argmax(1)
    return (out, np.stack(H,1)) if return_h else out
rng = np.random.default_rng(0)
X = rng.standard_normal((300000,10))
y, H = fwd(X, True)
S = np.sort(X,1); m1,m2,m3 = S[:,-1],S[:,-2],S[:,-3]
p2 = (X==m2[:,None]).argmax(1); p1 = X.argmax(1); p3=(X==m3[:,None]).argmax(1)
g23 = m2-np.maximum(m3,0); g12 = m1-m2
zone = (g23<0.025)|(g23<0.03*m1)|(g12<0.015)|(g12<0.02*m1)|(m2<0)
np.set_printoptions(precision=3, suppress=True, linewidth=200)
rank = (X > X[np.arange(len(X)), y][:,None]).sum(1)
zp = zone & (m3>0)
print("zone&m3>0 frac", zp.mean(), "rank dist", np.bincount(rank[zp], minlength=10)/zp.sum())
zn = zone & (m3<=0)
print("zone&m3<=0 frac", zn.mean(), "rank dist", np.bincount(rank[zn], minlength=10)/zn.sum())
print("R rows 4,9,5:\n", R[[4,9,5]])
print("Ro:\n", Ro)
print("svals R", np.linalg.svd(R, compute_uv=False))
# unit 4 firing: z4 = w4 x_t + R4.h ; look at -R4.h/w4 vs running max
Xz = X[zone]; Hz = H[zone]
for t in [3,6,9]:
    hp = Hz[:,t-1]; thr = -(hp@R[4])/w[4]
    rm = Xz[:,:t].max(1)
    print(t, "thr/runmax quantiles", np.quantile(thr/np.maximum(rm,1e-9),[0.01,0.1,0.5,0.9,0.99]), "corr", np.corrcoef(thr,rm)[0,1])
    hp9 = -(hp@R[9])/w[9]  # w9 negative -> fires when x_t < thr9
    print(t, "unit9 fires frac", (Hz[:,t,9]>0).mean(), "thr9 quantiles", np.quantile(hp9,[0.01,0.1,0.5,0.9,0.99]))
