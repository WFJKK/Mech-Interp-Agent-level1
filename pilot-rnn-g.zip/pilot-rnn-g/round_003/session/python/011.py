
import numpy as np, json, traceback
PERM = [0,1,2,3,6,7,8,10,11,12,13,14,15,5,9,4]
F23 = entries['best']['nodes'][23]['value']; F12 = entries['best']['nodes'][26]['value']

def build(th23a=0.025, f23=F23, th12a=0.015, f12=F12, perm=PERM, mode="hybrid", example=None):
    g = graph(example=example or [0.3,-1.2,0.8,0.1,-0.4,1.5,0.2,-0.9,0.6,-0.1])
    x = g.tokens()
    S = lv1.sort(x)
    m1, m2, m3 = S[9], S[8], S[7]
    p2 = (x == m2).argmax()
    p1 = x.argmax()
    g23 = m2 - lv1.maximum(m3, 0.0)
    g12 = m1 - m2
    c23 = g.const(np.array(f23, dtype=float)); c12 = g.const(np.array(f12, dtype=float))
    zone = (g23 < th23a) | (g23 < c23[p2] * m1) | (g12 < th12a) | (g12 < c12[p1] * m1) | (m2 < 0.0)
    P = g.const(np.array(perm, dtype=int))
    wv = g.weight("input")[:, 0]
    wP = lv1.take(wv, P, 0)
    RP = lv1.take(lv1.take(g.weight("recurrent"), P, 0), P, 1)
    RoP = lv1.take(g.weight("readout"), P, 1)
    Raug = lv1.concat([wP.reshape(16, 1), RP], axis=1)
    def cols(Mat, pre, sub):
        parts = [Mat[:, :pre]] + [Mat[:, j:j+1] for j in sub]
        return parts[0] if len(parts) == 1 else lv1.concat(parts, axis=1)
    # recurrent branches: subsets of aug cols {14:u5, 15:u9, 16:u4}; rare ones use full
    RM = {(): Raug[:, :14], (14,): Raug[:, :15], (14,15): Raug[:, :16], (14,15,16): Raug,
          (15,): cols(Raug, 14, (15,)), (16,): cols(Raug, 14, (16,))}
    RM[(14,16)] = Raug; RM[(15,16)] = Raug
    # readout branches on u9 (col 14), u4 (col 15); u5 col 13 always included
    OM = {(): RoP[:, :14], (14,): RoP[:, :15], (15,): cols(RoP, 14, (15,)), (14,15): RoP}
    cp = RP @ lv1.maximum(wP, 0.0); cm = RP @ lv1.maximum(-wP, 0.0)
    def table(c):
        b = -c / wP
        B = lv1.sort(b)
        mids = (B[:-1] + B[1:]) * 0.5
        reps = lv1.concat([B[0:1] - 1.0, mids, B[15:16] + 1.0], axis=0)
        M = lv1.cast((reps.reshape(17, 1) * wP.reshape(1, 16) + c.reshape(1, 16)) > 0.0, "float")
        Tw = (M * wP.reshape(1, 16)) @ RP.T
        Tv = (M * c.reshape(1, 16)) @ RP.T
        return B, lv1.concat([Tw, Tv], axis=1)
    Bp, Tp = table(cp); Bm, Tm = table(cm)
    Ball = lv1.stack([Bp, Bm], axis=0)
    Tall = lv1.concat([Tp, Tm], axis=0)
    x0, x1, x2 = g.token(0), g.token(1), g.token(2)
    s = lv1.cast(x0 < 0.0, "int")
    ax0 = abs(x0); rho = x1 / ax0
    k = lv1.cast((rho > Ball[s]).sum(), "int")
    idx = s * 17 + k
    Tsel = Tall[idx].reshape(2, 16).T
    M3 = lv1.concat([wP.reshape(16, 1), Tsel], axis=1)
    v = lv1.stack([x2, x1, ax0], axis=0)
    h = lv1.maximum(M3 @ v, 0.0)
    for t in range(3, 10):
        xt = g.token(t)
        a = lv1.concat([xt[None], h], axis=0)
        e5 = h[13] == 0.0; e9 = h[14] == 0.0; e4 = h[15] == 0.0
        a14, a15, a16 = a[:14], a[:15], a[:16]
        v15 = lv1.concat([a14, a[15:16]], axis=0)
        v16 = lv1.concat([a14, a[16:17]], axis=0)
        z = lv1.cond(e4, lv1.cond(e9, lv1.cond(e5, RM[()] @ a14, RM[(14,)] @ a15),
                                      lv1.cond(e5, RM[(15,)] @ v15, RM[(14,15)] @ a16)),
                         lv1.cond(e9, lv1.cond(e5, RM[(16,)] @ v16, Raug @ a),
                                      Raug @ a))
        h = lv1.maximum(z, 0.0)
    e9 = h[14] == 0.0; e4 = h[15] == 0.0
    logits = lv1.cond(e4, lv1.cond(e9, OM[()] @ h[:14], OM[(14,)] @ h[:15]),
                          lv1.cond(e9, OM[(15,)] @ lv1.concat([h[:14], h[15:16]], axis=0), RoP @ h))
    fb = logits.argmax()
    if mode == "fallback_all":
        return g.entry(interpretation=fb)
    if mode == "fallback_zone":
        return g.entry(interpretation=fb, region=zone)
    if mode == "cheap_outside":
        return g.entry(interpretation=p2, region=~zone)
    return g.entry(interpretation=lv1.cond(zone, fb, p2))

try:
    for mode in ["fallback_all", "cheap_outside", "hybrid"]:
        e = build(mode=mode); m = measure(e)
        print(mode, "nodes", len(e['nodes']), {k: m[k] for k in ['n_in_region','fidelity','cost','r','r_rule','b','predict_ops','rule_ops','reward']})
        if mode == "hybrid": save_entry("fold_v1", e)
except Exception as ex:
    traceback.print_exc()
