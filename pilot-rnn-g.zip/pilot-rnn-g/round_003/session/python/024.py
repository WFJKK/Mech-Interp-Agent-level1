
import numpy as np
w = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    N = X.shape[0]; h = np.zeros((N,16))
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0)
    return (h@Ro.T).argmax(1)
F23 = np.array(entries['best']['nodes'][23]['value']); F12 = np.array(entries['best']['nodes'][26]['value'])
rng = np.random.default_rng(99)
X0 = lv1.draw_inputs(info['data_set'], info['input_space'], 1000000, rng)
def stats(X, label):
    y = fwd(X)
    order = np.argsort(X, axis=1, kind='stable')
    p1, p2, p3 = order[:,9], order[:,8], order[:,7]
    ar = np.arange(len(X))
    m1, m2, m3 = X[ar,p1], X[ar,p2], X[ar,p3]
    g23 = m2-np.maximum(m3,0); g12 = m1-m2
    znew = (g23<np.maximum(1.1*F23[p2]*m1,0.03))|(g12<0.022*m1)|(m2<0)
    p2b = (X==m2[:,None]).argmax(1)
    zbase = (g23<0.025)|(g23<F23[p2b]*m1)|(g12<0.015)|(g12<F12[p1]*m1)|(m2<0)
    print(label, "new: zone", round(znew.mean(),4), "err", round(((y!=p2)&~znew).mean(),5), "| base: zone", round(zbase.mean(),4), "err", round(((y!=p2b)&~zbase).mean(),5), "| ties m1==m2", (m1==m2).mean(), "m2==m3", (m2==m3).mean())
stats(X0, "float64")
stats(X0.astype(np.float32).astype(np.float64), "float32")
for d in [3,2,1]:
    stats(np.round(X0, d), f"round{d}")
# uniform-ish alternatives
stats(rng.uniform(-1.7,1.7,(1000000,10)), "uniform")
stats(rng.standard_t(5,(1000000,10)), "t5")
