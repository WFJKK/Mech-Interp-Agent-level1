
import numpy as np, json
print(info.keys())
print({k:(v if not hasattr(v,'shape') else v.shape) for k,v in info.items() if k!='check'})
print(list(entries.keys()))
for k,v in weights.items(): print(k, v.shape)
best = entries['best']
print(type(best))
s = json.dumps(best)
print(len(s))
print(s[:1500])
