
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
for fn in ['concat','stack','cond','where','take','sort','maximum']:
    f = getattr(lv1, fn)
    try: print(fn, inspect.signature(f)); print((f.__doc__ or '')[:300])
    except Exception as e: print(fn, e)
g = graph()
print([n for n in dir(g) if not n.startswith('_')])
x = g.tokens()
print(type(x), [n for n in dir(x) if not n.startswith('_')])
print(inspect.signature(g.entry))
