
import inspect
for n in ['apply','Evaluator','run_reference','real_inputs','draw_inputs','measure','all_inputs']:
    f = getattr(lv1, n)
    try: print(n, inspect.signature(f)); print((f.__doc__ or '')[:400])
    except Exception as e: print(n, e)
print(inspect.signature(lv1.Graph.load)); print((lv1.Graph.load.__doc__ or '')[:400])
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
