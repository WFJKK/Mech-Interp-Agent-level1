
import json
best = entries['best']
nodes = best['nodes']
print(len(nodes), [k for k in best.keys()])
for i,n in enumerate(nodes[:60]):
    s = json.dumps(n)
    print(i, s[:200])
print(best.get('predict'), best.get('rule'))
m = measure(best); print(m)
