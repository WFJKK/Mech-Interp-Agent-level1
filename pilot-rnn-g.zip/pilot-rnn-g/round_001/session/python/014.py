
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]; ok = second==Y
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-v3
F = np.stack([v1,v2,v3,v4,g12,g23,v3-v4,(X>0).sum(1),X.sum(1),first,second,third,X[:,9],X[:,0],np.abs(first-second),np.abs(second-third)],1)
names=['v1','v2','v3','v4','g12','g23','g34','npos','sum','pos1','pos2','pos3','x9','x0','d12','d23']
try:
    from sklearn.tree import DecisionTreeClassifier, export_text
    clf = DecisionTreeClassifier(max_depth=4, min_samples_leaf=100).fit(F, ok)
    print(export_text(clf, feature_names=names))
except Exception as ex:
    print('no sklearn', ex)
