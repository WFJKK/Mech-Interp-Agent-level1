
def build(a=0.05, b=0.02, c=0.0):
    g = graph()
    x = g.tokens()
    m1 = x.max(); 
    x2 = lv1.where(x == m1, -1e9, x)
    m2 = x2.max(); p2 = x2.argmax()
    x3 = lv1.where(x2 == m2, -1e9, x2)
    m3 = x3.max()
    region = ((m2 - lv1.maximum(m3, 0.0)) > a) & ((m1 - m2) > b) & (m2 > c)
    return g.entry(interpretation=p2, region=region)
e = build()
print(measure(e))
save_entry("second_argmax_margin", e)
e2 = build(0.05,0.02,0.1); print(measure(e2))
