
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
ranks = (-X).argsort(1).argsort(1)  # 0 = largest
ry = ranks[np.arange(len(Y)), Y]
print(np.bincount(ry, minlength=10)/len(Y))
# does rank of Y relate to something, e.g. number of positives, or the max value?
npos = (X>0).sum(1)
for k in range(11):
    m = npos==k
    if m.sum(): print(k, m.sum(), np.bincount(ry[m], minlength=10))
