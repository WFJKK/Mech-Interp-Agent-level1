
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
# how does Y depend on each token? mean of token per class
for t in range(10):
    print(t, [round(X[Y==c,t].mean(),2) for c in range(10)])
# mutual info-ish: variance of class means
# Try: output = something like (sum of tokens * k) mod 10? check rounding of linear combos
S = X.sum(1)
for c in range(10):
    print(c, round(S[Y==c].mean(),2), round(S[Y==c].std(),2))
