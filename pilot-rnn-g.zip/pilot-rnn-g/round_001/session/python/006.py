
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
def first_gt(th):
    m = X>th
    has = m.any(1)
    idx = np.where(has, m.argmax(1), 9)
    return idx
def last_gt(th):
    m = (X>th)[:, ::-1]
    has = m.any(1)
    idx = np.where(has, 9-m.argmax(1), 0)
    return idx
for th in [-0.5,0,0.3,0.5,0.8,1.0]:
    print(th, (first_gt(th)==Y).mean(), (last_gt(th)==Y).mean())
# Also: does Y equal argmax restricted to something? check P(Y=c | x_c is argmax)
am = X.argmax(1)
print('P(Y=argmax)', (Y==am).mean())
# x_Y value distribution
xy = X[np.arange(len(Y)), Y]
print(np.percentile(xy,[1,5,25,50,75,95,99]))
