
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; ok = second==Y
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-v3
rel23 = 1-np.maximum(v3,0)/np.maximum(v2,1e-9)
rel12 = 1-v2/np.maximum(v1,1e-9)
def rew(r, cost=0.025):
    cov=r.mean(); n=r.sum(); fid=ok[r].mean(); fl=fid-1.96*np.sqrt(fid*(1-fid)/n)
    return cov*((1-cost)-10*(1-fl)), cov, fid
best=[]
for a in [0.05,0.1,0.12,0.15,0.18,0.2,0.25,0.3]:
  for bk,b in [('g12',g12),('rel12',rel12)]:
    for bt in [0.02,0.03,0.05,0.08,0.1]:
      for c in [0,0.1,0.2,0.3]:
        r=(rel23>a)&(b>bt)&(v2>c)
        best.append((*rew(r),a,bk,bt,c))
best.sort(reverse=True)
for b in best[:15]: print(np.round(b[:3],4), b[3:])
# also absolute gap with v3 clipped
print('abs clipped')
best=[]
g23c = v2-np.maximum(v3,0)
for a in [0.05,0.08,0.1,0.15,0.2]:
    for bt in [0.02,0.03,0.05,0.08]:
      for c in [0,0.1,0.2,0.3]:
        r=(g23c>a)&(g12>bt)&(v2>c); best.append((*rew(r),a,bt,c))
best.sort(reverse=True)
for b in best[:8]: print(np.round(b[:3],4), b[3:])
