
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
w = weights['input'][:,0]; R = weights['recurrent']; O = weights['readout']
def fwd(X):
    h = np.zeros((len(X),16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return np.array(H)
H = fwd(X)
print('check', ((H[-1]@O.T).argmax(1)==Y).mean())
print('frac active per unit per t')
print(np.round((H>0).mean(1),2))
print('mean value per unit at final')
print(np.round(H[-1].mean(0),2))
print(np.round(H[-1].std(0),2))
