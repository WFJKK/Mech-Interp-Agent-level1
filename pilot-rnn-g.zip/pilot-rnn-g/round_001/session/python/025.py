
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; ok = second==Y
v1,v2,v3 = srt[:,0],srt[:,1],srt[:,2]
g12=v1-v2; g23=v2-np.maximum(v3,0)
rel23 = g23/np.maximum(v2,1e-9); rel12 = g12/np.maximum(v1,1e-9)
res=[]
for a in [0.0,0.02,0.03,0.04,0.05]:
  for a2 in [0.0,0.02,0.03,0.05,0.07,0.1]:
    for b in [0.005,0.01,0.02,0.03]:
      for b2 in [0, 0.01,0.02]:
        for c in [0.0,0.05,0.1]:
            zone=(g23<a)|(rel23<a2)|(g12<b)|(rel12<b2)|(v2<c)
            err_out = (~ok & ~zone).mean()
            score = zone.mean()*1.0 + 10*err_out
            res.append((score, zone.mean(), err_out, a,a2,b,b2,c))
res.sort()
for r in res[:10]: print(np.round(r[:3],4), r[3:])
