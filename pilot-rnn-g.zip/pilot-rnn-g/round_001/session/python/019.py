
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; ok = second==Y
v1,v2,v3 = srt[:,0],srt[:,1],srt[:,2]
g12=v1-v2; g23=v2-np.maximum(v3,0); g23raw=v2-v3
rel23 = g23/np.maximum(v2,1e-9)
res=[]
for a in [0.03,0.04,0.05,0.06,0.08,0.1,0.12,0.15]:
  for b in [0.01,0.02,0.03,0.04,0.05,0.08]:
    for c in [0.0,0.1,0.15,0.2,0.3]:
      for gk,gg in [('abs',g23),('raw',g23raw),('rel',rel23)]:
        zone=(gg<a)|(g12<b)|(v2<c)
        err_out = (~ok & ~zone).mean()
        score = zone.mean() + 10*err_out
        res.append((score, zone.mean(), err_out, a,b,c,gk))
res.sort()
for r in res[:15]: print(np.round(r[:3],4), r[3:])
