
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
w = weights['input'][:,0]; R = weights['recurrent']; O = weights['readout']
def fwd(X):
    h = np.zeros((len(X),16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return np.array(H)
H = fwd(X)  # (10, N, 16)
# features over time: running max, running second max, running sum, running count pos, current x
rmax = np.maximum.accumulate(X,1)
rsec = np.array([np.sort(X[:,:t+1],1)[:,-2] if t>=1 else np.full(len(X),-3.0) for t in range(10)]).T
rsum = np.cumsum(X,1); rpos = np.cumsum(X>0,1)
feats = {'x_t':X, 'rmax':rmax, 'rsec':rsec, 'rsum':rsum, 'rpos':rpos, 'x_prev':np.roll(X,1,1)}
np.set_printoptions(precision=2, suppress=True, linewidth=220)
for t in [3,6,9]:
    print('t',t)
    for k,f in feats.items():
        print(f'{k:7}', np.array([np.corrcoef(H[t][:,u], f[:,t])[0,1] for u in range(16)]))
