
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-v3
z = (g23<0.1)&(g12>0.05)&(v2>0.2)&((Y==second)|(Y==third))
print('zone n', z.sum(), 'picks third frac', (Y[z]==third[z]).mean())
Xz=X[z]; y=(Y[z]==third[z]).astype(float)
p2=second[z]; p3=third[z]; p1=first[z]
def onehot(p): 
    o=np.zeros((len(p),10)); o[np.arange(len(p)),p]=1; return o
# feature sets
F = np.column_stack([np.ones(z.sum()), g23[z], v2[z], v1[z], v4[z], onehot(p2), onehot(p3), onehot(p1), (p3>p2), np.abs(p3-p2), Xz.sum(1), (Xz>0).sum(1)])
def fit(F,y,iters=4000,lr=0.5,l2=1e-3):
    mu=F.mean(0); sd=F.std(0)+1e-9; sd[0]=1; mu[0]=0
    Fs=(F-mu)/sd; wv=np.zeros(F.shape[1])
    for i in range(iters):
        p=1/(1+np.exp(-Fs@wv)); g=Fs.T@(p-y)/len(y)+l2*wv; wv-=lr*g
    return (lambda G: 1/(1+np.exp(-((G-mu)/sd)@wv))), wv
n=len(y); tr=np.arange(n)%2==0; te=~tr
m,wv=fit(F[tr],y[tr]); p=m(F)
print('acc train', ((p>0.5)==y)[tr].mean(), 'test', ((p>0.5)==y)[te].mean(), 'base', 1-y.mean())
print(np.round(wv,2))
# error rate by pos2 and pos3
print('pick3 rate by pos2', [round(y[p2==k].mean(),2) for k in range(10)])
print('pick3 rate by pos3', [round(y[p3==k].mean(),2) for k in range(10)])
