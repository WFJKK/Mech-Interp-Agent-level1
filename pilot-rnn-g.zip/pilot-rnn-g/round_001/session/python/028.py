
def forward(g):
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()

def buildC(a=0.04, a2=0.04, b=0.02, c=0.0):
    g = graph()
    x = g.tokens()
    s = lv1.sort(x)
    m1, m2, m3 = s[9], s[8], s[7]
    p2 = (x == m2).argmax()
    g23 = m2 - lv1.maximum(m3, 0.0)
    g12 = m1 - m2
    zone = (g23 < a) | (g23 < a2 * m2) | (g12 < b) | (m2 < c)
    pred = lv1.cond(zone, forward(g), p2)
    return g.entry(interpretation=pred)
for params in [(0.04,0.04,0.02,0.0),(0.03,0.03,0.01,0.0),(0.05,0.05,0.02,0.0)]:
    e = buildC(*params); r = measure(e); print(params, {k:r[k] for k in ['fidelity','cost','reward']})
e = buildC(0.04,0.04,0.02,0.0)
save_entry("hybrid_sort_v2", e)
# verify p2 matches second argmax on sample
X, Y, ops = network_outputs(); X=np.asarray(X)
gg, interp, reg = lv1.Graph.load(e, weights, 10)
print(type(interp), interp.value if hasattr(interp,'value') else None)
