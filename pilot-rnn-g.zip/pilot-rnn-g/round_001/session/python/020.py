
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
w = weights['input'][:,0]; R = weights['recurrent']; O = weights['readout']
def fwd(X):
    h = np.zeros((len(X),16)); H=[]
    for t in range(10):
        h = np.maximum(w[None,:]*X[:,t:t+1] + h@R.T, 0); H.append(h.copy())
    return np.array(H)
H = fwd(X)
hf = H[-1]
np.set_printoptions(precision=2, suppress=True, linewidth=220)
print('mean final h per class')
for c in range(10): print(c, hf[Y==c].mean(0))
# singular values of R
print('svals R', np.linalg.svd(R, compute_uv=False))
print('eig R', np.round(np.linalg.eigvals(R),2))
