
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; ok = second==Y
v1,v2,v3 = srt[:,0],srt[:,1],srt[:,2]
g12=v1-v2; g23=v2-v3
ranks = (-X).argsort(1).argsort(1); ry = ranks[np.arange(len(Y)), Y]
m = ry>=3
print('ry>=3 count', m.sum(), 'v2<0 frac', (v2[m]<0).mean(), 'v2 pct', np.percentile(v2[m],[10,50,90]), 'g23', np.percentile(g23[m],[10,50,90]))
print('ry>=3 and v2>0 and g23>0.1:', (m & (v2>0) & (g23>0.1)).sum())
# those cases
mm = m & (v2>0) & (g23>0.1)
for i in np.where(mm)[0][:10]:
    print(np.round(X[i],2), Y[i], second[i])
# grid
best=[]
for a in [0,0.05,0.1,0.15,0.2,0.3]:
  for b in [0,0.02,0.05,0.1,0.2]:
    for c in [-9,0,0.2,0.4]:
        r = (g23>a)&(g12>b)&(v2>c)
        cov=r.mean(); fid=ok[r].mean(); n=r.sum()
        fl = fid-1.96*np.sqrt(fid*(1-fid)/n)
        rew = cov*((1-0.025)-10*(1-fl))
        best.append((rew,a,b,c,cov,fid))
best.sort(reverse=True)
for b in best[:12]: print(b)
