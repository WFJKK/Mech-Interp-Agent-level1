
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]; ok = second==Y
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-v3
ranks = (-X).argsort(1).argsort(1); ry = ranks[np.arange(len(Y)), Y]
m = (v3<0)&(g12>0.05)
print('v3<0: by v2 bins')
for lo,hi in [(0,0.2),(0.2,0.4),(0.4,0.6),(0.6,0.8),(0.8,1.0),(1.0,1.3),(1.3,9)]:
    mm = m&(v2>=lo)&(v2<hi)
    print(lo,hi,mm.sum(), f'{(1-ok[mm].mean())*100:.1f}%', np.bincount(ry[mm&~ok],minlength=4)[:4])
print('v3<0: by v3 bins, v2>0.6')
for lo,hi in [(-9,-1),(-1,-0.5),(-0.5,-0.3),(-0.3,-0.15),(-0.15,0)]:
    mm = m&(v2>0.6)&(v3>=lo)&(v3<hi)
    print(lo,hi,mm.sum(), f'{(1-ok[mm].mean())*100:.1f}%')
# relative resolution: err by g23/v2 for v3>0
m = (v3>0)&(g12>0.05)
print('v3>0: err by g23/v2')
rel = g23/v2
for lo,hi in [(0,0.03),(0.03,0.06),(0.06,0.1),(0.1,0.15),(0.15,0.2),(0.2,0.3),(0.3,0.5),(0.5,1)]:
    mm = m&(rel>=lo)&(rel<hi); print(lo,hi,mm.sum(), f'{(1-ok[mm].mean())*100:.1f}%')
