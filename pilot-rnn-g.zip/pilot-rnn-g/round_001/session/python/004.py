
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
print(X.shape, Y.shape, ops)
print(np.bincount(Y, minlength=10))
cands = {
 'argmax': X.argmax(1), 'argmin': X.argmin(1), 'argmaxabs': np.abs(X).argmax(1),
 'npos': (X>0).sum(1), 'nneg': (X<0).sum(1),
 'ngt_x0': (X>X[:,:1]).sum(1), 'rank_x0': (X<X[:,:1]).sum(1),
 'rank_last': (X<X[:,-1:]).sum(1), 'ngt_last': (X>X[:,-1:]).sum(1),
 'sumsign': ((X.sum(1)>0)).astype(int),
}
for k,v in cands.items(): print(k, (v==Y).mean())
