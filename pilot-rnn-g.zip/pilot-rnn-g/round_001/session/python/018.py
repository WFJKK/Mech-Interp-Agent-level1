
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
w = weights['input'][:,0]; R = weights['recurrent']; O = weights['readout']
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; ok = second==Y
v1,v2,v3 = srt[:,0],srt[:,1],srt[:,2]
g12=v1-v2; g23=v2-np.maximum(v3,0)
zone = (g23<0.06)|(g12<0.03)|(v2<0.15)
print('zone frac', zone.mean(), 'err in zone', (~ok[zone]).mean(), 'err outside', (~ok[~zone]).mean(), 'overall rule err', (~ok).mean())
def fwd(X, keep):
    k = np.array(keep)
    wk=w[k]; Rk=R[np.ix_(k,k)]; Ok=O[:,k]
    h = np.zeros((len(X),len(k)))
    for t in range(10):
        h = np.maximum(wk[None,:]*X[:,t:t+1] + h@Rk.T, 0)
    return (h@Ok.T).argmax(1)
Xz = X[zone]; Yz=Y[zone]
print('full', (fwd(Xz, list(range(16)))==Yz).mean())
for u in range(16):
    keep=[i for i in range(16) if i!=u]
    print('drop',u, round((fwd(Xz, keep)==Yz).mean(),4), 'all', round((fwd(X,keep)==Y).mean(),4))
