
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]; ok = second==Y
v1,v2,v3 = srt[:,0],srt[:,1],srt[:,2]
g12=v1-v2; g23=v2-np.maximum(v3,0)
zone=(g23<0.03)|(g23<0.03*v2)|(g12<0.01)|(v2<0)
o = ~zone
print('outside zone n', o.sum(), 'err', (~ok[o]).mean())
print('err by pos1', [f'{(~ok[o&(first==k)]).mean()*100:.1f}' for k in range(10)])
print('err by pos2', [f'{(~ok[o&(second==k)]).mean()*100:.1f}' for k in range(10)])
print('err by pos3', [f'{(~ok[o&(third==k)]).mean()*100:.1f}' for k in range(10)])
print('err by npos', [f'{(~ok[o&((X>0).sum(1)==k)]).mean()*100:.1f}' for k in range(11)])
# err by g23 bins outside zone (finer), and by v2
for lo,hi in [(0.03,0.05),(0.05,0.07),(0.07,0.1),(0.1,0.15),(0.15,0.2),(0.2,0.3),(0.3,9)]:
    m=o&(g23>=lo)&(g23<hi); print(lo,hi,m.sum(), f'{(~ok[m]).mean()*100:.1f}%', 'share of all errs', round((~ok&m).sum()/(~ok&o).sum(),2))
