
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]; ok = second==Y
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-v3
def table(a, b, abins, bbins, mask=None):
    if mask is None: mask=np.ones(len(a),bool)
    print('      '+' '.join(f'{x:>12}' for x in bbins[1:]))
    for i in range(len(abins)-1):
        row=[]
        for j in range(len(bbins)-1):
            m=mask&(a>=abins[i])&(a<abins[i+1])&(b>=bbins[j])&(b<bbins[j+1])
            row.append(f'{(1-ok[m].mean())*100:5.1f}%/{m.sum():5d}' if m.sum()>0 else ' '*12)
        print(f'{abins[i+1]:5}',' '.join(row))
print('err% by g23 (rows) x g12 (cols)')
table(g23, g12, [0,0.03,0.06,0.1,0.15,0.2,0.3,0.5,9], [0,0.02,0.05,0.1,0.2,0.5,9], mask=v2>0)
print('err% by g23 (rows) x v2 (cols), g12>0.05')
table(g23, v2, [0,0.03,0.06,0.1,0.15,0.2,0.3,0.5,9], [-9,0,0.3,0.6,1,1.5,9], mask=g12>0.05)
print('err% by g23 (rows) x v3 (cols), g12>0.05')
table(g23, v3, [0,0.03,0.06,0.1,0.15,0.2,0.3,0.5,9], [-9,0,0.3,0.6,1,1.5,9], mask=g12>0.05)
