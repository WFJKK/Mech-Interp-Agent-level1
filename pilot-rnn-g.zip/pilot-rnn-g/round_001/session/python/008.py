
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1)
second = order[:,1]
srt = -np.sort(-X,1)
ok = second==Y
print('acc', ok.mean())
v2 = srt[:,1]; v1=srt[:,0]; v3=srt[:,2]
# accuracy by v2 bins
for lo,hi in [(-9,0),(0,0.3),(0.3,0.6),(0.6,1),(1,1.5),(1.5,9)]:
    m=(v2>=lo)&(v2<hi); print('v2',lo,hi,m.sum(), ok[m].mean())
# accuracy by gap v2-v3
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,9)]:
    m=(v2-v3>=lo)&(v2-v3<hi); print('gap23',lo,hi,m.sum(), ok[m].mean())
for lo,hi in [(0,0.05),(0.05,0.1),(0.1,0.2),(0.2,0.4),(0.4,9)]:
    m=(v1-v2>=lo)&(v1-v2<hi); print('gap12',lo,hi,m.sum(), ok[m].mean())
# wrong ones: which rank did the net pick?
ranks = (-X).argsort(1).argsort(1); ry = ranks[np.arange(len(Y)), Y]
print(np.bincount(ry[~ok], minlength=10))
