
def forward(g):
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()

def buildB(a=0.03, a2=0.03, b=0.01, b2=0.01, c=0.0):
    g = graph()
    x = g.tokens()
    m1 = x.max()
    x2 = lv1.where(x == m1, -1e9, x)
    m2 = x2.max(); p2 = x2.argmax()
    x3 = lv1.where(x2 == m2, -1e9, x2)
    m3 = x3.max()
    g23 = m2 - lv1.maximum(m3, 0.0)
    g12 = m1 - m2
    zone = (g23 < a) | (g23 < a2 * m2) | (g12 < b) | (g12 < b2 * m1) | (m2 < c)
    pred = lv1.cond(zone, forward(g), p2)
    return g.entry(interpretation=pred)
eB = buildB()
r = measure(eB); print(r)
save_entry("hybrid_second_argmax_fallback", eB)
