
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]; ok = second==Y
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-v3
ranks = (-X).argsort(1).argsort(1); ry = ranks[np.arange(len(Y)), Y]
r = (g23>0.05)&(g12>0.02)&(v2>0)
e = r & ~ok
print(e.sum(), np.bincount(ry[e],minlength=10))
feats = {'v1':v1,'v2':v2,'v3':v3,'v4':v4,'g12':g12,'g23':g23,'g34':v3-v4,'npos':(X>0).sum(1),'sum':X.sum(1),'pos1':first,'pos2':second,'pos3':third, 'x9':X[:,9],'x0':X[:,0]}
for k,v in feats.items():
    print(k, 'err', np.round(np.percentile(v[e],[10,50,90]),2), 'ok', np.round(np.percentile(v[r&ok],[10,50,90]),2))
