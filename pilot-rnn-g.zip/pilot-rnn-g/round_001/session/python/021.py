
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]; ok = second==Y
v1,v2,v3,v4 = srt[:,0],srt[:,1],srt[:,2],srt[:,3]
g12=v1-v2; g23=v2-np.maximum(v3,0)
def onehot(p): 
    o=np.zeros((len(p),10)); o[np.arange(len(p)),p]=1; return o
F = np.column_stack([np.ones(len(X)), v1,v2,v3,v4, np.log(g12+1e-3), np.log(g23+1e-3), np.log(np.maximum(v2,0)+1e-3), onehot(first), onehot(second), onehot(third), (X>0).sum(1), X.sum(1), np.abs(first-second), np.abs(second-third)])
yerr = (~ok).astype(float)
n=len(X); tr=np.arange(n)<n//2; te=~tr
def fit(F,y,iters=3000,lr=0.05,l2=1e-3):
    mu=F.mean(0); sd=F.std(0)+1e-9; sd[0]=1; mu[0]=0
    Fs=(F-mu)/sd; wv=np.zeros(F.shape[1])
    for i in range(iters):
        p=1/(1+np.exp(-Fs@wv)); g=Fs.T@(p-y)/len(y)+l2*wv; wv-=lr*g*10
    return lambda G: 1/(1+np.exp(-((G-mu)/sd)@wv))
model_ = fit(F[tr], yerr[tr])
p = model_(F)
def rew(r, okm, cost=0.03):
    cov=r.mean(); nn=r.sum(); fid=okm[r].mean(); fl=fid-1.96*np.sqrt(fid*(1-fid)/nn)
    return cov*((1-cost)-10*(1-fl)), cov, fid
for th in [0.03,0.05,0.07,0.09,0.1,0.12,0.15]:
    r = p<th
    print(th, 'train', np.round(rew(r[tr], ok[tr]),4), 'test', np.round(rew(r[te], ok[te]),4))
# baseline on test
rb = (g23>0.05)&(g12>0.02)&(v2>0)
print('baseline test', np.round(rew(rb[te], ok[te]),4))
