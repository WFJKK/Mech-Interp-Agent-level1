
X, Y, ops = network_outputs()
X = np.asarray(X); Y = np.asarray(Y)
order = (-X).argsort(1); srt = -np.sort(-X,1)
second = order[:,1]; first=order[:,0]; third=order[:,2]
ok = second==Y
print('by pos of second', [round(ok[second==p].mean(),3) for p in range(10)])
print('by pos of first', [round(ok[first==p].mean(),3) for p in range(10)])
print('by pos of third', [round(ok[third==p].mean(),3) for p in range(10)])
print('second before first', ok[second<first].mean(), 'after', ok[second>first].mean())
print('third before second', ok[third<second].mean(), 'after', ok[third>second].mean())
# wrong answers: which position did it pick relative?
wrong = ~ok
ranks = (-X).argsort(1).argsort(1); ry = ranks[np.arange(len(Y)), Y]
# when it picks third: is third before or after second?
m = wrong & (ry==2)
print('picked third: third<second', (third[m]<second[m]).mean())
m = wrong & (ry==0)
print('picked first: first<second', (first[m]<second[m]).mean())
# gap distribution when picking third
m = wrong & (ry==2)
print(np.percentile(srt[m,1]-srt[m,2],[10,50,90]))
m = wrong & (ry==0)
print(np.percentile(srt[m,0]-srt[m,1],[10,50,90]))
