
import numpy as np, time, math, gc, resource
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
rng = np.random.default_rng(1)
n=330000; d=309
F = rng.standard_normal((n,d)).astype(np.float32); print("F", mem())
y = (rng.random(n)<0.05).astype(float)
w = np.zeros(d)
t0=time.time()
Fc = F[:100000].astype(np.float64); print("Fc", mem())
z = Fc@w; p = 1/(1+np.exp(-z)); s = p*(1-p)+1e-9
g = Fc.T@(y[:100000]-p); print("g", mem())
H = (Fc*s[:,None]).T@Fc; print("H", mem(), time.time()-t0)
w += np.linalg.solve(H+np.eye(d), g); print("solve", mem(), time.time()-t0)
