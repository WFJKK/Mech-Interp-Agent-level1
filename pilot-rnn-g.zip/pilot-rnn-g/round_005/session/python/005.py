
X0, Y0, ops0 = no
X0 = np.asarray(X0, float); Y0 = np.asarray(Y0)
print(X0.shape, Y0.shape, ops0)
print("match", (fwd(X0)==Y0).mean())
import inspect
print(inspect.signature(lv1.draw_inputs))
print(inspect.getsource(lv1.draw_inputs)[:1500])
