
import inspect
print(inspect.signature(lv1.measure)); print(inspect.signature(lv1.apply)); 
print(inspect.getsource(lv1.apply)[:1500])
print(inspect.getsource(lv1.measure)[:2500])
