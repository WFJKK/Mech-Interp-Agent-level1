
e = entries['best']
for i, n in enumerate(e['nodes'][40:], 40):
    d = dict(n); 
    if d.get('op')=='const' and isinstance(d.get('value'), list) and len(d['value'])>6: d['value']=f"<{len(d['value'])} nums>"
    print(i, d)
