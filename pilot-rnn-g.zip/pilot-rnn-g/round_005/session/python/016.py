
import numpy as np, time, math, gc, resource
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
rng = np.random.default_rng(777)
N = 2_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1)
p1, p2, p3, p4 = order[:,9].copy(), order[:,8].copy(), order[:,7].copy(), order[:,6].copy()
del order
ar = np.arange(N)
m1, m2, m3, m4 = X[ar,p1], X[ar,p2], X[ar,p3], X[ar,p4]
g23 = (m2 - np.maximum(m3,0))/m1; g12 = (m1-m2)/m1
err = (Y != p2)
sure = (m2<0)|(g23<0.015)|(g12<0.008)
pre = (g23<0.1)|(g12<0.08)
el = pre & ~sure
l23 = np.log(g23+1e-4); l12 = np.log(g12+1e-4)
xs = X.sum(1); xneg = np.minimum(X,0).sum(1); npos=(X>0).sum(1)
g34 = (m3 - np.maximum(m4,0))/m1
num = np.stack([l23,g23,l12,g12,m2/m1,xs/m1,(m3<0).astype(float),l23*l12, np.log(np.maximum(g34,0)+1e-4), m3/m1, npos/10.0, xneg/m1, l23*(m3<0)],1).astype(np.float32)
del X, xs, xneg, npos, g34, m4, ar; gc.collect()
def wl(k,n,z=1.96):
    p=k/n; c=p+z*z/(2*n); s=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)); return (c-s)/(1+z*z/n)
def reward(zone, err, pre, n=16384, verbose=True, tag=""):
    cost = (59 + 36*pre.mean() + 2084*zone.mean())/2937 + 0.00046
    e = (err & ~zone).mean()
    k = round((1-e)*n); fl = wl(k, n)
    r = (1-cost) - 10*(1-fl)
    if verbose: print(f"{tag} zone {zone.mean():.4f} err {e:.5f} cost {cost:.4f} reward {r:.4f}")
    return r
# feature builder: linear part = num(13) + one + per-position additive (30) + slopes (20); bilinear: pairs with V fixed
pairs = [(p2,p3),(p1,p2),(p1,p3)]
def feats(rows, Vs, nnum=13):
    n=len(rows); a=np.arange(n)
    d = nnum+1+30+20 + sum(10*V.shape[1] for V in Vs)
    F = np.zeros((n,d),np.float32); c=0
    F[:,:nnum]=num[rows,:nnum]; c=nnum; F[:,c]=1; c+=1
    for p in (p1,p2,p3): F[a,c+p[rows]]=1; c+=10
    F[a,c+p1[rows]]=l12[rows]; c+=10; F[a,c+p2[rows]]=l23[rows]; c+=10
    for (pa,pb),V in zip(pairs,Vs):
        r=V.shape[1]
        for j in range(r): F[a,c+pa[rows]*r+j]=V[pb[rows],j]
        c+=10*r
    return F
def irls(F, y, l2=1e-2, iters=6, ch=50000, w0=None):
    n,d = F.shape; w = np.zeros(d) if w0 is None else w0.copy()
    for it in range(iters):
        g = np.zeros(d); H = l2*np.eye(d)
        for i in range(0,n,ch):
            Fc = F[i:i+ch].astype(np.float64); z = Fc@w; p = 1/(1+np.exp(-z)); s = p*(1-p)+1e-9
            g += Fc.T@(y[i:i+ch]-p); H += (Fc*s[:,None]).T@Fc
        g -= l2*w
        w += np.linalg.solve(H, g)
    return w
ntr = 1_200_000
rows_tr = np.flatnonzero(el[:ntr]); rows_te = np.flatnonzero(el); rows_te = rows_te[rows_te>=ntr]
ytr = err[rows_tr].astype(float)
ps = np.array([0.045,0.05,0.055,0.06,0.065,0.07,0.08]); thrs = np.log(ps/(1-ps))
def evaluate(Vs, w, tag):
    lg = np.full(N, -99.0)
    for i in range(0, len(rows_te), 50000):
        rr = rows_te[i:i+50000]; lg[rr] = feats(rr, Vs).astype(np.float64)@w
    best=None
    for thr in thrs:
        zone = sure | (lg>thr); r = reward(zone[ntr:], err[ntr:], pre[ntr:], verbose=False)
        if best is None or r>best[0]: best=(r,thr)
    zone = sure | (lg>best[1])
    reward(zone[ntr:], err[ntr:], pre[ntr:], tag=tag+" p=%.3f"%(1/(1+np.exp(-best[1]))))
    return best
for r in [1,2,3]:
    t0=time.time()
    rs = np.random.default_rng(r)
    Vs = [rs.standard_normal((10,r))*0.3 for _ in pairs]
    w=None
    for alt in range(4):
        F = feats(rows_tr, Vs); w = irls(F, ytr, w0=None); del F; gc.collect()
        # extract U's and swap roles: new V = U, and swap pair order (so that U becomes the fixed side)
        c = 13+1+30+20; Us=[]
        for V in Vs:
            k=V.shape[1]; Us.append(w[c:c+10*k].reshape(10,k)); c+=10*k
        # swap: pairs (pa,pb): term U[pa]·V[pb]; now fix U and fit V: define pairs reversed
        pairs = [(b,a) for (a,b) in pairs]; Vs = Us
    print("rank",r,"params",len(w),"time %.1f"%(time.time()-t0), "mem %.2f"%mem())
    evaluate(Vs, w, "  rank%d"%r)
    pairs = [(p2,p3),(p1,p2),(p1,p3)] if pairs[0][0] is p3 else pairs
    pairs = [(p2,p3),(p1,p2),(p1,p3)]
