
import numpy as np, gc
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
pn = entries['params_lr332']['nodes']
A1=np.array(pn[0]['value']); A2=np.array(pn[1]['value']); A3=np.array(pn[2]['value']); beta=np.array(pn[3]['value']); b0=pn[4]['value']; thr=pn[5]['value']
def wl(k,n,z=1.96):
    p=k/n; c=p+z*z/(2*n); s=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)); return (c-s)/(1+z*z/n)
rng = np.random.default_rng(5); N=2_000_000
X = rng.standard_normal((N,10)); Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order=np.argsort(X,1); p1,p2,p3=order[:,9],order[:,8],order[:,7]; ar=np.arange(N)
m1,m2,m3=X[ar,p1],X[ar,p2],X[ar,p3]; g23=(m2-np.maximum(m3,0))/m1; g12=(m1-m2)/m1; err=(Y!=p2)
sure=(m2<0)|(g23<0.015)|(g12<0.008); pre=(g23<0.1)|(g12<0.08); mr=pre&~sure
l23=np.log(g23+1e-4); l12=np.log(g12+1e-4)
num=np.stack([l23,g23,l12,g12,m2/m1,X.sum(1)/m1,(m3<0).astype(float),l23*l12],1)
r1=A1[p1]; r2=A2[p2]; r3=A3[p3]
lin = num@beta + b0
pos = (r1*np.concatenate([np.ones((N,1)), l12[:,None], r2[:,5:], r3[:,4:]],1)).sum(1) + (r2[:,:5]*np.concatenate([np.ones((N,1)), l23[:,None], r3[:,1:4]],1)).sum(1) + r3[:,0]
lg = lin+pos
print("pos term stats on mr: mean %.3f sd %.3f min %.2f max %.2f"%(pos[mr].mean(), pos[mr].std(), pos[mr].min(), pos[mr].max()))
# optionally shift: include mean of pos into b0 for stage 1
mu = pos[mr].mean()
for band in [0.5,1.0,1.5,2.0,2.5,3.0,99]:
    near = mr & (np.abs(lin+mu-thr) < band)
    dec = np.where(near, lg>thr, lin+mu>thr)
    z = sure | (mr & dec)
    cost=(59+33*mr.mean()+31*near.mean()+2136*z.mean())/2937+0.00046; e=(err&~z).mean(); fl=wl(round((1-e)*16384),16384); r=(1-cost)-10*(1-fl)
    print(f"band {band}: stage2 frac of mr {near.sum()/mr.sum():.3f} zone {z.mean():.4f} err {e:.5f} cost {cost:.4f} reward {r:.4f}")
