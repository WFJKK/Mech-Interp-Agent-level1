
import numpy as np, time, math, gc, resource, json
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
rng = np.random.default_rng(2024)
N = 2_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1)
p1, p2, p3 = order[:,9].copy(), order[:,8].copy(), order[:,7].copy()
del order
ar = np.arange(N)
m1, m2, m3 = X[ar,p1], X[ar,p2], X[ar,p3]
g23 = (m2 - np.maximum(m3,0))/m1; g12 = (m1-m2)/m1
err = (Y != p2)
sure = (m2<0)|(g23<0.015)|(g12<0.008)
pre = (g23<0.1)|(g12<0.08)
el = pre & ~sure
l23 = np.log(g23+1e-4); l12 = np.log(g12+1e-4)
xs = X.sum(1)
num = np.stack([l23,g23,l12,g12,m2/m1,xs/m1,(m3<0).astype(float),l23*l12],1).astype(np.float32)
del X, xs, ar; gc.collect()
def wl(k,n,z=1.96):
    p=k/n; c=p+z*z/(2*n); s=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)); return (c-s)/(1+z*z/n)
def reward(zone, err, pre, n=16384, verbose=True, tag="", fb=2084, ro=160):
    cost = (59 + 36*pre.mean() + fb*zone.mean())/2937 + 0.00046
    e = (err & ~zone).mean()
    k = round((1-e)*n); fl = wl(k, n)
    r = (1-cost) - 10*(1-fl)
    if verbose: print(f"{tag} zone {zone.mean():.4f} err {e:.5f} cost {cost:.4f} reward {r:.4f}")
    return r
P = {'p1':p1,'p2':p2,'p3':p3}
def feats(rows, cfg):
    n=len(rows); a=np.arange(n)
    d = 8+1+30+20 + sum(10*V.shape[1] for _,_,V in cfg)
    F = np.zeros((n,d),np.float32); c=0
    F[:,:8]=num[rows]; c=8; F[:,c]=1; c+=1
    for p in (p1,p2,p3): F[a,c+p[rows]]=1; c+=10
    F[a,c+p1[rows]]=l12[rows]; c+=10; F[a,c+p2[rows]]=l23[rows]; c+=10
    for an,bn,V in cfg:
        pa,pb=P[an],P[bn]; r=V.shape[1]
        for j in range(r): F[a,c+pa[rows]*r+j]=V[pb[rows],j]
        c+=10*r
    return F
def irls(F, y, l2=1e-2, iters=6, ch=50000):
    n,d = F.shape; w = np.zeros(d)
    for it in range(iters):
        g = np.zeros(d); H = l2*np.eye(d)
        for i in range(0,n,ch):
            Fc = F[i:i+ch].astype(np.float64); z = Fc@w; p = 1/(1+np.exp(-z)); s = p*(1-p)+1e-9
            g += Fc.T@(y[i:i+ch]-p); H += (Fc*s[:,None]).T@Fc
        g -= l2*w
        w += np.linalg.solve(H, g)
    return w
def logits(rows, cfg, w):
    lg = np.full(N, -99.0)
    for i in range(0, len(rows), 50000):
        rr = rows[i:i+50000]; lg[rr] = feats(rr, cfg).astype(np.float64)@w
    return lg
ranks = {'23':3,'12':3,'13':2}
def fit(rows_tr, nalt=6):
    I10=np.eye(10)
    cfg_full = [('p2','p3',I10),('p1','p2',I10),('p1','p3',I10)]
    F = feats(rows_tr, cfg_full); wf = irls(F, err[rows_tr].astype(float)); del F; gc.collect()
    c0=59; cfg=[]
    for k,(an,bn,key) in enumerate([('p2','p3','23'),('p1','p2','12'),('p1','p3','13')]):
        Tk = wf[c0+100*k:c0+100*(k+1)].reshape(10,10); r=ranks[key]
        Tc = Tk - Tk.mean(0,keepdims=True) - Tk.mean(1,keepdims=True) + Tk.mean()
        u,s,vt = np.linalg.svd(Tc); cfg.append((an,bn,(vt[:r].T*np.sqrt(s[:r]))))
    for alt in range(nalt):
        F = feats(rows_tr, cfg); w = irls(F, err[rows_tr].astype(float)); del F; gc.collect()
        if alt==nalt-1: break
        c=59; newcfg=[]
        for an,bn,V in cfg:
            k=V.shape[1]; U=w[c:c+10*k].reshape(10,k); c+=10*k; newcfg.append((bn,an,U))
        cfg=newcfg
    return cfg, w
ntr=1_500_000
rows_tr = np.flatnonzero(el[:ntr]); rows_te = np.flatnonzero(el); rows_te = rows_te[rows_te>=ntr]
t0=time.time(); cfg, w = fit(rows_tr); print("fit time %.1f mem %.2f"%(time.time()-t0, mem()))
lg = logits(rows_te, cfg, w)
best=None
for pth in [0.05,0.055,0.06,0.065,0.07]:
    thr=np.log(pth/(1-pth)); zone = sure | (lg>thr)
    r = reward(zone[ntr:], err[ntr:], pre[ntr:], tag="  p=%.3f"%pth)
    if best is None or r>best[0]: best=(r,pth)
# baseline comparison on the same held-out
e = entries['best']; nd = e['nodes']
beta0 = np.array(nd[377]['value']); C23 = np.array(nd[379]['value']); C12 = np.array(nd[380]['value']); b00 = nd[381]['value']; thr0 = nd[392]['value']
lg0 = np.full(N,-99.0); lg0[rows_te] = num[rows_te].astype(np.float64)@beta0 + b00 + C23[p2[rows_te]*10+p3[rows_te]] + C12[p1[rows_te]*10+p2[rows_te]]
reward((sure|(lg0>thr0))[ntr:], err[ntr:], pre[ntr:], tag="  current best")
pth = best[1]; print("chosen p", pth)
# refit on all
rows_all = np.flatnonzero(el)
cfg, w = fit(rows_all); print("refit done %.1f"%(time.time()-t0))
# extract parameters
beta = w[:8]; b0 = w[8]; add = {'p1':w[9:19],'p2':w[19:29],'p3':w[29:39]}; sl12 = w[39:49]; sl23 = w[49:59]
c=59; side={}
for an,bn,V in cfg:
    k=V.shape[1]; U=w[c:c+10*k].reshape(10,k); c+=10*k
    key = ''.join(sorted([an[1],bn[1]]))  # '23','12','13'
    side[(key,an)] = U; side[(key,bn)] = V
A1 = np.concatenate([add['p1'][:,None], sl12[:,None], side[('12','p1')], side[('13','p1')]],1)
A2 = np.concatenate([add['p2'][:,None], sl23[:,None], side[('23','p2')], side[('12','p2')]],1)
A3 = np.concatenate([add['p3'][:,None], side[('23','p3')], side[('13','p3')]],1)
print(A1.shape, A2.shape, A3.shape)
thr = float(np.log(pth/(1-pth)))
def np_logit(num_, p1_, p2_, p3_, l12_, l23_):
    r1=A1[p1_]; r2=A2[p2_]; r3=A3[p3_]
    u1 = np.concatenate([np.ones((len(p1_),1)), l12_[:,None], r2[:,2+3:], r3[:,1+3:]],1)
    u2 = np.concatenate([np.ones((len(p1_),1)), l23_[:,None], r3[:,1:4]],1)
    return num_.astype(np.float64)@beta + b0 + (r1*u1).sum(1) + (r2[:,:5]*u2).sum(1) + r3[:,0]
# consistency check of the layout vs the fitted logits
chk = rows_all[:200000]
lgA = feats(chk, cfg).astype(np.float64)@w; lgB = np_logit(num[chk], p1[chk], p2[chk], p3[chk], l12[chk], l23[chk])
print("layout check max diff", np.abs(lgA-lgB).max())
params = dict(beta=beta.tolist(), b0=float(b0), A1=A1.tolist(), A2=A2.tolist(), A3=A3.tolist(), thr=thr)
save_entry("params_tmp", {"format": e['format'], "nodes": [{'op':'const','value':[0.0],'dtype':'float'}], "predict": 0, "rule": None, "_params": params})
print("saved params; mem %.2f"%mem())
