
import numpy as np, time, math, gc
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
rng = np.random.default_rng(777)
N = 4_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1)
p1, p2, p3, p4 = order[:,9], order[:,8], order[:,7], order[:,6]
del order
ar = np.arange(N)
m1, m2, m3, m4 = X[ar,p1], X[ar,p2], X[ar,p3], X[ar,p4]
g23 = (m2 - np.maximum(m3,0))/m1; g12 = (m1-m2)/m1
err = (Y != p2)
sure = (m2<0)|(g23<0.015)|(g12<0.008)
pre = (g23<0.1)|(g12<0.08)
el = pre & ~sure
print("el frac", el.mean(), el.sum())
def wl(k,n,z=1.96):
    p=k/n; c=p+z*z/(2*n); s=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)); return (c-s)/(1+z*z/n)
def reward(zone, err, pre, n=16384, verbose=True, tag=""):
    cost = (59 + 36*pre.mean() + 2084*zone.mean())/2937 + 0.00046
    e = (err & ~zone).mean()
    k = round((1-e)*n); fl = wl(k, n)
    r = (1-cost) - 10*(1-fl)
    if verbose: print(f"{tag} zone {zone.mean():.4f} err {e:.5f} cost {cost:.4f} reward {r:.4f}")
    return r
def onehot(idx, k):
    M = np.zeros((len(idx), k), np.float32); M[np.arange(len(idx)), idx] = 1; return M
l23 = np.log(g23+1e-4); l12 = np.log(g12+1e-4)
xs = X.sum(1); xneg = np.minimum(X,0).sum(1); npos=(X>0).sum(1)
base = np.stack([l23,g23,l12,g12,m2/m1,xs/m1,(m3<0).astype(float),l23*l12],1)
g34 = (m3 - np.maximum(m4,0))/m1
def feats(kind):
    cols = [base[el].astype(np.float32), np.ones((el.sum(),1),np.float32), onehot(p2[el]*10+p3[el],100), onehot(p1[el]*10+p2[el],100)]
    if 'slope' in kind:
        cols.append(onehot(p1[el],10)*l12[el][:,None].astype(np.float32)); cols.append(onehot(p2[el],10)*l23[el][:,None].astype(np.float32))
    if 'c13' in kind:
        cols.append(onehot(p1[el]*10+p3[el],100))
    if 'extra' in kind:
        cols.append(np.stack([np.log(np.maximum(g34,0)+1e-4), m3/m1, npos/10.0, xneg/m1, l23*(m3<0)],1)[el].astype(np.float32))
    return np.concatenate(cols,1)
def irls(F, y, l2=1e-2, iters=10, ch=200000):
    n,d = F.shape; w = np.zeros(d)
    for it in range(iters):
        g = np.zeros(d); H = l2*np.eye(d)
        for i in range(0,n,ch):
            Fc = F[i:i+ch].astype(np.float64); z = Fc@w; p = 1/(1+np.exp(-z)); s = p*(1-p)+1e-9
            g += Fc.T@(y[i:i+ch]-p); H += (Fc*s[:,None]).T@Fc
        g -= l2*w
        w += np.linalg.solve(H, g)
    return w
ntr = 2_500_000
yel = err[el].astype(float); idx_tr = (np.arange(N)[el] < ntr)
ps = np.array([0.045,0.05,0.055,0.06,0.065,0.07,0.08]); thrs = np.log(ps/(1-ps))
results = {}
for kind in ['base','slope','c13','extra','slope+c13','slope+c13+extra']:
    t0=time.time()
    F = feats(kind)
    w = irls(F[idx_tr], yel[idx_tr])
    lg = np.full(N, -99.0); lg[el] = (F.astype(np.float64)@w) if F.shape[0]<1 else np.concatenate([F[i:i+200000].astype(np.float64)@w for i in range(0,F.shape[0],200000)])
    best=None
    for thr in thrs:
        zone = sure | (lg>thr)
        r = reward(zone[ntr:], err[ntr:], pre[ntr:], verbose=False)
        if best is None or r>best[0]: best=(r,thr)
    zone = sure | (lg>best[1])
    print(kind, F.shape[1], "thr p=%.3f"%(1/(1+np.exp(-best[1]))), "time %.1f"%(time.time()-t0))
    reward(zone[ntr:], err[ntr:], pre[ntr:], tag="  test"); reward(zone[:ntr], err[:ntr], pre[:ntr], tag="  train")
    results[kind]=w
    del F; gc.collect()
