
import numpy as np, time, gc
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
pn = entries['params_lr332']['nodes']
A1=np.array(pn[0]['value']); A2=np.array(pn[1]['value']); A3=np.array(pn[2]['value']); beta=np.array(pn[3]['value']); b0=pn[4]['value']; thr=pn[5]['value']
rng = np.random.default_rng(99)
N = 2_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1); p1,p2,p3 = order[:,9].copy(),order[:,8].copy(),order[:,7].copy(); del order
ar=np.arange(N); m1,m2,m3 = X[ar,p1],X[ar,p2],X[ar,p3]
g23=(m2-np.maximum(m3,0))/m1; g12=(m1-m2)/m1; err=(Y!=p2)
sure=(m2<0)|(g23<0.015)|(g12<0.008)
l23=np.log(g23+1e-4); l12=np.log(g12+1e-4)
num=np.stack([l23,g23,l12,g12,m2/m1,X.sum(1)/m1,(m3<0).astype(float),l23*l12],1)
del X; gc.collect()
r1=A1[p1]; r2=A2[p2]; r3=A3[p3]
lg = num@beta + b0 + (r1*np.concatenate([np.ones((N,1)), l12[:,None], r2[:,5:], r3[:,4:]],1)).sum(1) + (r2[:,:5]*np.concatenate([np.ones((N,1)), l23[:,None], r3[:,1:4]],1)).sum(1) + r3[:,0]
def wl(k,n,z=1.96):
    p=k/n; c=p+z*z/(2*n); s=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)); return (c-s)/(1+z*z/n)
def reward(zone, modelrun, tag="", n=16384):
    cost = (59 + 64*modelrun.mean() + 2136*zone.mean())/2937 + 0.00046
    e = (err & ~zone).mean(); k=round((1-e)*n); fl=wl(k,n); r=(1-cost)-10*(1-fl)
    print(f"{tag} zone {zone.mean():.4f} model {modelrun.mean():.4f} err {e:.5f} cost {cost:.4f} reward {r:.4f}"); return r
for (a,b) in [(0.1,0.08),(0.09,0.07),(0.08,0.06),(0.07,0.05),(0.06,0.045)]:
    pre=(g23<a)|(g12<b); mr = pre & ~sure
    for pth in [0.055,0.06,0.065,0.07]:
        t=np.log(pth/(1-pth)); zone = sure | (mr & (lg>t))
        reward(zone, mr, tag=f"pre({a},{b}) p={pth}")
# how many zone inputs lie outside tighter pre-screens
t=np.log(0.06/0.94); zone0 = sure | (((g23<0.1)|(g12<0.08)) & (lg>t))
for (a,b) in [(0.09,0.07),(0.08,0.06),(0.07,0.05)]:
    pre=(g23<a)|(g12<b); print((a,b), "zone inputs lost", (zone0 & ~pre).mean(), "their err rate", err[zone0&~pre].mean() if (zone0&~pre).any() else None)
