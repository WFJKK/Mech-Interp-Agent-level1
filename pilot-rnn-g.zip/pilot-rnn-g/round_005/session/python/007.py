
import numpy as np, time, math
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
t0=time.time()
rng = np.random.default_rng(12345)
N = 3_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+500000]) for i in range(0,N,500000)])
print("fwd time", time.time()-t0)
order = np.argsort(X, axis=1)
p1, p2, p3 = order[:,9], order[:,8], order[:,7]
ar = np.arange(N)
m1, m2, m3 = X[ar,p1], X[ar,p2], X[ar,p3]
g23 = (m2 - np.maximum(m3,0))/m1; g12 = (m1-m2)/m1
err = (Y != p2)
print("base err", err.mean())
e = entries['best']; nd = e['nodes']
beta = np.array(nd[377]['value']); C23 = np.array(nd[379]['value']); C12 = np.array(nd[380]['value']); b0 = nd[381]['value']; thr = nd[392]['value']
print(beta, b0, thr, 1/(1+np.exp(-thr)))
def model_logit(g23,g12,m2,m1,m3,X,p1,p2,p3):
    l23 = np.log(g23+1e-4); l12 = np.log(g12+1e-4)
    F = np.stack([l23,g23,l12,g12,m2/m1,X.sum(1)/m1,(m3<0).astype(float),l23*l12],1)
    return F@beta + b0 + C23[p2*10+p3] + C12[p1*10+p2]
sure = (m2<0)|(g23<0.015)|(g12<0.008)
pre = (g23<0.1)|(g12<0.08)
lg = model_logit(g23,g12,m2,m1,m3,X,p1,p2,p3)
zone = sure | (pre & (lg>thr))
def reward(zone, err, pre, n=16384, verbose=True):
    cost = (59 + 36*pre.mean() + 2084*zone.mean())/2937 + 0.00046
    e = (err & ~zone).mean()
    k = round((1-e)*n); fl = lv1.wilson_lower(k, n)
    r = (1-cost) - 10*(1-fl)
    if verbose: print(f"zone {zone.mean():.4f} pre {pre.mean():.4f} err {e:.5f} cost {cost:.4f} fid_low {fl:.5f} reward {r:.4f}")
    return r
reward(zone, err, pre)
# check on fixed sample
no = network_outputs(); X0=np.asarray(no[0],float); Y0=np.asarray(no[1])
o0=np.argsort(X0,1); q1,q2,q3=o0[:,9],o0[:,8],o0[:,7]; a0=np.arange(len(X0))
n1,n2,n3=X0[a0,q1],X0[a0,q2],X0[a0,q3]; h23=(n2-np.maximum(n3,0))/n1; h12=(n1-n2)/n1
s0=(n2<0)|(h23<0.015)|(h12<0.008); pr0=(h23<0.1)|(h12<0.08)
z0 = s0 | (pr0 & (model_logit(h23,h12,n2,n1,n3,X0,q1,q2,q3)>thr))
print("fixed sample: zone", z0.mean(), "errors", ((Y0!=q2)&~z0).sum(), "pred ops", (59 + 36*pr0.mean() + 2084*z0.mean())*16384)
