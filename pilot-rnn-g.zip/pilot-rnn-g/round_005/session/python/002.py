
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
e = entries['best']
print(e['format'], len(e['nodes']), e['predict'], e['rule'])
from collections import Counter
print(Counter(n.get('op') for n in e['nodes']))
for n in e['nodes'][:40]: print(n)
