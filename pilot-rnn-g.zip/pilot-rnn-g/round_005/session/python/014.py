
import numpy as np, time, math, gc, resource
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
rng = np.random.default_rng(777)
N = 2_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1)
p1, p2, p3, p4 = order[:,9].copy(), order[:,8].copy(), order[:,7].copy(), order[:,6].copy()
del order
ar = np.arange(N)
m1, m2, m3, m4 = X[ar,p1], X[ar,p2], X[ar,p3], X[ar,p4]
g23 = (m2 - np.maximum(m3,0))/m1; g12 = (m1-m2)/m1
err = (Y != p2)
sure = (m2<0)|(g23<0.015)|(g12<0.008)
pre = (g23<0.1)|(g12<0.08)
el = pre & ~sure
print("el frac", el.mean(), el.sum(), "mem", mem())
l23 = np.log(g23+1e-4); l12 = np.log(g12+1e-4)
print("mem", mem())
xs = X.sum(1); xneg = np.minimum(X,0).sum(1); npos=(X>0).sum(1)
g34 = (m3 - np.maximum(m4,0))/m1
print("mem", mem())
base8 = np.stack([l23,g23,l12,g12,m2/m1,xs/m1,(m3<0).astype(float),l23*l12],1).astype(np.float32)
extra5 = np.stack([np.log(np.maximum(g34,0)+1e-4), m3/m1, npos/10.0, xneg/m1, l23*(m3<0)],1).astype(np.float32)
print("mem", mem())
def onehot(idx, k):
    M = np.zeros((len(idx), k), np.float32); M[np.arange(len(idx)), idx] = 1; return M
ntr = 1_200_000
rows_tr = np.flatnonzero(el[:ntr]); print(len(rows_tr), mem())
F = np.concatenate([base8[rows_tr], np.ones((len(rows_tr),1),np.float32), onehot(p2[rows_tr]*10+p3[rows_tr],100), onehot(p1[rows_tr]*10+p2[rows_tr],100)],1)
print(F.shape, F.dtype, mem())
