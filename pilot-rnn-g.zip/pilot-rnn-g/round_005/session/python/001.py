
import json
print(list(entries.keys()))
print({k: v for k, v in info.items() if k != 'data'} if isinstance(info, dict) else info)
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
m = measure(e)
print(m)
