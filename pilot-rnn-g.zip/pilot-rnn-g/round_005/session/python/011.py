
import numpy as np, time, resource
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
print("start", mem())
rng = np.random.default_rng(777)
N = 2_000_000
X = rng.standard_normal((N,10)); print("X", mem())
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)]); print("Y", mem())
order = np.argsort(X, axis=1); print("order", mem())
