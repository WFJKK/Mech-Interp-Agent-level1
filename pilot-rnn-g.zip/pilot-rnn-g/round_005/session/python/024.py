
import numpy as np
entry = entries['lowrank_v1']
no = network_outputs(); X0=np.asarray(no[0],float); Y0=np.asarray(no[1])
ev = lv1.Evaluator(entry, weights, 10)
from collections import Counter
cnt = Counter()
for i in range(3000):
    inside, ans, cr, cp = ev.run(X0[i]); cnt[cp]+=1
print(sorted(cnt.items())[:10], sorted(cnt.items())[-5:])
small = [(c,n) for c,n in cnt.items() if c<200]; big=[(c,n) for c,n in cnt.items() if c>=200]
print("cheap costs", sorted(small)); 
tot = sum(c*n for c,n in big); nn = sum(n for c,n in big); print("fallback avg", tot/nn, "n", nn)
