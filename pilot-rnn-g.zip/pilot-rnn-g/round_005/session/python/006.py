
import numpy as np, time, inspect
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
no = network_outputs()
X0, Y0, ops0 = no
X0 = np.asarray(X0, float); Y0 = np.asarray(Y0)
print(X0.shape, Y0.shape, ops0 if not hasattr(ops0,'__len__') or len(ops0)<5 else type(ops0))
print("match", (fwd(X0)==Y0).mean())
print(inspect.signature(lv1.draw_inputs))
print(inspect.getsource(lv1.draw_inputs)[:1200])
print(inspect.getsource(lv1.wilson_lower)[:800])
