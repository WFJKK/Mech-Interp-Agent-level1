
import numpy as np, json
g = graph()
A = g.const(np.arange(8.0).reshape(2,4))
i = g.token(0) > 0.0
idx = lv1.cast(i, "int")
row = A[idx]
one = g.const(1.0)
s = lv1.stack([one, g.token(1)])
u = lv1.concat([s, row[2:]])
try:
    d = row @ u
    print("matmul 1d ok", d.shape, d.value)
except Exception as ex:
    print("matmul 1d fails", ex); d = (row*u).sum()
ent = g.entry(interpretation=lv1.cast(d, "int") % 10, region=None)
for n in ent['nodes']: print(n)
ev = lv1.Evaluator(ent, weights, 10)
print(ev.run(np.array([1.0,2.0,0,0,0,0,0,0,0,0])))
print(ev.build_cost)
