
import numpy as np
no = network_outputs(); X0=np.asarray(no[0],float); Y0=np.asarray(no[1])
from collections import Counter
for name in ['best','lowrank_v1']:
    ev = lv1.Evaluator(entries[name], weights, 10)
    cnt = Counter(); costs=[]
    for i in range(3000):
        inside, ans, cr, cp = ev.run(X0[i]); costs.append(cp)
    costs=np.array(costs)
    small = costs[costs<300]; big = costs[costs>=300]
    print(name, "cheap:", Counter(small.tolist()), "fallback n", len(big), "mean %.1f min %d max %d"%(big.mean(), big.min(), big.max()), "overall mean %.1f"%costs.mean())
    # split fallback by whether model ran: can't tell directly; show histogram
    print("  fallback quantiles", np.percentile(big,[5,25,50,75,95]))
