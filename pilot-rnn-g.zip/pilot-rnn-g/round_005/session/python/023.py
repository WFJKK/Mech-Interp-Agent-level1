
import numpy as np, time, math, gc, resource, json
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
rng = np.random.default_rng(2024)
N = 2_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1)
p1, p2, p3 = order[:,9].copy(), order[:,8].copy(), order[:,7].copy()
del order
ar = np.arange(N)
m1, m2, m3 = X[ar,p1], X[ar,p2], X[ar,p3]
g23 = (m2 - np.maximum(m3,0))/m1; g12 = (m1-m2)/m1
err = (Y != p2)
sure = (m2<0)|(g23<0.015)|(g12<0.008)
pre = (g23<0.1)|(g12<0.08)
el = pre & ~sure
l23 = np.log(g23+1e-4); l12 = np.log(g12+1e-4)
xs = X.sum(1)
num = np.stack([l23,g23,l12,g12,m2/m1,xs/m1,(m3<0).astype(float),l23*l12],1).astype(np.float32)
del X, xs, ar; gc.collect()
P = {'p1':p1,'p2':p2,'p3':p3}
def feats(rows, cfg):
    n=len(rows); a=np.arange(n)
    d = 8+1+30+20 + sum(10*V.shape[1] for _,_,V in cfg)
    F = np.zeros((n,d),np.float32); c=0
    F[:,:8]=num[rows]; c=8; F[:,c]=1; c+=1
    for p in (p1,p2,p3): F[a,c+p[rows]]=1; c+=10
    F[a,c+p1[rows]]=l12[rows]; c+=10; F[a,c+p2[rows]]=l23[rows]; c+=10
    for an,bn,V in cfg:
        pa,pb=P[an],P[bn]; r=V.shape[1]
        for j in range(r): F[a,c+pa[rows]*r+j]=V[pb[rows],j]
        c+=10*r
    return F
def irls(F, y, l2=1e-2, iters=6, ch=50000):
    n,d = F.shape; w = np.zeros(d)
    for it in range(iters):
        g = np.zeros(d); H = l2*np.eye(d)
        for i in range(0,n,ch):
            Fc = F[i:i+ch].astype(np.float64); z = Fc@w; p = 1/(1+np.exp(-z)); s = p*(1-p)+1e-9
            g += Fc.T@(y[i:i+ch]-p); H += (Fc*s[:,None]).T@Fc
        g -= l2*w
        w += np.linalg.solve(H, g)
    return w
ranks = {'23':3,'12':3,'13':2}
def fit(rows_tr, nalt=6):
    I10=np.eye(10)
    cfg_full = [('p2','p3',I10),('p1','p2',I10),('p1','p3',I10)]
    F = feats(rows_tr, cfg_full); wf = irls(F, err[rows_tr].astype(float)); del F; gc.collect()
    c0=59; cfg=[]
    for k,(an,bn,key) in enumerate([('p2','p3','23'),('p1','p2','12'),('p1','p3','13')]):
        Tk = wf[c0+100*k:c0+100*(k+1)].reshape(10,10); r=ranks[key]
        Tc = Tk - Tk.mean(0,keepdims=True) - Tk.mean(1,keepdims=True) + Tk.mean()
        u,s,vt = np.linalg.svd(Tc); cfg.append((an,bn,(vt[:r].T*np.sqrt(s[:r]))))
    for alt in range(nalt):
        F = feats(rows_tr, cfg); w = irls(F, err[rows_tr].astype(float)); del F; gc.collect()
        if alt==nalt-1: break
        c=59; newcfg=[]
        for an,bn,V in cfg:
            k=V.shape[1]; U=w[c:c+10*k].reshape(10,k); c+=10*k; newcfg.append((bn,an,U))
        cfg=newcfg
    return cfg, w
t0=time.time()
rows_all = np.flatnonzero(el)
cfg, w = fit(rows_all); print("fit done %.1f"%(time.time()-t0))
pth=0.06; thr = float(np.log(pth/(1-pth)))
beta = w[:8]; b0 = float(w[8]); add_ = {'p1':w[9:19],'p2':w[19:29],'p3':w[29:39]}; sl12 = w[39:49]; sl23 = w[49:59]
c=59; side={}
for an,bn,V in cfg:
    k=V.shape[1]; U=w[c:c+10*k].reshape(10,k); c+=10*k
    key = ''.join(sorted([an[1],bn[1]])); side[(key,an)] = U; side[(key,bn)] = V
A1 = np.concatenate([add_['p1'][:,None], sl12[:,None], side[('12','p1')], side[('13','p1')]],1)
A2 = np.concatenate([add_['p2'][:,None], sl23[:,None], side[('23','p2')], side[('12','p2')]],1)
A3 = np.concatenate([add_['p3'][:,None], side[('23','p3')], side[('13','p3')]],1)
def np_logit(num_, p1_, p2_, p3_, l12_, l23_):
    r1=A1[p1_]; r2=A2[p2_]; r3=A3[p3_]
    u1 = np.concatenate([np.ones((len(p1_),1)), l12_[:,None], r2[:,5:], r3[:,4:]],1)
    u2 = np.concatenate([np.ones((len(p1_),1)), l23_[:,None], r3[:,1:4]],1)
    return num_.astype(np.float64)@beta + b0 + (r1*u1).sum(1) + (r2[:,:5]*u2).sum(1) + r3[:,0]
chk = rows_all[:100000]
print("layout check", np.abs(feats(chk, cfg).astype(np.float64)@w - np_logit(num[chk], p1[chk], p2[chk], p3[chk], l12[chk], l23[chk])).max())
# params entry (for persistence)
fmt = entries['best']['format']
pnodes = [{'op':'const','value':A1.tolist(),'dtype':'float'},{'op':'const','value':A2.tolist(),'dtype':'float'},{'op':'const','value':A3.tolist(),'dtype':'float'},
          {'op':'const','value':beta.tolist(),'dtype':'float'},{'op':'const','value':b0,'dtype':'float'},{'op':'const','value':thr,'dtype':'float'},{'op':'const','value':0,'dtype':'int'}]
save_entry("params_lr332", {"format":fmt,"nodes":pnodes,"predict":6,"rule":None})
# ---- build the entry ----
best = entries['best']
nodes = [dict(n) for n in best['nodes'][:336]]
def add(op, args=None, **kw):
    node={'op':op}
    if args is not None: node['args']=list(args)
    node.update(kw); nodes.append(node); return len(nodes)-1
def const(v, dtype): return add('const', value=v, dtype=dtype)
def sl(x, start=None, stop=None): return add('slice',[x], index=[{'start':start,'stop':stop,'step':None}])
def idx(x, i): return add('slice',[x], index=[i])
ZERO, ONE = 8, 49
H9 = 335
s15 = idx(H9, 15); e15 = add('eq',[s15, ZERO]); v15 = sl(H9, None, 15)
ma = add('matmul',[32, v15]); mb = add('matmul',[21, H9]); ro = add('cond',[e15, ma, mb]); am = add('argmax',[ro], axis=None)
g23n = add('div',[10,5]); g12n = add('div',[11,5])
lt1 = add('lt',[g23n, const(0.015,'float')]); lt2 = add('lt',[g12n, const(0.008,'float')]); surez = add('or',[add('or',[lt1,lt2]), 12])
lt3 = add('lt',[g23n, const(0.1,'float')]); lt4 = add('lt',[g12n, const(0.08,'float')]); prez = add('or',[lt3,lt4])
c1e4 = const(0.0001,'float')
L23 = add('log',[add('add',[g23n,c1e4])]); L12 = add('log',[add('add',[g12n,c1e4])])
m2n = add('div',[6,5]); smn = add('div',[add('sum',[0],axis=None),5]); neg3f = add('cast',[add('lt',[7,ZERO])],dtype='float'); ll = add('mul',[L23,L12])
f = add('stack',[L23,g23n,L12,g12n,m2n,smn,neg3f,ll],axis=0)
lg = add('add',[add('matmul',[const(beta.tolist(),'float'), f]), const(b0,'float')])
r1 = add('gather',[const(A1.tolist(),'float'), 2], axes=[0]); r2 = add('gather',[const(A2.tolist(),'float'), 3], axes=[0]); r3 = add('gather',[const(A3.tolist(),'float'), 4], axes=[0])
u1 = add('concat',[add('stack',[ONE,L12],axis=0), sl(r2,5,None), sl(r3,4,None)],axis=0); t1 = add('matmul',[r1,u1])
u2 = add('concat',[add('stack',[ONE,L23],axis=0), sl(r3,1,4)],axis=0); t2 = add('matmul',[sl(r2,None,5), u2])
lg = add('add',[lg,t1]); lg = add('add',[lg,t2]); lg = add('add',[lg, idx(r3,0)])
gtn = add('gt',[lg, const(thr,'float')])
cnd1 = add('cond',[prez, gtn, const(False,'bool')]); zone = add('cond',[surez, const(True,'bool'), cnd1])
pred = add('cond',[zone, am, 3])
# prune
reach=set(); stack=[pred]
while stack:
    i=stack.pop()
    if i in reach: continue
    reach.add(i); stack.extend(nodes[i].get('args',[]))
keep = sorted(reach); remap={o:n for n,o in enumerate(keep)}
new_nodes=[]
for o in keep:
    n=dict(nodes[o])
    if 'args' in n: n['args']=[remap[a] for a in n['args']]
    new_nodes.append(n)
entry = {"format":fmt, "nodes":new_nodes, "predict":remap[pred], "rule":None}
nconst = sum((np.asarray(n['value']).size if n['op']=='const' else 0) for n in new_nodes)
print("nodes", len(new_nodes), "consts", nconst)
save_entry("lowrank_v1", entry)
m = measure(entry); print(m)
# cross-check on fixed sample
no = network_outputs(); X0=np.asarray(no[0],float); Y0=np.asarray(no[1])
o0=np.argsort(X0,1); q1,q2,q3=o0[:,9],o0[:,8],o0[:,7]; a0=np.arange(len(X0))
n1,n2,n3=X0[a0,q1],X0[a0,q2],X0[a0,q3]; h23=(n2-np.maximum(n3,0))/n1; h12=(n1-n2)/n1
s0=(n2<0)|(h23<0.015)|(h12<0.008); pr0=(h23<0.1)|(h12<0.08)
L23_=np.log(h23+1e-4); L12_=np.log(h12+1e-4)
num0=np.stack([L23_,h23,L12_,h12,n2/n1,X0.sum(1)/n1,(n3<0).astype(float),L23_*L12_],1)
z0 = s0 | (pr0 & (np_logit(num0,q1,q2,q3,L12_,L23_)>thr))
exp_ans = np.where(z0, Y0, q2)
ev = lv1.Evaluator(entry, weights, 10)
bad=0; zone_mismatch=0
for i in range(4000):
    inside, ans, cr, cp = ev.run(X0[i])
    if ans != exp_ans[i]: bad+=1
    if (cp>1000) != z0[i]: zone_mismatch+=1
print("cross-check on 4000: answer mismatches", bad, "zone mismatches", zone_mismatch, "expected errors on fixed", ((Y0!=q2)&~z0).sum(), "zone frac", z0.mean())
