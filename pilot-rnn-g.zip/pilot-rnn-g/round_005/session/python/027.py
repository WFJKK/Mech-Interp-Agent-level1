
import numpy as np, time, math, gc, resource
def mem(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1e9
W = weights['input'][:,0]; R = weights['recurrent']; Ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], W), 0)
    for t in range(1, X.shape[1]):
        h = np.maximum(np.outer(X[:,t], W) + h @ R.T, 0)
    return (h @ Ro.T).argmax(1)
rng = np.random.default_rng(2024)
N = 2_000_000
X = rng.standard_normal((N,10))
Y = np.concatenate([fwd(X[i:i+250000]) for i in range(0,N,250000)])
order = np.argsort(X, axis=1); p1,p2,p3,p4 = order[:,9].copy(),order[:,8].copy(),order[:,7].copy(),order[:,6].copy(); del order
ar=np.arange(N); m1,m2,m3,m4 = X[ar,p1],X[ar,p2],X[ar,p3],X[ar,p4]
g23=(m2-np.maximum(m3,0))/m1; g12=(m1-m2)/m1; err=(Y!=p2)
sure=(m2<0)|(g23<0.015)|(g12<0.008); pre=(g23<0.1)|(g12<0.08); el=pre&~sure
l23=np.log(g23+1e-4); l12=np.log(g12+1e-4)
xs=X.sum(1); xneg=np.minimum(X,0).sum(1)
nxt2 = X[ar, np.minimum(p2+1,9)]/m1; prv2 = X[ar, np.maximum(p2-1,0)]/m1
cs = np.cumsum(X,1); before2 = (cs[ar,p2]-m2)/m1; before3 = (cs[ar,p3]-m3)/m1
num=np.stack([l23,g23,l12,g12,m2/m1,xs/m1,(m3<0).astype(float),l23*l12, l23**2, l12**2, (m2/m1)*l23, xneg/m1, (m3-np.maximum(m4,0))/m1, nxt2, prv2, before2, before3, (p2>p3).astype(float)*l23],1).astype(np.float32)
del X, xs, cs; gc.collect()
P={'p1':p1,'p2':p2,'p3':p3}
def feats(rows, cfg, cols):
    n=len(rows); a=np.arange(n); nn=len(cols)
    d = nn+1+30+20 + sum(10*V.shape[1] for _,_,V in cfg)
    F = np.zeros((n,d),np.float32); c=0
    F[:,:nn]=num[rows][:,cols]; c=nn; F[:,c]=1; c+=1
    for p in (p1,p2,p3): F[a,c+p[rows]]=1; c+=10
    F[a,c+p1[rows]]=l12[rows]; c+=10; F[a,c+p2[rows]]=l23[rows]; c+=10
    for an,bn,V in cfg:
        pa,pb=P[an],P[bn]; r=V.shape[1]
        for j in range(r): F[a,c+pa[rows]*r+j]=V[pb[rows],j]
        c+=10*r
    return F
def irls(F, y, l2=1e-2, iters=6, ch=50000):
    n,d = F.shape; w = np.zeros(d)
    for it in range(iters):
        g = np.zeros(d); H = l2*np.eye(d)
        for i in range(0,n,ch):
            Fc = F[i:i+ch].astype(np.float64); z = Fc@w; p = 1/(1+np.exp(-z)); s = p*(1-p)+1e-9
            g += Fc.T@(y[i:i+ch]-p); H += (Fc*s[:,None]).T@Fc
        g -= l2*w
        w += np.linalg.solve(H, g)
    return w
def wl(k,n,z=1.96):
    p=k/n; c=p+z*z/(2*n); s=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n)); return (c-s)/(1+z*z/n)
def reward(zone, modelrun, errv, tag="", n=16384):
    cost = (59 + 64*modelrun.mean() + 2136*zone.mean())/2937 + 0.00046
    e = (errv & ~zone).mean(); k=round((1-e)*n); fl=wl(k,n); r=(1-cost)-10*(1-fl)
    print(f"{tag} zone {zone.mean():.4f} err {e:.5f} cost {cost:.4f} reward {r:.4f}"); return r
ranks={'23':3,'12':3,'13':2}
ntr=1_500_000
rows_tr=np.flatnonzero(el[:ntr]); rows_te=np.flatnonzero(el); rows_te=rows_te[rows_te>=ntr]
ytr=err[rows_tr].astype(float)
def fit_eval(cols, tag, nalt=5, l2=1e-2):
    I10=np.eye(10); cfg=[('p2','p3',I10),('p1','p2',I10),('p1','p3',I10)]
    F=feats(rows_tr,cfg,cols); wf=irls(F,ytr,l2=l2); del F; gc.collect()
    c0=len(cols)+51; newcfg=[]
    for k,(an,bn,key) in enumerate([('p2','p3','23'),('p1','p2','12'),('p1','p3','13')]):
        Tk=wf[c0+100*k:c0+100*(k+1)].reshape(10,10); r=ranks[key]
        Tc=Tk-Tk.mean(0,keepdims=True)-Tk.mean(1,keepdims=True)+Tk.mean(); u,s,vt=np.linalg.svd(Tc); newcfg.append((an,bn,vt[:r].T*np.sqrt(s[:r])))
    cfg=newcfg
    for alt in range(nalt):
        F=feats(rows_tr,cfg,cols); w=irls(F,ytr,l2=l2); del F; gc.collect()
        if alt==nalt-1: break
        c=c0; newcfg=[]
        for an,bn,V in cfg:
            k=V.shape[1]; U=w[c:c+10*k].reshape(10,k); c+=10*k; newcfg.append((bn,an,U))
        cfg=newcfg
    lg=np.full(N,-99.0)
    for i in range(0,len(rows_te),50000):
        rr=rows_te[i:i+50000]; lg[rr]=feats(rr,cfg,cols).astype(np.float64)@w
    best=None
    for pth in [0.055,0.06,0.065]:
        t=np.log(pth/(1-pth)); zone=sure|(lg>t); r=reward(zone[ntr:], (pre&~sure)[ntr:], err[ntr:], tag=f"{tag} p={pth}")
    return w
base8=list(range(8))
fit_eval(base8, "base8")
fit_eval(base8+[8,9], "sq")
fit_eval(base8+[8,9,10], "sq+m2l23")
fit_eval(base8+[11], "xneg")
fit_eval(base8+[12], "g34")
fit_eval(base8+[13,14], "nbrs")
fit_eval(base8+[15,16], "before")
fit_eval(base8+[17], "orderl23")
fit_eval(base8, "base8 l2=1", l2=1.0)
