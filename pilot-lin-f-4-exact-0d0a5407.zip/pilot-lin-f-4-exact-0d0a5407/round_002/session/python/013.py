
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=100000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out = L.argmax(0)
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))
order = np.argsort(-Pt,axis=2); vals = -np.sort(-Pt,axis=2)
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def side(T, pr):
    a,b = T[:,pr[0]], T[:,pr[1]]
    return order[a,b], vals[a,b], Pt[a,b]
S = [ (side(T,pa), side(T,pb)) for pa,pb in pairings ]
def tests(sA,sB):
    idxA,valA,rowA = sA; idxB,valB,rowB = sB
    a1=idxA[:,0]; b1=idxB[:,0]
    ta = valA[:,0]+rowB[np.arange(N),a1] > valA[:,1]+valB[:,0]
    tb = valB[:,0]+rowA[np.arange(N),b1] > valB[:,1]+valA[:,0]
    # two-sided K=1
    best = np.maximum(valA[:,0]+rowB[np.arange(N),a1], valB[:,0]+rowA[np.arange(N),b1])
    t11 = best > valA[:,1]+valB[:,1]
    return ta,tb,t11
for i in range(3):
    ta,tb,t11 = tests(*S[i]); print(i, ta.mean(), tb.mean(), (ta|tb).mean(), t11.mean())
# best-of-3 by KV2 bound
bnds = np.stack([S[i][0][1][:,2]+S[i][1][1][:,2] for i in range(3)],1); ch=bnds.argmin(1)
bnds1 = np.stack([S[i][0][1][:,1]+S[i][1][1][:,1] for i in range(3)],1); ch1=bnds1.argmin(1)
for chs,name in [(ch,'KV2'),(ch1,'KV1')]:
    acc=np.zeros((3,N),bool)
    for i in range(3):
        m=chs==i; r=tests(*S[i])
        for k in range(3): acc[k][m]=r[k][m]
    print(name, acc[0].mean(), acc[1].mean(), (acc[0]|acc[1]).mean(), acc[2].mean())
# any-of-3 for ta|tb
anyt = np.zeros(N,bool)
for i in range(3):
    ta,tb,t11=tests(*S[i]); anyt|= (ta|tb)
print("any of 3 (ta|tb)", anyt.mean())
