
import inspect, re
src = inspect.getsource(lv1)
for m in re.finditer(r'\n(def|class|    def) [^\n]*', src):
    pass
# locate cost-related function
for kw in ['def _cost','def cost','def price','n_ops','"gather"','"take"']:
    for m in re.finditer(re.escape(kw), src):
        s=m.start(); print('---',kw, s); print(src[max(0,s-300):s+500]); break
