
import numpy as np, json
def build_entry(sched=(2,4,6,9,12,16), fallback='take_sum'):
    g = graph()
    Kmax = sched[-1]
    E = g.weight("embed")[:, :64]          # 8 x 64
    H = g.weight("hidden"); U = g.weight("unembed")
    W = U @ (H @ E)                        # 64 rows x 64 tokens
    Wt = W.T                               # tokens x rows
    rows = [Wt + Wt]
    for d in range(1, 33):
        rows.append(Wt + lv1.concat([Wt[d:], Wt[:d]], axis=0))
    Ph = lv1.stack(rows, axis=0).reshape(2112, 64)   # row d*64+a : pair (a,(a+d)%64)
    Phf = Ph.reshape(135168)
    PhT = Ph.T                              # 64 x 2112
    ar = g.arange(64)
    A = ar.reshape(64, 1); B = ar.reshape(1, 64)
    d = (B - A) % 64
    PI = lv1.where(d <= 32, d * 64 + A, (64 - d) * 64 + B)   # 64x64 -> pair index
    idx = lv1.argsort(Ph, axis=1)           # ascending
    base = (g.arange(2112) * 64).reshape(2112, 1)
    top = idx[:, 64 - Kmax:]                # (2112, Kmax), ascending; last = top-1
    SV = Phf[(base + top).reshape(2112 * Kmax)].reshape(2112, Kmax)
    def kv(K):   # (K+1)-th largest value per pair, position 63-K
        col = idx[:, 63 - K:64 - K]
        return Phf[(base + col).reshape(2112)]
    KVs = {K: kv(K) for K in sched}
    KVt = KVs[sched[0]][PI.reshape(4096)].reshape(64, 64)   # per ordered token pair
    t0, t1, t2, t3 = [g.token(i) for i in range(4)]
    b0 = KVt[t0, t1] + KVt[t2, t3]
    b1 = KVt[t0, t2] + KVt[t1, t3]
    b2 = KVt[t0, t3] + KVt[t1, t2]
    c1 = b0 <= b1
    m01 = lv1.minimum(b0, b1)
    c2 = m01 <= b2
    bound1 = lv1.minimum(m01, b2)
    pq = lv1.cond(c2, lv1.cond(c1, lv1.stack([PI[t0, t1], PI[t2, t3]], axis=0),
                                   lv1.stack([PI[t0, t2], PI[t1, t3]], axis=0)),
                      lv1.stack([PI[t0, t3], PI[t1, t2]], axis=0))
    p = pq[0]; q = pq[1]
    P64 = p * 64; Q64 = q * 64
    def cands(lo, hi):   # ranks lo..hi-1 from top (0 = best): positions Kmax-1-r
        sl_top = top[:, Kmax - hi: Kmax - lo]
        sl_sv = SV[:, Kmax - hi: Kmax - lo]
        ia = sl_top[p]; ib = sl_top[q]
        va = sl_sv[p]; vb = sl_sv[q]
        sa = va + Phf[Q64 + ia]
        sb = vb + Phf[P64 + ib]
        return lv1.concat([ia, ib], axis=0), lv1.concat([sa, sb], axis=0)
    # stage 1
    K1 = sched[0]
    ci, cv = cands(0, K1)
    m = cv.argmax(); best = cv[m]; ans = ci[m]
    ok = best > bound1
    # build the rest lazily from the last stage backwards
    def rest(i, best_prev, ans_prev):
        if i == len(sched):
            if fallback == 'take_sum':
                full = lv1.take_sum(PhT, pq, axis=1)
            else:
                full = Ph[p] + Ph[q]
            return full.argmax()
        Kp, K = sched[i - 1], sched[i]
        ci, cv = cands(Kp, K)
        cv2 = lv1.concat([cv, best_prev.reshape(1)], axis=0)
        ci2 = lv1.concat([ci, ans_prev.reshape(1)], axis=0)
        m = cv2.argmax(); b = cv2[m]; a = ci2[m]
        okk = b > (KVs[K][p] + KVs[K][q])
        return lv1.cond(okk, a, rest(i + 1, b, a))
    out = lv1.cond(ok, ans, rest(1, best, ans))
    return g.entry(interpretation=out)
e = build_entry()
print(len(e['nodes']))
r = measure(e); print(r)
save_entry("r2a", e)
