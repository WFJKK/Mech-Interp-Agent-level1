
import inspect, re
src = inspect.getsource(lv1)
for m in re.finditer(r'def (ops|_ops|op_cost|cost_of|price|charge)\w*\(', src):
    s=m.start(); print('---', m.group()); print(src[s:s+2500]); break
