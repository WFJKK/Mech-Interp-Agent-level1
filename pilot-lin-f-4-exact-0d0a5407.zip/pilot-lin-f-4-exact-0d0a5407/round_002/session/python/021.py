
import numpy as np, json
def build_entry(sched=(2,4,6,9,12,16)):
    g = graph()
    Kmax = sched[-1]
    E = g.weight("embed")[:, :64]
    H = g.weight("hidden"); U = g.weight("unembed")
    W = U @ (H @ E)
    Wt = W.T
    rows = [Wt + Wt]
    for d in range(1, 33):
        rows.append(Wt + lv1.concat([Wt[d:], Wt[:d]], axis=0))
    Ph = lv1.stack(rows, axis=0).reshape(2112, 64)
    Phf = Ph.reshape(135168)
    PhT = Ph.T
    ar = g.arange(64)
    A = ar.reshape(64, 1); B = ar.reshape(1, 64)
    d = (B - A) % 64
    X = d * 64
    PI = lv1.where(d <= 32, X + A, (B + 4096) - X)
    idx = lv1.argsort(Ph, axis=1)
    base = (g.arange(2112) * 64).reshape(2112, 1)
    top17 = idx[:, 63 - Kmax:]                       # (2112, Kmax+1) ascending
    SV17 = Phf[(base + top17).reshape(2112 * (Kmax + 1))].reshape(2112, Kmax + 1)
    top = top17[:, 1:]; SV = SV17[:, 1:]              # (2112, Kmax)
    def kv(K):   # (K+1)-th largest: ascending position 63-K -> offset 63-K-(63-Kmax) = Kmax-K
        return SV17[:, Kmax - K]
    KVt = kv(sched[0])[PI.reshape(4096)].reshape(64, 64)
    t0, t1, t2, t3 = [g.token(i) for i in range(4)]
    b0 = KVt[t0, t1] + KVt[t2, t3]
    b1 = KVt[t0, t2] + KVt[t1, t3]
    b2 = KVt[t0, t3] + KVt[t1, t2]
    c1 = b0 <= b1
    m01 = lv1.minimum(b0, b1)
    c2 = m01 <= b2
    bound1 = lv1.minimum(m01, b2)
    pq = lv1.cond(c2, lv1.cond(c1, lv1.stack([PI[t0, t1], PI[t2, t3]], axis=0),
                                   lv1.stack([PI[t0, t2], PI[t1, t3]], axis=0)),
                      lv1.stack([PI[t0, t3], PI[t1, t2]], axis=0))
    p = pq[0]; q = pq[1]
    pq64 = pq * 64
    P64 = pq64[0]; Q64 = pq64[1]
    def cands(lo, hi):
        sl_top = top[:, Kmax - hi: Kmax - lo]
        sl_sv = SV[:, Kmax - hi: Kmax - lo]
        ia = sl_top[p]; ib = sl_top[q]
        va = sl_sv[p]; vb = sl_sv[q]
        sa = va + Phf[Q64 + ia]
        sb = vb + Phf[P64 + ib]
        return lv1.concat([ia, ib], axis=0), lv1.concat([sa, sb], axis=0)
    K1 = sched[0]
    ci, cv = cands(0, K1)
    m = cv.argmax(); best = cv[m]; ans = ci[m]
    ok = best > bound1
    def rest(i, best_prev, ans_prev):
        if i == len(sched):
            return lv1.take_sum(PhT, pq, axis=1).argmax()
        Kp, K = sched[i - 1], sched[i]
        ci, cv = cands(Kp, K)
        cv2 = lv1.concat([cv, best_prev.reshape(1)], axis=0)
        ci2 = lv1.concat([ci, ans_prev.reshape(1)], axis=0)
        m = cv2.argmax(); b = cv2[m]; a = ci2[m]
        okk = b > (kv(K)[p] + kv(K)[q])
        return lv1.cond(okk, a, rest(i + 1, b, a))
    out = lv1.cond(ok, ans, rest(1, best, ans))
    return g.entry(interpretation=out)
e = build_entry()
print(len(e['nodes']))
r = measure(e); print(r)
save_entry("r2b", e)
