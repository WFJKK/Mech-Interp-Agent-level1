
import inspect, re
src = inspect.getsource(lv1)
lines = src.splitlines()
for i,l in enumerate(lines):
    if re.search(r'gather', l) and ('size' in l or 'prod' in l or 'cost' in l or 'ops' in l or '==' in l):
        print(i, l)
# find the function that maps op->count
for i,l in enumerate(lines):
    if 'def ' in l and ('op' in l.lower()):
        print(i, l)
