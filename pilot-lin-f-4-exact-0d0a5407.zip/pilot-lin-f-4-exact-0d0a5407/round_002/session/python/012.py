
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=100000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out = L.argmax(0)
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))
order = np.argsort(-Pt,axis=2); vals = -np.sort(-Pt,axis=2)
freq = np.bincount(out, minlength=64)/N
colrank = np.argsort(np.argsort(-W,axis=0),axis=0)
prox = {}
prox['pairtop1'] = np.bincount(order[:,:,0].ravel(), minlength=64)
prox['pairtop2'] = np.bincount(order[:,:,:2].ravel(), minlength=64)
prox['col_top1'] = np.bincount((-W).argmin(0), minlength=64)
for m in [2,3,4,6,8]:
    prox[f'col_top{m}'] = (colrank<m).sum(1)
prox['rowsum'] = W.sum(1)
prox['rowmax'] = W.max(1)
prox['rowsum_top8'] = np.sort(W,axis=1)[:,-8:].sum(1)
prox['rowsum_top16'] = np.sort(W,axis=1)[:,-16:].sum(1)
ordf = np.argsort(-freq)
for k,v in prox.items():
    o = np.argsort(-v, kind='stable')
    cum = [freq[o[:R]].sum().round(4) for R in [16,24,32,40,48]]
    print(f"{k:14s}", cum)
print("ideal         ", [freq[ordf[:R]].sum().round(4) for R in [16,24,32,40,48]])
