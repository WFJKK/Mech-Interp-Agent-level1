
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=50000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out = L.argmax(0)
cidx = np.argsort(-W,axis=0)  # cidx[k,t]
cval = -np.sort(-W,axis=0)
for K in [1,2,3,4,6,8]:
    cands = np.concatenate([cidx[:K, T[:,i]].T for i in range(4)],1)  # N x 4K
    cv = np.take_along_axis(L.T, cands, 1).max(1)
    bound = sum(cval[K, T[:,i]] for i in range(4))
    print(K, (cv>bound).mean())
