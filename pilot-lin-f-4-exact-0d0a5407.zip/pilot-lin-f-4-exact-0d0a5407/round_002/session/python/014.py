
import json
e = entries['best']
g, pred, rule = lv1.Graph.load(e, weights, 4)
print(type(g), len(e.get('nodes', [])) if isinstance(e, dict) else None)
print(e.keys())
# print node ops summary
nodes = e['nodes'] if 'nodes' in e else e
from collections import Counter
print(Counter(n['op'] for n in nodes))
# show the first 60 nodes compactly
for i,n in enumerate(nodes[:400]):
    s = {k:v for k,v in n.items() if k not in ('value',)}
    if 'value' in n: s['value']='<%d nums>'%(np.size(n['value']))
    print(i, s)
