
save_entry("best", entries['r2b'])
print(list(entries.keys()))
