
import numpy as np, time
e = entries['r2b']
# reference entry
gref = graph(); ref = gref.entry(interpretation=model.reference(gref, lv1))
def check(wts, n=3000, seed=0, targeted=False):
    rng = np.random.default_rng(seed)
    X = rng.integers(0,64,size=(n,4))
    ans, cost = lv1.run_reference(ref, wts, 4, X)
    ev = lv1.Evaluator(e, wts, 4)
    bad = 0; tot=0
    for x,a in zip(X, ans):
        inside, out, cr, cp = ev.run(x); tot += cp
        bad += int(out != a)
    return bad, tot/n, ev.build_cost
# this network
print("own", check(weights, 4000))
# random gaussian weights of several scales/seeds
for s in range(5):
    rng = np.random.default_rng(100+s)
    wts = {'embed': rng.normal(size=(8,65)).astype(np.float32), 'hidden': rng.normal(size=(8,8)).astype(np.float32), 'unembed': rng.normal(size=(64,8)).astype(np.float32)}
    wts['embed'][:,64]=0
    print("rand", s, check(wts, 3000, seed=s))
# degenerate: low-rank hidden, integer weights (many ties!)
rng = np.random.default_rng(7)
wts = {'embed': rng.integers(-2,3,size=(8,65)).astype(np.float64), 'hidden': rng.integers(-2,3,size=(8,8)).astype(np.float64), 'unembed': rng.integers(-2,3,size=(64,8)).astype(np.float64)}
wts['embed'][:,64]=0
print("int weights (ties expected)", check(wts, 2000, seed=3))
