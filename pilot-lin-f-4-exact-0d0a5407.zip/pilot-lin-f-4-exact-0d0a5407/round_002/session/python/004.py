
i = src.find('"gather"'); 
for m in re.finditer(r'gather|"take"|take_sum', src):
    pass
# find cost table
j = src.find('def cost') 
print(src[j:j+200] if j>=0 else 'no def cost')
k = src.find('PRICES'); print(k)
# print all lines mentioning 'ops' or 'price'
for line in src.splitlines():
    if ('gather' in line or 'take' in line) and ('cost' in line or 'ops' in line or 'price' in line or 'charge' in line):
        print(line)
