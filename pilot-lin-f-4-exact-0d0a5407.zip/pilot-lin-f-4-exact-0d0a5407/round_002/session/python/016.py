
import numpy as np, itertools
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(2)
N=100000
T=rng.integers(0,64,size=(N,4))
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))
order = np.argsort(-Pt,axis=2); vals = -np.sort(-Pt,axis=2)
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def side(T, pr):
    a,b = T[:,pr[0]], T[:,pr[1]]
    return order[a,b], vals[a,b], Pt[a,b]
S = [ (side(T,pa), side(T,pb)) for pa,pb in pairings ]
Kmax=24
def resolved_table(sA,sB):
    idxA,valA,rowA = sA; idxB,valB,rowB = sB
    res = np.zeros((Kmax+1,N),bool)
    best = np.full(N,-np.inf)
    for K in range(1,Kmax+1):
        va = valA[:,K-1] + rowB[np.arange(N), idxA[:,K-1]]
        vb = valB[:,K-1] + rowA[np.arange(N), idxB[:,K-1]]
        best = np.maximum(best, np.maximum(va,vb))
        res[K] = best > valA[:,K] + valB[:,K]
    return res
R = [resolved_table(*S[i]) for i in range(3)]
def choose(npair):
    if npair==1: return np.zeros(N,int)
    bnds = np.stack([S[i][0][1][:,2]+S[i][1][1][:,2] for i in range(npair)],1); return bnds.argmin(1)
def expected_cost(npair, sched, fallback=191):
    ch = choose(npair)
    res = np.zeros((Kmax+1,N),bool)
    for i in range(npair):
        m=ch==i; res[:,m]=R[i][:,m]
    setup = {1:7, 2:16, 3:25}[npair]
    cost = setup + 12*sched[0]+3
    reach = ~res[sched[0]]
    for a,b in zip(sched[:-1], sched[1:]):
        cost += reach.mean()*(12*(b-a)+10)
        reach = reach & ~res[b]
    cost += reach.mean()*fallback
    return cost
for npair in [1,2,3]:
    for sched in [[2,4,6,9,12,16],[2,4,7,11,16],[2,3,5,8,12,16],[2,4,6,8,11,14,18],[1,2,4,6,9,12,16],[3,5,8,12,16],[2,4,6,9,12,16,24]]:
        print(npair, sched, round(expected_cost(npair,sched),2))
