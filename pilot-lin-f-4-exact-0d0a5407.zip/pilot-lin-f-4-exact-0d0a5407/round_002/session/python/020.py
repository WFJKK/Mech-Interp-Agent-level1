
import numpy as np, itertools
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(5)
N=200000
T=rng.integers(0,64,size=(N,4))
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))
order = np.argsort(-Pt,axis=2); vals = -np.sort(-Pt,axis=2)
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def side(T, pr):
    a,b = T[:,pr[0]], T[:,pr[1]]
    return order[a,b], vals[a,b], Pt[a,b]
S = [ (side(T,pa), side(T,pb)) for pa,pb in pairings ]
Kmax=32
def resolved_table(sA,sB):
    idxA,valA,rowA = sA; idxB,valB,rowB = sB
    res = np.zeros((Kmax+1,N),bool); best = np.full(N,-np.inf)
    for K in range(1,Kmax+1):
        va = valA[:,K-1] + rowB[np.arange(N), idxA[:,K-1]]
        vb = valB[:,K-1] + rowA[np.arange(N), idxB[:,K-1]]
        best = np.maximum(best, np.maximum(va,vb))
        res[K] = best > valA[:,K] + valB[:,K]
    return res
R = [resolved_table(*S[i]) for i in range(3)]
bnds = np.stack([S[i][0][1][:,2]+S[i][1][1][:,2] for i in range(3)],1); ch=bnds.argmin(1)
res = np.zeros((Kmax+1,N),bool)
for i in range(3):
    m=ch==i; res[:,m]=R[i][:,m]
def expected_cost(sched, fallback=191):
    cost = 19 + 12*sched[0]+3
    reach = ~res[sched[0]]
    for a,b in zip(sched[:-1], sched[1:]):
        cost += reach.mean()*(12*(b-a)+7)
        reach = reach & ~res[b]
    cost += reach.mean()*fallback
    return cost + 2*sched[-1]*2112/16384   # SV build amortized
best=[]
for sched in [[2,4,6,9,12,16],[2,4,6,8,11,14,18],[2,4,6,8,10,13,16,20],[2,4,6,8,11,14,18,24],[2,4,6,9,12,16,22],[2,4,6,8,10,12,15,18,22],[2,4,6,8,10,12,14,16,18,20,24],[2,4,6,8,10,12,14,17,20,24,28]]:
    print(sched, round(expected_cost(sched),2))
