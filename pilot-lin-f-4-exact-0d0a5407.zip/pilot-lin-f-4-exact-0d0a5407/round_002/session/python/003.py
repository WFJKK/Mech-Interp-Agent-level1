
import inspect
src = inspect.getsource(lv1)
print(len(src))
import re
# print the parts about take/gather/getitem/cost
for name in ['take','gather','__getitem__','take_sum','cond','where','argsort','cost','price']:
    for m in re.finditer(name, src):
        pass
idx = src.find('def __getitem__')
print(src[idx:idx+3000])
