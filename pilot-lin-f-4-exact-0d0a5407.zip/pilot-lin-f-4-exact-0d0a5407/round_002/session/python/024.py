
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(5)
N=100000
T=rng.integers(0,64,size=(N,4))
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))
order_full = np.argsort(-Pt,axis=2)
pairtop1 = np.bincount(order_full[:,:,0].ravel(), minlength=64)
# subset proxy: pairs with d in 0..7
sub = np.zeros((64,64),bool)
for d in range(8):
    for a in range(64): sub[a,(a+d)%64]=True
pairtop1_sub = np.bincount(order_full[sub][:,0], minlength=64)
colrank = np.argsort(np.argsort(-W,axis=0),axis=0)
proxies = {'pairtop1':pairtop1, 'pairtop1_sub512':pairtop1_sub, 'col_top4':(colrank<4).sum(1)}
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
Kmax=16
def run(perm, R, mode):
    Pp = Pt[:,:,perm]
    strong = Pp[:,:,:R]; weak = Pp[:,:,R:]
    X = weak.max(2)                       # a,b
    order = np.argsort(-strong,axis=2); vals = -np.sort(-strong,axis=2)   # within strong
    def side(pr):
        a,b = T[:,pr[0]], T[:,pr[1]]
        return order[a,b], vals[a,b], Pp[a,b], X[a,b]
    S = [(side(pa), side(pb)) for pa,pb in pairings]
    def table(sA,sB):
        idxA,valA,rowA,XA = sA; idxB,valB,rowB,XB = sB
        res = np.zeros((Kmax+1,N),bool); best=np.full(N,-np.inf)
        for K in range(1,Kmax+1):
            va = valA[:,K-1] + rowB[np.arange(N), idxA[:,K-1]]
            vb = valB[:,K-1] + rowA[np.arange(N), idxB[:,K-1]]
            best = np.maximum(best, np.maximum(va,vb))
            if mode=='exact': bound = np.maximum(valA[:,K]+valB[:,K], XA+XB)
            else: bound = np.maximum(valA[:,K],XA)+np.maximum(valB[:,K],XB)
            res[K] = best > bound
        return res
    Rt = [table(*S[i]) for i in range(3)]
    def b2(i):
        sA,sB=S[i]
        if mode=='exact': return sA[1][:,2]+sB[1][:,2]   # choice by strong KV2 only
        return np.maximum(sA[1][:,2],sA[3])+np.maximum(sB[1][:,2],sB[3])
    ch = np.stack([b2(i) for i in range(3)],1).argmin(1)
    res = np.zeros((Kmax+1,N),bool)
    for i in range(3):
        m=ch==i; res[:,m]=Rt[i][:,m]
    sched=[2,4,6,9,12,16]
    extra = 4 if mode=='exact' else 0
    cost = 19 + extra + 12*sched[0]+3
    reach = ~res[sched[0]]
    for a,b in zip(sched[:-1], sched[1:]):
        cost += reach.mean()*(12*(b-a)+7+(1 if mode=='exact' else 0))
        reach = reach & ~res[b]
    cost += reach.mean()*191
    build = 2112*(R*int(np.ceil(np.log2(R))) + 17*2 + (64-R-1)) + 135168 + 37000 + 30000
    return cost, build/16384, res[2].mean(), reach.mean()
print("baseline per-input ~72.7, build 66.5 -> 139.2")
for pname,pv in proxies.items():
    perm = np.argsort(-pv, kind='stable')
    for R in [32,40,48]:
        for mode in ['exact','fold']:
            c,b,s1,fb = run(perm,R,mode)
            print(f"{pname:16s} R={R} {mode:5s} per-input={c:.1f} build={b:.1f} total={c+b:.1f} stage1={s1:.3f} fallback={fb:.4f}")
