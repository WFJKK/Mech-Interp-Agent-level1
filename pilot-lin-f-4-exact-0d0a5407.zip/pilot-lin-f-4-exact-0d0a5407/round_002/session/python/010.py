
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=100000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out = L.argmax(0)
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))  # a,b,j
order = np.argsort(-Pt,axis=2); vals = -np.sort(-Pt,axis=2)
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def side(T, pr):
    a,b = T[:,pr[0]], T[:,pr[1]]
    return order[a,b], vals[a,b], Pt[a,b]   # idx (N,64), sorted vals, raw row
S = [ (side(T,pa), side(T,pb)) for pa,pb in pairings ]
Ks=[0,1,2,3,4,5,6,8,10,12,16,24]
def resolved(sA,sB,KA,KB):
    idxA,valA,rowA = sA; idxB,valB,rowB = sB
    n=len(out)
    best = np.full(n,-np.inf)
    if KA>0:
        ca = idxA[:,:KA]; v = valA[:,:KA] + np.take_along_axis(rowB, ca, 1); best=np.maximum(best, v.max(1))
    if KB>0:
        cb = idxB[:,:KB]; v = valB[:,:KB] + np.take_along_axis(rowA, cb, 1); best=np.maximum(best, v.max(1))
    bound = valA[:,KA] + valB[:,KB]
    return best > bound
# fixed pairing, symmetric K
for K in [1,2,3,4,6,8,12,16]:
    r0 = resolved(*S[0],K,K)
    # best of 3 by bound KV_2
    bnds = np.stack([S[i][0][1][:,2]+S[i][1][1][:,2] for i in range(3)],1); ch=bnds.argmin(1)
    r3 = np.zeros(N,bool)
    for i in range(3):
        m=ch==i; r3[m]=resolved(*S[i],K,K)[m]
    r_any = r0|resolved(*S[1],K,K)|resolved(*S[2],K,K)
    print(K, "fixed",r0.mean().round(4), "best3(KV2)", r3.mean().round(4), "any of 3", r_any.mean().round(4))
# asymmetric
for KA,KB in [(1,0),(2,0),(3,0),(4,0),(2,1),(3,1),(4,1),(4,2),(6,2),(8,0),(8,2)]:
    print((KA,KB), resolved(*S[0],KA,KB).mean().round(4))
