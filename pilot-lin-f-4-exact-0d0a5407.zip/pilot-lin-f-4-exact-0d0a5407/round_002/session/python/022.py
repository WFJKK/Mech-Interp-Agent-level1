
import inspect, re
src = inspect.getsource(lv1)
for m in re.finditer(r'def run_reference[^\n]*\n(?:.*\n){0,15}', src):
    print(m.group()); break
i = src.find('class Evaluator'); print(src[i:i+1500])
