
import inspect
src = inspect.getsource(lv1); lines=src.splitlines()
print("\n".join(lines[604:668]))
