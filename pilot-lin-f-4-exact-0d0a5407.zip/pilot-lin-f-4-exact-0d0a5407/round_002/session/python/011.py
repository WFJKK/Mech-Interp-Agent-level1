
freq = np.bincount(out, minlength=64)/N
# proxies
colrank = np.argsort(np.argsort(-W,axis=0),axis=0)  # rank of row j in column t
prox = {}
prox['pairtop1'] = np.bincount(order[:,:,0].ravel(), minlength=64)
prox['pairtop2'] = np.bincount(order[:,:,:2].ravel(), minlength=64)
prox['col_top1'] = np.bincount(colrank.argmin(0) if False else (-W).argmin(0), minlength=64)
for m in [2,3,4,6,8]:
    prox[f'col_top{m}'] = (colrank<m).sum(1)
prox['rowsum'] = W.sum(1)
prox['rowmax'] = W.max(1)
prox['rowsum_top8'] = np.sort(W,axis=1)[:,-8:].sum(1)
ordf = np.argsort(-freq)
for k,v in prox.items():
    o = np.argsort(-v, kind='stable')
    # mass of wins captured by top R rows under proxy
    cum = [freq[o[:R]].sum().round(4) for R in [16,24,32,40,48]]
    print(f"{k:14s}", cum)
print("ideal", [freq[ordf[:R]].sum().round(4) for R in [16,24,32,40,48]])
