
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(3)
N=50000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out = L.argmax(0)
s = np.sort(T,axis=1)
cands = {'max':s[:,3],'min':s[:,0],'2nd':s[:,1],'3rd':s[:,2],'sum%64':T.sum(1)%64,'mean':T.sum(1)//4,
         'range':s[:,3]-s[:,0], 'median':(s[:,1]+s[:,2])//2, 'sum//4':T.sum(1)//4,'sum//8':T.sum(1)//8,
         'xor':T[:,0]^T[:,1]^T[:,2]^T[:,3], 'prod%64':(T[:,0]*T[:,1]*T[:,2]*T[:,3])%64,
         'absdiff01':abs(T[:,0]-T[:,1]), 'sum%32':T.sum(1)%32, 'max-min//2':(s[:,3]-s[:,0])//2,
        '(t0+t1)%64':(T[:,0]+T[:,1])%64,'(t2+t3)%64':(T[:,2]+T[:,3])%64,'(t0+t1-t2-t3)%64':(T[:,0]+T[:,1]-T[:,2]-T[:,3])%64,
        '(t0-t1)%64':(T[:,0]-T[:,1])%64, 'sum/4 round':np.round(T.sum(1)/4).astype(int)}
for k,v in cands.items():
    print(f"{k:18s} {np.mean(v==out):.4f}")
# structure of W: top singular values; correlation of output with sum
print(np.linalg.svd(W,compute_uv=False)[:9])
print(np.corrcoef(out, T.sum(1))[0,1], np.corrcoef(out, s[:,3])[0,1], np.corrcoef(out, s[:,0])[0,1])
# argmax per column of W, and E column structure
print(W.argmax(0))
