
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)   # 64 x 64 : W[j, t]
rng=np.random.default_rng(0)
N=200000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]  # 64 x N
out = L.argmax(0)
# sorted gaps
Ls=np.sort(L,axis=0)
gap=Ls[-1]-Ls[-2]
print("min gap", gap.min(), np.mean(gap<1e-9))
# pair tables: P[a,b,:] = W[:,a]+W[:,b]
P = W[:,:,None]+W[:,None,:]   # 64 x 64 x 64 : P[j,a,b]
Pt = np.transpose(P,(1,2,0))  # a,b,j
order = np.argsort(-Pt,axis=2)  # descending
vals = -np.sort(-Pt,axis=2)
# rank of winner in pair A=(t1,t2) and B=(t3,t4)
rank = np.argsort(order,axis=2)  # rank[a,b,j]
rA = rank[T[:,0],T[:,1],out]; rB=rank[T[:,2],T[:,3],out]
rmin=np.minimum(rA,rB)
print("fixed pairing: winner rank min dist", np.bincount(rmin,minlength=20)[:20]/N)
# top1 equal?
a1=order[T[:,0],T[:,1],0]; b1=order[T[:,2],T[:,3],0]
print("a1==b1", np.mean(a1==b1), " a1==b1 and correct", np.mean((a1==b1)&(a1==out)))
print("a1==out",np.mean(a1==out)," b1==out",np.mean(b1==out), "either", np.mean((a1==out)|(b1==out)))
# distribution of outputs
bc=np.bincount(out,minlength=64); print(np.sort(bc)[::-1][:10]/N, (bc>0).sum())
