
import inspect
src = inspect.getsource(lv1); lines=src.splitlines()
print("\n".join(lines[240:330]))
