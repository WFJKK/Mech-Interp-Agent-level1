
import json, inspect
print(info.keys())
print({k:v for k,v in info.items() if k!='data'})
print(list(entries.keys()))
e = entries['best']
print(len(json.dumps(e)))
print(measure(e))
