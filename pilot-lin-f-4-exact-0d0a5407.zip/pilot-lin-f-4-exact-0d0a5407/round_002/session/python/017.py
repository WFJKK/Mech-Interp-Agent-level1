
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(2)
N=100000
T=rng.integers(0,64,size=(N,4))
Pt = np.transpose(W[:,:,None]+W[:,None,:],(1,2,0))  # a,b,j
order = np.argsort(-Pt,axis=2)
colrank = np.argsort(np.argsort(-W,axis=0),axis=0)
prox = {'pairtop1': np.bincount(order[:,:,0].ravel(), minlength=64),
        'col_top4': (colrank<4).sum(1), 'col_top3': (colrank<3).sum(1),
        'pairtop2': np.bincount(order[:,:,:2].ravel(), minlength=64)}
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
tiers=[4,8,12,16,20,24,32,40,48,64]
for pname,pv in prox.items():
    perm = np.argsort(-pv, kind='stable')
    Pp = Pt[:,:,perm]  # permuted rows
    # X_n[p] = max over rows n.. of Pp
    rev = np.minimum.accumulate(Pp[:,:,::-1],axis=2)  # not max; do max accumulate from the end
    revmax = np.maximum.accumulate(Pp[:,:,::-1],axis=2)[:,:,::-1]  # revmax[...,n] = max over rows >= n
    rows = [Pp[T[:,a],T[:,b]] for a,b in [(0,1),(2,3),(0,2),(1,3),(0,3),(1,2)]]
    Xs = [revmax[T[:,a],T[:,b]] for a,b in [(0,1),(2,3),(0,2),(1,3),(0,3),(1,2)]]
    res = {}
    for i in range(3):
        A=rows[2*i]; B=rows[2*i+1]; S_=A+B
        cm = np.maximum.accumulate(S_,axis=1)  # best among first n rows: cm[:,n-1]
        r = np.zeros((len(tiers),N),bool)
        for k,n in enumerate(tiers):
            if n==64: r[k]=True
            else: r[k] = cm[:,n-1] > Xs[2*i][:,n] + Xs[2*i+1][:,n]
        res[i]=r
    # choice by X8 sum
    for nch in [4,8]:
        bnds = np.stack([Xs[2*i][:,nch]+Xs[2*i+1][:,nch] for i in range(3)],1); ch=bnds.argmin(1)
        comb = np.zeros((len(tiers),N),bool)
        for i in range(3):
            m=ch==i; comb[:,m]=res[i][:,m]
        print(pname, f"best3 by X{nch}", [round(x,3) for x in comb.mean(1)])
    print(pname, "fixed      ", [round(x,3) for x in res[0].mean(1)])
    anyr = res[0]|res[1]|res[2]
    print(pname, "any3       ", [round(x,3) for x in anyr.mean(1)])
print("tiers", tiers)
