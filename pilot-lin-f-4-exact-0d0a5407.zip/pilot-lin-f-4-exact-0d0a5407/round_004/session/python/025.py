
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(13); N=60000
T=rng.integers(0,64,size=(N,4)); ar=np.arange(N)
P = (W.T[:,None,:] + W.T[None,:,:])
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
colidx=np.argsort(-W,axis=0)
def sim(m,Ks):
    ca = colidx[:m,:].T   # 64 x m
    cand = np.concatenate([np.broadcast_to(ca[:,None,:],(64,64,m)), np.broadcast_to(ca[None,:,:],(64,64,m))],2)
    vals = np.take_along_axis(P, cand, 2)
    o = np.argsort(-vals,axis=2,kind='stable')
    srows = np.take_along_axis(cand,o,2); svals=np.take_along_axis(vals,o,2)
    # complement max
    rank = np.argsort(colidx,axis=0)   # rank[j,t]
    Wm = np.where(rank<m, -np.inf, W)
    comp = (Wm.T[:,None,:]+Wm.T[None,:,:]).max(2)   # 64x64
    nK=2*m
    def bound(K):
        b = svals[:,:,K] if K<nK else np.full((64,64),-np.inf)
        return np.maximum(b,comp)
    KV=bound(2)
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ta,tb,tc,td=[T[ar,A_tok[:,i]] for i in range(4)]
    AB=P[ta,tb]+P[tc,td]
    Arows=srows[ta,tb]; Brows=srows[tc,td]
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0; rates=[]
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        c=np.concatenate([Arows[:,:K],Brows[:,:K]],1)
        best=np.take_along_axis(AB,c,1).max(1)
        bs=bound(K)[ta,tb]+bound(K)[tc,td]
        ok=(~done)&(best>bs); cost[ok]=cum; rates.append(round(ok.mean(),3)); done|=ok
    cost[~done]=cum+1+191
    bpp = 64+63 + 2*m*2 + 2*m*int(np.ceil(np.log2(2*m))) + 2*m + 7*2
    return round(cost.mean()+bpp*2112/16384,2), rates, round((~done).mean(),4), round(bpp*2112/16384,1)
print('old-equivalent per-input ~63.4 + build 49.5+8.2 = 121')
for m in (8,12,16,20):
    for Ks in ([2,4,6,8,10,13,16],[2,4,6,8,11,14],[2,4,6,9,13]):
        if max(Ks)>2*m-1: continue
        print(m,Ks,sim(m,Ks))
