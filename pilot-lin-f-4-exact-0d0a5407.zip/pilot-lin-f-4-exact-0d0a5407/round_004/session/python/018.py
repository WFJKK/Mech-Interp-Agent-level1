
import inspect
src=inspect.getsource(lv1)
j=src.find('def __getitem__'); print(src[j+1800:j+4200])
k=src.find('def run_reference'); print(src[k:k+900])
