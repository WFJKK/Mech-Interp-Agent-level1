
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(4)
N=100000
T=rng.integers(0,64,size=(N,4))
P = (W.T[:,None,:] + W.T[None,:,:])
cnt = lambda k: (np.argsort(-W,axis=0)[:k,:][:,:,None]==np.arange(64)).sum((0,1))
sc = cnt(2)+1e-6*W.max(1)
order=np.argsort(-sc)
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
ar=np.arange(N)
def choose(KV):
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    return T[ar,A_tok[:,0]],T[ar,A_tok[:,1]],T[ar,A_tok[:,2]],T[ar,A_tok[:,3]]
truth = (P[T[:,0],T[:,1]]+P[T[:,2],T[:,3]]).argmax(1)

def sim_Gp(s, Ks, fb_cost=191, continue_after=False):
    strong=order[:s]; weak=order[s:]; m=64-s
    Ps = np.concatenate([P[:,:,strong], P[:,:,weak].max(2,keepdims=True)],2)
    srt=np.sort(Ps,2)[:,:,::-1]; aidx=np.argsort(-Ps,2,kind='stable')
    KV=srt[:,:,2]
    ta,tb,tc,td=choose(KV)
    AB=Ps[ta,tb]+Ps[tc,td]
    wtrue=(P[ta,tb][:,weak]+P[tc,td][:,weak]).max(1)
    Aidx=aidx[ta,tb]; Bidx=aidx[tc,td]; Asrt=srt[ta,tb]; Bsrt=srt[tc,td]
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0; stages=[]; weak_rate=0; wfail=0
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        c=np.concatenate([Aidx[:,:K],Bidx[:,:K]],1)
        v=np.take_along_axis(AB,c,1); bi=v.argmax(1); best=v[ar,bi]; bj=c[ar,bi]
        bs=Asrt[:,K]+Bsrt[:,K]
        ok=(~done)&(best>bs)
        isv = ok & (bj==s)
        # resolve: masked best real
        vm=np.where(c==s,-np.inf,v); br=vm.max(1)
        nb=np.maximum(br,wtrue)
        vfail = isv & ~(nb>bs)
        okfinal = ok & ~vfail
        cost[okfinal]=cum+2; cost[isv & ~vfail]+=3*m+4+4*K+2
        weak_rate+=isv.mean(); wfail+=vfail.mean(); stages.append(round(ok.mean(),3))
        done|=okfinal
        if not continue_after:
            cost[vfail]=cum+2+3*m+4+4*K+2+1+fb_cost; done|=vfail
    cost[~done]=cum+1+fb_cost
    bpp=(s+1)*int(np.ceil(np.log2(s+1)))+(m-1)
    return dict(stages=stages, weak=round(weak_rate,4), wfail=round(wfail,4), fb=round((~done).mean(),4), per_input=round(cost.mean(),2), build=round(bpp*2112/16384,2), total=round(cost.mean()+bpp*2112/16384,2))
Ks=[2,4,6,8,10,13,17]
for s in (44,48,52,56):
    print('Gp',s,sim_Gp(s,Ks))
