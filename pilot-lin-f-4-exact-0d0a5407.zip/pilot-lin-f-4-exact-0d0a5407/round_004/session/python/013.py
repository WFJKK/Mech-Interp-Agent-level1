
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(2)
N=100000
T=rng.integers(0,64,size=(N,4))
P = (W.T[:,None,:] + W.T[None,:,:])   # P[a,b,j]
colidx = np.argsort(-W,axis=0)        # colidx[r, t] = row with r-th largest W[:,t]
colval = -np.sort(-W,axis=0)

def sim_cand(m, Ks, dedupe=False):
    # candidates for pair (a,b): top-m of col a and col b
    ca = colidx[:m,:].T   # 64 x m  (per a)
    cand = np.concatenate([np.broadcast_to(ca[:,None,:],(64,64,m)), np.broadcast_to(ca[None,:,:],(64,64,m))],2)  # [a,b,2m]
    vals = np.take_along_axis(P, cand, 2)
    if dedupe:
        # mark duplicates (second occurrence) as -inf  (not used in the entry)
        dup = (cand[:,:,m:,None]==cand[:,:,None,:m]).any(3)
        vals = vals.copy(); vals[:,:,m:][dup] = -np.inf
    o = np.argsort(-vals,axis=2,kind='stable')
    srows = np.take_along_axis(cand,o,2); svals=np.take_along_axis(vals,o,2)
    thr = colval[m,:][:,None] + colval[m,:][None,:]
    nK=2*m
    def bound(K):
        b = svals[:,:,K] if K<nK else np.full((64,64),-np.inf)
        return np.maximum(b,thr)
    KV = bound(2)
    pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ar=np.arange(N)
    ta=T[ar,A_tok[:,0]]; tb=T[ar,A_tok[:,1]]; tc=T[ar,A_tok[:,2]]; td=T[ar,A_tok[:,3]]
    A=P[ta,tb]; B=P[tc,td]; AB=A+B
    Arows=srows[ta,tb]; Brows=srows[tc,td]
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0; stages=[]
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        c = np.concatenate([Arows[:,:K],Brows[:,:K]],1)
        best = np.take_along_axis(AB,c,1).max(1)
        bs = bound(K)[ta,tb]+bound(K)[tc,td]
        ok=(~done)&(best>bs)
        cost[ok]=cum; stages.append(round(ok.mean(),3)); done|=ok
    cost[~done]=cum+1+191
    build_pp = 2*m*(2+int(np.ceil(np.log2(2*m)))) + 7*2
    return dict(stages=stages, fb=round((~done).mean(),4), per_input=round(cost.mean(),2), build=round(build_pp*2112/16384+1.5,2), total=round(cost.mean()+build_pp*2112/16384+1.5,2))
for m,Ks in [(8,[2,4,6,8,10,13,16]),(12,[2,4,6,8,10,13,17]),(12,[2,4,6,8,11,15,20,24]),(16,[2,4,6,8,10,13,17]),(16,[2,4,6,8,11,15,20,26,32])]:
    print(m,Ks,sim_cand(m,Ks))
