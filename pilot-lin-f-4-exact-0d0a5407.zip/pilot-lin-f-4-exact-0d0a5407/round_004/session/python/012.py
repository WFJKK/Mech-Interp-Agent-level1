
import inspect, re
src=inspect.getsource(lv1)
i=src.find('def apply('); j=src.find('def check_structure')
print(src[i:j])
