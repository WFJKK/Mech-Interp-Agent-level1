
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(5)
N=100000
T=rng.integers(0,64,size=(N,4))
P = (W.T[:,None,:] + W.T[None,:,:])
cnt = lambda k: (np.argsort(-W,axis=0)[:k,:][:,:,None]==np.arange(64)).sum((0,1))
mx=W.max(1); o1=np.argsort(-mx,kind='stable'); c=cnt(2)[o1]; o2=np.argsort(-c,kind='stable'); order=o1[o2]
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
ar=np.arange(N)
def choose(KV):
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    return T[ar,A_tok[:,0]],T[ar,A_tok[:,1]],T[ar,A_tok[:,2]],T[ar,A_tok[:,3]]
cache={}
def prep(s):
    if s in cache: return cache[s]
    strong=order[:s]; weak=order[s:]
    Ps=P[:,:,strong]; wmax=P[:,:,weak].max(2)
    srt=np.sort(Ps,2)[:,:,::-1]; aidx=np.argsort(-Ps,2,kind='stable')
    ta,tb,tc,td=choose(srt[:,:,2])
    AB=Ps[ta,tb]+Ps[tc,td]; bw=wmax[ta,tb]+wmax[tc,td]
    r=(AB,bw,aidx[ta,tb],aidx[tc,td],srt[ta,tb],srt[tc,td]); cache[s]=r; return r
def sim(s,Ks):
    m=64-s
    AB,bw,Aidx,Bidx,Asrt,Bsrt=prep(s)
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        c=np.concatenate([Aidx[:,:K],Bidx[:,:K]],1)
        best=np.take_along_axis(AB,c,1).max(1)
        bs=Asrt[:,K]+Bsrt[:,K]
        ok=(~done)&(best>bs)
        cost[ok]=cum+6+np.where(best[ok]>bw[ok],0,3*m+4); done|=ok
    best=AB.max(1)
    cost[~done]=cum+1+3*s+2+6+np.where(best[~done]>bw[~done],0,3*m+4)
    bpp=s*int(np.ceil(np.log2(s)))+(m-1)
    return cost.mean()+bpp*2112/16384+1.5
res=[]
for s in (44,48,52):
    for n in (4,5,6,7):
        for Ks in itertools.combinations(range(3,s//2+1),n-1):
            Ks=(2,)+Ks
            if any(Ks[i+1]-Ks[i]>8 for i in range(len(Ks)-1)): continue
            res.append((sim(s,Ks),s,Ks))
res.sort()
for r in res[:15]: print(r)
print('baseline', sim(64,[2,4,6,8,10,13,17]))
