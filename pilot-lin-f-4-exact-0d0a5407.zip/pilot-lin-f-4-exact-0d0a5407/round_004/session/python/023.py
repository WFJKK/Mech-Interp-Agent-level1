
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(11); N=60000
T=rng.integers(0,64,size=(N,4)); ar=np.arange(N)
P = (W.T[:,None,:] + W.T[None,:,:])
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def make_order(k):
    cnt = (np.argsort(-W,axis=0)[:k,:][:,:,None]==np.arange(64)).sum((0,1))
    mx=W.max(1); o1=np.argsort(-mx,kind='stable'); c=cnt[o1]; o2=np.argsort(-c,kind='stable'); return o1[o2]
cache={}
def prep(s,k):
    key=(s,k)
    if key in cache: return cache[key]
    order=make_order(k); strong=order[:s]; weak=order[s:]
    Ps=P[:,:,strong]; wmax=P[:,:,weak].max(2) if s<64 else np.full((64,64),-np.inf)
    srt=np.sort(Ps,2)[:,:,::-1]; aidx=np.argsort(-Ps,2,kind='stable')
    KV=srt[:,:,2]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ta,tb,tc,td=[T[ar,A_tok[:,i]] for i in range(4)]
    AB=Ps[ta,tb]+Ps[tc,td]; bw=wmax[ta,tb]+wmax[tc,td]
    maxK=24; bestK=np.zeros((N,maxK+1)); bsK=np.zeros((N,maxK+1))
    Ai=aidx[ta,tb]; Bi=aidx[tc,td]; As=srt[ta,tb]; Bs=srt[tc,td]
    for K in range(1,maxK+1):
        c=np.concatenate([Ai[:,:K],Bi[:,:K]],1)
        bestK[:,K]=np.take_along_axis(AB,c,1).max(1)
        bsK[:,K]=As[:,K]+Bs[:,K] if K<s else -np.inf
    r=(AB.max(1),bw,bestK,bsK); cache[key]=r; return r
def sim(s,Ks,k=1,policy='now',exit_cost=6):
    m=64-s
    bestall,bw,bestK,bsK=prep(s,k)
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0; wr=3*m+4
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        best=bestK[:,K]
        oks=(~done)&(best>bsK[:,K]); okw=best>bw
        if m==0:
            cost[oks]=cum+1; done|=oks; continue
        if policy=='now' or i==len(Ks)-1:
            cost[oks]=cum+exit_cost+np.where(okw[oks],0,wr); done|=oks
        else:
            # continue if weak fails (max bound): +1 per stage for the max
            ok=oks&okw
            cost[ok]=cum+exit_cost+1*(i+1); done|=ok
    fb=cum+1+3*s+2
    cost[~done]=fb+exit_cost+(np.where(bestall[~done]>bw[~done],0,wr) if m>0 else 0)
    bpp=s*int(np.ceil(np.log2(s)))+(m-1 if m>1 else 0)
    extra = (13000 if k==1 else 46000)/16384 + (4096/16384 if s<64 else 0)
    return cost.mean()+bpp*2112/16384+extra
print('old', sim(64,[2,4,6,8,10,13,17]))
for s in (48,52):
    for k in (1,2):
        for pol in ('now','cont'):
            for Ks in ([2,4,6,8,11,14],[2,4,6,9,13],[2,4,6,8,10,13,17],[2,4,7,11,16],[2,4,6,9,12,16]):
                print(s,k,pol,Ks, round(sim(s,Ks,k,pol),2))
