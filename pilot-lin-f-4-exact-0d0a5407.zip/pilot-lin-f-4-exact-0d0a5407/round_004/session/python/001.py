
import numpy as np, time
print(info.keys())
print({k:v.shape for k,v in weights.items()})
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)   # 64 x 64, logit_j = sum_i W[j, t_i]
print(list(entries.keys()))
t=time.time(); m=measure(entries['best']); print(m, time.time()-t)
