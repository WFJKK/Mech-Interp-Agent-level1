
import inspect, re
src=inspect.getsource(lv1)
i=src.find('class Evaluator'); j=src.find('def all_inputs')
seg=src[i:j]
# print the cost-related parts
for m in re.finditer(r'\n    def \w+', seg):
    print(seg[m.start():m.start()+60].strip().split('\n')[0])
k=seg.find('def _charge'); 
if k<0: k=seg.find('cost')
print(seg[k:k+3500])
