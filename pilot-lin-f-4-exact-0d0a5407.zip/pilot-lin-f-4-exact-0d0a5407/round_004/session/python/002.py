
rng=np.random.default_rng(0)
N=200000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]   # 64 x N
out=L.argmax(0)
freq=np.bincount(out,minlength=64)/N
order_freq=np.argsort(-freq)
print("freq sorted:", np.round(freq[order_freq],4))
# heuristic scores
s_max = W.max(1)
s_sum = W.sum(1)
s_top4 = np.sort(W,1)[:,-4:].sum(1)
s_q = np.quantile(W,0.9,axis=1)
for name,s in [('max',s_max),('sum',s_sum),('top4',s_top4),('q90',s_q)]:
    o=np.argsort(-s)
    # how much win-frequency is in the bottom 32 / bottom 40 / bottom 48 by this score
    print(name, [round(freq[o[k:]].sum(),4) for k in (16,24,32,40,48)])
print('oracle', [round(freq[order_freq[k:]].sum(),4) for k in (16,24,32,40,48)])
