
save_entry("best", entries['r4b'])
print(sorted(entries.keys()))
