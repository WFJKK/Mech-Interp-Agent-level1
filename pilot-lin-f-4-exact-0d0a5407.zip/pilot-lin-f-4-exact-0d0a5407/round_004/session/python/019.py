
import numpy as np, json
def build_entry(s=48, Ks=(2,4,6,8,11,14), topn=None, verbose=True):
    m = 64 - s
    g = graph()
    emb, hid, unemb = g.weight("embed"), g.weight("hidden"), g.weight("unembed")
    W = unemb @ (hid @ emb[:, 0:64])          # 64 x 64
    # ---- row order: by count of top-2 appearances per token column, tie-break by row max
    mx = W.max(axis=1)
    o1 = lv1.argsort(-mx)                      # descending max (stable)
    ci = lv1.argsort(W, axis=0)                # ascending per column
    top2 = ci[62:64, :].reshape([128])
    cnt = (top2[None, :] == g.arange(64)[:, None]).sum(axis=1)   # 64
    o2 = lv1.argsort(-cnt[o1])
    order = o1[o2]                             # 64: strong rows first
    Wp = lv1.take(W, order, axis=0)            # rows permuted
    WT = Wp.T                                  # 64 tokens x 64 rows
    WTT = lv1.concat([WT, WT], axis=0)
    Ph = lv1.concat([WT + WTT[d:d + 64] for d in range(33)], axis=0)   # 2112 x 64, row = d*64 + a
    Phs = Ph[:, 0:s]; Phw = Ph[:, s:64]
    idx = lv1.argsort(Phs, axis=1)             # ascending
    wmax = Phw.max(axis=1)                     # 2112
    # pair index table
    A = g.arange(64)[:, None]; B = g.arange(64)[None, :]
    d = (B - A) % 64
    d64 = d * 64
    PI = lv1.where(d <= 32, d64 + A, (4096 - d64) + B)     # 64 x 64
    # bound columns: (K+1)-th largest strong value per pair, for each stage K
    base = g.arange(2112) * s
    PhsF = Phs.reshape([2112 * s])
    SV = [PhsF[base + idx[:, s - 1 - K]] for K in Ks]
    KVt = SV[0][PI.reshape([4096])].reshape([64, 64])
    IDXc = {r: idx[:, s - 1 - r] for r in range(max(Ks))}   # rank r (0 = top) column
    # ---- per input
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    b1 = KVt[t0, t1] + KVt[t2, t3]; b2 = KVt[t0, t2] + KVt[t1, t3]; b3 = KVt[t0, t3] + KVt[t1, t2]
    c12 = b1 <= b2
    c3 = b3 < lv1.minimum(b1, b2)
    toks = lv1.cond(c3, lv1.stack([t0, t3, t1, t2]), lv1.cond(c12, lv1.stack([t0, t1, t2, t3]), lv1.stack([t0, t2, t1, t3])))
    p = PI[toks[0], toks[1]]; q = PI[toks[2], toks[3]]
    pq = lv1.stack([p, q])
    def cand(r):
        out = []
        for pp in (p, q):
            j = IDXc[r][pp]
            out.append((j, Phs[p, j] + Phs[q, j]))
        return out
    # stages
    stage_res = []   # list of (ok, jbest, best)
    prev = None
    Kprev = 0
    for i, K in enumerate(Ks):
        cs = []
        for r in range(Kprev, K):
            cs += cand(r)
        js = [c[0] for c in cs]; vs = [c[1] for c in cs]
        if prev is None:
            v = lv1.stack(vs); jj = lv1.stack(js)
        else:
            v = lv1.concat([prev[1].reshape([1]), lv1.stack(vs)])
            jj = lv1.concat([prev[0].reshape([1]), lv1.stack(js)])
        bi = v.argmax()
        best = v[bi]; jbest = jj[bi]
        bound = SV[i][p] + SV[i][q]
        ok = best > bound
        stage_res.append((ok, jbest, best))
        prev = (jbest, best); Kprev = K
    # fallback over strong rows
    sums = lv1.take_sum(Phs, pq, axis=0)       # s
    jf = sums.argmax(); vf = sums[jf]
    res = lv1.stack([jf, vf])
    for ok, jbest, best in reversed(stage_res):
        res = lv1.cond(ok, lv1.stack([jbest, best]), res)
    j = lv1.cast(res[0], "int"); best = res[1]
    ans_strong = order[j]
    okw = best > (wmax[p] + wmax[q])
    ws = lv1.take_sum(Phw, pq, axis=0)         # m
    wi = ws.argmax(); wv = ws[wi]
    ans_weak = lv1.cond(wv > best, order[wi + s], ans_strong)
    ans = lv1.cond(okw, ans_strong, ans_weak)
    entry = g.entry(interpretation=ans)
    if verbose: print("nodes", len(entry['nodes']))
    return entry
e = build_entry()
r = measure(e); print(r)
save_entry("r4a", e)
