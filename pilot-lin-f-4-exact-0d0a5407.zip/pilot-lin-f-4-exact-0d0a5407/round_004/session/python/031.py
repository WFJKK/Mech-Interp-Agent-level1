
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(31)
X=rng.integers(0,64,size=(400000,4))
L=(W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]).T
s=np.sort(L,1); gap=s[:,-1]-s[:,-2]
sel=X[np.argsort(gap)[:600]]
extra=np.array([[a,a,a,a] for a in range(64)]+[[a,b,a,b] for a in range(0,64,5) for b in range(0,64,7)])
Xt=np.concatenate([sel,extra])
e2=entries['r4b']
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
ans,_=lv1.run_reference(ref_entry, weights, 4, Xt)
ev=lv1.Evaluator(e2, weights, 4)
bad=[(x,int(a),int(ev.run(x)[1])) for x,a in zip(Xt,ans) if int(ev.run(x)[1])!=int(a)]
print('near-tie min gap', gap.min(), 'tested', len(Xt), 'mismatches', len(bad), bad[:5])
