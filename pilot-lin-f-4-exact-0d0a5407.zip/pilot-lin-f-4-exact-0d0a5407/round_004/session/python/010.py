
import inspect, re
src=inspect.getsource(lv1)
idx=[m.start() for m in re.finditer(r'\n(def |class )', src)]
names=[src[i+1:src.find('\n',i+1)] for i in idx]
print(names)
k=src.find('"argsort"'); print(src[k-1500:k+1500])
