
import inspect, re
src=inspect.getsource(lv1)
for key in ['def cost', 'def _cost', 'PRICES =', 'def op_cost', 'cond']:
    for m in re.finditer(re.escape(key), src):
        pass
i=src.find('def op_cost'); 
if i<0: i=src.find('cost(')
print(src[i:i+4000])
