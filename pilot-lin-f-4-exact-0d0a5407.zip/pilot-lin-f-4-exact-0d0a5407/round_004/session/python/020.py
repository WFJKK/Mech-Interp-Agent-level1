
import numpy as np, collections
e=entries['r4a']
ev=lv1.Evaluator(e, weights, 4)
rng=np.random.default_rng(7)
X=rng.integers(0,64,size=(4000,4))
costs=[]
for x in X:
    inside, ans, cr, cp = ev.run(x)
    costs.append(cp)
costs=np.array(costs)
print(costs.mean(), ev.build_cost)
c=collections.Counter(costs.tolist())
for k in sorted(c): print(k, c[k])
