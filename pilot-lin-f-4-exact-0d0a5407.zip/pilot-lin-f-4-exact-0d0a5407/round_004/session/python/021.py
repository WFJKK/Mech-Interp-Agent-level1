
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
cnt2 = (np.argsort(-W,axis=0)[:2,:][:,:,None]==np.arange(64)).sum((0,1))
mx=W.max(1); o1=np.argsort(-mx,kind='stable'); c=cnt2[o1]; o2=np.argsort(-c,kind='stable'); order_np=o1[o2]
g = graph()
emb, hid, unemb = g.weight("embed"), g.weight("hidden"), g.weight("unembed")
Wg = unemb @ (hid @ emb[:, 0:64])
mxg = Wg.max(axis=1); o1g = lv1.argsort(-mxg)
ci = lv1.argsort(Wg, axis=0); top2 = ci[62:64, :].reshape([128])
cntg = (top2[None, :] == g.arange(64)[:, None]).sum(axis=1)
o2g = lv1.argsort(-cntg[o1g]); orderg = o1g[o2g]
print(np.abs(Wg.value-W).max())
print((cntg.value==cnt2).all(), (o1g.value==o1).all(), (orderg.value==order_np).all())
print(cnt2[order_np])
# win frequency of weak rows under this order
rng=np.random.default_rng(0); T=rng.integers(0,64,size=(100000,4))
L=W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]; out=L.argmax(0); freq=np.bincount(out,minlength=64)/1e5
print(np.round(freq[order_np],4))
