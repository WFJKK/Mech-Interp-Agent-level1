
import numpy as np, itertools, time
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(5)
N=40000
T=rng.integers(0,64,size=(N,4))
P = (W.T[:,None,:] + W.T[None,:,:])
cnt = lambda k: (np.argsort(-W,axis=0)[:k,:][:,:,None]==np.arange(64)).sum((0,1))
mx=W.max(1); o1=np.argsort(-mx,kind='stable'); c=cnt(2)[o1]; o2=np.argsort(-c,kind='stable'); order=o1[o2]
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
ar=np.arange(N)
def choose(KV):
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    return T[ar,A_tok[:,0]],T[ar,A_tok[:,1]],T[ar,A_tok[:,2]],T[ar,A_tok[:,3]]
cache={}
def prep(s):
    if s in cache: return cache[s]
    strong=order[:s]; weak=order[s:]
    Ps=P[:,:,strong]; wmax=P[:,:,weak].max(2) if s<64 else np.full((64,64),-np.inf)
    srt=np.sort(Ps,2)[:,:,::-1]; aidx=np.argsort(-Ps,2,kind='stable')
    ta,tb,tc,td=choose(srt[:,:,2])
    AB=Ps[ta,tb]+Ps[tc,td]; bw=wmax[ta,tb]+wmax[tc,td]
    # precompute: for each K, best over top-K union, and bs
    maxK=33
    bestK=np.zeros((N,maxK+1)); bsK=np.zeros((N,maxK+1))
    for K in range(1,maxK+1):
        c=np.concatenate([aidx[ta,tb][:,:K],aidx[tc,td][:,:K]],1)
        bestK[:,K]=np.take_along_axis(AB,c,1).max(1)
        bsK[:,K]=srt[ta,tb][:,K]+srt[tc,td][:,K] if K<s else -np.inf
    r=(AB.max(1),bw,bestK,bsK); cache[s]=r; return r
def sim(s,Ks):
    m=64-s
    bestall,bw,bestK,bsK=prep(s)
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        best=bestK[:,K]
        ok=(~done)&(best>bsK[:,K])
        cost[ok]=cum+6+(np.where(best[ok]>bw[ok],0,3*m+4) if m>0 else 0); done|=ok
    cost[~done]=cum+1+3*s+2+6+(np.where(bestall[~done]>bw[~done],0,3*m+4) if m>0 else 0)
    bpp=s*int(np.ceil(np.log2(s)))+(m-1 if m>1 else 0)
    return cost.mean()+bpp*2112/16384+1.5
t=time.time()
print('baseline', sim(64,[2,4,6,8,10,13,17]), time.time()-t)
def coord(s,Ks):
    Ks=list(Ks); best=sim(s,Ks)
    improved=True
    while improved:
        improved=False
        for i in range(1,len(Ks)):
            for delta in (-2,-1,1,2):
                K2=Ks.copy(); K2[i]+=delta
                if K2[i]<=K2[i-1] or (i+1<len(K2) and K2[i]>=K2[i+1]) or K2[i]>s//2: continue
                v=sim(s,K2)
                if v<best-1e-9: best=v; Ks=K2; improved=True
    return best,Ks
for s in (44,48,52,56):
    for init in ([2,4,6,9,13],[2,4,6,8,11,15],[2,4,6,8,10,13,17],[2,5,9]):
        print(s, coord(s,init))
