
import numpy as np
def build_plain2(Ks=(2,4,6,8,10,13,17)):
    g = graph()
    emb, hid, unemb = g.weight("embed"), g.weight("hidden"), g.weight("unembed")
    W = unemb @ (hid @ emb[:, 0:64])
    WT = W.T
    WTT = lv1.concat([WT, WT], axis=0)
    Ph = lv1.concat([WT + WTT[d:d + 64] for d in range(33)], axis=0)   # 2112 x 64
    idx = lv1.argsort(Ph, axis=1)
    A = g.arange(64)[:, None]; B = g.arange(64)[None, :]
    d = (B - A) % 64
    dv = g.arange(64)
    F = lv1.where(dv <= 32, dv * 64, 4096 - dv * 64)
    PI = F[d.reshape([4096])].reshape([64, 64]) + lv1.where(d <= 32, A, B)
    base = g.arange(2112) * 64
    PhF = Ph.reshape([2112 * 64])
    SV = [PhF[base + idx[:, 63 - K]] for K in Ks]
    KVt = SV[0][PI.reshape([4096])].reshape([64, 64])
    IDXc = {r: idx[:, 63 - r] for r in range(max(Ks))}
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    b1 = KVt[t0, t1] + KVt[t2, t3]; b2 = KVt[t0, t2] + KVt[t1, t3]; b3 = KVt[t0, t3] + KVt[t1, t2]
    c12 = b1 <= b2
    m12 = lv1.minimum(b1, b2)
    c3 = b3 < m12
    bound1 = lv1.minimum(b3, m12)
    toks = lv1.cond(c3, lv1.stack([t0, t3, t1, t2]), lv1.cond(c12, lv1.stack([t0, t1, t2, t3]), lv1.stack([t0, t2, t1, t3])))
    p = PI[toks[0], toks[1]]; q = PI[toks[2], toks[3]]
    def cand(r):
        out = []
        for pp in (p, q):
            j = IDXc[r][pp]
            out.append((j, Ph[p, j] + Ph[q, j]))
        return out
    stage_res = []; prev = None; Kprev = 0
    for i, K in enumerate(Ks):
        cs = []
        for r in range(Kprev, K): cs += cand(r)
        js = [c[0] for c in cs]; vs = [c[1] for c in cs]
        if prev is None:
            v = lv1.stack(vs); jj = lv1.stack(js)
        else:
            v = lv1.concat([prev[1].reshape([1]), lv1.stack(vs)]); jj = lv1.concat([prev[0].reshape([1]), lv1.stack(js)])
        bi = v.argmax(); best = v[bi]; jbest = jj[bi]
        bound = bound1 if i == 0 else SV[i][p] + SV[i][q]
        ok = best > bound
        stage_res.append((ok, jbest)); prev = (jbest, best); Kprev = K
    res = lv1.take_sum(Ph, lv1.stack([p, q]), axis=0).argmax()
    for ok, jbest in reversed(stage_res):
        res = lv1.cond(ok, jbest, res)
    entry = g.entry(interpretation=res)
    print("nodes", len(entry['nodes']))
    return entry
e2 = build_plain2(); r2 = measure(e2); print({k: r2[k] for k in ('build_ops','predict_ops','cost','reward','fidelity')})
save_entry("r4b", e2)
rb = measure(entries['best']); print({k: rb[k] for k in ('build_ops','predict_ops','cost','reward')})
