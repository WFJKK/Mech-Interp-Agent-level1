
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(12); N=60000
T=rng.integers(0,64,size=(N,4)); ar=np.arange(N)
P = (W.T[:,None,:] + W.T[None,:,:])
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def make_order(k):
    cnt = (np.argsort(-W,axis=0)[:k,:][:,:,None]==np.arange(64)).sum((0,1))
    mx=W.max(1); o1=np.argsort(-mx,kind='stable'); c=cnt[o1]; o2=np.argsort(-c,kind='stable'); return o1[o2]
cache={}
def prep(s,k):
    key=(s,k)
    if key in cache: return cache[key]
    order=make_order(k); strong=order[:s]; weak=order[s:]
    Ps=P[:,:,strong]; wmax=P[:,:,weak].max(2) if s<64 else np.full((64,64),-np.inf)
    srt=np.sort(Ps,2)[:,:,::-1]; aidx=np.argsort(-Ps,2,kind='stable')
    srt2=np.maximum(srt,wmax[:,:,None])   # folded bounds
    KV=srt2[:,:,2]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ta,tb,tc,td=[T[ar,A_tok[:,i]] for i in range(4)]
    AB=Ps[ta,tb]+Ps[tc,td]
    maxK=24; bestK=np.zeros((N,maxK+1)); bsK=np.zeros((N,maxK+1))
    Ai=aidx[ta,tb]; Bi=aidx[tc,td]; As=srt2[ta,tb]; Bs=srt2[tc,td]
    for K in range(1,maxK+1):
        c=np.concatenate([Ai[:,:K],Bi[:,:K]],1)
        bestK[:,K]=np.take_along_axis(AB,c,1).max(1)
        bsK[:,K]=As[:,K]+Bs[:,K] if K<s else np.inf
    r=(bestK,bsK); cache[key]=r; return r
def sim(s,Ks,k=1):
    m=64-s
    bestK,bsK=prep(s,k)
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0; rates=[]
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        ok=(~done)&(bestK[:,K]>bsK[:,K])
        cost[ok]=cum+1; rates.append(round(ok.mean(),3)); done|=ok
    cost[~done]=cum+1+191+1
    bpp=s*int(np.ceil(np.log2(s)))+(m-1 if m>1 else 0)
    extra = (13000 if k==1 else 46000)/16384 + 4096/16384 + 14.4 + (2112*len(Ks)/16384)
    return round(cost.mean()+bpp*2112/16384+extra,2), rates, round((~done).mean(),4)
print('old', sim(64,[2,4,6,8,10,13,17]))
for s in (48,52,56,60):
    for k in (1,2):
        for Ks in ([2,4,6,8,10,13,17],[2,4,6,8,11,14],[2,4,6,9,13],[2,4,6,8,10,12],[2,4,6,8,10]):
            print(s,k,Ks, sim(s,Ks,k))
