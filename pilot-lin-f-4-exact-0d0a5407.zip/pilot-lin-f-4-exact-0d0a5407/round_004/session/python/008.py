
import inspect
src=inspect.getsource(lv1)
i=src.find('def price'); print(src[i:i+3500])
j=src.find('def __getitem__'); print(src[j:j+1800])
