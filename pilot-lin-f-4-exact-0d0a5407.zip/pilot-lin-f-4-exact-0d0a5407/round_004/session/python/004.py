
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=100000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out=L.argmax(0)
freq=np.bincount(out,minlength=64)/N

# pair table token-indexed: P[a,b,:] = W[:,a]+W[:,b]
P = (W.T[:,None,:] + W.T[None,:,:])  # 64x64x64

def simulate(S_order, s, Ks, m_cost=None, verbose=False):
    # S_order: row permutation, first s are strong
    strong = S_order[:s]; weak = S_order[s:]; m=64-s
    Ps = P[:,:,strong]   # 64x64xs
    srt = np.sort(Ps,axis=2)[:,:,::-1]   # desc values
    aidx = np.argsort(-Ps,axis=2)        # indices into strong
    if m>0:
        wmax = P[:,:,weak].max(2)
    else:
        wmax = np.full((64,64), -np.inf)
    KV = srt[:,:,2]  # 3rd largest
    # pairing choice
    pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ta=T[np.arange(N),A_tok[:,0]]; tb=T[np.arange(N),A_tok[:,1]]; tc=T[np.arange(N),A_tok[:,2]]; td=T[np.arange(N),A_tok[:,3]]
    A=Ps[ta,tb]; B=Ps[tc,td]        # N x s strong values
    Asrt=srt[ta,tb]; Bsrt=srt[tc,td]; Aidx=aidx[ta,tb]; Bidx=aidx[tc,td]
    bw = wmax[ta,tb]+wmax[tc,td]
    AB=A+B
    full_s_max = AB.max(1)
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0
    res={'stage':[], 'weak':0.0,'fallback':0.0}
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        cand = np.concatenate([Aidx[:,:K],Bidx[:,:K]],1)
        best = np.take_along_axis(AB,cand,1).max(1)
        bs = Asrt[:,K]+Bsrt[:,K] if K<s else np.full(N,-np.inf)
        ok = (~done) & (best>bs)
        okw = ok & (best>bw)
        okweak = ok & ~(best>bw)
        cost[okw]=cum+5
        cost[okweak]=cum+5+3*m+4
        res['stage'].append(okw.mean()); res['weak']+=okweak.mean()
        done|=ok
    cost[~done]=cum+1+191
    res['fallback']=(~done).mean()
    res['mean_cost']=cost.mean()
    build_per_pair = (s*int(np.ceil(np.log2(s))) if s>1 else 0) + (m-1 if m>1 else 0)
    res['build_pp']=build_per_pair
    res['build_per_input']=build_per_pair*2112/16384
    res['total']=res['mean_cost']+res['build_per_input']
    return res

Ks=[2,4,6,8,10,13,17]
o_or=np.argsort(-freq)
print('baseline s=64', simulate(np.arange(64),64,Ks))
for s in (32,40,48,56):
    print('oracle',s, simulate(o_or,s,Ks))
