
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
cnt2 = (np.argsort(-W,axis=0)[:2,:][:,:,None]==np.arange(64)).sum((0,1))
mx=W.max(1); o1=np.argsort(-mx,kind='stable'); c=cnt2[o1]; o2=np.argsort(-c,kind='stable'); order=o1[o2]
s=48; strong=order[:s]; weak=order[s:]
P = (W.T[:,None,:] + W.T[None,:,:])
Ps=P[:,:,strong]; wmax=P[:,:,weak].max(2)
srt=np.sort(Ps,2)[:,:,::-1]; aidx=np.argsort(-Ps,2,kind='stable')
KV=srt[:,:,2]
rng=np.random.default_rng(7); N=4000
T=rng.integers(0,64,size=(N,4)); ar=np.arange(N)
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
ch=bounds.argmin(1)
A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
ta,tb,tc,td=[T[ar,A_tok[:,i]] for i in range(4)]
AB=Ps[ta,tb]+Ps[tc,td]; bw=wmax[ta,tb]+wmax[tc,td]
K=2
cnd=np.concatenate([aidx[ta,tb][:,:K],aidx[tc,td][:,:K]],1)
best=np.take_along_axis(AB,cnd,1).max(1); bs=srt[ta,tb][:,K]+srt[tc,td][:,K]
ok=best>bs
print('stage1 ok', ok.mean(), 'weak trigger among ok', (ok&~(best>bw)).mean())
# true weak max vs best
wtrue=(P[ta,tb][:,weak]+P[tc,td][:,weak]).max(1)
print('weak actually wins', (ok&(wtrue>best)).mean())
# compare with entry: build variant returning okw
import types
src_build = None
