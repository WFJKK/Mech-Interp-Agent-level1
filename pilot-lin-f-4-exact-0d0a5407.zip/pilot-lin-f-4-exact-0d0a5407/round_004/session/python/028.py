
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(21); N=60000
T=rng.integers(0,64,size=(N,4)); ar=np.arange(N)
P = (W.T[:,None,:] + W.T[None,:,:])
srt=np.sort(P,2)[:,:,::-1]; aidx=np.argsort(-P,2,kind='stable')
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
cache={}
def prep(npair,K0):
    key=(npair,K0)
    if key in cache: return cache[key]
    KV=srt[:,:,K0]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings[:npair]],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ta,tb,tc,td=[T[ar,A_tok[:,i]] for i in range(4)]
    AB=P[ta,tb]+P[tc,td]; Ai=aidx[ta,tb]; Bi=aidx[tc,td]; As=srt[ta,tb]; Bs=srt[tc,td]
    maxK=24; bestK=np.zeros((N,maxK+1)); bsK=np.zeros((N,maxK+1))
    for K in range(1,maxK+1):
        c=np.concatenate([Ai[:,:K],Bi[:,:K]],1)
        bestK[:,K]=np.take_along_axis(AB,c,1).max(1); bsK[:,K]=As[:,K]+Bs[:,K]
    cache[key]=(bestK,bsK); return cache[key]
def run(npair, Ks):
    pair_cost={3:16,2:10,1:5}[npair]
    bestK,bsK=prep(npair,Ks[0])
    cost=np.zeros(N); done=np.zeros(N,bool); cum=pair_cost; rates=[]
    costs_stage=[10*Ks[0]+4]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        ok=(~done)&(bestK[:,K]>bsK[:,K]); cost[ok]=cum; rates.append(round(ok.mean(),3)); done|=ok
    cost[~done]=cum+1+191
    return round(cost.mean(),2), rates
def coord(npair,Ks):
    Ks=list(Ks); best=run(npair,Ks)[0]
    improved=True
    while improved:
        improved=False
        for i in range(len(Ks)):
            for delta in (-1,1):
                K2=Ks.copy(); K2[i]+=delta
                if K2[i]<1 or (i>0 and K2[i]<=K2[i-1]) or (i+1<len(K2) and K2[i]>=K2[i+1]) or K2[i]>24: continue
                v=run(npair,K2)[0]
                if v<best-1e-9: best=v; Ks=K2; improved=True
    return best,Ks
for npair in (3,2):
    for init in ([2,4,6,8,10,13,17],[3,5,7,10,13,17],[1,3,5,7,10,13,17],[3,6,9,13,17],[2,4,6,9,13,17]):
        print(npair, init, run(npair,init)[0], coord(npair,init))
