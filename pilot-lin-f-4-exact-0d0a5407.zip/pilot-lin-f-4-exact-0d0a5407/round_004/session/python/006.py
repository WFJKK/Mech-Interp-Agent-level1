
import json, collections, inspect
e=entries['best']
print(type(e), list(e.keys()) if isinstance(e,dict) else None)
nodes=e['nodes'] if 'nodes' in e else None
print(len(nodes) if nodes else None)
print(collections.Counter(n.get('op') for n in nodes).most_common() if nodes else None)
print([k for k in dir(lv1) if not k.startswith('_')])
print(inspect.signature(lv1.cond), inspect.signature(lv1.take_sum), inspect.signature(lv1.argsort))
