
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=100000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
out=L.argmax(0)
freq=np.bincount(out,minlength=64)/N
P = (W.T[:,None,:] + W.T[None,:,:])
def simulate(S_order, s, Ks):
    strong = S_order[:s]; weak = S_order[s:]; m=64-s
    Ps = P[:,:,strong]
    srt = np.sort(Ps,axis=2)[:,:,::-1]
    aidx = np.argsort(-Ps,axis=2)
    wmax = P[:,:,weak].max(2) if m>0 else np.full((64,64), -np.inf)
    KV = srt[:,:,2]
    pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ar=np.arange(N)
    ta=T[ar,A_tok[:,0]]; tb=T[ar,A_tok[:,1]]; tc=T[ar,A_tok[:,2]]; td=T[ar,A_tok[:,3]]
    A=Ps[ta,tb]; B=Ps[tc,td]
    Asrt=srt[ta,tb]; Bsrt=srt[tc,td]; Aidx=aidx[ta,tb]; Bidx=aidx[tc,td]
    bw = wmax[ta,tb]+wmax[tc,td]
    AB=A+B
    cost=np.zeros(N); done=np.zeros(N,bool)
    costs_stage=[23]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    cum=17.0; weak=0; stages=[]
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        cand = np.concatenate([Aidx[:,:K],Bidx[:,:K]],1)
        best = np.take_along_axis(AB,cand,1).max(1)
        bs = Asrt[:,K]+Bsrt[:,K] if K<s else np.full(N,-np.inf)
        ok = (~done) & (best>bs)
        okw = ok & (best>bw); okweak = ok & ~(best>bw)
        cost[okw]=cum+(5 if m>0 else 0); cost[okweak]=cum+5+3*m+4
        weak+=okweak.mean(); stages.append(round(okw.mean(),3))
        done|=ok
    cost[~done]=cum+1+191
    bpp = (s*int(np.ceil(np.log2(s)))) + (m-1 if m>1 else 0)
    return dict(stages=stages, weak=round(weak,4), fb=round((~done).mean(),4), per_input=round(cost.mean(),2), build=round(bpp*2112/16384,2), total=round(cost.mean()+bpp*2112/16384,2))
Ks=[2,4,6,8,10,13,17]
Wsrt=np.sort(W,1)
cnt = lambda k: (np.argsort(-W,axis=0)[:k,:][:,:,None]==np.arange(64)).sum((0,1))
heur = {'oracle':freq,'max':W.max(1),'q90':np.quantile(W,0.9,axis=1),'top4':Wsrt[:,-4:].sum(1),'top8':Wsrt[:,-8:].sum(1),'top2':Wsrt[:,-2:].sum(1),
        'cnt1':cnt(1)+1e-6*W.max(1),'cnt2':cnt(2)+1e-6*W.max(1),'cnt4':cnt(4)+1e-6*W.max(1),'cnt8':cnt(8)+1e-6*W.max(1),
        'pairargmax': np.bincount(P.reshape(-1,64).argmax(1),minlength=64)+1e-6*W.max(1)}
for name,sc in heur.items():
    o=np.argsort(-sc)
    for s in (48,56):
        print(name, s, simulate(o,s,Ks))
