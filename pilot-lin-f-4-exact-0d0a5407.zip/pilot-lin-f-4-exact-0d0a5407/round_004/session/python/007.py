
import inspect
print(lv1.PRICES)
print([k for k in dir(lv1.Expr) if not k.startswith('__')])
print([k for k in dir(lv1.Graph) if not k.startswith('__')])
src=inspect.getsource(lv1)
i=src.find('def gather'); print(src[i:i+1500])
