
import numpy as np, time
e2 = entries['r4b']
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
def check(wts, n=1500, seed=0, name=''):
    rng=np.random.default_rng(seed)
    X=rng.integers(0,64,size=(n,4))
    ans, c = lv1.run_reference(ref_entry, wts, 4, X)
    ev=lv1.Evaluator(e2, wts, 4)
    bad=0; tot=0
    for x,a in zip(X,ans):
        inside, pred, cr, cp = ev.run(x); tot+=cp
        bad += int(pred)!=int(a)
    print(name, 'mismatches', bad, 'of', n, 'per-input', tot/n, 'build', ev.build_cost)
t=time.time()
for seed in range(3):
    rng=np.random.default_rng(100+seed)
    wts={'embed': np.concatenate([rng.normal(size=(8,64))*(0.1 if seed else 1.0), np.zeros((8,1))],1),
         'hidden': rng.normal(size=(8,8)), 'unembed': rng.normal(size=(64,8))}
    check(wts, seed=seed, name=f'gauss{seed}')
# degenerate: near rank-1 hidden
rng=np.random.default_rng(7)
u=rng.normal(size=(8,1)); v=rng.normal(size=(1,8))
wts={'embed': np.concatenate([rng.normal(size=(8,64)), np.zeros((8,1))],1), 'hidden': u@v+1e-3*rng.normal(size=(8,8)), 'unembed': rng.normal(size=(64,8))}
check(wts, seed=5, name='rank1')
# permuted own weights
wts={'embed': weights['embed'][:, list(rng.permutation(64))+[64]], 'hidden': weights['hidden'][::-1,:], 'unembed': weights['unembed'][rng.permutation(64)]}
check(wts, seed=6, name='permuted')
check(weights, n=3000, seed=9, name='own')
print(time.time()-t)
