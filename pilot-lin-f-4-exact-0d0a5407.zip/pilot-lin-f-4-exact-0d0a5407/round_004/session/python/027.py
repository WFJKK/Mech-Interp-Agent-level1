
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(21); N=60000
T=rng.integers(0,64,size=(N,4)); ar=np.arange(N)
P = (W.T[:,None,:] + W.T[None,:,:])
srt=np.sort(P,2)[:,:,::-1]; aidx=np.argsort(-P,2,kind='stable')
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def run(npair, Ks, pair_cost):
    KV=srt[:,:,2]
    bounds=np.stack([KV[T[:,a],T[:,b]]+KV[T[:,c],T[:,d]] for (a,b),(c,d) in pairings[:npair]],1)
    ch=bounds.argmin(1)
    A_tok=np.array([[pairings[c][0][0],pairings[c][0][1],pairings[c][1][0],pairings[c][1][1]] for c in ch])
    ta,tb,tc,td=[T[ar,A_tok[:,i]] for i in range(4)]
    AB=P[ta,tb]+P[tc,td]; Ai=aidx[ta,tb]; Bi=aidx[tc,td]; As=srt[ta,tb]; Bs=srt[tc,td]
    cost=np.zeros(N); done=np.zeros(N,bool); cum=pair_cost; rates=[]
    costs_stage=[24]+[10*(Ks[i]-Ks[i-1])+7 for i in range(1,len(Ks))]
    for i,K in enumerate(Ks):
        cum+=costs_stage[i]
        c=np.concatenate([Ai[:,:K],Bi[:,:K]],1)
        best=np.take_along_axis(AB,c,1).max(1); bs=As[:,K]+Bs[:,K]
        ok=(~done)&(best>bs); cost[ok]=cum; rates.append(round(ok.mean(),3)); done|=ok
    cost[~done]=cum+1+191
    return round(cost.mean(),2), rates
print('3 pairings', run(3,[2,4,6,8,10,13,17],16))
print('2 pairings', run(2,[2,4,6,8,10,13,17],10))
print('1 pairing ', run(1,[2,4,6,8,10,13,17],5))
print('2 pairings alt', run(2,[2,4,6,9,13,17],10), run(2,[3,5,7,10,13,17],10))
