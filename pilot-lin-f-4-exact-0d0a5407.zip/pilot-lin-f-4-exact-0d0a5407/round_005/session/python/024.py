
import json
for name in ['best','r5a']:
    e = entries[name]
    s = json.dumps(e)
    print(name, len(s), 'nodes:', len(e.get('nodes', e.get('ops', []))) if isinstance(e, dict) else type(e))
    print(measure(e))
e = entries['r5a']
print(list(e.keys()) if isinstance(e, dict) else None)
