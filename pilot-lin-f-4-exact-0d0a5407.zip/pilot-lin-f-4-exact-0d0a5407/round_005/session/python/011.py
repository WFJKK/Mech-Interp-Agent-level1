
e=entries['best']
nodes=e['nodes']
for i,n in enumerate(nodes[139:], start=139):
    print(i, {k:(v if k!='value' else (np.array(v).shape if isinstance(v,list) else v)) for k,v in n.items()})
