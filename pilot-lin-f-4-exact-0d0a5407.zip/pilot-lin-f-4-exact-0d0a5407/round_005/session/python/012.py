
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=30000
T=rng.integers(0,64,size=(N,4))
colidx=np.argsort(-W,axis=0)
h_top4 = np.bincount(colidx[:4].ravel(), minlength=64)
order=np.argsort(-(h_top4 + 1e-3*W.max(1)), kind='stable')
PH=np.zeros((64,64,64))
for a in range(64): PH[a]=(W[:,a][:,None]+W).T
LOG=np.stack([W[:,t].sum(1) for t in T])  # N x 64

def chunk_tables(c):
    sz=64//c
    chunks=[order[i*sz:(i+1)*sz] for i in range(c)]
    CO=[]; CV=[]
    for ch in chunks:
        v=PH[:,:,ch]; o=np.argsort(-v,axis=2,kind='stable')
        CO.append(ch[o]); CV.append(np.take_along_axis(v,o,axis=2))
    return CO,CV
def evaluate(c, sched, CO, CV, pairing_stage=0):
    # sched: list of tuples (k_1..k_c) cumulative per side
    # returns stage distribution and expected per-input cost
    ks=np.array(sched)
    # bound per side per stage: max_c CV[c][p][k_c]
    def side_bound(p, s):
        return max(CV[i][p][ks[s,i]] for i in range(c))
    res=np.zeros(len(sched)+1)
    for n,t in enumerate(T):
        opts=[]
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            p=(t[i],t[j]); q=(t[k],t[l])
            opts.append((side_bound(p,pairing_stage)+side_bound(q,pairing_stage),p,q))
        bd,p,q=min(opts,key=lambda o:o[0])
        lg=LOG[n]
        for s in range(len(sched)):
            cand=np.concatenate([CO[i][p][:ks[s,i]] for i in range(c)]+[CO[i][q][:ks[s,i]] for i in range(c)])
            if lg[cand].max() > side_bound(p,s)+side_bound(q,s):
                res[s]+=1; break
        else: res[-1]+=1
    res/=N
    # cost
    ncand=[2*ks[s].sum() for s in range(len(sched))]
    cost=[5*ncand[0]+3]
    for s in range(1,len(sched)): cost.append(cost[-1]+5*(ncand[s]-ncand[s-1])+7)
    cost.append(cost[-1]+191)
    return res, float(np.dot(res,cost))
CO1,CV1=chunk_tables(1)
base=[(2,),(4,),(6,),(8,),(10,),(13,),(17,)]
r,cst=evaluate(1,base,CO1,CV1); print('base',np.round(r,4),cst)
CO2,CV2=chunk_tables(2)
for sched in [[(2,0),(4,0),(5,1),(7,1),(9,1),(11,2),(14,3)],
              [(2,0),(3,1),(5,1),(7,1),(9,2),(12,2),(15,3)],
              [(1,1),(3,1),(5,1),(7,2),(9,2),(12,3),(15,4)],
              [(2,0),(4,1),(6,2),(8,3),(10,4),(13,5),(17,6)],
              [(2,0),(4,0),(6,0),(8,1),(10,1),(13,2),(17,3)]]:
    r,cst=evaluate(2,sched,CO2,CV2); print(sched, np.round(r,4), round(cst,1))
