
import json
e = entries['r5a']
nodes = e['nodes']
for i,n in enumerate(nodes[60:200]):
    i+=60
    d = {k:v for k,v in n.items() if k not in ('value',)}
    if d['op'] in ('slice','add') and i<74: continue
    print(i, json.dumps(d)[:150])
