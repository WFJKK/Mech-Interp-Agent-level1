
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E); UH=U@H
rng=np.random.default_rng(5)
N=40000
T=rng.integers(0,64,size=(N,4))
LOG=np.stack([W[:,t].sum(1) for t in T])
PH=np.zeros((64,64,64))
for a in range(64): PH[a]=(W[:,a][:,None]+W).T
SCHED=[2,4,6,8,10,13,17]
def tables(order, s):
    S=order[:s]; Wk=order[s:]
    v=PH[:,:,S]; o=np.argsort(-v,axis=2,kind='stable')
    CO=S[o]; CV=np.take_along_axis(v,o,axis=2)
    wm = PH[:,:,Wk].max(axis=2) if s<64 else np.full((64,64),-np.inf)
    return CO,CV,wm,Wk
def evaluate(CO,CV,wm,Wk,m):
    res=np.zeros(len(SCHED)+1)
    for n,t in enumerate(T):
        opts=[]
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            p=(t[i],t[j]); q=(t[k],t[l]); opts.append((max(CV[p][2],wm[p])+max(CV[q][2],wm[q]),p,q))
        bd,p,q=min(opts,key=lambda o:o[0]); lg=LOG[n]
        for s_,K in enumerate(SCHED):
            cand=np.concatenate([CO[p][:K],CO[q][:K]])
            if s_>=m:
                cand=np.concatenate([cand,Wk]); bd=CV[p][K]+CV[q][K]
            else:
                bd=max(CV[p][K],wm[p])+max(CV[q][K],wm[q])
            if lg[cand].max() > bd:
                res[s_]+=1; break
        else: res[-1]+=1
    res/=N
    nw=len(Wk)
    cost=[23]
    for s_ in range(1,len(SCHED)): cost.append(cost[-1]+10*(SCHED[s_]-SCHED[s_-1])+7 + (4*nw if s_==m else 0))
    cost.append(cost[-1]+191)
    return res, float(np.dot(res,cost))
cfull=45.91
top3=np.argsort(-PH.reshape(-1,64),axis=1)[:,:3]; true=np.bincount(top3.ravel(),minlength=64)
heur={'norm':np.linalg.norm(UH,axis=1),'rownormW':np.linalg.norm(W,axis=1),'true':true+1e-6*np.linalg.norm(W,axis=1),
      'top2max':np.sort(W,axis=1)[:,-2], 'meantop8':np.sort(W,axis=1)[:,-8:].mean(1)}
for name,h in heur.items():
    order=np.argsort(-h,kind='stable')
    print(name, 'weakest 8:', order[56:], 'their true strength', true[order[56:]])
    for s,ms in ((56,(3,4,5)),(52,(3,4))):
        tb=tables(order,s); saving=((64-s)*6-(64-s-1))*2080/16384
        for m in ms:
            r,c=evaluate(*tb,m); print('  ',s,'m',m,round(c,2),'net',round(saving-(c-cfull)-1-0.25-0.4,2))
