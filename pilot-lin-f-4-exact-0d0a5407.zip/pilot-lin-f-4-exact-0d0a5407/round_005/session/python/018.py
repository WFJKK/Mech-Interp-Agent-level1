
import numpy as np, inspect
print({k:(v.dtype, v.shape) for k,v in weights.items()})
print(inspect.getsource(lv1._norm)[:800] if hasattr(lv1,'_norm') else 'no _norm')
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E)
rng=np.random.default_rng(123)
X=rng.integers(0,64,size=(2000000,4))
L=W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]
S=np.sort(L,axis=0); gap=S[-1]-S[-2]
print('float64 min gaps', np.sort(gap)[:8], 'exact ties', int((gap==0).sum()))
# network-order computation
h=E[:,X[:,0]]+E[:,X[:,1]]+E[:,X[:,2]]+E[:,X[:,3]]
L2=U@(H@h)
S2=np.sort(L2,axis=0); gap2=S2[-1]-S2[-2]
print('network-order min gaps', np.sort(gap2)[:8], 'exact ties', int((gap2==0).sum()))
print('argmax disagreement between orders', int((L.argmax(0)!=L2.argmax(0)).sum()))
