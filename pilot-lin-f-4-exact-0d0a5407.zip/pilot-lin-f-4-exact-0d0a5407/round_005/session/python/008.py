
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(1)
N=40000
T=rng.integers(0,64,size=(N,4))
# precompute sorted pair tables
PH=np.zeros((64,64,64)); 
for a in range(64):
    PH[a]=(W[:,a][:,None]+W).T  # PH[a,b,:] = W[:,a]+W[:,b]
ORD=np.argsort(-PH,axis=2,kind='stable'); SVAL=np.take_along_axis(PH,ORD,axis=2)
def run(sched, orient='fixed', pairing='min3'):
    # sched: list of (ka,kb) cumulative; returns success distribution
    res=np.zeros(len(sched)+1)
    for t in T:
        opts=[]
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            p=(t[i],t[j]); q=(t[k],t[l])
            bd=SVAL[p][2]+SVAL[q][2]
            opts.append((bd,p,q))
        bd,p,q=min(opts,key=lambda o:o[0])
        if orient=='top1' and SVAL[q][0]>SVAL[p][0]: p,q=q,p
        if orient=='gap' and SVAL[q][0]-SVAL[q][1] > SVAL[p][0]-SVAL[p][1]: p,q=q,p
        logits=W[:,t].sum(1)
        for si,(ka,kb) in enumerate(sched):
            cand=np.concatenate([ORD[p][:ka],ORD[q][:kb]])
            if logits[cand].max() > SVAL[p][ka]+SVAL[q][kb]:
                res[si]+=1; break
        else: res[-1]+=1
    return res/N
base=[(2,2),(4,4),(6,6),(8,8),(10,10),(13,13),(17,17)]
print('base', np.round(run(base),4))
s1=[(1,0),(1,1),(2,2),(4,4),(6,6),(8,8),(10,10),(13,13),(17,17)]
print('s1 fixed', np.round(run(s1),4))
print('s1 top1', np.round(run(s1,'top1'),4))
print('s1 gap', np.round(run(s1,'gap'),4))
s2=[(1,1),(2,2),(4,4),(6,6),(8,8),(10,10),(13,13),(17,17)]
print('s2', np.round(run(s2),4))
