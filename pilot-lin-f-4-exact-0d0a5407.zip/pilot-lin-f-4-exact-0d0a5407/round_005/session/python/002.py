
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)   # 64x64, logit_j = sum_i W[j,t_i]
rng=np.random.default_rng(0)
N=100000
T=rng.integers(0,64,size=(N,4))
# column sorts
colidx = np.argsort(W, axis=0)  # ascending, per column: rows
def sim(m, dedupe=True, sched=(2,4,6,8,10,13,17)):
    # per pair (a,b) unordered; for sim just compute per input directly
    a17 = np.sort(W,axis=0)[64-m-1, :]  # (m+1)-th largest per column
    res = np.zeros(len(sched)+1)
    # for the 3 pairings pick min bound at K=2 (3rd largest within S vs weak)
    def pair_struct(a,b):
        Sa = colidx[64-m:, a]; Sb = colidx[64-m:, b]
        vals = np.concatenate([W[Sa,a]+W[Sa,b], W[Sb,a]+W[Sb,b]])
        rows = np.concatenate([Sa,Sb])
        if dedupe:
            dup = np.isin(Sb, Sa)
            vals[m:][dup] = -np.inf
        o = np.argsort(-vals, kind='stable')
        return rows[o], vals[o], a17[a]+a17[b]
    cnt=0
    for t in T[:20000]:
        best_b=None
        structs=[]
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            A=pair_struct(t[i],t[j]); B=pair_struct(t[k],t[l])
            bd = max(A[1][2],A[2]) + max(B[1][2],B[2])
            structs.append((bd,A,B))
        bd,A,B = min(structs, key=lambda s:s[0])
        logits = W[:,t].sum(1)
        true = logits.argmax()
        for si,K in enumerate(sched):
            cand = np.concatenate([A[0][:K],B[0][:K]])
            bestv = logits[cand].max()
            bound = max(A[1][K],A[2]) + max(B[1][K],B[2])
            if bestv > bound:
                res[si]+=1; break
        else:
            res[-1]+=1
    return res/20000
for m in (8,12,16,24):
    print(m, 'dedupe', sim(m,True))
print(16,'nodedupe', sim(16,False))
print(32, 'full', sim(32,False))
