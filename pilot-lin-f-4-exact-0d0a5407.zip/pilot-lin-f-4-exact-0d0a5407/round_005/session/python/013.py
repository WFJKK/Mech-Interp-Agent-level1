
import inspect
print(inspect.signature(lv1.Evaluator.__init__))
print([m for m in dir(lv1.Evaluator) if not m.startswith('_')])
print(inspect.signature(lv1.run_reference))
print(inspect.signature(lv1.Graph.load))
print(inspect.signature(lv1.take), inspect.signature(lv1.argsort), inspect.signature(lv1.cond), inspect.signature(lv1.concat))
src=inspect.getsource(lv1.Evaluator)
print(src[:3000])
