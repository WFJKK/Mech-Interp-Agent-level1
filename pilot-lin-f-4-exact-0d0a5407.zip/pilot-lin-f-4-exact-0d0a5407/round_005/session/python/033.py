
import json
e = entries['r5a']; nodes = e['nodes']
for i in [79,80,81,82,83,84,97,98,102,110]: print(i, json.dumps(nodes[i])[:200])
# users of nodes 79..96 outside that range
for i,n in enumerate(nodes):
    for a in n.get('args',[]):
        if 79<=a<=96 and not (79<=i<=96): print('user', i, n['op'], a)
print(nodes[380])
