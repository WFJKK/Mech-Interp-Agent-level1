
import numpy as np
SCHED=[2,4,6,8,10,13,17]
def build(sv_stages=(2,4,6), dedupe32=True, sched=SCHED):
    g=graph()
    Emb=g.weight("embed")[:, 0:64]
    Wm=g.weight("unembed") @ (g.weight("hidden") @ Emb)   # 64 rows x 64 tokens
    WT=Wm.T                                               # tokens x rows
    WW=lv1.concat([WT,WT],axis=0)
    Ph=lv1.concat([WT + WW[d:d+64] for d in range(33)],axis=0)   # 2112 x 64
    if dedupe32:
        idx=lv1.argsort(Ph[0:2080],axis=1)
        idx=lv1.concat([idx, idx[2048:2080]],axis=0)
    else:
        idx=lv1.argsort(Ph,axis=1)
    r=g.arange(64); col=r.reshape(64,1); row=r.reshape(1,64)
    c64=g.const(64); c32=g.const(32); c4096=g.const(4096)
    d=(row-col)%c64
    F=lv1.where(r<=c32, r*c64, c4096-r*c64)
    PI=lv1.take(F, d.reshape(4096),axis=0).reshape(64,64) + lv1.where(d<=c32, col, row)
    off=g.arange(2112)*c64
    Phf=Ph.reshape(135168)
    SV={}
    for K in sv_stages:
        SV[K]=lv1.take(Phf, off+idx[:,64-(K+1)],axis=0)
    KVt=lv1.take(SV[2], PI.reshape(4096),axis=0).reshape(64,64)
    # per input
    t0,t1,t2,t3=[g.token(i) for i in range(4)]
    b1=KVt[t0,t1]+KVt[t2,t3]
    b2=KVt[t0,t2]+KVt[t1,t3]
    b3=KVt[t0,t3]+KVt[t1,t2]
    c12=b1<=b2; m12=lv1.minimum(b1,b2)
    c3=b3<m12; bound1=lv1.minimum(b3,m12)
    s1=lv1.stack([t0,t1,t2,t3],axis=0); s2=lv1.stack([t0,t2,t1,t3],axis=0); s3=lv1.stack([t0,t3,t1,t2],axis=0)
    sel=lv1.cond(c3, s3, lv1.cond(c12, s1, s2))
    p=PI[sel[0],sel[1]]; q=PI[sel[2],sel[3]]
    def cand(rank):   # rank 1 = top
        colv=idx[:,64-rank]
        ja=colv[p]; va=Ph[p,ja]+Ph[q,ja]
        jb=colv[q]; vb=Ph[p,jb]+Ph[q,jb]
        return [ja,jb],[va,vb]
    # stage 1
    J=[];V=[]
    for rk in (1,2):
        j,v=cand(rk); J+=j; V+=v
    vals=lv1.stack(V,axis=0); inds=lv1.stack(J,axis=0)
    am=vals.argmax(); bestv=vals[am]; besti=inds[am]
    tests=[(bestv>bound1, besti)]
    prevK=2
    for K in sched[1:]:
        J=[];V=[]
        for rk in range(prevK+1,K+1):
            j,v=cand(rk); J+=j; V+=v
        vals=lv1.concat([bestv.reshape(1), lv1.stack(V,axis=0)],axis=0)
        inds=lv1.concat([besti.reshape(1), lv1.stack(J,axis=0)],axis=0)
        am=vals.argmax(); bestv=vals[am]; besti=inds[am]
        if K in SV:
            bd=SV[K][p]+SV[K][q]
        else:
            colv=idx[:,64-(K+1)]
            jb=colv[p]; jc=colv[q]
            bd=Ph[p,jb]+Ph[q,jc]
        tests.append((bestv>bd, besti))
        prevK=K
    fb=lv1.take_sum(Ph, lv1.stack([p,q],axis=0), axis=0).argmax()
    out=fb
    for c,i in reversed(tests):
        out=lv1.cond(c,i,out)
    return g.entry(interpretation=out)
e1=build()
print(len(e1['nodes']))
m=measure(e1); print(m)
save_entry('r5a', e1)
