
import numpy as np
E=weights['embed'][:, :64].astype(np.float64); H=weights['hidden'].astype(np.float64); U=weights['unembed'].astype(np.float64)
W = U @ (H @ E); UH=U@H
rng=np.random.default_rng(5)
N=40000
T=rng.integers(0,64,size=(N,4))
LOG=np.stack([W[:,t].sum(1) for t in T])
PH=np.zeros((64,64,64))
for a in range(64): PH[a]=(W[:,a][:,None]+W).T
SCHED=[2,4,6,8,10,13,17]
def tables(order, s):
    S=order[:s]; Wk=order[s:]
    v=PH[:,:,S]; o=np.argsort(-v,axis=2,kind='stable')
    CO=S[o]; CV=np.take_along_axis(v,o,axis=2)
    wm = PH[:,:,Wk].max(axis=2) if s<64 else np.full((64,64),-np.inf)
    # bounds per stage: max(CV[K], wm)
    B=np.stack([np.maximum(CV[:,:,K], wm) for K in SCHED],axis=2)
    return CO,B
def evaluate(CO,B):
    res=np.zeros(len(SCHED)+1)
    for n,t in enumerate(T):
        opts=[]
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            p=(t[i],t[j]); q=(t[k],t[l]); opts.append((B[p][0]+B[q][0],p,q))
        bd,p,q=min(opts,key=lambda o:o[0]); lg=LOG[n]
        for s_,K in enumerate(SCHED):
            cand=np.concatenate([CO[p][:K],CO[q][:K]])
            if lg[cand].max() > B[p][s_]+B[q][s_]:
                res[s_]+=1; break
        else: res[-1]+=1
    res/=N
    cost=[23]
    for s_ in range(1,len(SCHED)): cost.append(cost[-1]+10*(SCHED[s_]-SCHED[s_-1])+7)
    cost.append(cost[-1]+191)
    return res, float(np.dot(res,cost))
colidx=np.argsort(-W,axis=0)
heur={'top4':np.bincount(colidx[:4].ravel(),minlength=64)+1e-3*W.max(1),
      'max':W.max(1), 'norm':np.linalg.norm(UH,axis=1), 'top2':np.bincount(colidx[:2].ravel(),minlength=64)+1e-3*W.max(1),
      'top8':np.bincount(colidx[:8].ravel(),minlength=64)+1e-3*W.max(1)}
r,c=evaluate(*tables(np.arange(64),64)); print('full',np.round(r,4),round(c,2))
for name,h in heur.items():
    order=np.argsort(-h,kind='stable')
    for s in (56,60):
        r,c=evaluate(*tables(order,s)); print(name,s,np.round(r,4),round(c,2), 'build saving/input', round(((64-s)*6-(64-s-1))*2080/16384,2))
