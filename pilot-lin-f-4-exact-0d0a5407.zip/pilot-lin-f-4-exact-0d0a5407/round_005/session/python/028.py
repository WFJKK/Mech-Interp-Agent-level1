
import numpy as np, time
E = weights['embed'][:, :64]; W = weights['unembed'] @ (weights['hidden'] @ E)   # 64x64, W[j,t]
WT = W.T  # [t, j]
rng = np.random.default_rng(0)
N = 60000
T = rng.integers(0,64,(N,4))
# pair table: for pair (a,b): row = WT[a]+WT[b]
def pairvals(a,b): return WT[a]+WT[b]
pairings = [((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
sched = [2,4,6,8,10,13,17]
def simulate(D):
    # per pairing: bounds and availability
    bounds = []; avail = []
    for (i,j),(k,l) in pairings:
        A = pairvals(T[:,i],T[:,j]); B = pairvals(T[:,k],T[:,l])
        sA = np.sort(A,axis=1); sB = np.sort(B,axis=1)
        bounds.append(sA[:,-3]+sB[:,-3])
        d1 = np.minimum((T[:,i]-T[:,j])%64, (T[:,j]-T[:,i])%64)
        d2 = np.minimum((T[:,k]-T[:,l])%64, (T[:,l]-T[:,k])%64)
        avail.append((d1<=D)&(d2<=D))
    bounds = np.stack(bounds,1); avail = np.stack(avail,1)
    bb = np.where(avail, bounds, np.inf)
    choice = bb.argmin(1)
    none = ~avail.any(1)
    cost = np.full(N, 16.0)  # pairing choice
    cost[none] += 191
    idx = np.arange(N)
    rows = np.array(pairings)[choice]  # N,2,2
    A = pairvals(T[idx, rows[:,0,0]], T[idx, rows[:,0,1]]); B = pairvals(T[idx, rows[:,1,0]], T[idx, rows[:,1,1]])
    oA = np.argsort(-A,axis=1); oB = np.argsort(-B,axis=1)
    sA = -np.sort(-A,axis=1); sB = -np.sort(-B,axis=1)
    S = A+B
    unresolved = ~none
    prevK = 0
    for K in sched:
        cand = np.concatenate([oA[:,:K], oB[:,:K]],1)
        best = np.take_along_axis(S, cand, 1).max(1)
        bnd = sA[:,K]+sB[:,K]
        stage_cost = 10*K+4 if prevK==0 else 10*(K-prevK)+7
        cost[unresolved] += stage_cost
        ok = unresolved & (best > bnd)
        unresolved = unresolved & ~ok
        prevK = K
    cost[unresolved] += 191
    rows_sorted = (D+1)*64 if D<32 else 2080
    build = rows_sorted*384 + 2080*64/ (1) * 0  # argsort only; other build parts ~ constant
    return cost.mean(), none.mean(), unresolved.mean(), build/16384
for D in [32,28,24,20,16,12]:
    print(D, simulate(D))
