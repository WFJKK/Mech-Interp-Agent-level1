
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
for n in ['Evaluator','run_reference','evaluate','run_entry']:
    if hasattr(lv1,n):
        o=getattr(lv1,n)
        try: print(n, inspect.signature(o))
        except Exception as ex: print(n, ex)
        if inspect.isclass(o):
            for m in ['__init__','run','__call__','evaluate']:
                if hasattr(o,m):
                    try: print('  ',m, inspect.signature(getattr(o,m)))
                    except Exception as ex: print(' ',m,ex)
