
import json, copy, numpy as np
print([k for k in lv1.ELEMENTWISE_2] if hasattr(lv1,'ELEMENTWISE_2') else None)
e = entries['r5b']; nodes = e['nodes']
for i in [72,73,74,75,76,77,78,97,99,100,101,102]: print(i, json.dumps(nodes[i])[:120])
S=79
for i in range(S, S+20): print(i, json.dumps(nodes[i])[:100])
