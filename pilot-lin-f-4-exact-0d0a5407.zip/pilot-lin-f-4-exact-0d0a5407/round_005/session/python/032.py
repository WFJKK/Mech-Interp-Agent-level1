
import numpy as np
def ref_out(w, T):
    outs=[]
    for t in T:
        h = w['embed'][:, t].sum(axis=1)
        logits = w['unembed'] @ (w['hidden'] @ h)
        outs.append(int(np.argmax(logits)))
    return np.array(outs)
def check(entry, w, n, seed, name, T=None):
    rng = np.random.default_rng(seed)
    if T is None: T = rng.integers(0,64,(n,4))
    ev = lv1.Evaluator(entry, w, 4)
    r = ref_out(w,T); mism=0; ops=0
    for i,t in enumerate(T):
        res = ev.run(list(map(int,t)))
        ops += res[3]
        if int(res[1]) != r[i]: mism+=1
    print(name, 'n',len(T),'mismatch',mism, 'mean ops', ops/len(T))
e = entries['r5a']
rng = np.random.default_rng(5)
for s in range(3):
    w2 = {k: rng.normal(size=v.shape)*(0.1*(s+1)) for k,v in weights.items()}
    w2['embed'][:, 64] = 0
    check(e, w2, 1500, s, f'gauss{s}')
check(e, weights, 2000, 99, 'own')
Td = np.array([[a,a,a,a] for a in range(64)] + [[a,b,a,b] for a in range(0,64,3) for b in range(0,64,5)] + [[a,(a+32)%64,b,(b+32)%64] for a in range(16) for b in range(0,64,4)])
check(e, weights, 0, 0, 'degenerate', T=Td)
w3 = {k: v.copy() for k,v in weights.items()}
u = rng.normal(size=(8,1)); w3['hidden'] = u @ rng.normal(size=(1,8)) + 1e-3*rng.normal(size=(8,8))
check(e, w3, 1500, 7, 'rank1')
