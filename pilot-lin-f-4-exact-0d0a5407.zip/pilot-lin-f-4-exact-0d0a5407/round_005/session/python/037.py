
import json, copy, numpy as np
e = entries['r5b']; nodes = e['nodes']
items = []  # (key, dict) ; args reference keys
for i,n in enumerate(nodes):
    items.append((i, copy.deepcopy(n)))
def find(key): return next(k for k,(kk,_) in enumerate(items) if kk==key)
# 1. insert slice(6, 0:32) before 73; 72 -> 32:64 ; 73 = add(new, 72)
items[find(72)][1]['index'] = [{"start":32,"step":None,"stop":64}]
items.insert(find(73), ('sl6', {"args":[6], "index":[{"start":0,"step":None,"stop":32}], "op":"slice"}))
items[find(73)][1]['args'] = ['sl6', 72]
# 2. drop 75, 77, 78 ; 76 = argsort(74); uses of 78 -> 76
items[find(76)][1]['args'] = [74]
alias = {75:74, 78:76}
for k in [75,77,78]: del items[find(k)]
# 3. arange 2112 -> 2080, reshape 135168 -> 133120
items[find(99)][1]['n'] = 2080
items[find(101)][1]['shape'] = [133120]
# 4. H mask: (d<=32) & (e != 32): insert after 85
pos = find(85)
items.insert(pos+1, ('ne32', {"args":[83, 82], "op":"ne"}))
items.insert(pos+2, ('mask', {"args":[85, 'ne32'], "op":"and"}))
items[find(91)][1]['args'] = ['mask', 86, 90]
# renumber
keymap = {}
for newi,(k,_) in enumerate(items): keymap[k]=newi
def mp(a):
    a = alias.get(a, a)
    return keymap[a]
nodes3=[]
for k,n in items:
    m = copy.deepcopy(n)
    if 'args' in m: m['args'] = [mp(a) for a in m['args']]
    nodes3.append(m)
e3 = {"format":e['format'], "nodes":nodes3, "predict":mp(e['predict']), "rule":None}
print(len(nodes3), e3['predict'])
g, interp, region = lv1.Graph.load(e3, weights, 4)
m = measure(e3); print({k:m[k] for k in ['n_agree','build_ops','predict_ops','cost','reward']})
# compare vs r5b on exhaustive pair grid incl. d=32 cases
ev1 = lv1.Evaluator(e, weights, 4); ev2 = lv1.Evaluator(e3, weights, 4)
diff=0; ops1=0; ops2=0
for a in range(64):
    for b in range(64):
        for x in ([a,b,(a*7+3)%64,(b*5+11)%64], [a,(a+32)%64,b,(b+32)%64]):
            r1=ev1.run(x); r2=ev2.run(x); ops1+=r1[3]; ops2+=r2[3]
            if r1[1]!=r2[1]: diff+=1
print('grid diff', diff, ops1/8192, ops2/8192)
save_entry('r5c', e3)
