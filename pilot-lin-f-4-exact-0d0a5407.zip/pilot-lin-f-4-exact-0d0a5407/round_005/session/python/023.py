
import numpy as np
SCHED=[2,4,6,8,10,13,17]
def build2(s=56, m=3, sv_stages=(2,4,6), sched=SCHED):
    nw=64-s
    g=graph()
    Emb=g.weight("embed")[:, 0:64]
    Hd=g.weight("hidden"); Un=g.weight("unembed")
    UH=Un @ Hd                                    # 64 x 8
    sq=(UH*UH).sum(axis=1)                        # 64
    perm=lv1.argsort(0.0-sq, axis=0)              # strongest first
    Wm=Un @ (Hd @ Emb)                            # 64 rows x 64 tokens
    WT=Wm.T                                       # tokens x rows (original order)
    WTp=lv1.take(WT, perm, axis=1)                # tokens x rows (permuted)
    WW=lv1.concat([WTp,WTp],axis=0)
    Ph=lv1.concat([WTp + WW[d:d+64] for d in range(33)],axis=0)   # 2112 x 64 (cols permuted)
    idx=lv1.argsort(Ph[0:2080, 0:s],axis=1)       # 2080 x s, ascending
    idx=lv1.concat([idx, idx[2048:2080]],axis=0)  # 2112 x s
    wm=Ph[:, s:64].max(axis=1)                    # 2112
    r=g.arange(64); col=r.reshape(64,1); row=r.reshape(1,64)
    c64=g.const(64); c32=g.const(32); c4096=g.const(4096)
    d=(row-col)%c64
    F=lv1.where(r<=c32, r*c64, c4096-r*c64)
    PI=lv1.take(F, d.reshape(4096),axis=0).reshape(64,64) + lv1.where(d<=c32, col, row)
    off=g.arange(2112)*c64
    Phf=Ph.reshape(135168)
    SV={}
    for K in sv_stages:
        SV[K]=lv1.maximum(lv1.take(Phf, off+idx[:,s-(K+1)],axis=0), wm)
    KVt=lv1.take(SV[2], PI.reshape(4096),axis=0).reshape(64,64)
    widx=g.arange(nw)+g.const(s)
    PhW=Ph[:, s:64]
    # per input
    t0,t1,t2,t3=[g.token(i) for i in range(4)]
    b1=KVt[t0,t1]+KVt[t2,t3]
    b2=KVt[t0,t2]+KVt[t1,t3]
    b3=KVt[t0,t3]+KVt[t1,t2]
    c12=b1<=b2; m12=lv1.minimum(b1,b2)
    c3=b3<m12; bound1=lv1.minimum(b3,m12)
    s1=lv1.stack([t0,t1,t2,t3],axis=0); s2=lv1.stack([t0,t2,t1,t3],axis=0); s3=lv1.stack([t0,t3,t1,t2],axis=0)
    sel=lv1.cond(c3, s3, lv1.cond(c12, s1, s2))
    p=PI[sel[0],sel[1]]; q=PI[sel[2],sel[3]]
    def cand(rank):
        colv=idx[:,s-rank]
        ja=colv[p]; va=Ph[p,ja]+Ph[q,ja]
        jb=colv[q]; vb=Ph[p,jb]+Ph[q,jb]
        return [ja,jb],[va,vb]
    J=[];V=[]
    for rk in (1,2):
        j,v=cand(rk); J+=j; V+=v
    vals=lv1.stack(V,axis=0); inds=lv1.stack(J,axis=0)
    am=vals.argmax(); bestv=vals[am]; besti=inds[am]
    tests=[(bestv>bound1, besti)]
    prevK=2
    for si,K in enumerate(sched[1:], start=1):
        J=[];V=[]
        for rk in range(prevK+1,K+1):
            j,v=cand(rk); J+=j; V+=v
        vparts=[bestv.reshape(1), lv1.stack(V,axis=0)]; iparts=[besti.reshape(1), lv1.stack(J,axis=0)]
        if si==m:
            vparts.append(PhW[p]+PhW[q]); iparts.append(widx)
        vals=lv1.concat(vparts,axis=0); inds=lv1.concat(iparts,axis=0)
        am=vals.argmax(); bestv=vals[am]; besti=inds[am]
        if si<m:
            assert K in SV
            bd=SV[K][p]+SV[K][q]
        else:
            colv=idx[:,s-(K+1)]
            bd=Ph[p,colv[p]]+Ph[q,colv[q]]
        tests.append((bestv>bd, besti))
        prevK=K
    out=g.const(-1)
    for c,i in reversed(tests):
        out=lv1.cond(c,i,out)
    # map back; fallback in original row order (tie-exact)
    fb=lv1.take_sum(WT, g.tokens(), axis=0).argmax()
    ans=lv1.cond(out>=g.const(0), perm[out], fb)
    return g.entry(interpretation=ans)
e2=build2(56,3)
print(len(e2['nodes']))
mm=measure(e2); print(mm)
save_entry('r5b', e2)
