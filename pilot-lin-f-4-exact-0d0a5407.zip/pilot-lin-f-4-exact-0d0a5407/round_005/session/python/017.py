
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(123)
X=rng.integers(0,64,size=(300000,4))
L=W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]   # 64 x N
S=np.sort(L,axis=0); gap=S[-1]-S[-2]
sel=np.argsort(gap)[:600]
print('min gaps', gap[sel][:5])
e1=entries['r5a']
g=graph(); REF=g.entry(interpretation=model.reference(g,lv1))
ev=lv1.Evaluator(e1, weights, 4)
preds=np.array([ev.run(x)[1] for x in X[sel]])
ans,_=lv1.run_reference(REF, weights, 4, X[sel])
print('near-tie mismatches', int((preds!=ans).sum()))
