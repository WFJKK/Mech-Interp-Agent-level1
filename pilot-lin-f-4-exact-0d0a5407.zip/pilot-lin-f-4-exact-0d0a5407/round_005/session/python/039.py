
save_entry('best', entries['r5c'])
print(measure(entries['r5c'])['reward'])
