
e=entries['best']
nodes=e['nodes']
print(e['format'], e['predict'], e['rule'])
print(nodes[0])
import collections
for i,n in enumerate(nodes[:140]):
    print(i, {k:(v if k!='value' else (np.array(v).shape if isinstance(v,list) else v)) for k,v in n.items()})
