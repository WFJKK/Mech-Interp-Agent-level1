
import numpy as np
def ref_out(w, T):
    outs=[]
    for t in T:
        h = w['embed'][:, t].sum(axis=1)
        outs.append(int(np.argmax(w['unembed'] @ (w['hidden'] @ h))))
    return np.array(outs)
def check(entry, w, n, seed, name, T=None):
    rng = np.random.default_rng(seed)
    if T is None: T = rng.integers(0,64,(n,4))
    ev = lv1.Evaluator(entry, w, 4)
    r = ref_out(w,T); mism=0; ops=0
    for i,t in enumerate(T):
        res = ev.run(list(map(int,t))); ops += res[3]
        if int(res[1]) != r[i]: mism+=1
    print(name, 'n',len(T),'mismatch',mism, 'mean ops', round(ops/len(T),2))
e = entries['r5c']
rng = np.random.default_rng(31)
for s in range(3):
    w2 = {k: rng.normal(size=v.shape)*(0.05*(s+1)) for k,v in weights.items()}
    w2['embed'][:, 64] = 0
    check(e, w2, 1500, s+40, f'gauss{s}')
check(e, weights, 2000, 321, 'own')
Td = np.array([[a,a,a,a] for a in range(64)] + [[a,b,a,b] for a in range(0,64,3) for b in range(0,64,5)] + [[a,(a+32)%64,b,(b+32)%64] for a in range(64) for b in range(0,64,4)] + [[(a+32)%64,a,a,(a+32)%64] for a in range(64)])
check(e, weights, 0, 0, 'degenerate', T=Td)
w3 = {k: v.copy() for k,v in weights.items()}
u = rng.normal(size=(8,1)); w3['hidden'] = u @ rng.normal(size=(1,8)) + 1e-3*rng.normal(size=(8,8))
check(e, w3, 1500, 7, 'rank1')
w4 = {k: v[::-1].copy() if k!='embed' else v[:, list(range(63,-1,-1))+[64]].copy() for k,v in weights.items()}
check(e, w4, 1500, 8, 'permuted')
w5 = {k: v*3.0 for k,v in weights.items()}; check(e, w5, 1000, 9, 'scaled')
