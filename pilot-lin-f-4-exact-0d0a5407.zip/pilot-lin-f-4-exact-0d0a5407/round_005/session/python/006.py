
import numpy as np, itertools
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E); UH = U@H
rng=np.random.default_rng(0)
T=rng.integers(0,64,size=(20000,4))
pairs=[(a,b) for a in range(64) for b in range(a,64)]
PH=np.array([W[:,a]+W[:,b] for a,b in pairs])  # 2080 x 64
top3 = np.argsort(-PH,axis=1)[:,:3]
true_strength = np.bincount(top3.ravel(), minlength=64)
h_max = W.max(1); h_norm=np.linalg.norm(UH,axis=1); h_sum=W.sum(1)
colidx=np.argsort(-W,axis=0)
h_top4 = np.bincount(colidx[:4].ravel(), minlength=64); h_top2=np.bincount(colidx[:2].ravel(), minlength=64)
h_top8 = np.bincount(colidx[:8].ravel(), minlength=64)
for name,h in [('max',h_max),('norm',h_norm),('sum',h_sum),('top2',h_top2),('top4',h_top4),('top8',h_top8)]:
    order=np.argsort(-h, kind='stable')
    # how much of true strength mass lies in the top 16 / 32 by this heuristic
    ts=true_strength[order]
    print(name, ts[:16].sum()/ts.sum(), ts[:32].sum()/ts.sum(), ts[:48].sum()/ts.sum())
print('true', np.sort(true_strength)[::-1])
