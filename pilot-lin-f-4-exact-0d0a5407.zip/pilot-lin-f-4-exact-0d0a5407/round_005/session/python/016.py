
import numpy as np, time
e1=entries['r5a']
def ref_entry():
    g=graph(); return g.entry(interpretation=model.reference(g,lv1))
REF=ref_entry()
def check(wts, inputs, name):
    t=time.time()
    ev=lv1.Evaluator(e1, wts, 4)
    preds=[ev.run(x)[1] for x in inputs]
    ans,_=lv1.run_reference(REF, wts, 4, inputs)
    bad=int((np.array(preds)!=ans).sum())
    print(name, 'n',len(inputs),'mismatch',bad, 'build',ev.build_cost, '%.1fs'%(time.time()-t))
    return bad
rng=np.random.default_rng(7)
X=rng.integers(0,64,size=(1500,4))
tot=0
tot+=check(weights, X, 'own')
for seed,scale in [(1,1.0),(2,0.01),(3,10.0),(4,1.0)]:
    r=np.random.default_rng(seed)
    wts={'embed':np.concatenate([r.normal(size=(8,64))*scale, np.zeros((8,1))],axis=1),
         'hidden':r.normal(size=(8,8)), 'unembed':r.normal(size=(64,8))}
    tot+=check(wts, X[:800], f'gauss{seed}_{scale}')
# near rank-1 hidden
r=np.random.default_rng(11)
u=r.normal(size=(8,1)); v=r.normal(size=(1,8))
wts={'embed':np.concatenate([r.normal(size=(8,64)), np.zeros((8,1))],axis=1),'hidden':u@v+1e-6*r.normal(size=(8,8)),'unembed':r.normal(size=(64,8))}
tot+=check(wts, X[:800], 'rank1')
# degenerate inputs on own weights
D=np.array([[a,a,a,a] for a in range(64)]+[[a,b,a,b] for a in range(0,64,5) for b in range(0,64,7)]+[[a,b,b,a] for a in range(0,64,9) for b in range(0,64,3)])
tot+=check(weights, D, 'degenerate')
print('total mismatches', tot)
