
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
colidx=np.argsort(-W,axis=0); Ws=-np.sort(-W,axis=0)
for m in (12,16,20,24):
    cnt=0; capt=[]
    for a in range(64):
        for b in range(a,64):
            v=W[:,a]+W[:,b]
            S=np.unique(np.concatenate([colidx[:m,a],colidx[:m,b]]))
            sv=np.sort(v[S])[::-1]
            weak=Ws[m,a]+Ws[m,b]
            top18=set(np.argsort(-v)[:18])
            capt.append(len(top18 & set(S)))
            if len(sv)>=18 and sv[17]>=weak: cnt+=1
    print(m, 'pairs exact-complete', cnt/2080, 'mean captured of top18', np.mean(capt), 'min', np.min(capt))
