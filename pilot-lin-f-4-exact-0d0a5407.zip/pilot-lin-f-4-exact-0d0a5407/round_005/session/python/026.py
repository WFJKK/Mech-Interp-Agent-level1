
import json
e = entries['r5a']
nodes = e['nodes']
for i,n in enumerate(nodes[:60]):
    d = {k:v for k,v in n.items() if k not in ('value',)}
    print(i, json.dumps(d)[:200])
