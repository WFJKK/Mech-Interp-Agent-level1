
import json, copy, numpy as np
e = entries['r5a']; nodes = e['nodes']
S=79
new = [
 {"n":64,"op":"arange"},
 {"args":[S+0],"op":"reshape","shape":[64,1]},
 {"dtype":"int","op":"const","value":64},
 {"dtype":"int","op":"const","value":32},
 {"n":128,"op":"arange"},
 {"args":[S+4,S+2],"op":"mod"},
 {"args":[S+5,S+3],"op":"le"},
 {"args":[S+5,S+2],"op":"mul"},
 {"args":[S+2,S+5],"op":"sub"},
 {"args":[S+8,S+2],"op":"mul"},
 {"args":[S+4,S+2],"op":"sub"},
 {"args":[S+9,S+10],"op":"add"},
 {"args":[S+6,S+7,S+11],"op":"where"},
 {"args":[S+0,S+2],"op":"add"},
 {"args":[S+13],"op":"reshape","shape":[1,64]},
 {"args":[S+14,S+1],"op":"sub"},
 {"args":[S+15],"op":"reshape","shape":[4096]},
 {"args":[S+12,S+16],"axis":0,"op":"take"},
 {"args":[S+17],"op":"reshape","shape":[64,64]},
 {"args":[S+18,S+1],"op":"add"},
]
def remap(i):
    if i<79: return i
    if i==82: return S+2
    if i==83: return S+3
    if i==96: return S+19
    if i>96: return i+2
    raise ValueError(i)
out=[]
for i,n in enumerate(nodes):
    if 79<=i<=96: continue
    m = copy.deepcopy(n)
    if 'args' in m: m['args']=[remap(a) for a in m['args']]
    out.append((i,m))
nodes2 = nodes[:79] + new + [m for i,m in out if i>96]
e2 = {"format":e['format'], "nodes":nodes2, "predict":remap(e['predict']), "rule":None}
print(len(nodes2))
g, interp, region = lv1.Graph.load(e2, weights, 4)
# compare PI table: old node 96 vs new node 98
g1,_,_ = lv1.Graph.load(e, weights, 4)
# find values via evaluator? use Expr value if available
try:
    print(np.array_equal(np.asarray(g.nodes[S+19].value), np.asarray(g1.nodes[96].value)))
except Exception as ex:
    print('no direct value', ex)
m = measure(e2); print({k:m[k] for k in ['n_agree','build_ops','predict_ops','cost','reward']})
save_entry('r5b', e2)
