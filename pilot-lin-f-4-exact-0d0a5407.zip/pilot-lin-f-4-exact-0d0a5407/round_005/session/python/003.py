
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(0)
N=20000
T=rng.integers(0,64,size=(N,4))
colidx = np.argsort(W, axis=0)
Wsorted=np.sort(W,axis=0)
def sim(m, dedupe=True, sched=(2,4,6,8,10,13,17)):
    sched=[K for K in sched if K < 2*m]
    a17 = Wsorted[64-m-1, :]
    res = np.zeros(len(sched)+1)
    cache={}
    def pair_struct(a,b):
        key=(min(a,b),max(a,b))
        if key in cache: return cache[key]
        Sa = colidx[64-m:, a]; Sb = colidx[64-m:, b]
        vals = np.concatenate([W[Sa,a]+W[Sa,b], W[Sb,a]+W[Sb,b]])
        rows = np.concatenate([Sa,Sb])
        if dedupe:
            dup = np.isin(Sb, Sa)
            vals[m:][dup] = -np.inf
        o = np.argsort(-vals, kind='stable')
        r=(rows[o], vals[o], a17[a]+a17[b]); cache[key]=r; return r
    for t in T:
        structs=[]
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            A=pair_struct(t[i],t[j]); B=pair_struct(t[k],t[l])
            bd = max(A[1][2],A[2]) + max(B[1][2],B[2])
            structs.append((bd,A,B))
        bd,A,B = min(structs, key=lambda s:s[0])
        logits = W[:,t].sum(1)
        for si,K in enumerate(sched):
            cand = np.concatenate([A[0][:K],B[0][:K]])
            bestv = logits[cand].max()
            bound = max(A[1][K],A[2]) + max(B[1][K],B[2])
            if bestv > bound:
                res[si]+=1; break
        else:
            res[-1]+=1
    return sched, res/N
for m in (8,12,16,24):
    print(m, 'dedupe', sim(m,True))
print(16,'nodedupe', sim(16,False))
print(32, 'full', sim(32,False))
