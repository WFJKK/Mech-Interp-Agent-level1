
import inspect, json
print(info)
print([n for n in dir(lv1) if not n.startswith('_')])
e = entries['best']
print(type(e), list(e.keys()) if isinstance(e, dict) else None)
print(len(e['nodes']) if 'nodes' in e else None)
print(measure(e))
