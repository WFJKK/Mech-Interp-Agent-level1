
import numpy as np, time
def ref_out(w, T):
    E = w['embed'][:, :64]; W = w['unembed'] @ (w['hidden'] @ E)
    # replicate reference exactly: sum of embed columns then hidden then unembed
    outs=[]
    for t in T:
        h = w['embed'][:, t].sum(axis=1)  # note: take_sum order
        logits = w['unembed'] @ (w['hidden'] @ h)
        outs.append(int(np.argmax(logits)))
    return np.array(outs)
def check(entry, w, n, seed, name):
    rng = np.random.default_rng(seed)
    T = rng.integers(0,64,(n,4))
    ev = lv1.Evaluator(entry, w, 4)
    t0=time.time()
    mism=0
    r = ref_out(w,T)
    for i,t in enumerate(T):
        res = ev.run(list(map(int,t)))
        pred = res[0] if isinstance(res,tuple) else res
        try: pv = int(pred)
        except Exception: pv = int(pred[0])
        if pv != r[i]: mism+=1
    print(name, 'n',n,'mismatch',mism, 'time',round(time.time()-t0,1))
e = entries['r5a']
ev = lv1.Evaluator(e, weights, 4)
print(ev.run([1,2,3,4]))
rng = np.random.default_rng(5)
for s in range(3):
    w2 = {k: rng.normal(size=v.shape)*(0.1*(s+1)) for k,v in weights.items()}
    w2['embed'][:, 64] = 0
    check(e, w2, 1500, s, f'gauss{s}')
check(e, weights, 1500, 99, 'own')
