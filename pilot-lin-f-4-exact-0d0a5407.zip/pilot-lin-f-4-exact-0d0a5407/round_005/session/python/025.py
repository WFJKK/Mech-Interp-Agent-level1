
e = entries['r5a']
nodes = e['nodes']
print(e['format'], e['predict'], e['rule'])
from collections import Counter
print(Counter(n.get('op') for n in nodes))
for i,n in enumerate(nodes[:140]):
    d = {k:v for k,v in n.items() if k not in ('value',)}
    s = json.dumps(d)
    print(i, s[:160])
