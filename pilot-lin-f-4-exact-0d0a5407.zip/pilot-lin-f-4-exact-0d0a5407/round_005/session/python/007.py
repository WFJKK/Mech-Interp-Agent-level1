
import numpy as np
E=weights['embed'][:, :64]; H=weights['hidden']; U=weights['unembed']
W = U @ (H @ E)
rng=np.random.default_rng(0)
T=rng.integers(0,64,size=(20000,4))
colidx=np.argsort(-W,axis=0)
h_top4 = np.bincount(colidx[:4].ravel(), minlength=64)
order=np.argsort(-(h_top4 + 1e-3*W.max(1)), kind='stable')  # strong first
def structs_for(mode, s=32):
    # returns function pair -> (rows_sorted(desc), vals_sorted, L)
    cache={}
    def f(a,b):
        key=(min(a,b),max(a,b))
        if key in cache: return cache[key]
        v = W[:,a]+W[:,b]
        if mode=='full':
            o=np.argsort(-v,kind='stable'); r=(o, v[o], -np.inf)
        elif mode=='tier':
            S=order[:s]; Wk=order[s:]
            o=np.argsort(-v[S],kind='stable'); r=(S[o], v[S][o], v[Wk].max())
        elif mode=='match':
            S=order[:32]; Wk=order[32:][::-1]  # strongest matched with weakest? try both
            c = v[S] >= v[Wk]
            win = np.where(c, S, Wk); lose=np.where(c, Wk, S)
            o=np.argsort(-v[win],kind='stable'); r=(win[o], v[win][o], v[lose].max())
        elif mode=='match2':
            S=order[:32]; Wk=order[32:]
            c = v[S] >= v[Wk]
            win = np.where(c, S, Wk); lose=np.where(c, Wk, S)
            o=np.argsort(-v[win],kind='stable'); r=(win[o], v[win][o], v[lose].max())
        elif mode=='hyb16':  # 16 unmatched strongest, 16 matches among rest paired strong-weak, sorted 32
            S0=order[:16]; S=order[16:32]; Wk=order[32:48]; rest=order[48:]
            # 3-way groups? keep: match S with Wk, rest 16 bounded by max -> L = max(losers, rest)
            c = v[S] >= v[Wk]
            win=np.concatenate([S0, np.where(c,S,Wk)]); lose=np.concatenate([np.where(c,Wk,S), rest])
            o=np.argsort(-v[win],kind='stable'); r=(win[o], v[win][o], v[lose].max())
        cache[key]=r; return r
    return f
def sim(f, sched=(2,4,6,8,10,13,17), N=20000):
    res=np.zeros(len(sched)+1)
    for t in T[:N]:
        best=None
        for (i,j,k,l) in [(0,1,2,3),(0,2,1,3),(0,3,1,2)]:
            A=f(t[i],t[j]); B=f(t[k],t[l])
            bd = max(A[1][2],A[2]) + max(B[1][2],B[2])
            if best is None or bd<best[0]: best=(bd,A,B)
        bd,A,B=best
        logits=W[:,t].sum(1)
        for si,K in enumerate(sched):
            cand=np.concatenate([A[0][:K],B[0][:K]])
            if logits[cand].max() > max(A[1][K],A[2])+max(B[1][K],B[2]):
                res[si]+=1; break
        else: res[-1]+=1
    return res/N
def cost(res, sched=(2,4,6,8,10,13,17)):
    c=[24]; 
    for i in range(1,len(sched)): c.append(c[-1]+10*(sched[i]-sched[i-1])+7)
    c.append(c[-1]+191)
    return float(np.dot(res,c))
for mode,s in [('full',0),('tier',32),('tier',40),('tier',48),('match',0),('match2',0),('hyb16',0)]:
    r=sim(structs_for(mode,s)); print(mode,s, np.round(r,4), 'per-input', round(cost(r),1))
