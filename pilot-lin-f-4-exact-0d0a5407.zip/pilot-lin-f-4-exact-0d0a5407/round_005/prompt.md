# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 5 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx slots. A slot holds a token, a whole number from 0 to d_vocab - 1, or it is empty,
which is written as the number d_vocab. An input has at least one token; its tokens fill the first
slots and the empty slots come after them.

The network has three weight matrices and no biases:

    embed     d_model x (d_vocab + 1)    its last column, the empty slot's, is all zeros
    hidden    d_model x d_model
    unembed   d_vocab x d_model

It adds up the columns of embed at the input's slots (an empty slot adds nothing), applies hidden,
applies unembed, and its output is the position of the highest of the d_vocab resulting numbers
(the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    h = lv1.take_sum(g.weight("embed"), g.tokens(), axis=1)
    logits = g.weight("unembed") @ (g.weight("hidden") @ h)
    return logits.argmax()
```

Sizes: n_ctx = 4, d_vocab = 64, d_model = 8, outputs: 64. One forward pass of the network costs 671 operations under the prices
below.

## The data set

An input is drawn like this. Four tokens are picked, each a whole number from 0 to 63 and equally likely, and they fill the four slots, so no slot is empty. The data set is every input that can be drawn this way, each as likely as any other: 64^4 = 16,777,216 different inputs.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

This run asks one more thing of an entry: that it be exact whatever the weights. When the rounds are
over, the entries are also run, unchanged, on several other networks of the same definition and sizes,
with other weights, and an entry counts only if it gives each network's output on every input of its
region that is checked there. So whatever depends on the weights has to be computed from the weights
inside the entry, and every shortcut has to hold for any weights: a rule that holds only for this
network makes the entry fail on the others.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.7438 | 1.0000 | 1.00000 | 0.2539 | 1.00000 | 1.00000 |
| r1s2 | scored | 0.7767 | 1.0000 | 1.00000 | 0.2209 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The network is purely linear before the argmax: `logits = unembed @ hidden @ (sum of embed columns at the 4 tokens)`, so `logit_j = Σ_i W[j, t_i]` with `W = unembed·hidden·embed[:, :64]` (64×64), and the output is `argmax_j` of that. Its outputs match no simple token rule I tested (max, min, mode, sum mod 64, mean, xor/and/or, individual positions all ≈ 1/64 agreement), the output distribution is very uneven (53 of 64 classes appear in a 16k sample; rows 19, 48, 25 take ~25%), and `unembed·hidden` has one near-zero singular value. I did not identify a human task; the interpretation is the exact weight-derived linear rule, which holds for any weights (fidelity 1.0 measured on 16,384 verifier inputs, plus ~30k inputs on random/permuted/rescaled weights and 805 targeted near-tie inputs, all exact).
    
    ## How you found it
    
    Read the model definition (sum of embeddings → two linear maps → argmax), checked the sampled outputs against simple token-rule hypotheses (all failed), verified that `argmax_j Σ_i W[j,t_i]` reproduces every output, then worked purely on making that exact rule cheap. Read the `lv1` source for exact prices (argsort = n·ceil(log2 n) per vector, take/gather = 1 per entry read, cond charges only the chosen branch, build amortised over the 16,384 sampled inputs). Simulated in numpy the success rate of candidate/bound schemes (fixed candidate sets, single-token top-K, grouped sorts, pair top-K, one-sided vs two-sided, choice among the 3 pairings) before building entries, and tuned stage schedules with `measure`.
    
    ## The best entry
    
    `st6_2_4_6_9_12_16` (reward 0.7767 when submitted; cost 0.221, coverage 1, fidelity 1). Region: every input. Interpretation (branch-and-bound over an exact pair table):
    - Build (≈1.107M ops, b≈0.10): `W = unembed·(hidden·embed[:, :64])`; pair table `Ph[(a,d)] = W[:,a] + W[:,(a+d)%64]` for d=0..32 (2112 unordered pairs, built with free slices/concat so only adds are paid); `PI[t1,t2]` → pair index; `idx = argsort(Ph, axis=1)` (811k ops, the main build cost); `SV` = top-16 values per pair; `KV_K` = (K+1)-th largest value per pair for K in the schedule.
    - Per input (≈80 ops): for the 3 pairings {(t1,t2),(t3,t4)}, {(t1,t3),(t2,t4)}, {(t1,t4),(t2,t3)} read the K=2 bound `KV_2[p] + KV_2[q]` and pick the pairing with the smallest bound (A,B = its two pair rows). Stages K = 2,4,6,9,12,16: candidates = top-K rows of A ∪ top-K rows of B (indices from `idx`, own-side values from `SV`, cross values by flat `take` from `Ph`), best = max of A_j+B_j over candidates; if `best > A_(K+1) + B_(K+1)` the answer is that candidate (exact: every non-candidate row is bounded by that sum); otherwise `lv1.cond` goes to the next stage, and after K=16 to the full 64-row computation `(Ph[p]+Ph[q]).argmax()`. Stage 1 resolves ~57%, K=4 ~78%, K=8 ~95%, K=16 ~99.7%.
    - Saving: a forward pass is 671 ops; the entry spends ≈80 per input plus ≈68 amortised build. Only exact ties of the top two logits (probability ~1e-13 with float64) could make it differ from the network.
    
    ## Claims
    
    Claimed fidelity 1.0 on this network; expected 1.0 on the second network. The interpretation is the network's own linear rule computed from the weights inside the entry, and every shortcut is an exact bound (order statistics of the pair table), so it holds for any weights; verified exact on random Gaussian weights, reversed/permuted weights, rescaled hidden, degenerate inputs, and 805 inputs with top-2 logit gap < 3e-6. The only failure mode is an exact float64 tie between two logits (tie-break order not replicated), which is practically impossible for trained weights (it did fail once on a synthetic test with two identical unembed rows).
    
    ## Next
    
    The design is at a plateau (~0.22 cost: ≈0.10 build dominated by the 811k-op per-pair argsort, ≈0.12 per input dominated by ~6 ops per candidate plus ~25 for choosing the pairing). Ideas not yet exhausted: (1) cheaper exact tie-breaking only if it costs < 5 ops/input; (2) a cheaper way to get per-pair top-16 than a full 64-length argsort (partial/tournament sorts tested on paper were not cheaper under the n·ceil(log2 n) price); (3) tightening the bound using rows already read (e.g. when the (K+1)-th row of A is itself a B-candidate); (4) micro-trimming the pairing selection (~8 ops) and PI build. Schedules [2,4,7,11,16] or [2,3,5,8,12,16] with 2 or 3 pairings all score within ±0.002, so further gains must come from the build (argsort) or a new candidate/bound structure, not from schedule tuning.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.7915 | 1.0000 | 1.00000 | 0.2061 | 1.00000 | 1.00000 |
| r2s2 | scored | 0.7912 | 1.0000 | 1.00000 | 0.2065 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The network is linear up to the final argmax: `logit_j = Σ_i W[j, t_i]` with `W = unembed·hidden·embed[:, :64]` (64×64), output = `argmax_j`. It matches no simple token rule (max/min/order statistics/sum mod 64/mean/xor/products/pairwise differences all ≈ 1/64 agreement); W has effective rank 7 (8th singular value ≈ 1e-3), outputs are very uneven (55 of 64 classes appear in 200k samples, top class ≈ 10%). It looks like a near-random linear scorer rather than a human task. The interpretation is the exact weight-derived linear rule, so it holds for any weights; verified exact on the verifier samples (2 × 16,384), 4,000 own-weight inputs and 5 × 3,000 inputs on random Gaussian weights. Only exact float ties between two logits can differ (confirmed on synthetic small-integer weights, where ties are common; impossible in practice for trained float weights).
    
    ## How you found it
    
    Re-read the model definition and lv1's pricing source (gather with a scalar reads a whole slice; `take` costs 1 per entry; `take_sum` costs slice × len(v); `cond` charges only the chosen branch; build is amortised over the 16,384 sampled inputs). Loaded the round-1 best entry and reconstructed its op accounting. Simulated in numpy (100k–200k random inputs) the success rate and expected cost of many candidate/bound schemes: fixed vs best-of-2 vs best-of-3 pairings, symmetric/asymmetric K, K=1 gap tests, single-column candidates (≤43% even at K=8), global-row-order tiers with a max bound on weak rows (fallback 10–35%, much worse), and stage schedules. Only micro-savings in the per-input path and the build survived; built them, measured with `measure`, checked exactness on other weights with `lv1.Evaluator`/`lv1.run_reference`, then submitted.
    
    ## The best entry
    
    `r2b` (also saved as `best`): reward 0.7915 / 0.7912, coverage 1, fidelity 1.0, cost 0.2065 (build 0.099, per input 0.107 ≈ 72 ops vs 671). Region: every input. Interpretation: exact branch-and-bound over a pair table.
    - Build (1.09M ops): `W = unembed·(hidden·embed[:, :64])`; `Ph[d*64+a] = W[:,a] + W[:,(a+d)%64]` for d = 0..32 (2112 rows, built with free slices/concat/stack); `PI[a,b]` → pair row (7 ops/entry); `idx = argsort(Ph, axis=1)` (811k, the dominant cost); a single top-17 block `SV17 = Ph[p, idx[p, 47:]]` gives both candidate values and all (K+1)-th bounds as free slices; `KVt[t,t'] = 3rd-largest value of pair (t,t')` as a 64×64 token-indexed table.
    - Per input: bounds of the three pairings `KVt[t0,t1]+KVt[t2,t3]`, … (6 reads, 3 adds), pick the smallest (4 ops), fetch the chosen pair indices with nested `cond` (≈4 ops), `pq*64` (2). Stage K=2: top-2 rows of each pair (indices + own values from the tables, cross values by flat `take` from Ph), argmax of the 4 sums, answer if `best > bound` (27 ops; resolves ≈57%). Later stages K = 4, 6, 9, 12, 16 read only the new ranks and merge with the previous best by free concat + argmax (12Δ+7 ops each); after K=16 the fallback is `take_sum(PhT, [p,q]).argmax()` (191 ops, ≈0.3% of inputs).
    - Saving: ≈72 ops per input plus ≈66 amortised build against a 671-op forward pass. Compared with round 1: pairing choice with `cond` and token-indexed bound table (−6), cheaper stage merging (−3 per stage), one top-17 block instead of separate SV/KV takes (−21k build), cheaper PI (−8k), `take_sum` fallback.
    
    ## Claims
    
    Claimed fidelity 1.0 here; expected 1.0 on the second network. Everything is computed from the weights inside the entry; every early exit is an exact order-statistic bound (non-candidate rows are ≤ A_(K+1)+B_(K+1)), and the final fallback is the full computation. Verified exact on random Gaussian weights of several seeds; the only possible discrepancy is an exact float tie of the top two logits (tie-break order among candidates not replicated), which has negligible probability for trained float weights.
    
    ## Next
    
    The design is at a plateau (~0.206 cost): the per-pair argsort (49 ops/input amortised) and ≈46 unavoidable ops per input (pairing choice + first stage) dominate. Simulated and rejected this round: sorting only a strong-row tier with a max bound on weak rows (fallback rate 10–35%), column-based candidates, K=1 gap tests, 1 or 2 pairings, alternative schedules (all within ±1 op). Remaining small ideas (each ≲ +0.003): token-indexed stage-1 tables with lazy p/q, dropping the 32 duplicate d=32 rows, ending at K=12. A real gain would need either a cheaper exact top-17 selection than n·ceil(log2 n) sorting (none found under the price list) or a fundamentally tighter per-input certificate than separable order-statistic bounds.

### Round 3

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r3s1 | scored | 0.8096 | 1.0000 | 1.00000 | 0.1880 | 1.00000 | 1.00000 |
| r3s2 | scored | 0.8091 | 1.0000 | 1.00000 | 0.1886 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The network is linear up to the final argmax: `logit_j = Σ_i W[j, t_i]` with `W = unembed·hidden·embed[:, :64]` (64×64), output = `argmax_j` (lowest index on a tie). It matches no simple token rule (checked in rounds 1–2); logits are tiny (|logit| ≈ 0.03) and the top-2 gap has density ≈ 80 per unit near 0, so exact float ties are ~1e-13-probable. The interpretation is the exact weight-derived linear rule, so it holds for any weights; verified exact on the verifier samples (2 × 16,384), 2,000 own-weight inputs, 4 × 1,500 inputs on random Gaussian weights of different scales and 1,500 on a near-rank-1 `hidden`.
    
    ## How you found it
    
    Re-used the round-2 structure (pair table + branch-and-bound) and read `lv1`'s pricing source again: a `gather` with several *scalar* indices costs 1 per entry of the result, so `Ph[q, j]` costs 1, whereas the old flat `take(Phf, q*64 + j)` cost 2 and slice-gathers of 2-vectors cost 2 — this cut ~1 op per candidate and the `p*64`/stack overhead. Simulated in numpy (100k–200k inputs) and rejected: chunked sorts (2/4/8 chunks with per-chunk bounds, adaptive expansion), approximate per-pair top-K built from single-column sorts with an exact fallback bound (saturates at 87%), "weak rows" folded into a virtual max row (virtual wins 10%), union of candidates across pairings (no gain), asymmetric K with orientation choice (better per candidate but the 6-way choice costs 17 more ops), lazy pairing choice with a threshold (worse), fixed/2-way pairing (worse). Optimized the stage schedule with the new per-stage cost model (10ΔK+7), built, measured, tested exactness on other weights with `lv1.Evaluator`, submitted.
    
    ## The best entry
    
    `r3a` (also saved as `best`): reward 0.8096 / 0.8091, coverage 1, fidelity 1.0, cost 0.188 (build 0.095 ≈ 64 ops/input amortised, per input ≈ 63 ops vs 671). Region: every input. Interpretation: exact branch-and-bound over a pair table.
    - Build (1.048M ops): `W = unembed·(hidden·embed[:, :64])`; `Ph[d*64+a] = W[:,a] + W[:,(a+d)%64]` for d=0..32 (2112 rows, built as `WT + concat(WT,WT)[d:d+64]`, 2 nodes per d); `PI[a,b]` → pair row (7 ops/entry); `idx = argsort(Ph, axis=1)` (811k, dominant); `IDX = idx[:, 46:]` (18 top ranks, free slice); `SVsel` = the (K+1)-th largest value per pair for K in the schedule only (7 columns, 31.7k); `KVt[t,t']` = 3rd-largest value per pair, token-indexed (4k).
    - Per input (≈63 ops): bounds of the 3 pairings `KVt[t0,t1]+KVt[t2,t3]`, … (9 ops), min + 2 comparisons (4), chosen token order by two `cond`s over free stacks (2), `p,q = PI[..]` (2). Stage K=2: for each of the top-2 rows j of A and B: `j = IDX[p, 17-k]`, value `Ph[p,j] + Ph[q,j]` (4 ops per candidate), argmax of 4, gathers, `best > bound` (23 ops; resolves 57%). Later stages K = 4,6,8,10,13,17 read only the new ranks, merge with the previous best (10ΔK+7 ops each), bound `SVsel[p,s]+SVsel[q,s]`; after K=17 the fallback is `take_sum(PhT,[p,q]).argmax()` (191 ops, ≈0.15%).
    - Compared with round 2 (0.7915): −9 ops/input from scalar gathers and cond-selected tokens, −2.6 build from only 7 SV columns; 394 nodes (limit 400).
    
    ## Claims
    
    Claimed fidelity 1.0 here; expected 1.0 on the second network. Everything is computed from the weights inside the entry (3 scalar constants: 64, 32, 4096 for indexing); every early exit is an exact order-statistic bound (non-candidate rows are ≤ A_(K+1)+B_(K+1) < best), and the final fallback is the full computation. Exact on random Gaussian weights of several seeds/scales and a near-degenerate `hidden`. The only possible discrepancy is an exact float tie between the top two logits (candidate order instead of lowest index), probability ~1e-13 per input for trained float weights.
    
    ## Next
    
    The design is at its plateau: ≈49.5 ops/input of the build are the unavoidable per-pair argsort (n·ceil(log2 n) with no cheaper exact top-18 under the price list; chunked sorts, weak-row/virtual-row bounds and approximate tables all simulate worse), and the ≈63 per-input ops are 17 for the pairing choice + 23 for stage 1 + ≈23 expected for later stages, with every alternative schedule/asymmetry within ±1 op. Remaining ideas are each ≲ +0.003: drop the 32 duplicate d=32 rows (needs a 3-way PI formula, net ≈0.2 op), replace SVsel by 2-op reads (≈0), adaptive one-candidate-at-a-time extension after stage 1 (asymmetric K helps per candidate but costs more per step). A real gain would need a cheaper exact selection primitive than full sorting, or a certificate not based on separable order statistics.

### Round 4

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r4s1 | scored | 0.8101 | 1.0000 | 1.00000 | 0.1875 | 1.00000 | 1.00000 |
| r4s2 | scored | 0.8100 | 1.0000 | 1.00000 | 0.1877 | 1.00000 | 1.00000 |

Notes of that round:

    ## What the network does
    
    The network is linear up to the final argmax: `logit_j = Σ_i W[j, t_i]` with `W = unembed·hidden·embed[:, :64]` (64×64), output = `argmax_j` (lowest index on a tie). It matches no simple token rule (checked in rounds 1–3); the win frequency per row is very uneven (10 rows never/almost never win, top row ≈ 10%), logits are tiny (|logit| ≈ 0.03) and the top-2 gap is dense near 0 (min gap in 400k samples ≈ 5e-8), so it behaves like a near-random linear scorer, not a human task. The interpretation is the exact weight-derived linear rule, so it holds for any weights: this round verified exact on the verifier samples (2 × 16,384), 3,000 own-weight inputs, 794 near-tie/degenerate inputs (all-equal tokens, abab patterns, top-2 gap down to 5e-8), 3 × 1,500 inputs on random Gaussian weights of different scales, 1,500 on a near-rank-1 `hidden`, and 1,500 on permuted/reversed own weights — zero mismatches.
    
    ## How you found it
    
    Re-used the round-3 structure (pair table + exact branch-and-bound) and spent the round trying to break the build plateau (the 811k-op per-pair argsort). Simulated in numpy (40k–100k inputs, with cost models checked against `measure` histograms) and built/measured where promising:
    - **Strong/weak row tiers** (sort only the 48 "strong" rows per pair, ordered by a weight-computed heuristic — count of top-2 appearances per token column, tie-break by row max — and bound the 16 weak rows per pair by their max, resolving them exactly with a 52-op `take_sum` only when the weak bound exceeds the certified best). Built it (`r4a`, exact, 387 nodes): build fell 1047k→926k but per-input rose 63→74.7 (exit overhead 7 ops: weak check, cast of the stacked (index,value) chain result, order map; plus weak resolution triggered 11% of the time, mostly at later stages where gaps are small) → reward 0.802, worse. Variants (virtual weak row inside the sort; weak max folded into the order-statistic bound with full fallback; "continue instead of resolve" policy; s = 40…60) all simulated worse, mainly because the max-of-weak bound is loose exactly on the hard inputs.
    - **Single-column candidate sets** (top-m of each token column, sorted per pair, bound by the exact complement max or by a_(m+1)+b_(m+1)): stage-1 success drops from 57% to ≤ 44% even at m = 16 because pair-top rows are often outside both columns' top-16; always worse.
    - Re-optimised the schedule / number of pairings with a corrected cost model (stage 1 = 10K+4, later 10ΔK+7, 3 pairings = 16 ops, 2 = 10, 1 = 5): the current [2,4,6,8,10,13,17] with 3 pairings is within 0.1 op of the optimum; 2 pairings costs +1 op, 1 pairing +14.
    - Rebuilt the round-3 entry from scratch with a cheaper pair-index table (PI via a 64-entry offset table `F[d]`: 6 ops/entry instead of 7, −3.9k build ops) and reusing the pairing-choice minimum as the stage-1 bound; measured, tested exactness on other weights, submitted.
    
    ## The best entry
    
    `r4b` (also saved as `best`): reward 0.8101 / 0.8100 (coverage 1, fidelity 1.0, cost 0.1875: build 0.0949 ≈ 63.7 ops/input amortised, per input ≈ 62.2 ops vs 671), 390 nodes, 3 scalar constants (64, 32, 4096 and arange sizes). Region: every input. Interpretation: exact branch-and-bound over a pair table.
    - Build (1.044M ops): `W = unembed·(hidden·embed[:, :64])`; `Ph[d*64+a] = W[:,a] + W[:,(a+d)%64]` for d = 0..32 (2112 rows, built as `WT + concat(WT,WT)[d:d+64]`); `PI[a,b] = F[(b−a)%64] + where(d≤32, a, b)` with `F[d] = d*64` (d ≤ 32) or `(64−d)*64`; `idx = argsort(Ph, axis=1)` (811k, dominant); 7 bound columns `SV_K[p]` = (K+1)-th largest value of pair p (flat `take`); `KVt[t,t']` = 3rd-largest value of pair (t,t'), token-indexed.
    - Per input: bounds of the 3 pairings `KVt[t0,t1]+KVt[t2,t3]`, … (9 ops), `min`/2 comparisons, chosen token order by `cond`s over free stacks, `p,q = PI[..]`; stage K = 2: top-2 rows of each of the two pair rows, value `Ph[p,j] + Ph[q,j]`, argmax of 4, answer if `best > min(b1,b2,b3)` (that minimum is exactly A_3 + B_3 of the chosen pairing); later stages K = 4,6,8,10,13,17 read only the new ranks and merge with the previous best (10ΔK+7 ops), bound `SV_K[p] + SV_K[q]`; after K = 17 the fallback is `take_sum(Ph,[p,q]).argmax()` (191 ops, ≈0.15%).
    - Saving: ≈62 ops per input plus ≈64 amortised build against a 671-op forward pass. Every early exit is an exact order-statistic certificate (non-candidate rows are ≤ A_(K+1)+B_(K+1) < best, monotone under float rounding), and the fallback is the full computation.
    
    ## Claims
    
    Claimed fidelity 1.0 on this network; expected 1.0 on the second network. Everything is computed from the weights inside the entry; the only constants are index sizes. Exact on Gaussian weights of several seeds and scales, a near-degenerate `hidden`, permuted weights, degenerate inputs and 600 near-tie inputs. The only possible discrepancy is an exact float64 tie between the top two logits (the entry then returns the candidate found first instead of the lowest index) or rounding differences at gaps ~1e-17, both with probability ≈1e-13 per input for trained float weights.
    
    ## Next
    
    The design is at a hard plateau (0.1875 cost): ≈49.5 ops/input of the build are the per-pair argsort (no cheaper exact top-18 selection exists under the price list) and the ≈62 per-input ops are ≈16 for the pairing choice + ≈24 for stage 1 + ≈22 expected for later stages, with the schedule and number of pairings at their optimum (±0.1 op). Tested and rejected this round with real cost accounting: strong/weak row tiers in every form (best case equals the current cost, built version is 4 ops worse), single-column candidate sets with exact complement bounds, and 2/1-pairing choices. Only sub-0.001 items remain (drop the 32 duplicate d=32 rows: ≈+0.0003; cheaper PI arithmetic). A real gain would need a certificate that is not a separable order-statistic bound (e.g. something exploiting d_model = 8 at < 20 ops/input) or an exact selection primitive cheaper than n·ceil(log2 n) sorting; n

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.8101) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
