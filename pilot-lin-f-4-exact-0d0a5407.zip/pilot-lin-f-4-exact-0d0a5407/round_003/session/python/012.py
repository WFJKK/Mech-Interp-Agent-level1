
import numpy as np, itertools
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(1); N=200000
T=rng.integers(0,64,size=(N,4))
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
bnd=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1); ch=bnd.argmin(1)
A=np.stack(PA,0)[ch,np.arange(N)]; B=np.stack(PB,0)[ch,np.arange(N)]
ia=np.argsort(-A,1); ib=np.argsort(-B,1)
sa=np.take_along_axis(A,ia,1); sb=np.take_along_axis(B,ib,1)
AB=A+B
succ={}
for K in range(1,20):
    cand=np.concatenate([ia[:,:K],ib[:,:K]],1)
    best=np.take_along_axis(AB,cand,1).max(1)
    succ[K]=(best>sa[:,K]+sb[:,K]).mean()
print({k:round(v,4) for k,v in succ.items()})
def expected(sched, first_extra=0):
    # stage1 K0: cost 8*K0 + (2K0-1) + 2 + 1 + 1 ; later: 10 dK + 7 ; fallback 191
    K0=sched[0]; cost=8*K0+(2*K0-1)+4; p_prev=succ[K0]; prevK=K0
    for K in sched[1:]:
        dK=K-prevK; cost+=(1-p_prev)*(10*dK+7); p_prev=succ[K]; prevK=K
    cost+=(1-p_prev)*191
    return cost
res=[]
for L in range(3,8):
    for sched in itertools.combinations(range(1,19),L):
        if sched[0]>3: continue
        res.append((expected(sched),sched))
res.sort(); print(res[:15])
