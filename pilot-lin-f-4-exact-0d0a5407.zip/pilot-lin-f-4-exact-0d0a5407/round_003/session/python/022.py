
import numpy as np, time
ent = entries['r3a']
def test_weights(wts, n=3000, seed=0):
    rng=np.random.default_rng(seed)
    X=rng.integers(0,64,size=(n,4))
    ev=lv1.Evaluator(ent, wts, 4)
    E=wts['embed'][:,:64]; W=wts['unembed']@(wts['hidden']@E)
    bad=0; costs=[]
    for x in X:
        inside, ans, cr, cp = ev.run(list(x))
        # network reference: emulate exactly as model does
        h=wts['embed'][:,x].sum(1); logits=wts['unembed']@(wts['hidden']@h); ref=int(np.argmax(logits))
        bad+= (ans!=ref); costs.append(cp)
    return bad, np.mean(costs), ev.build_cost
t=time.time()
print('own', test_weights(weights, 2000))
for s in range(4):
    rng=np.random.default_rng(100+s)
    wts={'embed': np.concatenate([rng.normal(size=(8,64)), np.zeros((8,1))],1)*rng.uniform(0.3,3),
         'hidden': rng.normal(size=(8,8)), 'unembed': rng.normal(size=(64,8))}
    print('rand',s, test_weights(wts, 1500, seed=s))
# degenerate-ish: low rank hidden
rng=np.random.default_rng(7)
wts={'embed': np.concatenate([rng.normal(size=(8,64)), np.zeros((8,1))],1),'hidden': np.outer(rng.normal(size=8),rng.normal(size=8))+0.01*rng.normal(size=(8,8)), 'unembed': rng.normal(size=(64,8))}
print('lowrank', test_weights(wts, 1500, seed=9))
print(time.time()-t)
