
import inspect, re
src=inspect.getsource(lv1)
for m in re.finditer(r'\nclass (\w+)|\ndef (\w+)\(', src):
    print(m.group(0).strip(), end=' | ')
print()
i=src.find('class Evaluator'); print(src[i:i+1500])
i=src.find('def run_reference'); print(src[i:i+800])
