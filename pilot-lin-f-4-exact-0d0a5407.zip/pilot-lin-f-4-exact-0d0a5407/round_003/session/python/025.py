
import numpy as np, itertools
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(1); N=200000
T=rng.integers(0,64,size=(N,4))
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
bnd=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1)
def succ_table(A,B):
    ia=np.argsort(-A,1); ib=np.argsort(-B,1)
    sa=np.take_along_axis(A,ia,1); sb=np.take_along_axis(B,ib,1); AB=A+B
    s={}
    for K in range(1,20):
        cand=np.concatenate([ia[:,:K],ib[:,:K]],1)
        best=np.take_along_axis(AB,cand,1).max(1)
        s[K]=(best>sa[:,K]+sb[:,K]).mean()
    return s
def expected(sched,succ,pre):
    K0=sched[0]; cost=pre+8*K0+(2*K0-1)+4; p_prev=succ[K0]; prevK=K0
    for K in sched[1:]:
        dK=K-prevK; cost+=(1-p_prev)*(10*dK+7); p_prev=succ[K]; prevK=K
    return cost+(1-p_prev)*191
sched=(2,4,6,8,10,13,17)
ch=bnd.argmin(1)
A=np.stack(PA,0)[ch,np.arange(N)]; B=np.stack(PB,0)[ch,np.arange(N)]
print('full choice', expected(sched,succ_table(A,B),17))
# threshold from weights: quantiles of 2*KV3 (single-pair bound doubled) approximates; here use quantile of b1 directly
for qq in [0.2,0.3,0.4,0.5,0.6]:
    th=np.quantile(bnd[:,0],qq)
    lazy=bnd[:,0]<=th
    ch2=np.where(lazy,0,ch)
    A=np.stack(PA,0)[ch2,np.arange(N)]; B=np.stack(PB,0)[ch2,np.arange(N)]
    pre=17-8*lazy.mean()+2   # +2 for compare & cond
    print(qq, round(lazy.mean(),3), expected(sched,succ_table(A,B),pre))
