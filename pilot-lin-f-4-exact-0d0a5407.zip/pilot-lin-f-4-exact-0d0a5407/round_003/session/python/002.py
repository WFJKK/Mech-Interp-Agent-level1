
import numpy as np, time
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)   # 64x64, W[j,t]
rng=np.random.default_rng(0)
N=100000
T=rng.integers(0,64,size=(N,4))
L = W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]  # 64xN
out = L.argmax(0)
# pair rows
def pairrow(a,b): return (W[:,a]+W[:,b]).T  # N x 64
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
# sorted descending values
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
# current scheme: choose pairing with min SA[2]+SB[2]
bnd=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1)
ch=bnd.argmin(1)
A=np.choose(ch[:,None], PA) if False else np.stack(PA,0)[ch,np.arange(N)]
B=np.stack(PB,0)[ch,np.arange(N)]
def stage_success(A,B,K):
    ia=np.argsort(-A,1); ib=np.argsort(-B,1)
    sa=np.take_along_axis(A,ia,1); sb=np.take_along_axis(B,ib,1)
    cand=np.concatenate([ia[:,:K],ib[:,:K]],1)
    vals=np.take_along_axis(A+B,cand,1)
    best=vals.max(1)
    return best>sa[:,K]+sb[:,K]
for K in [1,2,3,4,6,9,12,16]:
    print(K, stage_success(A,B,K).mean())
# fixed pairing 0
print('fixed', [stage_success(PA[0],PB[0],K).mean() for K in [1,2,4,8]])
