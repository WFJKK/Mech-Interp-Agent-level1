
e = entries['best']
nodes=e['nodes']
print(e['format'], e['predict'], e['rule'])
for i,n in enumerate(nodes):
    print(i, n)
