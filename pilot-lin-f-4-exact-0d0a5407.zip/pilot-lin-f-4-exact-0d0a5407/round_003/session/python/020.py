
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(2); N=100000
T=rng.integers(0,64,size=(N,4))
L=(W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]).T
out=L.argmax(1)
a=np.repeat(np.arange(64),64); b=np.tile(np.arange(64),64)
Pall=(W[:,a]+W[:,b]).T
freq=np.bincount(out,minlength=64)
crits={'oracle':freq,'pairtop1':np.bincount(Pall.argmax(1),minlength=64),
 'coltop1':np.bincount(W.argmax(0),minlength=64),
 'soft':np.exp((W-W.max(0))*20).sum(1),
 'soft5':np.exp((W-W.max(0))*5).sum(1),
 'd0to3':np.bincount((W[:,a]+W[:,b]).T[(b-a)%64<4].argmax(1),minlength=64)}
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
def pairrow(a,b): return (W[:,a]+W[:,b]).T
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
sched=[2,4,6,8,10,13,17]
def sim(weak):
    strong=np.setdiff1d(np.arange(64),weak); ns=len(strong)
    def ext(P): return np.concatenate([P[:,strong], P[:,weak].max(1,keepdims=True)],1)  # ns+1 columns, virtual last
    XA=[ext(P) for P in PA]; XB=[ext(P) for P in PB]
    SA=[-np.sort(-x,1) for x in XA]; SB=[-np.sort(-x,1) for x in XB]
    b2=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1); ch=b2.argmin(1)
    A=np.stack(XA,0)[ch,np.arange(N)]; B=np.stack(XB,0)[ch,np.arange(N)]
    ia=np.argsort(-A,1); ib=np.argsort(-B,1); sa=np.take_along_axis(A,ia,1); sb=np.take_along_axis(B,ib,1)
    AB=A+B
    Aw=np.stack(PA,0)[ch,np.arange(N)][:,weak]+np.stack(PB,0)[ch,np.arange(N)][:,weak]
    weakmax=Aw.max(1)
    done=np.zeros(N,bool); stats=[]
    for K in sched:
        cand=np.concatenate([ia[:,:K],ib[:,:K]],1)
        vals=np.take_along_axis(AB,cand,1); am=vals.argmax(1); best=vals.max(1); bj=cand[np.arange(N),am]
        bnd=sa[:,K]+sb[:,K]
        ok=(best>bnd)&~done
        virt=ok&(bj==ns)
        # resolve: best strong candidate
        vals2=np.where(cand==ns,-np.inf,vals); bs=vals2.max(1)
        cert=virt&(np.maximum(bs,weakmax)>bnd)
        stats.append((K, round((ok&~virt).mean(),4), round(virt.mean(),4), round((virt&~cert).mean(),4)))
        done|=ok
    return stats, (~done).mean()
for name,c in crits.items():
    for nw in [16,24,32]:
        weak=np.argsort(c)[:nw]
        st,fb=sim(weak)
        pv=sum(s[2] for s in st); pnc=sum(s[3] for s in st)
        print(name,nw,'virt',round(pv,4),'uncert',round(pnc,4),'fallback',round(fb,4), [s[1] for s in st])
