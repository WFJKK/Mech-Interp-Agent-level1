
import inspect
src=inspect.getsource(lv1)
print(src[12300:14400])
print('=====')
print(src[36300:37200])
