
save_entry('best', entries['r3a'])
print(sorted(entries.keys()))
