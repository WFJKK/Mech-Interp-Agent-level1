
import inspect
src=inspect.getsource(lv1)
import re
for name in ['def stack','def concat','def cond','def where','def argsort','def take_sum','def take(','def minimum','def entry','def argmax','def sort(']:
    for m in re.finditer(re.escape(name), src):
        print(src[m.start():m.start()+250].split('\n')[0:4]); break
