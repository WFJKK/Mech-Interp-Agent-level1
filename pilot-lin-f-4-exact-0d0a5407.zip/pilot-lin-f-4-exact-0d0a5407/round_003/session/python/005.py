
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(0); N=40000
T=rng.integers(0,64,size=(N,4))
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
bnd=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1); ch=bnd.argmin(1)
A=np.stack(PA,0)[ch,np.arange(N)]; B=np.stack(PB,0)[ch,np.arange(N)]
def chunk_sorted(A,C):
    S=64//C
    Ac=A.reshape(N,C,S)
    ia=np.argsort(-Ac,2); sa=np.take_along_axis(Ac,ia,2)
    return ia+ (np.arange(C)*S)[None,:,None], sa

def sim_adaptive(A,B,C,K0,dK,maxsteps,pairing_cost=15):
    S=64//C
    ia,sa=chunk_sorted(A,C); ib,sb=chunk_sorted(B,C)
    AB=A+B
    k=np.full((N,C),K0)
    # best from initial
    cand=np.concatenate([ia[:,:,:K0].reshape(N,-1),ib[:,:,:K0].reshape(N,-1)],1)
    best=np.take_along_axis(AB,cand,1).max(1)
    n0=2*C*K0
    cost=np.full(N, pairing_cost + 4*n0 + (n0-1) + 2*C + C + (C-1) + 2, float)
    bounds=np.take_along_axis(sa,k[:,:,None],2)[:,:,0]+np.take_along_axis(sb,k[:,:,None],2)[:,:,0]
    done=best>bounds.max(1)
    stepcost=10*dK+2*C+5
    resolved=[done.mean()]
    for s in range(maxsteps):
        cs=bounds.argmax(1)
        act=~done
        # expand chunk cs by dK for active
        kk=k[np.arange(N),cs]
        for d in range(dK):
            r=np.minimum(kk+d,S-1)
            ja=ia[np.arange(N),cs,r]; jb=ib[np.arange(N),cs,r]
            best=np.where(act,np.maximum(best,np.maximum(AB[np.arange(N),ja],AB[np.arange(N),jb])),best)
        knew=np.minimum(kk+dK,S-1)
        k[np.arange(N),cs]=np.where(act,knew,kk)
        nb=sa[np.arange(N),cs,knew]+sb[np.arange(N),cs,knew]
        nb=np.where(knew>=S-1, -np.inf, nb)  # chunk fully read -> no bound (approx)
        bounds[np.arange(N),cs]=np.where(act,nb,bounds[np.arange(N),cs])
        cost+=act*stepcost
        done=done|(best>=bounds.max(1))
        resolved.append(done.mean())
    cost+= (~done)*191
    return cost.mean(), resolved

sortcost={1:384,2:320,4:256,8:192,16:128}
for C in [1,2,4,8]:
    for K0 in [1,2,3]:
        for dK in [1,2,3]:
            if K0+dK*6<64//C:
                c,res=sim_adaptive(A,B,C,K0,dK,12)
                build=(sortcost[C]*2112+135000+36000+28000+8000)/16384
                print(C,K0,dK, round(c,1), round(build,1), round(c+build,1), [round(x,3) for x in res[:6]])
