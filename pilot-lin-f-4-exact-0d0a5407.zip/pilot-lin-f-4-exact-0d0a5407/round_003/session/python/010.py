
import inspect, re
src=inspect.getsource(lv1)
i=src.find('def cost'); 
for m in re.finditer(r'def [a-z_]*cost[a-z_]*|"gather"', src):
    print(m.start(), src[m.start():m.start()+80].split('\n')[0])
# print the cost function body
m=re.search(r'def (_?op_cost|cost_of|_cost)\(', src)
print(src[m.start():m.start()+3000] if m else 'nf')
