
import numpy as np
def build_entry(sched=(2,4,6,8,10,13,17), nsv=18):
    g = graph()
    Emb = g.weight("embed")[:, :64]
    W = g.weight("unembed") @ (g.weight("hidden") @ Emb)     # 64 rows x 64 tokens
    WT = W.T                                                   # tokens x rows
    blocks = []
    for d in range(33):
        if d == 0:
            blocks.append(WT + WT)
        else:
            blocks.append(WT + lv1.concat([WT[d:], WT[:d]], axis=0))
    Ph = lv1.stack(blocks, axis=0).reshape(2112, 64)           # pair rows: p = d*64 + a
    Phf = Ph.reshape(2112 * 64)
    PhT = Ph.T                                                 # 64 x 2112
    # pair index table PI[a,b]
    ar = g.arange(64)
    a = ar.reshape(64, 1); b = ar.reshape(1, 64)
    d = (b - a) % 64
    dm = lv1.minimum(d, 64 - d)
    base = lv1.where(d <= 32, a + 0 * b, b + 0 * a)  # placeholder; fix below
    return None
print('ok')
