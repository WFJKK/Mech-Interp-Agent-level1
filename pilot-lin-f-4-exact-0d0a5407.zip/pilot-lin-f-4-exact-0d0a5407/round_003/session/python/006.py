
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(0); N=100000
T=rng.integers(0,64,size=(N,4))
CI=np.argsort(-W,axis=0)   # CI[:,t] rows of column t sorted desc
CS=-np.sort(-W,axis=0)
def approx_tables(m):
    # for all ordered pairs (a,b) -> candidate rows (2m) sorted desc by Ph value, with bound terms
    a=np.repeat(np.arange(64),64); b=np.tile(np.arange(64),64)
    rows=np.concatenate([CI[:m,a].T, CI[:m,b].T],1)   # (4096, 2m)
    vals=W[rows,a[:,None]]+W[rows,b[:,None]]
    # mask duplicates: second occurrence -> -inf
    dup=np.zeros_like(vals,dtype=bool)
    ra=rows[:,:m]; rb=rows[:,m:]
    dup[:,m:]=(rb[:,:,None]==ra[:,None,:]).any(2)
    vals=np.where(dup,-np.inf,vals)
    o=np.argsort(-vals,1); rows=np.take_along_axis(rows,o,1); vals=np.take_along_axis(vals,o,1)
    base=CS[m,a]+CS[m,b]
    return rows.reshape(64,64,2*m), vals.reshape(64,64,2*m), base.reshape(64,64)
def evalK(m,Ks):
    rows,vals,base=approx_tables(m)
    res={}
    pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
    L=W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]
    for K in Ks:
        succ=[]
        bnds=[]
        for (pa,pb) in pairings:
            a0,a1=T[:,pa[0]],T[:,pa[1]]; b0,b1=T[:,pb[0]],T[:,pb[1]]
            VA=np.maximum(vals[a0,a1,K],base[a0,a1]); VB=np.maximum(vals[b0,b1,K],base[b0,b1])
            cand=np.concatenate([rows[a0,a1,:K],rows[b0,b1,:K]],1)
            best=L[cand,np.arange(N)[:,None]].max(1)
            succ.append(best>VA+VB); bnds.append(VA+VB)
        succ=np.stack(succ,1); bnds=np.stack(bnds,1)
        # choose pairing by min bound at K=2 analog: use this K's bound
        ch=bnds.argmin(1)
        res[K]=(succ[:,0].mean(), succ[np.arange(N),ch].mean(), succ.any(1).mean())
    return res
for m in [4,6,8,12,16]:
    print(m, {k:tuple(round(x,3) for x in v) for k,v in evalK(m,[1,2,3,4,6,9]).items()})
