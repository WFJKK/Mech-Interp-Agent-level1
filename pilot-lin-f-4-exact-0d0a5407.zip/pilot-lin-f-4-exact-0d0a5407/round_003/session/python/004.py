
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(0); N=100000
T=rng.integers(0,64,size=(N,4))
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
bnd=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1); ch=bnd.argmin(1)
A=np.stack(PA,0)[ch,np.arange(N)]; B=np.stack(PB,0)[ch,np.arange(N)]
def chunk_sorted(A,C):
    S=64//C
    Ac=A.reshape(N,C,S)
    ia=np.argsort(-Ac,2); sa=np.take_along_axis(Ac,ia,2)
    return ia+ (np.arange(C)*S)[None,:,None], sa
def stageX(A,B,C,K):
    ia,sa=chunk_sorted(A,C); ib,sb=chunk_sorted(B,C)
    cand=np.concatenate([ia[:,:,:K].reshape(N,-1),ib[:,:,:K].reshape(N,-1)],1)
    vals=np.take_along_axis(A+B,cand,1); best=vals.max(1)
    bnd=(sa[:,:,K]+sb[:,:,K]).max(1)
    return best>bnd
for C in [1,2,4,8]:
    for K in [1,2,3,4]:
        if K< 64//C:
            print(C,K, 2*K*C, round(stageX(A,B,C,K).mean(),4))
# fixed pairing with chunks
for C in [2,4]:
    print('fixed',C,[round(stageX(PA[0],PB[0],C,K).mean(),4) for K in [1,2]])
