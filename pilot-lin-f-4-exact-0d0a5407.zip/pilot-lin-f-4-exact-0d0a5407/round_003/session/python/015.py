
import numpy as np
def build_entry(sched=(2,4,6,8,10,13,17), nsv=18):
    g = graph()
    Emb = g.weight("embed")[:, :64]
    W = g.weight("unembed") @ (g.weight("hidden") @ Emb)
    WT = W.T
    blocks = [WT + WT] + [WT + lv1.concat([WT[d:], WT[:d]], axis=0) for d in range(1, 33)]
    Ph = lv1.stack(blocks, axis=0).reshape(2112, 64)
    Phf = Ph.reshape(2112 * 64)
    PhT = Ph.T
    ar = g.arange(64)
    a = ar.reshape(64, 1); b = ar.reshape(1, 64)
    d = (b - a) % 64
    d64 = d * 64
    PI = lv1.where(d <= 32, d64 + a, (b + 4096) - d64)        # 64x64 pair index
    idx = lv1.argsort(Ph, axis=1)                              # ascending
    IDX = idx[:, 64 - nsv:]                                    # column nsv-1 = top-1; rank r at column nsv-r
    cols = [nsv - 1 - K for K in sched]                        # (K+1)-th largest for each stage K
    IDXsel = lv1.concat([IDX[:, c:c + 1] for c in cols], axis=1)   # 2112 x len(sched), free
    rowbase = (g.arange(2112) * 64).reshape(2112, 1)
    SVsel = lv1.take(Phf, (rowbase + IDXsel).reshape(2112 * len(sched)), axis=0).reshape(2112, len(sched))
    KV3 = SVsel[:, 0]                                          # (sched[0]+1)-th largest per pair
    KVt = lv1.take(KV3, PI.reshape(4096), axis=0).reshape(64, 64)
    # ---- per input
    t0, t1, t2, t3 = g.token(0), g.token(1), g.token(2), g.token(3)
    b1 = KVt[t0, t1] + KVt[t2, t3]
    b2 = KVt[t0, t2] + KVt[t1, t3]
    b3 = KVt[t0, t3] + KVt[t1, t2]
    c12 = b1 <= b2; m12 = lv1.minimum(b1, b2)
    c3 = m12 <= b3; bound = lv1.minimum(m12, b3)
    toks = lv1.cond(c3, lv1.cond(c12, lv1.stack([t0, t1, t2, t3]), lv1.stack([t0, t2, t1, t3])), lv1.stack([t0, t3, t1, t2]))
    p = PI[toks[0], toks[1]]; q = PI[toks[2], toks[3]]
    def cand(k):   # k-th largest (1-based) of A and of B: returns (vals list, idx list)
        jA = IDX[p, nsv - k]; jB = IDX[q, nsv - k]
        vA = Ph[p, jA] + Ph[q, jA]
        vB = Ph[p, jB] + Ph[q, jB]
        return [vA, vB], [jA, jB]
    K0 = sched[0]
    vals, js = [], []
    for k in range(1, K0 + 1):
        v, j = cand(k); vals += v; js += j
    V = lv1.stack(vals); J = lv1.stack(js)
    am = V.argmax(); best = V[am]; bestj = J[am]
    oks = [best > bound]; bests = [bestj]
    prevK = K0
    for si, K in enumerate(sched[1:], start=1):
        vals, js = [], []
        for k in range(prevK + 1, K + 1):
            v, j = cand(k); vals += v; js += j
        V = lv1.concat([lv1.stack(vals), best.reshape(1)]); J = lv1.concat([lv1.stack(js), bestj.reshape(1)])
        am = V.argmax(); best = V[am]; bestj = J[am]
        bnd = SVsel[p, si] + SVsel[q, si]
        oks.append(best > bnd); bests.append(bestj)
        prevK = K
    full = lv1.take_sum(PhT, lv1.stack([p, q]), axis=1).argmax()
    out = full
    for ok, bj in zip(reversed(oks), reversed(bests)):
        out = lv1.cond(ok, bj, out)
    return g.entry(interpretation=out)
ent = build_entry()
print(len(ent['nodes']))
m = measure(ent); print(m)
save_entry('r3a', ent)
