
import inspect, numpy as np
print(info['sizes'] if 'sizes' in info else info.keys())
print({k:v for k,v in info.items() if k!='weights'})
e = entries['best']
m = measure(e); print(m)
import json
print(len(e.get('nodes', e)) if isinstance(e, dict) else type(e))
print(list(e.keys()) if isinstance(e, dict) else None)
