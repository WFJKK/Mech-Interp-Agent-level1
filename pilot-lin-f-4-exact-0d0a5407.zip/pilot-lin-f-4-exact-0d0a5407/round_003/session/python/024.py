
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(5); N=400000
T=rng.integers(0,64,size=(N,4))
L=(W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]).T
S=np.sort(L,1); gap=S[:,-1]-S[:,-2]
print('logit scale', np.abs(L).mean(), 'gap quantiles', np.quantile(gap,[0.001,0.01,0.1,0.5]))
for x in [1e-2,1e-3,1e-4]:
    print(x, (gap<x).mean(), 'density est', (gap<x).mean()/x)
# compare our sum order vs network's on near ties
idx=np.argsort(gap)[:2000]
bad=0
for i in idx:
    x=T[i]; h=weights['embed'][:,x].sum(1); ref=int(np.argmax(U@(H@h)))
    a,b,c,d=x; ours=int(np.argmax((W[:,a]+W[:,b])+(W[:,c]+W[:,d])))
    bad+=ours!=ref
print('near-tie disagreements', bad, 'min gap', gap[idx[0]])
