
import numpy as np, itertools
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(1); N=100000
T=rng.integers(0,64,size=(N,4))
L=(W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]).T  # N x 64
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
IA=[np.argsort(-a,1) for a in PA]; IB=[np.argsort(-b,1) for b in PB]
SA=[np.take_along_axis(PA[i],IA[i],1) for i in range(3)]; SB=[np.take_along_axis(PB[i],IB[i],1) for i in range(3)]
def bound(i,K): return SA[i][:,K]+SB[i][:,K]
def succ(Ks):  # Ks: per pairing K (list of 3), candidates union, bound min over pairings with K>0
    cands=[]; b=np.full(N,np.inf)
    for i,K in enumerate(Ks):
        if K>0:
            cands.append(IA[i][:,:K]); cands.append(IB[i][:,:K]); b=np.minimum(b,bound(i,K))
    cand=np.concatenate(cands,1)
    best=np.take_along_axis(L,cand,1).max(1)
    return (best>b).mean()
print('6x top1', succ([1,1,1]))
print('pairing0 top2', succ([2,0,0]))
# chosen pairing by K=2 bound
b2=np.stack([bound(i,2) for i in range(3)],1); ch=b2.argmin(1)
def succ_ch(Kc,Ko):
    res=np.zeros(N,bool)
    for c in range(3):
        Ks=[Ko]*3; Ks[c]=Kc
        m=ch==c
        cands=[]; b=np.full(N,np.inf)
        for i,K in enumerate(Ks):
            if K>0:
                cands.append(IA[i][:,:K]); cands.append(IB[i][:,:K]); b=np.minimum(b,bound(i,K))
        cand=np.concatenate(cands,1)
        best=np.take_along_axis(L,cand,1).max(1)
        res[m]=(best>b)[m]
    return res.mean()
for Kc,Ko in [(2,0),(2,1),(3,0),(3,1),(4,0),(4,1),(1,1),(2,2)]:
    print(Kc,Ko,succ_ch(Kc,Ko))
