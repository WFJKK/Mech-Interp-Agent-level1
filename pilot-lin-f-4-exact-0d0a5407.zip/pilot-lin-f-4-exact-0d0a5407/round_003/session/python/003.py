
def chunk_sorted(A,C):
    S=64//C
    Ac=A.reshape(N,C,S)
    ia=np.argsort(-Ac,2); sa=np.take_along_axis(Ac,ia,2)
    return ia+ (np.arange(C)*S)[None,:,None], sa
def stageX(A,B,C,K):
    ia,sa=chunk_sorted(A,C); ib,sb=chunk_sorted(B,C)
    cand=np.concatenate([ia[:,:,:K].reshape(N,-1),ib[:,:,:K].reshape(N,-1)],1)
    vals=np.take_along_axis(A+B,cand,1); best=vals.max(1)
    bnd=(sa[:,:,K]+sb[:,:,K]).max(1)
    return best>bnd
for C in [1,2,4,8]:
    for K in [1,2,3,4]:
        if K< 64//C:
            print(C,K, 2*K*C, round(stageX(A,B,C,K).mean(),4))
