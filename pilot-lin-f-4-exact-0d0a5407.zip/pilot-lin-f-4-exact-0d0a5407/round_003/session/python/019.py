
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(1); N=100000
T=rng.integers(0,64,size=(N,4))
L=(W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]).T
out=L.argmax(1)
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
b2=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(3)],1); ch=b2.argmin(1)
A=np.stack(PA,0)[ch,np.arange(N)]; B=np.stack(PB,0)[ch,np.arange(N)]
freq=np.bincount(out,minlength=64)
# all-pairs table for criteria
a=np.repeat(np.arange(64),64); b=np.tile(np.arange(64),64)
Pall=(W[:,a]+W[:,b]).T  # 4096 x 64
top1=np.bincount(Pall.argmax(1),minlength=64)
crit={'oracle':freq,'rowmean':W.mean(1),'rowmax':W.max(1),'pairtop1':top1,'pairmaxgap':(Pall-Pall.max(1,keepdims=True)).max(0)}
for name,c in crit.items():
    for nw in [16,24,32]:
        weak=np.argsort(c)[:nw]; strong=np.setdiff1d(np.arange(64),weak)
        As=A[:,strong]; Bs=B[:,strong]; Aw=A[:,weak].max(1)+B[:,weak].max(1)
        ia=np.argsort(-As,1); ib=np.argsort(-Bs,1)
        sa=np.take_along_axis(As,ia,1); sb=np.take_along_axis(Bs,ib,1); ABs=As+Bs
        r=[]
        for K in [2,4,6,8,10,13]:
            cand=np.concatenate([ia[:,:K],ib[:,:K]],1)
            best=np.take_along_axis(ABs,cand,1).max(1)
            okstrong=best>sa[:,K]+sb[:,K]
            okweak=best>Aw
            r.append((round((okstrong&okweak).mean(),3), round((okstrong&~okweak).mean(),3)))
        print(name,nw,r)
