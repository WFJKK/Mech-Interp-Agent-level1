
import numpy as np, itertools
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(1); N=200000
T=rng.integers(0,64,size=(N,4))
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
PA=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]
PB=[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
SA=[-np.sort(-a,axis=1) for a in PA]; SB=[-np.sort(-b,axis=1) for b in PB]
def succ_table(A,B):
    ia=np.argsort(-A,1); ib=np.argsort(-B,1)
    sa=np.take_along_axis(A,ia,1); sb=np.take_along_axis(B,ib,1); AB=A+B
    s={}
    for K in range(1,22):
        cand=np.concatenate([ia[:,:K],ib[:,:K]],1)
        best=np.take_along_axis(AB,cand,1).max(1)
        s[K]=(best>sa[:,K]+sb[:,K]).mean()
    return s
def expected(sched,succ,pre):
    K0=sched[0]; cost=pre+8*K0+(2*K0-1)+4; p_prev=succ[K0]; prevK=K0
    for K in sched[1:]:
        dK=K-prevK; cost+=(1-p_prev)*(10*dK+7); p_prev=succ[K]; prevK=K
    return cost+(1-p_prev)*191
def best_sched(succ,pre,maxK=21):
    res=[]
    for L in range(3,8):
        for sched in itertools.combinations(range(1,maxK),L):
            if sched[0]>3: continue
            res.append((expected(sched,succ,pre),sched))
    res.sort(); return res[0]
# option A: choice among 3 by 3rd values (pre=17)
for Kc in [1,2,3]:
    bnd=np.stack([SA[i][:,Kc]+SB[i][:,Kc] for i in range(3)],1); ch=bnd.argmin(1)
    A=np.stack(PA,0)[ch,np.arange(N)]; B=np.stack(PB,0)[ch,np.arange(N)]
    s=succ_table(A,B); print('choice3 Kc',Kc, best_sched(s,17))
# option B: fixed pairing (pre = 2 + 3)
s=succ_table(PA[0],PB[0]); print('fixed', best_sched(s,5))
# option C: best of 2 (pre = 6+1+1+1+2 = 11)
bnd=np.stack([SA[i][:,2]+SB[i][:,2] for i in range(2)],1); ch=bnd.argmin(1)
A=np.stack(PA[:2],0)[ch,np.arange(N)]; B=np.stack(PB[:2],0)[ch,np.arange(N)]
s=succ_table(A,B); print('choice2', best_sched(s,11))
