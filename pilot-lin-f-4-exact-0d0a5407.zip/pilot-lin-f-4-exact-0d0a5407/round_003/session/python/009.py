
import inspect, re
src=inspect.getsource(lv1)
# find cost-related code for gather / take / cond
for kw in ['def _cost','gather','"cond"',"'cond'"]:
    for m in re.finditer(kw, src):
        s=max(0,m.start()-200); print('----',kw); print(src[s:m.start()+600]); break
print(len(src))
