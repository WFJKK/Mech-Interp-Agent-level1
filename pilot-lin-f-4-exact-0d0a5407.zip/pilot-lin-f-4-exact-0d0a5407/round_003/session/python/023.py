
import numpy as np
E=weights['embed'][:,:64]; H=weights['hidden']; U=weights['unembed']
W = U@(H@E)
rng=np.random.default_rng(3); N=100000
T=rng.integers(0,64,size=(N,4))
L=(W[:,T[:,0]]+W[:,T[:,1]]+W[:,T[:,2]]+W[:,T[:,3]]).T
def pairrow(a,b): return (W[:,a]+W[:,b]).T
pairings=[((0,1),(2,3)),((0,2),(1,3)),((0,3),(1,2))]
P=[pairrow(T[:,p[0][0]],T[:,p[0][1]]) for p in pairings]+[pairrow(T[:,p[1][0]],T[:,p[1][1]]) for p in pairings]
I=[np.argsort(-x,1) for x in P]; S=[np.take_along_axis(P[i],I[i],1) for i in range(6)]
def run(KA,KB,orient=True):
    # options: pairing i with A=P[i],B=P[i+3] and (if orient) swapped
    opts=[(i,i+3) for i in range(3)]+([(i+3,i) for i in range(3)] if orient else [])
    bnds=np.stack([S[a][:,KA]+S[b][:,KB] for a,b in opts],1); ch=bnds.argmin(1)
    ok=np.zeros(N,bool)
    for oi,(a,b) in enumerate(opts):
        m=ch==oi
        cand=np.concatenate([I[a][:,:KA],I[b][:,:KB]],1)
        best=np.take_along_axis(L,cand,1).max(1)
        ok[m]=(best>bnds[:,oi])[m]
    return ok.mean()
for KA,KB in [(2,2),(3,1),(4,1),(3,2),(4,2),(5,1),(6,2),(4,4),(5,3),(6,1)]:
    print(KA,KB, round(run(KA,KB,False),4), round(run(KA,KB,True),4))
