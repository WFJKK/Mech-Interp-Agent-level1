
for Ks, Kmax in [([1,2,4,7,11,16],16), ([2,3,5,8,12,16],16), ([2,4,6,9,12,16],16), ([2,4,7,11,16,24],24), ([2,4,7,11,16,22,32],32)]:
    e = staged5(Ks, Kmax); m = measure(e); print(Ks, Kmax, {k: round(m[k],4) if isinstance(m[k], float) else m[k] for k in ['predict_ops','build_ops','cost','b','fidelity','reward']})
    save_entry('st5_' + '_'.join(map(str,Ks)), e)
