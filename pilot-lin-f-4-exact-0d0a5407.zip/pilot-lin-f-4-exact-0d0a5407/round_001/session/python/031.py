
import time
e = entries['st6_2_4_6_9_12_16']
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
rng = np.random.default_rng(1)
for trial in range(4):
    w = {}
    for k,v in weights.items():
        scale = {'embed':1.0, 'hidden':0.5, 'unembed':0.7}[k]
        arr = (rng.standard_normal(v.shape) * scale).astype(np.float32)
        if k == 'embed': arr[:, 64] = 0
        w[k] = arr
    if trial == 2:
        w = {k: v.copy() for k,v in weights.items()}; w['unembed'] = w['unembed'][::-1].copy(); w['embed'] = w['embed'][:, list(range(63,-1,-1))+[64]].copy()
    if trial == 3:
        w = {k: v.copy() for k,v in weights.items()}; w['hidden'] = (w['hidden'] * 3).astype(np.float32)
    inputs = rng.integers(0, 64, size=(8000, 4))
    inputs[:200] = inputs[:200, :1]  # all-equal tokens
    inputs[200:400, 2:] = inputs[200:400, :2]
    t0 = time.time()
    ans, mops = lv1.run_reference(ref_entry, w, 4, inputs)
    m = lv1.measure(e, w, 4, inputs, ans, mops)
    print(trial, {k: (round(m[k],4) if isinstance(m[k], float) else m[k]) for k in m if k in ['n_agree','n_in_region','cost','fidelity']}, round(time.time()-t0,1))
