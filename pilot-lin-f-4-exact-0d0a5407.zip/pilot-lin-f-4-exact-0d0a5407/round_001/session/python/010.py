
import inspect
print(lv1.PRICES)
print(lv1.MAX_ELEMENTS, lv1.MAX_HELD, lv1.MAX_NODES, lv1.MAX_RANK, lv1.MAX_CONST_SCALARS)
print(inspect.getsource(lv1.gather)[:1500])
print(inspect.getsource(lv1.take)[:800])
print(inspect.getsource(lv1.argsort)[:600])
