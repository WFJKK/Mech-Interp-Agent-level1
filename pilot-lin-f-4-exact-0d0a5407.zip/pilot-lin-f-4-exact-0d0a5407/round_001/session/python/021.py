
def build_tables(g):
    E = g.weight('embed'); Hh = g.weight('hidden'); Uu = g.weight('unembed')
    W = Uu @ (Hh @ E[:, :64])
    Wt = W.T
    q = 2079 - g.arange(2080)
    ap = lv1.cast((lv1.sqrt(lv1.cast(8*q+1, "float")) - 1.0) / 2.0, "int")
    bp = q - ap*(ap+1)//2
    a = 63 - ap; b = 63 - bp
    Ph = lv1.take(Wt, a, 0) + lv1.take(Wt, b, 0)
    r = g.arange(64)
    lo = lv1.minimum(r.reshape(64,1), r.reshape(1,64)); hi = lv1.maximum(r.reshape(64,1), r.reshape(1,64))
    PI = 64*lo - lo*(lo-1)//2 + hi - lo
    return Ph, PI

def staged3(Ks, Kmax=16):
    g = graph()
    Ph, PI = build_tables(g)
    PIb = PI*64
    idx = lv1.argsort(Ph, axis=1)
    Pflat = Ph.reshape(2080*64)
    pbase = (g.arange(2080)*64).reshape(2080,1)
    TOPI = idx[:, 64-Kmax:]
    SV = lv1.take(Pflat, pbase + TOPI)
    KVs = [lv1.take(Pflat, (pbase + idx[:, 63-K:64-K])).reshape(2080) for K in Ks]
    t = [g.token(i) for i in range(4)]
    p12 = PI[t[0], t[1]]; p34 = PI[t[2], t[3]]
    base12 = PIb[t[0], t[1]]; base34 = PIb[t[2], t[3]]
    fallback = (Ph[p12] + Ph[p34]).argmax()
    def stage(i, prev_best, prev_arg):
        K = Ks[i]; K0 = Ks[i-1] if i > 0 else 0
        sl = slice(Kmax-K, Kmax-K0)
        ca = TOPI[:, sl][p12]; cb = TOPI[:, sl][p34]
        sa = SV[:, sl][p12]; sb = SV[:, sl][p34]
        va = sa + lv1.take(Pflat, base34 + ca)
        vb = sb + lv1.take(Pflat, base12 + cb)
        vals = lv1.concat([va, vb], axis=0); c = lv1.concat([ca, cb], axis=0)
        arg = vals.argmax(); best = vals[arg]; cand = c[arg]
        if prev_best is not None:
            better = prev_best > best
            best = lv1.where(better, prev_best, best); cand = lv1.where(better, prev_arg, cand)
        ok = best > KVs[i][p12] + KVs[i][p34]
        nxt = stage(i+1, best, cand) if i+1 < len(Ks) else fallback
        return lv1.cond(ok, cand, nxt)
    return g.entry(interpretation=stage(0, None, None))

best = None
for Ks, Kmax in [([3,6,10,16],16), ([3,5,8,12,16],16), ([2,4,7,11,16],16), ([3,6,10,16,24],24), ([3,5,8,12,17,24],24)]:
    e = staged3(Ks, Kmax); m = measure(e); print(Ks, Kmax, {k: round(m[k],4) if isinstance(m[k], float) else m[k] for k in ['predict_ops','build_ops','cost','b','fidelity','reward']})
    save_entry('st3_' + '_'.join(map(str,Ks)), e)
