
import inspect, re
src = inspect.getsource(lv1)
print(src[3000:7500])
