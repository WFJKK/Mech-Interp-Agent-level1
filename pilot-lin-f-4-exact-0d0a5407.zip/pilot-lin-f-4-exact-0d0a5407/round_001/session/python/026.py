
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
PT = (W[:,:,None]+W[:,None,:]).transpose(1,2,0)
L = (W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]).T; Lmax = L.max(1)
pairings = [((0,1),(2,3)), ((0,2),(1,3)), ((0,3),(1,2))]
Ks = [3,5,8,12,16]
bounds = {}
for pi,(u,v) in enumerate(pairings):
    A = PT[X[:,u[0]],X[:,u[1]]]; B = PT[X[:,v[0]],X[:,v[1]]]
    sa = -np.sort(-A,1); sb = -np.sort(-B,1)
    bounds[pi] = np.stack([sa[:,K]+sb[:,K] for K in Ks],1)   # N x len(Ks)
fixed = bounds[0]
print('fixed ok per stage', [(Lmax > fixed[:,i]).mean().round(3) for i in range(len(Ks))])
# choose pairing by stage-1 bound
sel = np.argmin(np.stack([bounds[p][:,0] for p in range(3)],1),1)
chosen = np.stack([bounds[sel[n]][n] for n in range(len(X))])
print('chosen ok per stage', [(Lmax > chosen[:,i]).mean().round(3) for i in range(len(Ks))])
# best-of-3 at each stage (oracle)
allb = np.stack([bounds[p] for p in range(3)],0).min(0)
print('oracle ok per stage', [(Lmax > allb[:,i]).mean().round(3) for i in range(len(Ks))])
