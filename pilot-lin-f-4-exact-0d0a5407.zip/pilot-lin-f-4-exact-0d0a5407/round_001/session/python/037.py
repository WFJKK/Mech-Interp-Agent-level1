
import time
E32,H32,U32 = weights['embed'], weights['hidden'], weights['unembed']
E,H,U = E32.astype(np.float64), H32.astype(np.float64), U32.astype(np.float64)
W64 = U@H@E[:,:64]
rng = np.random.default_rng(11)
sel = []
for chunk in range(8):
    Xs = rng.integers(0,64,size=(400_000,4))
    Lt = (W64[:,Xs[:,0]]+W64[:,Xs[:,1]]+W64[:,Xs[:,2]]+W64[:,Xs[:,3]])
    s = np.sort(Lt,0); gap = s[-1]-s[-2]
    sel.append(Xs[gap < 3e-6])
sel = np.concatenate(sel); print('near-tie inputs', len(sel))
e = entries['st6_2_4_6_9_12_16']
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
t0 = time.time()
ans, mops = lv1.run_reference(ref_entry, weights, 4, sel)
m = lv1.measure(e, weights, 4, sel, ans, mops)
print({k: m[k] for k in ['n_in_region','n_agree','fidelity']}, round(time.time()-t0,1))
# which disagree and their gaps
Lt = (W64[:,sel[:,0]]+W64[:,sel[:,1]]+W64[:,sel[:,2]]+W64[:,sel[:,3]]); truth = Lt.argmax(0)
ans = np.array(ans); print('ref vs float64 truth disagreements among near-ties:', (ans != truth).sum())
s = np.sort(Lt,0); gap = s[-1]-s[-2]
print('gaps of ref/truth disagreements:', gap[ans != truth][:10])
