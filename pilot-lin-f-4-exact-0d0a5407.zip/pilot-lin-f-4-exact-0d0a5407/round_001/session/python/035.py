
E32,H32,U32 = weights['embed'], weights['hidden'], weights['unembed']
print(E32.dtype)
# check dtype of entry values
g = graph(); W = g.weight('unembed') @ (g.weight('hidden') @ g.weight('embed')[:, :64]); print('entry W dtype', W.value.dtype, (W.T*2.0).value.dtype, (W+W).value.dtype)
h = lv1.take_sum(g.weight("embed"), g.tokens(), axis=1); print('h dtype', h.value.dtype, (g.weight('hidden')@h).value.dtype)
rng = np.random.default_rng(5)
N = 3_000_000
Xs = rng.integers(0,64,size=(N,4))
# reference as evaluator: take_sum -> float32 sum -> _norm to float64? then matmul with float32 weights -> float64
hs = np.take(E32, Xs, axis=1).sum(axis=2)  # shape (8, N) float32 ; order: np.take(x, idx, axis=1) gives (8, N, 4) -> sum axis 2
print(hs.dtype)
hs64 = hs.astype(np.float64)
ref_logits = (U32.astype(np.float64) @ (H32.astype(np.float64) @ hs64)) if False else None
# emulate: H32 @ hs64 -> numpy promotes to float64
l1 = H32 @ hs64; l2 = U32 @ l1
ref = l2.argmax(0)
# truth in float64 from float64 weights
E,H,U = E32.astype(np.float64), H32.astype(np.float64), U32.astype(np.float64)
W64 = U@H@E[:,:64]
Lt = (W64[:,Xs[:,0]]+W64[:,Xs[:,1]]+W64[:,Xs[:,2]]+W64[:,Xs[:,3]])
truth = Lt.argmax(0)
print('ref vs float64-truth disagreements:', (ref != truth).sum(), 'of', N)
# my entry pipeline: W computed in float32 matmul then pairs in float32?
W32 = U32 @ (H32 @ E32[:, :64])
print(W32.dtype)
Pa = W32[:,Xs[:,0]] + W32[:,Xs[:,1]]; Pb = W32[:,Xs[:,2]] + W32[:,Xs[:,3]]
mine = (Pa + Pb).argmax(0)
print('mine(float32 tables) vs ref:', (mine != ref).sum(), ' mine vs truth:', (mine != truth).sum())
