
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
PT = (W[:,:,None]+W[:,None,:]).transpose(1,2,0)  # a,b,j
A = PT[X[:,0],X[:,1]]; B = PT[X[:,2],X[:,3]]; L = A+B
N = len(X)
def sim(G, ms):
    # grouped: rows reshaped (N, 64/G, G)
    Ag = A.reshape(N, 64//G, G); Bg = B.reshape(N, 64//G, G)
    oa = np.argsort(-Ag, axis=2); ob = np.argsort(-Bg, axis=2)
    sa = -np.sort(-Ag, axis=2); sb = -np.sort(-Bg, axis=2)
    res = []
    for m in ms:
        ca = (oa[:,:,:m] + (np.arange(64//G)*G)[None,:,None]).reshape(N,-1)
        cb = (ob[:,:,:m] + (np.arange(64//G)*G)[None,:,None]).reshape(N,-1)
        c = np.concatenate([ca,cb],1)
        best = np.take_along_axis(L, c, 1).max(1)
        if m < G:
            bound = sa[:,:,m].max(1) + sb[:,:,m].max(1)
        else:
            bound = -np.inf
        res.append((m, c.shape[1], (best > bound).mean()))
    return res
print('G=64 exact', sim(64, [2,3,4,6,8,12,16]))
print('G=16', sim(16, [1,2,3,4]))
print('G=8', sim(8, [1,2,3]))
print('G=32', sim(32, [1,2,3,4,6,8]))
