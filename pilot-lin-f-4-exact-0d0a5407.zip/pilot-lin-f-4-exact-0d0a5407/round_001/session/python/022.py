
NP = 64*33
def build_tables2(g):
    E = g.weight('embed'); Hh = g.weight('hidden'); Uu = g.weight('unembed')
    W = Uu @ (Hh @ E[:, :64])
    Wt = W.T                                   # (t, j)
    a = g.arange(64).reshape(64,1); d = g.arange(33).reshape(1,33)
    b = ((a + d) % 64).reshape(NP)
    Ph = (Wt.reshape(64,1,64) + lv1.take(Wt, b, 0).reshape(64,33,64)).reshape(NP, 64)
    r = g.arange(64)
    t1 = r.reshape(64,1); t2 = r.reshape(1,64)
    dd = (t2 - t1) % 64
    small = dd <= 32
    PI = lv1.where(small, t1*33 + dd, t2*33 + (64 - dd))
    return Ph, PI

def staged4(Ks, Kmax=16):
    g = graph()
    Ph, PI = build_tables2(g)
    PIb = PI*64
    idx = lv1.argsort(Ph, axis=1)
    Pflat = Ph.reshape(NP*64)
    pbase = (g.arange(NP)*64).reshape(NP,1)
    TOPI = idx[:, 64-Kmax:]
    SV = lv1.take(Pflat, pbase + TOPI)
    KVs = [lv1.take(Pflat, (pbase + idx[:, 63-K:64-K])).reshape(NP) for K in Ks]
    t = [g.token(i) for i in range(4)]
    p12 = PI[t[0], t[1]]; p34 = PI[t[2], t[3]]
    base12 = PIb[t[0], t[1]]; base34 = PIb[t[2], t[3]]
    fallback = (Ph[p12] + Ph[p34]).argmax()
    def stage(i, prev_best, prev_arg):
        K = Ks[i]; K0 = Ks[i-1] if i > 0 else 0
        sl = slice(Kmax-K, Kmax-K0)
        ca = TOPI[:, sl][p12]; cb = TOPI[:, sl][p34]
        sa = SV[:, sl][p12]; sb = SV[:, sl][p34]
        va = sa + lv1.take(Pflat, base34 + ca)
        vb = sb + lv1.take(Pflat, base12 + cb)
        vals = lv1.concat([va, vb], axis=0); c = lv1.concat([ca, cb], axis=0)
        arg = vals.argmax(); best = vals[arg]; cand = c[arg]
        if prev_best is not None:
            better = prev_best > best
            best = lv1.where(better, prev_best, best); cand = lv1.where(better, prev_arg, cand)
        ok = best > KVs[i][p12] + KVs[i][p34]
        nxt = stage(i+1, best, cand) if i+1 < len(Ks) else fallback
        return lv1.cond(ok, cand, nxt)
    return g.entry(interpretation=stage(0, None, None))

# sanity on tables
g = graph(); Ph, PI = build_tables2(g)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
Wn = U@H@E[:,:64]; PIv = PI.value; Phv = Ph.value
err = 0
for t1 in range(64):
    for t2 in range(64):
        err = max(err, np.abs(Phv[PIv[t1,t2]] - (Wn[:,t1]+Wn[:,t2])).max())
print('max table err', err, PIv.max(), PIv.min())
for Ks in [[3,5,8,12,16], [3,6,10,16]]:
    e = staged4(Ks); m = measure(e); print(Ks, {k: round(m[k],4) if isinstance(m[k], float) else m[k] for k in ['predict_ops','build_ops','cost','b','fidelity','reward']})
    save_entry('st4_' + '_'.join(map(str,Ks)), e)
print(len(e['nodes']) if isinstance(e, dict) and 'nodes' in e else type(e))
