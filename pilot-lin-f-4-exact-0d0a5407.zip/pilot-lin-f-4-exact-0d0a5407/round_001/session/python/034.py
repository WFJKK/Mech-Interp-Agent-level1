
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
L = (W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]).T
s = np.sort(L,1); gap = s[:,-1]-s[:,-2]
print('min gap', gap.min(), 'frac<1e-6', (gap<1e-6).mean(), 'frac<1e-4', (gap<1e-4).mean(), 'median', np.median(gap))
# check evaluator weight dtype
import inspect
src = inspect.getsource(lv1)
i = src.find('"weight"'); 
import re
for m in re.finditer(r'op == "weight"', src):
    print(src[m.start()-100:m.start()+400])
