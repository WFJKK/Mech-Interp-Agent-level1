
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
WT = W.T  # t, j
asrt = np.argsort(-WT, axis=1); srt = -np.sort(-WT,axis=1)
L = (W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]).T  # N x 64
for k in [4,6,8,10,12,16,20]:
    cands = np.concatenate([asrt[X[:,i],:k] for i in range(4)],1)  # N x 4k
    bound = sum(srt[X[:,i],k] for i in range(4))
    vals = np.take_along_axis(L,cands,1)
    best = vals.max(1); ok = best > bound
    pred = cands[np.arange(len(X)), vals.argmax(1)]
    cost_fast = 4*k + 4*k*3 + 4*k - 1 + 10
    print(k, 'ok %.3f'%ok.mean(), 'correct|ok', (pred[ok]==Y[ok]).mean(), 'fast ops', cost_fast, 'est cost %.3f'%((cost_fast + (1-ok.mean())*254)/671))
