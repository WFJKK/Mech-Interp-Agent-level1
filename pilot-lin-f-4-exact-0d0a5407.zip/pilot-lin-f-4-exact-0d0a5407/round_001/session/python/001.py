
print({k: (v if not hasattr(v,'shape') else v.shape) for k,v in info.items()})
for k,v in weights.items(): print(k, v.shape, v.dtype)
out = network_outputs()
print(type(out), len(out) if hasattr(out,'__len__') else '')
if isinstance(out, dict): print(out.keys())
