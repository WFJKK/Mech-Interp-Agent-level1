
import inspect, re
src = inspect.getsource(lv1)
for kw in ['op == "take"', 'op == "gather"', 'op == "cond"', 'op == "take_sum"', 'op in ALONG']:
    i = src.find(kw)
    print('-----', kw, i); print(src[i-100:i+900])
