
X, Y, ops = network_outputs()
X = np.array(X); Y = np.array(Y)
print(X.shape, Y.shape, ops)
print(X[:10], Y[:10])
# hypotheses
mx = X.max(1); mn = X.min(1); s = X.sum(1)%64
print('max', (Y==mx).mean(), 'min', (Y==mn).mean(), 'sum%64', (Y==s).mean())
for i in range(4): print('tok',i,(Y==X[:,i]).mean())
# sorted positions
srt = np.sort(X,1)
for i in range(4): print('sorted',i,(Y==srt[:,i]).mean())
print('median-ish', (Y==(s))[:5])
# distribution of Y
print(np.bincount(Y, minlength=64))
