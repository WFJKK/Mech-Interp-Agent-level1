
E32,H32,U32 = weights['embed'], weights['hidden'], weights['unembed']
g = graph(); W = g.weight('unembed') @ (g.weight('hidden') @ g.weight('embed')[:, :64]); print('entry W dtype', W.value.dtype, (W.T*2.0).value.dtype)
h = lv1.take_sum(g.weight("embed"), g.tokens(), axis=1); print('h dtype', h.value.dtype, (g.weight('hidden')@h).value.dtype)
E,H,U = E32.astype(np.float64), H32.astype(np.float64), U32.astype(np.float64)
W64 = U@H@E[:,:64]
W32 = U32 @ (H32 @ E32[:, :64]); print(W32.dtype)
rng = np.random.default_rng(5)
tot = 0; d_ref_truth = 0; d_mine_ref = 0; d_mine_truth = 0
for chunk in range(10):
    N = 300_000
    Xs = rng.integers(0,64,size=(N,4))
    hs = np.take(E32, Xs, axis=1).sum(axis=2)          # (8, N) float32, like the evaluator's take_sum
    l2 = U32 @ (H32 @ hs.astype(np.float64))           # weights float32 @ float64 -> float64
    ref = l2.argmax(0)
    Lt = (W64[:,Xs[:,0]]+W64[:,Xs[:,1]]+W64[:,Xs[:,2]]+W64[:,Xs[:,3]]); truth = Lt.argmax(0)
    mine = ((W32[:,Xs[:,0]] + W32[:,Xs[:,1]]) + (W32[:,Xs[:,2]] + W32[:,Xs[:,3]])).argmax(0)
    tot += N; d_ref_truth += (ref != truth).sum(); d_mine_ref += (mine != ref).sum(); d_mine_truth += (mine != truth).sum()
print(tot, 'ref vs truth', d_ref_truth, 'mine vs ref', d_mine_ref, 'mine vs truth', d_mine_truth)
