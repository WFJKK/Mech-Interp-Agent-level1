
import inspect, re
src = inspect.getsource(lv1)
idx = [m.start() for m in re.finditer(r'ceil|log2', src)]
print(len(src), idx[:10])
for s in idx[:2]:
    print(src[max(0,s-1500):s+800]); print("=========")
