
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
L = W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]
P = W[:,:,None]+W[:,None,:]
pa = P.argmax(0); freq = np.bincount(pa.ravel(), minlength=64); order = np.argsort(-freq)
T3 = P[:,:,:,None]+W[:,None,None,:]  # 64x64x64x64
for k in [8,12,16,20,24,32]:
    S = order[:k]; C = np.ones(64,bool); C[S]=False
    Q = P[C].max(0)   # 64x64
    best = L[S].max(0)
    bound22 = Q[X[:,0],X[:,1]] + Q[X[:,2],X[:,3]]
    ok22 = best > bound22
    Q3 = T3[C].max(0); Q1 = W[C].max(0)
    bound31 = Q3[X[:,0],X[:,1],X[:,2]] + Q1[X[:,3]]
    ok31 = best > bound31
    # exact check
    truth = (L[C].max(0) < best)
    cheap = 4*k + (k-1) + 2 + 1 + 1 + 1
    full = 256+63+2
    cost22 = (cheap + (1-ok22.mean())*full)/671
    print(k, 'ok22', ok22.mean(), 'ok31', ok31.mean(), 'exact-possible', truth.mean(), 'cost22 %.3f'%cost22, 'correct when ok', (pred:=L[S].argmax(0))[ok22].__eq__(0).mean() if False else (S[L[S].argmax(0)][ok22]==Y[ok22]).mean())
