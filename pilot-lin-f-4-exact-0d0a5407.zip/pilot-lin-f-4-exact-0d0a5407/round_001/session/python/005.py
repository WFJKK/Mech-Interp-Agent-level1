
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]   # 64 x 64
L = W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]  # 64 x N
pred = L.argmax(0); print('fidelity of W-sum', (pred==Y).mean())
# pair table argmax frequencies
P = W[:,:,None]+W[:,None,:]   # 64 x 64 x 64 (j,a,b)
pa = P.argmax(0)
freq = np.bincount(pa.ravel(), minlength=64)
print('pair argmax freq', freq)
# 4-token frequency from sample
f4 = np.bincount(Y, minlength=64)
order = np.argsort(-freq)
print('order by pair freq', order)
print('sample freq in that order', f4[order])
# pairwise domination
dom = np.array([[np.all(W[k]>W[j]) for k in range(64)] for j in range(64)])
print('rows dominated by some other row:', np.where(dom.any(1))[0])
