
import inspect
print([n for n in dir(lv1) if not n.startswith('_')])
g = graph()
print([n for n in dir(g) if not n.startswith('_')])
x = g.weight('embed')
print([n for n in dir(x) if not n.startswith('_')])
print(inspect.signature(lv1.take), inspect.signature(lv1.take_sum), inspect.signature(lv1.argsort), inspect.signature(lv1.cond))
print(inspect.getdoc(lv1.take)); print(inspect.getdoc(lv1.argsort)); print(inspect.getdoc(lv1.cond)); print(inspect.getdoc(lv1.gather) if hasattr(lv1,'gather') else '')
