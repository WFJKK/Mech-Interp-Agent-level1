
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
PT = (W[:,:,None]+W[:,None,:]).transpose(1,2,0)
L = (W[:,X[:,0]]+W[:,X[:,1]]+W[:,X[:,2]]+W[:,X[:,3]]).T; Lmax = L.max(1)
pairings = [((0,1),(2,3)), ((0,2),(1,3)), ((0,3),(1,2))]
S = {}
for pi,(u,v) in enumerate(pairings):
    A = PT[X[:,u[0]],X[:,u[1]]]; B = PT[X[:,v[0]],X[:,v[1]]]
    S[pi] = (-np.sort(-A,1), -np.sort(-B,1))
Ks = [1,2,3,4,6,8,12,16]
# two-sided: bound A_(K+1)+B_(K+1), best of 3 pairings chosen by K=2 bound
two = np.stack([np.stack([S[p][0][:,K]+S[p][1][:,K] for K in Ks],1) for p in range(3)],0)  # 3 x N x nK
sel2 = two[:,:,1].argmin(0)
ch2 = two[sel2, np.arange(len(X))]
print('two-sided (2K cands):', [(K, 2*K, (Lmax > ch2[:,i]).mean().round(3)) for i,K in enumerate(Ks)])
# one-sided: candidates top-K of A; bound A_(K+1)+B_(1); 6 orientations; choose by K=2 bound
one = []
for p in range(3):
    sa, sb = S[p]
    one.append(np.stack([sa[:,K]+sb[:,0] for K in Ks],1))
    one.append(np.stack([sb[:,K]+sa[:,0] for K in Ks],1))
one = np.stack(one,0)
for selK in [1,2,3]:
    sel1 = one[:,:,selK].argmin(0); ch1 = one[sel1, np.arange(len(X))]
    print('one-sided sel by K=%d (K cands):'%Ks[selK], [(K, K, (Lmax > ch1[:,i]).mean().round(3)) for i,K in enumerate(Ks)])
