
import inspect, re
src = inspect.getsource(lv1)
i = src.find('def price'); 
if i<0: i = src.find('PRICES')
# find function computing op cost
for m in re.finditer(r'def (\w*(cost|price|charge)\w*)\(', src):
    print(m.group(0), m.start())
j = src.find('def op_cost'); 
k = [m.start() for m in re.finditer(r'def (\w*(cost|price|charge)\w*)\(', src)]
for s in k[:3]:
    print(src[s:s+2500]); print('=======')
