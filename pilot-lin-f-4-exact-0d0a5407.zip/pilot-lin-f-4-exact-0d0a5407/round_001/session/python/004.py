
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
s = X.sum(1)
print('mean', (Y==s//4).mean(), 'round mean', (Y==np.round(s/4)).mean(), 'corr', np.corrcoef(Y, s)[0,1])
for f,name in [(lambda x: x.sum(1)%64,'sum%64'), (lambda x: x.prod(1)%64,'prod%64'), (lambda x: (x[:,0]+x[:,1])%64,'a+b'), (lambda x: (x[:,0]*x[:,1])%64,'ab'),(lambda x:(x[:,0]-x[:,1])%64,'a-b'),(lambda x: np.bitwise_xor.reduce(x,axis=1),'xor'),(lambda x: np.bitwise_and.reduce(x,axis=1),'and'),(lambda x: np.bitwise_or.reduce(x,axis=1),'or')]:
    print(name, (Y==f(X)).mean())
E,H,U = weights['embed'], weights['hidden'], weights['unembed']
W = U@H@E[:,:64]
print('n distinct outputs', len(set(Y.tolist())))
print(np.linalg.svd(U@H, compute_uv=False))
print(np.linalg.svd(E[:,:64], compute_uv=False))
print(np.linalg.svd(W, compute_uv=False)[:10])
# mode-of-tokens? most common token
def mode(x):
    out=[]
    for r in x:
        c=np.bincount(r,minlength=64); out.append(c.argmax())
    return np.array(out)
print('mode', (Y==mode(X)).mean())
print('corr with each token', [np.corrcoef(Y, X[:,i])[0,1] for i in range(4)])
print('corr with max', np.corrcoef(Y, X.max(1))[0,1], 'min', np.corrcoef(Y, X.min(1))[0,1])
