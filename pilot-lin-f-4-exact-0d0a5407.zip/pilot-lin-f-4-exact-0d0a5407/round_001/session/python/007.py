
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
P = W[:,:,None]+W[:,None,:]   # j,a,b
PT = np.transpose(P,(1,2,0))  # a,b,j
srt = np.sort(PT,axis=2)[:,:,::-1]; asrt = np.argsort(-PT,axis=2)
A = PT[X[:,0],X[:,1]]; B = PT[X[:,2],X[:,3]]   # N x 64
L = A+B; truth = L.argmax(1); print((truth==Y).mean())
for k in [2,3,4,6,8,12,16]:
    ca = asrt[X[:,0],X[:,1],:k]; cb = asrt[X[:,2],X[:,3],:k]
    Ak = srt[X[:,0],X[:,1],k]; Bk = srt[X[:,2],X[:,3],k]  # (k+1)-th largest
    bound = Ak+Bk
    va = np.take_along_axis(L,ca,1); vb = np.take_along_axis(L,cb,1)
    best = np.maximum(va.max(1), vb.max(1))
    ok = best > bound
    # correctness when ok
    cands = np.concatenate([ca,cb],1); vals = np.concatenate([va,vb],1)
    # argmax among candidates with lowest index on tie - approximate
    pred = cands[np.arange(len(X)), vals.argmax(1)]
    print(k, 'ok', ok.mean(), 'correct|ok', (pred[ok]==Y[ok]).mean(), 'est cost', (10*k+8 + (1-ok.mean())*254)/671)
