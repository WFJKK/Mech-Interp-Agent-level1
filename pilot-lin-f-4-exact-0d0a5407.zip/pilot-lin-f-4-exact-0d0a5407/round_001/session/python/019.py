
X, Y, ops = network_outputs(); X = np.array(X); Y = np.array(Y)
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
W = U@H@E[:,:64]
PT = (W[:,:,None]+W[:,None,:]).transpose(1,2,0)
A = PT[X[:,0],X[:,1]]; B = PT[X[:,2],X[:,3]]; L = A+B; N=len(X)
rank = np.argsort(np.argsort(-W, axis=0), axis=0)  # rank[j,t]
for topm in [4,8,16]:
    cnt = (rank < topm).sum(1)
    for Rsize in [24,32,40,48]:
        R = np.argsort(-cnt, kind='stable')[:Rsize]; nonR = np.setdiff1d(np.arange(64), R)
        AR = A[:,R]; BR = B[:,R]; sa = -np.sort(-AR,1); sb = -np.sort(-BR,1); oa = np.argsort(-AR,1); ob = np.argsort(-BR,1)
        mA = A[:,nonR].max(1); mB = B[:,nonR].max(1)
        out = []
        for K in [4,8,16]:
            c = np.concatenate([R[oa[:,:K]], R[ob[:,:K]]],1)
            best = np.take_along_axis(L,c,1).max(1)
            bound = np.maximum(sa[:,K], mA) + np.maximum(sb[:,K], mB)
            out.append(round((best>bound).mean(),3))
        print('topm',topm,'R',Rsize, out, 'argmax in R', np.isin(Y,R).mean())
