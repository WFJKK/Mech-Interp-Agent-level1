
import time
e = entries['st4_3_5_8_12_16']
# reference entry
gref = graph(); ref_entry = gref.entry(interpretation=model.reference(gref, lv1))
rng = np.random.default_rng(0)
for trial in range(4):
    w = {}
    for k,v in weights.items():
        scale = {'embed':1.0, 'hidden':0.5, 'unembed':0.7}[k]
        arr = (rng.standard_normal(v.shape) * scale).astype(np.float32)
        if k == 'embed': arr[:, 64] = 0
        w[k] = arr
    # also a degenerate variant: duplicate rows, zeros
    if trial == 3:
        w['unembed'][5] = w['unembed'][9]; w['embed'][:, 7] = w['embed'][:, 20]
    inputs = rng.integers(0, 64, size=(6000, 4))
    t0 = time.time()
    ans, mops = lv1.run_reference(ref_entry, w, 4, inputs)
    m = lv1.measure(e, w, 4, inputs, ans, mops)
    print(trial, {k: round(m[k],4) if isinstance(m[k], float) else m[k] for k in ['n_agree','n_in_region','cost','fidelity','reward']}, round(time.time()-t0,1))
