
import inspect, re
src = inspect.getsource(lv1)
# print cost-related snippets
for kw in ['def cost', '"gather"', '"take"', '"take_sum"', '"cond"', '"argsort"', '"sort"']:
    for m in re.finditer(re.escape(kw), src):
        s = max(0, m.start()-200); print('-----', kw); print(src[s:m.start()+500]); break
