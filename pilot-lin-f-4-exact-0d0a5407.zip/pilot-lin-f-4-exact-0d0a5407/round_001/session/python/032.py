
NP = 64*33
def build_tables3(g):
    E = g.weight('embed'); Hh = g.weight('hidden'); Uu = g.weight('unembed')
    W = Uu @ (Hh @ E[:, :64])
    Wt = W.T
    parts = [Wt * 2.0]
    for d in range(1, 33):
        parts.append(Wt + lv1.concat([Wt[d:], Wt[:d]], axis=0))
    Ph = lv1.stack(parts, axis=1).reshape(NP, 64)
    r = g.arange(64)
    t1 = r.reshape(64,1); t2 = r.reshape(1,64)
    dd = (t2 - t1) % 64
    PI = lv1.where(dd <= 32, t1*33 + dd, t2*33 + (64 - dd))
    return Ph, PI

def staged7(Ks, Kmax=16, npair=3):
    g = graph()
    Ph, PI = build_tables3(g)
    idx = lv1.argsort(Ph, axis=1)
    Pflat = Ph.reshape(NP*64)
    pbase = (g.arange(NP)*64).reshape(NP,1)
    TOPI = idx[:, 64-Kmax:]
    SV = lv1.take(Pflat, pbase + TOPI)
    KVs = [lv1.take(Pflat, (pbase + idx[:, 63-K:64-K])).reshape(NP) for K in Ks]
    t = [g.token(i) for i in range(4)]
    pairings = [((0,1),(2,3)), ((0,2),(1,3)), ((0,3),(1,2))][:npair]
    pf = []; ps = []; bnd = []
    for (u,v) in pairings:
        f = PI[t[u[0]], t[u[1]]]; s = PI[t[v[0]], t[v[1]]]
        pf.append(f); ps.append(s); bnd.append(KVs[0][f] + KVs[0][s])
    c01 = bnd[0] <= bnd[1]
    m01 = lv1.where(c01, bnd[0], bnd[1]); f01 = lv1.where(c01, pf[0], pf[1]); s01 = lv1.where(c01, ps[0], ps[1])
    if npair == 3:
        c2 = m01 <= bnd[2]
        bound1 = lv1.where(c2, m01, bnd[2]); p12 = lv1.where(c2, f01, pf[2]); p34 = lv1.where(c2, s01, ps[2])
    else:
        bound1, p12, p34 = m01, f01, s01
    base12 = p12*64; base34 = p34*64
    fallback = (Ph[p12] + Ph[p34]).argmax()
    def stage(i, prev_best, prev_arg):
        K = Ks[i]; K0 = Ks[i-1] if i > 0 else 0
        sl = slice(Kmax-K, Kmax-K0)
        ca = TOPI[:, sl][p12]; cb = TOPI[:, sl][p34]
        sa = SV[:, sl][p12]; sb = SV[:, sl][p34]
        va = sa + lv1.take(Pflat, base34 + ca)
        vb = sb + lv1.take(Pflat, base12 + cb)
        vals = lv1.concat([va, vb], axis=0); c = lv1.concat([ca, cb], axis=0)
        arg = vals.argmax(); best = vals[arg]; cand = c[arg]
        if prev_best is not None:
            better = prev_best > best
            best = lv1.where(better, prev_best, best); cand = lv1.where(better, prev_arg, cand)
        bd = bound1 if i == 0 else KVs[i][p12] + KVs[i][p34]
        ok = best > bd
        nxt = stage(i+1, best, cand) if i+1 < len(Ks) else fallback
        return lv1.cond(ok, cand, nxt)
    return g.entry(interpretation=stage(0, None, None))

for Ks, npair in [([2,4,6,9,12,16], 2), ([2,3,5,7,10,13,16], 3)]:
    e = staged7(Ks, 16, npair); m = measure(e); print(Ks, npair, len(e['nodes']), {k: round(m[k],4) if isinstance(m[k], float) else m[k] for k in ['predict_ops','build_ops','cost','b','fidelity','reward']})
    save_entry('st7_%d_'%npair + '_'.join(map(str,Ks)), e)
