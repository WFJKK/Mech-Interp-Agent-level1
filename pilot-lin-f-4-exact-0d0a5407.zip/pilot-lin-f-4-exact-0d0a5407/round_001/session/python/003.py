
s = X.sum(1)
print('mean', (Y==s//4).mean(), 'round mean', (Y==np.round(s/4)).mean(), 'corr', np.corrcoef(Y, s)[0,1])
for f,name in [(lambda x: x.sum(1)%64,'sum%64'), (lambda x: x.prod(1)%64,'prod%64'), (lambda x: (x[:,0]+x[:,1])%64,'a+b'), (lambda x: (x[:,0]*x[:,1])%64,'ab'),(lambda x:(x[:,0]-x[:,1])%64,'a-b'),(lambda x: np.bitwise_xor.reduce(x,axis=1),'xor'),(lambda x: np.bitwise_and.reduce(x,axis=1),'and'),(lambda x: np.bitwise_or.reduce(x,axis=1),'or')]:
    print(name, (Y==f(X)).mean())
# which rows of W=U H E are ever argmax
E,H,U = weights['embed'], weights['hidden'], weights['unembed']
W = U@H@E[:,:64]
print('ever argmax rows', sorted(set(Y.tolist())).__len__())
# W structure: look at singular values
print(np.linalg.svd(U@H, compute_uv=False))
print(np.linalg.svd(E[:,:64], compute_uv=False))
