
def build_tables(g):
    E = g.weight('embed'); Hh = g.weight('hidden'); Uu = g.weight('unembed')
    W = Uu @ (Hh @ E[:, :64])
    Wt = W.T
    q = 2079 - g.arange(2080)
    ap = lv1.cast((lv1.sqrt(lv1.cast(8*q+1, "float")) - 1.0) / 2.0, "int")
    bp = q - ap*(ap+1)//2
    a = 63 - ap; b = 63 - bp
    Ph = lv1.take(Wt, a, 0) + lv1.take(Wt, b, 0)
    r = g.arange(64)
    lo = lv1.minimum(r.reshape(64,1), r.reshape(1,64)); hi = lv1.maximum(r.reshape(64,1), r.reshape(1,64))
    PI = 64*lo - lo*(lo-1)//2 + hi - lo
    return Ph, PI

# plain pair entry
g = graph()
Ph, PI = build_tables(g)
t = [g.token(i) for i in range(4)]
p12 = PI[t[0], t[1]]; p34 = PI[t[2], t[3]]
full = (Ph[p12] + Ph[p34]).argmax()
e_plain = g.entry(interpretation=full)
m = measure(e_plain); print('plain', m)
save_entry('pair_plain', e_plain)

# staged entry
def staged(Ks):
    g = graph()
    Ph, PI = build_tables(g)
    idx = lv1.argsort(Ph, axis=1)
    Pflat = Ph.reshape(2080*64)
    t = [g.token(i) for i in range(4)]
    p12 = PI[t[0], t[1]]; p34 = PI[t[2], t[3]]
    base12 = p12*64; base34 = p34*64
    fallback = (Ph[p12] + Ph[p34]).argmax()
    # build stages from the last to the first
    def stage(i, prev_best, prev_arg):
        K = Ks[i]; K0 = Ks[i-1] if i > 0 else 0
        TOP = idx[:, 64-K:64-K0]           # ranks K0..K-1 (ascending order)
        ca = TOP[p12]; cb = TOP[p34]
        c = lv1.concat([ca, cb], axis=0)
        vals = lv1.take(Pflat, base12 + c) + lv1.take(Pflat, base34 + c)
        arg = vals.argmax(); best = vals[arg]; cand = c[arg]
        if prev_best is not None:
            better = prev_best > best
            best = lv1.where(better, prev_best, best); cand = lv1.where(better, prev_arg, cand)
        kcol = idx[:, 63-K]
        vA = Pflat[base12 + kcol[p12]]; vB = Pflat[base34 + kcol[p34]]
        ok = best > vA + vB
        if i+1 < len(Ks):
            nxt = stage(i+1, best, cand)
        else:
            nxt = fallback
        return lv1.cond(ok, cand, nxt)
    out = stage(0, None, None)
    return g.entry(interpretation=out)

for Ks in [[8], [4,12], [3,8,16], [4,8,16]]:
    e = staged(Ks); m = measure(e); print(Ks, m)
    save_entry('staged_' + '_'.join(map(str,Ks)), e)
