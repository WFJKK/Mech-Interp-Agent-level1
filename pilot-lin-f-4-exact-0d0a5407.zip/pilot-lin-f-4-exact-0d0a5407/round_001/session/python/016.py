
def build_tables(g, K):
    E = g.weight('embed'); Hh = g.weight('hidden'); Uu = g.weight('unembed')
    W = Uu @ (Hh @ E[:, :64])      # (j, t)
    Wt = W.T                        # (t, j)
    q = 2079 - g.arange(2080)
    ap = lv1.cast((lv1.sqrt(lv1.cast(8*q+1, "float")) - 1.0) / 2.0, "int")
    bp = q - ap*(ap+1)//2
    a = 63 - ap; b = 63 - bp
    Ph = lv1.take(Wt, a, 0) + lv1.take(Wt, b, 0)   # 2080 x 64
    r = g.arange(64)
    lo = lv1.minimum(r.reshape(64,1), r.reshape(1,64)); hi = lv1.maximum(r.reshape(64,1), r.reshape(1,64))
    PI = 64*lo - lo*(lo-1)//2 + hi - lo
    idx = lv1.argsort(Ph, axis=1)
    return W, Ph, PI, idx, a, b

g = graph()
W, Ph, PI, idx, a, b = build_tables(g, 8)
# verify
E,H,U = weights['embed'].astype(np.float64), weights['hidden'].astype(np.float64), weights['unembed'].astype(np.float64)
Wn = U@H@E[:,:64]
print(np.abs(W.value - Wn).max())
av, bv = a.value, b.value
print(av[:5], bv[:5], av[-5:], bv[-5:], (av<=bv).all(), len(set(zip(av,bv))))
PIv = PI.value
print(PIv[0,0], PIv[0,1], PIv[63,63], PIv[5,3], av[PIv[5,3]], bv[PIv[5,3]], PIv.max())
Phv = Ph.value
print(np.abs(Phv - (Wn[:,av]+Wn[:,bv]).T).max())
print(idx.shape, idx.value[0,-3:], np.argsort(Phv[0])[-3:])
