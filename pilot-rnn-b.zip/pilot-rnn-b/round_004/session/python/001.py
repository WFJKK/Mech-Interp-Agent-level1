
import json, numpy as np, time
print(info)
print(list(entries.keys()))
print(json.dumps(entries['best'])[:1500])
print(measure(entries['best']))
