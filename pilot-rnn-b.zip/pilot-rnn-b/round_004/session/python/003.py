
X, Y, ops = no
X = np.asarray(X, float); Y = np.asarray(Y)
print(X.shape, Y.shape, ops, (net(X)==Y).mean())
rng = np.random.default_rng(1)
N = 8_000_000
Xb = rng.standard_normal((N,3)); Yb = net(Xb)
x0,x1,x2 = Xb.T
d = x1-x2
c1 = x0>x1; c2 = d<0
def wilson_low(p, n, z=1.96):
    den = 1+z*z/n; c = p + z*z/(2*n); m = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))
    return (c-m)/den
def reward(region, pred, ops_region, ops_pred_mean, n=16384):
    cov = region.mean(); fid = (pred[region]==Yb[region]).mean()
    fl = wilson_low(fid, n*cov)
    cost = (ops_region + ops_pred_mean*cov)/cov/78
    return cov*((1-cost) - 10*(1-fl)), cov, fid, cost
def tree(k_min=1.0, k_max=1.0):
    # c1 true & c2 false: x1 min -> median = 2 if x2 < k*x0 else 0
    # c1 false & c2 true: x1 max -> median = 2 if x2 > k*x0 else 0
    pred = np.ones(N, int)
    m = c1 & ~c2; pred[m] = np.where(x2[m] < k_min*x0[m], 2, 0)
    m = ~c1 & c2; pred[m] = np.where(x2[m] > k_max*x0[m], 2, 0)
    return pred
base = tree()
for t in [0.04,0.045,0.05,0.055,0.06]:
    print(t, reward(np.abs(d)>t, base, 3, 16/3))
