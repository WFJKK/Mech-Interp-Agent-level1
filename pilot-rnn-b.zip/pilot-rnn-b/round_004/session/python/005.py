
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(1)
N = 8_000_000
Xb = rng.standard_normal((N,3)); Yb = net(Xb)
x0,x1,x2 = Xb.T
d = x1-x2
c1 = x0>x1; c2 = d<0   # c2: x1 < x2
def wilson_low(p, n, z=1.96):
    den = 1+z*z/n; c = p + z*z/(2*n); m = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))
    return (c-m)/den
def reward(region, pred, ops_region, ops_pred_mean, n=16384):
    cov = region.mean(); fid = (pred[region]==Yb[region]).mean()
    fl = wilson_low(fid, n*cov)
    cost = (ops_region + ops_pred_mean*cov)/cov/78
    return round(cov*((1-cost) - 10*(1-fl)),4), round(cov,4), round(fid,5), round(cost,4)
def tree(k_min=1.0, k_max=1.0):
    pred = np.ones(N, int)
    m = c1 & c2; pred[m] = np.where(x2[m] < k_min*x0[m], 2, 0)      # x1 min
    m = ~c1 & ~c2; pred[m] = np.where(x2[m] > k_max*x0[m], 2, 0)    # x1 max
    return pred
base = tree()
print('plain', (base==Yb).mean())
for t in [0.04,0.045,0.05,0.055,0.06]:
    print(t, reward(np.abs(d)>t, base, 3, 16/3))
reg = np.abs(d)>0.05
for k in [0.99,0.995,1.0,1.005,1.007,1.01,1.015]:
    print('kmin',k, reward(reg, tree(k_min=k), 3, 16/3+1/3), 'kmax', k, reward(reg, tree(k_max=k), 3, 16/3+1/3))
