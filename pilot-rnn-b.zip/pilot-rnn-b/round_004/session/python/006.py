
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(2)
N = 8_000_000
Xb = rng.standard_normal((N,3)); Yb = net(Xb)
x0,x1,x2 = Xb.T
med = np.argsort(Xb,1)[:,1]
reg = np.abs(x1-x2)>0.05
err = (med!=Yb) & reg
print('err rate in region', err.sum()/reg.sum())
E = Xb[err]; ye = Yb[err]; me = med[err]
from collections import Counter
print(Counter(zip(me.tolist(), ye.tolist())))
# geometry: distances
for (m,y),cnt in sorted(Counter(zip(me.tolist(), ye.tolist())).items()):
    s = (me==m)&(ye==y); Z = E[s]
    print(m,y,cnt, 'mean |x0-x2|/|x0|', np.median(np.abs(Z[:,0]-Z[:,2])/np.abs(Z[:,0])), ' |x0-x1|/|x0|', np.median(np.abs(Z[:,0]-Z[:,1])/np.abs(Z[:,0])),
          'sign x0', np.mean(Z[:,0]>0), 'sign x1', np.mean(Z[:,1]>0), 'sign x2', np.mean(Z[:,2]>0), 'sign x0*x1>0', np.mean(Z[:,0]*Z[:,1]>0))
