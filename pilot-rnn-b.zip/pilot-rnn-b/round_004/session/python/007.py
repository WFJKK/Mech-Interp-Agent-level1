
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def net(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(3)
N = 8_000_000
Xb = rng.standard_normal((N,3)); Yb = net(Xb)
x0,x1,x2 = Xb.T
d = x1-x2; reg = np.abs(d)>0.05
c1 = x0>x1; c2 = d<0
bmin = reg & c1 & c2      # x1 min: median = 2 if x2 < x0 else 0
bmax = reg & ~c1 & ~c2    # x1 max: median = 2 if x2 > x0 else 0
print('branch sizes', bmin.sum()/N, bmax.sum()/N)
def errs(mask, a, b, lower):
    m = mask
    thr = a*x0[m] + b*x1[m]
    pred = np.where(x2[m] < thr, 2, 0) if lower else np.where(x2[m] > thr, 2, 0)
    return (pred != Yb[m]).sum()/N
print('base err min-branch', errs(bmin,1,0,True), 'max-branch', errs(bmax,1,0,False))
best=None
for a in np.arange(0.995,1.0151,0.0025):
    for b in np.arange(-0.03,0.0301,0.005):
        e1 = errs(bmin,a,b,True); e2 = errs(bmax,a,b,False)
        if best is None or e1+e2 < best[0]: best=(e1+e2,a,b,e1,e2)
print(best)
# also per-branch optimum
for mask,lower,name in [(bmin,True,'min'),(bmax,False,'max')]:
    bb=None
    for a in np.arange(0.995,1.0151,0.0025):
        for b in np.arange(-0.03,0.0301,0.005):
            e = errs(mask,a,b,lower)
            if bb is None or e<bb[0]: bb=(e,a,b)
    print(name, bb)
