
e = entries['best']
print(measure(e))
g, pred, rule = lv1.Graph.load(e, weights, info['n_ctx'])
print(info.get('check'), info['sizes'] if 'sizes' in info else '')
