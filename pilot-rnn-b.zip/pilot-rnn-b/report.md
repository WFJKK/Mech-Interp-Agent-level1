# Run pilot-rnn-b

- Model models/rnn-b, rounds on rnn-b-s0, seed check on rnn-b-s4.
- Agent: claude-fable-5-1 at effort high, through the claude_code backend.
- Data set: real-valued inputs, 16,384 drawn afresh for each scoring. One forward pass: 78 operations (prices-v1).
- Reward: r_alpha, alpha = 10.
- Sandbox: seatbelt.
- The rounds ended: rounds_max (5) reached.

## The locked entry

Submission r3s1 (saved as `best`), 18 nodes, 4 numbers in constants, sha256 `3a8820b426958f26`.

| Network | Reward | Coverage | Fidelity | Cost | Fidelity claimed |
| --- | --- | --- | --- | --- | --- |
| rnn-b-s0 (the rounds) | 0.8262 | 0.9699 | 0.99698 | 0.1082 | 0.99500 |
| rnn-b-s0 (measured again, on a fresh sample) | 0.8179 | 0.9728 | 0.99598 | 0.1080 | 0.99500 |
| rnn-b-s4 (the seed check) | 0.4091 | 0.9716 | 0.95621 | 0.1081 | 0.98500 |

The first row is the best of several scorings, each on its own sample, so it leans high; the second row is one more scoring of the same entry.

```
n0 = token(i=0)
n1 = token(i=1)
n2 = token(i=2)
n3 = sub(n1, n2)
n4 = abs(n3)
n5 = const(dtype="float", value=0.05)
n6 = gt(n4, n5)   <- region
n7 = gt(n0, n1)
n8 = const(dtype="int", value=0)
n9 = lt(n3, n8)
n10 = gt(n2, n0)
n11 = const(dtype="int", value=2)
n12 = cond(n10, n8, n11)
n13 = cond(n10, n11, n8)
n14 = const(dtype="int", value=1)
n15 = cond(n9, n12, n14)
n16 = cond(n9, n14, n13)
n17 = cond(n7, n15, n16)   <- interpretation
```

## Against the baseline

The baseline run pilot-rnn-e-exact-0d0a5407 froze r5s3, which **passes** the check on its model's other networks (it gave the network's output on every input of its region on all 3 networks). Its agent was given the same first prompt as this run's, byte for byte, but for the paragraph that asks for an entry exact for any weights: yes.

| | On rnn-b-s0 (this run's network) | On rnn-b-s4 (held out) |
| --- | --- | --- |
| The locked entry | 0.8179 to 0.8372 | 0.4091 to 0.4709 |
| The baseline, on the same inputs | 0.4939 to 0.4962 | 0.4828 to 0.4851 |
| The locked entry above the baseline | +0.3240 | -0.0736 |

| Part | Reward | With the sampling intervals |
| --- | --- | --- |
| The baseline on this run's network | 0.4939 | 0.4939 to 0.4962 |
| The excess kept on the held-out network | -0.0736 | -0.0760 to -0.0118 |
| The gap between this run's network and the held-out one | +0.3977 | +0.3335 to +0.4193 |
| Together: the locked entry on this run's network | 0.8179 | |

Each number is measured on the same inputs as the locked entry's own: its second scoring, on a fresh sample, and the seed check. The baseline's entry is exact on both, so it differs from the locked entry there only in what it costs and in what the locked entry gets wrong. This is accounting, not a causal split. The baseline is a generic score an agent reached, not the best possible one, so the excess can hold generic tricks the baseline run did not find as well as what the networks learned; and the gap can be sampling noise or a difference between the two networks as well as fitting this run's own network.

## Reference entries

Scored here for comparison. They are withheld from the agent. Each number is the mean of 8 scorings on fixed samples. The task: The network was trained to output the position of the second-largest of its three numbers (2nd argmax, x.argsort()[-2]); with three numbers that is the position of the median. It was trained on inputs drawn exactly as the data set says, fresh at every step, so the data set is what it was trained on. It is one of the networks of ARC's AlgZoo, which trains networks this small on algorithmic tasks and publishes them uninterpreted, as a challenge to explain them; AlgZoo's own chart puts this size at 98.5% (its best of five seeds, seed 0; measured here 98.43%, on another sample and in float64).


| Entry | Network | Reward | Coverage | Fidelity | Cost | Reward, highest less lowest |
| --- | --- | --- | --- | --- | --- | --- |
| folded_first_step | rnn-b-s0 | 0.2284 | 1.0000 | 1.00000 | 0.7693 | 0.0000 |
| folded_first_step | rnn-b-s4 | 0.2284 | 1.0000 | 1.00000 | 0.7693 | 0.0000 |
| target | rnn-b-s0 | 0.7440 | 1.0000 | 0.98412 | 0.0769 | 0.0388 |
| target | rnn-b-s4 | 0.3324 | 1.0000 | 0.94454 | 0.0769 | 0.0578 |
| the network itself | rnn-b-s0 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |
| the network itself | rnn-b-s4 | -0.0023 | 1.0000 | 1.00000 | 1.0000 | 0.0000 |

## Rounds

| Round | Submissions | Best reward so far | Raised it | Ended with | Tool calls | Minutes | Output tokens | Programs run | Sandbox minutes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2 | 0.7695 | yes | end_turn | 22 run_python, 2 submit_entry | 12.9 | 56,579 | 22 | 0.6 |
| 2 | 4 | 0.8091 | yes | end_turn | 18 run_python, 4 submit_entry | 8.3 | 35,154 | 18 | 0.4 |
| 3 | 4 | 0.8262 | yes | end_turn | 14 run_python, 4 submit_entry | 8.3 | 34,858 | 14 | 0.2 |
| 4 | 4 | 0.8262 | no | end_turn | 7 run_python, 4 submit_entry | 6.6 | 24,584 | 7 | 1.1 |
| 5 | 4 | 0.8262 | no | end_turn | 1 run_python, 4 submit_entry | 1.8 | 6,726 | 1 | 0.0 |

The rounds were billed to an API key: $11.48 by Claude Code's count.

## What the agent ran

Every program is kept in full in its round's `session/python/` folder, with what it got back; the round's `response.md` has what the agent wrote, and `stream_NN.jsonl` everything the CLI emitted.

The guard inside Python refused nothing: no program tried to reach files outside its folder, the network or other programs.

No program's text reaches for files or the system.

## Submissions

Cost: everything the entry computes, per input of its region, over one forward pass. Right and wrong: the share of the inputs the entry answers rightly and wrongly. On the frontier: no other submission is at least as good in right share, wrong share and cost, and better in one. On the second network: the reward and the fidelity of the same entry on the seed check's network, every submission on one fixed sample, scored after its round; the agent never saw these, and they chose nothing.

| Entry | Saved as | Reward | Coverage | Fidelity | Cost | Right | Wrong | On the frontier | Claimed | Overclaim | On the second network | Fidelity there |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | `median_adaptive` | 0.7695 | 1.0000 | 0.98572 | 0.0684 | 0.9857 | 0.01428 | no | 0.98400 | 0.00000 | 0.3156 | 0.94208 |
| r1s2 | `median_adaptive` | 0.7695 | 1.0000 | 0.98572 | 0.0683 | 0.9857 | 0.01428 | yes | 0.98400 | 0.00000 | 0.3156 | 0.94208 |
| r2s1 | `median_slab05` | 0.8000 | 0.9711 | 0.99447 | 0.1081 | 0.9658 | 0.00537 | no | 0.99500 | 0.00053 | 0.3624 | 0.95159 |
| r2s2 | `median_slab045` | 0.8079 | 0.9742 | 0.99493 | 0.1078 | 0.9693 | 0.00494 | yes | 0.99500 | 0.00007 | 0.3541 | 0.95065 |
| r2s3 | `median_slab045` | 0.8027 | 0.9753 | 0.99437 | 0.1078 | 0.9698 | 0.00549 | yes | 0.99500 | 0.00063 | 0.3541 | 0.95065 |
| r2s4 | `median_slab05` | 0.8091 | 0.9730 | 0.99517 | 0.1081 | 0.9683 | 0.00470 | no | 0.99470 | 0.00000 | 0.3624 | 0.95159 |
| r3s1 | `best` | 0.8262 | 0.9699 | 0.99698 | 0.1082 | 0.9670 | 0.00293 | yes | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r3s2 | `best` | 0.8140 | 0.9730 | 0.99561 | 0.1080 | 0.9688 | 0.00427 | yes | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r3s3 | `r2s2` | 0.8045 | 0.9715 | 0.99485 | 0.1080 | 0.9665 | 0.00500 | no | 0.99500 | 0.00015 | 0.3541 | 0.95065 |
| r3s4 | `best` | 0.8108 | 0.9747 | 0.99518 | 0.1080 | 0.9700 | 0.00470 | yes | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r4s1 | `best` | 0.8161 | 0.9702 | 0.99604 | 0.1082 | 0.9664 | 0.00385 | no | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r4s2 | `best` | 0.8088 | 0.9711 | 0.99529 | 0.1081 | 0.9666 | 0.00458 | no | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r4s3 | `best` | 0.8189 | 0.9716 | 0.99617 | 0.1080 | 0.9679 | 0.00372 | yes | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r4s4 | `best` | 0.8067 | 0.9711 | 0.99510 | 0.1082 | 0.9663 | 0.00476 | no | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r5s1 | `best` | 0.8058 | 0.9728 | 0.99486 | 0.1079 | 0.9678 | 0.00500 | no | 0.99500 | 0.00014 | 0.3624 | 0.95159 |
| r5s2 | `best` | 0.8030 | 0.9714 | 0.99472 | 0.1081 | 0.9662 | 0.00513 | no | 0.99500 | 0.00028 | 0.3624 | 0.95159 |
| r5s3 | `best` | 0.8109 | 0.9736 | 0.99530 | 0.1082 | 0.9690 | 0.00458 | yes | 0.99500 | 0.00000 | 0.3624 | 0.95159 |
| r5s4 | `best` | 0.8075 | 0.9720 | 0.99510 | 0.1082 | 0.9673 | 0.00476 | no | 0.99500 | 0.00000 | 0.3624 | 0.95159 |

On the second network the best submission was r2s1 (`median_slab05`), 0.3624; the locked entry, r3s1, scored 0.3624 there on the same sample.

## The agent's closing notes

> ## What the network does
> The network outputs the **position of the median** of (x_0, x_1, x_2): 0 if x_0 lies between the other two, 1 if x_1 does, 2 if x_2 does. The plain median rule agrees with it on ≈98.46% of standard‑normal inputs (8M‑sample estimate from a numpy forward pass verified 100% against `network_outputs()`). The network is bias‑free, hence scale‑invariant, so every disagreement is a thin cone around a tie plane: (1) the dominant artifact (~1.2% of inputs) is a wedge around x_1 ≈ x_2 where it outputs 0 instead of 1/2; |x_1−x_2| < 0.05 holds ~97% of it; (2) after excluding that slab, ~0.44–0.5% remain wrong, mostly at x_0 ≈ x_2 within ~1% relative (median 0 → net 2, and the reverse when all three are close) and at x_0 ≈ x_1 within ~0.4% (0 → 1), with pattern‑dependent kinks, not simple tilts. Very confident in the median semantics; the artifacts are seed‑specific.
> 
> ## How you found it
> Both weights and outputs across the rounds: input weights split the 4 hidden units into a mirror‑symmetric positive/negative pair, readout rows ≈ multiples of (−1,1,1,−1), so the output depends on a ratio of hidden sums with two thresholds; candidate rules were tested on samples (median position wins), ReLU activation patterns enumerated to get exact decision planes, errors mapped in the normalized (x_1/x_0, x_2/x_0) plane and along 1‑D scans. Candidate regions (absolute/relative/product slabs, widths 0.03–0.07) and interpretation variants (per‑branch tilts, extra slabs, vector/cond reformulations) were scored with the exact reward formula including the Wilson lower‑CI fidelity. This round I only re‑measured `best` locally (0.80 on the fixed sample) and spent the four submissions drawing fresh verifier samples on it (0.8058, 0.8030, 0.8109, 0.8075).
> 
> ## The best entry
> `best` (= `median_slab05`; locked maximum 0.8262 from round 3; across 14 verifier samples 0.800–0.826, mean ≈0.81). Region: |x_1 − x_2| > 0.05 (3 ops on every input: subtract, abs, compare; coverage ≈97.2%). Interpretation: an adaptive median comparison tree using `lv1.cond`: c1 = x_0 > x_1, c2 = (x_1 − x_2) < 0 (reusing the region's difference); if c1 == c2 (x_1 is an extreme) a third compare x_2 vs x_0 picks 0 or 2, otherwise 1. ≈5.33 ops per input in the region, no build, no weight‑derived constants; total cost ≈0.108 of a forward pass; fidelity 0.9944–0.9970 on verifier samples. The saving comes from replacing the recurrent pass by ≤3 scalar comparisons and excluding the x_1≈x_2 wedge (≈75% of the median rule's errors) for 3 ops and ~2.8% coverage.
> 
> ## Claims
> Claimed fidelity on this network: 0.995 (large‑sample 0.9955; verifier samples 0.9944–0.9970, this round 0.9947–0.9953, overclaim ≤0.0003). Expected on the second network: 0.985 — a network trained the same way should learn the median rule equally well, but its tie artifacts may lie on planes the slab does not cover; nothing in the entry is read off this network's weights except the slab width.
> 
> ## Next
> Nothing found beats `best` in expectation: the family is at its 8.33‑op cost floor (≈0.107), with residual error ≈0.45% (≈0.045), coverage loss ≈2.8% (≈0.027) and Wilson penalty ≈0.011. Rejected over the rounds: other slab widths (flat 0.04–0.06), relative/product/one‑sided regions, tilted third comparisons, extra slabs at x_0≈x_2, arithmetic/argsort/where formulations of the median (≥5.33 ops), exact activation‑pattern emulation (≥30 ops). If more rounds existed, the only remaining lever would be resubmission for sampling noise (SD ≈0.008 per sample).
