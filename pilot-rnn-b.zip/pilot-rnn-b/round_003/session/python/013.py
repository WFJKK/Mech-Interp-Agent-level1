
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(5)
N=6_000_000
X=rng.standard_normal((N,3)); Y=net(X)
x0,x1,x2=X.T
d=x1-x2
med=np.argsort(X,axis=1)[:,1]
err=med!=Y
small=np.abs(d)<0.045
print("errors with |d|<0.045:", (err&small).sum(), " of which d>0:", (err&small&(d>0)).sum(), " d<0:", (err&small&(d<0)).sum())
# by sign of x0 as well
for s0 in [1,-1]:
    for sd in [1,-1]:
        m=err&small&(np.sign(x0)==s0)&(np.sign(d)==sd)
        print("sign x0",s0,"sign d",sd, m.sum())
# histogram of d for wedge errors
h,edges=np.histogram(d[err&small],bins=np.linspace(-0.045,0.045,19))
print(np.round(edges,3)); print(h)
