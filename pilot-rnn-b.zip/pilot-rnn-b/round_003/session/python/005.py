
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(1)
N=4_000_000
X=rng.standard_normal((N,3)); Y=net(X)
med=np.argsort(X,axis=1)[:,1]
ok=(med==Y)
print("median agree",ok.mean())
def wil(p,n,z=1.959964):
    return ((p+z*z/(2*n)) - z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
def reward(region, correct, rule_ops, pred_ops=16/3, build=0, n_s=16384):
    cov=region.mean(); fid=correct[region].mean()
    n=n_s*cov
    cost=(build/n + rule_ops/cov + pred_ops)/78
    fl=wil(fid,n)
    return cov*((1-cost)-10*(1-fl)), cov, fid, cost
x0,x1,x2=X.T
d=x1-x2
print("none", reward(np.ones(N,bool), ok, 0))
for t in [0.03,0.04,0.045,0.05,0.055,0.06,0.07]:
    print("slab",t, reward(np.abs(d)>t, ok, 3))
for t in [0.02,0.03,0.04,0.05,0.06,0.08]:
    print("rel x0",t, reward(np.abs(d/x0)>t, ok, 4))
e=x0-x1
for t in [0.02,0.03,0.04,0.05,0.06,0.08]:
    print("rel e",t, reward(np.abs(d/e)>t, ok, 5))
