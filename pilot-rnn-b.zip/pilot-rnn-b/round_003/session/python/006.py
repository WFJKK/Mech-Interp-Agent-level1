
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(2)
N=6_000_000
X=rng.standard_normal((N,3)); Y=net(X)
med=np.argsort(X,axis=1)[:,1]
ok=(med==Y)
x0,x1,x2=X.T
d=x1-x2
reg=np.abs(d)>0.045
err=reg&~ok
print("err rate in region", err.sum()/reg.sum(), err.sum())
from collections import Counter
print(Counter(zip(med[err],Y[err])))
# what's the closest pair for errors
E=X[err]
dif=np.stack([np.abs(E[:,0]-E[:,1]),np.abs(E[:,0]-E[:,2]),np.abs(E[:,1]-E[:,2])],1)
print(Counter(dif.argmin(1)))
# for errors with closest pair (0,2): distribution of |x0-x2| and |x0-x2|/scale
m=dif.argmin(1)==1
print(np.percentile(dif[m,1],[10,50,90,99]))
print(np.percentile(dif[m,1]/np.abs(E[m]).max(1),[10,50,90,99]))
m0=dif.argmin(1)==0
print(np.percentile(dif[m0,0],[10,50,90,99]))
print(np.percentile(dif[m0,0]/np.abs(E[m0]).max(1),[10,50,90,99]))
# signs of errors: by (med,Y) and sign of x0, x1
for key in [(0,2),(2,0),(0,1),(1,0),(1,2),(2,1)]:
    mk=err & (med==key[0]) & (Y==key[1])
    print(key, mk.sum(), "sign x0,x1,x2 mean:", np.sign(X[mk]).mean(0).round(2), "mean |x|", np.abs(X[mk]).mean(0).round(2))
