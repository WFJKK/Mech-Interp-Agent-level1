
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
# branch x1 min: x1=-1 or x1 = +1 (max). For x0 = a, scan x2 near a and find switching points.
def boundary(x1, a_list, lo=-0.3, hi=0.3, n=6001):
    out=[]
    for a in a_list:
        x2=a+np.linspace(lo,hi,n)
        Xs=np.stack([np.full(n,a),np.full(n,x1),x2],1)
        y=net(Xs)
        # find transitions
        tr=np.nonzero(np.diff(y)!=0)[0]
        out.append((a, [(round(x2[i]-a,4), int(y[i]), int(y[i+1])) for i in tr]))
    return out
for x1 in [-1.0, 1.0]:
    print("x1=",x1)
    for a,tr in boundary(x1, [-3,-2,-1.5,-1.2,-0.9,-0.6,-0.3,-0.1,0.1,0.3,0.6,0.9,1.2,1.5,2,3]):
        print("  a=",a, tr)
