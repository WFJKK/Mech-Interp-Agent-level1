
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(4)
N=8_000_000
X=rng.standard_normal((N,3)); Y=net(X)
x0,x1,x2=X.T
d=x1-x2
c1=x0>x1; c2=d<0
reg=np.abs(d)>0.045
for name,mask,sgn in [("A x1min",c1&c2&reg,1),("B x1max",~c1&~c2&reg,-1)]:
    near=mask&(np.abs(x2-x0)<0.15)
    a0,a1,a2,y=x0[near],x1[near],x2[near],Y[near]
    print(name, near.sum(), "far errors:", ((Y!=np.where(sgn*(x2-x0)>0,0,2))&mask&~near).sum())
    best=None
    for k in np.arange(1.000,1.0141,0.001):
        for m in np.arange(-0.004,0.0161,0.001):
            pred=np.where(sgn*(a2-k*a0+m*a1)>0,0,2)
            err=(pred!=y).sum()
            if best is None or err<best[0]: best=(err,k,m)
    print("  best k,m:",best, "base err:", (np.where(sgn*(a2-a0)>0,0,2)!=y).sum(), "of total region", reg.sum())
