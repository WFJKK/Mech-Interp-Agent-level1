
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
# check against network_outputs
no=network_outputs()
print(type(no), (no.keys() if isinstance(no,dict) else len(no)))
