
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
no=network_outputs()
X,Y,ops=no
X=np.asarray(X,dtype=float); Y=np.asarray(Y)
print(X.shape,Y.shape,ops, (net(X)==Y).mean())
n,k=15920,15831; p=k/n; z=1.959964
wil=( (p+z*z/(2*n)) - z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)) )/(1+z*z/n)
print("wilson",wil, "normal", p-z*math.sqrt(p*(1-p)/n))
