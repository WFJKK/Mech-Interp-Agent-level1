
import json, numpy as np
print(info)
print({k:v.shape for k,v in weights.items()})
for k,v in weights.items(): print(k, np.round(v,4))
e = entries['best']
print(json.dumps(e)[:3000])
print(measure(e))
