
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(3)
N=6_000_000
X=rng.standard_normal((N,3)); Y=net(X)
x0,x1,x2=X.T
d=x1-x2; e=x0-x1
c1=x0>x1; c2=d<0
def wil(p,n,z=1.959964):
    return ((p+z*z/(2*n)) - z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
def reward(region, correct, rule_ops, pred_ops, build=0, n_s=16384):
    cov=region.mean(); fid=correct[region].mean(); n=n_s*cov
    cost=(build/n + rule_ops/cov + pred_ops)/78
    return round(cov*((1-cost)-10*(1-wil(fid,n))),4), round(cov,4), round(fid,5), round(cost,4)
def tree(innerA, innerB):
    # innerA: bool 'x0 is median' in branch x1-min (c1 & ~c2); innerB: same in x1-max (~c1 & c2)
    out=np.ones(N,int)
    mA=c1&~c2; mB=~c1&c2
    out[mA]=np.where(innerA[mA],0,2)
    out[mB]=np.where(innerB[mB],0,2)
    return out
reg=np.abs(d)>0.045
base=tree(x2>x0, x0>x2)
print("base", reward(reg, base==Y, 3, 16/3))
for p in [0.004,0.006,0.007,0.008,0.01]:
    k=1+p
    pred=tree(d < -k*e, d > -k*e)
    print("e-form p",p, reward(reg, pred==Y, 3, 7))
for k in [1.004,1.006,1.008,1.01]:
    pred=tree(x2>k*x0, x2<k*x0)
    print("kx0 k",k, reward(reg, pred==Y, 3, 6))
for (k,m,k2,m2) in [(1.007,0.011,1.0055,0.0055),(1.007,0.011,1.007,0.011),(1.006,0.009,1.006,0.009),(1.008,0.012,1.005,0.005)]:
    pred=tree(x2>k*x0-m*x1, x2<k2*x0-m2*x1)
    print("full",k,m,k2,m2, reward(reg, pred==Y, 3, 4+2/3*4))
