
import numpy as np, math
W=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(np.outer(X[:,0],W),0)
    for t in range(1,3):
        h=np.maximum(np.outer(X[:,t],W)+h@R.T,0)
    return (h@O.T).argmax(1)
# boundary x0 ~ x1 with x2 fixed: x2 = -1 (x2 min) or +1 (x2 max); x1 = a, scan x0
def boundary(x2, a_list, lo=-0.3, hi=0.3, n=6001):
    for a in a_list:
        x0=a+np.linspace(lo,hi,n)
        Xs=np.stack([x0,np.full(n,a),np.full(n,x2)],1)
        y=net(Xs)
        tr=np.nonzero(np.diff(y)!=0)[0]
        print("  x1=a=",a, [(round(x0[i]-a,4), int(y[i]), int(y[i+1])) for i in tr])
for x2 in [-1.0, 1.0]:
    print("x2=",x2)
    boundary(x2, [-3,-2,-1.5,-1.2,-0.9,-0.6,-0.3,-0.1,0.1,0.3,0.6,0.9,1.2,1.5,2,3])
