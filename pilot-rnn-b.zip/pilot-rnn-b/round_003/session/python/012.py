
import numpy as np, math
X,Y,ops=network_outputs()
X=np.asarray(X,dtype=float); Y=np.asarray(Y)
print(X[:5], X.dtype, X.mean(0), X.std(0))
# check for rounding
print(np.unique(np.round(X,6)).size, X.size)
print("float32 exact?", np.all(X.astype(np.float32).astype(np.float64)==X))
# fraction near x1~x2
d=X[:,1]-X[:,2]
print("frac |d|<0.045", (np.abs(d)<0.045).mean(), "expected", 2*(0.5-0.5*math.erfc(0.045/math.sqrt(2)/math.sqrt(2))) )
from scipy import stats
print(stats.kstest(X.ravel(),'norm'))
print(stats.kstest(d/np.sqrt(2),'norm'))
# correlation structure
print(np.corrcoef(X.T))
