
X,Y,ops=no
X=np.asarray(X,dtype=float); Y=np.asarray(Y)
print(X.shape,Y.shape,ops, (net(X)==Y).mean())
# CI check: n=15920,k=15831 -> 0.993126
n,k=15920,15831; p=k/n; z=1.959964
wil=( (p+z*z/(2*n)) - z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)) )/(1+z*z/n)
print("wilson",wil, "normal", p-z*math.sqrt(p*(1-p)/n))
