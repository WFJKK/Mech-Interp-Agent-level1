
import json
for n in ['best','r2s1','r2s2','r2s3','r2s4']:
    e=entries[n]
    consts=[nd.get('value') for nd in e['nodes'] if nd['op']=='const']
    print(n, consts)
