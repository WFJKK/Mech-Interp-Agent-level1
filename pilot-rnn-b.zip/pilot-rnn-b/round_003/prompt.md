# The task

You are given a neural network: its definition and its weights. You are not told what it was
trained to do.

Your goal is to interpret it. An **interpretation** here is a program that predicts the network's
output from the input without running the network. You hand it in as an **entry**: the
interpretation together with the **region** of inputs it applies to.

The verifier measures three things about an entry: its **coverage** (how much of the data set the
region holds), its **fidelity** (how often the interpretation gives the network's output there) and
its **cost** (its operations, compared with a forward pass). They are defined exactly under "How an
entry is scored", where one formula combines them into the reward. Your aim is the highest reward.

This is round 3 of at most 5. Each round is a fresh session: you keep nothing
from earlier rounds except what is written under "Earlier rounds" below and the saved entries.

## The network

Its definition is this file. In your sandbox it is the module `model`, and the same network is
written there as an entry by `model.reference(g, lv1)`.

```python
"""The network, written in the entry language.

An input is n_ctx real numbers, x_0 to x_(n_ctx - 1). The network reads them one at a time, in that order.
In an entry, g.token(t) is x_t, as a float, and g.tokens() is all of them; the output is still a whole number.

The network is a recurrent network with one layer of d_hidden units, a ReLU and no biases. Its weights:

    input       d_hidden x 1
    recurrent   d_hidden x d_hidden
    readout     n_outputs x d_hidden

Its state h, a vector of d_hidden numbers, starts at zero. At each position t, in order, it becomes

    h = relu(input x_t + recurrent h)

where relu sets every negative number to zero. After the last position, readout h gives n_outputs numbers,
and the output is the position of the highest (the first one on a tie).
"""


def reference(g, lv1):
    """The network's output on the graph's input. g is an lv1.Graph, lv1 the entry language."""
    w, rec = g.weight("input")[:, 0], g.weight("recurrent")
    h = lv1.maximum(w * g.token(0), 0.0)  # the first position: the state before it is zero, and so is recurrent h
    for t in range(1, g.n_ctx):
        h = lv1.maximum(w * g.token(t) + rec @ h, 0.0)
    return (g.weight("readout") @ h).argmax()
```

Sizes: n_ctx = 3, d_hidden = 4, outputs: 3. One forward pass of the network costs 78 operations under the prices
below.

## The data set

An input is three real numbers, x_0, x_1 and x_2, each drawn on its own from the standard normal distribution (mean 0, standard deviation 1). The data set is every input that can be drawn this way, each weighted by how likely it is to be drawn. There are infinitely many, so the verifier scores a sample.

## Entries

An entry is a program with two results per input:

- its **region**: a boolean. Is this input one the entry speaks about? Leave it out and the region is
  every input.
- its **interpretation**: a whole number, the network's output on this input as the entry predicts
  it. It is only computed for inputs in the region.

An entry is a graph of operations on tensors, stored as JSON data. You write it in Python with the
entry language `lv1`, and the verifier interprets the JSON; nothing of an entry is run as code, so
only the operations below exist.

### Writing one

```python
g = graph()                      # a new lv1.Graph on this network's weights
a, b = g.token(0), g.token(1)    # the input's tokens, whole numbers
t = g.tokens()                   # all of them, as a vector
W = g.weight("embed")            # a weight matrix, by name
c = g.const([1.0, 2.0])          # a constant; plain Python numbers and numpy arrays become constants too
r = g.arange(8)                  # 0, 1, ..., 7

x = W[:, a] * 2.0 + W[:, b]      # arithmetic and comparisons as in numpy, with broadcasting
entry = g.entry(interpretation=(a + b) % info["n_outputs"], region=a < 8)   # only an example of the format
save_entry("example", entry)     # keep it; submit_entry takes the name
print(measure(entry))            # coverage, fidelity, cost and the reward, as the verifier measures them
```

Every expression is also computed on an example input (all tokens 0) while you build, so `x.shape`
and `x.value` exist and a wrong shape fails at the line that makes it. `graph(example=[3, 5])`
builds on another example input, given as one number per position of the input.
`lv1.Graph.load(entry, weights, n_ctx)` opens a saved entry again and returns
`(graph, interpretation, region)`. In the stored JSON the interpretation is called `predict` and
the region `rule`.

Values are whole numbers, floats or booleans (64 bits). There are no loops and no Python `if` on
expressions: use `lv1.where(c, x, y)` (both sides are computed) or `lv1.cond(c, x, y)` (c is one
boolean, and only the chosen side is computed and charged).

### Operations and what they cost

Each operation on numbers costs 1. Per entry of the result unless said otherwise:

| Operation | Cost |
| --- | --- |
| `+ - * / // %`, unary `-`, `abs(x)`, `lv1.maximum`, `lv1.minimum`, `lv1.exp`, `lv1.log`, `lv1.sqrt` | 1 |
| `< <= > >= == !=`, `&`, `\|`, `~` (booleans) | 1 |
| `lv1.where(c, x, y)` | 1 |
| `lv1.cond(c, x, y)` | 1 in all, plus the chosen side |
| `x @ y`, `lv1.matmul(x, y)` | 1 per multiply-add: result entries times the contracted length |
| `x.sum(axis)`, `.max`, `.min`, `.argmax`, `.argmin`, `.any`, `.all` over n entries | n - 1 |
| `lv1.cumsum(x, axis)` | n - 1 per vector |
| `lv1.sort(x, axis)`, `lv1.argsort(x, axis)` of n entries | n * ceil(log2 n) per vector |
| `lv1.softmax(x, axis)` | 3 |
| `x[i]`, `x[i, j]`, `x[:, i]` with expressions that are one whole number (`lv1.gather`) | 1 per entry read |
| `x[v]` or `lv1.take(x, v, axis)` with a vector of whole numbers | 1 per entry read |
| `lv1.take_sum(x, v, axis)`: the sum of the slices of x at the positions v | slice entries times len(v) |
| `lv1.svd(x)` of an m x n matrix: `(u, s, vt)` | 4 * m * n * min(m, n), once for the three |
| `lv1.cast(x, "int")`, `"float"`, `"bool"` | 1 |
| `g.token`, `g.tokens`, `g.weight`, `g.const`, `g.arange` | 0 |
| `x.reshape(...)`, `x.T`, `lv1.transpose`, `x[2]`, `x[1:5]`, `x[None]`, `lv1.concat`, `lv1.stack` | 0 |

Reading costs 1 per number read: `T[a, b]` reads one number, `T[:, a]` a whole column.

### What an entry's cost is made of

Everything an entry computes is counted, in three parts:

- **Build.** Whatever does not depend on the input is computed once, when first needed. A table
  computed from the weights is paid for in full here.
- **Region test.** What the region computes from the input, charged for every input the verifier
  runs, in the region or not.
- **Interpretation.** What the interpretation computes from the input, charged for the inputs in the
  region. A value the region test already computed for an input is not charged again.

The entry's cost is the three together, per input of the region, as a share of one forward pass.
`measure(entry)` gives it as `cost`, and the parts as `b`, `r_rule` and `r`.

### Limits

The run limits an entry's size and the time the verifier gives it: the numbers are under "Tools,
budgets and limits" in your message. A constant counts every number it holds, and no single value
may hold more than 4,000,000 numbers. The verifier refuses an entry, and says why, when on any
input an index is out of range, shapes do not fit, the region is not one boolean, the
interpretation is not one whole number, or a float that is not finite is cast to a whole number.
An interpretation that gives something other than one of the network's outputs counts as a wrong
answer.

## How an entry is scored

The verifier runs the entry on 16,384 inputs drawn afresh from the data set for each submission and measures:

- **coverage**: the share of those inputs that are in the entry's region;
- **fidelity**: the share of the inputs in the region on which the interpretation gives the
  network's output;
- **cost**: all the operations the entry spends on those inputs (its build once, its region test on
  every input, its interpretation on the inputs in the region), divided by the number of inputs in
  the region and by the operations of one forward pass.

The reward is

    reward = coverage * [ (1 - cost) - alpha * (1 - fidelity) ],   alpha = 10

Read it for one input of the region: using the entry there in place of the network saves
(1 - cost) of a forward pass, and with probability (1 - fidelity) its answer is wrong, which is
charged at 10 forward passes. Coverage turns that into a share of the data set; the inputs
outside the region are left to the network and earn nothing.

The network itself, as an entry, has fidelity 1 and cost 1, which makes 0; an entry that is right
everywhere at no cost would score 1. An entry whose region is empty scores 0, less what its region
test and its build cost.

Because the verifier scores a sample, two things follow. The fidelity the reward uses is the lower end
of its 95% confidence interval on that sample: a lucky sample does not pay, and even an entry that is
right on every sampled input is charged a little (the network itself then scores just under 0). And
the same entry submitted twice gets two slightly different rewards.

When the rounds are over, the entry with the highest reward is locked and run, unchanged, on a
second network: the same definition, sizes and training, with another random seed. You never see
that network. What an entry computes from the weights is computed afresh there; a number you read
off this network and wrote into the entry as a constant stays what it was. With every submission you
state the fidelity you claim on this network and the fidelity you expect on the second one; both are
compared with what is measured.

## Tools, budgets and limits

- `run_python(code)`: up to 40 calls this round, 300 s each. Exploring
  costs nothing: only a submitted entry is scored.
- `submit_entry(name, claimed_fidelity, expected_fidelity_other)`: up to 4 submissions
  this round.
- An entry may have up to 400 nodes, and its constants up to 256 numbers in all.
  The verifier gives an entry 120 s on its inputs.

## Earlier rounds

### Round 1

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r1s1 | scored | 0.7695 | 1.0000 | 0.98572 | 0.0684 | 0.98400 | 0.97500 |
| r1s2 | scored | 0.7695 | 1.0000 | 0.98572 | 0.0683 | 0.98400 | 0.97500 |

Notes of that round:

    ## What the network does
    The network computes the **position of the median** of the three inputs (x_0, x_1, x_2): output 0 if x_0 lies between the other two, 1 if x_1 does, 2 if x_2 does. This holds on ~98.5% of standard-normal inputs (plain median rule agrees with the network on 98.46% of 3M sampled inputs; verifier samples gave 98.57%). The function is scale-invariant (no biases), so all deviations are thin cones around the median's boundary planes x_i = x_j, of relative width ~1–3%:
    - Main deviation (≈1.2% of inputs): when x_1 ≈ x_2 and x_0 is the extreme (min or max), the network outputs **0** instead of 1/2. The wedge is |x_2 − x_1| < ~0.012·| |x_0| − 2x_1 |, plus a wider "bulge" when 0.5|x_0| < x_1 < |x_0|.
    - Tilts (≈0.34%): when x_0 ≈ x_2 (x_0 the true median) it tends to say 2; when x_0 ≈ x_1 it tends to say 1 (boundary planes tilted by ~0.7–2%).
    Very confident about the median semantics; the wedge/tilt details are this network's artifacts.
    
    ## How you found it
    Looked at both. Weights: input weights split the 4 units into a "positive" pair (0,1) and a "negative" pair (2,3) with a mirror symmetry under x → −x; readout rows are ≈ multiples of (−1,1,1,−1), so the output depends on the ratio (h1+h2)/(h0+h3) with two thresholds. Outputs: tested candidate rules on the sample (argmax/argmin/abs ≈ chance; median position 98.2%). Then, on 1–3M random inputs, enumerated the ReLU activation patterns, computed each pattern's exact linear decision planes, and scanned 1-D slices (x_0 = ±1, x_1 = u·x_0, varying x_2) to map the error wedges. Also tested cheap fixes (scaled comparisons, wedge tests with various scales) — none beat the cost of their ops.
    
    ## The best entry
    `median_adaptive` (submitted twice: rewards 0.7695, 0.7695; fidelity 0.9857, cost 0.068). Region: all inputs. Interpretation: an adaptive comparison tree with `lv1.cond`: compare x_0 > x_1, then x_2 > x_1, then (only if needed) x_2 > x_0 — returns the index of the median of three. Expected 2.67 comparisons + 2.67 conds = 5.33 ops per input (vs 78 for a forward pass), no build, no constants from the weights. Saving comes entirely from replacing the recurrent forward pass by at most three scalar comparisons. Also saved but not submitted: `median_wedge` (adds the x_1≈x_2 → 0 wedge test inside the sub-branches; 11.3 ops, fidelity ≈0.990, local reward 0.74 vs 0.73 for the plain one on the same sample — break-even and network-specific).
    
    ## Claims
    Claimed fidelity on this network: 0.984 (large-sample estimate 0.9846; verifier measured 0.9857). Expected on the second network: 0.975 — the median rule is the task, so a similarly trained network should match it at a similar rate, but its tie-region artifacts will be different and could be somewhat larger.
    
    ## Next
    - Reward is bounded by cost: each op ≈ 0.0128 reward, each 0.1% error ≈ 0.01. The plain median at 5.33 ops is near-optimal; only a ≤2-op fix removing ≥0.3% error would help. Ideas not yet tried: a single cheap test that captures the wedge in *both* sub-branches at once (e.g., reuse of x_2 − x_1 across the tree), or an exact description of the wedge via the network's own hidden-ratio quantity if it can be written in ≤4 ops.
    - If the second network's behaviour matters most, keep the plain median (robust); if only this network's reward matters, `median_wedge` with per-branch δ (≈0.011–0.013) is at best +0.005.
    - Possibly resubmit `median_adaptive` for sampling noise; no other structural gains found.

### Round 2

| saved as | status | reward | coverage | fidelity | cost | claimed | expected on the second |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r2s1 | scored | 0.8000 | 0.9711 | 0.99447 | 0.1081 | 0.99500 | 0.98500 |
| r2s2 | scored | 0.8079 | 0.9742 | 0.99493 | 0.1078 | 0.99500 | 0.98500 |
| r2s3 | scored | 0.8027 | 0.9753 | 0.99437 | 0.1078 | 0.99500 | 0.98500 |
| r2s4 | scored | 0.8091 | 0.9730 | 0.99517 | 0.1081 | 0.99470 | 0.98500 |

Notes of that round:

    ## What the network does
    The network outputs the **position of the median** of (x_0, x_1, x_2). The plain median rule matches it on ~98.45% of standard‑normal inputs (large‑sample estimate; verifier samples 98.2–98.6%). The network has no biases so it is scale‑invariant, and all disagreements are thin cones around the tie planes:
    - Main artifact (~1.1–1.2% of inputs): a wedge around x_1 ≈ x_2 where the network outputs 0 instead of 1/2 (width relative to scale: |x_1−x_2|/(|x_0|+|x_1|) < ~0.04, in absolute terms almost entirely |x_1−x_2| < 0.05).
    - Residual (~0.45% of inputs after removing that slab): sign‑dependent, two‑sided deviations at x_0 ≈ x_2 (0.29%: med 0→2 and 2→0) and x_0 ≈ x_1 (0.15%). These are not simple tilts: a linear tilt of the comparison planes (x_2·k > x_0, or x_2 > x_0 + a·x_1, even per branch) only removes ~10–20% of them, less than its op cost.
    Very confident in the median semantics; the artifacts are this network's own.
    
    ## How you found it
    Both weights and outputs. This round: re‑verified my numpy forward pass against `network_outputs()` (100% agreement), sampled 3–6M inputs, split the median‑rule errors by closest pair, and mapped them in the normalized (x_1/x_0, x_2/x_0) plane (errors lie on the diagonal x_1=x_2 wedge and the lines x_1=x_0, x_2=x_0; the network is exactly symmetric under x→−x). Then evaluated many candidate region shapes (absolute slab |x_1−x_2|>t, relative slabs vs |x_0|, pairwise/triple products of differences, min of the three |differences|, two slabs) and candidate interpretation fixes (wedge→0 leaf fixes, per‑branch tilted comparisons) with the exact reward formula including the 95% lower‑CI fidelity penalty. The absolute slab at 3 ops dominated everything; the verifier’s samples run ~0.1% lower fidelity than my large‑sample estimate (0.9945 vs 0.9955), apparently sampling luck.
    
    ## The best entry
    `median_slab05` (reward 0.8091; also `median_slab045`, 0.8079/0.8027). Region: |x_1 − x_2| > 0.05 (3 ops on every input: subtract, abs, compare; coverage ≈ 97.2%). Interpretation: the adaptive median comparison tree with `lv1.cond` — c1 = x_0 > x_1, c2 = (x_1−x_2) < 0 (reusing the region’s difference), and only when c1 == c2 a third compare x_2 > x_0 to pick 0 or 2; otherwise 1. ≈5.33 ops per input in the region, no build, no weight‑derived constants. Total cost ≈ 0.108 of a forward pass; fidelity 0.9945–0.9952 on verifier samples. The gain over round 1 comes from excluding the x_1≈x_2 wedge (which held ~75% of the median rule’s errors) for just 3 ops and ~2.8% coverage.
    
    ## Claims
    Claimed fidelity on this network: 0.9947 (large‑sample 0.9955, verifier samples 0.9944–0.9952). Expected on the second network: 0.985 — the median task should be learned equally well, but a differently seeded network’s tie artifacts may sit on other planes (x_0≈x_1 or x_0≈x_2) where the slab gives no protection; with no slab‑relevant artifact it should still match the median at ≥98%.
    
    ## Next
    - Cost floor reached for this family: 3‑op region + 5.33‑op tree; each extra op costs ≈0.013 reward, each 0.1% error ≈0.01. Remaining losses: residual errors 0.45% (≈0.045), coverage loss 2.8% (≈0.025), cost (0.108), CI penalty (≈0.012).
    - Only ideas left with any chance: a 3‑op region of a different shape that removes more than the slab (none found among products/relative forms), or an exact ≤2‑op fix for the x_0≈x_2 confusions — but those are sign‑dependent in both directions, so a linear tilt won't do. An exact activation‑pattern emulation costs ≥30 ops and scores worse (~0.6).
    - Otherwise just resubmit `median_slab05`/`median_slab045` for sampling noise (rewards vary ±0.01 between samples); t between 0.04 and 0.06 is flat.

The scored entries above are in `entries` under the names in the first column, and the best so far (reward 0.8091) is also there as `best`.

## What to send back at the end

End your last message with these notes, with exactly these headings. They are all the next round
will know of this one.

    ## What the network does
    (in words: what you found, on which inputs, and how sure you are)

    ## How you found it
    (what you looked at: the network's outputs, its weights, or both, and what you ran)

    ## The best entry
    (its name, its region, what its interpretation does, and where its saving comes from)

    ## Claims
    (the fidelity you claim on this network and the one you expect on the second network, and why)

    ## Next
    (what you would try next)
