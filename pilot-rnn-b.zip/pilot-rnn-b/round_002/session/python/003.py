
m12 = (closest==1)
e = err & m12
print("errors in 12-group:", e.sum())
# distribution of d12 among errors
qs = [0.5,0.8,0.9,0.95,0.98,0.99,1.0]
print("d12 quantiles among errors:", np.quantile(d12[e], qs))
r = d12/np.abs(X[:,0])
print("d12/|x0| quantiles among errors:", np.quantile(r[e], qs))
s = d12/(np.abs(X[:,0])+np.abs(X[:,1]))
print("d12/(|x0|+|x1|):", np.quantile(s[e], qs))
# remaining errors after d12>t, by group
for t in [0.03,0.04,0.05,0.06,0.07]:
    reg = d12>t
    print(t, "remaining err frac", err[reg].mean(), "by group", [ (err&reg&(closest==c)).sum()/reg.sum() for c in range(3)])
# relative threshold
for c in [0.02,0.03,0.04,0.05,0.06]:
    reg = d12 > c*np.abs(X[:,0])
    cov = reg.mean(); fid = 1-err[reg].mean()
    cost = (5/cov + 5.33)/78
    print("rel", c, cov, fid, cov*((1-cost) - 10*(1-fid)))
