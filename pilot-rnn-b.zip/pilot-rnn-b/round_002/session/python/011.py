
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(5)
N = 4_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
x0,x1,x2 = X.T
reg = np.abs(x1-x2)>0.05
c1 = x0>x1; c2 = x2>x1
sub = reg & (c1==c2)
ys = y[sub]; a0=x0[sub]; a1=x1[sub]; a2=x2[sub]; cc=c1[sub]
def ev(c3): 
    pred = np.where(c3==cc, 0, 2); return (pred!=ys).sum()/N
print("baseline", ev(a2>a0))
for k in np.arange(0.97,1.03,0.005): print("k",round(k,3), ev(a2*k>a0))
for a in np.arange(-0.03,0.035,0.005): print("a",round(a,3), ev(a2>a0+a*a1))
# split by cc (x1 min vs max) and by sign of x0
for cv in [True, False]:
    for s in [1,-1]:
        m = (cc==cv)&(np.sign(a0)==s)
        e = ((a2>a0)!=cc)&(ys!=0)|(((a2>a0)==cc)&(ys!=0)) # placeholder
        pred = np.where((a2>a0)==cc,0,2)
        em = (pred!=ys)&m
        print("x1min" if cv else "x1max", "x0 sign", s, "errs", em.sum()/N, "net says 2 among errs:", (ys[em]==2).mean(), "x2>x0 among errs", (a2>a0)[em].mean())
