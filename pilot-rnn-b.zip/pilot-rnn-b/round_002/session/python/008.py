
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
# check symmetry
rng = np.random.default_rng(4)
X = rng.standard_normal((100000,3))
print("sym x->-x:", (fwd(X)==fwd(-X)).mean())
# grid in (u,v) with x0=1
u = np.linspace(-3,3,601); v = np.linspace(-3,3,601)
U,V = np.meshgrid(u,v, indexing='ij')
G = np.stack([np.ones(U.size), U.ravel(), V.ravel()],1)
yg = fwd(G).reshape(U.shape)
mg = np.argsort(G,axis=1)[:,1].reshape(U.shape)
E = yg != mg
print("grid err frac", E.mean())
# print coarse map of errors: rows u, cols v; mark where err, with the network output
step=20
for i in range(0,601,step):
    row=''
    for j in range(0,601,step):
        blk = E[i:i+step, j:j+step]
        if blk.mean()>0.3: row+='#'
        elif blk.any(): row+='.'
        else: row+=' '
    print(f"u={u[i]:+.1f} |{row}|")
