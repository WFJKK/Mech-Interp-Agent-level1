
import numpy as np
Xs, ys, ops = network_outputs()
Xs = np.asarray(Xs, dtype=np.float64); ys = np.asarray(ys)
print(Xs.shape, ys.shape, Xs.dtype, ops)
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
print(w.dtype)
def fwd(X, dt=np.float64):
    w_, r_, o_ = w.astype(dt), rec.astype(dt), ro.astype(dt)
    X = X.astype(dt)
    h = np.maximum(np.outer(X[:,0], w_), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w_) + h @ r_.T, 0)
    return (h @ o_.T).argmax(1)
for dt in [np.float64, np.float32]:
    print(dt, (fwd(Xs, dt)==ys).mean())
med = np.argsort(Xs,axis=1)[:,1]
ad = np.abs(Xs[:,1]-Xs[:,2])
print("median agreement all:", (med==ys).mean(), " in slab>0.05:", (med==ys)[ad>0.05].mean(), "coverage", (ad>0.05).mean())
print("std of inputs:", Xs.std(0), Xs.mean(0))
