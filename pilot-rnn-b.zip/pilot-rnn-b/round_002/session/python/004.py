
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(0)
N = 3_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
med = np.argsort(X,axis=1)[:,1]
err = y != med
d01 = np.abs(X[:,0]-X[:,1]); d12 = np.abs(X[:,1]-X[:,2]); d02 = np.abs(X[:,0]-X[:,2])
closest = np.argmin(np.stack([d01,d12,d02],1),1)
m12 = (closest==1)
e = err & m12
print("errors in 12-group:", e.sum())
qs = [0.5,0.8,0.9,0.95,0.98,0.99,1.0]
print("d12 quantiles among errors:", np.quantile(d12[e], qs))
r = d12/np.abs(X[:,0])
print("d12/|x0| quantiles among errors:", np.quantile(r[e], qs))
s = d12/(np.abs(X[:,0])+np.abs(X[:,1]))
print("d12/(|x0|+|x1|):", np.quantile(s[e], qs))
for t in [0.03,0.04,0.05,0.06,0.07]:
    reg = d12>t
    print(t, "remaining err frac", err[reg].mean(), "by group", [ (err&reg&(closest==c)).sum()/reg.sum() for c in range(3)])
for c in [0.02,0.03,0.04,0.05,0.06]:
    reg = d12 > c*np.abs(X[:,0])
    cov = reg.mean(); fid = 1-err[reg].mean()
    cost = (5/cov + 5.33)/78
    print("rel", c, cov, fid, cov*((1-cost) - 10*(1-fid)))
