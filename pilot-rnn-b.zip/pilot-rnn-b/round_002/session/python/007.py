
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(3)
N = 4_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
med = np.argsort(X,axis=1)[:,1]
err = y != med
x0,x1,x2 = X.T
d01=x0-x1; d12=x1-x2; d02=x0-x2
reg = np.abs(d12)>0.05
e = err & reg
print("remaining errors:", e.sum()/N)
# categorize: true median, network output
import collections
c = collections.Counter(zip(med[e], y[e]))
print(c)
# For 02 confusion: look at (x2-x0) relative to x1 and sign of things
m = e & (med==0) & (y==2)
print("med0->2: n", m.sum())
print("quantiles of (x2-x0):", np.quantile(d02[m]*-1, [0.05,0.25,0.5,0.75,0.95]))
print("quantiles of (x2-x0)/|x1|:", np.quantile((-d02/np.abs(x1))[m], [0.05,0.25,0.5,0.75,0.95]))
print("quantiles of (x2-x0)/|x0|:", np.quantile((-d02/np.abs(x0))[m], [0.05,0.25,0.5,0.75,0.95]))
print("sign x0, sign x1 counts:", collections.Counter(zip(np.sign(x0[m]), np.sign(x1[m]))))
m = e & (med==2) & (y==0)
print("med2->0: n", m.sum())
print("quantiles of (x2-x0)/|x0|:", np.quantile((-d02/np.abs(x0))[m], [0.05,0.25,0.5,0.75,0.95]))
print("sign x0, sign x1 counts:", collections.Counter(zip(np.sign(x0[m]), np.sign(x1[m]))))
m = e & (med==0) & (y==1)
print("med0->1: n", m.sum())
print("quantiles of (x1-x0)/|x0|:", np.quantile((-d01/np.abs(x0))[m], [0.05,0.25,0.5,0.75,0.95]))
print("sign x0, sign x2 counts:", collections.Counter(zip(np.sign(x0[m]), np.sign(x2[m]))))
m = e & (med==1) & (y==0)
print("med1->0: n", m.sum())
print("quantiles of (x1-x0)/|x0|:", np.quantile((-d01/np.abs(x0))[m], [0.05,0.25,0.5,0.75,0.95]))
print("sign x0, sign x2 counts:", collections.Counter(zip(np.sign(x0[m]), np.sign(x2[m]))))
