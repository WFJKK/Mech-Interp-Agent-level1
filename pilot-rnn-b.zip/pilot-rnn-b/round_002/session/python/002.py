
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(0)
N = 3_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
med = np.argsort(X,axis=1)[:,1]
err = y != med
print(err.mean())
d01 = np.abs(X[:,0]-X[:,1]); d12 = np.abs(X[:,1]-X[:,2]); d02 = np.abs(X[:,0]-X[:,2])
# error breakdown by which pair is closest
closest = np.argmin(np.stack([d01,d12,d02],1),1)
for c,name in enumerate(['01','12','02']):
    m = closest==c
    print(name, m.mean(), err[m].mean(), err[m].sum()/N)
# candidate region: |x1-x2| > t
for t in [0.02,0.05,0.08,0.1,0.15,0.2]:
    reg = d12 > t
    cov = reg.mean(); fid = 1-err[reg].mean()
    ops_r = 3; ops_i = 5.33
    cost = (ops_r/cov + ops_i)/78
    print(t, cov, fid, cost, cov*((1-cost) - 10*(1-fid)))
