
import numpy as np, collections
Xs, ys, ops = network_outputs()
Xs = np.asarray(Xs, dtype=np.float64); ys = np.asarray(ys)
print(Xs[:5])
print("float32 exact?", np.all(Xs.astype(np.float32).astype(np.float64)==Xs))
med = np.argsort(Xs,axis=1)[:,1]
ad = np.abs(Xs[:,1]-Xs[:,2])
reg = ad>0.05
e = reg & (med!=ys)
print("errors in region:", e.sum(), collections.Counter(zip(med[e], ys[e])))
# compare with expectation from big sample
w = weights['input'][:,0].astype(np.float64); rec = weights['recurrent'].astype(np.float64); ro = weights['readout'].astype(np.float64)
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rs = np.random.RandomState(99); X = rs.randn(4_000_000,3); y=fwd(X)
m2 = np.argsort(X,axis=1)[:,1]; a2=np.abs(X[:,1]-X[:,2]); r2=a2>0.05; e2=r2&(m2!=y)
c = collections.Counter(zip(m2[e2], y[e2]))
print("expected per 15920:", {k: v/r2.sum()*15920 for k,v in c.items()})
# distribution checks on Xs: kurtosis, correlation
print("corr", np.corrcoef(Xs.T))
print("kurtosis", ((Xs-Xs.mean(0))**4).mean(0)/Xs.var(0)**2)
print("frac |x|>2:", (np.abs(Xs)>2).mean(0), "expected", 2*(1-0.97725))
