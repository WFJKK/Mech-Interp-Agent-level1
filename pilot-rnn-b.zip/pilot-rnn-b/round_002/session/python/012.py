
import numpy as np
def build(t):
    g = graph()
    x0, x1, x2 = g.token(0), g.token(1), g.token(2)
    d = x1 - x2
    region = abs(d) > t
    c1 = x0 > x1
    c2 = d < 0          # x2 > x1
    # if c1 == c2: x1 is extreme -> median is 0 or 2 by comparing x2, x0; else 1
    leaf_min = lv1.cond(x2 > x0, 0, 2)   # x1 is min: median = min(x0,x2)
    leaf_max = lv1.cond(x2 > x0, 2, 0)   # x1 is max: median = max(x0,x2)
    interp = lv1.cond(c1, lv1.cond(c2, leaf_min, 1), lv1.cond(c2, 1, leaf_max))
    return g.entry(interpretation=interp, region=region)
for t in [0.045, 0.05]:
    e = build(t)
    m = measure(e)
    print(t, m)
save_entry("median_slab045", build(0.045))
save_entry("median_slab05", build(0.05))
# sanity check fidelity on a big sample via load
g, interp, region = lv1.Graph.load(entries['median_slab05'], weights, 3)
print(type(g), type(interp))
