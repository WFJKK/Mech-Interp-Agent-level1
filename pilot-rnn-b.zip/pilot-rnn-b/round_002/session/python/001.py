
import numpy as np
print(info)
print({k:v.shape for k,v in weights.items()})
for k,v in weights.items(): print(k, v)
print(list(entries.keys()))
print(measure(entries['best']))
