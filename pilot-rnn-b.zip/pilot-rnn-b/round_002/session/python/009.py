
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X, full=False):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    if full: return h, h @ ro.T
    return (h @ ro.T).argmax(1)
u = np.linspace(0.6,1.0,41); v = np.linspace(0.8,3.0,23)
U,V = np.meshgrid(u,v, indexing='ij')
G = np.stack([np.ones(U.size), U.ravel(), V.ravel()],1)
yg = fwd(G).reshape(U.shape)
mg = np.argsort(G,axis=1)[:,1].reshape(U.shape)
for i in range(len(u)):
    print(f"u={u[i]:.2f} " + ''.join(str(yg[i,j]) if yg[i,j]!=mg[i,j] else '.' for j in range(len(v))))
print("v:", v)
# examine a point: x0=1, x1=0.8, x2=2
h, lo = fwd(np.array([[1,0.8,2.0],[1,0.75,2.0],[1,0.85,2.0]]), True)
print(h); print(lo)
