
import numpy as np
w = weights['input'][:,0].astype(np.float64); rec = weights['recurrent'].astype(np.float64); ro = weights['readout'].astype(np.float64)
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rs = np.random.RandomState(21)
N=6_000_000
X = rs.randn(N, 3); y = fwd(X)
x0,x1,x2 = X.T
reg = np.abs(x1-x2)>0.05
c1 = x0>x1; c2 = x2>x1
for name, br, lo_hi in [("x1min", reg&c1&c2, (0,2)), ("x1max", reg&~c1&~c2, (2,0))]:
    ys=y[br]; a0=x0[br]; a1=x1[br]; a2=x2[br]
    print(name, "n", br.sum(), "net=1 count", (ys==1).sum()/N)
    base = np.where(a2>a0, lo_hi[0], lo_hi[1]); print(" base err", (base!=ys).sum()/N)
    for k in [0.97,0.98,0.985,0.99,0.995,1.0,1.005,1.01,1.015,1.02,1.03]:
        pred = np.where(a2*k>a0, lo_hi[0], lo_hi[1]); print("  k",k,(pred!=ys).sum()/N)
    for a in [-0.02,-0.01,-0.005,0.005,0.01,0.02]:
        pred = np.where(a2>a0+a*a1, lo_hi[0], lo_hi[1]); print("  a",a,(pred!=ys).sum()/N)
