
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(1)
N = 6_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
med = np.argsort(X,axis=1)[:,1]
err = y != med
d12 = np.abs(X[:,1]-X[:,2])
def est(reg, ops_r, ops_i=16/3, n=16384):
    cov = reg.mean(); fid = 1-err[reg].mean()
    nr = n*cov
    fl = fid - 1.96*np.sqrt(fid*(1-fid)/nr)
    cost = (ops_r/cov + ops_i)/78
    return cov, fid, fl, cost, cov*((1-cost) - 10*(1-fl))
for t in np.arange(0.035,0.08,0.005):
    print(round(t,3), est(d12>t, 3))
# signed asymmetric check: errors by sign of (x1-x2) and sign of x0
s = X[:,1]-X[:,2]
for t in [0.05]:
    reg = d12>t
    e = err & reg
    print("errors remaining by sign(s), sign(x0):")
    for ss in [-1,1]:
        for sx in [-1,1]:
            m = (np.sign(s)==ss)&(np.sign(X[:,0])==sx)
            print(ss, sx, (e&m).sum()/N, (err&m&(d12<=t)).sum()/N)
