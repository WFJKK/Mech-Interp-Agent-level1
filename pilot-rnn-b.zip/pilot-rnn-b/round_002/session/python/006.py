
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(2)
N = 6_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
med = np.argsort(X,axis=1)[:,1]
err = y != med
x0,x1,x2 = X.T
d01=x0-x1; d12=x1-x2; d02=x0-x2
def est(reg, ops_r, ops_i=16/3, n=16384):
    cov = reg.mean(); fid = 1-err[reg].mean()
    nr = n*cov
    fl = fid - 1.96*np.sqrt(fid*(1-fid)/nr)
    cost = (ops_r/cov + ops_i)/78
    return round(cov,4), round(fid,5), round(cost,4), round(cov*((1-cost) - 10*(1-fl)),4)
print("slab d12")
for t in [0.045,0.05]: print(t, est(np.abs(d12)>t, 3))
print("product d12*d02")
for T in [0.003,0.005,0.008,0.01,0.015,0.02,0.03]: print(T, est(np.abs(d12*d02)>T, 5))
print("product d12*d01")
for T in [0.003,0.005,0.008,0.01,0.015,0.02,0.03]: print(T, est(np.abs(d12*d01)>T, 5))
print("triple product")
for T in [0.001,0.002,0.003,0.005,0.008,0.01,0.015]: print(T, est(np.abs(d12*d01*d02)>T, 7))
print("min of three")
for t in [0.02,0.03,0.04,0.05]: print(t, est(np.minimum(np.minimum(np.abs(d01),np.abs(d12)),np.abs(d02))>t, 9))
print("d12 slab & d02 slab")
for t in [0.02,0.03,0.04,0.05]: print(t, est((np.abs(d12)>0.05)&(np.abs(d02)>t), 7))
