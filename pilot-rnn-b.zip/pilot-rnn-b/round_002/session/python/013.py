
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(6)
N = 6_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
med = np.argsort(X,axis=1)[:,1]
x0,x1,x2 = X.T
ad = np.abs(x1-x2)
def est(reg, pred, ops_r, ops_i, n=16384):
    cov = reg.mean(); fid = (pred[reg]==y[reg]).mean()
    nr = n*cov
    fl = fid - 1.96*np.sqrt(fid*(1-fid)/nr)
    cost = (ops_r/cov + ops_i)/78
    return round(cov,4), round(fid,5), round(cost,4), round(cov*((1-cost) - 10*(1-fl)),4)
print("plain slab 0.05:", est(ad>0.05, med, 3, 16/3))
for t1 in [0.0, 0.01, 0.02, 0.03]:
    for t2 in [0.03, 0.04, 0.05, 0.06, 0.08]:
        if t2<=t1: continue
        pred = np.where((ad<t2)&(med!=0), 0, med)
        ops_r = 3 if t1>0 else 1  # if t1==0 region is all; abs d still computed (1 op) in interpretation
        ops_i = 16/3 + 2*(2/3) + (0 if t1>0 else 1)  # d computed, abs computed, compare+cond on leaves
        print(t1, t2, est(ad>t1, pred, 3 if t1>0 else 0, 16/3 + 4/3 + (2 if t1==0 else 0)))
