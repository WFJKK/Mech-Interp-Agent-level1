
import numpy as np
w = weights['input'][:,0].astype(np.float64); rec = weights['recurrent'].astype(np.float64); ro = weights['readout'].astype(np.float64)
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
for seed in [11, 12]:
    rs = np.random.RandomState(seed)
    X = rs.randn(4_000_000, 3)
    y = fwd(X); med = np.argsort(X,axis=1)[:,1]; ad = np.abs(X[:,1]-X[:,2])
    print(seed, "all", (med==y).mean(), "slab05", (med==y)[ad>0.05].mean(), "slab045", (med==y)[ad>0.045].mean())
    # distribution of per-16384-block fidelity in slab
    f = []
    for i in range(0, 4_000_000, 16384):
        m = ad[i:i+16384]>0.05
        f.append((med==y)[i:i+16384][m].mean())
    f = np.array(f); print("block fid mean/std/min", f.mean(), f.std(), f.min())
