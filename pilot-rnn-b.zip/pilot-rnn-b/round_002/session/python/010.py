
import numpy as np
w = weights['input'][:,0]; rec = weights['recurrent']; ro = weights['readout']
def fwd(X):
    h = np.maximum(np.outer(X[:,0], w), 0)
    for t in range(1,3):
        h = np.maximum(np.outer(X[:,t], w) + h @ rec.T, 0)
    return (h @ ro.T).argmax(1)
rng = np.random.default_rng(5)
N = 4_000_000
X = rng.standard_normal((N,3))
y = fwd(X)
x0,x1,x2 = X.T
reg = np.abs(x1-x2)>0.05
c1 = x0>x1; c2 = x2>x1
sub = reg & (c1==c2)   # x1 extreme; answer 0 or 2
print("subset frac", sub.mean(), "net outputs:", np.bincount(y[sub]))
ys = y[sub]; a0=x0[sub]; a1=x1[sub]; a2=x2[sub]
base = np.where(a2>a0, 0, 2)
print("baseline err in subset:", (base!=ys).mean(), "overall contrib", (base!=ys).sum()/N)
best=None
for k in np.arange(0.96,1.04,0.005):
    pred = np.where(a2*k>a0, 0, 2); e=(pred!=ys).sum()/N
    print("k",round(k,3), e)
for a in np.arange(-0.04,0.045,0.01):
    pred = np.where(a2>a0+a*a1, 0, 2); e=(pred!=ys).sum()/N
    print("a",round(a,3), e)
