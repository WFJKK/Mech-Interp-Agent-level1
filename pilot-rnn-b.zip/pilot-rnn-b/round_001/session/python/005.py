
X, Y, _ = network_outputs()
order = np.argsort(X,1)
cands = {'median_pos':order[:,1], 'rank_of_x0':np.argsort(order,1)[:,0],'rank_of_x1':np.argsort(order,1)[:,1],'rank_of_x2':np.argsort(order,1)[:,2],
 'argmax_diff':np.abs(np.diff(X,axis=1)).argmax(1), 'nsignchange':(np.diff(np.sign(X),axis=1)!=0).sum(1), 'npos':(X>0).sum(1)%3,
 'argmaxabs_rev':2-np.abs(X).argmax(1),'argmax_rev':2-X.argmax(1),'argmin_rev':2-X.argmin(1)}
for k,v in cands.items(): print(k, (v==Y).mean())
# tree
from sklearn.tree import DecisionTreeClassifier, export_text
F = np.c_[X, np.abs(X), X[:,1]-X[:,0], X[:,2]-X[:,1], X[:,2]-X[:,0], np.abs(X[:,1]-X[:,0]), np.abs(X[:,2]-X[:,1]), np.abs(X[:,2]-X[:,0])]
names=['x0','x1','x2','a0','a1','a2','d10','d21','d20','ad10','ad21','ad20']
for depth in [2,3,4,6,8]:
    t=DecisionTreeClassifier(max_depth=depth).fit(F,Y); print(depth, t.score(F,Y))
t=DecisionTreeClassifier(max_depth=3).fit(F,Y); print(export_text(t,feature_names=names))
