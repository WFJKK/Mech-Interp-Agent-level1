
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(5)
X=rng.standard_normal((2000000,3)); Y=net(X)
x0,x1,x2=X.T
def err(a=1,b=1,c=1):
    c01=x0>a*x1; c02=b*x0>x2; c12=x1>c*x2
    pred=np.where(c01!=c02,0,np.where(c01==c12,1,2)); return (pred!=Y).mean()
print('base',err())
for a in [0.97,0.98,0.99,1.01,1.02,1.03]: print('a',a,err(a=a))
for b in [0.97,0.98,0.99,1.01,1.02,1.03]: print('b',b,err(b=b))
for c in [0.97,0.98,0.99,1.01,1.02,1.03]: print('c',c,err(c=c))
