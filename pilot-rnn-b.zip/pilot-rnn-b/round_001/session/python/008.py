
X, Y, _ = network_outputs()
med = np.argsort(X,1)[:,1]
bad = med!=Y
d01=np.abs(X[:,0]-X[:,1]); d12=np.abs(X[:,1]-X[:,2]); d02=np.abs(X[:,0]-X[:,2])
which = np.argmin(np.c_[d01,d12,d02],1)  # closest pair: 0->(0,1),1->(1,2),2->(0,2)
for wp in range(3):
    m = bad & (which==wp)
    print('pair',wp,'nbad',m.sum(), 'Y', np.bincount(Y[m],minlength=3),'med',np.bincount(med[m],minlength=3))
# for pair (1,2): probability of Y=0 vs d12, when median in {1,2}
m = (which==1)&(med!=0)
for lo,hi in [(0,0.01),(0.01,0.02),(0.02,0.04),(0.04,0.08),(0.08,0.16),(0.16,0.3)]:
    mm = m&(d12>=lo)&(d12<hi); print(lo,hi,mm.sum(), np.bincount(Y[mm],minlength=3), 'bad', bad[mm].mean())
