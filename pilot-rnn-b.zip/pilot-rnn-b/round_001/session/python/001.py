
import numpy as np
for k,v in weights.items(): print(k, v.shape); print(np.round(v,4))
print(info)
no = network_outputs()
print(type(no), [ (k, getattr(v,'shape',v) if not isinstance(v,(int,float)) else v) for k,v in (no.items() if isinstance(no,dict) else enumerate(no))])
