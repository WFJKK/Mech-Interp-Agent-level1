
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0); p0=(X[:,0]>0).astype(int)
    h=np.maximum(w[None]*X[:,1:2]+h@R.T,0); p1=(h>0).astype(int)
    h=np.maximum(w[None]*X[:,2:3]+h@R.T,0); p2=(h>0).astype(int)
    return (h@O.T).argmax(1), p0, p1, p2
rng=np.random.default_rng(0)
X=rng.standard_normal((400000,3)); Y,p0,p1,p2=net(X)
key = p0*256 + (p1*[8,4,2,1]).sum(1)*16 + (p2*[8,4,2,1]).sum(1)
ks,cnt=np.unique(key,return_counts=True)
def A_of(k):
    d0=np.array([k>>8]*4)*(w>0)+(1-(k>>8))*(w<0); d0=d0.astype(float)
    d1=np.array([(k>>7)&1,(k>>6)&1,(k>>5)&1,(k>>4)&1],float); d2=np.array([(k>>3)&1,(k>>2)&1,(k>>1)&1,k&1],float)
    A=np.zeros((4,3)); A[:,2]=d2*w; A[:,1]=d2*(R@(d1*w)); A[:,0]=d2*(R@(d1*(R@(d0*w))))
    return A
for k,c in sorted(zip(ks,cnt), key=lambda t:-t[1])[:12]:
    G=O@A_of(k); m=key==k
    print(f"x0>0={k>>8} p1={(k>>4)&15:04b} p2={k&15:04b} n={c} Y={np.bincount(Y[m],minlength=3)}")
    for i,j in [(0,1),(0,2),(1,2)]:
        v=G[i]-G[j]; v=v/np.linalg.norm(v); print(f"   o{i}-o{j} normal {np.round(v,3)}")
