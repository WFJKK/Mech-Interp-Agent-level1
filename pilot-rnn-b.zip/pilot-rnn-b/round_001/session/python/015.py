
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(3)
X=rng.standard_normal((3000000,3)); Y=net(X)
x0,x1,x2=X.T
Xn = X/np.linalg.norm(X,axis=1,keepdims=True)
ext=(x0>x1)==(x0>x2)
near = ext & (np.abs(x1-x2) < 0.15*np.linalg.norm(X,axis=1))
def fit(P, lab, iters=3000, lr=0.05):
    # logistic regression through origin on normalized points
    v=np.array([0.0,1.0,-1.0]); 
    for i in range(iters):
        s=P@v; p=1/(1+np.exp(-s*30)); grad=P.T@((p-lab))/len(P)*30
        v-=lr*grad
    return v/np.linalg.norm(v)
for regime_name, reg in [('x0 max', x0>x1), ('x0 min', x0<x1)]:
    for side_name, side in [('x1<x2', x1<x2), ('x1>x2', x1>x2)]:
        m = near&reg&side
        P=Xn[m]; lab=(Y[m]==0).astype(float)
        v=fit(P,lab)
        pred=(P@v>0)
        print(regime_name, side_name, m.sum(), 'frac Y=0', lab.mean(), 'normal', np.round(v/np.abs(v[1]),4), 'mismatch', (pred!=lab).mean())
