
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
def runs(v,Y):
    out=[]; start=0
    for i in range(1,len(Y)+1):
        if i==len(Y) or Y[i]!=Y[start]:
            out.append((Y[start], round(v[start],4), round(v[i-1],4))); start=i
    return out
for s0,u in [(1,0.8),(1,0.95),(1,0.5),(1,0.6),(1,0.7),(-1,-0.8),(-1,-0.5),(1,1.2),(1,1.05),(1,3.0),(-1,-3.0)]:
    v=np.linspace(u-0.4,u+0.4,8001); X=np.c_[np.full_like(v,s0), np.full_like(v,u), v]; Y=net(X)
    print(s0,u, runs(v,Y))
