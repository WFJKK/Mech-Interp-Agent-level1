
X, Y, _ = network_outputs()
print(np.bincount(Y)/len(Y))
# hypotheses: sign patterns
s = (X>0).astype(int)
for pat in range(8):
    m = (s[:,0]*4+s[:,1]*2+s[:,2])==pat
    print(pat, m.sum(), np.bincount(Y[m], minlength=3))
# try sum of inputs
S = X.sum(1)
for lo,hi in [(-9,-2),(-2,-1),(-1,-0.5),(-0.5,0),(0,0.5),(0.5,1),(1,2),(2,9)]:
    m=(S>lo)&(S<=hi); print(lo,hi,np.bincount(Y[m],minlength=3))
