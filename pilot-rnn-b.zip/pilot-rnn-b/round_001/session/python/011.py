
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0); p0=(X[:,0]>0).astype(int)
    h=np.maximum(w[None]*X[:,1:2]+h@R.T,0); p1=(h>0).astype(int)
    h=np.maximum(w[None]*X[:,2:3]+h@R.T,0); p2=(h>0).astype(int)
    return (h@O.T).argmax(1), h, p0, p1, p2
rng=np.random.default_rng(0)
X=rng.standard_normal((400000,3)); Y,H,p0,p1,p2=net(X)
med=np.argsort(X,1)[:,1]
key = p0*256 + (p1*[8,4,2,1]).sum(1)*16 + (p2*[8,4,2,1]).sum(1)
ks,cnt=np.unique(key,return_counts=True)
for k,c in sorted(zip(ks,cnt), key=lambda t:-t[1]):
    m=key==k
    print(f"x0>0={k>>8} p1={(k>>4)&15:04b} p2={k&15:04b} n={c} Y={np.bincount(Y[m],minlength=3)} err={(Y[m]!=med[m]).sum()}")
