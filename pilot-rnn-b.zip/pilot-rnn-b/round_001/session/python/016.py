
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
# grid scan: x0 = +1 (x0 max, i.e. u,v<1) and x0 = -1 (x0 min, u,v>-1)
for s0 in [1.0,-1.0]:
    print('x0 =',s0)
    for u in [-3,-2,-1.5,-1,-0.5,-0.2,0,0.2,0.5,0.8,0.95] if s0>0 else [-0.95,-0.8,-0.5,-0.2,0,0.2,0.5,1,1.5,2,3]:
        dv=np.linspace(-0.3,0.3,6001); v=u+dv
        X=np.c_[np.full_like(v,s0), np.full_like(v,u), v]; Y=net(X)
        z=Y==0
        if z.any(): print(f"  u={u:5.2f}: Y=0 for dv in [{dv[z].min():.4f},{dv[z].max():.4f}]  width {dv[z].max()-dv[z].min():.4f}  (contiguous: {z.sum()==(np.argmax(z[::-1])+0 or 0) or (dv[z].max()-dv[z].min())/0.0001+1-z.sum()<2})")
        else: print(f"  u={u:5.2f}: no Y=0")
