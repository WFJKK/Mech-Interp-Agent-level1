
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(1)
X=rng.standard_normal((1000000,3)); Y=net(X)
S=np.sort(X,1); order=np.argsort(X,1); med=order[:,1]
err=Y!=med
n=np.linalg.norm(X,axis=1)
# for errors: relative gaps (median - min)/n, (max - median)/n
g1=(S[:,1]-S[:,0])/n; g2=(S[:,2]-S[:,1])/n
print('err rate',err.mean())
for perm in [(0,1,2),(0,2,1),(1,0,2),(1,2,0),(2,0,1),(2,1,0)]:
    m=err&(order==np.array(perm)).all(1)
    for y in range(3):
        mm=m&(Y==y)
        if mm.sum()>20:
            print(perm,'Y=',y,mm.sum(),'g1 q',np.round(np.quantile(g1[mm],[.05,.5,.95]),3),'g2 q',np.round(np.quantile(g2[mm],[.05,.5,.95]),3), 'min(g1,g2)>0.05:',(np.minimum(g1,g2)[mm]>0.05).sum())
