
X, Y, _ = network_outputs()
med = np.argsort(X,1)[:,1]
bad = med!=Y
print(bad.sum())
B = X[bad]
print(np.round(B[:20],2), Y[bad][:20], med[bad][:20])
# features of the bad: min gap between sorted values
S=np.sort(X,1); gap=np.minimum(S[:,1]-S[:,0], S[:,2]-S[:,1])
print('gap quantiles bad', np.quantile(gap[bad],[0.1,0.5,0.9]), 'all', np.quantile(gap,[0.1,0.5,0.9]))
print('maxabs bad', np.quantile(np.abs(X[bad]).max(1),[0.1,0.5,0.9]))
print('sign patterns of bad', np.bincount(((X[bad]>0)*[4,2,1]).sum(1),minlength=8))
print('Y of bad', np.bincount(Y[bad],minlength=3), 'med of bad', np.bincount(med[bad],minlength=3))
