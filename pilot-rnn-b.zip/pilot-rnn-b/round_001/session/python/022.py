
g = graph()
x0,x1,x2 = g.token(0), g.token(1), g.token(2)
def wedge_then(ans):
    # output 0 if |x2-x1| < 0.012*| |x0| - 2 x1 |, else ans
    d = abs(x2 - x1); s = abs(abs(x0) - 2.0*x1)
    return lv1.cond(d < 0.012*s, 0, ans)
hi = lv1.cond(x2 > x1, lv1.cond(x2 > x0, 0, wedge_then(2)), wedge_then(1))
lo = lv1.cond(x2 > x1, wedge_then(1), lv1.cond(x2 > x0, wedge_then(2), 0))
pred = lv1.cond(x0 > x1, hi, lo)
e = g.entry(interpretation=pred)
save_entry("median_wedge", e)
print(measure(e))
print(measure(entries["median_adaptive"]))
