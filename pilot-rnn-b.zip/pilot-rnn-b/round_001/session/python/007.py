
g = graph()
x0,x1,x2 = g.token(0), g.token(1), g.token(2)
c01 = x0 > x1; c12 = x1 > x2; c02 = x0 > x2
pred = lv1.where(c01 != c02, 0, lv1.where(c01 == c12, 1, 2))
e = g.entry(interpretation=pred)
save_entry("median_plain", e)
print(measure(e))
