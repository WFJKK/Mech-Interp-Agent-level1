
X, Y, _ = network_outputs()
med = np.argsort(X,1)[:,1]
d01=np.abs(X[:,0]-X[:,1]); d12=np.abs(X[:,1]-X[:,2]); d02=np.abs(X[:,0]-X[:,2])
m = (med!=0)&(d12<0.1)
z = (Y[m]==0)
# look at d12 versus candidate scales
for name, sc in [('abs',np.ones(m.sum())),('d01',d01[m]),('|x1|',np.abs(X[m,1])),('|x0|',np.abs(X[m,0])),('|x0|+|x1|',np.abs(X[m,0])+np.abs(X[m,1]))]:
    r = d12[m]/sc
    # best threshold separating z
    ths = np.quantile(r, np.linspace(0.01,0.99,99))
    best = max(((( (r<t)==z).mean()),t) for t in ths)
    print(name, best)
# also sign of x1 (x1>0 vs <0), x2 > x1 vs <
for s0 in [0,1]:
  for s1 in [0,1]:
    mm = m & ((X[:,0]>0)==s0) & ((X[:,1]>0)==s1)
    r=d12[mm]; z=(Y[mm]==0)
    ths=np.linspace(0,0.1,101); best=max((((r<t)==z).mean(),t) for t in ths)
    print('x0>0',s0,'x1>0',s1, mm.sum(), best, 'med', np.bincount(med[mm],minlength=3))
