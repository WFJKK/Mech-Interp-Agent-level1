
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1), h
rng=np.random.default_rng(0)
X=rng.standard_normal((400000,3)); Y,H=net(X)
med=np.argsort(X,1)[:,1]
print('agree',(med==Y).mean())
order=np.argsort(X,1)
import itertools
for perm in itertools.permutations(range(3)):
    m=(order==np.array(perm)).all(1)
    print(perm, m.sum(), np.bincount(Y[m],minlength=3), 'median is', perm[1])
