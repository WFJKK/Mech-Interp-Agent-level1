
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(11)
X=rng.standard_normal((3000000,3)); Y=net(X)
x0,x1,x2=X.T
med=np.argsort(X,1)[:,1]
s=np.abs(x0)-2*x1
subs={'hi,x2<x1 (ans1)':(x1<x0)&(x2<x1),'hi,x1<x2<x0 (ans2)':(x1<x0)&(x2>x1)&(x2<x0),'lo,x2>x1 (ans1)':(x1>x0)&(x2>x1),'lo,x0<x2<x1 (ans2)':(x1>x0)&(x2<x1)&(x2>x0)}
total_gain=0
for name,m in subs.items():
    d=np.abs(x2-x1)[m]; e0=(med[m]!=Y[m]).sum()
    best=None
    for sc_name,sc in [('|s|',np.abs(s)[m]),('s',s[m]),('-s',-s[m])]:
        for dl in np.linspace(0.006,0.02,15):
            wd=d<dl*sc; pred=np.where(wd,0,med[m]); e=(pred!=Y[m]).sum()
            if best is None or e<best[0]: best=(e,sc_name,dl)
    print(name, m.mean(), 'err0',e0/len(X),'best',best[0]/len(X),best[1:], 'gain',(e0-best[0])/len(X))
    total_gain+=(e0-best[0])/len(X)
print('total gain',total_gain)
