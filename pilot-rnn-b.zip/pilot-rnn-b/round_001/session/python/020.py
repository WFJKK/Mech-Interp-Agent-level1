
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(7)
X=rng.standard_normal((3000000,3)); Y=net(X)
x0,x1,x2=X.T
med=np.argsort(X,1)[:,1]
E=(med!=Y)
print('total err',E.mean())
s=np.abs(x0)-2*x1; d=x2-x1
wedge=np.abs(d)<0.012*np.abs(s)
print('wedge frac',wedge.mean(),'err in wedge',(E&wedge).mean(),'Y=0 in wedge',(wedge&(Y==0)).mean(), 'wedge&Y!=0',(wedge&(Y!=0)).mean())
bulge=(x1>0.5*np.abs(x0))&(x1<np.abs(x0))&(np.abs(d)<0.15*np.abs(x0))
print('bulge frac',bulge.mean(),'err in bulge (not wedge)',(E&bulge&~wedge).mean())
tilt02=(med==0)&(Y==2); tilt01=(med==0)&(Y==1)
print('tilt02',tilt02.mean(),'tilt01',tilt01.mean())
rest=E&~wedge&~bulge&~tilt02&~tilt01
print('rest',rest.mean(), np.bincount(Y[rest],minlength=3), np.bincount(med[rest],minlength=3))
# error if we use the wedge rule in interpretation
pred=np.where(wedge,0,med); print('err with wedge->0', (pred!=Y).mean())
for dl in [0.008,0.01,0.011,0.012,0.013,0.014]:
    wd=np.abs(d)<dl*np.abs(s); print(dl,(np.where(wd,0,med)!=Y).mean())
