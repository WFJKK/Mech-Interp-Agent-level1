
X, Y, _ = network_outputs()
cands = {'argmax':X.argmax(1),'argmin':X.argmin(1),'argmaxabs':np.abs(X).argmax(1),'argminabs':np.abs(X).argmin(1)}
for k,v in cands.items(): print(k, (v==Y).mean())
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def fwd(x):
    h=np.maximum(w*x[0],0)
    for t in range(1,3): h=np.maximum(w*x[t]+R@h,0)
    return h, O@h
for x in X[:8]:
    h,o=fwd(x); print(np.round(x,2), np.round(h,2), np.round(o,2), o.argmax())
print(np.round(R@np.maximum(w,0),3), np.round(R@np.maximum(-w,0),3))
