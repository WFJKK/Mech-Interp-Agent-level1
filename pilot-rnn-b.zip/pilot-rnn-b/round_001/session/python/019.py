
g = graph()
x0,x1,x2 = g.token(0), g.token(1), g.token(2)
# adaptive: if x0 > x1: median is 1 if x2 < x1; else 0 if x2 > x0 else 2.  symmetric otherwise
c01 = x0 > x1
hi = lv1.cond(x2 > x1, lv1.cond(x2 > x0, 0, 2), 1)       # x1 < x0
lo = lv1.cond(x2 > x1, 1, lv1.cond(x2 > x0, 2, 0))       # x1 > x0
pred = lv1.cond(c01, hi, lo)
e = g.entry(interpretation=pred)
save_entry("median_adaptive", e)
print(measure(e))
# check against numpy on sample
X,Y,_ = network_outputs()
med=np.argsort(X,1)[:,1]
print((med==Y).mean())
