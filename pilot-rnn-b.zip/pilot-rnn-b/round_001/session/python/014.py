
w=weights['input'][:,0]; R=weights['recurrent']; O=weights['readout']
def net(X):
    h=np.maximum(w[None]*X[:,0:1],0)
    for t in range(1,3): h=np.maximum(w[None]*X[:,t:t+1]+h@R.T,0)
    return (h@O.T).argmax(1)
rng=np.random.default_rng(2)
X=rng.standard_normal((2000000,3)); Y=net(X)
x0,x1,x2=X.T
d01=x0-x1; d12=x1-x2; c01=d01>0; c12=d12>0; c02=x0>x2
ext = c01==c02   # x0 is extreme -> median is 1 or 2
base = np.where(~ext,0,np.where(c01==c12,1,2))
print('base err', (base!=Y).mean(), 'err in ext', ((base!=Y)&ext).mean(), 'err in ~ext', ((base!=Y)&~ext).mean())
z = (Y==0)&ext
scales = {'|d01|':np.abs(d01), '|x0|':np.abs(x0), '|d01|+|x1|':np.abs(d01)+np.abs(x1), '|d02|':np.abs(x0-x2), '|d01|+|d02|':np.abs(d01)+np.abs(x0-x2),'|x0|+|x1|':np.abs(x0)+np.abs(x1), 'max(|x0|,|x1|)':np.maximum(np.abs(x0),np.abs(x1)), '|x0-2x1|': np.abs(x0-2*x1), '|x0|+2|x1|':np.abs(x0)+2*np.abs(x1)}
for name,s in scales.items():
    best=None
    for d in np.linspace(0.005,0.1,96):
        wedge = (np.abs(d12) < d*s)&ext
        pred = np.where(wedge,0,base); e=(pred!=Y).mean()
        if best is None or e<best[0]: best=(e,d)
    print(name, best)
